// ============================================================================
// ferramentas-extra.js — Concurseiro Blindado (Planalto)
// Barra flutuante extra com: Lupa, Caneta (desenho livre), Ouvir em voz alta
// e Baixar em PDF. Fica separada do marcador de texto e do Modo de Leitura
// pra não competir com o z-index/eventos deles.
// ============================================================================

(function () {
    if (window.__cbFerramentasExtraLoaded) return;
    window.__cbFerramentasExtraLoaded = true;

    const ICON_LUPA = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>';
    const ICON_CANETA = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5z"/></svg>';
    const ICON_OUVIR = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>';
    const ICON_PDF = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="8" y1="17" x2="16" y2="17"/><line x1="8" y1="13" x2="12" y2="13"/></svg>';
    const ICON_PLAY = '<svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor"><polygon points="6 3 20 12 6 21 6 3"/></svg>';
    const ICON_PAUSE = '<svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>';
    const ICON_STOP = '<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><rect x="5" y="5" width="14" height="14" rx="2"/></svg>';
    const ICON_TRASH = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>';

    const CANETA_CORES = ['#ff3b30', '#2dd4a0', '#74c0fc', '#ffd43b', '#f2f2f7', '#000000'];
    const CANETA_TIPOS = [
        { id: 'fina', nome: 'Fina', largura: 2.5, opacidade: 1, blend: 'normal' },
        { id: 'media', nome: 'Média', largura: 5.5, opacidade: 1, blend: 'normal' },
        { id: 'grossa', nome: 'Grossa', largura: 10, opacidade: 1, blend: 'normal' },
        { id: 'marcador', nome: 'Marcador', largura: 20, opacidade: 0.35, blend: 'multiply' }
    ];

    const pageKey = 'cbDraw::' + location.href.split('#')[0];

    let rail = null;

    // -------------------- BUSCA DE PALAVRA-CHAVE --------------------
    let ultimoTermoBuscado = '';

    function contarOcorrencias(termo) {
        if (!termo) return 0;
        const alvo = document.getElementById('cb-reading-mode-overlay');
        const container = (alvo && alvo.style.display !== 'none') ? alvo : document.body;
        const texto = container.innerText || '';
        const escapado = termo.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const regex = new RegExp(escapado, 'gi');
        return (texto.match(regex) || []).length;
    }

    function atualizarContadorBusca() {
        const input = document.getElementById('cb-ft-busca-input');
        const contador = document.getElementById('cb-ft-busca-contador');
        const termo = input.value.trim();
        if (!termo) { contador.textContent = ''; return; }
        const total = contarOcorrencias(termo);
        contador.textContent = total ? `${total} ocorrência${total === 1 ? '' : 's'}` : 'nada encontrado';
    }

    function buscar(voltar) {
        const input = document.getElementById('cb-ft-busca-input');
        const termo = input.value.trim();
        if (!termo) return;
        if (termo !== ultimoTermoBuscado) window.getSelection().removeAllRanges();
        ultimoTermoBuscado = termo;
        // window.find() é uma API antiga mas ainda suportada pelo Chrome: busca,
        // seleciona e rola a página até o trecho — exatamente o comportamento de
        // um "Ctrl+F" de palavra-chave, sem precisar reimplementar navegação de
        // texto manualmente.
        const achou = window.find(termo, false, !!voltar, true, false, true, false);
        const contador = document.getElementById('cb-ft-busca-contador');
        if (!achou) {
            contador.textContent = 'nada encontrado';
        } else {
            atualizarContadorBusca();
        }
    }

    function focarBusca() {
        const input = document.getElementById('cb-ft-busca-input');
        if (input) { input.focus(); input.select(); }
    }

    // -------------------- CANETA (desenho livre) --------------------
    let canvasEl = null, ctx = null, desenhoAtivo = false, desenhando = false;
    let corAtual = CANETA_CORES[0], tipoAtual = CANETA_TIPOS[1];
    let ultimoX = 0, ultimoY = 0;

    function garantirCanvas() {
        if (canvasEl) return;
        canvasEl = document.createElement('canvas');
        canvasEl.id = 'cb-desenho-canvas';
        document.body.appendChild(canvasEl);
        ctx = canvasEl.getContext('2d');
        redimensionarCanvas();
        window.addEventListener('resize', redimensionarCanvas);
        carregarDesenho();
    }
    function redimensionarCanvas() {
        if (!canvasEl) return;
        const largura = Math.max(document.documentElement.scrollWidth, window.innerWidth);
        const altura = Math.max(document.documentElement.scrollHeight, window.innerHeight);
        if (canvasEl.width === largura && canvasEl.height === altura) return;
        const anterior = canvasEl.width ? canvasEl.toDataURL() : null;
        canvasEl.width = largura;
        canvasEl.height = altura;
        if (anterior) {
            const img = new Image();
            img.onload = () => ctx.drawImage(img, 0, 0);
            img.src = anterior;
        }
    }
    function salvarDesenhoDebounced() {
        clearTimeout(salvarDesenhoDebounced._t);
        salvarDesenhoDebounced._t = setTimeout(() => {
            try {
                chrome.storage.local.set({ [pageKey]: canvasEl.toDataURL('image/png') });
            } catch (e) {}
        }, 500);
    }
    function carregarDesenho() {
        try {
            chrome.storage.local.get([pageKey], (res) => {
                const dataUrl = res && res[pageKey];
                if (!dataUrl) return;
                const img = new Image();
                img.onload = () => ctx.drawImage(img, 0, 0);
                img.src = dataUrl;
            });
        } catch (e) {}
    }
    function limparDesenho() {
        if (!confirm('Apagar todo o desenho feito nesta página?')) return;
        if (ctx) ctx.clearRect(0, 0, canvasEl.width, canvasEl.height);
        try { chrome.storage.local.remove(pageKey); } catch (e) {}
    }

    function posDoEvento(e) {
        return { x: e.pageX, y: e.pageY };
    }
    function iniciarTraco(e) {
        if (!desenhoAtivo) return;
        desenhando = true;
        const p = posDoEvento(e);
        ultimoX = p.x; ultimoY = p.y;
        // ponto único (clique sem arrastar) também desenha
        desenharSegmento(p.x, p.y, p.x + 0.1, p.y + 0.1);
    }
    function continuarTraco(e) {
        if (!desenhoAtivo || !desenhando) return;
        const p = posDoEvento(e);
        desenharSegmento(ultimoX, ultimoY, p.x, p.y);
        ultimoX = p.x; ultimoY = p.y;
    }
    function pararTraco() {
        if (!desenhando) return;
        desenhando = false;
        salvarDesenhoDebounced();
    }
    function desenharSegmento(x1, y1, x2, y2) {
        ctx.save();
        ctx.globalAlpha = tipoAtual.opacidade;
        ctx.globalCompositeOperation = tipoAtual.blend === 'multiply' ? 'multiply' : 'source-over';
        ctx.strokeStyle = corAtual;
        ctx.lineWidth = tipoAtual.largura;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
        ctx.restore();
    }

    function ativarCaneta() {
        garantirCanvas();
        if (desenhoAtivo) { desativarCaneta(); return; }
        pararTudoQueConflita('caneta');
        desenhoAtivo = true;
        redimensionarCanvas();
        canvasEl.classList.add('cb-desenho-ativo');
        document.getElementById('cb-ft-btn-caneta').classList.add('cb-ft-btn-ativo');
    }
    function desativarCaneta() {
        desenhoAtivo = false;
        if (canvasEl) canvasEl.classList.remove('cb-desenho-ativo');
        const btn = document.getElementById('cb-ft-btn-caneta');
        if (btn) btn.classList.remove('cb-ft-btn-ativo');
        fecharPopover('cb-ft-pop-caneta');
    }

    // -------------------- OUVIR EM VOZ ALTA --------------------
    let utteranceAtual = null;

    function textoParaLer() {
        const sel = window.getSelection();
        if (sel && !sel.isCollapsed && sel.toString().trim()) return sel.toString().trim();
        const overlay = document.getElementById('cb-reading-mode-overlay');
        if (overlay && overlay.style.display !== 'none') {
            const conteudo = overlay.querySelector('#cb-rm-content');
            if (conteudo) return conteudo.innerText;
        }
        const candidatos = document.querySelectorAll('#conteudo, #content, main, article, .container');
        let melhor = null, melhorScore = -1;
        candidatos.forEach((el) => {
            const t = el.innerText || '';
            const score = (t.match(/Art\.\s*\d/g) || []).length;
            if (score > melhorScore) { melhorScore = score; melhor = el; }
        });
        return (melhor || document.body).innerText;
    }

    function falar() {
        pararTudoQueConflita('ouvir');
        const texto = textoParaLer();
        if (!texto || !texto.trim()) return;
        window.speechSynthesis.cancel();
        utteranceAtual = new SpeechSynthesisUtterance(texto);
        utteranceAtual.lang = 'pt-BR';
        const velocidade = document.getElementById('cb-ft-velocidade');
        utteranceAtual.rate = velocidade ? parseFloat(velocidade.value) : 1;
        utteranceAtual.onend = () => atualizarUiOuvir('parado');
        utteranceAtual.onerror = () => atualizarUiOuvir('parado');
        window.speechSynthesis.speak(utteranceAtual);
        atualizarUiOuvir('lendo');
    }
    function pausarOuRetomar() {
        if (window.speechSynthesis.speaking && !window.speechSynthesis.paused) {
            window.speechSynthesis.pause();
            atualizarUiOuvir('pausado');
        } else if (window.speechSynthesis.paused) {
            window.speechSynthesis.resume();
            atualizarUiOuvir('lendo');
        }
    }
    function pararLeitura() {
        window.speechSynthesis.cancel();
        atualizarUiOuvir('parado');
    }
    function atualizarUiOuvir(estado) {
        const btnPlay = document.getElementById('cb-ft-play-pause');
        const btnRail = document.getElementById('cb-ft-btn-ouvir');
        if (!btnPlay) return;
        if (estado === 'lendo') {
            btnPlay.innerHTML = ICON_PAUSE;
            btnRail.classList.add('cb-ft-btn-ativo');
        } else if (estado === 'pausado') {
            btnPlay.innerHTML = ICON_PLAY;
            btnRail.classList.add('cb-ft-btn-ativo');
        } else {
            btnPlay.innerHTML = ICON_PLAY;
            btnRail.classList.remove('cb-ft-btn-ativo');
        }
    }

    // -------------------- BAIXAR EM PDF --------------------
    function baixarPdf() {
        // Fecha ferramentas que atrapalham a impressão e usa o diálogo nativo
        // de impressão do navegador — lá dá pra escolher "Salvar como PDF"
        // como destino, sem precisar de nenhuma biblioteca extra.
        desativarCaneta();
        fecharTodosPopovers();
        setTimeout(() => window.print(), 80);
    }

    // -------------------- Popovers / rail --------------------
    function fecharPopover(id) {
        const el = document.getElementById(id);
        if (el) el.classList.remove('cb-ft-pop-open');
    }
    function fecharTodosPopovers() {
        ['cb-ft-pop-lupa', 'cb-ft-pop-caneta', 'cb-ft-pop-ouvir'].forEach(fecharPopover);
    }
    function alternarPopover(id) {
        const el = document.getElementById(id);
        const abrir = !el.classList.contains('cb-ft-pop-open');
        fecharTodosPopovers();
        if (abrir) el.classList.add('cb-ft-pop-open');
    }

    // Desativa ferramentas que competem por eventos de mouse entre si.
    function pararTudoQueConflita(quem) {
        if (quem !== 'caneta') desativarCaneta();
    }

    function montarRail() {
        rail = document.createElement('div');
        rail.id = 'cb-ft-rail';
        rail.innerHTML = `
            <button id="cb-ft-btn-lupa" class="cb-ft-btn" title="Buscar palavra-chave">${ICON_LUPA}</button>
            <div id="cb-ft-pop-lupa" class="cb-ft-pop">
                <div class="cb-ft-pop-label">Buscar palavra-chave</div>
                <input id="cb-ft-busca-input" type="text" class="cb-ft-busca-input" placeholder="Digite e aperte Enter...">
                <div class="cb-ft-busca-row">
                    <button id="cb-ft-busca-anterior" class="cb-ft-busca-nav" title="Anterior (Shift+Enter)">‹</button>
                    <span id="cb-ft-busca-contador" class="cb-ft-busca-contador"></span>
                    <button id="cb-ft-busca-proximo" class="cb-ft-busca-nav" title="Próximo (Enter)">›</button>
                </div>
            </div>

            <button id="cb-ft-btn-caneta" class="cb-ft-btn" title="Caneta">${ICON_CANETA}</button>
            <div id="cb-ft-pop-caneta" class="cb-ft-pop">
                <div class="cb-ft-pop-label">Tipo de caneta</div>
                <div class="cb-ft-tipos-row">
                    ${CANETA_TIPOS.map(t => `<button class="cb-ft-tipo-btn" data-tipo="${t.id}" title="${t.nome}"><span class="cb-ft-tipo-dot" style="width:${Math.min(t.largura, 14)}px;height:${Math.min(t.largura, 14)}px;"></span></button>`).join('')}
                </div>
                <div class="cb-ft-pop-label">Cor</div>
                <div class="cb-ft-cores-row">
                    ${CANETA_CORES.map(c => `<div class="cb-ft-cor-sw" data-cor="${c}" style="background:${c}"></div>`).join('')}
                </div>
                <button id="cb-ft-limpar-desenho" class="cb-ft-limpar-btn">${ICON_TRASH}<span>Limpar desenho</span></button>
            </div>

            <button id="cb-ft-btn-ouvir" class="cb-ft-btn" title="Ouvir em voz alta">${ICON_OUVIR}</button>
            <div id="cb-ft-pop-ouvir" class="cb-ft-pop">
                <div class="cb-ft-pop-label">Ler em voz alta</div>
                <div class="cb-ft-ouvir-row">
                    <button id="cb-ft-play-pause" class="cb-ft-play-btn" title="Tocar/Pausar">${ICON_PLAY}</button>
                    <button id="cb-ft-stop" class="cb-ft-stop-btn" title="Parar">${ICON_STOP}</button>
                </div>
                <div class="cb-ft-pop-label">Velocidade</div>
                <input id="cb-ft-velocidade" type="range" min="0.5" max="2" step="0.1" value="1">
                <div class="cb-ft-hint">Seleciona um trecho de texto antes pra ouvir só ele, ou deixa sem seleção pra ouvir a lei inteira.</div>
            </div>

            <button id="cb-ft-btn-pdf" class="cb-ft-btn" title="Baixar em PDF">${ICON_PDF}</button>
        `;
        document.body.appendChild(rail);

        document.getElementById('cb-ft-btn-lupa').addEventListener('click', () => {
            alternarPopover('cb-ft-pop-lupa');
            if (document.getElementById('cb-ft-pop-lupa').classList.contains('cb-ft-pop-open')) {
                setTimeout(focarBusca, 30);
            }
        });
        const inputBusca = document.getElementById('cb-ft-busca-input');
        inputBusca.addEventListener('input', atualizarContadorBusca);
        inputBusca.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') { e.preventDefault(); buscar(e.shiftKey); }
        });
        document.getElementById('cb-ft-busca-anterior').addEventListener('click', () => buscar(true));
        document.getElementById('cb-ft-busca-proximo').addEventListener('click', () => buscar(false));

        document.getElementById('cb-ft-btn-caneta').addEventListener('click', () => {
            if (!desenhoAtivo) { ativarCaneta(); alternarPopover('cb-ft-pop-caneta'); }
            else { desativarCaneta(); }
        });
        rail.querySelectorAll('.cb-ft-tipo-btn').forEach((btn) => {
            btn.addEventListener('click', () => {
                tipoAtual = CANETA_TIPOS.find(t => t.id === btn.dataset.tipo) || tipoAtual;
                rail.querySelectorAll('.cb-ft-tipo-btn').forEach(b => b.classList.toggle('cb-ft-tipo-ativo', b === btn));
            });
        });
        rail.querySelectorAll('.cb-ft-cor-sw').forEach((sw) => {
            sw.addEventListener('click', () => {
                corAtual = sw.dataset.cor;
                rail.querySelectorAll('.cb-ft-cor-sw').forEach(s => s.classList.toggle('cb-ft-cor-ativa', s === sw));
            });
        });
        document.getElementById('cb-ft-limpar-desenho').addEventListener('click', limparDesenho);
        rail.querySelector('.cb-ft-tipo-btn[data-tipo="media"]').classList.add('cb-ft-tipo-ativo');
        rail.querySelector(`.cb-ft-cor-sw[data-cor="${CANETA_CORES[0]}"]`).classList.add('cb-ft-cor-ativa');

        document.getElementById('cb-ft-btn-ouvir').addEventListener('click', () => alternarPopover('cb-ft-pop-ouvir'));
        document.getElementById('cb-ft-play-pause').addEventListener('click', () => {
            if (!window.speechSynthesis.speaking) falar();
            else pausarOuRetomar();
        });
        document.getElementById('cb-ft-stop').addEventListener('click', pararLeitura);

        document.getElementById('cb-ft-btn-pdf').addEventListener('click', baixarPdf);

        document.addEventListener('mousedown', (e) => {
            if (rail.contains(e.target)) return;
            fecharTodosPopovers();
        });
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') { fecharTodosPopovers(); }
        });

        document.addEventListener('mousedown', (e) => {
            if (!desenhoAtivo) return;
            if (rail.contains(e.target)) return;
            iniciarTraco(e);
        });
        document.addEventListener('mousemove', continuarTraco);
        document.addEventListener('mouseup', pararTraco);
    }

    function iniciar() {
        // Barra flutuante (lupa/caneta/ouvir) removida a pedido: estava
        // aparecendo com erro no canto inferior esquerdo e a caneta
        // (desenho livre) não funcionava direito. Se quiser reativar no
        // futuro, troque a linha abaixo de volta para "montarRail();".
        return;
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', iniciar);
    } else {
        iniciar();
    }
})();
