// ============================================================================
// artigos-importantes.js — Marca com 🔥 os artigos mais cobrados em concurso
// direto no texto da lei, na página normal do Planalto (fora do Modo de
// Leitura). A lógica de detecção/inserção fica em cb-artigos-lista.js
// (compartilhada com o reading-mode.js).
//
// v3: escaneia UMA VEZ no carregamento e pronto — sem MutationObserver
// contínuo. Leis do Planalto não mudam de conteúdo depois de carregadas, e
// ficar observando o DOM o tempo todo era arriscado: qualquer mutação (até
// a nossa própria, ou uma inserção do marcador de texto) podia disparar
// reprocessamento bem na hora que a pessoa estava selecionando um trecho,
// derrubando a seleção no meio do gesto. Um escaneamento único e definitivo
// é mais previsível e nunca compete com o marcador de texto.
// ============================================================================

(function () {
    if (window.__cbArtigosImportantesLoaded) return;
    window.__cbArtigosImportantesLoaded = true;

    const DEBUG = true;
    function log(...args) { if (DEBUG) console.log('[Artigos Importantes]', ...args); }

    if (!window.CBArtigos) {
        console.warn('[Artigos Importantes] cb-artigos-lista.js não carregou — abortando.');
        return;
    }

    // Trava a restauração automática de scroll do navegador (ex: ao recarregar
    // a aba) e força o topo quando a página não tem uma âncora própria na URL
    // (ex: .../l13105.htm#art54) — evita abrir "cortada" no meio de um artigo
    // por causa dos elementos que a extensão insere no texto.
    try { if ('scrollRestoration' in history) history.scrollRestoration = 'manual'; } catch (e) {}

    function garantirTopoSeNecessario(scrollAntes) {
        if (location.hash) return; // tem âncora própria — respeita
        if (scrollAntes > 4) return; // usuário/página já tinha rolado por outro motivo — não mexe
        requestAnimationFrame(() => {
            if (!location.hash && window.scrollY > 4) window.scrollTo(0, 0);
        });
    }

    // Largura de leitura confortável na página normal (fora do Modo de
    // Leitura): liga por padrão, mas guarda a preferência caso a pessoa
    // prefira desligar (ex: usando o texto compilado com colunas próprias).
    function aplicarLarguraLegivel() {
        chrome.storage.sync.get(['cbLarguraLegivel'], (r) => {
            const ligado = r.cbLarguraLegivel !== false; // padrão: ligado
            if (!ligado) return;
            try {
                const link = document.createElement('link');
                link.rel = 'stylesheet';
                link.href = 'https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,600;1,400&display=swap';
                document.head.appendChild(link);
            } catch (e) {}
            document.body.classList.add('cb-largura-legivel');
        });
    }

    function processar() {
        const scrollAntes = window.scrollY;
        const { encontrados, marcados, ehCPC } = window.CBArtigos.aplicarBadges(document.body, { marcarEscaneado: true });
        log(`página é CPC? ${ehCPC} — ${encontrados} "Art." encontrados, ${marcados} marcados com 🔥`);
        garantirTopoSeNecessario(scrollAntes);
        aplicarLarguraLegivel();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', processar);
    } else {
        processar();
    }
})();
