// ============================================================================
// dock.js — Um só painel de botões para as leis do Planalto, no canto direito.
//
// Antes cada recurso criava o próprio botão flutuante, uns à direita (grifos, modo de leitura, artigos dos erros) e outros à
// esquerda (lupa/caneta/ouvir/PDF), empilhados uns sobre os outros. Aqui eles são REUNIDOS num dock:
//   • os botões que já existem são movidos para dentro dele (mesmo elemento, então cada recurso continua funcionando);
//   • o botão "Artigos dos erros" (que mora num Shadow DOM) ganha um espelho no dock: clicar nele clica no original, e o
//     número vermelho acompanha; o botão original fica escondido pela variável CSS --cb-fab-display.
// Ordem, de cima para baixo: ferramentas (lupa, caneta, ouvir, PDF) · captura rápida · grifos · modo de leitura · edição de estudo · artigos dos erros.
// O dock pode ser recolhido (chevron no topo); a escolha fica guardada (cbDockMin).
// ============================================================================
(function () {
    'use strict';
    if (window.__cbDock) return;
    window.__cbDock = true;

    const ICON_CHEV = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>';
    const ICON_GRADE = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>';
    const ICON_ERROS = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/><line x1="12" y1="7" x2="12" y2="12"/><circle cx="12" cy="15" r="0.6"/></svg>';

    // seletor → ordem no dock (menor = mais acima)
    const ITENS = [
        ['#cb-ft-rail', 1],
        ['#cb-cap-toggle', 3],
        ['#cb-hl-panel-toggle', 4],
        ['#cb-rm-toggle', 5],
        ['#cb-ed-toggle', 6],
    ];

    let dock = null, lista = null, lanc = null, espelho = null;
    let minimizado = false;

    function montar() {
        if (dock) return;
        dock = document.createElement('div');
        dock.id = 'cb-dock';
        dock.setAttribute('role', 'toolbar');
        dock.setAttribute('aria-label', 'Ferramentas da lei');
        dock.innerHTML = `
            <button type="button" id="cb-dock-recolher" title="Recolher / mostrar as ferramentas" aria-label="Recolher ou mostrar as ferramentas">${ICON_CHEV}</button>
            <div class="cb-dock-itens"></div>
            <button type="button" id="cb-dock-lancador" title="Mostrar as ferramentas" aria-label="Mostrar as ferramentas">${ICON_GRADE}</button>`;
        document.body.appendChild(dock);
        lista = dock.querySelector('.cb-dock-itens');
        lanc = dock.querySelector('#cb-dock-lancador');
        const alternar = () => { minimizado = !minimizado; aplicarMin(); try { chrome.storage.local.set({ cbDockMin: minimizado }); } catch (e) { /* ignora */ } };
        dock.querySelector('#cb-dock-recolher').addEventListener('click', alternar);
        lanc.addEventListener('click', alternar);
        try {
            chrome.storage.local.get(['cbDockMin'], (r) => { minimizado = !!(r && r.cbDockMin); aplicarMin(); });
        } catch (e) { /* sem storage */ }
        aplicarMin();
    }
    function aplicarMin() { if (dock) dock.classList.toggle('cb-dock--min', minimizado); }

    function adotar() {
        montar();
        ITENS.forEach(([sel, ordem]) => {
            const el = document.querySelector(sel);
            if (el && el.parentElement !== lista) { el.style.order = String(ordem); lista.appendChild(el); }
        });
        espelharArtigosErros();
        separar();
    }

    // traço fino entre o grupo das ferramentas e o resto
    function separar() {
        if (!lista || lista.querySelector('.cb-dock-sep')) return;
        if (!lista.querySelector('#cb-ft-rail')) return;
        const sep = document.createElement('div');
        sep.className = 'cb-dock-sep';
        sep.style.order = '2';
        lista.appendChild(sep);
    }

    // ---- espelho do botão "Artigos dos seus erros" (Shadow DOM de artigos-erros.js) ----
    function espelharArtigosErros() {
        const host = document.getElementById('cb-ae-host');
        const raiz = host && host.shadowRoot;
        if (!raiz) { if (espelho) espelho.hidden = true; return; }
        host.style.setProperty('--cb-fab-display', 'none');
        host.style.setProperty('--cb-painel-right', '84px');
        if (!espelho) {
            espelho = document.createElement('button');
            espelho.type = 'button';
            espelho.id = 'cb-dock-erros';
            espelho.title = 'Artigos dos seus erros no QConcursos';
            espelho.setAttribute('aria-label', 'Artigos dos seus erros no QConcursos');
            espelho.style.order = '7';
            espelho.innerHTML = `${ICON_ERROS}<span class="cb-dock-n" hidden></span>`;
            espelho.addEventListener('click', () => {
                const fab = host.shadowRoot && host.shadowRoot.querySelector('.fab');
                if (fab) fab.click();
            });
            lista.appendChild(espelho);
            // o painel é redesenhado a cada mudança no storage: acompanha o número
            new MutationObserver(atualizarNumero).observe(raiz, { childList: true, subtree: true, characterData: true });
        }
        espelho.hidden = false;
        atualizarNumero();
    }
    function atualizarNumero() {
        const host = document.getElementById('cb-ae-host');
        const n = host && host.shadowRoot && host.shadowRoot.querySelector('.fab .n');
        const bolha = espelho && espelho.querySelector('.cb-dock-n');
        if (!bolha) return;
        const txt = n ? n.textContent.trim() : '';
        bolha.textContent = txt;
        bolha.hidden = !txt;
    }

    function iniciar() {
        adotar();
        // os recursos criam os botões em momentos diferentes (alguns esperam a página carregar): observa e adota quando surgirem
        new MutationObserver(() => adotar()).observe(document.documentElement, { childList: true });
        new MutationObserver(() => adotar()).observe(document.body, { childList: true });   // adotar() não mexe em quem já está no dock, então não entra em ciclo
        [400, 1400, 3200, 6000].forEach((ms) => setTimeout(adotar, ms));
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar); else iniciar();
})();
