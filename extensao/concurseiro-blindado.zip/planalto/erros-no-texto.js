// ============================================================================
// erros-no-texto.js — Marca, na lei do Planalto, os artigos que aparecem nas questões que VOCÊ errou no QConcursos.
//
// Substitui o antigo "prioridades-estudo.js", que pintava capítulos inteiros de laranja a partir de um mapa feito à mão
// (assunto do QConcursos → intervalo de artigos) e por isso só funcionava para poucos assuntos do CPC. Aqui não há mapa:
// o sinal é o artigo em si, o mesmo que dados-config/artigos-erros-store.js já guarda quando o QConcursos lê o Gabarito
// Comentado de uma questão errada. Funciona em qualquer lei que o leitor de referências (ref-artigos.js) reconheça.
//
// Como marca: só coloca o atributo data-cb-erros="N" no span "Art. N" que cb-artigos-lista.js já cria; o desenho
// (uma cápsula "errou N") é CSS puro, em erros-no-texto.css. Nenhum nó novo entra no texto da lei, então nada atrapalha
// o marcador de texto nem o Modo de Leitura. N = quantas questões erradas, distintas, citam o artigo.
// ============================================================================
(function (raiz) {
    'use strict';

    // ------------------------------------------------------------------ puro
    // estado = { pendentes: [...], revisao: [...] } (o que CBArtigosStore.ler devolve). Devolve { '279': 2, '5A': 1 } para a lei.
    function contarPorArtigo(estado, lei) {
        const porArtigo = new Map();
        [].concat((estado && estado.revisao) || [], (estado && estado.pendentes) || []).forEach((it) => {
            if (!it || it.lei !== lei || it.artigo == null) return;
            const chave = String(it.artigo) + String(it.sufixo || '').toUpperCase();
            if (!porArtigo.has(chave)) porArtigo.set(chave, new Set());
            (it.origens || []).forEach((o) => { if (o && o.questaoId) porArtigo.get(chave).add(o.questaoId); });
        });
        const saida = {};
        porArtigo.forEach((qs, chave) => { if (qs.size) saida[chave] = qs.size; });
        return saida;
    }

    const api = { contarPorArtigo };
    if (typeof module !== 'undefined' && module.exports) { module.exports = api; return; }
    raiz.CBErrosNoTexto = api;     // sugestoes-topo.js usa a mesma contagem

    // ------------------------------------------------------------------ página
    if (raiz.__cbErrosNoTexto) return;
    raiz.__cbErrosNoTexto = true;
    function aplicar() {
        const lei = raiz.CBArtigos && raiz.CBArtigos.detectarLei && raiz.CBArtigos.detectarLei();
        const Armazem = raiz.CBArtigosStore;
        if (!lei || !Armazem) return;
        Armazem.ler().then((estado) => {
            const contagem = contarPorArtigo(estado, lei);
            raiz.document.querySelectorAll('.cb-art-ref[data-cb-art-num]').forEach((ref) => {
                const sufixo = raiz.CBCorpus927 ? raiz.CBCorpus927.sufixoDoRef(ref) : '';
                const n = contagem[ref.getAttribute('data-cb-art-num') + sufixo] || 0;
                if (n) {
                    ref.setAttribute('data-cb-erros', String(n));
                    ref.title = `Você errou ${n} ${n === 1 ? 'questão' : 'questões'} do QConcursos que citam este artigo`;
                } else if (ref.hasAttribute('data-cb-erros')) {
                    ref.removeAttribute('data-cb-erros');
                    ref.removeAttribute('title');
                }
            });
        }).catch(() => {});
    }

    // as refs "Art. N" são criadas por cb-artigos-lista.js depois do carregamento: tenta de novo uma vez
    function iniciar() {
        aplicar();
        setTimeout(aplicar, 1800);
        try {
            raiz.chrome.storage.onChanged.addListener((mud, area) => {
                const Store = raiz.CBArtigosStore;
                if (area === 'local' && Store && (mud[Store.K_PEND] || mud[Store.K_REV])) aplicar();
            });
        } catch (e) { /* sem storage: marca só no carregamento */ }
    }
    if (raiz.document.readyState === 'loading') raiz.document.addEventListener('DOMContentLoaded', iniciar); else iniciar();
})(typeof window !== 'undefined' ? window : globalThis);
