// ============================================================================
// cb-artigos-lista.js — Lista compartilhada dos artigos mais cobrados do CPC
// + lógica única de inserção do selo 🔥. Usado por artigos-importantes.js
// (página normal) e por reading-mode.js (dentro do Modo de Leitura).
//
// v3:
//  - Os selos 🔥 SÓ aparecem na página do CPC (Lei 13.105/2015). Em
//    qualquer outra lei do Planalto, a lista nem é consultada.
//  - O selo agora fica ANTES de "Art. Nº" (não depois), e o próprio
//    "Art. Nº" fica destacado em vermelho ao lado do fogo.
//  - Função separada (não depende da lista de importantes, roda em
//    qualquer lei) que esconde o iconezinho verde de âncora/permalink que
//    o próprio Planalto injeta antes de alguns artigos — puramente visual,
//    a extensão só oculta com display:none.
// ============================================================================

(function () {
    if (window.CBArtigos) return;

    const ARTIGOS_IMPORTANTES = new Set([
        1,2,3,5,6,7,8,9,10,12,15,17,18,23,25,26,28,33,36,43,45,46,47,51,52,53,54,55,56,
        61,62,63,64,65,72,73,75,77,81,82,85,87,91,95,96,98,99,100,101,104,109,112,113,
        114,115,116,117,121,122,125,128,130,134,138,139,140,183,185,188,189,190,191,196,
        203,212,216,218,219,220,223,224,225,226,229,231,237,238,239,240,244,245,246,247,
        249,252,253,256,293,294,300,305,311,312,313,316,317,321,322,323,324,325,326,327,
        329,330,331,332,334,335,337,340,342,343,344,354,355,356,357,372,373,374,381,388,
        390,392,395,400,406,417,418,422,430,435,443,447,455,485,486,487,488,489,494,495,
        496,502,503,504,506,507,515,517,523,525,531,532,534,535,536,552,553,554,560,562,
        616,617,619,633,644,659,660,663,664,668,674,682,685,686,695,698,699,700,701,702,
        724,742,743,747,748,774,775,778,789,790,792,800,802,803,808,810,814,825,826,827,
        829,830,832,833,834,835,839,841,842,844,845,846,847,848,852,853,854,855,858,861,
        862,864,865,866,870,871,873,876,877,878,879,880,881,884,889,891,892,895,903,910,
        914,915,916,917,918,919,921,924,925,927,928,932,936,941,942,946,947,948,949,951,
        955,960,961,962,963,966,967,975,976,977,985,987,988,994,995,997,998,999,1000,
        1001,1005,1009,1012,1015,1016,1019,1021,1022,1024,1026,1027,1029,1030,1031,1034,
        1035,1042,1043,1048,1062,1070
    ]);

    const BADGE_CLASS = 'cb-imp-badge';
    const NUMERO_CLASS = 'cb-imp-numero';
    const SCANNED_ATTR = 'data-cb-imp-scanned';
    const ICONE_OCULTO_ATTR = 'data-cb-icone-oculto';
    const RE_ARTIGO = /^\s*Art(?:igo)?\.?\s*(\d{1,4}(?:\.\d{3})?)\s*[ºo°]?/i;
    const TAGS_IGNORAR = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEXTAREA', 'INPUT']);
    const RE_CLASSE_OCULTA = /sr-only|visually-hidden|screen-reader|assistive|d-none|hidden/i;

    // -------------------- em qual lei estamos --------------------
    // O CPC (Lei 13.105/2015) aparece no Planalto como .../L13105.htm ou
    // .../l13105compilada.htm — cobrindo maiúsculas/minúsculas e variações.
    function paginaEhCPC() {
        return /l13105/i.test(location.pathname);
    }

    function normalizarNumero(str) {
        return parseInt(str.replace('.', ''), 10);
    }

    function elementoVisivel(el) {
        if (!el) return true;
        if (el.hidden) return false;
        if (el.className && typeof el.className === 'string' && RE_CLASSE_OCULTA.test(el.className)) return false;
        let style;
        try { style = window.getComputedStyle(el); } catch (e) { return true; }
        if (!style) return true;
        if (style.display === 'none' || style.visibility === 'hidden' || parseFloat(style.opacity) === 0) return false;
        if (style.position === 'absolute' && parseInt(style.width) <= 1 && parseInt(style.height) <= 1) return false;
        return true;
    }

    function encontrarBlocoAncestral(node) {
        let el = node.nodeType === Node.TEXT_NODE ? node.parentElement : node;
        while (el && el !== document.body) {
            const tag = el.tagName;
            if (tag === 'P' || tag === 'LI' || tag === 'DIV' || tag === 'TD' || tag === 'BLOCKQUOTE' || tag === 'SPAN') {
                return el;
            }
            el = el.parentElement;
        }
        return node.nodeType === Node.TEXT_NODE ? node.parentElement : node;
    }

    function criarBadge() {
        const span = document.createElement('span');
        span.className = BADGE_CLASS;
        span.textContent = '🔥';
        span.title = 'Um dos artigos mais cobrados em concurso público';
        span.setAttribute('aria-hidden', 'true');
        return span;
    }

    function coletarNosDeTexto(root) {
        const nos = [];
        const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
            acceptNode(node) {
                if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
                const parent = node.parentElement;
                if (!parent) return NodeFilter.FILTER_REJECT;
                if (TAGS_IGNORAR.has(parent.tagName)) return NodeFilter.FILTER_REJECT;
                if (parent.closest && parent.closest(
                    '#cb-hl-panel, #cb-hl-toolbar, .cb-hl-barra, #cb-hl-panel-toggle, ' +
                    '#cb-reading-mode-overlay, #cb-rm-toggle, .' + BADGE_CLASS + ', .' + NUMERO_CLASS
                )) return NodeFilter.FILTER_REJECT;
                if (!elementoVisivel(parent)) return NodeFilter.FILTER_REJECT;
                return NodeFilter.FILTER_ACCEPT;
            }
        });
        let n;
        while ((n = walker.nextNode())) nos.push(n);
        return nos;
    }

    // Esconde o iconezinho (âncora/permalink) que o Planalto às vezes injeta
    // logo antes do texto "Art. X" — não depende da lista de importantes,
    // roda em qualquer lei. Heurística: elemento irmão imediatamente antes
    // do nó de texto, dentro do mesmo bloco, sem texto visível próprio
    // (ou seja, é só um ícone/SVG).
    function esconderElementoIcone(el) {
        if (!el || el.nodeType !== Node.ELEMENT_NODE) return false;
        if (el.hasAttribute(ICONE_OCULTO_ATTR)) return true;
        const textoProprio = (el.textContent || '').trim();
        if (textoProprio.length > 2) return false; // tem texto de verdade, não é só ícone
        const tag = el.tagName;
        if (tag === 'A' || tag === 'BUTTON' || tag === 'SVG' || tag === 'I' || tag === 'SPAN' || tag === 'IMG') {
            el.setAttribute(ICONE_OCULTO_ATTR, '1');
            el.style.setProperty('display', 'none', 'important');
            return true;
        }
        return false;
    }

    // Alguns HTMLs do Planalto não colocam o iconezinho como ELEMENTO (o
    // que esconderElementoIcone cobre), e sim como um CARACTERE DE TEXTO
    // solto logo antes de "Art." (ex: um glyph decorativo tipo "☐"/"⚓"
    // vindo de uma fonte de ícone própria do site). Isso é invisível na
    // página normal do Planalto (a fonte de ícone carrega e desenha o
    // símbolo certo), mas vira um quadradinho vazio (tofu) assim que a
    // extensão força outra fonte por cima — principalmente dentro do
    // Modo de Leitura. Detecta um nó de texto curto (1-3 caracteres) sem
    // nenhuma letra/dígito de verdade — só pode ser um glyph decorativo —
    // e o esconde envolvendo num <span> oculto.
    const RE_TEM_LETRA_OU_DIGITO = /[a-zA-Z0-9À-ÿ]/;
    function esconderTextoIcone(node) {
        if (!node || node.nodeType !== Node.TEXT_NODE) return false;
        const texto = node.nodeValue.trim();
        if (!texto || texto.length > 3) return false;
        if (RE_TEM_LETRA_OU_DIGITO.test(texto)) return false; // texto de verdade, não é ícone
        const pai = node.parentElement;
        if (!pai) return false;
        const span = document.createElement('span');
        span.setAttribute(ICONE_OCULTO_ATTR, '1');
        span.style.setProperty('display', 'none', 'important');
        pai.insertBefore(span, node);
        span.appendChild(node);
        return true;
    }

    function esconderIconeAnterior(textNode) {
        // 1) tenta um irmão-elemento imediatamente antes do nó de texto
        let irmao = textNode.previousSibling;
        while (irmao && irmao.nodeType === Node.TEXT_NODE && !irmao.nodeValue.trim()) {
            irmao = irmao.previousSibling;
        }
        if (esconderElementoIcone(irmao)) return;
        if (esconderTextoIcone(irmao)) return;

        // 2) fallback: o ícone pode estar como PRIMEIRO filho do bloco pai
        // (ex: <p><a name="art1"></a><img/>Art. 1º ...</p>), não como irmão
        // direto do nó de texto — percorre os primeiros filhos do bloco.
        const bloco = textNode.parentElement;
        if (!bloco) return;
        let candidato = bloco.firstChild;
        let tentativas = 0;
        while (candidato && candidato !== textNode && tentativas < 4) {
            const proximo = candidato.nextSibling;
            if (candidato.nodeType === Node.ELEMENT_NODE) {
                esconderElementoIcone(candidato);
            } else if (candidato.nodeType === Node.TEXT_NODE) {
                esconderTextoIcone(candidato);
            }
            candidato = proximo;
            tentativas++;
        }
    }

    // Verifica se o nó de texto realmente é o INÍCIO de um artigo, e não
    // apenas uma referência cruzada a outro artigo no meio do parágrafo
    // (ex: "...previstas no art. 311, incisos II e III"). No site do
    // Planalto essas referências cruzadas são sempre um link <a href="#art...">
    // — um cabeçalho de artigo de verdade nunca é, ele mesmo, um link.
    function ehComecoDeArtigo(textNode) {
        const pai = textNode.parentElement;
        if (pai && pai.closest && pai.closest('a')) return false;
        return true;
    }

    // Detecta a lei atual pela URL (mesmo padrão usado em
    // prioridades-estudo.js) — usado pra marcar cada "Art. N" com a lei a
    // que pertence (data-cb-art-lei), pro painel de jurisprudência saber
    // em qual "gaveta" do JURIS_DB procurar.
    function detectarLei() {
        if (/constituicao/i.test(location.pathname)) return 'cf88';
        const m = location.pathname.match(/l(\d{3,5})/i);
        return m ? ('l' + m[1]).toLowerCase() : null;
    }

    const ART_REF_CLASS = 'cb-art-ref';

    // Aplica os selos + esconde ícones + marca CADA "Art. N" (de qualquer
    // lei, não só os importantes do CPC) com um <span class="cb-art-ref">
    // contendo data-cb-art-num/data-cb-art-lei. Esse span é o alvo de
    // clique do painel de jurisprudência (jurisprudencia.js) — ele decide
    // sozinho se reage ao clique (só reage dentro do Modo de Leitura).
    function aplicarBadges(root, { marcarEscaneado = false } = {}) {
        const ehCPC = paginaEhCPC();
        const lei = detectarLei();
        const nos = coletarNosDeTexto(root);
        const blocosComBadgeNestaPassada = new Set();
        let marcados = 0, encontrados = 0;

        nos.forEach((textNode) => {
            const bloco = encontrarBlocoAncestral(textNode);
            if (marcarEscaneado && bloco && bloco.hasAttribute(SCANNED_ATTR)) return;

            const texto = textNode.nodeValue;
            const m = texto.match(RE_ARTIGO);
            if (!m) return;
            if (!ehComecoDeArtigo(textNode)) return; // referência cruzada, não é o artigo em si

            encontrados++;
            esconderIconeAnterior(textNode);
            if (marcarEscaneado && bloco) bloco.setAttribute(SCANNED_ATTR, '1');

            const numero = normalizarNumero(m[1]);
            const ehImportante = ehCPC && ARTIGOS_IMPORTANTES.has(numero) && !blocosComBadgeNestaPassada.has(bloco);

            try {
                // separa "Art. Nº" (m[0]) num <span>. Sempre acontece (pra
                // todo artigo, de toda lei) — o selo 🔥/vermelho por cima
                // só entra se for um artigo importante do CPC.
                const range = document.createRange();
                range.setStart(textNode, 0);
                range.setEnd(textNode, m[0].length);
                const span = document.createElement('span');
                span.className = ART_REF_CLASS;
                span.setAttribute('data-cb-art-num', String(numero));
                if (lei) span.setAttribute('data-cb-art-lei', lei);
                range.surroundContents(span);

                if (ehImportante) {
                    span.classList.add(NUMERO_CLASS);
                    span.parentNode.insertBefore(criarBadge(), span);
                    blocosComBadgeNestaPassada.add(bloco);
                    marcados++;
                }
            } catch (e) {
                console.warn('[Artigos Importantes] Falha ao marcar "Art.":', e);
            }
        });

        return { encontrados, marcados, ehCPC };
    }

    window.CBArtigos = { ARTIGOS_IMPORTANTES, aplicarBadges, BADGE_CLASS, NUMERO_CLASS, ART_REF_CLASS, paginaEhCPC, detectarLei, coletarNosDeTexto, encontrarBlocoAncestral, RE_ARTIGO, normalizarNumero };
})();
