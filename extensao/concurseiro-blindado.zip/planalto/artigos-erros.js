// ============================================================================
// artigos-erros.js — Painel "Artigos dos seus erros", nas leis do Planalto.
// Mostra os artigos que o QConcursos deixou PENDENTES (citados nos comentários
// das questões que a pessoa errou — ver qconcursos/artigos-erros.js). A pessoa
// vê o artigo na lei (a página rola até ele e o destaca), confirma em "Salvar" e
// ele vai para a revisão espaçada, com o texto do artigo guardado. Também dá
// para adicionar um artigo à mão e remover os que já estavam salvos.
//
// Dependências (carregadas antes, ver manifest.json): CBArtigos (marca todo
// "Art. N" com <span class="cb-art-ref" data-cb-art-num data-cb-art-lei>),
// CBRefArtigos, CBRevisaoEspacada e CBArtigosStore.
//
// O painel mora num Shadow DOM (o CSS antigo do Planalto não mexe nele); só as
// marcas dentro do texto da lei (planalto/artigos-erros.css) ficam na página.
// ============================================================================
(function () {
    'use strict';
    if (window.__cbArtigosErrosPlanalto) return;
    window.__cbArtigosErrosPlanalto = true;

    const Ref = window.CBRefArtigos;
    const Srs = window.CBRevisaoEspacada;
    const Store = window.CBArtigosStore;
    const Art = window.CBArtigos;
    if (!Ref || !Srs || !Store || !Art) return;

    const lei = Art.detectarLei(); // 'cf88', 'l13105'... ou null fora de uma lei
    if (!lei) return;

    const CHAVE_FECHADO = 'cbAePainelFechado';
    let estado = { pendentes: [], revisao: [], ativo: true };
    let aberto = false;
    let host = null;
    let raiz = null;
    let primeiraCarga = true;

    // ------------------------------------------------------------------ achar o artigo na página
    function textoLimpo(el) {
        return (el.textContent || '').replace(/\s+/g, ' ').replace(/^[^A-Za-z]+/, '').trim();
    }
    function comecaComArtigo(bloco, artigo, sufixo) {
        const t = textoLimpo(bloco);
        const num = String(artigo).replace(/(\d)(?=(\d{3})$)/, '$1\\.?');
        const re = sufixo
            ? new RegExp('^Art(?:igo)?\\.?\\s*' + num + '\\s*[ºo°]?\\s*-\\s*' + sufixo + '\\b', 'i')
            : new RegExp('^Art(?:igo)?\\.?\\s*' + num + '\\s*[ºo°]?(?!\\s*-\\s*[A-Z]\\b)(?!\\d)', 'i');
        return re.test(t);
    }

    // Nas leis COMPILADAS do Planalto o texto antigo (que uma lei posterior substituiu) continua na
    // página, RISCADO (<strike>), com o mesmo número de artigo e ANTES do texto vigente — o âncora
    // #art12 até pertence a ele. Sem esta checagem o painel marcava, destacava e salvava o texto
    // revogado (ex.: CPC art. 12, trocado pela Lei 13.256/2016).
    const SEL_RISCADO = 'strike, s, del, [style*="line-through"]';
    function riscadoPorEstilo(el) {
        for (let e = el; e && e !== document.documentElement; e = e.parentElement) {
            if (e.tagName === 'STRIKE' || e.tagName === 'S' || e.tagName === 'DEL') return true;
            let d = '';
            try { d = getComputedStyle(e).textDecorationLine || ''; } catch (err) { /* ignora */ }
            if (d.indexOf('line-through') >= 0) return true;
        }
        return false;
    }
    function fracaoRiscada(el) {
        if (riscadoPorEstilo(el)) return 1;
        const total = (el.textContent || '').replace(/\s+/g, '').length;
        if (!total) return 0;
        // soma só os elementos riscados mais externos (um <strike> dentro de outro não conta duas vezes)
        const achados = Array.from(el.querySelectorAll(SEL_RISCADO));
        let soma = 0;
        achados.forEach((x) => {
            if (achados.some((y) => y !== x && y.contains(x))) return;
            soma += (x.textContent || '').replace(/\s+/g, '').length;
        });
        return soma / total;
    }
    function blocoRiscado(el) { return fracaoRiscada(el) > 0.6; }
    function textoSemRiscado(el) {
        const copia = el.cloneNode(true);
        copia.querySelectorAll(SEL_RISCADO).forEach((x) => x.remove());
        return (copia.textContent || '').replace(/\s+/g, ' ').trim();
    }

    // "Art. 1.072. (Revogado pela Lei…)": a lei vigente diz que o artigo não existe mais
    const RE_REVOGADO = /^Art(?:igo)?\.?\s*[\d.]+\s*[ºo°]?(?:\s*-\s*[A-Z])?\s*\.?\s*(?:[-–—]\s*)?\(?\s*Revogad[oa]/i;
    function revogado(bloco) { return !!bloco && RE_REVOGADO.test(textoLimpo(bloco)); }

    function candidatosDoArtigo(artigo, sufixo) {
        const lista = [];
        document.querySelectorAll('.cb-art-ref[data-cb-art-num="' + artigo + '"]').forEach((r) => {
            const bloco = r.closest('p, li, blockquote, td') || r.parentElement;
            if (bloco && lista.indexOf(bloco) < 0 && comecaComArtigo(bloco, artigo, sufixo)) lista.push(bloco);
        });
        return lista;
    }
    function acharBloco(artigo, sufixo) {
        const suf = sufixo ? sufixo.toLowerCase() : '';
        let cands = candidatosDoArtigo(artigo, sufixo);
        if (!cands.length) {
            // reserva: âncoras do próprio Planalto (<a name="art279">; o texto vigente às vezes usa "art12.")
            const ancoras = document.querySelectorAll('a[name="art' + artigo + suf + '"], a[name="art' + artigo + suf + '."], [id="art' + artigo + suf + '"]');
            ancoras.forEach((a) => {
                const b = a.closest('p, li, blockquote, td') || a.parentElement;
                if (b && cands.indexOf(b) < 0) cands.push(b);
            });
        }
        // o vigente: o primeiro que não está riscado (se todos estiverem, o último — o mais novo)
        return cands.find((b) => !blocoRiscado(b)) || cands[cands.length - 1] || null;
    }
    // âncora do texto vigente (ex.: "#art12."), para o link salvo abrir no lugar certo
    function ancoraDoBloco(bloco, artigo, sufixo) {
        const prefixo = 'art' + artigo + (sufixo ? sufixo.toLowerCase() : '');
        const a = bloco && Array.from(bloco.querySelectorAll('a[name]')).find((x) => {
            const nome = x.getAttribute('name').toLowerCase();
            return nome === prefixo || nome === prefixo + '.';
        });
        return a ? '#' + a.getAttribute('name') : Ref.ancoraDoArtigo(artigo, sufixo);
    }

    const RE_NOVO_ARTIGO = /^[^A-Za-z]*Art(?:igo)?\.?\s*\d/i;
    const RE_DIVISAO = /^(T[ÍI]TULO|CAP[ÍI]TULO|SE[ÇC][ÃA]O|SUBSE[ÇC][ÃA]O|LIVRO|PARTE)\b/i;
    const RE_NOTA = /\((?:Reda[çc][ãa]o|Inclu[ií]d[oa]|Vide|Vig[êe]ncia|Regulamento)[^)]*\)/gi;
    // o artigo = o parágrafo "Art. N …" + os parágrafos seguintes (§, incisos) até o próximo artigo ou título.
    // Parágrafos riscados (texto antigo) ficam de fora.
    function capturarTexto(bloco) {
        const partes = [textoSemRiscado(bloco).replace(/^[^A-Za-z]+/, '')];
        let el = bloco.nextElementSibling;
        for (let i = 0; el && i < 20; i++, el = el.nextElementSibling) {
            if (blocoRiscado(el)) continue;
            const t = textoSemRiscado(el);
            if (!t) continue;
            if (RE_NOVO_ARTIGO.test(t) || RE_DIVISAO.test(t)) break;
            partes.push(t);
        }
        return partes.join('\n').replace(RE_NOTA, '').replace(/[ \t]{2,}/g, ' ').replace(/ +\n/g, '\n').trim().slice(0, 2400);
    }

    function focarArtigo(artigo, sufixo) {
        const bloco = acharBloco(artigo, sufixo);
        if (!bloco) return false;
        bloco.scrollIntoView({ behavior: 'smooth', block: 'center' });
        bloco.classList.remove('cb-ae-foco');
        void bloco.offsetWidth; // reinicia a animação se clicar de novo
        bloco.classList.add('cb-ae-foco');
        setTimeout(() => bloco.classList.remove('cb-ae-foco'), 3600);
        return true;
    }

    // marca, dentro do texto da lei, os artigos pendentes e os já salvos
    function marcarNaPagina() {
        document.querySelectorAll('[data-cb-ae]').forEach((el) => el.removeAttribute('data-cb-ae'));
        estado.revisao.filter((r) => r.lei === lei).forEach((r) => {
            const b = acharBloco(r.artigo, r.sufixo);
            if (b) b.setAttribute('data-cb-ae', 'salvo');
        });
        estado.pendentes.filter((p) => p.lei === lei).forEach((p) => {
            const b = acharBloco(p.artigo, p.sufixo);
            if (b) b.setAttribute('data-cb-ae', 'pendente');
        });
    }

    // ------------------------------------------------------------------ ações
    function urlDoArtigo(artigo, sufixo, bloco) {
        return location.origin + location.pathname + ancoraDoBloco(bloco, artigo, sufixo);
    }
    const MSG_REVOGADO = 'Este artigo foi revogado e não vale mais na lei vigente — por isso não vai para a revisão.';
    async function salvar(item) {
        const bloco = acharBloco(item.artigo, item.sufixo);
        if (revogado(bloco)) { avisar(MSG_REVOGADO); return; }
        const texto = bloco ? capturarTexto(bloco) : '';
        await Store.salvarParaRevisao({
            id: item.id, lei, artigo: item.artigo, sufixo: item.sufixo, detalhe: item.detalhe,
            texto, url: urlDoArtigo(item.artigo, item.sufixo, bloco)
        });
        avisar(bloco ? 'Salvo para revisar. A primeira revisão é amanhã.' : 'Salvei a referência, mas não achei o texto do artigo nesta página.');
    }
    async function adicionarManual(valor) {
        const m = /^\s*(\d{1,4}(?:\.\d{3})?)\s*[ºo°]?\s*(?:-\s*([A-Za-z]))?\s*$/.exec(valor || '');
        if (!m) { avisar('Digite só o número do artigo, por exemplo 279 ou 311-A.'); return false; }
        const artigo = String(parseInt(m[1].replace('.', ''), 10));
        const sufixo = m[2] ? m[2].toUpperCase() : '';
        const bloco = acharBloco(artigo, sufixo);
        if (!bloco) { avisar('Não encontrei o art. ' + artigo + (sufixo ? '-' + sufixo : '') + ' nesta lei.'); return false; }
        if (revogado(bloco)) { avisar(MSG_REVOGADO); return false; }
        await Store.salvarParaRevisao({ lei, artigo, sufixo, texto: capturarTexto(bloco), url: urlDoArtigo(artigo, sufixo, bloco), manual: true });
        focarArtigo(artigo, sufixo);
        avisar('Art. ' + artigo + (sufixo ? '-' + sufixo : '') + ' salvo para revisar.');
        return true;
    }

    // ------------------------------------------------------------------ painel
    const ICONE_LIVRO = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z"/></svg>';
    const ICONE_FECHAR = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>';
    const CSS = `
        :host { all: initial; }
        * { box-sizing: border-box; }
        .fab {
            position: fixed; right: 18px; bottom: 140px; z-index: 2147483640;
            width: 46px; height: 46px; padding: 0; border: 0; border-radius: 50%; cursor: pointer;
            display: var(--cb-fab-display, grid); place-items: center; color: #fff;
            background: linear-gradient(160deg, #a78bfa, #6d28d9);
            box-shadow: 0 8px 22px rgba(109, 40, 217, 0.42), inset 0 1px 0 rgba(255, 255, 255, 0.3);
            transition: transform 0.18s ease;
        }
        .fab:hover { transform: scale(1.06); }
        .fab:active { transform: scale(0.94); }
        .fab svg { width: 21px; height: 21px; }
        .fab .n { position: absolute; top: -4px; right: -4px; min-width: 19px; height: 19px; padding: 0 5px; border-radius: 999px;
            display: grid; place-items: center; font: 700 11px/1 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            color: #fff; background: #e5484d; box-shadow: 0 0 0 2px #fff; }
        .painel {
            position: fixed; top: 16px; right: var(--cb-painel-right, 16px); z-index: 2147483641;
            width: 330px; max-width: calc(100vw - 32px); max-height: calc(100vh - 32px);
            display: flex; flex-direction: column; overflow: hidden;
            font: 13px/1.45 -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            color: #1c2333; background: rgba(255, 255, 255, 0.93);
            -webkit-backdrop-filter: blur(24px) saturate(1.4); backdrop-filter: blur(24px) saturate(1.4);
            border-radius: 24px; box-shadow: 0 0 0 1px rgba(20, 25, 45, 0.08), 0 22px 54px rgba(20, 25, 45, 0.28);
            transform-origin: top right; animation: abre 0.3s cubic-bezier(0.2, 0.9, 0.25, 1);
        }
        .painel[hidden] { display: none; }
        @keyframes abre { from { opacity: 0; transform: translateY(-8px) scale(0.97); } to { opacity: 1; transform: none; } }
        @media (prefers-reduced-motion: reduce) { .painel { animation: none; } .fab { transition: none; } }
        .topo { display: flex; align-items: center; gap: 11px; padding: 16px 14px 12px 16px; border-bottom: 1px solid rgba(20, 25, 45, 0.08); }
        .selo { flex: none; width: 36px; height: 36px; display: grid; place-items: center; border-radius: 11px; color: #fff;
            background: linear-gradient(160deg, #a78bfa, #6d28d9); box-shadow: 0 4px 12px rgba(109, 40, 217, 0.35); }
        .selo svg { width: 19px; height: 19px; }
        .textos { flex: 1; min-width: 0; }
        .tit { font-size: 15px; font-weight: 700; letter-spacing: -0.015em; }
        .sub { font-size: 12px; color: #5c657a; }
        .fechar { flex: none; width: 28px; height: 28px; padding: 0; border: 0; border-radius: 50%; cursor: pointer; display: grid; place-items: center;
            background: rgba(20, 25, 45, 0.07); color: #5c657a; }
        .fechar svg { width: 13px; height: 13px; }
        .corpo { padding: 6px 14px 14px; overflow-y: auto; overscroll-behavior: contain; }
        .secao { margin: 14px 2px 8px; font-size: 11px; font-weight: 700; letter-spacing: 0.05em; text-transform: uppercase; color: #5c657a; }
        .cartao { margin-bottom: 8px; padding: 12px 12px 10px; border-radius: 16px; background: rgba(20, 25, 45, 0.045); }
        .linha { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
        .art { font-size: 15px; font-weight: 800; letter-spacing: -0.02em; }
        .chip { padding: 2px 9px; border-radius: 999px; background: rgba(109, 40, 217, 0.12); color: #5b21b6; font-size: 11.5px; font-weight: 700; }
        .chip.ok { background: rgba(22, 130, 74, 0.13); color: #11663a; }
        .chip.aviso { background: rgba(180, 83, 9, 0.14); color: #8a4a06; }
        .chip.revog { background: rgba(213, 64, 90, 0.14); color: #a3263b; }
        .nota-rev { margin-top: 5px; font-size: 12px; font-weight: 600; color: #a3263b; }
        .meta { margin-top: 3px; font-size: 12px; color: #5c657a; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .acoes { display: flex; gap: 6px; margin-top: 10px; }
        .btn { padding: 6px 12px; border: 0; border-radius: 999px; font: inherit; font-size: 12px; font-weight: 700; cursor: pointer;
            color: #1c2333; background: rgba(20, 25, 45, 0.09); }
        .btn.pri { color: #fff; background: linear-gradient(160deg, #8b5cf6, #6d28d9); }
        .btn.perigo { color: #a3263b; background: rgba(213, 64, 90, 0.12); }
        .btn:active { transform: scale(0.96); }
        .vazio { margin: 14px 2px; font-size: 12.5px; color: #5c657a; }
        .manual { display: flex; gap: 8px; margin-top: 4px; }
        .manual input { flex: 1; min-width: 0; padding: 9px 12px; border: 0; border-radius: 12px; font: inherit; font-size: 13px;
            color: #1c2333; background: rgba(20, 25, 45, 0.07); box-shadow: inset 0 0 0 1px rgba(20, 25, 45, 0.06); }
        .manual input:focus { outline: none; box-shadow: 0 0 0 2px #8b5cf6; }
        .aviso-msg { margin: 10px 2px 0; padding: 9px 12px; border-radius: 12px; font-size: 12px; font-weight: 600;
            background: rgba(109, 40, 217, 0.1); color: #5b21b6; }
        .aviso-msg[hidden] { display: none; }
        .rodape { margin: 12px 2px 0; font-size: 11.5px; color: #5c657a; }
        @media (prefers-color-scheme: dark) {
            .painel { color: #f2f3f7; background: rgba(26, 29, 42, 0.92); box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.1), 0 22px 54px rgba(0, 0, 0, 0.55); }
            .topo { border-bottom-color: rgba(255, 255, 255, 0.09); }
            .sub, .meta, .secao, .vazio, .rodape { color: #a9afc4; }
            .fechar { background: rgba(255, 255, 255, 0.12); color: #c9cde0; }
            .cartao { background: rgba(255, 255, 255, 0.07); }
            .chip { background: rgba(167, 139, 250, 0.2); color: #d8c8ff; }
            .chip.ok { background: rgba(95, 220, 154, 0.16); color: #8ff0bb; }
            .chip.aviso { background: rgba(255, 180, 84, 0.16); color: #ffcf91; }
            .chip.revog { background: rgba(255, 138, 155, 0.18); color: #ffb0bd; }
            .nota-rev { color: #ffb0bd; }
            .btn { color: #f2f3f7; background: rgba(255, 255, 255, 0.13); }
            .btn.perigo { color: #ffb0bd; background: rgba(255, 138, 155, 0.16); }
            .manual input { color: #f2f3f7; background: rgba(255, 255, 255, 0.09); box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.08); }
            .aviso-msg { background: rgba(167, 139, 250, 0.18); color: #e2d6ff; }
            .fab .n { box-shadow: 0 0 0 2px #1a1d2a; }
        }
    `;

    function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
    function rotuloArt(i) { return Ref.rotuloDoArtigo(i); }
    function origemTxt(i) {
        const o = (i.origens || [])[0];
        if (!o) return 'adicionado por você';
        const mais = (i.origens || []).length > 1 ? ' (+' + ((i.origens || []).length - 1) + ')' : '';
        return (o.questaoId || 'questão') + (o.assunto ? ' · ' + o.assunto : o.materia ? ' · ' + o.materia : '') + mais;
    }

    function cartaoPendente(p) {
        const semLei = !p.lei;
        // artigo que a lei vigente revogou: avisa em vez de oferecer "Salvar"
        const revog = !semLei && revogado(acharBloco(p.artigo, p.sufixo));
        const chips = (p.detalhe ? '<span class="chip">' + esc(p.detalhe) + '</span>' : '')
            + (revog ? '<span class="chip revog">revogado</span>' : '')
            + (semLei ? '<span class="chip aviso">lei não identificada</span>' : (p.inferida ? '<span class="chip aviso">lei sugerida</span>' : ''));
        const id = esc(p.id);
        const acoes = semLei
            ? '<button class="btn pri" data-a="atribuir" data-id="' + id + '">É desta lei</button><button class="btn perigo" data-a="descartar" data-id="' + id + '">Descartar</button>'
            : revog
                ? '<button class="btn" data-a="ver" data-id="' + id + '">Ver na lei</button><button class="btn perigo" data-a="descartar" data-id="' + id + '">Descartar</button>'
                : '<button class="btn" data-a="ver" data-id="' + id + '">Ver na lei</button><button class="btn pri" data-a="salvar" data-id="' + id + '">Salvar</button><button class="btn perigo" data-a="descartar" data-id="' + id + '" aria-label="Descartar">✕</button>';
        return '<div class="cartao"><div class="linha"><span class="art">' + esc(rotuloArt(p)) + '</span>' + chips + '</div>'
            + '<div class="meta" title="' + esc(origemTxt(p)) + '">' + esc(origemTxt(p)) + '</div>'
            + (revog ? '<div class="nota-rev">Revogado pela lei vigente. A questão pode ser de antes da mudança.</div>' : '')
            + '<div class="acoes">' + acoes + '</div></div>';
    }
    function cartaoSalvo(r) {
        const quando = r.srs ? Srs.rotuloProxima(r.srs, Date.now()) : '';
        return '<div class="cartao"><div class="linha"><span class="art">' + esc(rotuloArt(r)) + '</span>'
            + (r.detalhe ? '<span class="chip">' + esc(r.detalhe) + '</span>' : '')
            + (revogado(acharBloco(r.artigo, r.sufixo)) ? '<span class="chip revog">revogado</span>' : '')
            + '<span class="chip ok">revisar ' + esc(quando) + '</span></div>'
            + '<div class="acoes"><button class="btn" data-a="ver" data-id="' + esc(r.id) + '">Ver na lei</button><button class="btn perigo" data-a="remover" data-id="' + esc(r.id) + '">Remover</button></div></div>';
    }

    function listas() {
        return {
            pendentes: estado.pendentes.filter((p) => p.lei === lei),
            semLei: estado.pendentes.filter((p) => !p.lei),
            salvos: estado.revisao.filter((r) => r.lei === lei)
        };
    }

    function renderizar() {
        // captura desligada e nada guardado: não há o que mostrar, então nem o botão aparece
        if (!estado.ativo && !estado.revisao.length && !estado.pendentes.length) { if (host) { host.remove(); host = null; raiz = null; } return; }
        if (!host || !host.isConnected) {
            host = document.createElement('div');
            host.id = 'cb-ae-host';
            raiz = host.attachShadow({ mode: 'open' });
            document.documentElement.appendChild(host);
        }
        const { pendentes, semLei, salvos } = listas();
        const total = pendentes.length + semLei.length;
        const msgAnterior = raiz.querySelector('.aviso-msg');
        const msgTexto = msgAnterior && !msgAnterior.hidden ? msgAnterior.textContent : '';
        const valorManual = raiz.querySelector('.manual input') ? raiz.querySelector('.manual input').value : '';

        let corpo = '';
        if (pendentes.length) corpo += '<div class="secao">Para confirmar</div>' + pendentes.map(cartaoPendente).join('');
        if (semLei.length) corpo += '<div class="secao">Sem lei definida</div>' + semLei.map(cartaoPendente).join('');
        if (salvos.length) corpo += '<div class="secao">Salvos para revisar</div>' + salvos.map(cartaoSalvo).join('');
        if (!pendentes.length && !semLei.length && !salvos.length) {
            corpo += '<p class="vazio">Nada por aqui ainda. Quando você errar uma questão no QConcursos e os comentários citarem artigos, eles aparecem neste painel para você confirmar.</p>';
        }
        corpo += '<div class="secao">Adicionar um artigo</div><div class="manual"><input type="text" inputmode="numeric" placeholder="Número, ex.: 279 ou 311-A" aria-label="Número do artigo"><button class="btn pri" data-a="manual">Adicionar</button></div>';
        corpo += '<div class="aviso-msg" role="status" ' + (msgTexto ? '' : 'hidden') + '>' + esc(msgTexto) + '</div>';
        corpo += '<p class="rodape">A revisão espaçada fica no popup da extensão, em “Artigos para revisar”.</p>';

        raiz.innerHTML = '<style>' + CSS + '</style>'
            + '<button class="fab" aria-label="Artigos dos seus erros" title="Artigos dos seus erros">' + ICONE_LIVRO + (total ? '<span class="n">' + total + '</span>' : '') + '</button>'
            + '<section class="painel" ' + (aberto ? '' : 'hidden') + ' aria-label="Artigos dos seus erros">'
            + '<div class="topo"><span class="selo">' + ICONE_LIVRO + '</span><div class="textos"><div class="tit">Artigos dos seus erros</div><div class="sub">' + esc(Ref.nomeCompletoDaLei(lei)) + '</div></div>'
            + '<button class="fechar" aria-label="Fechar painel">' + ICONE_FECHAR + '</button></div>'
            + '<div class="corpo">' + corpo + '</div></section>';

        const campo = raiz.querySelector('.manual input');
        if (campo && valorManual) campo.value = valorManual;
        ligarEventos();
        marcarNaPagina();
    }

    let timerMsg = null;
    function avisar(texto) {
        if (!raiz) return;
        const el = raiz.querySelector('.aviso-msg');
        if (!el) return;
        el.textContent = texto;
        el.hidden = false;
        clearTimeout(timerMsg);
        // procura o elemento de novo na hora de esconder: o painel é redesenhado a cada mudança no storage
        timerMsg = setTimeout(() => {
            const atual = raiz && raiz.querySelector('.aviso-msg');
            if (atual) atual.hidden = true;
        }, 6000);
    }

    function abrirPainel(v) {
        aberto = v;
        if (!v) { try { sessionStorage.setItem(CHAVE_FECHADO, lei); } catch (e) { /* sem sessionStorage */ } }
        else { try { sessionStorage.removeItem(CHAVE_FECHADO); } catch (e) { /* ignora */ } }
        const painel = raiz && raiz.querySelector('.painel');
        if (painel) painel.hidden = !v;
    }

    function ligarEventos() {
        raiz.querySelector('.fab').addEventListener('click', () => abrirPainel(!aberto));
        raiz.querySelector('.fechar').addEventListener('click', () => abrirPainel(false));
        raiz.querySelector('.manual input').addEventListener('keydown', (e) => {
            if (e.key === 'Enter') adicionarManual(e.target.value).then((ok) => { if (ok) e.target.value = ''; });
        });
        raiz.querySelector('.painel').addEventListener('click', async (e) => {
            const b = e.target.closest('button[data-a]');
            if (!b) return;
            const id = b.dataset.id;
            const item = estado.pendentes.find((x) => x.id === id) || estado.revisao.find((x) => x.id === id);
            switch (b.dataset.a) {
                case 'ver': if (item && !focarArtigo(item.artigo, item.sufixo)) avisar('Não achei esse artigo nesta página.'); break;
                case 'salvar': if (item) await salvar(item); break;
                case 'descartar': await Store.descartarPendente(id); break;
                case 'remover': await Store.removerRevisao(id); break;
                case 'atribuir': await Store.atribuirLei(id, lei); avisar('Pronto: agora ele é desta lei.'); break;
                case 'manual': {
                    const campo = raiz.querySelector('.manual input');
                    if (await adicionarManual(campo.value)) campo.value = '';
                    break;
                }
                default: break;
            }
        });
    }

    // ------------------------------------------------------------------ ciclo de vida
    async function atualizar() {
        const contar = (e) => e.pendentes.filter((p) => p.lei === lei || !p.lei).length;
        const antes = contar(estado);
        estado = await Store.ler();
        const agora = contar(estado);
        let fechado = false;
        try { fechado = sessionStorage.getItem(CHAVE_FECHADO) === lei; } catch (e) { /* ignora */ }
        // abre sozinho quando há algo para confirmar ao carregar a lei (a menos que a pessoa já tenha
        // fechado o painel nesta aba) ou quando chega algo novo enquanto a lei está aberta
        if (agora > 0 && (primeiraCarga ? !fechado : agora > antes)) aberto = true;
        primeiraCarga = false;
        renderizar();
    }

    try {
        chrome.storage.onChanged.addListener((mud, area) => {
            if (area !== 'local') return;
            if (mud[Store.K_PEND] || mud[Store.K_REV] || mud[Store.K_ATIVO]) atualizar();
        });
    } catch (e) { /* sem storage */ }

    // link vindo do popup/QConcursos: ...l13105.htm#art279 → rola e destaca o artigo
    function focarPeloHash() {
        const m = /^#art(\d{1,4})([a-z])?\.?$/i.exec(location.hash); // "#art12." é o âncora do texto vigente
        if (!m) return;
        const artigo = String(parseInt(m[1], 10));
        const sufixo = m[2] ? m[2].toUpperCase() : '';
        if (!focarArtigo(artigo, sufixo)) setTimeout(() => focarArtigo(artigo, sufixo), 1500);
    }

    atualizar().then(() => setTimeout(focarPeloHash, 700));
})();
