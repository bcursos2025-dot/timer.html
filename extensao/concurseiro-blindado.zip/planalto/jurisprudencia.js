// ============================================================================
// jurisprudencia.js — Painel de jurisprudência por artigo, só dentro do
// Modo de Leitura. Clica em "Art. N" (qualquer artigo, de qualquer lei —
// o span .cb-art-ref é inserido por cb-artigos-lista.js pra TODOS, não só
// os importantes do CPC) e abre um painel deslizando da direita com os
// julgados cadastrados pra aquele artigo.
//
// IMPORTANTE: o JURIS_DB abaixo começa VAZIO de propósito. Este arquivo só
// cuida da interface (abrir/fechar/mostrar) — o conteúdo jurídico (STJ,
// STF, ementas etc.) tem que ser preenchido com fonte real, por você. Ver
// o formato comentado logo abaixo.
// ============================================================================

(function () {
    if (window.__cbJurisprudenciaLoaded) return;
    window.__cbJurisprudenciaLoaded = true;

    // --------------------------------------------------------------------
    // Base de dados de jurisprudência. Chave externa = lei (mesmo formato
    // que cb-assunto-artigo.js usa: 'l13105' pro CPC, 'cf88' pra
    // Constituição etc. — ver CBArtigos.detectarLei()). Chave interna =
    // número do artigo (inteiro, sem "Art." nem "º"). Cada entrada é uma
    // lista de julgados, mais recente primeiro:
    //
    // window.CBJurisprudenciaDB = {
    //   l13105: {
    //     109: [
    //       {
    //         tribunal: 'STJ',                         // STJ, STF, TJ-SP...
    //         referencia: 'REsp 1.234.567/SP',          // número do processo
    //         relator: 'Min. Fulano de Tal',            // opcional
    //         orgao: '3ª Turma',                        // opcional
    //         data: '12/03/2024',                       // opcional
    //         ementa: 'Resumo curto do que foi decidido, 2-3 linhas.',
    //         url: 'https://...'                        // opcional, link pro acórdão
    //       }
    //     ]
    //   }
    // };
    //
    // Pode colar isso num arquivo à parte (ex: jurisprudencia-dados.js,
    // carregado DEPOIS deste no manifest) em vez de editar aqui — o painel
    // lê de window.CBJurisprudenciaDB, então funciona do mesmo jeito.
    // --------------------------------------------------------------------
    window.CBJurisprudenciaDB = window.CBJurisprudenciaDB || {};

    // Mapa lei → slug usado pela Corpus927 (extensão de terceiros,
    // corpus927.enfam.jus.br) nas URLs de cada código, ex:
    // corpus927.enfam.jus.br/legislacao/cpc-15#art-9 pro CPC. Usado só pra
    // dar um link de saída no estado vazio, quando não há nada cadastrado
    // localmente ainda — não fazemos nenhuma requisição pra lá, é só um
    // link clicável.
    const CORPUS927_SLUGS = { l13105: 'cpc-15' };
    function linkCorpus927(lei, numero) {
        const slug = CORPUS927_SLUGS[lei];
        return slug ? `https://corpus927.enfam.jus.br/legislacao/${slug}#art-${numero}` : null;
    }

    const ICON_CLOSE = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
    const ICON_SCALE = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="3" x2="12" y2="21"/><path d="M5 7l-3 7a3 3 0 0 0 6 0z"/><path d="M19 7l-3 7a3 3 0 0 0 6 0z"/><path d="M5 7h14"/><path d="M12 3l4 4"/></svg>';
    const ICON_LINK = '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>';

    let painel = null;

    function nomeLei(lei) {
        const nomes = { l13105: 'CPC', cf88: 'Constituição Federal', l10406: 'Código Civil', l5172: 'CTN', l6830: 'LEF' };
        return nomes[lei] || (lei || '').toUpperCase();
    }

    function escapeHtml(s) {
        const div = document.createElement('div');
        div.textContent = s || '';
        return div.innerHTML;
    }

    function montarPainel() {
        painel = document.createElement('div');
        painel.id = 'cb-jur-painel';
        painel.innerHTML = `
            <div class="cb-jur-header">
                <div class="cb-jur-titulo-wrap">
                    <span class="cb-jur-icone">${ICON_SCALE}</span>
                    <div>
                        <div class="cb-jur-titulo">Jurisprudência</div>
                        <div class="cb-jur-subtitulo" id="cb-jur-subtitulo"></div>
                    </div>
                </div>
                <button id="cb-jur-fechar" class="cb-jur-fechar-btn" title="Fechar">${ICON_CLOSE}</button>
            </div>
            <div id="cb-jur-corpo" class="cb-jur-corpo"></div>
        `;
        document.body.appendChild(painel);
        painel.querySelector('#cb-jur-fechar').addEventListener('click', fecharPainel);
    }

    function renderizarEntradas(entradas, lei, numero) {
        if (!entradas || !entradas.length) {
            const linkExterno = linkCorpus927(lei, numero);
            return `
                <div class="cb-jur-vazio">
                    <span class="cb-jur-vazio-icone">${ICON_SCALE}</span>
                    <p>Nenhuma jurisprudência cadastrada para este artigo ainda.</p>
                    ${linkExterno ? `<a class="cb-jur-link-externo" href="${linkExterno}" target="_blank" rel="noopener">${ICON_LINK} Ver na Corpus927</a>` : ''}
                </div>
            `;
        }
        return entradas.map((j) => `
            <div class="cb-jur-card">
                <div class="cb-jur-card-top">
                    <span class="cb-jur-tribunal">${escapeHtml(j.tribunal || '')}</span>
                    ${j.data ? `<span class="cb-jur-data">${escapeHtml(j.data)}</span>` : ''}
                </div>
                <div class="cb-jur-referencia">${escapeHtml(j.referencia || '')}</div>
                ${(j.orgao || j.relator) ? `<div class="cb-jur-meta">${[j.orgao, j.relator].filter(Boolean).map(escapeHtml).join(' · ')}</div>` : ''}
                ${j.ementa ? `<div class="cb-jur-ementa">${escapeHtml(j.ementa)}</div>` : ''}
                ${j.url ? `<a class="cb-jur-link" href="${escapeHtml(j.url)}" target="_blank" rel="noopener">${ICON_LINK} Ver íntegra</a>` : ''}
            </div>
        `).join('');
    }

    let pedidoAtual = 0;
    async function abrirPainel(lei, numero, sufixo) {
        if (!painel) montarPainel();
        const entradas = (window.CBJurisprudenciaDB[lei] && window.CBJurisprudenciaDB[lei][numero]) || [];
        const corpo = painel.querySelector('#cb-jur-corpo');
        painel.querySelector('#cb-jur-subtitulo').textContent = `Art. ${numero}${sufixo ? '-' + sufixo : 'º'} — ${nomeLei(lei)}`;
        requestAnimationFrame(() => painel.classList.add('cb-jur-aberto'));
        // julgados cadastrados à mão (CBJurisprudenciaDB) têm prioridade; sem eles, busca no Corpus927 (corpus927.js)
        if (entradas.length || !window.CBCorpus927) {
            corpo.innerHTML = renderizarEntradas(entradas, lei, numero);
            return;
        }
        const meu = ++pedidoAtual;
        corpo.innerHTML = '<div class="cb-c9-carregando">Buscando no Corpus927…</div>';
        const r = await window.CBCorpus927.carregar(numero, sufixo);
        if (meu !== pedidoAtual) return;
        if (r.indisponivel) corpo.innerHTML = `<div class="cb-c9-aviso">${escapeHtml(r.indisponivel)}</div>`;
        else if (r.erro) corpo.innerHTML = `<div class="cb-c9-aviso">Não consegui buscar agora: ${escapeHtml(r.erro)}.</div>`;
        else corpo.innerHTML = r.html;
    }

    function fecharPainel() {
        if (painel) painel.classList.remove('cb-jur-aberto');
    }

    document.addEventListener('click', (e) => {
        // Só reage dentro do Modo de Leitura — na página normal do
        // Planalto, "Art. N" continua sem nenhum comportamento de clique.
        const overlay = e.target.closest('#cb-reading-mode-overlay');
        if (!overlay || overlay.style.display === 'none') return;

        const martelo = e.target.closest('a.c927');
        if (martelo && window.CBCorpus927 && window.CBArtigos) {
            const info = window.CBCorpus927.artigoDoLink(martelo.getAttribute('href'));
            const leiM = window.CBArtigos.detectarLei();
            if (info && leiM) { e.preventDefault(); abrirPainel(leiM, info.numero, info.sufixo); return; }
        }

        const ref = e.target.closest('.cb-art-ref');
        if (!ref) return;

        const numero = ref.getAttribute('data-cb-art-num');
        const lei = ref.getAttribute('data-cb-art-lei');
        if (!numero || !lei) return;

        abrirPainel(lei, numero, window.CBCorpus927 ? window.CBCorpus927.sufixoDoRef(ref) : '');
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && painel && painel.classList.contains('cb-jur-aberto')) fecharPainel();
    });
})();
