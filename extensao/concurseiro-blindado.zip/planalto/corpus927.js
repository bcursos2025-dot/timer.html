// ============================================================================
// corpus927.js — Jurisprudência por artigo, vinda do Corpus927 (ENFAM, corpus927.enfam.jus.br), para as páginas de lei
// do Planalto. Duas camadas, no molde dos outros módulos:
//   • funções puras (chave da lei, número do artigo, HTML do painel) — rodam em Node, ver
//     planalto/testes/corpus927.test.js;
//   • ligação com a página: pede o artigo ao serviço de fundo (dados-config/corpus927-bg.js, que é quem tem permissão de
//     falar com o site) e devolve o HTML pronto para os painéis (comunidade.js e jurisprudencia.js).
//
// Só se busca o artigo em que a pessoa clicou. A Constituição Federal e as leis que o Corpus927 não tem ficam sem painel
// (a função devolve { indisponivel }), sem erro.
// ============================================================================
(function (raiz) {
    'use strict';

    // ------------------------------------------------------------------ puro
    // "l13105.htm" → "l:13105"; "Del2848compilado.htm" → "del:2848"; "Lcp64.htm" → "lcp:64"; "L10.833compilado.htm" → "l:10833"
    function chaveDaLei(caminho) {
        const base = String(caminho || '').split('?')[0].split('#')[0].split('/').pop().toLowerCase().replace(/\.html?$/, '');
        const m = /^(lcp|del|lei|l)\.?0*(\d[\d.]*)/.exec(base);
        if (!m) return null;
        const numero = m[2].replace(/\./g, '').replace(/^0+/, '');
        if (!numero) return null;
        return (m[1] === 'lei' ? 'l' : m[1]) + ':' + numero;
    }

    // número do artigo na URN: "5" + "A" → "5A" (o site não usa hífen). `numero` vem do span (inteiro) e `sufixo` do texto
    // logo depois ("-A"), porque o span da extensão só cobre "Art. 121".
    function artigoParaUrn(numero, sufixo) {
        const n = String(numero == null ? '' : numero).replace(/\D/g, '');
        if (!n) return null;
        const s = String(sufixo || '').replace(/[^A-Za-z]/g, '').toUpperCase().slice(0, 2);
        return n + s;
    }
    const sufixoDoTexto = (texto) => {
        const m = /^\s*[ºo°]?\s*-\s*([A-Z])(?![a-zà-ú])/.exec(String(texto || ''));
        return m ? m[1] : '';
    };

    // O Planalto põe um martelinho (<a class="c927" href="http://corpus927.enfam.jus.br/legislacao/cpc-15#art-121A">) antes de cada
    // artigo, que abre o site do Corpus927 em outra aba. A extensão usa o href para abrir o painel de jurisprudência na própria página.
    function artigoDoLink(href) {
        const m = /#art-(\d{1,5})([A-Za-z]{0,2})\s*$/.exec(String(href || ''));
        return m ? { numero: m[1], sufixo: m[2].toUpperCase() } : null;
    }

    const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const dataBr = (iso) => { const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || ''); return m ? `${m[3]}/${m[2]}/${m[1]}` : ''; };

    const GRUPOS = [
        ['sumulasVinculantes', 'Súmulas vinculantes'],
        ['sumulas', 'Súmulas'],
        ['teses', 'Teses (Jurisprudência em Teses)'],
        ['controle', 'Controle de constitucionalidade'],
        ['repercussao', 'Repercussão geral (STF)'],
        ['repetitivos', 'Recursos repetitivos (STJ)'],
        ['stjAgrupados', 'Posicionamentos agrupados do STJ'],
        ['stjIsolados', 'Posicionamentos isolados do STJ'],
        ['alteracoes', 'Alterações do artigo'],
    ];

    function itemHtml(it) {
        const cab = [`<b class="cb-c9-tit">${esc(it.titulo || 'Sem título')}</b>`];
        if (it.data) cab.push(`<span class="cb-c9-data">${esc(dataBr(it.data))}</span>`);
        if (it.situacao) cab.push(`<span class="cb-c9-sit">${esc(it.situacao)}</span>`);
        const meta = [it.relator && 'Rel. ' + it.relator, it.origem, it.semelhantes ? `${it.semelhantes} semelhante${it.semelhantes === 1 ? '' : 's'}` : ''].filter(Boolean).map(esc).join(' · ');
        const resumo = it.tese || it.tema;
        const texto = it.texto
            ? `<details class="cb-c9-det"><summary>${it.tese || it.tema ? 'ver ementa' : 'ver texto'}</summary><div class="cb-c9-texto">${esc(it.texto)}</div></details>`
            : '';
        const link = it.url ? `<a class="cb-c9-link" href="${esc(it.url)}" target="_blank" rel="noopener">fonte</a>` : '';
        return `<div class="cb-c9-item"><div class="cb-c9-cab">${cab.join('')}</div>${meta ? `<div class="cb-c9-meta">${meta}</div>` : ''}${resumo ? `<p class="cb-c9-resumo">${esc(resumo)}</p>` : ''}${texto}${link}</div>`;
    }

    function painelHtml(dados, ctx) {
        const c = ctx || {};
        let abriu = false;
        const secoes = GRUPOS.map(([chave, titulo]) => {
            const itens = (dados && dados[chave]) || [];
            if (!itens.length) return '';
            const corpo = chave === 'alteracoes'
                ? itens.map((a) => `<div class="cb-c9-item"><div class="cb-c9-cab"><b class="cb-c9-tit">${esc(a.titulo || 'Alteração')}</b>${a.data ? `<span class="cb-c9-data">${esc(String(a.data).slice(0, 10))}</span>` : ''}</div>${a.texto ? `<div class="cb-c9-texto">${esc(a.texto)}</div>` : ''}</div>`).join('')
                : itens.map(itemHtml).join('');
            const aberta = !abriu; abriu = true;
            return `<details class="cb-c9-sec"${aberta ? ' open' : ''}><summary>${esc(titulo)} <em>${itens.length}</em></summary>${corpo}</details>`;
        }).join('');
        const rodape = c.link ? `<a class="cb-c9-externo" href="${esc(c.link)}" target="_blank" rel="noopener">Abrir este artigo no Corpus927</a>` : '';
        if (!secoes) return `<div class="cb-c9-vazio"><p>O Corpus927 não tem julgados cadastrados para este artigo.</p>${rodape}</div>`;
        return `<div class="cb-c9">${secoes}${rodape}<p class="cb-c9-fonte">Fonte: Corpus927 (ENFAM/CNJ). Confira sempre a decisão original.</p></div>`;
    }

    const api = { chaveDaLei, artigoParaUrn, sufixoDoTexto, artigoDoLink, painelHtml, GRUPOS };
    if (typeof module !== 'undefined' && module.exports) { module.exports = api; return; }

    // ------------------------------------------------------------------ página
    if (raiz.CBCorpus927) return;
    const memoria = new Map();

    function normaDaPagina() {
        const t = raiz.CBCorpus927Normas || {};
        const e = t[chaveDaLei(raiz.location.pathname)];
        return e ? { id: e[0], slug: e[1] } : null;
    }

    function pedirAoFundo(urn) {
        return new Promise((resolve) => {
            try {
                raiz.chrome.runtime.sendMessage({ action: 'corpus927_buscar', urn }, (r) => {
                    if (raiz.chrome.runtime.lastError || !r) resolve({ erro: 'não consegui falar com a extensão (recarregue a página)' });
                    else resolve(r);
                });
            } catch (e) { resolve({ erro: 'a extensão foi recarregada: atualize a página' }); }
        });
    }

    // numero: inteiro do artigo; sufixo: "A", "B"... (opcional). Devolve { html } ou { indisponivel } ou { erro }.
    async function carregar(numero, sufixo) {
        const norma = normaDaPagina();
        if (!norma) return { indisponivel: 'O Corpus927 não tem esta lei (ele cobre leis e códigos, não a Constituição).' };
        const art = artigoParaUrn(numero, sufixo);
        if (!art) return { erro: 'número de artigo não entendido' };
        const urn = `nrm:${norma.id}|art:${art}`;
        if (memoria.has(urn)) return memoria.get(urn);
        const r = await pedirAoFundo(urn);
        if (r.erro) return { erro: r.erro };
        const saida = { html: painelHtml(r.dados, { link: `https://corpus927.enfam.jus.br/legislacao/${norma.slug}#art-${art.replace(/\D+$/, '')}` }), semDados: !!r.semDados };
        memoria.set(urn, saida);
        return saida;
    }

    // Lê o sufixo ("-A") do texto logo depois do span "Art. N" que a extensão cria.
    function sufixoDoRef(ref) {
        const prox = ref && ref.nextSibling;
        return prox && prox.nodeType === 3 ? sufixoDoTexto(prox.textContent) : '';
    }

    raiz.CBCorpus927 = Object.assign({ normaDaPagina, carregar, sufixoDoRef }, api);
})(typeof window !== 'undefined' ? window : globalThis);
