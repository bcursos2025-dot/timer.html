// ============================================================================
// highlighter.js — Marcador de Texto (Planalto) — módulo do
// Concurseiro Blindado. Roda só em *.planalto.gov.br.
//
// v4 (captura rápida + negrito):
//  • CAPTURA RÁPIDA (botão no dock ou tecla G): passe o mouse e o parágrafo sob o cursor é destacado; um clique marca o parágrafo
//    inteiro com a cor/caneta escolhida (clicar de novo tira); ARRASTAR por vários parágrafos marca todos de uma vez (a página rola
//    sozinha junto à borda); Shift+clique marca do último parágrafo clicado até este; Ctrl+clique segue o link normalmente.
//    Cada parágrafo vira um grifo próprio (marcado com `bloco: true`), então dá para tirar um só sem mexer nos vizinhos.
//    Dentro da captura: teclas 1–6 trocam a cor, N liga a caneta de negrito, U liga o sublinhado, Esc sai.
//  • NEGRITO: botão "N" na barra de seleção (palavras soltas ou trechos) e caneta de negrito na captura. O negrito é uma CAMADA à
//    parte da cor (tipo 'negrito'): dá para ter um parágrafo colorido com palavras em negrito dentro, e apagar cada um sozinho.
//  • Gravação em fila (várias gravações seguidas não se atropelam) e em lote (arrastar por 40 parágrafos grava uma vez só).
//
// v3 (visual estilo Apple, apagar fácil, paleta de 19 cores):
//  • Seleção: 6 cores favoritas + "todas as cores" (paleta completa com o nome de cada uma), sublinhar, nota; se a seleção
//    toca um grifo existente aparece o botão vermelho "Apagar".
//  • Grifo existente: barra com cores, nota, copiar e "Apagar" com texto; Delete apaga; aviso "Desfazer" depois de apagar;
//    Ctrl+Z desfaz o último grifo criado ou apagado; "Apagar todos" no painel (com confirmação).
//  • Marcar por cima de um grifo que ficaria inteiro dentro do novo SUBSTITUI o antigo (antes ficavam um dentro do outro e o de
//    baixo virava um "fantasma" difícil de tirar).
//  • Ao restaurar, o texto grifado é conferido e, se o XPath apontar para outro lugar, a posição é recuperada pelo texto.
//
// v2:
//  1. Toolbar de seleção nova (cores + comentário) — igual antes.
//  2. Grifo já existente agora abre uma BARRA COMPACTA de ícones (cores +
//     comentar + copiar + excluir), em vez do popover grande com textarea
//     sempre visível. A nota só aparece se clicar no ícone de comentário.
//  3. Painel lateral vira uma lista de CARTÕES: texto, tempo relativo
//     ("há 5 min"), bolinha de cor, e ações rápidas (comentar/copiar/excluir)
//     direto no cartão, sem precisar clicar no texto da página.
//  4. Link "Ver todas as páginas" no topo do painel, abre a Central de
//     Páginas (paginas.html) numa aba nova, com todas as leis já grifadas.
// ============================================================================

(function () {
    if (window.__cbHighlighterLoaded) return;
    window.__cbHighlighterLoaded = true;
    console.log('[Marcador] highlighter.js carregado em', location.href);

    // Paleta completa (19). As 6 primeiras do FAVORITAS ficam sempre na barra; as outras abrem em "todas as cores".
    // As cores entram translúcidas sobre o texto (ver highlighter.css), então tons médios funcionam melhor que pastéis claríssimos.
    // Os hex das 5 primeiras são os de sempre: grifos antigos continuam com a mesma cor.
    const CORES = [
        { id: 'amarelo',           nome: 'Amarelo',           hex: '#ffe066' },
        { id: 'laranja',           nome: 'Laranja',           hex: '#ffc078' },
        { id: 'vermelho-honda',    nome: 'Vermelho Honda',    hex: '#e4002b' },
        { id: 'dusty-red',         nome: 'Dusty Red',         hex: '#c25b61' },
        { id: 'vinho',             nome: 'Vinho',             hex: '#a8345a' },
        { id: 'rosa',              nome: 'Rosa',              hex: '#ffa8c9' },
        { id: 'magenta',           nome: 'Magenta',           hex: '#e645b8' },
        { id: 'roxo',              nome: 'Roxo',              hex: '#b388eb' },
        { id: 'dusty-indigo',      nome: 'Dusty Indigo',      hex: '#6a78b0' },
        { id: 'azul',              nome: 'Azul',              hex: '#74c0fc' },
        { id: 'azul-bebe',         nome: 'Azul bebê',         hex: '#a8dcfb' },
        { id: 'verde-agua',        nome: 'Verde-água',        hex: '#7ee8d3' },
        { id: 'verde-azulado',     nome: 'Verde-azulado',     hex: '#2bb3a3' },
        { id: 'verde',             nome: 'Verde',             hex: '#8ce99a' },
        { id: 'verde-kawasaki',    nome: 'Verde Kawasaki',    hex: '#8cd100' },
        { id: 'verde-musgo-claro', nome: 'Verde-musgo claro', hex: '#aab87b' },
        { id: 'marrom-claro',      nome: 'Marrom claro',      hex: '#c8a27a' },
        { id: 'marfim',            nome: 'Marfim',            hex: '#eadfb4' },
        { id: 'cinza-claro',       nome: 'Cinza claro',       hex: '#bfc5cc' }
    ];
    const FAVORITAS = ['amarelo', 'verde', 'azul', 'rosa', 'laranja', 'roxo'];

    // UI da própria extensão (o texto dela não é texto da lei): fica de fora da busca por texto
    function ehElementoDaExtensao(el) {
        return !!(el && el.closest && el.closest('#cb-hl-toolbar, #cb-hl-barra, #cb-hl-panel, #cb-hl-panel-toggle, .cb-hl-toast, #cb-dock, #cb-ed-barra, #cb-ed-quadro, #cb-sug-topo, #cb-com-painel, #cb-jur-painel, #cb-cap-barra, #cb-cap-toggle, #cb-ft-rail, .cb-ft-pop, #cb-ae-host, #cb-desenho-canvas, script, style'));
    }

    const STORAGE_PREFIX = 'cbHighlights::';
    const pageKey = STORAGE_PREFIX + location.href.split('#')[0];

    const ICON_COMMENT = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>';
    const ICON_TRASH = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>';
    const ICON_COPY = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>';
    const ICON_LIST = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>';
    const ICON_UNDERLINE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3v7a6 6 0 0 0 12 0V3"/><line x1="4" y1="21" x2="20" y2="21"/></svg>';
    const ICON_BOLD = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M6 12h9a4 4 0 0 1 0 8H7a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h7a4 4 0 0 1 0 8"/></svg>';
    const ICON_UNDO = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7v6h6"/><path d="M21 17a9 9 0 0 0-15-6.7L3 13"/></svg>';
    // captura rápida: quatro cantos de seleção com um traço de grifo no meio (como o ícone do Cubox)
    const ICON_CAPTURA = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 8V5a2 2 0 0 1 2-2h3"/><path d="M16 3h3a2 2 0 0 1 2 2v3"/><path d="M21 16v3a2 2 0 0 1-2 2h-3"/><path d="M8 21H5a2 2 0 0 1-2-2v-3"/><line x1="8" y1="12" x2="16" y2="12"/></svg>';
    // Ícone do botão flutuante do marcador — mesmo estilo "linha fina" dos
    // outros ícones do hub (livro do Modo de Leitura, triângulo de
    // Prioridades). Antes era o emoji "✏️" nativo do SO, que destoava
    // (colorido, sombreado, tamanho inconsistente) do resto da interface.
    const ICON_MARCADOR = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 11-6 6v3h9l3-3"/><path d="m22 12-4.6 4.6a2 2 0 0 1-2.8 0l-5.2-5.2a2 2 0 0 1 0-2.8L14 4"/></svg>';

    let modoSublinhado = false;

    let toolbarEl = null;
    let barraEl = null; // barra compacta sobre um grifo existente
    let panelEl = null;
    let panelToggleEl = null;
    let activeMarkId = null;

    // -------------------- Persistência --------------------
    function carregarGrifos() {
        return new Promise((resolve) => {
            chrome.storage.local.get([pageKey], (res) => resolve(res[pageKey] || []));
        });
    }
    // Toda gravação passa por uma fila: "ler → alterar → gravar" de duas ações seguidas (cliques rápidos, arrastar por vários
    // parágrafos) não pode se atropelar, senão a segunda leitura volta sem a primeira alteração e uma marca some do storage.
    let filaDeGravacao = Promise.resolve();
    function naFila(fn) {
        const p = filaDeGravacao.then(fn);
        filaDeGravacao = p.then(() => {}, () => {});
        return p;
    }
    function salvarGrifos(lista) {
        return new Promise((resolve) => {
            try { chrome.storage.local.set({ [pageKey]: lista }, () => resolve()); } catch (e) { resolve(); }
        });
    }
    function adicionarGrifos(novos) {
        return naFila(async () => {
            const lista = await carregarGrifos();
            const ja = new Set(lista.map((g) => g.id));
            novos.forEach((g) => { if (!ja.has(g.id)) lista.push(g); });
            await salvarGrifos(lista);
            atualizarPainel(lista);
        });
    }
    function adicionarGrifo(grifo) { return adicionarGrifos([grifo]); }
    function atualizarGrifo(id, campos) {
        return naFila(async () => {
            const lista = await carregarGrifos();
            const idx = lista.findIndex(g => g.id === id);
            if (idx === -1) return;
            lista[idx] = { ...lista[idx], ...campos };
            await salvarGrifos(lista);
            atualizarPainel(lista);
        });
    }
    function removerGrifos(ids) {
        return naFila(async () => {
            const lista = await carregarGrifos();
            const set = new Set(ids);
            const nova = lista.filter((g) => !set.has(g.id));
            await salvarGrifos(nova);
            atualizarPainel(nova);
        });
    }
    function removerGrifo(id) { return removerGrifos([id]); }

    // -------------------- Serialização de posição (XPath simples) --------------------
    function getXPath(node) {
        if (node.nodeType === Node.TEXT_NODE) {
            const parent = node.parentNode;
            const siblings = Array.from(parent.childNodes).filter(n => n.nodeType === Node.TEXT_NODE);
            const idx = siblings.indexOf(node);
            return getXPath(parent) + '/text()[' + (idx + 1) + ']';
        }
        if (!node || node.nodeType !== Node.ELEMENT_NODE) return '';
        if (node === document.body) return '/html/body';
        const siblings = Array.from(node.parentNode ? node.parentNode.children : []).filter(n => n.tagName === node.tagName);
        const idx = siblings.indexOf(node) + 1;
        return getXPath(node.parentNode) + '/' + node.tagName.toLowerCase() + '[' + idx + ']';
    }
    function resolveXPath(xpath) {
        try {
            const result = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
            return result.singleNodeValue;
        } catch (e) {
            return null;
        }
    }
    function serializarSelecao(range) {
        return {
            startXPath: getXPath(range.startContainer),
            startOffset: range.startOffset,
            endXPath: getXPath(range.endContainer),
            endOffset: range.endOffset
        };
    }
    function reconstruirRange(pos) {
        const startNode = resolveXPath(pos.startXPath);
        const endNode = resolveXPath(pos.endXPath);
        if (!startNode || !endNode) return null;
        try {
            const range = document.createRange();
            range.setStart(startNode, Math.min(pos.startOffset, startNode.textContent.length));
            range.setEnd(endNode, Math.min(pos.endOffset, endNode.textContent.length));
            return range;
        } catch (e) {
            return null;
        }
    }

    // -------------------- Re-ancoragem por texto (fallback) --------------------
    // O XPath acima funciona bem enquanto a página não muda de estrutura
    // entre uma visita e outra — mas se o planalto.gov.br mexer em UM
    // elemento (ex: adicionar um parágrafo de nota de rodapé, trocar uma
    // <font> por <span>), o índice usado no XPath desalinha e o grifo some
    // silenciosamente, mesmo com o texto grifado ainda lá na página, idêntico.
    // Esse fallback re-localiza o grifo pelo PRÓPRIO TEXTO grifado (que já
    // era salvo em g.texto) mais um pedacinho de contexto antes/depois (pra
    // desempatar quando a mesma frase aparece mais de uma vez na lei) — é a
    // mesma ideia usada por ferramentas de anotação web como o Hypothesis
    // (open source, hypothes.is), só que numa versão bem mais enxuta, sem
    // precisar embutir a lib inteira (que depende de backend próprio) só
    // por essa única função.
    const CB_HL_CONTEXTO_LEN = 40;

    function normalizarEspacosRM(s) {
        return (s || '').replace(/\s+/g, ' ').trim();
    }

    // Chamada na hora de CRIAR o grifo — captura ~40 caracteres antes e
    // depois da seleção, já normalizados (espaços/quebras de linha viram
    // um espaço só), pra usar como "impressão digital" de contexto.
    function capturarContextoGrifo(range) {
        try {
            const antes = document.createRange();
            antes.setStart(document.body, 0);
            antes.setEnd(range.startContainer, range.startOffset);
            const depois = document.createRange();
            depois.setStart(range.endContainer, range.endOffset);
            depois.setEndAfter(document.body.lastChild || document.body);

            return {
                contextoPrefixo: normalizarEspacosRM(antes.toString()).slice(-CB_HL_CONTEXTO_LEN),
                contextoSufixo: normalizarEspacosRM(depois.toString()).slice(0, CB_HL_CONTEXTO_LEN)
            };
        } catch (e) {
            return { contextoPrefixo: '', contextoSufixo: '' };
        }
    }

    // Busca o texto grifado em qualquer lugar do body, escolhendo (entre
    // ocorrências repetidas) a que tem prefixo/sufixo mais parecidos com o
    // contexto salvo, e devolve um Range real correspondente.
    function buscarRangePorTexto(textoAlvo, contextoPrefixo, contextoSufixo) {
        const alvo = normalizarEspacosRM(textoAlvo);
        if (!alvo) return null;
        try {
            const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
                acceptNode: (n) => (n.parentElement && !ehElementoDaExtensao(n.parentElement))
                    ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT
            });
            let textoTotal = '';
            const mapa = []; // { no, inicio } — inicio = índice em textoTotal onde esse nó começa
            let n;
            while ((n = walker.nextNode())) {
                mapa.push({ no: n, inicio: textoTotal.length });
                textoTotal += n.nodeValue;
            }
            if (!textoTotal) return null;

            // Regex tolerante a diferenças de espaçamento (não a diferenças
            // de acentuação/maiúsculas — o texto de leis é bem estável
            // nesse quesito, então manter a busca exata reduz falso-positivo).
            const escapar = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            const regexAlvo = new RegExp(escapar(alvo).replace(/\s+/g, '\\s+'), 'g');

            let melhorInicio = -1, melhorFim = -1, melhorPontuacao = -1;
            let match;
            while ((match = regexAlvo.exec(textoTotal))) {
                const janelaAntes = textoTotal.slice(Math.max(0, match.index - CB_HL_CONTEXTO_LEN), match.index);
                const janelaDepois = textoTotal.slice(match.index + match[0].length, match.index + match[0].length + CB_HL_CONTEXTO_LEN);
                let pontuacao = 0;
                if (contextoPrefixo && normalizarEspacosRM(janelaAntes).endsWith(contextoPrefixo)) pontuacao += 2;
                if (contextoSufixo && normalizarEspacosRM(janelaDepois).startsWith(contextoSufixo)) pontuacao += 2;
                if (pontuacao > melhorPontuacao) {
                    melhorPontuacao = pontuacao;
                    melhorInicio = match.index;
                    melhorFim = match.index + match[0].length;
                }
                if (regexAlvo.lastIndex === match.index) regexAlvo.lastIndex++; // evita loop infinito em match vazio
            }
            if (melhorInicio === -1) return null;

            function localizarNo(indiceAlvo) {
                for (let i = mapa.length - 1; i >= 0; i--) {
                    if (mapa[i].inicio <= indiceAlvo) {
                        return { no: mapa[i].no, offset: indiceAlvo - mapa[i].inicio };
                    }
                }
                return null;
            }
            const inicioPos = localizarNo(melhorInicio);
            const fimPos = localizarNo(melhorFim);
            if (!inicioPos || !fimPos) return null;

            const range = document.createRange();
            range.setStart(inicioPos.no, Math.min(inicioPos.offset, inicioPos.no.textContent.length));
            range.setEnd(fimPos.no, Math.min(fimPos.offset, fimPos.no.textContent.length));
            return range;
        } catch (e) {
            console.warn('[Marcador] Falha na re-ancoragem por texto:', e);
            return null;
        }
    }

    // Ponto único usado pra restaurar um grifo salvo: tenta o caminho
    // rápido (XPath) e só cai pro fallback por texto se o primeiro falhar
    // de verdade — assim não muda nada no caso comum (site não mudou nada).
    function reconstruirRangeComFallback(g) {
        const viaXPath = reconstruirRange(g.pos);
        if (viaXPath) return viaXPath;
        if (!g.texto) return null;
        return buscarRangePorTexto(g.texto, g.contextoPrefixo || '', g.contextoSufixo || '');
    }

    // -------------------- Aplicar grifo visualmente --------------------
    function pintarRange(range, cor, id, tipo, bloco) {
        tipo = tipo || 'grifo';
        const marks = [];
        try {
            if (range.startContainer === range.endContainer) {
                marks.push(envolverTexto(range));
            } else {
                const commonAncestor = range.commonAncestorContainer;
                const walker = document.createTreeWalker(commonAncestor, NodeFilter.SHOW_TEXT, {
                    acceptNode: (node) => range.intersectsNode(node) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT
                });
                const nos = [];
                let n;
                while ((n = walker.nextNode())) nos.push(n);
                nos.forEach((textNode) => {
                    const subRange = document.createRange();
                    subRange.selectNodeContents(textNode);
                    if (textNode === range.startContainer) subRange.setStart(textNode, range.startOffset);
                    if (textNode === range.endContainer) subRange.setEnd(textNode, range.endOffset);
                    if (!subRange.collapsed) marks.push(envolverTexto(subRange));
                });
            }
        } catch (e) {
            console.warn('[Marcador] Falha ao pintar seleção:', e);
        }
        marks.forEach((m) => {
            if (!m) return;
            m.classList.add('cb-hl-mark');
            aplicarEstiloMark(m, cor, tipo);
            m.dataset.cbHlId = id;
            m.dataset.cbHlTipo = tipo;
            if (bloco) m.dataset.cbHlBloco = '1';   // veio da captura rápida (parágrafo inteiro)
            m.addEventListener('click', (ev) => {
                ev.stopPropagation();
                abrirBarra(m, id);
            });
        });
        return marks;
    }
    function aplicarEstiloMark(m, cor, tipo) {
        m.style.setProperty('--cb-hl-cor', cor);
        // negrito é só o peso da fonte (o CSS tira fundo e traço); a cor guardada serve apenas para a Central de Páginas
        m.classList.toggle('cb-hl-negrito', tipo === 'negrito');
        if (tipo === 'sublinhado') {
            m.style.backgroundColor = 'transparent';
            m.classList.add('cb-hl-sublinhado');
            m.style.textDecorationColor = cor;
            m.style.borderBottomColor = cor;
        } else {
            // a cor vai numa variável: o CSS faz um fundo translúcido e o texto mantém a cor da página
            // (a cor opaca com texto forçado escuro ficava ilegível em tema escuro/modo escuro forçado)
            m.style.removeProperty('background-color');
            m.classList.remove('cb-hl-sublinhado');
            m.style.textDecorationColor = '';
            m.style.borderBottomColor = '';
        }
    }
    function envolverTexto(range) {
        const mark = document.createElement('mark');
        try {
            range.surroundContents(mark);
            return mark;
        } catch (e) {
            const frag = range.extractContents();
            mark.appendChild(frag);
            range.insertNode(mark);
            return mark;
        }
    }

    // -------------------- Restaurar grifos salvos --------------------
    // O XPath guardado pode apontar para o lugar errado sem avisar (a página ganhou um elemento, o Modo de Leitura moveu o
    // texto de lugar...). Por isso o resultado é CONFERIDO contra o texto grifado; se não bater, procura-se o texto na página.
    function textoConfere(range, g) {
        if (!range) return false;
        const alvo = normalizarEspacosRM(g.texto || '');
        if (!alvo) return true;
        const achado = normalizarEspacosRM(range.toString());
        const n = Math.min(60, alvo.length, achado.length);
        return n > 0 && achado.slice(0, n) === alvo.slice(0, n);
    }
    function localizarRange(g) {
        const viaXPath = reconstruirRange(g.pos);
        if (textoConfere(viaXPath, g)) return viaXPath;
        if (!g.texto) return null;
        return buscarRangePorTexto(g.texto, g.contextoPrefixo || '', g.contextoSufixo || '');
    }
    async function restaurarGrifos() {
        const lista = await carregarGrifos();
        lista.forEach((g) => {
            const range = localizarRange(g);
            if (range) pintarRange(range, g.cor, g.id, g.tipo, g.bloco);
        });
        atualizarPainel(lista);
    }

    // -------------------- Cores: favoritas, recentes e paleta completa --------------------
    let ultimaCor = CORES[0].hex;
    const corPorHex = (hex) => CORES.find((c) => c.hex.toLowerCase() === String(hex || '').toLowerCase());
    // 6 cores sempre à mão. Se a última usada for outra (da paleta completa), ela entra no lugar da 6ª.
    function favoritas() {
        const base = FAVORITAS.map((id) => CORES.find((c) => c.id === id));
        const ult = corPorHex(ultimaCor);
        if (ult && !base.some((c) => c.id === ult.id)) base[base.length - 1] = ult;
        return base;
    }
    function lembrarCor(hex) {
        ultimaCor = hex;
        try { chrome.storage.local.set({ cbHlUltimaCor: hex }); } catch (e) { /* ignora */ }
    }
    const botaoCor = (c, selecionada) =>
        `<button type="button" class="cb-hl-cor${selecionada ? ' cb-hl-cor--sel' : ''}" data-cor="${c.hex}" style="--c:${c.hex}" title="${c.nome}" aria-label="${c.nome}"></button>`;
    function favoritasHtml(corAtual) {
        return `<div class="cb-hl-fav">${favoritas().map((c) => botaoCor(c, corAtual && c.hex.toLowerCase() === corAtual.toLowerCase())).join('')}`
            + `<button type="button" class="cb-hl-mais" data-acao="mais" title="Todas as cores" aria-label="Todas as cores"></button></div>`;
    }
    function paletaHtml(corAtual) {
        return `<div class="cb-hl-paleta" hidden>
            <div class="cb-hl-paleta-grade">${CORES.map((c) => botaoCor(c, corAtual && c.hex.toLowerCase() === corAtual.toLowerCase())).join('')}</div>
            <div class="cb-hl-paleta-nome">Escolha uma cor</div></div>`;
    }
    // hover na paleta mostra o nome da cor (ex.: "Verde Kawasaki")
    function ligarNomesDaPaleta(raiz) {
        const nome = raiz.querySelector('.cb-hl-paleta-nome');
        if (!nome) return;
        raiz.querySelectorAll('.cb-hl-paleta .cb-hl-cor').forEach((b) => {
            b.addEventListener('mouseenter', () => { nome.textContent = b.title; });
            b.addEventListener('mouseleave', () => { nome.textContent = 'Escolha uma cor'; });
        });
    }
    function alternarPaleta(raiz) {
        const p = raiz.querySelector('.cb-hl-paleta');
        if (p) p.hidden = !p.hidden;
    }

    // -------------------- Desfazer (Ctrl+Z) e aviso com ação --------------------
    const pilhaDesfazer = [];
    function empilhar(item) { pilhaDesfazer.push(item); if (pilhaDesfazer.length > 30) pilhaDesfazer.shift(); }

    function mostrarAviso(texto, acaoRotulo, aoClicar) {
        document.querySelectorAll('.cb-hl-toast').forEach((t) => t.remove());
        const toast = document.createElement('div');
        toast.className = 'cb-hl-toast';
        toast.setAttribute('role', 'status');
        toast.innerHTML = `<span>${escapeHtml(texto)}</span>${acaoRotulo ? `<button type="button" class="cb-hl-toast-acao">${escapeHtml(acaoRotulo)}</button>` : ''}`;
        document.body.appendChild(toast);
        requestAnimationFrame(() => toast.classList.add('cb-hl-toast-visible'));
        const fechar = () => { toast.classList.remove('cb-hl-toast-visible'); setTimeout(() => toast.remove(), 250); };
        const t = setTimeout(fechar, acaoRotulo ? 7000 : 1600);
        const b = toast.querySelector('.cb-hl-toast-acao');
        if (b) b.addEventListener('click', () => { clearTimeout(t); fechar(); aoClicar && aoClicar(); });
    }
    function mostrarToastCopiado() { mostrarAviso('Copiado'); }

    // -------------------- Apagar --------------------
    function removerMarcasDoDom(id) {
        document.querySelectorAll(`mark[data-cb-hl-id="${id}"]`).forEach((m) => {
            const parent = m.parentNode;
            if (!parent) return;
            while (m.firstChild) parent.insertBefore(m.firstChild, m);
            parent.removeChild(m);
            parent.normalize();
        });
    }
    async function apagarGrifo(id, opcoes) {
        const o = opcoes || {};
        const lista = await carregarGrifos();
        const g = lista.find((x) => x.id === id);
        removerMarcasDoDom(id);
        await removerGrifo(id);
        if (g && !o.silencioso) {
            empilhar({ tipo: 'apagou', grifo: g });
            mostrarAviso('Grifo apagado', 'Desfazer', () => restaurarApagado(g));
        }
        return g;
    }
    // devolve vários grifos de uma vez, na ordem em que foram criados (o XPath de cada um foi guardado com os anteriores já pintados)
    async function restaurarLote(grifos) {
        const ordem = grifos.slice().sort((a, b) => (a.criadoEm || 0) - (b.criadoEm || 0));
        const ok = [];
        ordem.forEach((g) => {
            const range = localizarRange(g);
            if (range) { pintarRange(range, g.cor, g.id, g.tipo, g.bloco); ok.push(g); }
        });
        if (ok.length < ordem.length) mostrarAviso(ordem.length === 1 ? 'Não consegui restaurar este grifo' : `Não consegui restaurar ${ordem.length - ok.length} grifo(s)`);
        if (ok.length) await adicionarGrifos(ok);
    }
    const restaurarApagado = (g) => restaurarLote([g]);
    // tira do DOM e do storage de uma vez; devolve os grifos removidos
    async function removerLote(ids) {
        const lista = await carregarGrifos();
        const set = new Set(ids);
        const removidos = lista.filter((g) => set.has(g.id));
        ids.forEach(removerMarcasDoDom);
        await removerGrifos(ids);
        return removidos;
    }
    async function apagarVarios(ids, opcoes) {
        const o = opcoes || {};
        const apagados = await removerLote(ids);
        if (!apagados.length) return;
        empilhar({ tipo: 'apagouVarios', grifos: apagados });
        if (o.semAviso) return;
        mostrarAviso(o.rotulo || (apagados.length === 1 ? 'Grifo apagado' : `${apagados.length} grifos apagados`), 'Desfazer', () => restaurarLote(apagados));
    }
    // desfaz uma criação em lote específica (aviso "Desfazer" depois de marcar vários parágrafos)
    async function desfazerCriacao(ids) {
        const chave = ids.join('|');
        const i = pilhaDesfazer.findIndex((it) => it.tipo === 'criouVarios' && it.ids.join('|') === chave);
        if (i >= 0) pilhaDesfazer.splice(i, 1);
        await removerLote(ids);
    }
    async function desfazerUltimo() {
        const item = pilhaDesfazer.pop();
        if (!item) return false;
        if (item.tipo === 'criouVarios') await removerLote(item.ids);
        else if (item.tipo === 'apagou') await restaurarLote([item.grifo]);
        else if (item.tipo === 'apagouVarios') await restaurarLote(item.grifos);
        return true;
    }

    // grifos que tocam um trecho (ids), e os que ficam inteiros dentro dele
    function idsDeGrifosNoRange(range, marcas) {
        const ids = new Set();
        (marcas || document.querySelectorAll('mark.cb-hl-mark[data-cb-hl-id]')).forEach((m) => {
            try { if (range.intersectsNode(m)) ids.add(m.dataset.cbHlId); } catch (e) { /* ignora */ }
        });
        return ids;
    }
    // cor e negrito são camadas independentes: marcar de novo só substitui grifos da MESMA camada
    const camadaDoTipo = (t) => (t === 'negrito' ? 'negrito' : 'cor');
    function tipoDoGrifoNaPagina(id) {
        const m = document.querySelector(`mark[data-cb-hl-id="${id}"]`);
        return m ? m.dataset.cbHlTipo : null;
    }
    function grifoInteiroDentro(id, range) {
        const marcas = document.querySelectorAll(`mark[data-cb-hl-id="${id}"]`);
        if (!marcas.length) return false;
        try {
            const mr = document.createRange();
            mr.setStartBefore(marcas[0]);
            mr.setEndAfter(marcas[marcas.length - 1]);
            return range.compareBoundaryPoints(Range.START_TO_START, mr) <= 0 && range.compareBoundaryPoints(Range.END_TO_END, mr) >= 0;
        } catch (e) { return false; }
    }

    // -------------------- Toolbar de seleção --------------------
    let ultimaRangeSelecionada = null;
    let idsNaSelecao = [];

    function criarToolbar() {
        toolbarEl = document.createElement('div');
        toolbarEl.id = 'cb-hl-toolbar';
        toolbarEl.setAttribute('role', 'toolbar');
        toolbarEl.setAttribute('aria-label', 'Grifar texto');
        document.body.appendChild(toolbarEl);
        // não deixa o clique na barra desmarcar o texto selecionado
        toolbarEl.addEventListener('mousedown', (e) => { if (!e.target.closest('textarea')) e.preventDefault(); });
        desenharToolbar();
    }
    function desenharToolbar() {
        toolbarEl.innerHTML = `
            ${favoritasHtml(null)}
            <div class="cb-hl-divider"></div>
            <button type="button" class="cb-hl-icon-btn${modoSublinhado ? ' cb-hl-icon-btn-ativo' : ''}" id="cb-hl-btn-sublinhar" title="${modoSublinhado ? 'Modo: sublinhar (clique para voltar a grifar)' : 'Sublinhar em vez de grifar'}" aria-label="Sublinhar">${ICON_UNDERLINE}</button>
            <button type="button" class="cb-hl-icon-btn" data-acao="negrito" title="Negrito" aria-label="Negrito">${ICON_BOLD}</button>
            <button type="button" class="cb-hl-icon-btn" data-acao="nota" title="Grifar e escrever uma nota" aria-label="Grifar com nota">${ICON_COMMENT}</button>
            <button type="button" class="cb-hl-apagar" data-acao="apagar" hidden title="Apagar o grifo desta seleção"><span class="cb-hl-apagar-ic">${ICON_TRASH}</span><span class="cb-hl-apagar-tx">Apagar</span></button>
            ${paletaHtml(null)}`;
        toolbarEl.querySelectorAll('.cb-hl-fav .cb-hl-cor, .cb-hl-paleta .cb-hl-cor').forEach((b) => b.addEventListener('click', () => grifarSelecaoAtual(b.dataset.cor)));
        toolbarEl.querySelector('[data-acao="mais"]').addEventListener('click', () => alternarPaleta(toolbarEl));
        toolbarEl.querySelector('#cb-hl-btn-sublinhar').addEventListener('click', () => { modoSublinhado = !modoSublinhado; desenharToolbar(); atualizarApagar(); });
        toolbarEl.querySelector('[data-acao="negrito"]').addEventListener('click', negritarSelecaoAtual);
        toolbarEl.querySelector('[data-acao="nota"]').addEventListener('click', () => grifarSelecaoAtual(ultimaCor, true));
        toolbarEl.querySelector('[data-acao="apagar"]').addEventListener('click', () => { const ids = idsNaSelecao.slice(); window.getSelection().removeAllRanges(); esconderToolbar(); apagarVarios(ids); });
        ligarNomesDaPaleta(toolbarEl);
    }
    function atualizarApagar() {
        const b = toolbarEl && toolbarEl.querySelector('[data-acao="apagar"]');
        if (!b) return;
        b.hidden = idsNaSelecao.length === 0;
        b.querySelector('.cb-hl-apagar-tx').textContent = idsNaSelecao.length > 1 ? `Apagar ${idsNaSelecao.length}` : 'Apagar';
        // o "N" fica aceso quando a seleção já tem negrito (clicar de novo tira)
        const nb = toolbarEl.querySelector('[data-acao="negrito"]');
        if (nb) {
            const tem = idsNaSelecao.some((id) => tipoDoGrifoNaPagina(id) === 'negrito');
            nb.classList.toggle('cb-hl-icon-btn-ativo', tem);
            nb.title = tem ? 'Tirar o negrito' : 'Negrito';
        }
    }

    function mostrarToolbarNaSelecao() {
        const sel = window.getSelection();
        if (!sel || sel.isCollapsed || sel.rangeCount === 0) { esconderToolbar(); return; }
        const texto = sel.toString().trim();
        if (!texto) { esconderToolbar(); return; }

        ultimaRangeSelecionada = sel.getRangeAt(0).cloneRange();
        if (ehElementoDaExtensao(ultimaRangeSelecionada.commonAncestorContainer.nodeType === 1 ? ultimaRangeSelecionada.commonAncestorContainer : ultimaRangeSelecionada.commonAncestorContainer.parentElement)) { esconderToolbar(); return; }
        const rect = ultimaRangeSelecionada.getBoundingClientRect();
        if (!rect || (rect.width === 0 && rect.height === 0)) { esconderToolbar(); return; }

        idsNaSelecao = Array.from(idsDeGrifosNoRange(ultimaRangeSelecionada));
        atualizarApagar();
        const pal = toolbarEl.querySelector('.cb-hl-paleta');
        if (pal) pal.hidden = true;

        toolbarEl.classList.add('cb-hl-medindo');
        const w = toolbarEl.offsetWidth, h = toolbarEl.offsetHeight;
        toolbarEl.classList.remove('cb-hl-medindo');
        const larg = document.documentElement.clientWidth;
        let left = rect.left + window.scrollX + rect.width / 2 - w / 2;
        left = Math.min(Math.max(window.scrollX + 8, left), window.scrollX + larg - w - 8);
        let top = rect.top + window.scrollY - h - 12;
        let abaixo = false;
        if (top < window.scrollY + 8) { top = rect.bottom + window.scrollY + 12; abaixo = true; }
        toolbarEl.style.top = top + 'px';
        toolbarEl.style.left = left + 'px';
        toolbarEl.classList.toggle('cb-hl-abaixo', abaixo);
        toolbarEl.classList.add('cb-hl-visible');
    }
    function esconderToolbar() {
        if (toolbarEl) toolbarEl.classList.remove('cb-hl-visible');
    }

    // Cria um ou vários grifos de uma vez. itens = [{ range, cor, tipo, bloco }]. Pinta tudo no DOM e grava uma vez só.
    // Grifos da MESMA camada (cor ou negrito) que ficariam INTEIROS dentro de um novo seriam um dentro do outro (e o de baixo viraria
    // um "fantasma" difícil de apagar): o novo substitui esses.
    async function criarGrifos(itens) {
        const marcasAntes = Array.from(document.querySelectorAll('mark.cb-hl-mark[data-cb-hl-id]'));
        const substituir = new Set();
        itens.forEach((it) => {
            const camada = camadaDoTipo(it.tipo);
            idsDeGrifosNoRange(it.range, marcasAntes).forEach((id) => {
                if (camadaDoTipo(tipoDoGrifoNaPagina(id)) === camada && grifoInteiroDentro(id, it.range)) substituir.add(id);
            });
        });
        const idsSubstituidos = Array.from(substituir);
        idsSubstituidos.forEach(removerMarcasDoDom);

        const agora = Date.now();
        const criados = [];
        itens.forEach((it) => {
            const texto = it.range.toString();
            if (!texto.trim()) return;
            const pos = serializarSelecao(it.range);
            const ctx = capturarContextoGrifo(it.range);
            const id = 'hl_' + agora + '_' + Math.random().toString(36).slice(2, 7) + criados.length;
            const marks = pintarRange(it.range.cloneRange(), it.cor, id, it.tipo, it.bloco);
            const grifo = {
                id, cor: it.cor, tipo: it.tipo, texto: texto.slice(0, 1500), nota: '', pos,
                contextoPrefixo: ctx.contextoPrefixo, contextoSufixo: ctx.contextoSufixo,
                url: location.href, titulo: document.title, criadoEm: agora
            };
            if (it.bloco) grifo.bloco = true;
            criados.push({ id, marks, grifo });
        });

        await naFila(async () => {
            const lista = await carregarGrifos();
            const fora = new Set(idsSubstituidos);
            const nova = lista.filter((g) => !fora.has(g.id));
            criados.forEach((c) => nova.push(c.grifo));
            await salvarGrifos(nova);
            atualizarPainel(nova);
        });
        if (criados.length) empilhar({ tipo: 'criouVarios', ids: criados.map((c) => c.id) });
        return criados;
    }

    async function grifarSelecaoAtual(cor, abrirNotaDepois) {
        if (!ultimaRangeSelecionada) return;
        const range = ultimaRangeSelecionada;
        lembrarCor(cor);
        const tipo = modoSublinhado ? 'sublinhado' : 'grifo';
        const criados = await criarGrifos([{ range, cor, tipo }]);

        window.getSelection().removeAllRanges();
        esconderToolbar();
        desenharToolbar();

        if (abrirNotaDepois && criados[0] && criados[0].marks[0]) {
            abrirBarra(criados[0].marks[0], criados[0].id, /* focarNota */ true);
        }
    }

    // "N" da barra de seleção: deixa a seleção em negrito (e tira, se já estiver). Sem cor: só o peso da fonte.
    async function negritarSelecaoAtual() {
        if (!ultimaRangeSelecionada) return;
        const range = ultimaRangeSelecionada;
        const jaNegrito = Array.from(idsDeGrifosNoRange(range)).filter((id) => tipoDoGrifoNaPagina(id) === 'negrito');
        window.getSelection().removeAllRanges();
        esconderToolbar();
        if (jaNegrito.length) { await apagarVarios(jaNegrito, { rotulo: 'Negrito removido' }); return; }
        await criarGrifos([{ range, cor: ultimaCor, tipo: 'negrito' }]);
        desenharToolbar();
    }

    // -------------------- Barra sobre um grifo existente --------------------
    function criarBarra() {
        barraEl = document.createElement('div');
        barraEl.id = 'cb-hl-barra';
        barraEl.className = 'cb-hl-barra';
        barraEl.setAttribute('role', 'toolbar');
        barraEl.setAttribute('aria-label', 'Editar grifo');
        document.body.appendChild(barraEl);
    }

    // Barra de um grifo de COR: cores, negrito, nota, copiar, apagar. Barra de um grifo de NEGRITO: só a etiqueta, nota, copiar, apagar.
    function montarBarraHtml(corAtual, tipo, temNegrito) {
        const ehNegrito = tipo === 'negrito';
        return `
            <div class="cb-hl-barra-row">
                ${ehNegrito ? `<span class="cb-hl-chip-negrito">${ICON_BOLD}<span>Negrito</span></span>` : favoritasHtml(corAtual)}
                <div class="cb-hl-divider"></div>
                ${ehNegrito ? '' : `<button type="button" class="cb-hl-icon-btn${temNegrito ? ' cb-hl-icon-btn-ativo' : ''}" data-acao="negritar" title="${temNegrito ? 'Tirar o negrito deste trecho' : 'Deixar este trecho em negrito'}" aria-label="Negrito">${ICON_BOLD}</button>`}
                <button type="button" class="cb-hl-icon-btn" data-acao="comentar" title="Nota" aria-label="Nota">${ICON_COMMENT}</button>
                <button type="button" class="cb-hl-icon-btn" data-acao="copiar" title="Copiar" aria-label="Copiar">${ICON_COPY}</button>
                <button type="button" class="cb-hl-apagar" data-acao="excluir" title="Apagar este grifo (Delete)"><span class="cb-hl-apagar-ic">${ICON_TRASH}</span><span class="cb-hl-apagar-tx">Apagar</span></button>
            </div>
            ${ehNegrito ? '' : paletaHtml(corAtual)}
            <div class="cb-hl-barra-nota" style="display:none;">
                <textarea placeholder="Escreva uma nota..."></textarea>
                <button type="button" class="cb-hl-btn-save">Salvar nota</button>
            </div>
        `;
    }

    async function abrirBarra(markEl, id, focarNota) {
        activeMarkId = id;
        const lista = await carregarGrifos();
        const grifo = lista.find(g => g.id === id);
        const marcasDoGrifo = Array.from(document.querySelectorAll(`mark[data-cb-hl-id="${id}"]`));
        const rangeDoGrifo = marcasDoGrifo.length ? rangeDeConteudo(marcasDoGrifo[0], marcasDoGrifo[marcasDoGrifo.length - 1]) : null;
        const negritosNoGrifo = rangeDoGrifo ? Array.from(idsDeGrifosNoRange(rangeDoGrifo)).filter((x) => tipoDoGrifoNaPagina(x) === 'negrito') : [];
        barraEl.innerHTML = montarBarraHtml(grifo && grifo.cor, grifo && grifo.tipo, negritosNoGrifo.length > 0);
        const textarea = barraEl.querySelector('textarea');
        if (grifo) textarea.value = grifo.nota || '';

        barraEl.querySelectorAll('.cb-hl-fav .cb-hl-cor, .cb-hl-paleta .cb-hl-cor').forEach((sw) => {
            sw.addEventListener('click', () => {
                const cor = sw.dataset.cor;
                const tipo = (grifo && grifo.tipo) || 'grifo';
                document.querySelectorAll(`mark[data-cb-hl-id="${id}"]`).forEach(m => aplicarEstiloMark(m, cor, tipo));
                atualizarGrifo(id, { cor });
                lembrarCor(cor);
                barraEl.querySelectorAll('.cb-hl-cor').forEach((b) => b.classList.toggle('cb-hl-cor--sel', b.dataset.cor.toLowerCase() === cor.toLowerCase()));
            });
        });
        const btnMais = barraEl.querySelector('[data-acao="mais"]');
        if (btnMais) btnMais.addEventListener('click', () => alternarPaleta(barraEl));
        ligarNomesDaPaleta(barraEl);
        const btnNegritar = barraEl.querySelector('[data-acao="negritar"]');
        if (btnNegritar) btnNegritar.addEventListener('click', () => {
            fecharBarra();
            if (negritosNoGrifo.length) apagarVarios(negritosNoGrifo, { rotulo: 'Negrito removido' });
            else if (rangeDoGrifo) criarGrifos([{ range: rangeDoGrifo, cor: ultimaCor, tipo: 'negrito' }]);
        });
        barraEl.querySelector('[data-acao="comentar"]').addEventListener('click', () => {
            const notaBox = barraEl.querySelector('.cb-hl-barra-nota');
            const abrir = notaBox.style.display === 'none';
            notaBox.style.display = abrir ? 'block' : 'none';
            if (abrir) textarea.focus();
        });
        barraEl.querySelector('[data-acao="copiar"]').addEventListener('click', () => copiarGrifo(grifo));
        barraEl.querySelector('[data-acao="excluir"]').addEventListener('click', () => { fecharBarra(); apagarGrifo(id); });
        barraEl.querySelector('.cb-hl-btn-save').addEventListener('click', () => {
            atualizarGrifo(id, { nota: textarea.value });
            fecharBarra();
        });

        const rect = markEl.getBoundingClientRect();
        barraEl.classList.add('cb-hl-medindo');
        const w = barraEl.offsetWidth;
        barraEl.classList.remove('cb-hl-medindo');
        const larg = document.documentElement.clientWidth;
        barraEl.style.top = (rect.bottom + window.scrollY + 10) + 'px';
        barraEl.style.left = Math.min(Math.max(window.scrollX + 8, rect.left + window.scrollX), window.scrollX + larg - w - 8) + 'px';
        barraEl.classList.add('cb-hl-visible');

        if (focarNota) {
            barraEl.querySelector('.cb-hl-barra-nota').style.display = 'block';
            textarea.focus();
        }
    }
    function fecharBarra() {
        if (barraEl) barraEl.classList.remove('cb-hl-visible');
        activeMarkId = null;
    }

    function copiarGrifo(grifo) {
        if (!grifo) return;
        const texto = `"${grifo.texto}"${grifo.nota ? '\n📝 ' + grifo.nota : ''}\n— ${grifo.titulo}\n${grifo.url}`;
        navigator.clipboard.writeText(texto).then(() => {
            mostrarToastCopiado();
        }).catch(() => {});
    }

    // -------------------- Painel de índice (cartões) --------------------
    let confirmandoApagarTodos = null;
    function criarPainel() {
        panelToggleEl = document.createElement('div');
        panelToggleEl.id = 'cb-hl-panel-toggle';
        panelToggleEl.innerHTML = ICON_MARCADOR;
        panelToggleEl.title = 'Meus grifos nesta página';
        panelToggleEl.addEventListener('click', () => panelEl.classList.toggle('cb-hl-open'));
        document.body.appendChild(panelToggleEl);

        panelEl = document.createElement('div');
        panelEl.id = 'cb-hl-panel';
        panelEl.innerHTML = `
            <div class="cb-hl-panel-header">
                <h3>Grifos desta página <span class="cb-hl-panel-n" hidden></span></h3>
                <div class="cb-hl-panel-acoes">
                    <button type="button" class="cb-hl-panel-limpar" hidden title="Apagar todos os grifos desta página">Apagar todos</button>
                    <button type="button" class="cb-hl-panel-allpages" title="Ver todas as páginas">${ICON_LIST}<span>Todas</span></button>
                </div>
            </div>
            <div class="cb-hl-panel-list"></div>
        `;
        document.body.appendChild(panelEl);

        panelEl.querySelector('.cb-hl-panel-allpages').addEventListener('click', () => {
            window.open(chrome.runtime.getURL('paginas.html'), '_blank');
        });
        // dois toques para apagar tudo (o primeiro pede confirmação), com desfazer depois
        panelEl.querySelector('.cb-hl-panel-limpar').addEventListener('click', async (e) => {
            const btn = e.currentTarget;
            if (!confirmandoApagarTodos) {
                btn.textContent = 'Confirmar?';
                btn.classList.add('cb-hl-panel-limpar--sim');
                confirmandoApagarTodos = setTimeout(() => { confirmandoApagarTodos = null; btn.textContent = 'Apagar todos'; btn.classList.remove('cb-hl-panel-limpar--sim'); }, 3500);
                return;
            }
            clearTimeout(confirmandoApagarTodos); confirmandoApagarTodos = null;
            btn.textContent = 'Apagar todos'; btn.classList.remove('cb-hl-panel-limpar--sim');
            const lista = await carregarGrifos();
            apagarVarios(lista.map((g) => g.id));
        });
    }

    function tempoRelativo(ts) {
        const diffMs = Date.now() - ts;
        const min = Math.floor(diffMs / 60000);
        if (min < 1) return 'agora';
        if (min < 60) return `há ${min} min`;
        const h = Math.floor(min / 60);
        if (h < 24) return `há ${h}h`;
        const d = Math.floor(h / 24);
        return `há ${d}d`;
    }

    function atualizarPainel(lista) {
        if (!panelEl) return;
        const container = panelEl.querySelector('.cb-hl-panel-list');
        const n = panelEl.querySelector('.cb-hl-panel-n');
        const limpar = panelEl.querySelector('.cb-hl-panel-limpar');
        n.textContent = String(lista.length); n.hidden = !lista.length;
        limpar.hidden = !lista.length;
        if (!lista.length) {
            container.innerHTML = '<div class="cb-hl-panel-empty">Nenhum grifo ainda. Selecione um texto para começar.</div>';
            return;
        }
        container.innerHTML = '';
        lista
            .slice()
            .sort((a, b) => b.criadoEm - a.criadoEm)
            .forEach((g) => {
                const item = document.createElement('div');
                item.className = 'cb-hl-card';
                const ehNegrito = g.tipo === 'negrito';
                item.style.setProperty('--c', ehNegrito ? '#8e8e93' : g.cor);
                item.innerHTML = `
                    <div class="cb-hl-card-top">
                        ${ehNegrito
                            ? '<span class="cb-hl-card-dot cb-hl-card-dot--n" title="Negrito">N</span>'
                            : `<span class="cb-hl-card-dot" style="background:${g.cor}" title="${(corPorHex(g.cor) || {}).nome || ''}"></span>`}
                        <span class="cb-hl-card-time">${tempoRelativo(g.criadoEm)}</span>
                        ${g.tipo === 'sublinhado' ? '<span class="cb-hl-card-tipo">sublinhado</span>' : ''}
                        ${ehNegrito ? '<span class="cb-hl-card-tipo">negrito</span>' : ''}
                    </div>
                    <div class="cb-hl-card-text">${escapeHtml(g.texto).slice(0, 160)}${g.texto.length > 160 ? '…' : ''}</div>
                    ${g.nota ? `<div class="cb-hl-card-nota">📝 ${escapeHtml(g.nota)}</div>` : ''}
                    <div class="cb-hl-card-actions">
                        <button type="button" class="cb-hl-icon-btn" data-acao="comentar" title="Editar nota" aria-label="Editar nota">${ICON_COMMENT}</button>
                        <button type="button" class="cb-hl-icon-btn" data-acao="copiar" title="Copiar" aria-label="Copiar">${ICON_COPY}</button>
                        <button type="button" class="cb-hl-icon-btn cb-hl-icon-danger" data-acao="excluir" title="Apagar" aria-label="Apagar">${ICON_TRASH}</button>
                    </div>
                `;
                item.querySelector('.cb-hl-card-text').addEventListener('click', () => {
                    const markEl = document.querySelector(`mark[data-cb-hl-id="${g.id}"]`);
                    if (markEl) {
                        markEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        markEl.style.filter = 'brightness(1.4)';
                        setTimeout(() => { markEl.style.filter = ''; }, 900);
                    }
                });
                item.querySelector('[data-acao="comentar"]').addEventListener('click', () => {
                    const novaNota = prompt('Nota:', g.nota || '');
                    if (novaNota !== null) atualizarGrifo(g.id, { nota: novaNota });
                });
                item.querySelector('[data-acao="copiar"]').addEventListener('click', () => copiarGrifo(g));
                item.querySelector('[data-acao="excluir"]').addEventListener('click', () => apagarGrifo(g.id));
                container.appendChild(item);
            });
    }

    function escapeHtml(str) {
        const div = document.createElement('div');
        div.textContent = str || '';
        return div.innerHTML;
    }

    // -------------------- Captura rápida (estilo Cubox) --------------------
    // Ligada pelo botão do dock ou pela tecla G. Enquanto está ligada:
    //   • passar o mouse destaca o parágrafo sob o cursor;
    //   • clicar marca o parágrafo inteiro com a caneta atual (cor, sublinhado ou negrito); clicar de novo tira;
    //   • apertar num parágrafo e ARRASTAR para outros marca todos de uma vez (arrastar sobre parágrafos que já têm a marca apaga);
    //   • Shift+clique marca do último parágrafo clicado até este; Ctrl/Alt+clique voltam ao comportamento normal da página
    //     (seguir link / selecionar texto); selecionar palavras dentro de UM parágrafo continua abrindo a barra de seleção.
    // Nada é inserido na página: o destaque do parágrafo é só uma classe, e cada marca é um grifo comum com `bloco: true`.
    const SEL_BLOCO = 'p, li, h1, h2, h3, h4, h5, h6, blockquote, dt, dd, pre, td, th';
    let capAtivo = false;
    let capPen = 'cor';          // 'cor' (usa ultimaCor + sublinhado, se ligado) ou 'negrito'
    let capBarraEl = null;
    let capBotaoEl = null;
    let capHoverEl = null;
    let capGesto = null;
    let capUltimoBloco = null;   // âncora do Shift+clique
    let capPendente = null;      // { bloco, acao, cls, timer }: clique simples esperando a janela do duplo clique
    let capSuprimirClick = false;
    let capRaf = 0;

    const tipoDaCaneta = () => (capPen === 'negrito' ? 'negrito' : (modoSublinhado ? 'sublinhado' : 'grifo'));

    // o "bloco" sob um elemento: o parágrafo/item mais interno que contém texto (e nenhum outro bloco dentro)
    function blocoDe(alvo) {
        const el = alvo && (alvo.nodeType === 1 ? alvo : alvo.parentElement);
        if (!el || !el.closest || ehElementoDaExtensao(el)) return null;
        const bloco = el.closest(SEL_BLOCO);
        if (!bloco || ehElementoDaExtensao(bloco)) return null;
        // dentro do Modo de Leitura só vale o texto da lei, não os botões e painéis dele
        if (bloco.closest('#cb-reading-mode-overlay') && !bloco.closest('#cb-rm-content')) return null;
        if (bloco.querySelector(SEL_BLOCO)) return null;              // só blocos "folha"
        const t = bloco.textContent;
        if (!/\S/.test(t) || t.length > 8000) return null;            // parágrafo vazio (só &nbsp;) ou "bloco" que é a página toda
        return bloco;
    }
    function capBlocosDoDocumento() {
        const lista = [];
        document.body.querySelectorAll(SEL_BLOCO).forEach((b) => { if (blocoDe(b)) lista.push(b); });
        return lista;
    }

    // primeiro/último texto "de verdade" (ignora espaços e a interface da extensão) e o Range que vai de um ao outro
    function textosDe(raiz) {
        return document.createTreeWalker(raiz, NodeFilter.SHOW_TEXT, {
            acceptNode: (n) => {
                const p = n.parentElement;
                if (!p || p.closest('script, style, noscript') || ehElementoDaExtensao(p)) return NodeFilter.FILTER_REJECT;
                return /\S/.test(n.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
            }
        });
    }
    function primeiroTexto(raiz) { return textosDe(raiz).nextNode(); }
    function ultimoTexto(raiz) {
        const w = textosDe(raiz);
        let n, ult = null;
        while ((n = w.nextNode())) ult = n;
        return ult;
    }
    function rangeDeConteudo(raizIni, raizFim) {
        const ini = primeiroTexto(raizIni);
        const fim = ultimoTexto(raizFim || raizIni);
        if (!ini || !fim) return null;
        const r = document.createRange();
        r.setStart(ini, Math.max(0, ini.nodeValue.search(/\S/)));
        const v = fim.nodeValue;
        let e = v.length;
        while (e > 0 && /\s/.test(v[e - 1])) e--;
        r.setEnd(fim, e);
        return r;
    }

    // grifos de captura (parágrafo inteiro) de uma camada dentro de um bloco
    function marcasDeBloco(b, camada) {
        return Array.from(b.querySelectorAll('mark.cb-hl-mark[data-cb-hl-bloco]')).filter((m) => camadaDoTipo(m.dataset.cbHlTipo) === camada);
    }
    // o que um clique neste bloco faz: tira, se já tem exatamente esta marca; senão marca (e troca a cor, se tinha outra)
    function acaoPara(b) {
        const tipo = tipoDaCaneta();
        const camada = camadaDoTipo(tipo);
        const ms = marcasDeBloco(b, camada);
        if (!ms.length) return 'pintar';
        if (camada === 'negrito') return 'apagar';
        const cor = String(ultimaCor).toLowerCase();
        const igual = ms.some((m) => m.dataset.cbHlTipo === tipo && String(m.style.getPropertyValue('--cb-hl-cor')).trim().toLowerCase() === cor);
        return igual ? 'apagar' : 'pintar';
    }

    async function capAplicar(blocos, acao) {
        if (!blocos.length) return;
        const tipo = tipoDaCaneta();
        const camada = camadaDoTipo(tipo);
        if (acao === 'apagar') {
            const ids = new Set();
            blocos.forEach((b) => marcasDeBloco(b, camada).forEach((m) => ids.add(m.dataset.cbHlId)));
            if (!ids.size) return;
            await apagarVarios(Array.from(ids), blocos.length === 1 ? { semAviso: true } : { rotulo: camada === 'negrito' ? 'Negrito removido' : undefined });
            return;
        }
        const itens = [];
        blocos.forEach((b) => {
            const r = rangeDeConteudo(b);
            if (r) itens.push({ range: r, cor: ultimaCor, tipo, bloco: true });
        });
        const criados = await criarGrifos(itens);
        if (criados.length > 1) {
            const ids = criados.map((c) => c.id);
            mostrarAviso(`${criados.length} parágrafos marcados`, 'Desfazer', () => desfazerCriacao(ids));
        }
    }

    // ---- destaque do parágrafo sob o mouse ----
    function capDestacar(b) {
        if (b === capHoverEl) return;
        if (capHoverEl) capHoverEl.classList.remove('cb-cap-alvo');
        capHoverEl = b || null;
        if (capHoverEl) capHoverEl.classList.add('cb-cap-alvo');
    }

    // ---- gesto de arrastar por vários parágrafos ----
    // índice do bloco que está na altura y (o último cujo topo já passou): só a posição vertical importa, então o cursor pode
    // sair para a margem sem perder o parágrafo
    function capIndiceNoY(y, partida) {
        const bl = capGesto.blocos;
        let i = Math.min(Math.max(partida, 0), bl.length - 1);
        while (i > 0 && y < bl[i].getBoundingClientRect().top) i--;
        while (i < bl.length - 1 && y >= bl[i + 1].getBoundingClientRect().top) i++;
        return i;
    }
    function capAtualizarArrasto() {
        const g = capGesto;
        if (!g || !g.arrastando) return;
        g.i1 = capIndiceNoY(g.y, g.i1);
        const a = Math.min(g.i0, g.i1), b = Math.max(g.i0, g.i1);
        if (a === g.ta && b === g.tb) return;
        const cls = g.acao === 'apagar' ? 'cb-cap-sel-apagar' : 'cb-cap-sel';
        for (let i = g.ta; i <= g.tb; i++) if (i < a || i > b) g.blocos[i].classList.remove(cls);
        for (let i = a; i <= b; i++) g.blocos[i].classList.add(cls);
        g.ta = a; g.tb = b;
    }
    function capLimparArrasto(g) {
        if (!g || !g.blocos) return;
        for (let i = g.ta; i <= g.tb; i++) g.blocos[i] && g.blocos[i].classList.remove('cb-cap-sel', 'cb-cap-sel-apagar');
    }
    function capCancelarGesto() {
        cancelAnimationFrame(capRaf);
        capLimparArrasto(capGesto);
        capGesto = null;
        document.body.classList.remove('cb-cap-arrastando');
    }
    // quem rola: a janela, ou (no Modo de Leitura) a caixa com rolagem própria
    function scrollPaiDe(el) {
        for (let p = el.parentElement; p && p !== document.body && p !== document.documentElement; p = p.parentElement) {
            const oy = getComputedStyle(p).overflowY;
            if ((oy === 'auto' || oy === 'scroll') && p.scrollHeight > p.clientHeight + 1) return p;
        }
        return null;
    }
    // rola sozinho quando o cursor chega perto da borda de cima ou de baixo, para marcar "muitos parágrafos" sem soltar o botão
    function capAutoRolar() {
        cancelAnimationFrame(capRaf);
        const passo = () => {
            const g = capGesto;
            if (!g || !g.arrastando) return;
            const area = g.scroller ? g.scroller.getBoundingClientRect() : { top: 0, bottom: window.innerHeight };
            const zona = 80;
            let dy = 0;
            if (g.y < area.top + zona) dy = -Math.ceil((area.top + zona - g.y) / zona * 22 + 2);
            else if (g.y > area.bottom - zona) dy = Math.ceil((g.y - (area.bottom - zona)) / zona * 22 + 2);
            if (dy) {
                if (g.scroller) g.scroller.scrollTop += dy; else window.scrollBy(0, dy);
                capAtualizarArrasto();
            }
            capRaf = requestAnimationFrame(passo);
        };
        capRaf = requestAnimationFrame(passo);
    }

    function capMouseDown(e) {
        if (!capAtivo || e.button !== 0 || e.ctrlKey || e.metaKey || e.altKey) return;
        const b = blocoDe(e.target);
        if (!b) return;
        // Duplo clique = selecionar uma palavra. O clique simples só marca depois de uma espera curta (capPendente): se vier o segundo
        // clique, a marcação é cancelada e nada foi pintado (pintar e desfazer mexeria no texto e faria a seleção sumir).
        // Qualquer outro clique antes do fim da espera confirma o anterior na hora.
        const duplo = e.detail >= 2;
        if (capPendente) { if (duplo) capCancelarPendente(); else capConfirmarPendente(); }
        capGesto = { inicio: b, x0: e.clientX, y0: e.clientY, x: e.clientX, y: e.clientY, arrastando: false, blocos: null, i0: -1, i1: -1, ta: 0, tb: -1, acao: acaoPara(b), shift: e.shiftKey, semToggle: duplo, scroller: null };
        if (e.shiftKey) e.preventDefault();   // Shift+clique não pode estender a seleção nativa
    }
    function capMouseMove(e) {
        if (!capAtivo) return;
        const g = capGesto;
        if (!g) { capDestacar(blocoDe(e.target)); return; }
        if (!(e.buttons & 1)) { capCancelarGesto(); return; }   // soltou o botão fora da janela
        g.x = e.clientX; g.y = e.clientY;
        if (!g.arrastando) {
            if (g.semToggle || g.shift) return;
            // só vira "arrastar por vários" ao sair do parágrafo de origem (para outro bloco, ou acima/abaixo dele);
            // enquanto o cursor fica nele, continua sendo uma seleção de texto normal
            const r = g.inicio.getBoundingClientRect();
            const b = blocoDe(e.target);
            const saiu = (b && b !== g.inicio) || e.clientY < r.top || e.clientY > r.bottom;
            if (!saiu || Math.hypot(e.clientX - g.x0, e.clientY - g.y0) < 5) return;
            g.blocos = capBlocosDoDocumento();
            g.i0 = g.blocos.indexOf(g.inicio);
            if (g.i0 < 0) { capCancelarGesto(); return; }
            g.i1 = g.i0;
            g.arrastando = true;
            g.scroller = scrollPaiDe(g.inicio);
            capDestacar(null);
            const sel = window.getSelection();
            if (sel) sel.removeAllRanges();
            document.body.classList.add('cb-cap-arrastando');
            capAutoRolar();
        }
        capAtualizarArrasto();
    }
    async function capMouseUp(e) {
        const g = capGesto;
        if (!capAtivo || !g) return;
        if (e.button !== 0) { capCancelarGesto(); return; }
        if (g.arrastando) {
            const a = Math.min(g.i0, g.i1), b = Math.max(g.i0, g.i1);
            const blocos = g.blocos.slice(a, b + 1);
            capCancelarGesto();
            capSuprimirClick = true;
            setTimeout(() => { capSuprimirClick = false; }, 150);
            capUltimoBloco = blocos[blocos.length - 1];
            await capAplicar(blocos, g.acao);
            return;
        }
        capCancelarGesto();
        if (g.semToggle) return;
        // selecionou texto dentro do parágrafo (ou arrastou um pouco): deixa para a barra de seleção
        const sel = window.getSelection();
        if (sel && !sel.isCollapsed && sel.toString().trim()) return;
        if (Math.hypot(e.clientX - g.x0, e.clientY - g.y0) > 6) return;
        let blocos = [g.inicio];
        let imediato = false;
        if (g.shift && capUltimoBloco && capUltimoBloco !== g.inicio && document.contains(capUltimoBloco)) {
            const todos = capBlocosDoDocumento();
            const i = todos.indexOf(capUltimoBloco), j = todos.indexOf(g.inicio);
            if (i >= 0 && j >= 0) { blocos = todos.slice(Math.min(i, j), Math.max(i, j) + 1); imediato = true; }
        }
        capUltimoBloco = g.inicio;
        if (imediato) { await capAplicar(blocos, g.acao); return; }
        // clique simples: mostra já o "vai marcar" e confirma depois da espera do duplo clique
        const cls = g.acao === 'apagar' ? 'cb-cap-sel-apagar' : 'cb-cap-sel';
        g.inicio.classList.add(cls);
        capPendente = { bloco: g.inicio, acao: g.acao, cls, timer: setTimeout(capConfirmarPendente, 220) };
    }
    function capCancelarPendente() {
        if (!capPendente) return;
        clearTimeout(capPendente.timer);
        capPendente.bloco.classList.remove(capPendente.cls);
        capPendente = null;
    }
    function capConfirmarPendente() {
        const p = capPendente;
        if (!p) return;
        clearTimeout(p.timer);
        capPendente = null;
        p.bloco.classList.remove(p.cls);
        capAplicar([p.bloco], p.acao);
    }
    // o clique que o navegador dispara depois do mouseup não pode seguir link nem abrir nada da página
    function capClick(e) {
        if (!capAtivo || e.ctrlKey || e.metaKey || e.altKey) return;
        if (capSuprimirClick || blocoDe(e.target)) { e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); }
    }

    // ---- ligar / desligar e a barra da captura ----
    function alternarCaptura() { if (capAtivo) capDesativar(); else capAtivar(); }
    function capAtivar() {
        if (capAtivo || !capBarraEl) return;
        capAtivo = true;
        esconderToolbar();
        fecharBarra();
        document.body.classList.add('cb-cap-ativo');
        desenharBarraCaptura();
        capBarraEl.classList.add('cb-hl-visible');
        if (capBotaoEl) { capBotaoEl.classList.add('cb-cap-on'); capBotaoEl.setAttribute('aria-pressed', 'true'); }
    }
    function capDesativar() {
        if (!capAtivo) return;
        capAtivo = false;
        capConfirmarPendente();   // não perde o último clique se desligar logo em seguida
        capCancelarGesto();
        capDestacar(null);
        document.body.classList.remove('cb-cap-ativo');
        if (capBarraEl) capBarraEl.classList.remove('cb-hl-visible');
        if (capBotaoEl) { capBotaoEl.classList.remove('cb-cap-on'); capBotaoEl.setAttribute('aria-pressed', 'false'); }
    }
    function desenharBarraCaptura() {
        if (!capBarraEl) return;
        const negrito = capPen === 'negrito';
        const corAtual = negrito ? null : ultimaCor;
        capBarraEl.innerHTML = `
            <div class="cb-hl-barra-row">
                ${favoritasHtml(corAtual)}
                <div class="cb-hl-divider"></div>
                <button type="button" class="cb-hl-icon-btn${negrito ? ' cb-hl-icon-btn-ativo' : ''}" data-acao="cap-negrito" title="Caneta de negrito (N)" aria-label="Caneta de negrito" aria-pressed="${negrito}">${ICON_BOLD}</button>
                <button type="button" class="cb-hl-icon-btn${modoSublinhado ? ' cb-hl-icon-btn-ativo' : ''}" data-acao="cap-sublinhar" title="Sublinhar em vez de grifar (U)" aria-label="Sublinhar" aria-pressed="${modoSublinhado}">${ICON_UNDERLINE}</button>
                <button type="button" class="cb-hl-icon-btn" data-acao="cap-desfazer" title="Desfazer (Ctrl+Z)" aria-label="Desfazer">${ICON_UNDO}</button>
                <div class="cb-hl-divider"></div>
                <button type="button" class="cb-cap-sair" data-acao="cap-sair" title="Sair da captura rápida (Esc)">Concluir</button>
            </div>
            ${paletaHtml(corAtual)}
            <div class="cb-cap-dica">Clique num parágrafo para marcar · arraste para marcar vários · clique de novo para tirar</div>`;
        capBarraEl.querySelectorAll('.cb-hl-fav .cb-hl-cor, .cb-hl-paleta .cb-hl-cor').forEach((b) => b.addEventListener('click', () => {
            lembrarCor(b.dataset.cor);
            capPen = 'cor';
            desenharBarraCaptura();
        }));
        capBarraEl.querySelector('[data-acao="mais"]').addEventListener('click', () => alternarPaleta(capBarraEl));
        ligarNomesDaPaleta(capBarraEl);
        capBarraEl.querySelector('[data-acao="cap-negrito"]').addEventListener('click', () => { capPen = capPen === 'negrito' ? 'cor' : 'negrito'; desenharBarraCaptura(); });
        capBarraEl.querySelector('[data-acao="cap-sublinhar"]').addEventListener('click', () => { modoSublinhado = !modoSublinhado; capPen = 'cor'; desenharBarraCaptura(); });
        capBarraEl.querySelector('[data-acao="cap-desfazer"]').addEventListener('click', () => { if (pilhaDesfazer.length) desfazerUltimo(); else mostrarAviso('Nada para desfazer'); });
        capBarraEl.querySelector('[data-acao="cap-sair"]').addEventListener('click', capDesativar);
        if (toolbarEl) desenharToolbar();   // o "sublinhar" é compartilhado com a barra de seleção
    }
    function criarCaptura() {
        capBarraEl = document.createElement('div');
        capBarraEl.id = 'cb-cap-barra';
        capBarraEl.className = 'cb-hl-barra cb-cap-barra';
        capBarraEl.setAttribute('role', 'toolbar');
        capBarraEl.setAttribute('aria-label', 'Captura rápida de parágrafos');
        document.body.appendChild(capBarraEl);

        capBotaoEl = document.createElement('button');
        capBotaoEl.type = 'button';
        capBotaoEl.id = 'cb-cap-toggle';
        capBotaoEl.innerHTML = ICON_CAPTURA;
        capBotaoEl.title = 'Captura rápida: clique ou arraste sobre parágrafos para marcar (G)';
        capBotaoEl.setAttribute('aria-label', 'Captura rápida de parágrafos');
        capBotaoEl.setAttribute('aria-pressed', 'false');
        capBotaoEl.addEventListener('click', alternarCaptura);
        document.body.appendChild(capBotaoEl);

        document.addEventListener('mousedown', capMouseDown, true);
        document.addEventListener('mousemove', capMouseMove, true);
        document.addEventListener('mouseup', capMouseUp, true);
        document.addEventListener('click', capClick, true);
        document.addEventListener('dragstart', (e) => { if (capAtivo && blocoDe(e.target)) e.preventDefault(); }, true);
        document.documentElement.addEventListener('mouseleave', () => capDestacar(null));
        window.addEventListener('blur', capCancelarGesto);
    }

    // -------------------- Eventos globais --------------------
    document.addEventListener('mouseup', (e) => {
        if (toolbarEl && toolbarEl.contains(e.target)) return;
        if (barraEl && barraEl.contains(e.target)) return;
        setTimeout(mostrarToolbarNaSelecao, 0);
    });
    document.addEventListener('mousedown', (e) => {
        if (toolbarEl && !toolbarEl.contains(e.target)) esconderToolbar();
        if (barraEl && !barraEl.contains(e.target) && !(e.target.closest && e.target.closest('mark.cb-hl-mark'))) {
            fecharBarra();
        }
    });
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') { esconderToolbar(); fecharBarra(); if (capAtivo) capDesativar(); return; }
        // o alvo real pode estar dentro de um Shadow DOM (campo do painel "Artigos dos erros"): o alvo "retargetado" seria só o host
        const alvoReal = (e.composedPath && e.composedPath()[0]) || e.target;
        const emCampo = alvoReal && (alvoReal.isContentEditable || (alvoReal.closest && alvoReal.closest('input, textarea, select, [contenteditable="true"]')));
        // atalhos da captura rápida: G liga/desliga; dentro dela 1–6 trocam a cor, N liga o negrito, U o sublinhado
        if (!emCampo && !e.ctrlKey && !e.metaKey && !e.altKey && e.key && e.key.length === 1) {
            const k = e.key.toLowerCase();
            if (k === 'g') { e.preventDefault(); alternarCaptura(); return; }
            if (capAtivo) {
                if (k >= '1' && k <= '6') { e.preventDefault(); const c = favoritas()[Number(k) - 1]; if (c) { lembrarCor(c.hex); capPen = 'cor'; desenharBarraCaptura(); } return; }
                if (k === 'n') { e.preventDefault(); capPen = capPen === 'negrito' ? 'cor' : 'negrito'; desenharBarraCaptura(); return; }
                if (k === 'u') { e.preventDefault(); modoSublinhado = !modoSublinhado; capPen = 'cor'; desenharBarraCaptura(); return; }
            }
        }
        // Delete/Backspace com a barra de um grifo aberta apaga esse grifo
        if ((e.key === 'Delete' || e.key === 'Backspace') && !emCampo && activeMarkId && barraEl && barraEl.classList.contains('cb-hl-visible')) {
            e.preventDefault();
            const id = activeMarkId; fecharBarra(); apagarGrifo(id);
            return;
        }
        // Ctrl/Cmd+Z desfaz o último grifo criado ou apagado
        if ((e.ctrlKey || e.metaKey) && !e.shiftKey && (e.key === 'z' || e.key === 'Z') && !emCampo && pilhaDesfazer.length) {
            e.preventDefault();
            desfazerUltimo();
        }
    });

    // -------------------- Boot --------------------
    function iniciar() {
        try {
            chrome.storage.local.get(['cbHlUltimaCor'], (r) => {
                if (r && r.cbHlUltimaCor && corPorHex(r.cbHlUltimaCor)) { ultimaCor = r.cbHlUltimaCor; if (toolbarEl) desenharToolbar(); }
            });
        } catch (e) { /* sem storage */ }
        criarToolbar();
        criarBarra();
        criarPainel();
        criarCaptura();
        restaurarGrifos();
    }

    window.__cbHighlighterToggle = function () {
        if (!panelEl) return;
        panelEl.classList.toggle('cb-hl-open');
    };
    window.__cbCapturaToggle = function () { alternarCaptura(); };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', iniciar);
    } else {
        iniciar();
    }
})();
