// ============================================================================
// edicao-estudo.js — "Edição de estudo": outro layout para ler a lei no Planalto, no estilo de uma edição para concursos
// (papel creme, faixas verdes de Título, faixas bege de Capítulo, etiqueta cinza no artigo, texto serifado justificado)
// com seis tipos de informação marcados em cor e um quadro-resumo no fim: prazos, quóruns, exceções/vedações, datas,
// trechos alterados por emenda e percentuais. É uma opção SEPARADA do Modo de Leitura (que não é tocado).
//
// Como mexe na página sem estragar nada:
//   • o layout é CSS sobre classes que se ACRESCENTAM aos parágrafos (cb-ed-titulo, cb-ed-artigo...), e só quando ligado;
//   • as cores usam a API de realces do navegador (CSS.highlights): pintam o texto SEM criar nós novos, então o marcador de
//     texto do usuário (que guarda posições no documento) e o resto da extensão continuam funcionando;
//   • desligar remove classes e realces e devolve a página como estava.
// As regras de texto estão em edicao-estudo-regras.js (testadas em Node).
//
// Estado guardado em chrome.storage.local → cbEdicaoEstudo: { ativo, tema: 'papel'|'noite', cats: { prazo: true, ... } }
// ============================================================================
(function () {
    'use strict';
    if (window.__cbEdicaoEstudo) return;
    window.__cbEdicaoEstudo = true;

    const R = window.CBEdicaoRegras;
    if (!R) return;

    const SUPORTA_REALCE = !!(window.CSS && CSS.highlights && typeof Highlight !== 'undefined');
    const TIPOS_ESTRUTURA = new Set(['livro', 'titulo', 'capitulo', 'secao', 'subsecao', 'artigo', 'paragrafo', 'inciso', 'alinea', 'item']);
    const MIN_ARTIGOS_PARA_OFERECER = 3;
    const MAX_NO_QUADRO = 400;     // por categoria

    const ICON_LIVRO = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3h9l4 4v14H6z"/><path d="M15 3v4h4"/><line x1="9" y1="12" x2="16" y2="12"/><line x1="9" y1="16" x2="14" y2="16"/></svg>';
    const ICON_LISTA = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><circle cx="3.5" cy="6" r="1"/><circle cx="3.5" cy="12" r="1"/><circle cx="3.5" cy="18" r="1"/></svg>';
    const ICON_FECHAR = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
    const ICON_RECOLHER = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>';
    const ICON_LUA = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>';

    let estado = { ativo: false, tema: 'papel', cats: {} };
    R.ORDEM.forEach((c) => { estado.cats[c] = true; });
    let analise = null;               // { marcas: { cat: [{ art, trecho, range }] }, paragrafos: [...] }
    let analisando = false;
    let barra = null, quadro = null, botao = null;

    // ------------------------------------------------------------------ persistência
    function salvar() { try { chrome.storage.local.set({ cbEdicaoEstudo: estado }); } catch (e) { /* ignora */ } }
    function carregar() {
        return new Promise((res) => {
            try {
                chrome.storage.local.get(['cbEdicaoEstudo'], (r) => {
                    const s = r && r.cbEdicaoEstudo;
                    if (s) {
                        estado.ativo = !!s.ativo;
                        estado.tema = s.tema === 'noite' ? 'noite' : 'papel';
                        R.ORDEM.forEach((c) => { if (s.cats && typeof s.cats[c] === 'boolean') estado.cats[c] = s.cats[c]; });
                    }
                    res();
                });
            } catch (e) { res(); }
        });
    }

    // ------------------------------------------------------------------ texto dos parágrafos → posições
    const ehNossoOuIgnorado = (el) => !!(el.closest && el.closest('script, style, noscript, textarea, [id^="cb-"], .cb-hl-barra'));

    function paragrafos() {
        return Array.from(document.querySelectorAll('p')).filter((p) => !ehNossoOuIgnorado(p));
    }

    // concatena os textos do parágrafo (sem o que está riscado — texto revogado fica de fora das marcas) e guarda de onde
    // cada pedaço veio, para transformar posições do texto em Range
    function textoComMapa(p) {
        const segs = [];
        let full = '';
        const w = document.createTreeWalker(p, NodeFilter.SHOW_TEXT, {
            acceptNode(n) {
                if (!n.nodeValue) return NodeFilter.FILTER_REJECT;
                const pai = n.parentElement;
                if (!pai || pai.closest('strike, s, del, script, style')) return NodeFilter.FILTER_REJECT;
                return NodeFilter.FILTER_ACCEPT;
            },
        });
        let n;
        while ((n = w.nextNode())) {
            segs.push({ node: n, ini: full.length, fim: full.length + n.nodeValue.length });
            full += n.nodeValue;
        }
        return { full, segs };
    }
    function rangeDe(segs, ini, fim) {
        const a = segs.find((s) => ini >= s.ini && ini < s.fim);
        const b = segs.find((s) => fim > s.ini && fim <= s.fim);
        if (!a || !b) return null;
        const r = document.createRange();
        r.setStart(a.node, ini - a.ini);
        r.setEnd(b.node, fim - b.ini);
        return r;
    }

    // ------------------------------------------------------------------ análise (uma vez por página)
    const cedo = () => new Promise((r) => setTimeout(r, 0));
    async function analisar() {
        if (analise || analisando) return;
        analisando = true;
        const marcas = {};
        R.ORDEM.forEach((c) => { marcas[c] = []; });
        const rotulosPar = [];
        const rotulosArt = [];
        const lista = paragrafos();
        let artigoAtual = '';
        let cabecalhoAnterior = null;      // { p, tipo } do parágrafo imediatamente anterior, se for um cabeçalho
        let iniciou = false;               // só a partir do 1º Título/Capítulo/Artigo: o cabeçalho da página (brasão, "Presidência da República") fica intacto
        for (let i = 0; i < lista.length; i++) {
            const p = lista[i];
            const bruto = p.textContent;
            let tipo = R.classificar(bruto);
            if (tipo === 'vazio') continue;
            if (TIPOS_ESTRUTURA.has(tipo)) iniciou = true;
            if (!iniciou) { cabecalhoAnterior = null; continue; }
            // o Planalto às vezes põe o nome do capítulo/seção num parágrafo à parte ("CAPÍTULO IV" / "DA SUCESSÃO..."):
            // um texto curto logo depois de um cabeçalho é o subtítulo dele e entra na mesma faixa
            if (tipo === 'texto' && cabecalhoAnterior && cabecalhoAnterior.p === lista[i - 1] && R.limpar(bruto).length <= 200 && !/[.;:]$/.test(R.limpar(bruto))) {
                cabecalhoAnterior.p.dataset.cbEdTemSub = '1';
                p.dataset.cbEdTipo = 'sub-' + cabecalhoAnterior.tipo;
                cabecalhoAnterior = null;
                continue;
            }
            cabecalhoAnterior = ['livro', 'titulo', 'capitulo', 'secao', 'subsecao'].includes(tipo) ? { p, tipo } : null;
            p.dataset.cbEdTipo = tipo;
            if (tipo === 'artigo') {
                const a = R.numeroDoArtigo(bruto);
                artigoAtual = a ? `Art. ${a.numero}${a.sufixo ? '-' + a.sufixo : ''}` : '';
            }
            if (['artigo', 'paragrafo', 'inciso', 'alinea', 'item'].includes(tipo) || tipo === 'texto') {
                const { full, segs } = textoComMapa(p);
                if (!full.trim()) continue;
                if (tipo === 'artigo' && !p.querySelector('.cb-art-ref')) {
                    const m = /^\s*Art(?:igo)?s?\.?\s*\d{1,4}(?:\.\d{3})?\s*[ºo°]?(?:\s*-\s*[A-Z])?/i.exec(full);
                    if (m) { const r = rangeDe(segs, m.index + (m[0].length - m[0].trimStart().length), m.index + m[0].length); if (r) rotulosArt.push(r); }
                }
                if (tipo === 'paragrafo') {
                    const m = /^\s*(?:§\s*\d+\s*[ºo°]?|Par[áa]grafo\s+[úu]nico)/i.exec(full);
                    if (m) { const r = rangeDe(segs, m.index, m.index + m[0].length); if (r) rotulosPar.push(r); }
                }
                if (tipo !== 'texto' || /\d|salvo|exceto|vedad/i.test(full)) {
                    R.acharMarcas(full).forEach((m) => {
                        const r = rangeDe(segs, m.ini, m.fim);
                        if (!r) return;
                        marcas[m.cat].push({ art: artigoAtual, trecho: R.trechoAoRedor(full, m.ini, m.fim), range: r });
                    });
                }
            }
            if (i % 300 === 299) await cedo();      // não trava a página em leis grandes
        }
        analise = { marcas, rotulosPar, rotulosArt };
        analisando = false;
    }

    // ------------------------------------------------------------------ realces
    function aplicarRealces() {
        if (!SUPORTA_REALCE || !analise) return;
        R.ORDEM.forEach((cat) => {
            if (estado.cats[cat] && analise.marcas[cat].length) CSS.highlights.set('cb-ed-' + cat, new Highlight(...analise.marcas[cat].map((m) => m.range)));
            else CSS.highlights.delete('cb-ed-' + cat);
        });
        if (analise.rotulosPar.length) CSS.highlights.set('cb-ed-parlabel', new Highlight(...analise.rotulosPar));
        if (analise.rotulosArt.length) CSS.highlights.set('cb-ed-chip', new Highlight(...analise.rotulosArt));
    }
    function limparRealces() {
        if (!SUPORTA_REALCE) return;
        R.ORDEM.concat(['parlabel', 'chip', 'foco']).forEach((c) => CSS.highlights.delete('cb-ed-' + c));
    }

    // ------------------------------------------------------------------ classes de layout
    let classesAplicadas = false;
    function aplicarClasses() {
        if (!classesAplicadas) {
            classesAplicadas = true;
            classesDosParagrafos();
        }
        document.documentElement.classList.add('cb-ed-on');
        document.documentElement.classList.toggle('cb-ed-noite', estado.tema === 'noite');
    }
    function classesDosParagrafos() {
        paragrafos().forEach((p) => {
            const t = p.dataset.cbEdTipo;
            if (p.dataset.cbEdTemSub) p.classList.add('cb-ed-tem-sub');
            if (t && t.startsWith('sub-')) p.classList.add('cb-ed-p', 'cb-ed-sub', 'cb-ed-' + t);
            else if (t && TIPOS_ESTRUTURA.has(t)) p.classList.add('cb-ed-p', 'cb-ed-' + t);
            else if (t === 'texto') p.classList.add('cb-ed-p', 'cb-ed-texto');
        });
    }
    // As classes dos parágrafos só têm efeito sob html.cb-ed-on (todo o CSS é escopado nela), então desligar é tirar UMA classe
    // do <html>: instantâneo, mesmo no CPC (4 mil parágrafos). Antes cada parágrafo era percorrido para tirar as suas.
    function removerClasses() {
        document.documentElement.classList.remove('cb-ed-on', 'cb-ed-noite');
    }

    // ------------------------------------------------------------------ interface
    const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

    function montarBarra() {
        if (barra) return;
        barra = document.createElement('div');
        barra.id = 'cb-ed-barra';
        barra.innerHTML = `
            <div class="cb-ed-barra-topo">
                <b title="Recolher / expandir">Edição de estudo <span class="cb-ed-estado">ligada</span></b>
                <button type="button" id="cb-ed-btn-recolher" class="cb-ed-mini" title="Recolher esta barra (o layout continua ligado)" aria-label="Recolher a barra">${ICON_RECOLHER}</button>
            </div>
            <div class="cb-ed-corpo">
                <p class="cb-ed-explica">Layout de edição para concursos. As cores marcam <b>prazos</b>, <b>quóruns</b>, <b>exceções</b>, <b>datas</b>, <b>emendas</b> e <b>percentuais</b>; toque numa categoria para esconder ou mostrar.</p>
                <div class="cb-ed-cats" id="cb-ed-cats"></div>
                <div class="cb-ed-acoes">
                    <button type="button" id="cb-ed-btn-quadro" class="cb-ed-acao">${ICON_LISTA}<span>Quadro</span></button>
                    <button type="button" id="cb-ed-btn-tema" class="cb-ed-acao">${ICON_LUA}<span id="cb-ed-tema-rotulo">Noite</span></button>
                    <button type="button" id="cb-ed-btn-desligar" class="cb-ed-acao cb-ed-acao--sair">${ICON_FECHAR}<span>Desligar</span></button>
                </div>
            </div>
        `;
        document.body.appendChild(barra);
        const rotuloTema = () => { barra.querySelector('#cb-ed-tema-rotulo').textContent = estado.tema === 'noite' ? 'Papel' : 'Noite'; };
        rotuloTema();
        barra.querySelector('#cb-ed-btn-desligar').addEventListener('click', () => ligar(false));
        barra.querySelector('#cb-ed-btn-tema').addEventListener('click', () => {
            estado.tema = estado.tema === 'noite' ? 'papel' : 'noite';
            document.documentElement.classList.toggle('cb-ed-noite', estado.tema === 'noite');
            rotuloTema();
            salvar();
        });
        barra.querySelector('#cb-ed-btn-quadro').addEventListener('click', alternarQuadro);
        // recolher só esconde a barra (o botão do dock a traz de volta); NÃO desliga a edição
        const recolher = () => barra.classList.toggle('cb-ed-barra--min');
        barra.querySelector('#cb-ed-btn-recolher').addEventListener('click', recolher);
        barra.querySelector('.cb-ed-barra-topo b').addEventListener('click', recolher);
        if (estado.barraMin) barra.classList.add('cb-ed-barra--min');
    }

    function desenharCategorias() {
        const el = barra && barra.querySelector('#cb-ed-cats');
        if (!el) return;
        el.innerHTML = R.ORDEM.map((c) => {
            const n = analise ? analise.marcas[c].length : 0;
            return `<button type="button" class="cb-ed-cat cb-ed-cat--${c}${estado.cats[c] ? '' : ' cb-ed-cat--off'}" data-cat="${c}" title="${esc(R.CATEGORIAS[c].rotulo)} — clique para ${estado.cats[c] ? 'esconder' : 'mostrar'}"><i>${esc(R.CATEGORIAS[c].sigla)}</i><span>${n}</span></button>`;
        }).join('');
        el.querySelectorAll('.cb-ed-cat').forEach((b) => b.addEventListener('click', () => {
            estado.cats[b.dataset.cat] = !estado.cats[b.dataset.cat];
            salvar();
            aplicarRealces();
            desenharCategorias();
            if (quadro && quadro.classList.contains('cb-ed-quadro--aberto')) desenharQuadro();
        }));
    }

    function irPara(range) {
        const el = range.startContainer.parentElement;
        if (!el) return;
        el.scrollIntoView({ block: 'center', behavior: 'smooth' });
        if (SUPORTA_REALCE) {
            CSS.highlights.set('cb-ed-foco', new Highlight(range));
            setTimeout(() => CSS.highlights.delete('cb-ed-foco'), 1800);
        }
    }

    function desenharQuadro() {
        if (!quadro || !analise) return;
        const secoes = R.ORDEM.filter((c) => estado.cats[c] && analise.marcas[c].length).map((c) => {
            const itens = analise.marcas[c].slice(0, MAX_NO_QUADRO);
            const linhas = itens.map((m, i) => `<tr data-cat="${c}" data-i="${i}"><td class="cb-ed-q-art">${esc(m.art || '—')}</td><td>${esc(m.trecho)}</td></tr>`).join('');
            const mais = analise.marcas[c].length > MAX_NO_QUADRO ? `<p class="cb-ed-q-mais">Mostrando ${MAX_NO_QUADRO} de ${analise.marcas[c].length}.</p>` : '';
            return `<div class="cb-ed-q-sec cb-ed-q-sec--${c}"><div class="cb-ed-q-tit">${esc(R.CATEGORIAS[c].rotulo)} <em>(${analise.marcas[c].length})</em></div><table><tbody>${linhas}</tbody></table>${mais}</div>`;
        }).join('');
        quadro.querySelector('.cb-ed-q-corpo').innerHTML = secoes || '<p class="cb-ed-q-vazio">Nenhum ponto de atenção encontrado com as categorias ligadas.</p>';
        quadro.querySelectorAll('tr[data-cat]').forEach((tr) => tr.addEventListener('click', () => {
            const m = analise.marcas[tr.dataset.cat][Number(tr.dataset.i)];
            if (m) irPara(m.range);
        }));
    }

    function alternarQuadro() {
        if (!quadro) {
            quadro = document.createElement('div');
            quadro.id = 'cb-ed-quadro';
            quadro.innerHTML = `<div class="cb-ed-q-head"><b>Quadro de pontos de atenção</b><button type="button" id="cb-ed-q-fechar" title="Fechar">${ICON_FECHAR}</button></div><p class="cb-ed-q-intro">Todos os trechos marcados, por categoria e por artigo. Clique numa linha para ir ao ponto no texto.</p><div class="cb-ed-q-corpo"></div>`;
            document.body.appendChild(quadro);
            quadro.querySelector('#cb-ed-q-fechar').addEventListener('click', () => quadro.classList.remove('cb-ed-quadro--aberto'));
        }
        const abrir = !quadro.classList.contains('cb-ed-quadro--aberto');
        if (abrir) desenharQuadro();
        quadro.classList.toggle('cb-ed-quadro--aberto', abrir);
    }

    // ------------------------------------------------------------------ ligar / desligar
    async function ligar(sim) {
        estado.ativo = !!sim;
        salvar();
        if (botao) botao.classList.toggle('cb-ed-botao--ativo', estado.ativo);
        if (!estado.ativo) {
            removerClasses();
            limparRealces();
            if (barra) barra.remove();
            if (quadro) quadro.remove();
            barra = quadro = null;
            return;
        }
        await analisar();
        aplicarClasses();
        montarBarra();
        desenharCategorias();
        if (SUPORTA_REALCE) aplicarRealces();
        else {
            const aviso = document.createElement('div');
            aviso.className = 'cb-ed-aviso';
            aviso.textContent = 'Este navegador não pinta as marcações (falta a API de realces). O layout da edição foi aplicado, sem as cores.';
            barra.appendChild(aviso);
        }
    }

    function paginaDeLei() {
        const arts = paragrafos().slice(0, 4000).filter((p) => /^\s*Art(?:igo)?s?\.?\s*\d/i.test(p.textContent));
        return arts.length >= MIN_ARTIGOS_PARA_OFERECER;
    }

    function criarBotao() {
        if (botao || document.getElementById('cb-ed-toggle')) return;
        botao = document.createElement('button');
        botao.id = 'cb-ed-toggle';
        botao.type = 'button';
        botao.title = 'Edição de estudo: layout de edição para concursos, com prazos, quóruns e exceções marcados em cor';
        botao.innerHTML = ICON_LIVRO;
        botao.classList.toggle('cb-ed-botao--ativo', estado.ativo);
        botao.addEventListener('click', () => {
            if (!estado.ativo) ligar(true);
            else if (barra) barra.classList.toggle('cb-ed-barra--min');
        });
        document.body.appendChild(botao);
    }

    async function iniciar() {
        await carregar();
        // espera o cb-artigos-lista.js criar os "Art. N" (etiqueta do artigo) antes de decidir/aplicar
        setTimeout(async () => {
            if (!paginaDeLei()) return;
            criarBotao();
            if (estado.ativo) await ligar(true);
        }, 1200);
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar); else iniciar();
})();
