// ============================================================================
// edicao-estudo-regras.js — Regras PURAS (sem DOM) da "Edição de estudo": o texto da lei do Planalto no layout de uma
// edição para concursos (papel creme, faixas de Título/Capítulo, etiqueta no artigo) com seis tipos de informação
// marcados em cor, como na "Lei Orgânica do Município de Iporã — Edição para Concursos":
//
//   prazo    prazos e termos           "no prazo de 15 (quinze) dias", "trinta dias úteis"
//   quorum   quóruns de votação       "maioria absoluta", "dois terços", "unanimidade"
//   excecao  exceções e vedações      "salvo", "exceto", "ressalvado", "é vedado", "não se aplica"
//   data     datas específicas         "1º de janeiro de 1991", "20/12/2019" (datas de outras leis citadas ficam de fora)
//   emenda   trechos alterados         "(Redação dada pela Emenda...)", "(Incluído pela Lei...)", "(Revogado...)"
//   pct      percentuais                "5%", "cinco por cento"
//
// Roda em Node (planalto/testes/edicao-estudo-regras.test.js) e no navegador (window.CBEdicaoRegras).
// A marcação é feita por heurística de texto, não por interpretação jurídica: pode marcar de menos ou de mais. Por isso o
// quadro-resumo mostra o trecho de cada marca e cada categoria pode ser ligada/desligada.
// ============================================================================
(function (raiz) {
    'use strict';

    // ------------------------------------------------------------------ estrutura do texto
    const ROMANO = '[IVXLCDM]+';
    const limpar = (t) => String(t || '').replace(/\s+/g, ' ').trim();

    // Tipo do parágrafo pelo começo do texto. Cabeçalhos só valem se curtos (um "Título" no meio de uma frase não conta).
    function classificar(texto) {
        const t = limpar(texto);
        if (!t) return 'vazio';
        const curto = t.length <= 260;
        if (curto && new RegExp(`^(?:LIVRO|PARTE)\\s+(?:${ROMANO}|[ÚU]NIC[OA]|GERAL|ESPECIAL|FINAL|COMPLEMENTAR|\\d+)\\b`, 'i').test(t)) return 'livro';
        if (curto && new RegExp(`^T[ÍI]TULO\\s+(?:${ROMANO}|[ÚU]NICO|\\d+)\\b`, 'i').test(t)) return 'titulo';
        if (curto && new RegExp(`^CAP[ÍI]TULO\\s+(?:${ROMANO}|[ÚU]NICO|\\d+)\\b`, 'i').test(t)) return 'capitulo';
        if (curto && new RegExp(`^Subse[çc][ãa]o\\s+(?:${ROMANO}|[ÚU]nica|\\d+)\\b`, 'i').test(t)) return 'subsecao';
        if (curto && new RegExp(`^Se[çc][ãa]o\\s+(?:${ROMANO}|[ÚU]nica|\\d+)\\b`, 'i').test(t)) return 'secao';
        if (/^Art(?:igo)?s?\.?\s*\d/i.test(t)) return 'artigo';
        if (/^(?:§\s*\d+|Par[áa]grafo\s+[úu]nico)/i.test(t)) return 'paragrafo';
        if (new RegExp(`^${ROMANO}\\s*[-–—.]\\s`).test(t)) return 'inciso';
        if (/^[a-z]\)\s/.test(t)) return 'alinea';
        if (/^\d{1,2}\s*[-–.)]\s/.test(t)) return 'item';
        return 'texto';
    }

    // "Art. 16.", "Art. 5º-A", "Art. 1.046" → { numero: '16', sufixo: '' } | null
    function numeroDoArtigo(texto) {
        const m = /^\s*Art(?:igo)?\.?\s*(\d{1,4}(?:\.\d{3})?)\s*[ºo°]?\s*(?:-\s*([A-Z]))?/i.exec(String(texto || ''));
        if (!m) return null;
        return { numero: m[1].replace('.', ''), sufixo: (m[2] || '').toUpperCase() };
    }

    // ------------------------------------------------------------------ marcações
    const UNID = 'um|uma|dois|duas|três|tres|quatro|cinco|seis|sete|oito|nove';
    const DEZ = 'dez|onze|doze|treze|catorze|quatorze|quinze|dezesseis|dezessete|dezoito|dezenove';
    const DEZENAS = 'vinte|trinta|quarenta|cinquenta|sessenta|setenta|oitenta|noventa';
    const CENT = 'cem|cento|duzentos|trezentos|quatrocentos|quinhentos|seiscentos|setecentos|oitocentos|novecentos|mil';
    const PALAVRA_NUM = `(?:${CENT}|${DEZENAS}|${DEZ}|${UNID})`;
    const NUM = `(?:\\d{1,3}(?:\\.\\d{3})*|${PALAVRA_NUM}(?:\\s+e\\s+${PALAVRA_NUM})*)`;
    const MESES = 'janeiro|fevereiro|março|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro';
    // limites de palavra que entendem acento (o \b do JavaScript não entende)
    const ANTES = '(?<![\\p{L}\\d])';
    const DEPOIS = '(?![\\p{L}\\d])';
    const re = (corpo) => new RegExp(ANTES + '(?:' + corpo + ')' + DEPOIS, 'giu');

    const PREFIXO_PRAZO = '(?:prazos?\\s+(?:(?:m[áa]ximo|m[íi]nimo|improrrog[áa]vel|comum)\\s+)?(?:(?:de|at[ée]|igual\\s+a|superior\\s+a|inferior\\s+a|n[ãa]o\\s+superior\\s+a|n[ãa]o\\s+inferior\\s+a)\\s+)?)?';
    const UNIDADE_PRAZO = '(?:dias?|meses|m[êe]s|anos?|horas?|semanas?|semestres?|bi[êe]nios?|quinqu[êe]nios?)';

    const CATEGORIAS = {
        prazo: { rotulo: 'Prazos e termos', sigla: 'PRAZO', re: re(`${PREFIXO_PRAZO}${NUM}(?:\\s*\\([^)]{1,70}\\))?\\s+${UNIDADE_PRAZO}(?:\\s+(?:[úu]teis|corridos|consecutivos))?(?!\\s+de\\s+idade)`) },
        quorum: { rotulo: 'Quóruns de votação', sigla: 'QUÓRUM', re: re('maioria\\s+(?:absoluta|simples|qualificada|relativa)(?:\\s+d[eao]s?\\s+(?:seus\\s+)?(?:membros|votos|presentes|vereadores|deputados|senadores|integrantes))?|maioria\\s+d[eao]s?\\s+(?:seus\\s+)?(?:membros|votos|presentes|vereadores|deputados|senadores)|(?:dois|duas)\\s+ter[çc]os|tr[êe]s\\s+quintos|um\\s+ter[çc]o|um\\s+quinto|um\\s+quarto|um\\s+sexto|um\\s+d[ée]cimo|metade\\s+mais\\s+um|unanimidade|qu[óo]rum|ter[çc]a\\s+parte|quinta\\s+parte') },
        excecao: { rotulo: 'Exceções e vedações', sigla: 'EXCEÇÃO', re: re('(?:(?:[ée]|s[ãa]o|fica|ficam)\\s+)?(?:vedad[oa]s?|proibid[oa]s?)|veda[çc](?:[ãa]o|[õo]es)|(?:[ée]|s[ãa]o)\\s+defes[oa]s?|salvo|exceto|excetuad[oa]s?|ressalvad[oa]s?|ressalvando|(?:com|[àa])\\s+exce[çc][ãa]o|n[ãa]o\\s+se\\s+aplica(?:m)?') },
        data: { rotulo: 'Datas específicas', sigla: 'DATA', re: re(`\\d{1,2}\\s?[º°o]?\\s+de\\s+(?:${MESES})(?:\\s+de\\s+\\d{4})?|\\d{1,2}/\\d{1,2}/\\d{2,4}|\\d{1,2}\\.\\d{1,2}\\.\\d{2,4}`) },
        emenda: { rotulo: 'Trechos alterados por emenda', sigla: 'EMENDA', re: /\((?:Reda[çc][ãa]o\s+dada|Inclu[ií]d[oa]|Acrescentad[oa]|Revogad[oa]|Alterad[oa]|Renumerad[oa]|Vide|Vig[êe]ncia|Produ[çc][ãa]o\s+de\s+efeito|Regulament|Declarad[oa]|Suprimid[oa]|Texto\s+dado|Restabelecid[oa]|Mantid[oa]|Express[ãa]o\s+(?:inclu|substitu|suprimid))[^)]*\)/giu },
        pct: { rotulo: 'Percentuais', sigla: '%', re: re(`\\d{1,3}(?:\\.\\d{3})*(?:,\\d+)?\\s?%|${NUM}\\s+por\\s+cento(?:\\s*\\(\\s*[\\d.,]+\\s?%\\s*\\))?`) },
    };
    const ORDEM = ['prazo', 'quorum', 'excecao', 'data', 'emenda', 'pct'];
    // quando duas marcas se cruzam, vale a maior; empate → a de menor número aqui (emenda engole as datas dentro dela)
    const PRIORIDADE = { emenda: 0, prazo: 1, quorum: 2, pct: 3, data: 4, excecao: 5 };

    // "Lei nº 11.340, de 7 de agosto de 2006": a data é a da OUTRA lei, não uma data que a lei em estudo fixa.
    const RE_DATA_DE_NORMA = /\b(?:Lei|Decreto|Emenda|Medida\s+Provis[óo]ria|Resolu[çc][ãa]o|Portaria|C[óo]digo)\b[^()]{0,80}[,\s]\s*(?:de\s+)?$/i;

    // texto → [{ cat, ini, fim }] sem sobreposição, em ordem. `categorias` limita quais procurar (padrão: todas).
    function acharMarcas(texto, categorias) {
        const t = String(texto == null ? '' : texto);
        const brutas = [];
        (categorias || ORDEM).forEach((cat) => {
            const def = CATEGORIAS[cat];
            if (!def) return;
            def.re.lastIndex = 0;
            let m;
            while ((m = def.re.exec(t))) {
                if (!m[0]) { def.re.lastIndex++; continue; }
                const ini = m.index, fim = m.index + m[0].length;
                if (cat === 'data' && RE_DATA_DE_NORMA.test(t.slice(Math.max(0, ini - 90), ini))) continue;
                brutas.push({ cat, ini, fim });
            }
        });
        brutas.sort((a, b) => a.ini - b.ini || (b.fim - b.ini) - (a.fim - a.ini) || PRIORIDADE[a.cat] - PRIORIDADE[b.cat]);
        const saida = [];
        let limite = -1;
        brutas.forEach((b) => {
            if (b.ini < limite) return;    // cruza com uma marca já aceita
            saida.push(b);
            limite = b.fim;
        });
        return saida;
    }

    // trecho legível ao redor da marca, para o quadro-resumo
    function trechoAoRedor(texto, ini, fim, folga) {
        const t = String(texto || '');
        const f = folga || 110;
        let a = Math.max(0, ini - f), b = Math.min(t.length, fim + f);
        if (a > 0) { const e = t.indexOf(' ', a); if (e !== -1 && e < ini) a = e + 1; }
        if (b < t.length) { const e = t.lastIndexOf(' ', b); if (e > fim) b = e; }
        return (a > 0 ? '…' : '') + limpar(t.slice(a, b)) + (b < t.length ? '…' : '');
    }

    const api = { ORDEM, CATEGORIAS, classificar, numeroDoArtigo, acharMarcas, trechoAoRedor, limpar };
    if (typeof module !== 'undefined' && module.exports) module.exports = api;
    else raiz.CBEdicaoRegras = api;
})(typeof window !== 'undefined' ? window : globalThis);
