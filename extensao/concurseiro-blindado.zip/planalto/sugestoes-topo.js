// ============================================================================
// sugestoes-topo.js — Faixa "Sugestões de leitura" no topo de cada lei do Planalto: os artigos que mais aparecem nas questões
// que você ERROU no QConcursos (a mesma fonte do "errou N" ao lado do artigo, ver erros-no-texto.js), do mais errado para o menos.
// Clicar num artigo leva até ele no texto. Sem erros mapeados nesta lei, a faixa vira uma linha discreta explicando como aparecer.
// Funções puras (ordenar) rodam em Node: planalto/testes/sugestoes-topo.test.js.
// ============================================================================
(function (raiz) {
    'use strict';

    // contagem = { '279': 3, '5A': 1 } (erros-no-texto.contarPorArtigo) → [{ chave, numero, sufixo, n }], mais errado primeiro
    function ordenar(contagem, max) {
        const lista = Object.keys(contagem || {}).map((chave) => {
            const m = /^(\d+)([A-Z]*)$/.exec(chave);
            return m ? { chave, numero: Number(m[1]), sufixo: m[2], n: contagem[chave] } : null;
        }).filter(Boolean);
        lista.sort((a, b) => b.n - a.n || a.numero - b.numero || a.sufixo.localeCompare(b.sufixo));
        return max ? lista.slice(0, max) : lista;
    }
    const rotulo = (it) => `Art. ${it.numero}${it.sufixo ? '-' + it.sufixo : ''}`;

    const api = { ordenar, rotulo };
    if (typeof module !== 'undefined' && module.exports) { module.exports = api; return; }

    // ------------------------------------------------------------------ página
    if (raiz.__cbSugestoesTopo) return;
    raiz.__cbSugestoesTopo = true;
    const MAX_VISIVEIS = 8;
    let faixa = null, aberta = false, minimizada = false;

    const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const plural = (n, um, varios) => `${n} ${n === 1 ? um : varios}`;

    function irParaArtigo(it) {
        const ancora = raiz.document.querySelector(`a[name="art${it.numero}${it.sufixo.toLowerCase()}"]`)
            || Array.from(raiz.document.querySelectorAll(`.cb-art-ref[data-cb-art-num="${it.numero}"]`)).find((r) => (raiz.CBCorpus927 ? raiz.CBCorpus927.sufixoDoRef(r) : '') === it.sufixo);
        const bloco = ancora && (ancora.closest('p') || ancora);
        if (!bloco) return false;
        bloco.scrollIntoView({ block: 'center', behavior: 'smooth' });
        bloco.classList.add('cb-sug-pulso');
        setTimeout(() => bloco.classList.remove('cb-sug-pulso'), 2200);
        return true;
    }

    function desenhar(contagem) {
        const Doc = raiz.document;
        const itens = ordenar(contagem);
        if (!faixa) {
            // tag própria (não <div>): o marcador de texto guarda posições por XPath com índices por tipo de tag, e um <div> novo no topo deslocaria os <div> da lei
            faixa = Doc.createElement('cb-sugestoes');
            faixa.id = 'cb-sug-topo';
            Doc.body.insertBefore(faixa, Doc.body.firstChild);
            try { raiz.chrome.storage.local.get(['cbSugTopoMin'], (r) => { minimizada = !!(r && r.cbSugTopoMin); faixa.classList.toggle('cb-sug--min', minimizada); }); } catch (e) { /* ignora */ }
        }
        const total = itens.reduce((s, i) => s + i.n, 0);
        const visiveis = aberta ? itens : itens.slice(0, MAX_VISIVEIS);
        const corpo = itens.length
            ? `<div class="cb-sug-chips">${visiveis.map((it) => `<button type="button" class="cb-sug-chip" data-chave="${esc(it.chave)}" title="Ir para ${esc(rotulo(it))}"><b>${esc(rotulo(it))}</b><i>${plural(it.n, 'questão', 'questões')}</i></button>`).join('')}${itens.length > MAX_VISIVEIS ? `<button type="button" class="cb-sug-mais">${aberta ? 'Mostrar menos' : `Ver todos (${itens.length})`}</button>` : ''}</div>`
            : '<p class="cb-sug-vazio">Nenhum artigo desta lei apareceu ainda nas questões que você errou. Resolva questões no QConcursos (logado) e eles aparecem aqui.</p>';
        faixa.innerHTML = `
            <div class="cb-sug-cab">
                <span class="cb-sug-titulo">Sugestões de leitura</span>
                <span class="cb-sug-sub">${itens.length ? `${plural(itens.length, 'artigo', 'artigos')} de ${plural(total, 'erro', 'erros')} seus no QConcursos` : 'artigos que você errou no QConcursos'}</span>
                <button type="button" class="cb-sug-min" title="Recolher / mostrar" aria-label="Recolher ou mostrar as sugestões">▾</button>
            </div>
            ${corpo}`;
        faixa.classList.toggle('cb-sug--min', minimizada);
        faixa.querySelector('.cb-sug-min').addEventListener('click', () => {
            minimizada = !minimizada; faixa.classList.toggle('cb-sug--min', minimizada);
            try { raiz.chrome.storage.local.set({ cbSugTopoMin: minimizada }); } catch (e) { /* ignora */ }
        });
        faixa.querySelectorAll('.cb-sug-chip').forEach((b) => b.addEventListener('click', () => {
            const it = itens.find((x) => x.chave === b.dataset.chave);
            if (it) irParaArtigo(it);
        }));
        const mais = faixa.querySelector('.cb-sug-mais');
        if (mais) mais.addEventListener('click', () => { aberta = !aberta; desenhar(contagem); });
    }

    function atualizar() {
        const lei = raiz.CBArtigos && raiz.CBArtigos.detectarLei && raiz.CBArtigos.detectarLei();
        const Armazem = raiz.CBArtigosStore;
        const Contar = raiz.CBErrosNoTexto;
        if (!lei || !Armazem || !Contar) return;
        Armazem.ler().then((estado) => desenhar(Contar.contarPorArtigo(estado, lei))).catch(() => {});
    }
    function iniciar() {
        setTimeout(atualizar, 1500);
        try {
            raiz.chrome.storage.onChanged.addListener((mud, area) => {
                const S = raiz.CBArtigosStore;
                if (area === 'local' && S && (mud[S.K_PEND] || mud[S.K_REV])) atualizar();
            });
        } catch (e) { /* sem storage */ }
    }
    if (raiz.document.readyState === 'loading') raiz.document.addEventListener('DOMContentLoaded', iniciar); else iniciar();
})(typeof window !== 'undefined' ? window : globalThis);
