// ============================================================================
// reading-mode.js — Modo de Leitura próprio da extensão para o Planalto.
//
// v3: em vez de CLONAR o texto da lei pro overlay (o que quebrava o
// marcador de texto lá dentro — o XPath salvo não batia com a página real —
// e perdia a cor de fundo dos grifos já feitos), agora MOVEMOS o container
// real do texto pra dentro do overlay, e devolvemos ao lugar original
// quando fecha. É o mesmo nó, os mesmos grifos, o mesmo tudo — o marcador
// de texto (highlighter.js) funciona normalmente aqui dentro porque ele
// nem percebe diferença (é a mesma <mark> no mesmo document).
//
// Também adiciona um modo de rolagem automática (estilo teleprompter).
// ============================================================================

(function () {
    if (window.__cbReadingModeLoaded) return;
    window.__cbReadingModeLoaded = true;

    const ICON_CLOSE = '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
    const ICON_AA = '<span class="cb-rm-rail-aa">Aa</span>';
    const ICON_THEME = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19l7-7 3 3-7 7-3-3z"/><path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"/><path d="M2 2l7.586 7.586"/><circle cx="11" cy="11" r="2"/></svg>';
    const ICON_SCROLL = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="7 13 12 18 17 13"/><polyline points="7 6 12 11 17 6"/></svg>';
    const ICON_BOOK = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>';
    const ICON_MINUS = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><line x1="5" y1="12" x2="19" y2="12"/></svg>';
    const ICON_PLUS = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>';
    const ICON_PLAY = '<svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor"><polygon points="6 3 20 12 6 21 6 3"/></svg>';
    const ICON_PAUSE = '<svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>';
    const ICON_CHEVRON = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>';
    const ICON_WIDTH = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"/><polyline points="8 7 3 12 8 17"/><polyline points="16 7 21 12 16 17"/></svg>';
    const ICON_LETTER_SPACING = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="4" x2="4" y2="20"/><line x1="20" y1="4" x2="20" y2="20"/><text x="8.5" y="16" font-size="10" stroke="none" fill="currentColor" font-family="sans-serif">A</text></svg>';
    const ICON_WORD_SPACING = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><text x="2" y="16" font-size="10" stroke="none" fill="currentColor" font-family="sans-serif">A</text><line x1="12" y1="12" x2="20" y2="12"/><polyline points="15 8 20 12 15 16"/></svg>';
    const ICON_ALIGN_LEFT = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="12" x2="14" y2="12"/><line x1="4" y1="18" x2="17" y2="18"/></svg>';
    const ICON_ALIGN_CENTER = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="4" y1="6" x2="20" y2="6"/><line x1="7" y1="12" x2="17" y2="12"/><line x1="6" y1="18" x2="18" y2="18"/></svg>';
    const ICON_ALIGN_RIGHT = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="4" y1="6" x2="20" y2="6"/><line x1="10" y1="12" x2="20" y2="12"/><line x1="7" y1="18" x2="20" y2="18"/></svg>';
    const ICON_ALIGN_JUSTIFY = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="18" x2="20" y2="18"/></svg>';
    const ICON_SEARCH = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>';
    const ICON_SPEAKER = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg>';
    const ICON_MAPA = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="4" cy="6" r="2"/><circle cx="4" cy="18" r="2"/><circle cx="18" cy="4" r="2"/><circle cx="18" cy="12" r="2"/><circle cx="18" cy="20" r="2"/><path d="M6 6h6a4 4 0 0 1 4-2"/><path d="M6 18h6a4 4 0 0 0 4-6h2"/><path d="M6 6v12"/></svg>';

    const TEMAS = [
        { id: 'auto',      nome: 'Automático', bg: '#0c0d11', fg: '#e7e9f0' },
        { id: 'claro',     nome: 'Claro',      bg: '#ffffff', fg: '#1c1c1f' },
        { id: 'escuro',    nome: 'Escuro',     bg: '#0c0d11', fg: '#e7e9f0' },
        { id: 'sepia',     nome: 'Sépia',      bg: '#f4ecd8', fg: '#3a2f1c' },
        { id: 'contraste', nome: 'Contraste',  bg: '#000000', fg: '#ffffff' },
        { id: 'cinza',     nome: 'Cinza',      bg: '#e4e4e6', fg: '#1c1c1f' }
    ];

    const FONTES = [
        { id: 'sans', nome: 'Sem serifa', css: '-apple-system, BlinkMacSystemFont, "SF Pro Text", Roboto, sans-serif' },
        { id: 'serif', nome: 'Com serifa', css: 'Georgia, "Times New Roman", serif' },
        { id: 'lora', nome: 'Lora', css: '"Lora", Georgia, "Times New Roman", serif' }
    ];

    const CORES_FONTE = [
        { id: 'auto', nome: 'Automático', hex: null },
        { id: 'preto', nome: 'Preto', hex: '#111114' },
        { id: 'cinza', nome: 'Cinza escuro', hex: '#3a3d46' },
        { id: 'azul', nome: 'Azul', hex: '#1c3f8f' },
        { id: 'verde', nome: 'Verde', hex: '#0a6b47' },
        { id: 'marrom', nome: 'Marrom', hex: '#5c3a1e' }
    ];

    const ELEMENTOS_DA_EXTENSAO_SELECTOR =
        '#cb-hl-panel, #cb-hl-toolbar, .cb-hl-barra, #cb-hl-panel-toggle, ' +
        '#cb-reading-mode-overlay, #cb-rm-toggle, #cb-ft-rail, .cb-ft-pop, ' +
        '#cb-desenho-canvas, #cb-pri-toggle, #cb-pri-panel';

    function ehElementoDaExtensao(el) {
        if (!el || el.nodeType !== 1) return true;
        if (el.matches && el.matches(ELEMENTOS_DA_EXTENSAO_SELECTOR)) return true;
        return !!(el.closest && el.closest(ELEMENTOS_DA_EXTENSAO_SELECTOR));
    }

    function encontrarAncestralComumEl(a, b) {
        const ancestrais = new Set();
        let el = a;
        while (el) { ancestrais.add(el); el = el.parentElement; }
        el = b;
        while (el) { if (ancestrais.has(el)) return el; el = el.parentElement; }
        return null;
    }

    function filhoDiretoDe(ancestral, node) {
        let el = node;
        while (el && el.parentElement !== ancestral) el = el.parentElement;
        return el;
    }

    // Quando o texto da lei está espalhado em vários filhos soltos do body
    // (sem uma única <div>/<article> envolvendo tudo — comum no HTML antigo
    // do Planalto, com vários <font>/<p> soltos), cria uma <div> temporária
    // e move pra dentro dela a faixa de filhos do body que vai do primeiro
    // ao último nó "Art." — sem sair fora dessa faixa e sem incluir
    // elementos da própria extensão. Esse wrapper é desfeito (filhos
    // devolvidos ao body, sem deixar a div extra) quando o Modo de Leitura
    // fecha, ver devolverConteudoRealAoLugar().
    function envolverFilhosDoBodyNumWrapper(topInicio, topFim) {
        const elementos = [];
        let atual = topInicio, seguranca = 0, alcancouFim = false;
        while (atual && seguranca < 20000) {
            if (!ehElementoDaExtensao(atual)) elementos.push(atual);
            if (atual === topFim) { alcancouFim = true; break; }
            atual = atual.nextElementSibling;
            seguranca++;
        }
        if (!alcancouFim || !elementos.length) return null;

        const wrapper = document.createElement('div');
        wrapper.id = 'cb-rm-auto-wrapper';
        topInicio.parentElement.insertBefore(wrapper, topInicio);
        elementos.forEach(el => wrapper.appendChild(el));
        return wrapper;
    }

    // Devolve { elemento, envolvido }. `envolvido = true` quando o elemento
    // é um wrapper artificial criado por envolverFilhosDoBodyNumWrapper (e
    // portanto precisa ser desfeito ao fechar, em vez de só devolvido ao
    // lugar original).
    function encontrarContainerDaLei() {
        // Preferência: achar o ancestral comum de TODOS os nós "Art." da
        // página. A heurística antiga (elemento com mais "Art." dentro)
        // pegava só um <font>/<p> entre vários soltos direto no body,
        // deixando o início da lei pra trás — foi o que abria o Modo de
        // Leitura faltando os primeiros artigos.
        if (window.CBArtigos) {
            try {
                const nos = window.CBArtigos.coletarNosDeTexto(document.body)
                    .filter(n => window.CBArtigos.RE_ARTIGO.test(n.nodeValue));
                if (nos.length >= 2) {
                    const primeiro = nos[0].parentElement;
                    const ultimo = nos[nos.length - 1].parentElement;
                    const ancestral = encontrarAncestralComumEl(primeiro, ultimo);

                    if (ancestral && ancestral !== document.body && ancestral !== document.documentElement
                        && !ehElementoDaExtensao(ancestral)) {
                        return { elemento: ancestral, envolvido: false };
                    }

                    if (ancestral === document.body) {
                        const topInicio = filhoDiretoDe(document.body, primeiro);
                        const topFim = filhoDiretoDe(document.body, ultimo);
                        if (topInicio && topFim) {
                            const wrapper = envolverFilhosDoBodyNumWrapper(topInicio, topFim);
                            if (wrapper) return { elemento: wrapper, envolvido: true };
                        }
                    }
                }
            } catch (e) {
                console.warn('[Modo de Leitura] Falha ao localizar container via nós de "Art.":', e);
            }
        }

        // ---- fallback: heurística antiga (elemento com mais "Art." dentro) ----
        const candidatos = document.querySelectorAll('body > *, #conteudo, #content, main, article, .col, .col-md-12, .container');
        let melhor = null;
        let melhorScore = -1;
        candidatos.forEach((el) => {
            if (el === document.body || el === document.documentElement) return;
            if (ehElementoDaExtensao(el)) return;
            const texto = el.innerText || '';
            const ocorrencias = (texto.match(/Art\.\s*\d/g) || []).length;
            if (ocorrencias > melhorScore) { melhorScore = ocorrencias; melhor = el; }
        });

        // ---- fallback 3: densidade de texto (só entra quando NENHUM "Art."
        // foi encontrado em lugar nenhum — páginas sem artigo, tipo uma
        // súmula avulsa, um índice, uma portaria não numerada em artigos).
        // Antes, esse caso caía direto no fallback final abaixo (que só
        // pega o primeiro filho "de verdade" do body — um chute às cegas,
        // podia perfeitamente pegar um menu ou uma barra lateral).
        //
        // A ideia é a mesma do algoritmo do Readability.js da Mozilla
        // (usado no Modo Leitor do Firefox): pontuar cada bloco pelo
        // tamanho do texto, punindo bastante blocos dominados por links
        // (menu, lista de referências) — só que numa versão compacta,
        // porque a lib original (~2000 linhas) foi pensada pra notícia/
        // blog e não teria motivo pra entrar inteira aqui só por causa
        // desse fallback raro.
        if (!melhor || melhorScore <= 0) {
            const porDensidade = encontrarPorDensidadeTexto();
            if (porDensidade) melhor = porDensidade;
        }

        // fallback final: se mesmo assim nada bateu, usa o primeiro filho
        // "de verdade" do body em vez do body inteiro.
        if (!melhor) {
            melhor = Array.from(document.body.children).find(
                (el) => !ehElementoDaExtensao(el)
            ) || document.body;
        }
        return { elemento: melhor, envolvido: false };
    }

    const CB_RM_TAGS_IGNORAR_DENSIDADE = new Set([
        'script', 'style', 'nav', 'header', 'footer', 'a', 'svg',
        'button', 'input', 'select', 'textarea', 'noscript', 'iframe'
    ]);

    function pontuarBlocoPorDensidade(el) {
        const texto = (el.innerText || '').trim();
        const tamanhoTexto = texto.length;
        // Bloco curto demais pra plausivelmente ser "o conteúdo principal"
        // da página — evita que um títulozinho qualquer vença por não ter
        // nenhum link dentro.
        if (tamanhoTexto < 200) return -1;

        const links = el.querySelectorAll('a');
        let textoLinks = 0;
        links.forEach((a) => { textoLinks += (a.innerText || '').length; });
        const densidadeLinks = tamanhoTexto > 0 ? textoLinks / tamanhoTexto : 0;

        // Quanto maior a fração do texto que é só link, mais o bloco é
        // provavelmente menu/navegação/lista de referências — não o corpo
        // da lei. O corte em 0.9 evita pontuação negativa (só reduz).
        let pontuacao = tamanhoTexto * (1 - Math.min(densidadeLinks * 1.5, 0.9));

        const tag = el.tagName.toLowerCase();
        if (tag === 'article' || tag === 'main') pontuacao *= 1.3;

        return pontuacao;
    }

    function encontrarPorDensidadeTexto() {
        // Escopo intencionalmente amplo (body + todos os descendentes) —
        // esse fallback já só roda quando as duas heurísticas anteriores
        // (nós de "Art." e contagem por seletor) não acharam nada, então
        // vale a pena varrer a página inteira uma vez em troca de um chute
        // bem melhor que "primeiro filho do body".
        const candidatos = document.querySelectorAll('body, body *');
        let melhor = null;
        let melhorPontuacao = -1;
        candidatos.forEach((el) => {
            if (el === document.body) return;
            if (ehElementoDaExtensao(el)) return;
            if (CB_RM_TAGS_IGNORAR_DENSIDADE.has(el.tagName.toLowerCase())) return;
            const pontuacao = pontuarBlocoPorDensidade(el);
            if (pontuacao > melhorPontuacao) { melhorPontuacao = pontuacao; melhor = el; }
        });
        return melhor;
    }

    // -------------------- estado --------------------
    let overlay = null;
    let fontSize = 18;
    let temaAtual = 'auto';
    let fonteAtual = 'sans';
    let lineHeight = 1.75;
    let contentWidth = 720;
    let letterSpacing = 0;
    let wordSpacing = 0;
    let textAlign = 'left';
    let corFonte = 'auto';
    const FONT_MIN = 14, FONT_MAX = 32;
    const WIDTH_MIN = 480, WIDTH_MAX = 900;
    const LETTER_SPACING_MIN = 0, LETTER_SPACING_MAX = 0.15;
    const WORD_SPACING_MIN = 0, WORD_SPACING_MAX = 0.6;
    const PADRAO = { fontSize: 18, temaAtual: 'auto', fonteAtual: 'sans', lineHeight: 1.75, contentWidth: 720, letterSpacing: 0, wordSpacing: 0, textAlign: 'left', corFonte: 'auto' };

    // referência ao container REAL (não clone) e onde ele vivia antes, pra
    // devolver certinho ao fechar.
    let containerReal = null;
    let scrollYAntesDoModoLeitura = 0;
    let containerPaiOriginal = null;
    let containerIrmaoSeguinte = null; // nextSibling no momento em que movemos
    let containerFoiEnvolvido = false; // true se containerReal é um wrapper artificial (ver encontrarContainerDaLei)

    // rolagem automática
    let autoScrollAtivo = false;
    let autoScrollVelocidade = 40; // px por segundo
    let autoScrollRAF = null;
    let autoScrollUltimoTs = null;

    // -------------------- leitura em voz alta (Web Speech API) --------------------
    // 100% local/nativo do navegador — sem chamada de rede, sem custo, sem
    // limite. window.speechSynthesis já vem embutido no Firefox/Chrome.
    let ttsRate = 1;
    let ttsVoiceURI = '';
    let ttsChunks = [];
    let ttsIndex = 0;
    let ttsAtivo = false;
    let ttsPausado = false;

    function salvarPrefs() {
        try {
            chrome.storage.local.set({
                cbReadingPrefs: { fontSize, temaAtual, fonteAtual, lineHeight, autoScrollVelocidade, contentWidth, letterSpacing, wordSpacing, textAlign, corFonte, ttsRate, ttsVoiceURI }
            });
        } catch (e) {}
    }
    function carregarPrefs(cb) {
        try {
            chrome.storage.local.get(['cbReadingPrefs'], (res) => {
                const p = res && res.cbReadingPrefs;
                if (p) {
                    fontSize = p.fontSize || fontSize;
                    temaAtual = p.temaAtual || temaAtual;
                    fonteAtual = p.fonteAtual || fonteAtual;
                    lineHeight = p.lineHeight || lineHeight;
                    autoScrollVelocidade = p.autoScrollVelocidade || autoScrollVelocidade;
                    contentWidth = p.contentWidth || contentWidth;
                    letterSpacing = (p.letterSpacing != null) ? p.letterSpacing : letterSpacing;
                    wordSpacing = (p.wordSpacing != null) ? p.wordSpacing : wordSpacing;
                    textAlign = p.textAlign || textAlign;
                    corFonte = p.corFonte || corFonte;
                    ttsRate = p.ttsRate || ttsRate;
                    ttsVoiceURI = p.ttsVoiceURI || ttsVoiceURI;
                }
                cb();
            });
        } catch (e) { cb(); }
    }

    // Quebra o texto lido em pedaços curtos (por frase, ~220 caracteres no
    // máximo) — o speechSynthesis de alguns navegadores trava ou corta
    // silenciosamente utterances muito longas (lei inteira de uma vez),
    // então lemos em fila, avançando pro próximo pedaço no evento "onend".
    function prepararChunksTTS() {
        const corpo = overlay.querySelector('#cb-rm-content');
        const texto = (corpo && corpo.innerText) || '';
        const frases = texto.replace(/\s+/g, ' ').trim().split(/(?<=[.;:!?])\s+/);
        const chunks = [];
        let atual = '';
        frases.forEach((f) => {
            if ((atual + ' ' + f).trim().length > 220 && atual) {
                chunks.push(atual.trim());
                atual = f;
            } else {
                atual = (atual + ' ' + f).trim();
            }
        });
        if (atual) chunks.push(atual.trim());
        return chunks;
    }

    function vozSelecionada() {
        const vozes = window.speechSynthesis.getVoices();
        if (ttsVoiceURI) {
            const v = vozes.find(v => v.voiceURI === ttsVoiceURI);
            if (v) return v;
        }
        return vozes.find(v => /pt(-|_)?br/i.test(v.lang)) || vozes.find(v => /^pt/i.test(v.lang)) || null;
    }

    function falarProximoChunkTTS() {
        if (!ttsAtivo || ttsIndex >= ttsChunks.length) {
            pararLeituraTTS();
            return;
        }
        const utter = new SpeechSynthesisUtterance(ttsChunks[ttsIndex]);
        const voz = vozSelecionada();
        if (voz) utter.voice = voz;
        utter.lang = voz ? voz.lang : 'pt-BR';
        utter.rate = ttsRate;
        utter.onend = () => {
            if (!ttsAtivo) return;
            ttsIndex++;
            atualizarProgressoTTS();
            falarProximoChunkTTS();
        };
        utter.onerror = () => { pararLeituraTTS(); };
        window.speechSynthesis.speak(utter);
    }

    function iniciarLeituraTTS() {
        if (!('speechSynthesis' in window)) {
            alert('Seu navegador não suporta leitura em voz alta.');
            return;
        }
        window.speechSynthesis.cancel();
        ttsChunks = prepararChunksTTS();
        ttsIndex = 0;
        ttsAtivo = true;
        ttsPausado = false;
        atualizarBotaoTTS();
        atualizarProgressoTTS();
        falarProximoChunkTTS();
    }
    function pausarRetomarTTS() {
        if (!ttsAtivo) return;
        if (ttsPausado) {
            window.speechSynthesis.resume();
            ttsPausado = false;
        } else {
            window.speechSynthesis.pause();
            ttsPausado = true;
        }
        atualizarBotaoTTS();
    }
    function pararLeituraTTS() {
        ttsAtivo = false;
        ttsPausado = false;
        window.speechSynthesis.cancel();
        atualizarBotaoTTS();
        atualizarProgressoTTS();
    }
    function atualizarBotaoTTS() {
        if (!overlay) return;
        const btn = overlay.querySelector('#cb-rm-tts-toggle');
        const rail = overlay.querySelector('#cb-rm-btn-tts');
        if (!btn) return;
        btn.innerHTML = (ttsAtivo && !ttsPausado) ? ICON_PAUSE : ICON_PLAY;
        if (rail) rail.classList.toggle('cb-rm-rail-btn-ativo', ttsAtivo);
    }
    function atualizarProgressoTTS() {
        if (!overlay) return;
        const el = overlay.querySelector('#cb-rm-tts-progresso');
        if (!el) return;
        el.textContent = ttsChunks.length ? `${Math.min(ttsIndex + 1, ttsChunks.length)} / ${ttsChunks.length}` : '';
    }
    // -------------------- mapa mental da lei (Mermaid.js) --------------------
    // Lê a estrutura Título/Capítulo/Seção/Artigo do texto já movido pro Modo
    // de Leitura e monta um mindmap. Artigos viram faixas ("Art. 1 a 15") em
    // vez de um nó por artigo — em leis grandes (CPC tem ~1000 artigos) um nó
    // por artigo faria o diagrama ficar ilegível/pesado demais pra renderizar.
    const RE_MM_PARTE = /^PARTE\s+(GERAL|ESPECIAL|FINAL|COMPLEMENTAR|[ÚU]NICA|[IVXLCDM]+|\d+)\b\.?[\s\-–—]*(.*)$/i;
    const RE_MM_LIVRO = /^LIVRO\s+([IVXLCDM]+|[ÚU]NICO|\d+)\b\.?[\s\-–—]*(.*)$/i;
    const RE_MM_TITULO = /^T[ÍI]TULO\s+([IVXLCDM]+|\d+|[ÚU]NICO)\b\.?[\s\-–—]*(.*)$/i;
    const RE_MM_CAPITULO = /^CAP[ÍI]TULO\s+([IVXLCDM]+|\d+|[ÚU]NICO)\b\.?[\s\-–—]*(.*)$/i;
    const RE_MM_SECAO = /^Se[çc][ãa]o\s+([IVXLCDM]+|\d+|[ÚU]nica)\b\.?[\s\-–—]*(.*)$/i;
    const RE_MM_SUBSECAO = /^Subse[çc][ãa]o\s+([IVXLCDM]+|\d+|[ÚU]nica)\b\.?[\s\-–—]*(.*)$/i;
    const RE_MM_ART = /^Art\.?\s*(\d+º?-?[A-Z]?)/i;
    const MM_LIMITE_NOS = 240;

    function mmLimparTexto(s) {
        return (s || '').replace(/["\n\r]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 70);
    }

    function mmLinhasDoConteudo() {
        const corpo = overlay.querySelector('#cb-rm-content');
        if (!corpo) return [];
        const blocos = Array.from(corpo.querySelectorAll('p, font, div, li, h1, h2, h3, h4, h5, h6'))
            .filter((el) => !el.closest('#cb-sug-topo, #cb-ed-barra, #cb-ed-quadro, #cb-dock'));
        const alvo = blocos.length ? blocos : [corpo];
        // o texto de um título aparece em mais de um bloco aninhado (<p> e o <font> dentro dele): tira a repetição seguida
        return alvo.map(el => ((el.textContent || '').replace(/\s+/g, ' ').trim())).filter(Boolean)
            .filter((linha, i, todas) => linha !== todas[i - 1]);
    }

    function mmConstruirEstrutura(linhas) {
        const raiz = { titulo: 'raiz', rank: 0, filhos: [] };
        let pilha = [raiz];
        let faixaPai = null, faixaInicio = null, faixaFim = null;

        function fecharFaixa() {
            if (faixaPai && faixaInicio != null) {
                const label = (faixaInicio === faixaFim) ? `Art. ${faixaInicio}` : `Art. ${faixaInicio} a ${faixaFim}`;
                faixaPai.filhos.push({ titulo: label, rank: 99, filhos: [] });
            }
            faixaPai = null; faixaInicio = null; faixaFim = null;
        }
        function empilhar(rank, titulo) {
            fecharFaixa();
            while (pilha.length > 1 && pilha[pilha.length - 1].rank >= rank) pilha.pop();
            const pai = pilha[pilha.length - 1];
            const no = { titulo, rank, filhos: [] };
            pai.filhos.push(no);
            pilha.push(no);
        }

        const ehEstrutura = (t) => RE_MM_PARTE.test(t) || RE_MM_LIVRO.test(t) || RE_MM_TITULO.test(t) || RE_MM_CAPITULO.test(t) || RE_MM_SECAO.test(t) || RE_MM_SUBSECAO.test(t) || RE_MM_ART.test(t);
        // o Planalto às vezes põe o nome em outra linha ("CAPÍTULO I" / "DAS NORMAS FUNDAMENTAIS"): junta, se a seguinte for curta e não for estrutura
        const nomeDaProxima = (idx) => {
            const prox = linhas[idx + 1];
            return prox && prox.length <= 160 && !ehEstrutura(prox) && !/^[§IVXLCDM]+\s*[-–—.]/.test(prox) ? prox : '';
        };
        for (let k = 0; k < linhas.length; k++) {
            const linha = linhas[k];
            let m, rot, rank;
            if ((m = RE_MM_PARTE.exec(linha))) { rank = 0.1; rot = `Parte ${m[1]}`; }
            else if ((m = RE_MM_LIVRO.exec(linha))) { rank = 0.5; rot = `Livro ${m[1]}`; }
            else if ((m = RE_MM_TITULO.exec(linha))) { rank = 1; rot = `Título ${m[1]}`; }
            else if ((m = RE_MM_CAPITULO.exec(linha))) { rank = 2; rot = `Capítulo ${m[1]}`; }
            else if ((m = RE_MM_SECAO.exec(linha))) { rank = 3; rot = `Seção ${m[1]}`; }
            else if ((m = RE_MM_SUBSECAO.exec(linha))) { rank = 4; rot = `Subseção ${m[1]}`; }
            if (rank != null) {
                let nome = m[2] || '';
                if (!nome) { const prox = nomeDaProxima(k); if (prox) { nome = prox; k++; } }
                empilhar(rank, `${rot}${nome ? ' - ' + mmLimparTexto(nome) : ''}`);
            } else if ((m = RE_MM_ART.exec(linha))) {
                const pai = pilha[pilha.length - 1];
                if (faixaPai !== pai) { fecharFaixa(); faixaPai = pai; faixaInicio = m[1]; }
                faixaFim = m[1];
            }
        }
        fecharFaixa();
        return raiz;
    }

    function mmGerarDefinicao(raiz) {
        const nomeLei = mmLimparTexto(document.title) || 'Lei';
        const linhasSaida = ['mindmap', `  root(("${nomeLei}"))`];
        let contador = 0;
        function walk(no, prof) {
            for (const filho of no.filhos) {
                if (contador >= MM_LIMITE_NOS) return;
                contador++;
                linhasSaida.push('  '.repeat(prof + 2) + `"${mmLimparTexto(filho.titulo)}"`);
                if (filho.filhos && filho.filhos.length) walk(filho, prof + 1);
            }
        }
        walk(raiz, 0);
        return linhasSaida.join('\n');
    }

    function mmEnviarParaRenderizar(definicao) {
        return new Promise((resolve) => {
            try {
                chrome.runtime.sendMessage(
                    { action: 'cbMermaidRender', definicao, elementId: 'cb-mmd-' + Date.now() },
                    (resposta) => resolve(resposta || { ok: false, erro: 'sem resposta' })
                );
            } catch (e) {
                resolve({ ok: false, erro: String(e) });
            }
        });
    }

    async function abrirMapaMental() {
        const modal = overlay.querySelector('#cb-rm-mapa-modal');
        const corpo = overlay.querySelector('#cb-rm-mapa-corpo');
        modal.classList.add('cb-rm-mapa-aberto');
        corpo.innerHTML = 'Gerando mapa…';

        const linhas = mmLinhasDoConteudo();
        const estrutura = mmConstruirEstrutura(linhas);
        if (!estrutura.filhos.length) {
            corpo.innerHTML = '<div class="cb-rm-mapa-vazio">Não encontrei Título/Capítulo/Seção/Artigo nesta página pra montar um mapa.</div>';
            return;
        }
        // Desenhado aqui mesmo, sem a biblioteca Mermaid: ela era injetada dentro da página do Planalto e em alguns casos
        // devolvia um modal vazio. A árvore abre/fecha por nível e cada "Art. N" leva ao artigo no texto.
        corpo.innerHTML = mmArvoreHtml(estrutura);
        corpo.querySelectorAll('.cb-rm-mm-art').forEach((el) => el.addEventListener('click', () => {
            const alvo = overlay.querySelector(`a[name="art${el.dataset.art}"]`) || overlay.querySelector(`[data-cb-art-num="${el.dataset.art}"]`);
            fecharMapaMental();
            if (alvo) (alvo.closest('p') || alvo).scrollIntoView({ block: 'start', behavior: 'smooth' });
        }));
    }

    function mmEsc(s) { return String(s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
    function mmContar(no) { return (no.filhos || []).reduce((n, f) => n + (f.rank === 99 ? 1 : mmContar(f)), 0); }
    function mmArvoreHtml(raiz) {
        const no = (n, nivel) => {
            if (n.rank === 99) {
                const m = /(\d+)/.exec(n.titulo);
                return `<li class="cb-rm-mm-folha"><button type="button" class="cb-rm-mm-art" data-art="${m ? m[1] : ''}">${mmEsc(n.titulo)}</button></li>`;
            }
            const qtd = mmContar(n);
            return `<li><details${nivel <= 1 ? ' open' : ''}><summary>${mmEsc(n.titulo)}<em>${qtd} ${qtd === 1 ? 'artigo' : 'artigos'}</em></summary><ul>${(n.filhos || []).map((f) => no(f, nivel + 1)).join('')}</ul></details></li>`;
        };
        const titulo = mmLimparTexto(document.title) || 'Lei';
        return `<div class="cb-rm-mm"><div class="cb-rm-mm-raiz">${mmEsc(titulo)}</div><ul class="cb-rm-mm-lista">${(raiz.filhos || []).map((f) => no(f, 1)).join('')}</ul></div>`;
    }
    function fecharMapaMental() {
        const modal = overlay.querySelector('#cb-rm-mapa-modal');
        if (modal) modal.classList.remove('cb-rm-mapa-aberto');
    }

    function popularVozesTTS() {
        if (!overlay || !('speechSynthesis' in window)) return;
        const select = overlay.querySelector('#cb-rm-tts-voz');
        if (!select) return;
        const vozes = window.speechSynthesis.getVoices().filter(v => /^pt/i.test(v.lang));
        const listaFinal = vozes.length ? vozes : window.speechSynthesis.getVoices();
        select.innerHTML = listaFinal.map(v => `<option value="${v.voiceURI}">${v.name} (${v.lang})</option>`).join('');
        if (ttsVoiceURI) select.value = ttsVoiceURI;
    }

    // Carrega a fonte Lora (Google Fonts) uma única vez, só quando o Modo de
    // Leitura é aberto pela primeira vez — evita pedir a fonte se a pessoa
    // nunca usar o modo de leitura.
    let _cbLoraCarregada = false;
    function carregarFonteLora() {
        if (_cbLoraCarregada) return;
        _cbLoraCarregada = true;
        try {
            const link = document.createElement('link');
            link.rel = 'stylesheet';
            link.href = 'https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,600;1,400&display=swap';
            document.head.appendChild(link);
        } catch (e) {}
    }

    function montarOverlay() {
        carregarFonteLora();
        overlay = document.createElement('div');
        overlay.id = 'cb-reading-mode-overlay';
        overlay.innerHTML = `
            <div id="cb-rm-rail">
                <button id="cb-rm-close" class="cb-rm-rail-btn" title="Fechar (Esc)">${ICON_CLOSE}</button>
                <button id="cb-rm-btn-busca" class="cb-rm-rail-btn" title="Buscar palavra-chave">${ICON_SEARCH}</button>
                <button id="cb-rm-btn-aa" class="cb-rm-rail-btn" title="Fonte">${ICON_AA}</button>
                <button id="cb-rm-btn-theme" class="cb-rm-rail-btn" title="Tema">${ICON_THEME}</button>
                <button id="cb-rm-btn-scroll" class="cb-rm-rail-btn" title="Rolagem automática">${ICON_SCROLL}</button>
                <button id="cb-rm-btn-tts" class="cb-rm-rail-btn" title="Ouvir em voz alta">${ICON_SPEAKER}</button>
                <button id="cb-rm-btn-mapa" class="cb-rm-rail-btn" title="Mapa mental da lei">${ICON_MAPA}</button>
            </div>

            <div id="cb-rm-popover-busca" class="cb-rm-popover">
                <div class="cb-rm-pop-header"><span class="cb-rm-pop-title">Buscar nesta lei</span></div>
                <input id="cb-rm-busca-input" type="text" class="cb-rm-busca-input" placeholder="Digite e aperte Enter...">
                <div class="cb-rm-busca-row">
                    <button id="cb-rm-busca-anterior" class="cb-rm-busca-nav" title="Anterior (Shift+Enter)">‹</button>
                    <span id="cb-rm-busca-contador" class="cb-rm-busca-contador"></span>
                    <button id="cb-rm-busca-proximo" class="cb-rm-busca-nav" title="Próximo (Enter)">›</button>
                </div>
            </div>

            <div id="cb-rm-popover-aa" class="cb-rm-popover cb-rm-popover-wide">
                <div class="cb-rm-pop-header">
                    <span class="cb-rm-pop-title">Layout</span>
                </div>
                <div class="cb-rm-pop-row cb-rm-pop-row-stepper">
                    <span class="cb-rm-pop-label">Tamanho do texto</span>
                    <div class="cb-rm-stepper">
                        <button id="cb-rm-font-minus" class="cb-rm-step-btn">${ICON_MINUS}</button>
                        <button id="cb-rm-font-plus" class="cb-rm-step-btn">${ICON_PLUS}</button>
                    </div>
                </div>
                <div class="cb-rm-pop-row">
                    <span class="cb-rm-pop-label">Fonte</span>
                    <select id="cb-rm-fonte-select" class="cb-rm-select">
                        ${FONTES.map(f => `<option value="${f.id}">${f.nome}</option>`).join('')}
                    </select>
                </div>
                <div class="cb-rm-pop-row cb-rm-pop-row-col">
                    <span class="cb-rm-pop-label">Cor do texto</span>
                    <div class="cb-rm-corfonte-row">
                        ${CORES_FONTE.map(c => `<button class="cb-rm-corfonte-sw" data-cor="${c.id}" title="${c.nome}" style="${c.hex ? `background:${c.hex}` : 'background:linear-gradient(135deg,#fff,#0c0d11)'}"></button>`).join('')}
                    </div>
                </div>

                <div class="cb-rm-pop-row cb-rm-pop-row-col">
                    <span class="cb-rm-pop-label">Largura do conteúdo</span>
                    <div class="cb-rm-slider-row">
                        <span class="cb-rm-slider-icon">${ICON_WIDTH}</span>
                        <input id="cb-rm-content-width" type="range" min="${WIDTH_MIN}" max="${WIDTH_MAX}" step="20">
                    </div>
                </div>
                <div class="cb-rm-pop-row cb-rm-pop-row-col">
                    <span class="cb-rm-pop-label">Espaçamento entre linhas</span>
                    <div class="cb-rm-slider-row">
                        <span class="cb-rm-slider-icon">↕</span>
                        <input id="cb-rm-line-height" type="range" min="1.3" max="2.4" step="0.1">
                    </div>
                </div>

                <div class="cb-rm-divider-h"></div>

                <button id="cb-rm-advanced-toggle" class="cb-rm-advanced-toggle">
                    <span>Avançado</span>
                    ${ICON_CHEVRON}
                </button>
                <div id="cb-rm-advanced-body" class="cb-rm-advanced-body">
                    <div class="cb-rm-pop-row cb-rm-pop-row-col">
                        <span class="cb-rm-pop-label">Espaçamento entre caracteres</span>
                        <div class="cb-rm-slider-row">
                            <span class="cb-rm-slider-icon">${ICON_LETTER_SPACING}</span>
                            <input id="cb-rm-letter-spacing" type="range" min="${LETTER_SPACING_MIN}" max="${LETTER_SPACING_MAX}" step="0.01">
                        </div>
                        <div class="cb-rm-scale-labels"><span>Normal</span><span>Largo</span></div>
                    </div>
                    <div class="cb-rm-pop-row cb-rm-pop-row-col">
                        <span class="cb-rm-pop-label">Espaçamento entre palavras</span>
                        <div class="cb-rm-slider-row">
                            <span class="cb-rm-slider-icon">${ICON_WORD_SPACING}</span>
                            <input id="cb-rm-word-spacing" type="range" min="${WORD_SPACING_MIN}" max="${WORD_SPACING_MAX}" step="0.05">
                        </div>
                        <div class="cb-rm-scale-labels"><span>Normal</span><span>Largo</span></div>
                    </div>
                    <div class="cb-rm-pop-row cb-rm-pop-row-col">
                        <span class="cb-rm-pop-label">Alinhamento de texto</span>
                        <div class="cb-rm-align-row">
                            <button class="cb-rm-align-btn" data-align="left" title="Esquerda">${ICON_ALIGN_LEFT}</button>
                            <button class="cb-rm-align-btn" data-align="center" title="Centralizado">${ICON_ALIGN_CENTER}</button>
                            <button class="cb-rm-align-btn" data-align="right" title="Direita">${ICON_ALIGN_RIGHT}</button>
                            <button class="cb-rm-align-btn" data-align="justify" title="Justificado">${ICON_ALIGN_JUSTIFY}</button>
                        </div>
                    </div>
                </div>

                <button id="cb-rm-restaurar-padrao" class="cb-rm-restaurar-padrao">Restaurar padrão</button>
            </div>

            <div id="cb-rm-popover-theme" class="cb-rm-popover">
                <div class="cb-rm-pop-label" style="margin-bottom:10px;">Tema</div>
                <div class="cb-rm-theme-grid">
                    ${TEMAS.map(t => `
                        <button class="cb-rm-theme-swatch" data-tema="${t.id}" style="background:${t.bg}; color:${t.fg}">
                            <span class="cb-rm-theme-swatch-dot" style="background:${t.fg}"></span>
                            ${t.nome}
                        </button>
                    `).join('')}
                </div>
            </div>

            <div id="cb-rm-popover-scroll" class="cb-rm-popover">
                <div class="cb-rm-pop-row">
                    <span class="cb-rm-pop-label">Rolagem automática</span>
                    <button id="cb-rm-scroll-toggle" class="cb-rm-play-btn">${ICON_PLAY}</button>
                </div>
                <div class="cb-rm-pop-row cb-rm-pop-row-col">
                    <span class="cb-rm-pop-label">Velocidade</span>
                    <input id="cb-rm-scroll-speed" type="range" min="10" max="200" step="5">
                </div>
            </div>

            <div id="cb-rm-popover-tts" class="cb-rm-popover">
                <div class="cb-rm-pop-row">
                    <span class="cb-rm-pop-label">Ouvir texto</span>
                    <button id="cb-rm-tts-toggle" class="cb-rm-play-btn">${ICON_PLAY}</button>
                </div>
                <div class="cb-rm-pop-row cb-rm-pop-row-col">
                    <span class="cb-rm-pop-label">Voz</span>
                    <select id="cb-rm-tts-voz" class="cb-rm-select"></select>
                </div>
                <div class="cb-rm-pop-row cb-rm-pop-row-col">
                    <span class="cb-rm-pop-label">Velocidade</span>
                    <input id="cb-rm-tts-rate" type="range" min="0.6" max="2" step="0.1">
                </div>
                <div id="cb-rm-tts-progresso" class="cb-rm-busca-contador"></div>
            </div>

            <div id="cb-rm-body"><div id="cb-rm-content"></div></div>

            <div id="cb-rm-mapa-modal" class="cb-rm-mapa-modal">
                <div class="cb-rm-mapa-modal-inner">
                    <div class="cb-rm-mapa-modal-header">
                        <span class="cb-rm-pop-title">Mapa mental da lei</span>
                        <button id="cb-rm-mapa-fechar" class="cb-rm-rail-btn">${ICON_CLOSE}</button>
                    </div>
                    <div id="cb-rm-mapa-corpo" class="cb-rm-mapa-corpo">Gerando mapa…</div>
                </div>
            </div>
        `;
        document.body.appendChild(overlay);

        // -------- popovers --------
        const btnAa = overlay.querySelector('#cb-rm-btn-aa');
        const btnTheme = overlay.querySelector('#cb-rm-btn-theme');
        const btnScroll = overlay.querySelector('#cb-rm-btn-scroll');
        const btnBusca = overlay.querySelector('#cb-rm-btn-busca');
        const popAa = overlay.querySelector('#cb-rm-popover-aa');
        const popTheme = overlay.querySelector('#cb-rm-popover-theme');
        const popScroll = overlay.querySelector('#cb-rm-popover-scroll');
        const popBusca = overlay.querySelector('#cb-rm-popover-busca');
        const btnTts = overlay.querySelector('#cb-rm-btn-tts');
        const popTts = overlay.querySelector('#cb-rm-popover-tts');
        const todosBotoes = [
            [btnAa, popAa], [btnTheme, popTheme], [btnScroll, popScroll], [btnBusca, popBusca], [btnTts, popTts]
        ];

        function fecharPopovers() {
            todosBotoes.forEach(([btn, pop]) => {
                pop.classList.remove('cb-rm-pop-open');
                btn.classList.remove('cb-rm-rail-btn-ativo');
            });
        }
        todosBotoes.forEach(([btn, pop]) => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const abrir = !pop.classList.contains('cb-rm-pop-open');
                fecharPopovers();
                if (abrir) {
                    pop.classList.add('cb-rm-pop-open');
                    btn.classList.add('cb-rm-rail-btn-ativo');
                    if (pop === popBusca) setTimeout(() => overlay.querySelector('#cb-rm-busca-input')?.focus(), 30);
                }
            });
        });
        overlay.querySelector('#cb-rm-body').addEventListener('mousedown', (e) => {
            // não fecha se o clique for dentro de uma <mark> ou seleção de
            // texto — deixa o marcador de texto (highlighter.js) cuidar disso.
            fecharPopovers();
        });

        overlay.querySelector('#cb-rm-close').addEventListener('click', fecharOverlay);

        // ---- Buscar palavra-chave (só existe aqui dentro do Modo de Leitura) ----
        let ultimoTermoBuscadoRM = '';
        function contarOcorrenciasRM(termo) {
            if (!termo) return 0;
            const corpo = overlay.querySelector('#cb-rm-content');
            const texto = (corpo && corpo.innerText) || '';
            const escapado = termo.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            try { return (texto.match(new RegExp(escapado, 'gi')) || []).length; } catch (e) { return 0; }
        }
        function atualizarContadorBuscaRM() {
            const input = overlay.querySelector('#cb-rm-busca-input');
            const contador = overlay.querySelector('#cb-rm-busca-contador');
            const termo = input.value.trim();
            if (!termo) { contador.textContent = ''; return; }
            const total = contarOcorrenciasRM(termo);
            contador.textContent = total ? `${total} ocorrência${total === 1 ? '' : 's'}` : 'nada encontrado';
        }
        function buscarRM(voltar) {
            const input = overlay.querySelector('#cb-rm-busca-input');
            const termo = input.value.trim();
            if (!termo) return;
            if (termo !== ultimoTermoBuscadoRM) window.getSelection().removeAllRanges();
            ultimoTermoBuscadoRM = termo;
            const achou = window.find(termo, false, !!voltar, true, false, true, false);
            const contador = overlay.querySelector('#cb-rm-busca-contador');
            if (!achou) contador.textContent = 'nada encontrado';
            else atualizarContadorBuscaRM();
        }
        const buscaInputRM = overlay.querySelector('#cb-rm-busca-input');
        buscaInputRM.addEventListener('input', atualizarContadorBuscaRM);
        buscaInputRM.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') { e.preventDefault(); buscarRM(e.shiftKey); }
            e.stopPropagation(); // não deixa o Esc do input fechar o Modo de Leitura sem querer
        });
        overlay.querySelector('#cb-rm-busca-anterior').addEventListener('click', () => buscarRM(true));
        overlay.querySelector('#cb-rm-busca-proximo').addEventListener('click', () => buscarRM(false));

        overlay.querySelector('#cb-rm-font-minus').addEventListener('click', () => ajustarFonte(-1));
        overlay.querySelector('#cb-rm-font-plus').addEventListener('click', () => ajustarFonte(1));
        overlay.querySelector('#cb-rm-fonte-select').addEventListener('change', (e) => {
            fonteAtual = e.target.value;
            aplicarEstilos();
            salvarPrefs();
        });
        overlay.querySelectorAll('.cb-rm-corfonte-sw').forEach(btn => {
            btn.addEventListener('click', () => {
                corFonte = btn.dataset.cor;
                aplicarEstilos();
                salvarPrefs();
            });
        });
        overlay.querySelector('#cb-rm-line-height').addEventListener('input', (e) => {
            lineHeight = parseFloat(e.target.value);
            aplicarEstilos();
        });
        overlay.querySelector('#cb-rm-line-height').addEventListener('change', salvarPrefs);
        overlay.querySelector('#cb-rm-content-width').addEventListener('input', (e) => {
            contentWidth = parseInt(e.target.value, 10);
            aplicarEstilos();
        });
        overlay.querySelector('#cb-rm-content-width').addEventListener('change', salvarPrefs);
        overlay.querySelector('#cb-rm-letter-spacing').addEventListener('input', (e) => {
            letterSpacing = parseFloat(e.target.value);
            aplicarEstilos();
        });
        overlay.querySelector('#cb-rm-letter-spacing').addEventListener('change', salvarPrefs);
        overlay.querySelector('#cb-rm-word-spacing').addEventListener('input', (e) => {
            wordSpacing = parseFloat(e.target.value);
            aplicarEstilos();
        });
        overlay.querySelector('#cb-rm-word-spacing').addEventListener('change', salvarPrefs);
        overlay.querySelectorAll('.cb-rm-align-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                textAlign = btn.dataset.align;
                aplicarEstilos();
                salvarPrefs();
            });
        });
        const advToggle = overlay.querySelector('#cb-rm-advanced-toggle');
        const advBody = overlay.querySelector('#cb-rm-advanced-body');
        advToggle.addEventListener('click', () => {
            const abrir = !advBody.classList.contains('cb-rm-advanced-open');
            advBody.classList.toggle('cb-rm-advanced-open', abrir);
            advToggle.classList.toggle('cb-rm-advanced-open', abrir);
        });
        overlay.querySelector('#cb-rm-restaurar-padrao').addEventListener('click', () => {
            fontSize = PADRAO.fontSize;
            temaAtual = PADRAO.temaAtual;
            fonteAtual = PADRAO.fonteAtual;
            lineHeight = PADRAO.lineHeight;
            contentWidth = PADRAO.contentWidth;
            letterSpacing = PADRAO.letterSpacing;
            wordSpacing = PADRAO.wordSpacing;
            textAlign = PADRAO.textAlign;
            corFonte = PADRAO.corFonte;
            aplicarEstilos();
            salvarPrefs();
        });
        overlay.querySelectorAll('.cb-rm-theme-swatch').forEach(btn => {
            btn.addEventListener('click', () => {
                temaAtual = btn.dataset.tema;
                aplicarEstilos();
                salvarPrefs();
            });
        });

        overlay.querySelector('#cb-rm-scroll-toggle').addEventListener('click', () => {
            autoScrollAtivo ? pararAutoScroll() : iniciarAutoScroll();
        });
        overlay.querySelector('#cb-rm-scroll-speed').addEventListener('input', (e) => {
            autoScrollVelocidade = parseInt(e.target.value, 10);
        });
        overlay.querySelector('#cb-rm-scroll-speed').addEventListener('change', salvarPrefs);

        // ---- Ouvir em voz alta (Web Speech API nativa, sem rede) ----
        overlay.querySelector('#cb-rm-tts-toggle').addEventListener('click', () => {
            if (!ttsAtivo) iniciarLeituraTTS();
            else pausarRetomarTTS();
        });
        const ttsRateInput = overlay.querySelector('#cb-rm-tts-rate');
        ttsRateInput.value = ttsRate;
        ttsRateInput.addEventListener('input', (e) => { ttsRate = parseFloat(e.target.value); });
        ttsRateInput.addEventListener('change', salvarPrefs);
        overlay.querySelector('#cb-rm-tts-voz').addEventListener('change', (e) => {
            ttsVoiceURI = e.target.value;
            salvarPrefs();
        });
        popularVozesTTS();
        if ('speechSynthesis' in window) {
            window.speechSynthesis.onvoiceschanged = popularVozesTTS;
        }
        btnTts.addEventListener('click', popularVozesTTS);

        // ---- Mapa mental (Mermaid.js) ----
        overlay.querySelector('#cb-rm-btn-mapa').addEventListener('click', (e) => {
            e.stopPropagation();
            fecharPopovers();
            abrirMapaMental();
        });
        overlay.querySelector('#cb-rm-mapa-fechar').addEventListener('click', fecharMapaMental);

        // qualquer scroll manual do usuário pausa a rolagem automática
        overlay.querySelector('#cb-rm-body').addEventListener('wheel', () => { if (autoScrollAtivo) pararAutoScroll(); }, { passive: true });
        overlay.querySelector('#cb-rm-body').addEventListener('touchstart', () => { if (autoScrollAtivo) pararAutoScroll(); }, { passive: true });
    }

    function moverConteudoRealParaOverlay() {
        if (!containerReal) {
            const resultado = encontrarContainerDaLei();
            containerReal = resultado.elemento;
            containerFoiEnvolvido = resultado.envolvido;
        }
        containerPaiOriginal = containerReal.parentNode;
        containerIrmaoSeguinte = containerReal.nextSibling;
        overlay.querySelector('#cb-rm-content').appendChild(containerReal);
        containerReal.classList.add('cb-rm-container-ativo');
    }

    function devolverConteudoRealAoLugar() {
        if (!containerReal || !containerPaiOriginal) return;
        containerReal.classList.remove('cb-rm-container-ativo');

        if (containerFoiEnvolvido) {
            // Desfaz o wrapper artificial: devolve os filhos originais direto
            // pro lugar de antes, sem deixar a <div id="cb-rm-auto-wrapper">
            // extra na página (evita mudar a estrutura do DOM original, que
            // o CSS da própria página do Planalto pode depender).
            const frag = document.createDocumentFragment();
            while (containerReal.firstChild) frag.appendChild(containerReal.firstChild);
            if (containerIrmaoSeguinte && containerIrmaoSeguinte.parentNode === containerPaiOriginal) {
                containerPaiOriginal.insertBefore(frag, containerIrmaoSeguinte);
            } else {
                containerPaiOriginal.appendChild(frag);
            }
            containerReal.remove();
            // força uma nova detecção limpa na próxima abertura, já que este
            // wrapper não existe mais.
            containerReal = null;
            containerFoiEnvolvido = false;
            return;
        }

        if (containerIrmaoSeguinte && containerIrmaoSeguinte.parentNode === containerPaiOriginal) {
            containerPaiOriginal.insertBefore(containerReal, containerIrmaoSeguinte);
        } else {
            containerPaiOriginal.appendChild(containerReal);
        }
    }

    function ajustarFonte(delta) {
        fontSize = Math.min(FONT_MAX, Math.max(FONT_MIN, fontSize + delta));
        aplicarEstilos();
        salvarPrefs();
    }

    function aplicarEstilos() {
        const contentBox = overlay.querySelector('#cb-rm-content');
        contentBox.style.setProperty('--cb-rm-font-size', fontSize + 'px');
        contentBox.style.setProperty('--cb-rm-line-height', String(lineHeight));
        contentBox.style.setProperty('--cb-rm-font-family', (FONTES.find(f => f.id === fonteAtual) || FONTES[0]).css);
        contentBox.style.setProperty('--cb-rm-content-width', contentWidth + 'px');
        contentBox.style.setProperty('--cb-rm-letter-spacing', letterSpacing + 'em');
        contentBox.style.setProperty('--cb-rm-word-spacing', wordSpacing + 'em');
        contentBox.style.setProperty('--cb-rm-text-align', textAlign);
        const corSelecionada = CORES_FONTE.find(c => c.id === corFonte);
        contentBox.style.setProperty('--cb-rm-text-color', (corSelecionada && corSelecionada.hex) ? corSelecionada.hex : 'inherit');
        overlay.querySelector('#cb-rm-line-height').value = lineHeight;
        overlay.querySelector('#cb-rm-fonte-select').value = fonteAtual;
        overlay.querySelector('#cb-rm-scroll-speed').value = autoScrollVelocidade;
        overlay.querySelector('#cb-rm-content-width').value = contentWidth;
        overlay.querySelector('#cb-rm-letter-spacing').value = letterSpacing;
        overlay.querySelector('#cb-rm-word-spacing').value = wordSpacing;
        overlay.querySelectorAll('.cb-rm-align-btn').forEach(b => {
            b.classList.toggle('cb-rm-align-btn-ativo', b.dataset.align === textAlign);
        });
        overlay.querySelectorAll('.cb-rm-corfonte-sw').forEach(b => {
            b.classList.toggle('cb-rm-corfonte-ativa', b.dataset.cor === corFonte);
        });

        let temaResolvido = temaAtual;
        if (temaAtual === 'auto') {
            temaResolvido = window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches ? 'claro' : 'escuro';
        }
        overlay.setAttribute('data-tema', temaResolvido);
        overlay.querySelectorAll('.cb-rm-theme-swatch').forEach(b => {
            b.classList.toggle('cb-rm-theme-swatch-ativo', b.dataset.tema === temaAtual);
        });
    }

    // -------------------- rolagem automática --------------------
    function tickAutoScroll(ts) {
        if (!autoScrollAtivo) return;
        if (autoScrollUltimoTs == null) autoScrollUltimoTs = ts;
        const deltaS = (ts - autoScrollUltimoTs) / 1000;
        autoScrollUltimoTs = ts;
        const corpo = overlay.querySelector('#cb-rm-body');
        corpo.scrollTop += autoScrollVelocidade * deltaS;

        // chegou ao fim: para sozinho
        if (corpo.scrollTop + corpo.clientHeight >= corpo.scrollHeight - 2) {
            pararAutoScroll();
            return;
        }
        autoScrollRAF = requestAnimationFrame(tickAutoScroll);
    }
    function iniciarAutoScroll() {
        autoScrollAtivo = true;
        autoScrollUltimoTs = null;
        overlay.querySelector('#cb-rm-scroll-toggle').innerHTML = ICON_PAUSE;
        overlay.querySelector('#cb-rm-btn-scroll').classList.add('cb-rm-rail-btn-ativo');
        autoScrollRAF = requestAnimationFrame(tickAutoScroll);
    }
    function pararAutoScroll() {
        autoScrollAtivo = false;
        if (autoScrollRAF) cancelAnimationFrame(autoScrollRAF);
        autoScrollRAF = null;
        if (overlay) {
            const btn = overlay.querySelector('#cb-rm-scroll-toggle');
            if (btn) btn.innerHTML = ICON_PLAY;
            const rail = overlay.querySelector('#cb-rm-btn-scroll');
            if (rail) rail.classList.remove('cb-rm-rail-btn-ativo');
        }
    }

    // Zera o scroll do #cb-rm-body repetidamente por alguns frames seguidos
    // (em vez de só 1-2 vezes). Leis grandes (CPC) levam mais de um frame
    // pra terminar o reflow depois que o container real é movido pro
    // overlay, e o scroll anchoring do navegador pode reposicionar a
    // rolagem nesse meio-tempo — insistir por mais frames cobre essa
    // janela. Também força overflow-anchor:none via inline style, como
    // reforço caso algo sobrescreva a regra do CSS.
    function forcarTopoPorVariosFrames() {
        const corpo = overlay.querySelector('#cb-rm-body');
        corpo.style.overflowAnchor = 'none';
        const conteudo = overlay.querySelector('#cb-rm-content');
        if (conteudo) conteudo.style.overflowAnchor = 'none';

        let tentativas = 0;
        const MAX_TENTATIVAS = 12; // cobre bem mais que os 2 frames de antes
        function tick() {
            corpo.scrollTop = 0;
            tentativas++;
            if (tentativas < MAX_TENTATIVAS) requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
        // reforço final depois que o navegador certamente já terminou
        // qualquer reflow pendente (fontes, reposicionamento, etc.)
        setTimeout(() => { corpo.scrollTop = 0; }, 300);
    }

    function abrirOverlay() {
        const jaExiste = !!overlay;
        const finalizarAbertura = () => {
            try {
                if (!jaExiste) montarOverlay();
                moverConteudoRealParaOverlay();
                aplicarEstilos();
                overlay.style.display = 'flex';
                document.documentElement.style.overflow = 'hidden';
                // Garante que sempre abre no topo do texto (Art. 1º), mesmo que
                // o navegador tente "compensar" a mudança de altura do conteúdo
                // (badges/grifos inseridos) reposicionando a rolagem sozinho.
                //
                // Em leis grandes (ex.: o CPC, com milhares de elementos e
                // marcas) o reflow de mover o container real pra dentro do
                // overlay não termina num único frame — um reset em apenas
                // 1-2 rAFs às vezes ainda "perde a corrida" contra o scroll
                // anchoring nativo do navegador, que escolhe um elemento
                // qualquer já visível como referência e reposiciona a
                // rolagem em cima dele no meio do reflow (foi o que abria a
                // página sempre na altura dos arts. 54-56 no CPC). Por isso
                // o reset agora insiste por vários frames seguidos, cobrindo
                // esse reflow maior.
                forcarTopoPorVariosFrames();
            } catch (e) {
                console.error('[Modo de Leitura] Falha ao abrir:', e);
            }
        };
        scrollYAntesDoModoLeitura = window.scrollY;
        if (!jaExiste) carregarPrefs(finalizarAbertura);
        else finalizarAbertura();
    }
    function fecharOverlay() {
        pararAutoScroll();
        pararLeituraTTS();
        devolverConteudoRealAoLugar();
        if (overlay) overlay.style.display = 'none';
        document.documentElement.style.overflow = '';
        // Ao devolver o texto real pro lugar, a altura da página muda de
        // forma abrupta (o conteúdo "sai" e "volta") e o navegador pode
        // deixar a rolagem numa posição estranha (ex: perto do fim da lei,
        // com um vão em branco em cima). Restaura explicitamente pra onde
        // a pessoa estava antes de abrir o Modo de Leitura.
        requestAnimationFrame(() => {
            window.scrollTo(0, scrollYAntesDoModoLeitura || 0);
        });
    }

    document.addEventListener('keydown', (e) => {
        if (e.key !== 'Escape' || !overlay || overlay.style.display === 'none') return;
        const modalMapa = overlay.querySelector('#cb-rm-mapa-modal');
        if (modalMapa && modalMapa.classList.contains('cb-rm-mapa-aberto')) { fecharMapaMental(); return; }
        fecharOverlay();
    });

    function criarBotaoFlutuante() {
        const btn = document.createElement('button');
        btn.id = 'cb-rm-toggle';
        btn.title = 'Abrir Modo de Leitura';
        btn.innerHTML = ICON_BOOK;
        btn.addEventListener('click', abrirOverlay);
        document.body.appendChild(btn);
    }

    function iniciar() {
        criarBotaoFlutuante();
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', iniciar);
    } else {
        iniciar();
    }
})();
