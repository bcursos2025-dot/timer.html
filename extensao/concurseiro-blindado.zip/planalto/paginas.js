// paginas.js — Central de Páginas do Marcador de Texto.
// Lista todas as leis do Planalto onde já existem grifos salvos,
// permite abrir, apagar, buscar e ordenar, e mostra o uso de armazenamento.

const STORAGE_PREFIX = 'cbHighlights::';

const ICON_OPEN = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>';
const ICON_TRASH = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>';

let paginasCache = [];

async function carregarTudo() {
    const tudo = await chrome.storage.local.get(null);
    const paginas = Object.keys(tudo)
        .filter((k) => k.startsWith(STORAGE_PREFIX))
        .map((k) => {
            const lista = tudo[k] || [];
            const url = k.slice(STORAGE_PREFIX.length);
            const titulo = lista.length ? (lista[0].titulo || url) : url;
            const ultimaAtualizacao = lista.reduce((max, g) => Math.max(max, g.criadoEm || 0), 0);
            const cores = [...new Set(lista.map(g => g.cor))];
            return { key: k, url, titulo, quantidade: lista.length, ultimaAtualizacao, cores };
        })
        .filter((p) => p.quantidade > 0);
    return paginas;
}

function formatarData(ts) {
    if (!ts) return '—';
    const d = new Date(ts);
    return d.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' });
}

function renderizar(paginas) {
    const container = document.getElementById('cbp-list');
    const empty = document.getElementById('cbp-empty');
    container.innerHTML = '';

    if (!paginas.length) {
        empty.style.display = 'block';
        return;
    }
    empty.style.display = 'none';

    paginas.forEach((p) => {
        const card = document.createElement('div');
        card.className = 'cbp-card';
        card.innerHTML = `
            <div class="cbp-card-body">
                <div class="cbp-card-title">${escapeHtml(p.titulo)}</div>
                <div class="cbp-card-url">${escapeHtml(p.url)}</div>
                <div class="cbp-card-meta">
                    <span>${p.quantidade} destaque${p.quantidade === 1 ? '' : 's'}</span>
                    <span>${formatarData(p.ultimaAtualizacao)}</span>
                    <span class="cbp-card-dots">${p.cores.map(c => `<span class="cbp-card-dot" style="background:${c}"></span>`).join('')}</span>
                </div>
            </div>
            <div class="cbp-card-actions">
                <button class="cbp-icon-btn" data-acao="abrir" title="Abrir página">${ICON_OPEN}</button>
                <button class="cbp-icon-btn cbp-danger" data-acao="excluir" title="Apagar todos os grifos desta página">${ICON_TRASH}</button>
            </div>
        `;
        card.querySelector('.cbp-card-body').addEventListener('click', () => window.open(p.url, '_blank'));
        card.querySelector('[data-acao="abrir"]').addEventListener('click', () => window.open(p.url, '_blank'));
        card.querySelector('[data-acao="excluir"]').addEventListener('click', async () => {
            if (!confirm(`Apagar todos os ${p.quantidade} grifos de "${p.titulo}"? Essa ação não pode ser desfeita.`)) return;
            await chrome.storage.local.remove(p.key);
            await atualizarTudo();
        });
        container.appendChild(card);
    });
}

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
}

function aplicarFiltroOrdenacao() {
    const termo = document.getElementById('cbp-search').value.trim().toLowerCase();
    const ordenar = document.getElementById('cbp-sort').value;

    let filtradas = paginasCache.filter((p) =>
        !termo || p.titulo.toLowerCase().includes(termo) || p.url.toLowerCase().includes(termo)
    );

    if (ordenar === 'recent') filtradas.sort((a, b) => b.ultimaAtualizacao - a.ultimaAtualizacao);
    else if (ordenar === 'count') filtradas.sort((a, b) => b.quantidade - a.quantidade);
    else if (ordenar === 'title') filtradas.sort((a, b) => a.titulo.localeCompare(b.titulo, 'pt-BR'));

    renderizar(filtradas);
}

async function atualizarStorageBar() {
    chrome.storage.local.getBytesInUse(null, (bytes) => {
        const kb = (bytes / 1024).toFixed(1);
        document.getElementById('cbp-storage-text').textContent = `${kb} KB usados`;
        // unlimitedStorage está ativo na extensão, então não há um teto fixo
        // real — usamos 5MB como referência visual só pra dar noção de escala.
        const pct = Math.min(100, (bytes / (5 * 1024 * 1024)) * 100);
        document.getElementById('cbp-storage-fill').style.width = pct + '%';
    });
}

async function atualizarTudo() {
    paginasCache = await carregarTudo();
    aplicarFiltroOrdenacao();
    atualizarStorageBar();
}

document.getElementById('cbp-search').addEventListener('input', aplicarFiltroOrdenacao);
document.getElementById('cbp-sort').addEventListener('change', aplicarFiltroOrdenacao);

atualizarTudo();
