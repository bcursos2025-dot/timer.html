// ============================================================================
// comunidade.js — Painel do ARTIGO, na página normal do Planalto (fora do Modo de Leitura). Clica em "Art. N" e abre,
// deslizando da esquerda, um painel com duas abas, as duas REAIS:
//
//   1. Jurisprudência       — súmulas, teses, repercussão geral, repetitivos e posicionamentos do STJ sobre o artigo,
//                             buscados no Corpus927 (ENFAM) só quando você clica (ver corpus927.js e
//                             dados-config/corpus927-bg.js). A Constituição e leis fora do Corpus927 mostram um aviso.
//   2. Meu caderno de erros — o que fica salvo só no seu navegador (chrome.storage.local, por artigo): as questões que você
//                             errou citando este artigo (vindas do QConcursos, ver dados-config/artigos-erros-store.js) e
//                             suas próprias anotações.
//
// (Este arquivo já foi o painel "Comunidade", com abas de discussão e grifos populares SIMULADAS, sem servidor e sem outros
// usuários. Foram removidas: nada aqui finge ser de outras pessoas. O nome do arquivo e as classes cb-com-* ficaram.)
// ============================================================================
(function () {
    if (window.__cbComunidadeLoaded) return;
    window.__cbComunidadeLoaded = true;

    const ICON_CLOSE = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
    const ICON_ARTIGO = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>';
    const ICON_LIVRO_ERRO = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>';
    const ICON_TRASH = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>';

    const NOMES_LEI = { l13105: 'CPC', cf88: 'Constituição Federal', l10406: 'Código Civil', l5172: 'CTN', l6830: 'LEF', l2848: 'Código Penal', l3689: 'CPP', l8078: 'CDC', l5452: 'CLT', l8112: 'Lei 8.112/90', l8429: 'Improbidade' };
    function nomeLei(lei) { return NOMES_LEI[lei] || (lei || '').toUpperCase(); }

    // --------------------------------------------------------------------
    // Caderno de erros — salvo em chrome.storage.local por artigo.
    // Chave: cbErros::{lei}:{numero} → [{ id, texto, criadoEm }]
    // --------------------------------------------------------------------
    const chaveErros = (lei, numero) => `cbErros::${lei}:${numero}`;
    function carregarErros(lei, numero) {
        return new Promise((resolve) => {
            chrome.storage.local.get([chaveErros(lei, numero)], (r) => resolve((r && r[chaveErros(lei, numero)]) || []));
        });
    }
    async function salvarErro(lei, numero, texto) {
        const lista = await carregarErros(lei, numero);
        lista.unshift({ id: Date.now() + '-' + Math.random().toString(36).slice(2, 7), texto, criadoEm: Date.now() });
        await new Promise((resolve) => chrome.storage.local.set({ [chaveErros(lei, numero)]: lista }, resolve));
        return lista;
    }
    async function excluirErro(lei, numero, id) {
        const lista = (await carregarErros(lei, numero)).filter((e) => e.id !== id);
        await new Promise((resolve) => chrome.storage.local.set({ [chaveErros(lei, numero)]: lista }, resolve));
        return lista;
    }

    // Questões do QConcursos que você errou e que citam este artigo (pendentes + já salvas na revisão).
    async function questoesErradas(lei, numero, sufixo) {
        const Store = window.CBArtigosStore;
        if (!Store || !Store.ler) return [];
        try {
            const est = await Store.ler();
            const vistas = new Map();
            [].concat(est.revisao || [], est.pendentes || []).forEach((it) => {
                if (!it || it.lei !== lei || String(it.artigo) !== String(numero) || (it.sufixo || '') !== (sufixo || '')) return;
                (it.origens || []).forEach((o) => { if (o && o.questaoId && !vistas.has(o.questaoId)) vistas.set(o.questaoId, o); });
            });
            return Array.from(vistas.values()).sort((a, b) => (b.em || 0) - (a.em || 0));
        } catch (e) { return []; }
    }

    function escapeHtml(s) {
        const div = document.createElement('div');
        div.textContent = s == null ? '' : s;
        return div.innerHTML;
    }
    function formatarData(ts) {
        const d = new Date(ts);
        return d.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' }) + ' às ' +
               d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    }

    // --------------------------------------------------------------------
    // Painel
    // --------------------------------------------------------------------
    let painel = null;
    let leiAtual = null, numeroAtual = null, sufixoAtual = '';
    let abaAtiva = 'juris';
    let pedido = 0;      // descarta resposta atrasada se a pessoa já abriu outro artigo

    function montarPainel() {
        painel = document.createElement('div');
        painel.id = 'cb-com-painel';
        painel.innerHTML = `
            <div class="cb-com-header">
                <div class="cb-com-titulo-wrap">
                    <span class="cb-com-icone">${ICON_ARTIGO}</span>
                    <div>
                        <div class="cb-com-titulo">Artigo</div>
                        <div class="cb-com-subtitulo" id="cb-com-subtitulo"></div>
                    </div>
                </div>
                <button id="cb-com-fechar" class="cb-com-fechar-btn" title="Fechar">${ICON_CLOSE}</button>
            </div>
            <div class="cb-com-abas">
                <button class="cb-com-aba" data-aba="juris">Jurisprudência</button>
                <button class="cb-com-aba" data-aba="erros">Meu caderno de erros</button>
            </div>
            <div id="cb-com-corpo" class="cb-com-corpo"></div>
        `;
        document.body.appendChild(painel);
        painel.querySelector('#cb-com-fechar').addEventListener('click', fecharPainel);
        painel.querySelectorAll('.cb-com-aba').forEach((btn) => {
            btn.addEventListener('click', () => {
                abaAtiva = btn.dataset.aba;
                atualizarAbaAtiva();
                renderizarCorpo();
            });
        });
    }

    function atualizarAbaAtiva() {
        painel.querySelectorAll('.cb-com-aba').forEach((b) => b.classList.toggle('cb-com-aba-ativa', b.dataset.aba === abaAtiva));
    }

    function renderizarErros(lista, questoes) {
        const listaHtml = !lista.length
            ? `<div class="cb-com-erros-vazio">${ICON_LIVRO_ERRO}<p>Nenhuma anotação sua para este artigo ainda.</p></div>`
            : lista.map((e) => `
                <div class="cb-com-erro-item" data-id="${e.id}">
                    <div class="cb-com-erro-texto">${escapeHtml(e.texto)}</div>
                    <div class="cb-com-erro-rodape">
                        <span class="cb-com-erro-data">${formatarData(e.criadoEm)}</span>
                        <button class="cb-com-erro-excluir" data-id="${e.id}" title="Excluir">${ICON_TRASH}</button>
                    </div>
                </div>
            `).join('');
        const qHtml = questoes.length ? `
            <div class="cb-com-aviso-real">Questões do QConcursos que você errou citando este artigo (${questoes.length}):</div>
            <div class="cb-com-erros-lista">${questoes.map((q) => `
                <div class="cb-com-erro-item">
                    <div class="cb-com-erro-texto">${q.questaoUrl ? `<a href="${escapeHtml(q.questaoUrl)}" target="_blank" rel="noopener">${escapeHtml(q.questaoId)}</a>` : escapeHtml(q.questaoId)}${q.materia ? ' · ' + escapeHtml(q.materia) : ''}${q.assunto ? '<br><small>' + escapeHtml(q.assunto) + '</small>' : ''}</div>
                    ${q.em ? `<div class="cb-com-erro-rodape"><span class="cb-com-erro-data">${formatarData(q.em)}</span></div>` : ''}
                </div>`).join('')}</div>` : '';
        return `
            ${qHtml}
            <div class="cb-com-aviso-real">Suas anotações: ficam salvas só no seu navegador, por artigo.</div>
            <div class="cb-com-erro-form">
                <textarea id="cb-com-erro-input" class="cb-com-input" placeholder="Anote aqui o que errou ou quer lembrar sobre este artigo..." rows="3"></textarea>
                <button id="cb-com-erro-salvar" class="cb-com-enviar-btn">Salvar anotação</button>
            </div>
            <div class="cb-com-erros-lista">${listaHtml}</div>
        `;
    }

    async function montarErros(corpo) {
        const meu = ++pedido;
        corpo.innerHTML = '<div class="cb-com-carregando">Carregando…</div>';
        const [lista, questoes] = await Promise.all([carregarErros(leiAtual, numeroAtual), questoesErradas(leiAtual, numeroAtual, sufixoAtual)]);
        if (meu !== pedido) return;
        const desenhar = (l) => {
            corpo.innerHTML = renderizarErros(l, questoes);
            corpo.querySelector('#cb-com-erro-salvar').addEventListener('click', async () => {
                const input = corpo.querySelector('#cb-com-erro-input');
                const texto = input.value.trim();
                if (!texto) return;
                desenhar(await salvarErro(leiAtual, numeroAtual, texto));
            });
            corpo.querySelectorAll('.cb-com-erro-excluir').forEach((btn) => {
                btn.addEventListener('click', async () => desenhar(await excluirErro(leiAtual, numeroAtual, btn.dataset.id)));
            });
        };
        desenhar(lista);
    }

    async function montarJuris(corpo) {
        const meu = ++pedido;
        if (!window.CBCorpus927) { corpo.innerHTML = '<div class="cb-c9-aviso">O módulo de jurisprudência não carregou nesta página.</div>'; return; }
        corpo.innerHTML = '<div class="cb-c9-carregando">Buscando no Corpus927…</div>';
        const r = await window.CBCorpus927.carregar(numeroAtual, sufixoAtual);
        if (meu !== pedido) return;
        if (r.indisponivel) corpo.innerHTML = `<div class="cb-c9-aviso">${escapeHtml(r.indisponivel)}</div>`;
        else if (r.erro) corpo.innerHTML = `<div class="cb-c9-aviso">Não consegui buscar agora: ${escapeHtml(r.erro)}.</div>`;
        else corpo.innerHTML = r.html;
    }

    function renderizarCorpo() {
        const corpo = painel.querySelector('#cb-com-corpo');
        if (abaAtiva === 'erros') montarErros(corpo); else montarJuris(corpo);
    }

    function abrirPainel(lei, numero, sufixo) {
        if (!painel) montarPainel();
        leiAtual = lei;
        numeroAtual = numero;
        sufixoAtual = sufixo || '';
        painel.querySelector('#cb-com-subtitulo').textContent = `Art. ${numero}${sufixoAtual ? '-' + sufixoAtual : ''} — ${nomeLei(lei)}`;
        atualizarAbaAtiva();
        renderizarCorpo();
        requestAnimationFrame(() => painel.classList.add('cb-com-aberto'));
    }

    function fecharPainel() {
        if (painel) painel.classList.remove('cb-com-aberto');
    }

    document.addEventListener('click', (e) => {
        // Reage SÓ quando o clique NÃO está dentro do Modo de Leitura (lá quem responde é o jurisprudencia.js).
        const overlay = e.target.closest('#cb-reading-mode-overlay');
        if (overlay && overlay.style.display !== 'none') return;

        // o martelinho que o Planalto põe antes de cada artigo: em vez de abrir o Corpus927 em outra aba, abre o painel aqui
        const martelo = e.target.closest('a.c927');
        if (martelo && window.CBCorpus927 && window.CBArtigos) {
            const info = window.CBCorpus927.artigoDoLink(martelo.getAttribute('href'));
            const lei = window.CBArtigos.detectarLei();
            if (info && lei) { e.preventDefault(); abrirPainel(lei, info.numero, info.sufixo); return; }
        }

        const ref = e.target.closest('.cb-art-ref');
        if (!ref) return;

        const numero = ref.getAttribute('data-cb-art-num');
        const lei = ref.getAttribute('data-cb-art-lei');
        if (!numero || !lei) return;

        const sufixo = window.CBCorpus927 ? window.CBCorpus927.sufixoDoRef(ref) : '';
        abrirPainel(lei, numero, sufixo);
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && painel && painel.classList.contains('cb-com-aberto')) fecharPainel();
    });
})();
