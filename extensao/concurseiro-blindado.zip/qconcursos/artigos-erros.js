// ============================================================================
// artigos-erros.js — Roda no qconcursos.com. Quando a pessoa ERRA uma questão e
// o Gabarito Comentado / os Comentários trazem artigos de lei ("CPC, art. 279,
// caput"), guarda esses artigos como PENDENTES. Na página da lei, no Planalto,
// o painel (planalto/artigos-erros.js) mostra o que ficou pendente: a pessoa vê,
// confirma e o artigo vai para a revisão espaçada.
//
// Como detecta (estrutura conferida na página do QConcursos):
//   .q-question-item            — a questão inteira (enunciado + abas)
//     .q-question               — enunciado, alternativas, resultado
//       .q-id a                 — "Q4350021" (e o link da questão)
//       .q-question-breadcrumb  — disciplina e assuntos
//       .js-response-wrong      — o aviso "Incorreta. Gabarito oficial…" (só visível se errou)
//     .q-question-belt          — as abas
//       #question-belt-<id>-teacher-tab  — Gabarito Comentado (do professor)
//       #question-belt-<id>-comments-tab — Comentários (carregam só quando a aba é aberta)
//
// Só lê o que já está na tela da própria pessoa, só guarda o número do artigo e
// a questão de origem (não copia o texto dos comentários) e nada sai do navegador.
// Pode ser desligado em Configurações → Artigos da lei.
// ============================================================================
(function () {
    'use strict';
    if (window.__cbArtigosErrosQC) return;
    window.__cbArtigosErrosQC = true;

    const Ref = window.CBRefArtigos;
    const Store = window.CBArtigosStore;
    if (!Ref || !Store) return;

    let ativo = true;
    Store.ler().then((s) => { ativo = s.ativo; });
    try {
        chrome.storage.onChanged.addListener((mud, area) => {
            if (area === 'local' && mud[Store.K_ATIVO]) ativo = mud[Store.K_ATIVO].newValue !== false;
        });
    } catch (e) { /* sem storage: segue ligado */ }

    // ------------------------------------------------------------------ leitura da questão
    function visivel(el) {
        if (!el) return false;
        if (el.offsetParent === null && getComputedStyle(el).position !== 'fixed') return false;
        return getComputedStyle(el).display !== 'none' && getComputedStyle(el).visibility !== 'hidden';
    }
    function estaErrada(item) {
        return visivel(item.querySelector('.js-response-wrong'));
    }
    function idDaQuestao(item) {
        const a = item.querySelector('.q-id a');
        const texto = a && a.textContent.trim();
        if (texto) return texto;
        const pane = item.querySelector('[id^="question-belt-"]');
        const m = pane && /question-belt-(\d+)-/.exec(pane.id);
        return m ? 'Q' + m[1] : null;
    }
    function urlDaQuestao(item) {
        const a = item.querySelector('.q-id a');
        const href = a && a.getAttribute('href');
        try { return href ? new URL(href, location.origin).href : location.href; } catch (e) { return location.href; }
    }
    function materiaEAssunto(item) {
        const links = Array.from(item.querySelectorAll('.q-question-breadcrumb a.q-link'))
            .map((a) => a.textContent.replace(/[,\s]+$/g, '').trim())
            .filter(Boolean);
        return { materia: links[0] || '', assunto: links.slice(1).join(' · ').slice(0, 140) };
    }
    function textoDoEnunciado(item) {
        const el = item.querySelector('.q-question-enunciation');
        return el ? el.textContent : '';
    }
    // textContent (e não innerText) de propósito: a aba que não está aberta fica display:none
    function textoDosComentarios(item) {
        const panes = item.querySelectorAll('[id$="-teacher-tab"], [id$="-comments-tab"]');
        let texto = '';
        panes.forEach((p) => { texto += '\n' + p.textContent; });
        return texto.replace(/\s+/g, ' ').trim().slice(0, 60000);
    }

    // ------------------------------------------------------------------ varredura
    const avisadasSemArtigo = new Set();
    const ultimoTexto = new WeakMap();
    const timers = new WeakMap();
    const observados = new WeakSet();

    async function escanear(item) {
        if (!ativo || !item || !estaErrada(item)) return;
        const texto = textoDosComentarios(item);
        if (texto.length < 25 || ultimoTexto.get(item) === texto) return;
        ultimoTexto.set(item, texto);

        const questaoId = idDaQuestao(item);
        if (!questaoId) return;
        const { materia, assunto } = materiaEAssunto(item);
        const refs = Ref.extrairReferencias(texto, { materia, leiPadrao: Ref.leiDoTexto(textoDoEnunciado(item)) });
        if (!refs.length) {
            // Os comentários não citam número de artigo, mas a questão trata de uma lei conhecida
            // ("Agentes públicos e Lei 8.112 de 1990"): oferece abrir a lei no Planalto, uma vez por questão.
            const lei = Ref.leiDoTexto(textoDoEnunciado(item) + ' ' + assunto + ' ' + materia);
            if (lei && Ref.urlDaLei(lei) && !avisadasSemArtigo.has(questaoId)) {
                avisadasSemArtigo.add(questaoId);
                mostrarAvisoSemArtigo(lei);
            }
            return;
        }

        const resultado = await Store.adicionarPendentes(refs, { questaoId, questaoUrl: urlDaQuestao(item), materia, assunto });
        if (resultado.novas.length || resultado.reforcadas.length || resultado.jaPendentes.length) {
            mostrarAviso(resultado);
        }
    }
    function agendar(item, ms) {
        clearTimeout(timers.get(item));
        timers.set(item, setTimeout(() => escanear(item), ms));
    }
    function observar(item) {
        if (observados.has(item)) return;
        const raiz = item.querySelector('.q-question-belt-tab-content');
        if (!raiz) return;
        observados.add(item);
        new MutationObserver(() => agendar(item, 1500)).observe(raiz, { childList: true, subtree: true, characterData: true });
    }

    document.addEventListener('click', (e) => {
        const alvo = e.target;
        if (!alvo || !alvo.closest) return;
        const botao = alvo.closest('.js-answer-btn');
        if (botao) {
            const item = botao.closest('.q-question-item');
            if (item) setTimeout(() => { observar(item); escanear(item); }, 2500);
            return;
        }
        const aba = alvo.closest('a.q-tab-item');
        if (aba) {
            const item = aba.closest('.q-question-item');
            if (!item) return;
            observar(item);
            agendar(item, 2500);
            setTimeout(() => escanear(item), 6500); // rede lenta: os comentários demoram a carregar
        }
    }, true);

    // ------------------------------------------------------------------ aviso na tela (Shadow DOM: o CSS do QConcursos não mexe nele)
    let hospedeiro = null;
    let raizAviso = null;
    let timerAviso = null;

    const CSS = `
        :host { all: initial; }
        .cartao {
            position: fixed; right: 22px; bottom: 22px; z-index: 2147483647;
            width: 330px; box-sizing: border-box; padding: 16px 16px 14px;
            font: 13px/1.45 -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            color: #1c2333; background: rgba(255, 255, 255, 0.92);
            -webkit-backdrop-filter: blur(22px) saturate(1.4); backdrop-filter: blur(22px) saturate(1.4);
            border-radius: 20px; box-shadow: 0 0 0 1px rgba(20, 25, 45, 0.08), 0 18px 44px rgba(20, 25, 45, 0.26);
            animation: entra 0.34s cubic-bezier(0.2, 0.9, 0.25, 1);
        }
        @keyframes entra { from { opacity: 0; transform: translateY(14px) scale(0.97); } to { opacity: 1; transform: none; } }
        @media (prefers-reduced-motion: reduce) { .cartao { animation: none; } }
        .topo { display: flex; align-items: flex-start; gap: 12px; }
        .selo { flex: none; width: 36px; height: 36px; display: grid; place-items: center; border-radius: 11px; color: #fff;
            background: linear-gradient(160deg, #a78bfa, #6d28d9); box-shadow: 0 4px 12px rgba(109, 40, 217, 0.35); }
        .selo svg { width: 19px; height: 19px; }
        .textos { flex: 1; min-width: 0; }
        .tit { font-size: 14px; font-weight: 700; letter-spacing: -0.01em; }
        .sub { margin-top: 2px; font-size: 12px; color: #5c657a; }
        .fechar { flex: none; width: 26px; height: 26px; padding: 0; border: 0; border-radius: 50%; cursor: pointer;
            background: rgba(20, 25, 45, 0.07); color: #5c657a; font-size: 14px; line-height: 1; }
        .chips { display: flex; flex-wrap: wrap; gap: 6px; margin: 12px 0 0; }
        .chip { padding: 4px 10px; border-radius: 999px; background: rgba(20, 25, 45, 0.07); font-size: 12px; font-weight: 600; }
        .chip.vazia { background: transparent; padding-left: 0; font-weight: 500; }
        .acoes { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 14px; }
        .btn { padding: 8px 14px; border: 0; border-radius: 999px; font: inherit; font-size: 12.5px; font-weight: 700; cursor: pointer;
            color: #fff; background: linear-gradient(160deg, #8b5cf6, #6d28d9); }
        .btn.sec { color: #1c2333; background: rgba(20, 25, 45, 0.08); }
        .btn:active { transform: scale(0.97); }
        @media (prefers-color-scheme: dark) {
            .cartao { color: #f2f3f7; background: rgba(28, 31, 44, 0.9); box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.1), 0 18px 44px rgba(0, 0, 0, 0.5); }
            .sub, .vazia { color: #aab0c4; }
            .chip { background: rgba(255, 255, 255, 0.1); }
            .btn.sec { background: rgba(255, 255, 255, 0.12); color: #f2f3f7; }
            .fechar { background: rgba(255, 255, 255, 0.12); color: #c9cde0; }
        }
    `;
    const ICONE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z"/></svg>';

    function rotulo(item) {
        const nome = item.lei ? Ref.nomeDaLei(item.lei) : 'lei não identificada';
        return nome + ', ' + Ref.rotuloDoArtigo(item).toLowerCase();
    }
    function esc(s) { return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

    function garantirHospedeiro() {
        if (hospedeiro && hospedeiro.isConnected) return;
        hospedeiro = document.createElement('div');
        hospedeiro.id = 'cb-ae-aviso';
        raizAviso = hospedeiro.attachShadow({ mode: 'open' });
        document.documentElement.appendChild(hospedeiro);
    }
    function fecharAviso() {
        clearTimeout(timerAviso);
        if (hospedeiro) hospedeiro.remove();
        hospedeiro = null;
    }

    // Errou, mas os comentários não trazem artigo: só oferece abrir a lei da questão no Planalto.
    function mostrarAvisoSemArtigo(lei) {
        garantirHospedeiro();
        raizAviso.innerHTML = '<style>' + CSS + '</style>'
            + '<div class="cartao" role="status">'
            + '<div class="topo"><span class="selo">' + ICONE + '</span>'
            + '<div class="textos"><div class="tit">Você errou uma questão da ' + esc(Ref.nomeDaLei(lei)) + '</div>'
            + '<div class="sub">Os comentários não citam número de artigo. Quer abrir a lei no Planalto para conferir?</div></div>'
            + '<button class="fechar" aria-label="Fechar">✕</button></div>'
            + '<div class="acoes"><button class="btn" data-abrir>Abrir ' + esc(Ref.nomeDaLei(lei)) + '</button>'
            + '<button class="btn sec" data-fechar>Depois</button></div>'
            + '</div>';
        raizAviso.querySelector('.fechar').addEventListener('click', fecharAviso);
        raizAviso.querySelector('[data-fechar]').addEventListener('click', fecharAviso);
        raizAviso.querySelector('[data-abrir]').addEventListener('click', () => {
            window.open(Ref.urlDaLei(lei), '_blank', 'noopener');
            fecharAviso();
        });
        clearTimeout(timerAviso);
        timerAviso = setTimeout(fecharAviso, 16000);
    }

    function mostrarAviso(resultado) {
        garantirHospedeiro();
        const novas = resultado.novas.concat(resultado.jaPendentes);
        const reforcadas = resultado.reforcadas;
        const total = novas.length + reforcadas.length;
        const titulo = reforcadas.length && !novas.length
            ? 'Você errou de novo um artigo salvo'
            : (novas.length === 1 ? 'Um artigo dos comentários ficou pendente' : novas.length + ' artigos dos comentários ficaram pendentes');
        const sub = reforcadas.length && !novas.length
            ? 'A revisão dele recomeça amanhã.'
            : 'Abra a lei no Planalto: o painel mostra os artigos para você confirmar e salvar.';
        const chips = novas.concat(reforcadas).slice(0, 8).map((i) => '<span class="chip">' + esc(rotulo(i)) + '</span>').join('')
            + (total > 8 ? '<span class="chip vazia">+' + (total - 8) + '</span>' : '');
        // um botão por lei que tem link pronto no Planalto (no máximo 2)
        const leis = [];
        novas.concat(reforcadas).forEach((i) => { if (i.lei && Ref.urlDaLei(i.lei) && leis.indexOf(i.lei) < 0) leis.push(i.lei); });
        const botoes = leis.slice(0, 2).map((l) => '<button class="btn" data-lei="' + esc(l) + '">Abrir ' + esc(Ref.nomeDaLei(l)) + '</button>').join('');

        raizAviso.innerHTML = '<style>' + CSS + '</style>'
            + '<div class="cartao" role="status">'
            + '<div class="topo"><span class="selo">' + ICONE + '</span>'
            + '<div class="textos"><div class="tit">' + esc(titulo) + '</div><div class="sub">' + esc(sub) + '</div></div>'
            + '<button class="fechar" aria-label="Fechar">✕</button></div>'
            + '<div class="chips">' + chips + '</div>'
            + '<div class="acoes">' + botoes + '<button class="btn sec" data-fechar>Depois</button></div>'
            + '</div>';

        raizAviso.querySelector('.fechar').addEventListener('click', fecharAviso);
        raizAviso.querySelector('[data-fechar]').addEventListener('click', fecharAviso);
        raizAviso.querySelectorAll('[data-lei]').forEach((b) => {
            b.addEventListener('click', () => {
                const primeira = novas.concat(reforcadas).find((i) => i.lei === b.dataset.lei);
                window.open(Ref.urlDaLei(b.dataset.lei, primeira && primeira.artigo, primeira && primeira.sufixo), '_blank', 'noopener');
                fecharAviso();
            });
        });
        clearTimeout(timerAviso);
        timerAviso = setTimeout(fecharAviso, 16000);
    }
})();
