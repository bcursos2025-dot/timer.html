// ============================================================================
// caderno-erros.js — Caderno de Erros do Concurseiro Blindado
// ============================================================================
// Roda só no qconcursos.com (matches no manifest). Abre/fecha com Ctrl+E.
// A pessoa cola o artigo/trecho que errou, o comentário da questão (ou usa
// o botão "Usar texto selecionado" pra puxar direto da seleção na página),
// e classifica por matéria/assunto. Tudo fica salvo em chrome.storage.local
// na chave "cbCadernoErros" — essa é a base de dados que depois vai
// alimentar o cruzamento com o desempenho por assunto (já raspado pelo
// content.js em /usuario/estatisticas/assuntos) e os flashcards.
//
// Por que Ctrl+E e não Ctrl+X: o Ctrl+X já é usado pelo global_overlay.js
// (post-its + painel) em QUALQUER site, incluindo o qconcursos.com se a
// pessoa tiver dado a permissão <all_urls>. Usar uma tecla diferente aqui
// evita os dois atalhos brigando pelo mesmo evento na mesma página.
//
// Sobre limite de espaço: chrome.storage.local por padrão tem um teto de
// 5MB no total (compartilhado com o resto da extensão). A extensão agora
// pede a permissão "unlimitedStorage" no manifest, que remove esse teto de
// verdade — mas mesmo assim mostramos quanto espaço está em uso (função
// cbAtualizarUsoStorage), por transparência e pra pegar cedo qualquer
// comentário absurdamente grande colado por engano.
// ============================================================================

(function () {
    if (window.__cbCadernoErrosCarregado) return; // evita duplicar se o script rodar 2x
    window.__cbCadernoErrosCarregado = true;

    const CB_CAD_STORAGE_KEY = 'cbCadernoErros';

    const ICON_CLOSE = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18M6 6l12 12"/></svg>';
    const ICON_TRASH = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>';
    const ICON_BOOK = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z"/></svg>';
    const ICON_SELECT = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h6v6H4zM4 14h6v6H4zM14 4h6v6h-6zM14 14h6v6h-6z"/></svg>';

    function escapeHtml(s) {
        return String(s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    }

    function formatarBytes(bytes) {
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
    }

    // Tenta classificar a matéria a partir do assunto usando o dicionário já
    // existente na extensão — se por algum motivo ele não estiver disponível
    // nesta página, degrada bem (não quebra nada, só não sugere sozinho).
    function tentarClassificarMateria(assunto) {
        try {
            if (typeof CBDicionarioMaterias !== 'undefined' && CBDicionarioMaterias.classificarAssunto) {
                const { materia } = CBDicionarioMaterias.classificarAssunto(assunto, {});
                if (materia && materia !== 'Não classificado') return materia;
            }
        } catch (e) { /* silencioso — só é uma sugestão, não é crítico */ }
        return '';
    }

    // --------------------------------------------------------------------
    // Estrutura + estilos
    // --------------------------------------------------------------------
    const style = document.createElement('style');
    style.textContent = `
#cb-cad { display:none; position:fixed; inset:0; z-index:2147483647;
  background: rgba(6,7,11,0.55); backdrop-filter: blur(4px); -webkit-backdrop-filter: blur(4px);
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  color:#e7e9f0; opacity:0; transition: opacity 0.18s ease; overflow-y:auto; }
#cb-cad.cb-cad-open { opacity:1; }
#cb-cad-inner { max-width: 880px; margin: 40px auto 60px; padding: 0 20px; box-sizing:border-box;
  transform: scale(0.985); transition: transform 0.18s cubic-bezier(.2,.8,.2,1); }
#cb-cad.cb-cad-open #cb-cad-inner { transform: scale(1); }

.cb-cad-topbar { display:flex; align-items:center; justify-content:space-between; margin-bottom:16px; }
.cb-cad-title { display:flex; align-items:center; gap:9px; font-size:13px; font-weight:800; letter-spacing:0.05em; color:#8b90a6; text-transform:uppercase; }
.cb-cad-title svg { color:#2dd4a0; }
.cb-cad-close { display:flex; align-items:center; gap:7px; background:rgba(255,255,255,0.08); border:1px solid rgba(255,255,255,0.12);
  color:#aab0c2; border-radius:999px; padding:7px 13px; font-size:11.5px; font-weight:700; cursor:pointer; }
.cb-cad-close:hover { border-color:#2dd4a0; color:#2dd4a0; }

.cb-cad-card { background: rgba(16,19,28,0.92); border:1px solid rgba(255,255,255,0.08); border-radius:16px; padding:18px 18px 16px; margin-bottom:16px; }
.cb-cad-card h2 { margin:0 0 12px; font-size:12px; font-weight:800; letter-spacing:0.05em; text-transform:uppercase; color:#8b90a6; }

.cb-cad-row { display:flex; gap:10px; margin-bottom:10px; flex-wrap:wrap; }
.cb-cad-field { flex:1 1 160px; display:flex; flex-direction:column; gap:5px; }
.cb-cad-field label { font-size:10.5px; font-weight:700; color:#7c8194; text-transform:uppercase; letter-spacing:0.04em; }
.cb-cad-field input, .cb-cad-field textarea { background:#0e1017; border:1px solid #262a3b; color:#e7e9f0; border-radius:8px; padding:9px 10px; font-size:13px; font-family:inherit; }
.cb-cad-field input:focus, .cb-cad-field textarea:focus { outline:none; border-color:#2dd4a0; }
.cb-cad-field textarea { resize:vertical; min-height:90px; line-height:1.4; }

.cb-cad-selbtn { display:inline-flex; align-items:center; gap:6px; background:rgba(255,255,255,0.07); border:1px solid rgba(255,255,255,0.12);
  color:#aab0c2; border-radius:8px; padding:6px 10px; font-size:11px; font-weight:700; cursor:pointer; margin-bottom:8px; }
.cb-cad-selbtn:hover { border-color:#2dd4a0; color:#2dd4a0; }

.cb-cad-savebtn { display:flex; align-items:center; justify-content:center; gap:8px; background:#2dd4a0; border:none; color:#08090c;
  border-radius:10px; padding:11px 16px; font-weight:800; font-size:13px; cursor:pointer; margin-top:4px; }
.cb-cad-savebtn:hover { filter:brightness(1.06); transform:translateY(-1px); }
.cb-cad-savebtn:disabled { opacity:0.5; cursor:not-allowed; transform:none; }

.cb-cad-search { width:100%; box-sizing:border-box; background:#0e1017; border:1px solid #262a3b; color:#e7e9f0; border-radius:8px; padding:9px 10px; font-size:13px; margin-bottom:12px; }
.cb-cad-search:focus { outline:none; border-color:#2dd4a0; }

.cb-cad-stats { font-size:11px; color:#565c72; display:flex; justify-content:space-between; margin-top:2px; }

.cb-cad-item { border:1px solid rgba(255,255,255,0.07); border-radius:12px; padding:12px 14px; margin-bottom:10px; background:rgba(255,255,255,0.02); }
.cb-cad-item-top { display:flex; align-items:center; justify-content:space-between; gap:8px; margin-bottom:6px; }
.cb-cad-tags { display:flex; gap:6px; flex-wrap:wrap; }
.cb-cad-tag { font-size:10px; font-weight:800; letter-spacing:0.03em; text-transform:uppercase; padding:3px 8px; border-radius:999px; }
.cb-cad-tag.materia { background:rgba(45,212,160,0.14); color:#2dd4a0; }
.cb-cad-tag.assunto { background:rgba(255,255,255,0.08); color:#aab0c2; }
.cb-cad-item-del { background:transparent; border:none; color:#565c72; cursor:pointer; display:flex; flex-shrink:0; }
.cb-cad-item-del:hover { color:#e5586b; }
.cb-cad-item-artigo { font-size:12.5px; font-weight:700; color:#e7e9f0; margin-bottom:4px; }
.cb-cad-item-comentario { font-size:12.5px; color:#aab0c2; line-height:1.45; white-space:pre-wrap; cursor:pointer; }
.cb-cad-item-comentario.truncado { display:-webkit-box; -webkit-line-clamp:3; -webkit-box-orient:vertical; overflow:hidden; }
.cb-cad-item-data { font-size:10.5px; color:#4a5066; margin-top:6px; }
.cb-cad-empty { font-size:12.5px; color:#5c6376; font-style:italic; text-align:center; padding: 20px 4px; }
`;
    document.head.appendChild(style);

    const cbCad = document.createElement('div');
    cbCad.id = 'cb-cad';
    cbCad.innerHTML = `
      <div id="cb-cad-inner">
        <div class="cb-cad-topbar">
            <div class="cb-cad-title">${ICON_BOOK}<span>Caderno de erros</span></div>
            <button class="cb-cad-close" id="cb-cad-close-btn">${ICON_CLOSE}<span>Ctrl+Shift+E ou Esc</span></button>
        </div>

        <div class="cb-cad-card">
            <h2>Novo erro</h2>
            <div class="cb-cad-row">
                <div class="cb-cad-field" style="flex-basis:100%;">
                    <label for="cb-cad-artigo">Artigo / trecho que errou</label>
                    <input type="text" id="cb-cad-artigo" placeholder="Ex: Art. 23, caput, da Lei 8.429/1992">
                </div>
            </div>
            <div class="cb-cad-row">
                <div class="cb-cad-field">
                    <label for="cb-cad-materia">Matéria</label>
                    <input type="text" id="cb-cad-materia" list="cb-cad-materia-list" placeholder="Ex: Direito Administrativo">
                    <datalist id="cb-cad-materia-list"></datalist>
                </div>
                <div class="cb-cad-field">
                    <label for="cb-cad-assunto">Assunto</label>
                    <input type="text" id="cb-cad-assunto" list="cb-cad-assunto-list" placeholder="Ex: Improbidade administrativa">
                    <datalist id="cb-cad-assunto-list"></datalist>
                </div>
            </div>
            <div class="cb-cad-row" style="margin-bottom:4px;">
                <div class="cb-cad-field" style="flex-basis:100%;">
                    <label for="cb-cad-comentario">Comentário</label>
                    <button type="button" class="cb-cad-selbtn" id="cb-cad-usar-selecao">${ICON_SELECT}<span>Usar texto selecionado na página</span></button>
                    <textarea id="cb-cad-comentario" placeholder="Cole aqui o comentário da questão, ou selecione o texto na página e clique em 'Usar texto selecionado'"></textarea>
                </div>
            </div>
            <button class="cb-cad-savebtn" id="cb-cad-save-btn">Salvar no caderno</button>
        </div>

        <div class="cb-cad-card">
            <h2>Erros salvos</h2>
            <input type="text" class="cb-cad-search" id="cb-cad-search" placeholder="Buscar por matéria, assunto ou artigo...">
            <div id="cb-cad-list"></div>
            <div class="cb-cad-stats">
                <span id="cb-cad-total">0 erros salvos</span>
                <span id="cb-cad-uso">calculando espaço usado...</span>
            </div>
        </div>
      </div>
    `;
    document.documentElement.appendChild(cbCad);

    let cbCadOpen = false;
    let cbCadFiltro = '';

    function ehCampoEditavel(el) {
        if (!el) return false;
        const tag = (el.tagName || '').toLowerCase();
        return tag === 'input' || tag === 'textarea' || el.isContentEditable;
    }

    function abrirCaderno() {
        if (cbCadOpen) return;
        cbCadOpen = true;
        cbCad.style.display = 'block';
        requestAnimationFrame(() => cbCad.classList.add('cb-cad-open'));
        renderSugestoes();
        renderLista();
        atualizarUsoStorage();
        setTimeout(() => document.getElementById('cb-cad-artigo')?.focus(), 200);
    }

    function fecharCaderno() {
        if (!cbCadOpen) return;
        cbCadOpen = false;
        cbCad.classList.remove('cb-cad-open');
        setTimeout(() => { if (!cbCadOpen) cbCad.style.display = 'none'; }, 180);
    }

    document.getElementById('cb-cad-close-btn').addEventListener('click', fecharCaderno);
    cbCad.addEventListener('click', (e) => { if (e.target === cbCad) fecharCaderno(); });

    document.addEventListener('keydown', (e) => {
        // Ctrl+Shift+E abre/fecha o caderno — só fora de campos de texto, pra
        // não atrapalhar quem estiver digitando em algum campo do próprio
        // QConcursos. IMPORTANTE: Ctrl+E sozinho é atalho reservado do
        // próprio Chrome (foca a barra de endereço pra busca) — o navegador
        // intercepta antes de chegar na página, então a extensão nunca
        // recebe esse evento. Por isso usamos Ctrl+Shift+E.
        if (e.ctrlKey && e.shiftKey && !e.altKey && !e.metaKey && (e.key === 'e' || e.key === 'E') && !e.repeat) {
            if (ehCampoEditavel(e.target) || ehCampoEditavel(document.activeElement)) return;
            e.preventDefault();
            cbCadOpen ? fecharCaderno() : abrirCaderno();
            return;
        }
        if (cbCadOpen && e.key === 'Escape' && !ehCampoEditavel(e.target)) {
            e.preventDefault();
            fecharCaderno();
        }
    }, true);

    // --------------------------------------------------------------------
    // Puxar a seleção de texto da página pro campo de comentário
    // --------------------------------------------------------------------
    document.getElementById('cb-cad-usar-selecao').addEventListener('click', () => {
        const selecao = (window.getSelection ? window.getSelection().toString() : '').trim();
        const textarea = document.getElementById('cb-cad-comentario');
        if (!selecao) {
            textarea.placeholder = 'Nenhum texto selecionado na página — selecione o comentário no QConcursos primeiro.';
            textarea.focus();
            return;
        }
        textarea.value = textarea.value ? (textarea.value + '\n\n' + selecao) : selecao;
    });

    // --------------------------------------------------------------------
    // Sugestões (datalist) de matéria/assunto já usados antes, pra não
    // precisar redigitar sempre os mesmos nomes.
    // --------------------------------------------------------------------
    function renderSugestoes() {
        chrome.storage.local.get([CB_CAD_STORAGE_KEY], (result) => {
            const itens = result[CB_CAD_STORAGE_KEY] || [];
            const materias = [...new Set(itens.map(i => i.materia).filter(Boolean))].sort();
            const assuntos = [...new Set(itens.map(i => i.assunto).filter(Boolean))].sort();
            document.getElementById('cb-cad-materia-list').innerHTML = materias.map(m => `<option value="${escapeHtml(m)}">`).join('');
            document.getElementById('cb-cad-assunto-list').innerHTML = assuntos.map(a => `<option value="${escapeHtml(a)}">`).join('');
        });
    }

    // Ao sair do campo assunto, se a matéria ainda estiver vazia, tenta
    // classificar automaticamente usando o dicionário da extensão.
    document.getElementById('cb-cad-assunto').addEventListener('change', () => {
        const materiaInput = document.getElementById('cb-cad-materia');
        const assuntoInput = document.getElementById('cb-cad-assunto');
        if (!materiaInput.value.trim() && assuntoInput.value.trim()) {
            const sugestao = tentarClassificarMateria(assuntoInput.value.trim());
            if (sugestao) materiaInput.value = sugestao;
        }
    });

    // --------------------------------------------------------------------
    // Salvar
    // --------------------------------------------------------------------
    document.getElementById('cb-cad-save-btn').addEventListener('click', () => {
        const artigo = document.getElementById('cb-cad-artigo').value.trim();
        const materia = document.getElementById('cb-cad-materia').value.trim();
        const assunto = document.getElementById('cb-cad-assunto').value.trim();
        const comentario = document.getElementById('cb-cad-comentario').value.trim();

        if (!artigo && !comentario) {
            document.getElementById('cb-cad-artigo').focus();
            return;
        }

        const novo = {
            id: 'erro_' + Date.now(),
            artigo,
            materia,
            assunto,
            comentario,
            url: location.href,
            dataISO: new Date().toISOString()
        };

        chrome.storage.local.get([CB_CAD_STORAGE_KEY], (result) => {
            const itens = result[CB_CAD_STORAGE_KEY] || [];
            itens.unshift(novo); // mais recente primeiro
            chrome.storage.local.set({ [CB_CAD_STORAGE_KEY]: itens }, () => {
                document.getElementById('cb-cad-artigo').value = '';
                document.getElementById('cb-cad-materia').value = '';
                document.getElementById('cb-cad-assunto').value = '';
                document.getElementById('cb-cad-comentario').value = '';
                renderSugestoes();
                renderLista();
                atualizarUsoStorage();
            });
        });
    });

    // --------------------------------------------------------------------
    // Lista + busca + apagar
    // --------------------------------------------------------------------
    document.getElementById('cb-cad-search').addEventListener('input', (e) => {
        cbCadFiltro = e.target.value.trim().toLowerCase();
        renderLista();
    });

    function renderLista() {
        const wrap = document.getElementById('cb-cad-list');
        chrome.storage.local.get([CB_CAD_STORAGE_KEY], (result) => {
            let itens = result[CB_CAD_STORAGE_KEY] || [];
            document.getElementById('cb-cad-total').textContent = `${itens.length} erro${itens.length === 1 ? '' : 's'} salvo${itens.length === 1 ? '' : 's'}`;

            if (cbCadFiltro) {
                itens = itens.filter(i =>
                    (i.materia || '').toLowerCase().includes(cbCadFiltro) ||
                    (i.assunto || '').toLowerCase().includes(cbCadFiltro) ||
                    (i.artigo || '').toLowerCase().includes(cbCadFiltro)
                );
            }

            if (itens.length === 0) {
                wrap.innerHTML = `<div class="cb-cad-empty">${cbCadFiltro ? 'Nenhum erro encontrado pra essa busca.' : 'Nenhum erro salvo ainda — o que você errar, registra aqui.'}</div>`;
                return;
            }

            wrap.innerHTML = itens.map(i => `
                <div class="cb-cad-item" data-id="${i.id}">
                    <div class="cb-cad-item-top">
                        <div class="cb-cad-tags">
                            ${i.materia ? `<span class="cb-cad-tag materia">${escapeHtml(i.materia)}</span>` : ''}
                            ${i.assunto ? `<span class="cb-cad-tag assunto">${escapeHtml(i.assunto)}</span>` : ''}
                        </div>
                        <button class="cb-cad-item-del" title="Remover">${ICON_TRASH}</button>
                    </div>
                    ${i.artigo ? `<div class="cb-cad-item-artigo">${escapeHtml(i.artigo)}</div>` : ''}
                    ${i.comentario ? `<div class="cb-cad-item-comentario truncado">${escapeHtml(i.comentario)}</div>` : ''}
                    <div class="cb-cad-item-data">${new Date(i.dataISO).toLocaleDateString('pt-BR')} às ${new Date(i.dataISO).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</div>
                </div>
            `).join('');

            // Clique no comentário expande/recolhe (útil pros comentários
            // grandes tipo o do print — não precisa abrir nada separado).
            wrap.querySelectorAll('.cb-cad-item-comentario').forEach(el => {
                el.addEventListener('click', () => el.classList.toggle('truncado'));
            });

            wrap.querySelectorAll('.cb-cad-item-del').forEach(btn => {
                btn.addEventListener('click', () => {
                    const id = btn.closest('.cb-cad-item').dataset.id;
                    chrome.storage.local.get([CB_CAD_STORAGE_KEY], (r2) => {
                        const restantes = (r2[CB_CAD_STORAGE_KEY] || []).filter(x => x.id !== id);
                        chrome.storage.local.set({ [CB_CAD_STORAGE_KEY]: restantes }, () => {
                            renderSugestoes();
                            renderLista();
                            atualizarUsoStorage();
                        });
                    });
                });
            });
        });
    }

    // --------------------------------------------------------------------
    // Espaço usado — só informativo agora que a extensão pede
    // "unlimitedStorage" no manifest (sem teto de 5MB), mas continua útil
    // pra pegar cedo algum comentário colado errado e gigantesco demais.
    // --------------------------------------------------------------------
    function atualizarUsoStorage() {
        const el = document.getElementById('cb-cad-uso');
        if (!chrome.storage.local.getBytesInUse) { el.textContent = ''; return; }
        chrome.storage.local.getBytesInUse([CB_CAD_STORAGE_KEY], (bytes) => {
            el.textContent = `${formatarBytes(bytes)} usados pelo caderno`;
        });
    }
})();
