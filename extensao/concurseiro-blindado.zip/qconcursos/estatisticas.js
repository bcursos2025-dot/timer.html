// ============================================================================
// estatisticas.js — QConcursos: guarda, por questão, o desempenho da COMUNIDADE (aba "Estatísticas") ao lado do
// seu resultado, para comparar você com os outros usuários (seção "Você × comunidade" do popup).
//
// Como os números chegam, sem você abrir a aba:
//   1. AUTOMÁTICO — quando uma questão aparece respondida na tela (você acabou de responder, ou a lista já a traz
//      como resolvida), a extensão pede ao próprio QConcursos o mesmo componente que a aba "Estatísticas" pediria
//      (POST /components/questions/question_statistics, com a sua sessão e o token da página, igual ao que
//      content.js já faz com o widget "Meu Painel"). Um pedido por vez, com pausa entre eles, no máximo
//      MAX_POR_PAGINA por página, uma única vez por questão (renova só depois de VALIDADE_MS). Se o site responder
//      "faça login" / negar / limitar, para tudo e só volta no próximo carregamento (ou depois de PAUSA_APOS_ERRO_MS).
//      Interruptor: Configurações → Estatísticas do QConcursos (cbQcEstatAuto, ligado por padrão).
//   2. PASSIVO — se você abrir a aba na mão, estat-main.js (mundo da página) lê os gráficos e manda por postMessage.
//
// Guarda SÓ números: percentual de acertos da comunidade, contagens, distribuição das alternativas, o seu resultado
// (acertou/errou), matéria e assuntos. Nada do texto da questão. Tudo fica em chrome.storage.local; nada sai do
// navegador.
//
//   cbQcEstat        { 'Q4350021': { ts, pct, acertos, erros, alternativas: {A: %}, contagem: {A: n}, acertei,
//                                     materia, assunto, assuntos: [..], fonte: 'auto'|'aba' } }
//   cbQcEstatAmostra a última leitura crua (recorte do HTML + o que foi entendido), para conferir/ajustar quando o
//                    site mudar (Configurações → Estatísticas do QConcursos → "Copiar amostra")
//   cbQcEstatAuto    false desliga a busca automática (ausente = ligada)
//   cbQcEstatStatus  { ts, ok, erro, feitas, fila } — resumo da última busca automática, para a tela de Configurações
// ============================================================================
(function () {
    'use strict';
    if (window.__cbEstatQC) return;
    window.__cbEstatQC = true;

    const K_DADOS = 'cbQcEstat', K_AMOSTRA = 'cbQcEstatAmostra', K_AUTO = 'cbQcEstatAuto', K_STATUS = 'cbQcEstatStatus';
    const VALIDADE_MS = 30 * 24 * 3600 * 1000;      // a estatística da comunidade muda devagar
    const MAX_POR_PAGINA = 60;                       // teto de pedidos por carregamento de página
    const PAUSA_ENTRE_MS = [1400, 2800];             // intervalo aleatório entre dois pedidos
    const PAUSA_APOS_ERRO_MS = 30 * 60 * 1000;
    const VERSAO = 2;                                // 2 = registro com o histórico de tentativas e a sua alternativa
    const DIVERGENCIA_MS = 10 * 60 * 1000;           // tela ≠ servidor: busca de novo, no máximo a cada 10 min por questão

    const vivo = () => { try { return !!(chrome && chrome.runtime && chrome.runtime.id); } catch (e) { return false; } };
    const ler = (k) => new Promise((r) => { try { chrome.storage.local.get([k], (x) => r(x || {})); } catch (e) { r({}); } });
    const gravar = (o) => { try { if (vivo()) chrome.storage.local.set(o); } catch (e) { /* extensão recarregada */ } };

    // ---- escrita serializada no mapa (o automático e o passivo podem gravar ao mesmo tempo) ----
    let cadeia = Promise.resolve();
    function atualizarMapa(fn) {
        cadeia = cadeia.then(async () => {
            if (!vivo()) return;
            const x = await ler(K_DADOS);
            const mapa = Object.assign({}, x[K_DADOS] || {});
            let mudou = false;
            try { mudou = fn(mapa) !== false; } catch (e) { mudou = false; }
            if (mudou) gravar({ [K_DADOS]: mapa });
        }).catch(() => {});
        return cadeia;
    }

    // ------------------------------------------------------------------ leitura da questão na tela
    const visivel = (el) => !!el && el.offsetParent !== null;
    const limpa = (t) => String(t || '').replace(/\s+/g, ' ').replace(/[,\s]+$/g, '').trim();

    function resultado(item) {
        if (visivel(item.querySelector('.js-response-wrong'))) return false;
        if (visivel(item.querySelector('.js-response-right, .js-response-correct'))) return true;
        const q = item.querySelector('.q-question');
        if (q && q.classList.contains('q-question-is-correct')) return true;
        // lista que já traz a questão como resolvida (o site grava data-status e data-correct no item)
        if (item.getAttribute('data-status') === 'solved') return item.getAttribute('data-correct') === 'true';
        return null;      // ainda não respondeu (ou o site mudou o seletor)
    }

    function infoDoItem(item) {
        const belt = item.querySelector('.q-question-belt');
        const q = item.querySelector('.q-question');
        const a = item.querySelector('.q-id a');
        let qid = a && a.textContent.trim();
        const num = String((belt && belt.dataset.questionId) || (q && q.dataset.questionId) || (qid || '').replace(/\D/g, ''));
        if (!/^\d+$/.test(num)) return null;
        if (!/^Q\d+$/.test(qid || '')) qid = 'Q' + num;
        const links = Array.from(item.querySelectorAll('.q-question-breadcrumb a.q-link')).map((l) => limpa(l.textContent)).filter(Boolean);
        const assuntos = links.slice(1);
        const href = a && a.getAttribute('href');
        const url = href && href.charAt(0) === '/' ? href.split('?')[0].slice(0, 120) : '';
        return { qid, num, belt, url, materia: links[0] || '', assuntos, assunto: assuntos.join(' · ').slice(0, 140) };
    }

    // ------------------------------------------------------------------ interpretação da resposta
    const numero = (v) => {
        if (v == null || v === '') return null;
        const n = parseFloat(String(v).replace('%', '').replace(',', '.'));
        return Number.isFinite(n) ? n : null;
    };

    // Histórico SEU naquela questão, no fim do mesmo componente:
    //   <div class="q-event-item"><div class="q-description">Em 13/10/26 às 11:23, você respondeu a opção E.</div>
    //     <div class="q-question-wrong"><i>!</i><span>Incorreta</span></div></div>
    // Devolve [{ ts, op, certa }] da mais antiga para a mais nova. `op` é a letra (questão de Certo/Errado vira C ou E);
    // `certa` é true/false, ou null se o texto do status não for entendido.
    const semAcento = (t) => String(t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    function lerTentativas(doc) {
        const saida = [];
        doc.querySelectorAll('.q-event-item').forEach((el) => {
            const desc = limpa((el.querySelector('.q-description') || {}).textContent);
            const m = /Em\s+(\d{1,2})\/(\d{1,2})\/(\d{2,4})\s+(?:às|as)\s+(\d{1,2}):(\d{2}),?\s+você respondeu\s+(?:a\s+)?(?:opção\s+)?(.+?)\.?$/i.exec(desc);
            if (!m) return;
            const ano = Number(m[3]) < 100 ? 2000 + Number(m[3]) : Number(m[3]);
            const ts = new Date(ano, Number(m[2]) - 1, Number(m[1]), Number(m[4]), Number(m[5])).getTime();
            let op = m[6].trim();
            if (/^[a-e]$/i.test(op)) op = op.toUpperCase();
            else if (/^certo/i.test(op)) op = 'C';
            else if (/^errado/i.test(op)) op = 'E';
            else op = op.slice(0, 12);
            let certa = null;
            if (el.querySelector('.q-question-wrong')) certa = false;
            else if (el.querySelector('.q-question-right, .q-question-correct')) certa = true;
            else {
                const status = semAcento(limpa(el.textContent).replace(desc, ''));
                if (/incorret|errad/.test(status)) certa = false;
                else if (/corret|certa|acert/.test(status)) certa = true;
            }
            if (Number.isFinite(ts) && !saida.some((x) => x.ts === ts && x.op === op)) saida.push({ ts, op, certa });
        });
        return saida.sort((a, b) => a.ts - b.ts).slice(-20);
    }

    // O componente traz os números em atributos data-* dos <canvas> (é de lá que o próprio site desenha os gráficos):
    //   #js-income-percentage-chart            data-hits / data-mistakes (%), data-hits-count / data-mistakes-count
    //   #js-most-answered-alternatives-chart   data-options "A,B,C,D,E", data-pecentages (sic) "10.5,60,...", data-alternatives-count "5, 30, ..."
    function interpretarHtml(html) {
        let doc;
        try { doc = new DOMParser().parseFromString(String(html || ''), 'text/html'); } catch (e) { return null; }
        const pizza = doc.querySelector('#js-income-percentage-chart');
        const barras = doc.querySelector('#js-most-answered-alternatives-chart');
        let pct = null, acertos = null, erros = null, alternativas = null, contagem = null;
        if (pizza) {
            const d = pizza.dataset;
            acertos = numero(d.hitsCount);
            erros = numero(d.mistakesCount);
            const h = numero(d.hits), m = numero(d.mistakes);
            if (h != null && (m != null || h > 0)) pct = h;
            else if (acertos != null && erros != null && acertos + erros > 0) pct = (acertos / (acertos + erros)) * 100;
        }
        if (barras) {
            const d = barras.dataset;
            const nomes = String(d.options || '').split(',').map((s) => s.trim()).filter(Boolean);
            const pcts = String(d.pecentages || d.percentages || '').split(',').map(numero);
            const cont = String(d.alternativesCount || '').split(',').map(numero);
            if (nomes.length) {
                alternativas = {}; contagem = {};
                nomes.forEach((n, i) => { if (pcts[i] != null) alternativas[n] = pcts[i]; if (cont[i] != null) contagem[n] = cont[i]; });
            }
        }
        if (pct == null && !alternativas) return null;
        return { pct, acertos, erros, alternativas, contagem, tentativas: lerTentativas(doc) };
    }

    // Caminho passivo (aba aberta na mão): a rosca/pizza traz 2 valores em %, as barras uma por alternativa.
    function interpretarGraficos(graficos) {
        let pct = null, alternativas = null;
        (graficos || []).forEach((g) => {
            const dados = g.series && g.series[0] ? g.series[0].dados.map(Number) : [];
            if (/doughnut|pie/i.test(g.tipo) && dados.length >= 2) {
                const rot = (g.labels || []).map((l) => l.toLowerCase());
                const iA = rot.findIndex((l) => /acert/.test(l)), iE = rot.findIndex((l) => /err/.test(l));
                const a = dados[iA >= 0 ? iA : 0], e = dados[iE >= 0 ? iE : 1];
                if (Number.isFinite(a) && Number.isFinite(e) && a + e > 0) pct = (a / (a + e)) * 100;
            } else if (/bar/i.test(g.tipo) && dados.length) {
                alternativas = {};
                dados.forEach((v, i) => { alternativas[(g.labels && g.labels[i]) || String.fromCharCode(65 + i)] = v; });
            }
        });
        return (pct == null && !alternativas) ? null : { pct, acertos: null, erros: null, alternativas, contagem: null };
    }

    function recorteAmostra(html) {
        const s = String(html || '');
        const i = s.search(/js-income-percentage-chart|js-most-answered/);
        return i >= 0 ? s.slice(Math.max(0, i - 600), i + 2600) : s.slice(0, 3000);
    }

    // ------------------------------------------------------------------ gravação
    function guardar(qid, lido, extra) {
        return atualizarMapa((mapa) => {
            const anterior = mapa[qid] || {};
            const novo = Object.assign({}, anterior, { ts: Date.now() });
            // um dado que não deu para ler agora (null, '' ou lista vazia) não apaga o que já se sabia
            Object.keys(extra || {}).forEach((k) => {
                const v = extra[k];
                if (v === null || v === undefined || v === '' || (Array.isArray(v) && !v.length)) return;
                novo[k] = v;
            });
            if (lido) {
                novo.pct = lido.pct;
                novo.acertos = lido.acertos;
                novo.erros = lido.erros;
                novo.alternativas = lido.alternativas;
                novo.contagem = lido.contagem;
                if (lido.tentativas && lido.tentativas.length) novo.tentativas = lido.tentativas;
            }
            mapa[qid] = novo;
        });
    }

    // O histórico que o servidor devolve manda no resultado: vale a ÚLTIMA tentativa (a tela pode estar atrasada ou mostrar
    // outra). Sem histórico entendido, cai no que está na tela. `minha` é a alternativa dessa última tentativa.
    function extraDoServidor(lido, daTela) {
        const t = (lido && lido.tentativas) || [];
        const ultima = t.length ? t[t.length - 1] : null;
        const certa = ultima && typeof ultima.certa === 'boolean' ? ultima.certa : daTela;
        return { acertei: certa, minha: ultima ? ultima.op : '' };
    }

    // ------------------------------------------------------------------ busca automática
    let auto = true;
    let pausadoAte = 0;
    let feitasNaPagina = 0;
    let errosSeguidos = 0;
    const emFila = new Set();         // já na fila ou já buscadas nesta página
    const fila = [];
    let drenando = false;

    ler(K_AUTO).then((x) => { auto = x[K_AUTO] !== false; if (auto) agendar(1500); });
    try {
        chrome.storage.onChanged.addListener((mud, area) => {
            if (area === 'local' && mud[K_AUTO]) { auto = mud[K_AUTO].newValue !== false; if (auto) agendar(500); }
        });
    } catch (e) { /* sem storage: segue ligado */ }

    const dorme = (ms) => new Promise((r) => setTimeout(r, ms));
    const pausaAleatoria = () => PAUSA_ENTRE_MS[0] + Math.random() * (PAUSA_ENTRE_MS[1] - PAUSA_ENTRE_MS[0]);

    function status(ok, erro) {
        gravar({ [K_STATUS]: { ts: Date.now(), ok: !!ok, erro: erro || null, feitas: feitasNaPagina, fila: fila.length } });
    }

    async function pedirEstatistica(info) {
        const token = (document.body && document.body.getAttribute('data-authenticity-token'))
            || (document.querySelector('meta[name="csrf-token"]') || {}).content || '';
        if (!token) return { erro: 'sem token da página', parar: true };
        const b = info.belt ? info.belt.dataset : {};
        const corpo = new URLSearchParams();
        const d = (k, v) => corpo.set(`data[${k}]`, v == null ? '' : String(v));
        // espelha o que a aba envia (loadTab): a questão, o produto e alguns campos que a aba de estatísticas deixa vazios
        d('question_id', info.num);
        d('product_id', b.productId || '1');
        d('product_key', b.productKey || 'concursos');
        d('product_slug', b.productSlug || 'questoes-de-concursos');
        d('already_solved', 'true');
        d('has_definitive_feedback', '');
        d('url_feedback_justification', '');
        d('show_path', b.isShowPath || 'false');
        d('limit_reached', 'false');
        d('has_comments', '');
        d('total_comments', b.totalComments || '0');
        corpo.set('asset_key', '');
        corpo.set('authenticity_token', token);
        corpo.set('data_type', 'hash');
        corpo.set('type', 'page_component');
        let r;
        try {
            r = await fetch(`/components/questions/question_statistics?current_product=${encodeURIComponent(b.productKey || 'concursos')}`, {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-Token': token },
                body: corpo.toString(),
            });
        } catch (e) { return { erro: 'falha de rede: ' + e.message }; }
        if (r.status === 401) return { erro: 'não está logado no QConcursos (401)', parar: true };
        if (r.status === 403 || r.status === 429) return { erro: `o site recusou (${r.status})`, parar: true };
        if (!r.ok) return { erro: 'o site respondeu ' + r.status };
        return { html: await r.text() };
    }

    async function drenar() {
        if (drenando) return;
        drenando = true;
        try {
            while (fila.length && auto && vivo() && feitasNaPagina < MAX_POR_PAGINA) {
                if (Date.now() < pausadoAte) break;
                const item = fila.shift();
                // a questão pode ter saído da tela (outra página) enquanto esperava
                if (!document.contains(item.el)) continue;
                const info = infoDoItem(item.el);
                if (!info) continue;
                const res = await pedirEstatistica(info);
                feitasNaPagina++;
                if (res.erro) {
                    errosSeguidos++;
                    status(false, res.erro);
                    if (res.parar || errosSeguidos >= 3) { pausadoAte = Date.now() + PAUSA_APOS_ERRO_MS; break; }
                } else {
                    const lido = interpretarHtml(res.html);
                    if (lido) {
                        errosSeguidos = 0;
                        await guardar(info.qid, lido, Object.assign(extraDoServidor(lido, resultado(item.el)), { materia: info.materia, assunto: info.assunto, assuntos: info.assuntos, url: info.url, fonte: 'auto', v: VERSAO }));
                        status(true, null);
                    } else {
                        // resposta que não é a esperada (site mudou? pergunta sem estatística?): guarda amostra e conta como erro
                        errosSeguidos++;
                        gravar({ [K_AMOSTRA]: { ts: Date.now(), qid: info.qid, fonte: 'auto', url: '/components/questions/question_statistics', recorte: recorteAmostra(res.html), tamanho: String(res.html || '').length, interpretado: null } });
                        status(false, 'não entendi a resposta (use “Copiar amostra”)');
                        if (errosSeguidos >= 3) { pausadoAte = Date.now() + PAUSA_APOS_ERRO_MS; break; }
                    }
                    if (feitasNaPagina === 1) {
                        gravar({ [K_AMOSTRA]: { ts: Date.now(), qid: info.qid, fonte: 'auto', url: '/components/questions/question_statistics', recorte: recorteAmostra(res.html), tamanho: String(res.html || '').length, interpretado: lido } });
                    }
                }
                await dorme(pausaAleatoria());
            }
        } finally { drenando = false; }
    }

    let varrendo = false;
    const vistaSemResposta = new Set();   // qids que apareceram nesta página ainda sem resposta (se forem respondidas agora, é tentativa nova)
    async function varrer() {
        if (varrendo || !vivo()) return;
        varrendo = true;
        try {
            const x = await ler(K_DADOS);
            const mapa = x[K_DADOS] || {};
            const mudancas = [];
            document.querySelectorAll('.q-question-item').forEach((el) => {
                const meu = resultado(el);
                const info = infoDoItem(el);
                if (!info) return;
                if (meu === null) { vistaSemResposta.add(info.qid); return; }
                const reg = mapa[info.qid];
                // matéria/assuntos/link acompanham a tela; o RESULTADO só, se o registro ainda não tem o histórico do servidor
                if (reg && (reg.materia !== info.materia || reg.assunto !== info.assunto || !reg.assuntos || !reg.url || (!reg.tentativas && reg.acertei !== meu))) {
                    mudancas.push([info, meu]);
                }
                const idade = Date.now() - (reg && reg.ts || 0);
                const completo = reg && reg.pct != null && reg.v >= VERSAO;
                const fresco = completo && idade < VALIDADE_MS;
                const refeita = vistaSemResposta.has(info.qid);                 // respondida agora, depois de ter aparecido sem resposta
                const divergente = completo && reg.acertei !== meu && idade > DIVERGENCIA_MS;
                if ((!fresco || refeita || divergente) && auto) {
                    if (refeita) { vistaSemResposta.delete(info.qid); emFila.delete(info.qid); }
                    if (!emFila.has(info.qid)) { emFila.add(info.qid); fila.push({ el, qid: info.qid }); }
                }
            });
            if (mudancas.length) {
                await atualizarMapa((m) => {
                    mudancas.forEach(([info, meu]) => {
                        const r = m[info.qid];
                        if (!r) return;
                        Object.assign(r, { materia: info.materia, assunto: info.assunto, assuntos: info.assuntos, url: info.url || r.url });
                        if (!r.tentativas) r.acertei = meu;
                    });
                });
            }
            if (fila.length) { status(true, null); drenar(); }
        } finally { varrendo = false; }
    }

    let agendado = null;
    function agendar(ms) {
        if (agendado) return;
        agendado = setTimeout(() => { agendado = null; varrer(); }, ms || 1500);
    }
    function vigiar() {
        // uma questão respondida muda classes/estilo do item; a lista também ganha itens novos ao rolar
        new MutationObserver(() => { if (auto) agendar(1500); }).observe(document.documentElement, {
            childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'style', 'hidden', 'data-status', 'data-correct'],
        });
    }
    if (document.documentElement) vigiar(); else document.addEventListener('DOMContentLoaded', vigiar);

    // ------------------------------------------------------------------ caminho passivo (aba aberta na mão)
    function itemDoPainel(idPainel) {
        const painel = idPainel ? document.getElementById(idPainel) : null;
        return painel ? painel.closest('.q-question-item') : null;
    }

    window.addEventListener('message', async (e) => {
        if (e.source !== window || !e.data || !e.data.cbQcEstat || e.data.tipo !== 'graficos') return;
        const c = e.data.carga || {};
        const item = itemDoPainel(c.idPainel);
        const info = item ? infoDoItem(item) : null;
        const qid = info ? info.qid : ((/question-belt-(\d+)-/.exec(c.idPainel || '') || [])[1] ? 'Q' + /question-belt-(\d+)-/.exec(c.idPainel)[1] : null);
        const lido = interpretarHtml(c.resposta) || interpretarGraficos(c.graficos);

        // amostra crua: serve para conferir a leitura sem acesso à sua conta
        gravar({ [K_AMOSTRA]: { ts: Date.now(), qid, fonte: 'aba', url: c.url, temChart: c.temChart, graficos: c.graficos, recorte: recorteAmostra(c.resposta), interpretado: lido } });

        if (!qid || !lido) return;
        await guardar(qid, lido, {
            acertei: extraDoServidor(lido, item ? resultado(item) : null).acertei,
            minha: extraDoServidor(lido, null).minha,
            materia: info ? info.materia : '',
            assunto: info ? info.assunto : '',
            assuntos: info ? info.assuntos : [],
            url: info ? info.url : '',
            fonte: 'aba',
        });
    });
})();
