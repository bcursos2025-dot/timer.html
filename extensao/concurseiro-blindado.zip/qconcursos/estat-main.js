// ============================================================================
// estat-main.js — roda no MUNDO DA PÁGINA do QConcursos (content script com "world": "MAIN"), onde existem o
// jQuery, o Chart.js e as chamadas de rede do próprio site. O script isolado (estatisticas.js) não enxerga nada
// disso. Daqui só saem DADOS, por window.postMessage: nada é enviado para fora do navegador.
//
// O que faz: quando a aba "Estatísticas" de uma questão carrega (o site pede o conteúdo por XHR/fetch só ao
// clicar, e só para quem está logado), guarda a resposta e, logo depois, lê os gráficos (rosca de acertos e
// erros, barras de alternativas) direto das instâncias do Chart.js.
// ============================================================================
(function () {
    'use strict';
    if (window.__cbEstatMain) return;
    window.__cbEstatMain = true;

    const ehEstatistica = (url) => /statistic/i.test(String(url || ''));
    const enviar = (tipo, carga) => { try { window.postMessage({ cbQcEstat: true, tipo, carga }, '*'); } catch (e) { /* ignora */ } };

    // ---- lê os gráficos que estão na tela (Chart.js v2, v3 ou v4) ----
    function lerGraficos() {
        const C = window.Chart;
        const saida = [];
        document.querySelectorAll('[id$="-statistics-tab"] canvas, .q-statistics canvas').forEach((cv) => {
            let g = null;
            try {
                if (C && C.getChart) g = C.getChart(cv);
                if (!g && C && C.instances) g = Object.values(C.instances).find((x) => x && x.canvas === cv) || null;
            } catch (e) { g = null; }
            if (!g || !g.data) return;
            const cfg = g.config || {};
            saida.push({
                tipo: (cfg.type || (cfg._config && cfg._config.type) || '').toString(),
                titulo: (g.options && g.options.title && g.options.title.text) || (g.options && g.options.plugins && g.options.plugins.title && g.options.plugins.title.text) || '',
                labels: (g.data.labels || []).map(String),
                series: (g.data.datasets || []).map((d) => ({ nome: d.label || '', dados: Array.isArray(d.data) ? d.data.slice(0, 40) : [] })),
            });
        });
        return { graficos: saida, temChart: !!C };
    }

    function depoisDeCarregar(url, texto) {
        const painel = Array.from(document.querySelectorAll('[id$="-statistics-tab"]')).find((p) => p.offsetParent !== null) || document.querySelector('[id$="-statistics-tab"]');
        const idPainel = painel ? painel.id : '';
        // o Chart.js desenha logo depois do HTML entrar na página: lê duas vezes
        [900, 2500].forEach((ms) => setTimeout(() => enviar('graficos', Object.assign({ url, idPainel, resposta: String(texto || '').slice(0, 30000) }, lerGraficos())), ms));
    }

    // ---- reserva: se o endereço do pedido não tiver "statistic", o aparecimento dos gráficos na aba também serve ----
    const jaLidos = new WeakSet();
    function vigiarPainel() {
        new MutationObserver(() => {
            document.querySelectorAll('[id$="-statistics-tab"] canvas').forEach((cv) => {
                const painel = cv.closest('[id$="-statistics-tab"]');
                if (!painel || jaLidos.has(painel)) return;
                jaLidos.add(painel);
                depoisDeCarregar('(dom)', painel.innerHTML);
            });
        }).observe(document.documentElement, { childList: true, subtree: true });
    }
    if (document.documentElement) vigiarPainel(); else document.addEventListener('DOMContentLoaded', vigiarPainel);

    // ---- XHR ----
    const abrir = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function (metodo, url) {
        this.__cbUrl = url;
        return abrir.apply(this, arguments);
    };
    const enviarXhr = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function () {
        if (ehEstatistica(this.__cbUrl)) {
            this.addEventListener('load', () => {
                try { depoisDeCarregar(this.__cbUrl, typeof this.responseText === 'string' ? this.responseText : ''); } catch (e) { /* ignora */ }
            });
        }
        return enviarXhr.apply(this, arguments);
    };

    // ---- fetch ----
    if (window.fetch) {
        const buscar = window.fetch;
        window.fetch = function (entrada) {
            const url = typeof entrada === 'string' ? entrada : (entrada && entrada.url);
            const p = buscar.apply(this, arguments);
            if (ehEstatistica(url)) {
                p.then((r) => r.clone().text().then((t) => depoisDeCarregar(url, t)).catch(() => {})).catch(() => {});
            }
            return p;
        };
    }
})();
