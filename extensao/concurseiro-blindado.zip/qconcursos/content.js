console.log('[CB-DEBUG] content.js começou a rodar. URL:', location.href);

// ============================================================================
// CONCURSEIRO BLINDADO — content.js (v5.2)
// Funcionalidades:
// 1. Câmera & Detecção Facial (IA Local com face-api.js)
// 2. Economia de Bateria / Page Visibility API
// 3. Sincronização do Histórico Antigo (API Interna do QConcursos)
// 4. Monitoramento de Questões em Tempo Real (Detecção ao vivo de Acertos/Erros)
// ============================================================================

const video = document.createElement('video');
video.id = 'carrasco-webcam-invisible';
video.width = 80;
video.height = 60;
video.style.position = 'fixed';
video.style.bottom = '15px';
video.style.right = '15px';
video.style.width = '1px';
video.style.height = '1px';
video.style.opacity = '0';
video.style.pointerEvents = 'none';
video.autoplay = true;
video.playsInline = true;
document.body.appendChild(video);

let localStream = null;
let monitoringInterval = null;
let observer = null;
let cameraCheckIntervalMs = 3000;
let cameraEnabled = true;
let cameraDisableForQuestoes = false;
let privacyNoticeEnabled = true;
let cameraConsentGiven = false;
let currentActivity = 'questoes';
let qcSyncEnabled = true;

function safeSendMessage(message) {
    try {
        if (chrome.runtime && chrome.runtime.id) {
            chrome.runtime.sendMessage(message);
        } else {
            autoDesativarScript();
        }
    } catch (err) {
        autoDesativarScript();
    }
}

function autoDesativarScript() {
    pararCamera();
    if (observer) {
        observer.disconnect();
        observer = null;
    }
    if (disciplinasObserver) {
        disciplinasObserver.disconnect();
        disciplinasObserver = null;
    }
    if (assuntosObserver) {
        assuntosObserver.disconnect();
        assuntosObserver = null;
    }
}

chrome.storage.onChanged.addListener((changes, areaName) => {
    try {
        if (areaName === 'local' && (changes.sessionState || changes.activeMethod || changes.activeActivity)) {
            lerEstadoEAtualizarCamera();
        }
        if (areaName === 'sync' && changes.cameraEnabled) {
            cameraEnabled = changes.cameraEnabled.newValue !== false;
            lerEstadoEAtualizarCamera();
        }
        if (areaName === 'sync' && changes.cameraDisableForQuestoes) {
            cameraDisableForQuestoes = changes.cameraDisableForQuestoes.newValue === true;
            lerEstadoEAtualizarCamera();
        }
        if (areaName === 'sync' && changes.cameraCheckIntervalMs) {
            cameraCheckIntervalMs = changes.cameraCheckIntervalMs.newValue || 3000;
            if (monitoringInterval) {
                clearInterval(monitoringInterval);
                monitoringInterval = null;
                startMonitoring();
            }
        }
        if (areaName === 'sync' && changes.qcSyncEnabled) {
            qcSyncEnabled = changes.qcSyncEnabled.newValue !== false;
        }
        if (areaName === 'sync' && changes.privacyNoticeEnabled) {
            privacyNoticeEnabled = changes.privacyNoticeEnabled.newValue !== false;
        }
    } catch (e) {
        autoDesativarScript();
    }
});

// ----------------------------------------------------------------------------
// Câmera x horário do cronograma — se a pessoa cadastrou algum bloco
// "Leitura" com "Câmera ligada" na Agenda, a câmera passa a respeitar o
// horário DAQUELE bloco específico (só liga dentro da janela marcada), em
// vez de ligar assim que a sessão de estudo está rodando, não importa a
// hora. Quem nunca usou essa opção na Agenda continua com o comportamento
// de sempre (liga direto num site de questões com a sessão rodando).
function cbMinutosAgora() {
    const d = new Date();
    return d.getHours() * 60 + d.getMinutes();
}
function cbHojeStrCam() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
function cbCameraPermitidaPelaAgenda(callback) {
    chrome.storage.local.get(['cbCronogramaHoje', 'cbCronogramaData'], (res) => {
        const blocosHoje = (res.cbCronogramaData === cbHojeStrCam()) ? (res.cbCronogramaHoje || []) : [];
        const blocosComCamera = blocosHoje.filter(b => b && b.camera);
        if (blocosComCamera.length === 0) {
            callback(true); // ninguém configurou bloco com câmera hoje — mantém o comportamento antigo
            return;
        }
        const min = cbMinutosAgora();
        const dentroDeAlgum = blocosComCamera.some((b) => {
            const [ih, im] = (b.inicio || '0:0').split(':').map(Number);
            const [fh, fm] = (b.fim || '0:0').split(':').map(Number);
            return min >= (ih * 60 + im) && min < (fh * 60 + fm);
        });
        callback(dentroDeAlgum);
    });
}

function lerEstadoEAtualizarCamera() {
    chrome.storage.local.get(['sessionState', 'activeMethod', 'activeActivity'], (result) => {
        const state = result.sessionState || 'stopped';
        const method = result.activeMethod || 'online';
        currentActivity = result.activeActivity || 'questoes';
        cbCameraPermitidaPelaAgenda((permitidoPelaAgenda) => {
            gerenciarCamera(state, method, currentActivity, permitidoPelaAgenda);
        });
    });
}

try {
    chrome.storage.sync.get(['cameraEnabled', 'cameraCheckIntervalMs', 'cameraDisableForQuestoes', 'qcSyncEnabled', 'privacyNoticeEnabled', 'cameraConsentGiven'], (syncResult) => {
        cameraEnabled = syncResult.cameraEnabled !== false;
        cameraCheckIntervalMs = syncResult.cameraCheckIntervalMs || 3000;
        cameraDisableForQuestoes = syncResult.cameraDisableForQuestoes === true;
        qcSyncEnabled = syncResult.qcSyncEnabled !== false;
        privacyNoticeEnabled = syncResult.privacyNoticeEnabled !== false;
        cameraConsentGiven = syncResult.cameraConsentGiven === true;
        lerEstadoEAtualizarCamera();
    });
} catch (e) {
    autoDesativarScript();
}

// Reavalia periodicamente se "agora" entrou ou saiu da janela de um bloco
// "Leitura + Câmera" da Agenda — sem isso, só reagiria a mudanças de
// sessionState/activeMethod, podendo deixar a câmera ligada (ou desligada)
// depois que o horário do bloco já virou.
setInterval(lerEstadoEAtualizarCamera, 30000);

let avisoCameraEnviado = false;
let avisoPrivacidadeMostrado = false;

// ----------------------------------------------------------------------------
// Aviso de privacidade — mostrado por 3s sempre que a câmera/IA local liga,
// deixando claro que nada é fotografado/gravado, só analisado em tempo real
// no próprio dispositivo para detectar presença.
// ----------------------------------------------------------------------------
function mostrarAvisoPrivacidadeIA() {
    if (avisoPrivacidadeMostrado || !privacyNoticeEnabled) return;
    avisoPrivacidadeMostrado = true;

    const aviso = document.createElement('div');
    aviso.id = 'cb-privacy-notice';
    aviso.style.cssText = `
        position: fixed; top: 0; left: 0; width: 100%; z-index: 2147483647;
        display: flex; align-items: center; justify-content: center; gap: 8px;
        padding: 10px 16px; box-sizing: border-box;
        background: #0d1220; color: #e7e9f0; border-bottom: 1px solid #2dd4a0;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 13px; font-weight: 600; text-align: center;
        opacity: 0; transition: opacity 0.3s ease;
        pointer-events: none;
    `;
    aviso.innerHTML = `
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="#2dd4a0" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/></svg>
        <span>O sistema de I.A roda localmente, não tira foto, não grava vídeo e nem mesmo som — apenas verifica se você está realmente estudando.</span>
    `;
    document.body.appendChild(aviso);

    requestAnimationFrame(() => { aviso.style.opacity = '1'; });

    setTimeout(() => {
        aviso.style.opacity = '0';
        setTimeout(() => aviso.remove(), 350);
    }, 3000);
}

// ----------------------------------------------------------------------------
// Consentimento explícito de câmera/IA — mostrado UMA vez, ANTES de pedir
// getUserMedia pela primeira vez. Diferente do aviso de 3s (que só confirma
// depois que já ligou), este é um portão real: a câmera só é acionada se a
// pessoa clicar em "Autorizar". Se recusar, a extensão desliga esse recurso
// sozinha (cameraEnabled = false) e não volta a perguntar sem ação do usuário.
// ----------------------------------------------------------------------------
let consentModalAberto = false;

function pedirConsentimentoCamera(onDecidido) {
    if (cameraConsentGiven) { onDecidido(true); return; }
    if (consentModalAberto) return;
    consentModalAberto = true;

    const overlay = document.createElement('div');
    overlay.id = 'cb-camera-consent-overlay';
    overlay.style.cssText = `
        position: fixed; inset: 0; z-index: 2147483647;
        background: rgba(5,6,9,0.72); backdrop-filter: blur(2px);
        display: flex; align-items: center; justify-content: center;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    `;
    overlay.innerHTML = `
        <div style="max-width:380px; background:#0d1220; border:1px solid #262a3b; border-radius:14px; padding:22px; color:#e7e9f0; text-align:left; box-shadow:0 20px 60px rgba(0,0,0,0.5);">
            <div style="font-weight:800; font-size:14px; margin-bottom:8px; color:#2dd4a0;">Uso da câmera — Concurseiro Blindado</div>
            <div style="font-size:12.5px; line-height:1.6; color:#c3c7d6; margin-bottom:16px;">
                Este recurso usa a câmera para detectar, com I.A rodando 100% localmente no seu computador, se você está presente estudando. Nada é fotografado, gravado ou enviado a nenhum servidor. Você pode desligar isso quando quiser em Configurações.
            </div>
            <div style="display:flex; gap:8px; justify-content:flex-end;">
                <button id="cb-consent-recusar" style="padding:8px 14px; border-radius:8px; border:1px solid #333849; background:transparent; color:#aab0c2; font-size:12.5px; font-weight:700; cursor:pointer;">Não usar</button>
                <button id="cb-consent-aceitar" style="padding:8px 14px; border-radius:8px; border:none; background:#2dd4a0; color:#04120c; font-size:12.5px; font-weight:800; cursor:pointer;">Autorizar</button>
            </div>
        </div>
    `;
    document.body.appendChild(overlay);

    overlay.querySelector('#cb-consent-aceitar').addEventListener('click', () => {
        cameraConsentGiven = true;
        chrome.storage.sync.set({ cameraConsentGiven: true });
        overlay.remove();
        consentModalAberto = false;
        onDecidido(true);
    });
    overlay.querySelector('#cb-consent-recusar').addEventListener('click', () => {
        chrome.storage.sync.set({ cameraEnabled: false });
        overlay.remove();
        consentModalAberto = false;
        onDecidido(false);
    });
}

function gerenciarCamera(state, method, activity, permitidoPelaAgenda) {
    if (!cameraEnabled) {
        pararCamera();
        return;
    }
    if (cameraDisableForQuestoes && activity === 'questoes') {
        pararCamera();
        return;
    }
    if (permitidoPelaAgenda === false) {
        // Existe pelo menos um bloco "Leitura + Câmera" cadastrado hoje, mas
        // agora não é a hora de nenhum deles — respeita o horário marcado.
        pararCamera();
        return;
    }
    if (method === 'online' && (state === 'running' || state === 'paused_away')) {
        if (!localStream) {
            pedirConsentimentoCamera((autorizado) => {
                if (!autorizado) return;
                navigator.mediaDevices.getUserMedia({ video: true })
                    .then(stream => {
                        localStream = stream;
                        video.srcObject = stream;
                        avisoCameraEnviado = false;
                        mostrarAvisoPrivacidadeIA();
                        carregarModelosIA();
                    })
                    .catch(err => {
                        if (!avisoCameraEnviado) {
                            avisoCameraEnviado = true;
                            safeSendMessage({
                                action: "camera_error",
                                reason: err.name === 'NotAllowedError' ? 'permissao' : 'outro'
                            });
                        }
                    });
            });
        }
    } else {
        pararCamera();
    }
}

function pararCamera() {
    if (localStream) {
        localStream.getTracks().forEach(track => track.stop());
        localStream = null;
    }
    avisoPrivacidadeMostrado = false;
    video.srcObject = null;
    if (monitoringInterval) {
        clearInterval(monitoringInterval);
        monitoringInterval = null;
    }
}

async function carregarModelosIA() {
    if (typeof faceapi === 'undefined') return;

    const MODELS_URL = chrome.runtime.getURL('models');
    try {
        if (faceapi.tf) {
            await faceapi.tf.setBackend('cpu');
            await faceapi.tf.ready();
        }
    } catch (e) {}

    try {
        await faceapi.nets.tinyFaceDetector.loadFromUri(MODELS_URL);
        if (!monitoringInterval) {
            startMonitoring();
        }
    } catch (err) {}
}

function startMonitoring() {
    let absentCounter = 0;
    let presentCounter = 0;
    const leiturasParaAusente = Math.max(2, Math.round(12000 / cameraCheckIntervalMs));

    async function tick() {
        try {
            const options = new faceapi.TinyFaceDetectorOptions({ inputSize: 160, scoreThreshold: 0.25 });
            const detection = await faceapi.detectSingleFace(video, options);

            if (!detection) {
                absentCounter++;
                presentCounter = 0;
                if (absentCounter >= leiturasParaAusente) {
                    safeSendMessage({ action: "face_status", present: false });
                    absentCounter = 0;
                }
            } else {
                presentCounter++;
                absentCounter = 0;
                if (presentCounter >= 1) {
                    safeSendMessage({ action: "face_status", present: true });
                    presentCounter = 0;
                }
            }
        } catch (err) {}
    }

    monitoringInterval = setInterval(tick, cameraCheckIntervalMs);
}

document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        if (monitoringInterval) {
            clearInterval(monitoringInterval);
            monitoringInterval = null;
        }
    } else {
        if (localStream && !monitoringInterval && typeof faceapi !== 'undefined') {
            startMonitoring();
        }
        sincronizarHistoricoQC();
    }
});

// ----------------------------------------------------------------------------
// SINCRONIZAÇÃO DO HISTÓRICO ANTIGO (API INTERNA DO QCONCURSOS)
// ATENÇÃO: endpoint não-documentado, obtido por engenharia reversa das
// chamadas de rede da própria página. Pode mudar/quebrar sem aviso — por
// isso todo o bloco é silenciosamente tolerante a falha (nunca trava a
// extensão) e só roda enquanto uma sessão de estudo está de fato rodando.
// ----------------------------------------------------------------------------

let ultSincronizacaoHoje = 0;
const INTERVALO_MIN_HOJE_MS = 5 * 1000; // trava contra spam de cliques/re-sincronizações repetidas

// Confirmado via DevTools (Network) no widget "Meu Painel" do próprio QC:
// data-period="1" = Hoje, "7" = 7 dias, "30" = 30 dias, "999" = Sempre.
const QC_PERIODO_HOJE = 1;
const QC_PERIODO_SEMPRE = 999;

// O QC guarda o token CSRF do Rails numa <meta> da própria página — ele
// muda por sessão, então sempre lemos na hora em vez de fixar um valor.
function getCsrfToken() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    return meta ? meta.content : null;
}

async function buscarEstatisticasQC(period) {
    // Endpoint real confirmado via DevTools (Network > Payload) no widget
    // "Meu Painel": é um POST (não GET) para /components/user_dashboard/...,
    // com current_product=concursos (é o contexto do painel geral — o
    // conteúdo devolvido continua sendo especificamente "Resolução de
    // Questões", que é o que nos interessa) e o período no corpo do form.
    const token = getCsrfToken();
    if (!token) {
        return { erro: 'Token de segurança (CSRF) não encontrado na página — abra o QConcursos.com logado numa aba normal.' };
    }

    const urlApi = 'https://www.qconcursos.com/components/user_dashboard/widget_statistics?current_product=concursos';
    const corpo = new URLSearchParams();
    corpo.set('current_product', 'concursos');
    corpo.set('data[by_period]', String(period));
    corpo.set('authenticity_token', token);
    corpo.set('data_type', 'hash');
    corpo.set('type', 'page_component');

    let response;
    try {
        response = await fetch(urlApi, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            credentials: 'same-origin',
            body: corpo.toString()
        });
    } catch (errRede) {
        return { erro: `Falha de rede: ${errRede.message}` };
    }

    if (!response.ok) {
        return { erro: `Servidor respondeu ${response.status} (${response.statusText || 'sem detalhes'})` };
    }

    const html = await response.text();
    const doc = new DOMParser().parseFromString(html, 'text/html');

    // Se a resposta não é o widget esperado (ex: página de login, HTML
    // completo em vez do fragmento), avisa em vez de silenciosamente
    // devolver zero.
    if (!doc.querySelector('.q-widget-statistic-content-info') && !doc.querySelector('.q-widget-statistic-chart-feedback')) {
        return { erro: 'Resposta do QC não é o widget esperado (provável sessão/login expirado ou o site mudou).' };
    }

    // Estado "sem questões no período" — o QC mostra só uma mensagem,
    // sem gráfico nem os itens de resumo.
    if (doc.querySelector('.q-widget-statistic-chart-feedback')) {
        return { total: 0, acertos: 0, erros: 0 };
    }

    // Fonte primária: os textos "Resolução de Questão(ões) / Correta(s) / Errada(s)"
    // (mais estáveis que depender da ordem dos labels do gráfico de pizza).
    let total = null, acertos = null, erros = null;
    doc.querySelectorAll('.q-widget-statistic-content-info-item').forEach(item => {
        const num = parseInt(item.querySelector('strong')?.textContent.trim(), 10);
        const texto = item.textContent.toLowerCase();
        if (texto.includes('resolu') && texto.includes('quest')) total = num;
        else if (texto.includes('correta')) acertos = num;
        else if (texto.includes('errada')) erros = num;
    });

    // Fallback: lê direto do gráfico de pizza (data-labels/data-values),
    // caso o texto dos itens de resumo mude no futuro.
    if (acertos === null || erros === null) {
        const pie = doc.querySelector('canvas.js-chart-pie');
        if (pie) {
            const labels = (pie.dataset.labels || '').split(',').map(s => s.trim().toLowerCase());
            const values = (pie.dataset.values || '').split(',').map(v => parseInt(v, 10));
            const idxAcertos = labels.indexOf('acertos');
            const idxErros = labels.indexOf('erros');
            if (acertos === null && idxAcertos !== -1) acertos = values[idxAcertos];
            if (erros === null && idxErros !== -1) erros = values[idxErros];
        }
    }

    acertos = acertos || 0;
    erros = erros || 0;
    if (total === null) total = acertos + erros;

    return { total, acertos, erros };
}

// Busca um período (1=Hoje, 7=7 dias, 30=30 dias, 999=Sempre) direto da API
// do próprio QC e manda o resultado pra sempre substituir (nunca somar) o
// que estava guardado — isso é sempre um espelho fiel do widget "Meu
// Painel" do próprio site, sem depender de detectar cliques no DOM (frágil).
async function sincronizarPeriodo(period, forcar) {
    try {
        const dados = await buscarEstatisticasQC(period);
        if (dados && dados.erro) {
            safeSendMessage({ action: 'qc_sync_debug', origem: `período ${period}`, erro: dados.erro });
            return;
        }
        if (!dados) return;
        safeSendMessage({ action: 'sincronizar_periodo_qc', period, dados });
        if (period === QC_PERIODO_HOJE) {
            safeSendMessage({ action: 'qc_sync_debug', origem: 'hoje', ok: true });
        }
    } catch (err) {
        safeSendMessage({ action: 'qc_sync_debug', origem: `período ${period}`, erro: `Exceção: ${err.message}` });
    }
}

// Períodos que a extensão mostra (filtro Hoje/7 dias/30 dias) + Sempre
// (usado só no rodapé de estatística acumulada da conta).
const QC_PERIODOS_ACOMPANHADOS = [QC_PERIODO_HOJE, 7, 30, QC_PERIODO_SEMPRE];

async function sincronizarHistoricoQC(forcar = false) {
    if (!qcSyncEnabled) return;
    const agora = Date.now();
    // Trava simples contra spam de cliques repetidos para os períodos
    // (Hoje/7/30 dias — buscados juntos, um único controle de tempo basta).
    // IMPORTANTE: a sincronização de disciplinas é disparada por FORA desse
    // `if`, com seu próprio controle de tempo — antes ela ficava presa
    // atrás desse `return` antecipado e, se essa chamada específica batesse
    // no throttle de período, a disciplina nem tentava sincronizar.
    if (forcar || agora - ultSincronizacaoHoje >= INTERVALO_MIN_HOJE_MS) {
        ultSincronizacaoHoje = agora;
        QC_PERIODOS_ACOMPANHADOS.forEach(period => sincronizarPeriodo(period, forcar));
    }
    sincronizarDisciplinasQC(forcar);
}

// ----------------------------------------------------------------------------
// DESEMPENHO POR DISCIPLINA/MATÉRIA
// Fonte: a própria página "/usuario/estatisticas/disciplinas" do QC (a mesma
// que a pessoa vê manualmente com a tabela Certas/Erradas/Total/%). Buscamos
// ela via fetch (GET simples, com os cookies da sessão) e extraímos a tabela
// pelo cabeçalho ("Certas"/"Erradas"), em vez de fixar classes CSS — assim
// sobrevive melhor a pequenas mudanças visuais do site. Igual ao resto da
// sincronização, é tolerante a falha: se o site mudar demais, só reporta o
// erro no debug em vez de travar a extensão.
// ATENÇÃO: como o restante da sincronização baseada em scraping deste
// arquivo, os seletores aqui são um ponto de partida — se o QC mudar a
// estrutura da página, ajustar a função parseDisciplinasHtml abaixo.
// ----------------------------------------------------------------------------

let ultSincronizacaoDisciplinas = 0;
const INTERVALO_MIN_DISCIPLINAS_MS = 60 * 1000; // é um fetch de página inteira, mais pesado que o widget — throttle maior

function estaNaPaginaDisciplinas() {
    return /\/usuario\/estatisticas\/disciplinas/.test(location.pathname);
}

// Recebe um Document (tanto faz se veio de fetch+DOMParser ou é o próprio
// `document` da aba, quando estamos ao vivo na página de disciplinas) e
// extrai a tabela Certas/Erradas/Total/%.
function parseDisciplinasDoc(doc) {
    const tabelas = Array.from(doc.querySelectorAll('table'));

    let tabelaAlvo = null, idxCertas = -1, idxErradas = -1, idxTotal = -1;
    for (const tabela of tabelas) {
        const linhaCabecalho = tabela.querySelector('thead tr') || tabela.querySelector('tr');
        if (!linhaCabecalho) continue;
        const celulasCabecalho = Array.from(linhaCabecalho.querySelectorAll('th, td'));
        const textosCabecalho = celulasCabecalho.map(c => c.textContent.trim().toLowerCase());
        const iCertas = textosCabecalho.findIndex(t => t.includes('certa'));
        const iErradas = textosCabecalho.findIndex(t => t.includes('errada'));
        if (iCertas !== -1 && iErradas !== -1) {
            tabelaAlvo = tabela;
            idxCertas = iCertas;
            idxErradas = iErradas;
            idxTotal = textosCabecalho.findIndex(t => t.includes('total'));
            break;
        }
    }

    if (!tabelaAlvo) {
        return { erro: 'Tabela de disciplinas não encontrada na página (provável mudança no site ou sessão expirada).' };
    }

    const linhasCorpo = Array.from(tabelaAlvo.querySelectorAll('tbody tr'));
    const itens = [];
    linhasCorpo.forEach(linha => {
        const celulas = Array.from(linha.querySelectorAll('td'));
        if (!celulas.length) return;
        // Nome da disciplina: usa o atributo title se existir (evita nomes
        // cortados com "..." na tabela), senão o texto visível da 1ª célula.
        const nome = (celulas[0].getAttribute('title') || celulas[0].textContent || '').trim();
        if (!nome) return;

        const numDe = (idx) => {
            if (idx < 0 || !celulas[idx]) return null;
            const n = parseInt(celulas[idx].textContent.replace(/[^\d-]/g, ''), 10);
            return isNaN(n) ? null : n;
        };
        const certas = numDe(idxCertas) || 0;
        const erradas = numDe(idxErradas) || 0;
        const totalLido = idxTotal !== -1 ? numDe(idxTotal) : null;
        const total = totalLido !== null ? totalLido : (certas + erradas);

        if (total > 0) itens.push({ nome, certas, erradas, total });
    });

    return { itens };
}

// Debug das disciplinas vai num canal PRÓPRIO (qc_sync_debug_disciplinas),
// separado do canal de debug dos períodos "Hoje/7/30 dias" — antes ambos
// escreviam na mesma chave (`qcSyncDebug`), então uma sincronização de
// período bem-sucedida apagava silenciosamente um erro de disciplinas (ou
// vice-versa), fazendo parecer que nada estava sendo sincronizado quando na
// real só o *debug* estava sendo sobrescrito.
function reportarDebugDisciplinas(payload) {
    safeSendMessage(Object.assign({ action: 'qc_sync_debug_disciplinas' }, payload));
}

async function buscarESincronizarDisciplinasQC() {
    try {
        const response = await fetch('https://www.qconcursos.com/usuario/estatisticas/disciplinas', {
            credentials: 'same-origin'
        });
        if (!response.ok) {
            reportarDebugDisciplinas({ erro: `Servidor respondeu ${response.status}` });
            return;
        }
        const html = await response.text();
        const doc = new DOMParser().parseFromString(html, 'text/html');
        const resultado = parseDisciplinasDoc(doc);
        if (resultado.erro) {
            reportarDebugDisciplinas({ erro: resultado.erro });
            return;
        }
        safeSendMessage({ action: 'sincronizar_disciplinas_qc', itens: resultado.itens });
        reportarDebugDisciplinas({ ok: true });
    } catch (err) {
        reportarDebugDisciplinas({ erro: `Exceção: ${err.message}` });
    }
}

// Lê a tabela direto do DOM ao vivo da aba — usado quando o usuário já está
// na própria página de disciplinas. É mais confiável que buscar a página de
// novo via fetch (evita uma segunda requisição/carregamento e reflete
// exatamente o que está na tela, inclusive depois de trocar os filtros de
// data ali, que atualizam a tabela via AJAX sem recarregar a página).
function sincronizarDisciplinasDoDOM(forcar) {
    if (!qcSyncEnabled) return false;
    if (!estaNaPaginaDisciplinas()) return false;
    const agora = Date.now();
    if (!forcar && agora - ultSincronizacaoDisciplinasDOM < INTERVALO_MIN_DISCIPLINAS_DOM_MS) return true;
    ultSincronizacaoDisciplinasDOM = agora;

    const resultado = parseDisciplinasDoc(document);
    if (resultado.erro) {
        reportarDebugDisciplinas({ erro: resultado.erro });
        return true;
    }
    safeSendMessage({ action: 'sincronizar_disciplinas_qc', itens: resultado.itens });
    reportarDebugDisciplinas({ ok: true });
    return true;
}

let ultSincronizacaoDisciplinasDOM = 0;
const INTERVALO_MIN_DISCIPLINAS_DOM_MS = 2000; // leitura local, sem rede — pode reagir rápido

let disciplinasObserver = null;
function iniciarObservadorDisciplinas() {
    if (!estaNaPaginaDisciplinas()) {
        if (disciplinasObserver) { disciplinasObserver.disconnect(); disciplinasObserver = null; }
        return;
    }
    // Sincroniza assim que entra na página...
    sincronizarDisciplinasDoDOM(true);
    // ...e continua observando: o QC atualiza a tabela via AJAX quando o
    // usuário troca o filtro de data/categoria, sem recarregar a página.
    if (disciplinasObserver) disciplinasObserver.disconnect();
    disciplinasObserver = new MutationObserver(() => sincronizarDisciplinasDoDOM(false));
    disciplinasObserver.observe(document.body, { childList: true, subtree: true });
}

function sincronizarDisciplinasQC(forcar) {
    if (!qcSyncEnabled) return;
    // Se já estamos na própria página de disciplinas, a leitura direta do
    // DOM é estritamente melhor (mais rápida e mais fiel) que refazer um
    // fetch da mesma página em paralelo.
    if (sincronizarDisciplinasDoDOM(forcar)) return;

    const agora = Date.now();
    if (!forcar && agora - ultSincronizacaoDisciplinas < INTERVALO_MIN_DISCIPLINAS_MS) return;
    ultSincronizacaoDisciplinas = agora;
    buscarESincronizarDisciplinasQC();
}

// Detecta navegação client-side (o QC usa Rails/Turbo, então trocar de
// página nem sempre dispara um reload completo) para religar o observador
// da página de disciplinas quando o usuário entra/sai dela.
let ultimoPathname = location.pathname;
setInterval(() => {
    if (location.pathname !== ultimoPathname) {
        ultimoPathname = location.pathname;
        iniciarObservadorDisciplinas();
        iniciarObservadorAssuntos();
    }
}, 1000);

// ----------------------------------------------------------------------------
// DESEMPENHO POR ASSUNTO (dentro de cada matéria)
// Fonte: /usuario/estatisticas/assuntos — MESMA estrutura de tabela da página
// de disciplinas (Certas/Erradas/Total/%), mas os assuntos vêm todos
// misturados, sem coluna de matéria. A classificação por matéria é feita
// localmente (sem IA, sem custo) em dicionario-materias.js.
// ----------------------------------------------------------------------------

let ultSincronizacaoAssuntos = 0;
const INTERVALO_MIN_ASSUNTOS_MS = 60 * 1000; // reservado pra uma eventual versão via fetch, como em disciplinas

// Throttle PRÓPRIO e rápido pra leitura de DOM (igual ao padrão usado em
// disciplinas: INTERVALO_MIN_DISCIPLINAS_DOM_MS). Sem isto, o MutationObserver
// que acompanha o carregamento progressivo da tabela (o QC popula as linhas
// aos poucos via AJAX) ficava bloqueado por 60s inteiros depois da primeira
// leitura — que muitas vezes pegava a tabela com só 1 linha renderizada ainda,
// e essa lista incompleta sobrescrevia (sem merge) o `questoesAssuntosRaw`
// salvo, travando "só 1 assunto" até a próxima janela de 60s (ou pra sempre,
// se o usuário saísse da página antes disso).
let ultSincronizacaoAssuntosDOM = 0;
const INTERVALO_MIN_ASSUNTOS_DOM_MS = 2000;

function estaNaPaginaAssuntos() {
    return /\/usuario\/estatisticas\/assuntos/.test(location.pathname);
}

// A tabela tem a MESMA estrutura da página de disciplinas (procura
// cabeçalho "certa"/"errada"), então reaproveitamos o parser existente.
function parseAssuntosDoc(doc) {
    return parseDisciplinasDoc(doc);
}

function reportarDebugAssuntos(payload) {
    safeSendMessage(Object.assign({ action: 'qc_sync_debug_assuntos' }, payload));
}

function sincronizarAssuntosDoDOM(forcar) {
    if (!qcSyncEnabled) return false;
    if (!estaNaPaginaAssuntos()) return false;
    const agora = Date.now();
    if (!forcar && agora - ultSincronizacaoAssuntosDOM < INTERVALO_MIN_ASSUNTOS_DOM_MS) return true;
    ultSincronizacaoAssuntosDOM = agora;

    const resultado = parseAssuntosDoc(document);
    if (resultado.erro) {
        reportarDebugAssuntos({ erro: resultado.erro });
        return true;
    }
    safeSendMessage({ action: 'sincronizar_assuntos_qc', itens: resultado.itens });
    reportarDebugAssuntos({ ok: true });
    return true;
}

let assuntosObserver = null;
function iniciarObservadorAssuntos() {
    if (!estaNaPaginaAssuntos()) {
        if (assuntosObserver) { assuntosObserver.disconnect(); assuntosObserver = null; }
        return;
    }
    sincronizarAssuntosDoDOM(true);
    if (assuntosObserver) assuntosObserver.disconnect();
    assuntosObserver = new MutationObserver(() => sincronizarAssuntosDoDOM(false));
    assuntosObserver.observe(document.body, { childList: true, subtree: true });
}

// ----------------------------------------------------------------------------
// MONITORAMENTO DE QUESTÕES EM TEMPO REAL
// ATENÇÃO: os seletores abaixo são um PONTO DE PARTIDA — precisam ser
// confirmados inspecionando o DOM real do QConcursos (F12 → Elements) ao
// resolver uma questão de verdade, e ajustados aqui. Centralizados nesta
// constante para facilitar a manutenção sem mexer no resto da lógica.
// ----------------------------------------------------------------------------

const QC_SELETORES = {
    botaoResponder: '.js-submit-answer, [data-action="submit-answer"], .q-btn-submit',
    containerQuestao: '.q-question, .js-question, fieldset',
    feedbackAcerto: '.q-question-feedback-correct, .q-correct, .js-correct-answer, .is-correct',
    feedbackErro: '.q-question-feedback-incorrect, .q-incorrect, .js-incorrect-answer, .is-incorrect'
};

// Não tentamos mais ler "acertou/errou" direto do DOM da questão — os
// seletores de feedback do QC são um alvo móvel e não confiável. Em vez
// disso, o clique em "Responder" só serve de GATILHO: esperamos alguns
// segundos (tempo do QC processar e atualizar o próprio widget) e então
// buscamos o período "Hoje" (period=1) direto da API oficial do QC, que é
// sempre a fonte da verdade (ver sincronizarHoje em cima).
function iniciarMonitoramentoQuestoesTempoReal() {
    document.addEventListener('click', (event) => {
        const btnResponder = event.target.closest(QC_SELETORES.botaoResponder);
        if (!btnResponder) return;

        // 3s de folga pra dar tempo do backend do QC registrar a resposta
        // antes de perguntarmos pelo widget atualizado (e, se for o caso,
        // também pela tabela de disciplinas).
        setTimeout(() => {
            sincronizarHistoricoQC(true);
            sincronizarDisciplinasQC(true);
        }, 3000);
    });
}

// ----------------------------------------------------------------------------
// INICIALIZAÇÃO
// ----------------------------------------------------------------------------

console.log('[CB-DEBUG] content.js chegou até o final sem travar. estaNaPaginaAssuntos():', estaNaPaginaAssuntos());

sincronizarHistoricoQC();
iniciarMonitoramentoQuestoesTempoReal();
iniciarObservadorDisciplinas();
iniciarObservadorAssuntos();
