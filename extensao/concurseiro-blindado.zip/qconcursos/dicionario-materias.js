// ==========================================================================
// dicionario-materias.js — Classificação local (sem IA) de assunto → matéria
// ==========================================================================
// O QConcursos não amarra assunto→matéria na página de Estatísticas de
// Assuntos (a lista vem toda misturada). Como o desempenho aqui precisa ser
// confiável (evitar classificar errado em silêncio), usamos um dicionário
// de palavras-chave por matéria, baseado nos tópicos do cronograma do PGM.
//
// REGRA DE OURO: melhor deixar "Não classificado" do que chutar a matéria
// errada. Ambiguidades conhecidas (ex: "Prescrição" sozinho, que existe em
// várias matérias) ficam de propósito fora do dicionário — só entram termos
// específicos o suficiente pra não gerar falso positivo.
// ==========================================================================

function _normalizar(txt) {
    return (txt || '')
        .toLowerCase()
        .normalize('NFD').replace(/[\u0300-\u036f]/g, '') // remove acentos
        .replace(/[^a-z0-9\s]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
}

// --------------------------------------------------------------------------
// CAMADA 1 — MATCH EXATO (prioridade máxima)
// Gerado a partir de um mapeamento manual revisado por um usuário real
// (nome do assunto → matéria, no formato exato/truncado como aparece na
// tabela do QC). Muito mais preciso que o dicionário de palavras-chave
// abaixo — checado primeiro. Casa por PREFIXO (não igualdade exata) porque
// o nome que chega da página pode vir truncado ("Responsabilidade civil...")
// ou completo (quando o QC usa o atributo title) — nos dois casos o texto
// começa com as mesmas palavras.
// Lista ordenada do prefixo mais longo pro mais curto, pra bater no match
// mais específico primeiro e evitar que um prefixo curto capture errado.
// --------------------------------------------------------------------------
const CB_MATCH_EXATO = [
    // -------- adicionados a partir da lista real de "Não classificado" --------
    // Nutrição e Saúde Pública — matéria nova, não existia nenhuma cobertura
    // pra esse bloco inteiro (provavelmente cargo de Nutricionista/Saúde).
    ['nutricao e saude publi', 'Nutrição e Saúde Pública'],
    ['avaliacao nutricional', 'Nutrição e Saúde Pública'],
    ['metodos diretos e ind', 'Nutrição e Saúde Pública'],
    ['recomendacoes nutrici', 'Nutrição e Saúde Pública'],
    ['sistema de vigilancia', 'Nutrição e Saúde Pública'],
    ['sistema nacional de s', 'Nutrição e Saúde Pública'],
    ['estrategia global em', 'Nutrição e Saúde Pública'],
    ['estrategia de saude d', 'Nutrição e Saúde Pública'],
    ['politicas publicas de', 'Nutrição e Saúde Pública'],
    ['nutricionista na aten', 'Nutrição e Saúde Pública'],

    // Direito Tributário
    ['obrigacao principal e', 'Direito Tributário'],
    ['conceito de tributo e', 'Direito Tributário'],
    ['conceito legal de tri', 'Direito Tributário'],
    ['classicacao tripartid', 'Direito Tributário'], // (sic) typo real do QC: "Classicação"
    ['classificacao triparti', 'Direito Tributário'],
    ['medida cautelar fisca', 'Direito Tributário'],

    // Direito Constitucional
    ['congresso nacional', 'Direito Constitucional'],
    ['senado federal', 'Direito Constitucional'],
    ['camara dos deputados', 'Direito Constitucional'],
    ['principios gerais da', 'Direito Constitucional'],
    ['classificacao das con', 'Direito Constitucional'],
    ['intervencao federal e', 'Direito Constitucional'],
    ['defesa do estado e da', 'Direito Constitucional'],
    ['fundamentos da republ', 'Direito Constitucional'],
    ['objetivos fundamentai', 'Direito Constitucional'],

    // Direito Administrativo
    ['lei n 8112', 'Direito Administrativo'],
    ['orgaos publicos', 'Direito Administrativo'],
    ['mediacao no ambito da', 'Direito Administrativo'],
    ['concurso publico', 'Direito Administrativo'],
    ['administracao publica', 'Direito Administrativo'],
    ['servidores publicos', 'Direito Administrativo'],
    ['administracao indiret', 'Direito Administrativo'],
    ['autarquias', 'Direito Administrativo'],
    ['fundacoes publicas', 'Direito Administrativo'],
    ['principios propor', 'Direito Administrativo'],
    ['desconcentracao e des', 'Direito Administrativo'],

    // Direito Civil
    ['extincao clausula res', 'Direito Civil'],
    ['sucessao testamentari', 'Direito Civil'],
    ['propriedade', 'Direito Civil'],
    ['contratos em especie', 'Direito Civil'],
    ['usucapiao', 'Direito Civil'],
    ['uniao estavel', 'Direito Civil'],
    ['prestacao de servicos', 'Direito Civil'],
    ['formacao dos contrato', 'Direito Civil'],
    ['classificacao dos con', 'Direito Civil'],

    // Direito Processual Civil
    ['fase constitutiva', 'Direito Processual Civil'], // CONFIRA: termo genérico, pode ser de outra fase processual
    ['arbitragem', 'Direito Processual Civil'],
    ['audiencia de instruca', 'Direito Processual Civil'],
    ['teoria geral dos recu', 'Direito Processual Civil'],

    // Direito Previdenciário — "Previdência Social" e "Assistência Social" são
    // dois dos três pilares da Seguridade Social (o terceiro, Saúde, ficou de
    // fora de propósito por ser termo genérico demais pra classificar sozinho).
    ['previdencia social', 'Direito Previdenciário'],
    ['assistencia social', 'Direito Previdenciário'],

    ['modalidades de obrigacoes', 'Direito Civil'],
    ['resposta do reu e revelia', 'Direito Processual Civil'],
    ['citacao no processo civil', 'Direito Processual Civil'],
    ['supremo tribunal federal', 'Direito Constitucional'],
    ['conceito e classificacao', 'Direito Administrativo'],
    ['poderes da administracao', 'Direito Administrativo'],
    ['administracao tributaria', 'Direito Tributário'],
    ['o federalismo brasileiro', 'Direito Constitucional'],
    ['criterios de competencia', 'Direito Processual Civil'],
    ['prescricao e decadencia', 'Direito Civil'],
    ['interpretacao de textos', 'Língua Portuguesa'],
    ['organizacao dos poderes', 'Direito Constitucional'],
    ['cumprimento de sentenca', 'Direito Processual Civil'],
    ['intervencao de terceiro', 'Direito Processual Civil'],
    ['distribuicao e registro', 'Direito Processual Civil'],
    ['conflito de competencia', 'Direito Processual Civil'],
    ['embargos de divergencia', 'Direito Processual Civil'],
    ['responsabilidade civil', 'Direito Administrativo'],
    ['controle da administra', 'Direito Administrativo'],
    ['processo administrativ', 'Direito Administrativo'],
    ['principios fundamentai', 'Direito Constitucional'],
    ['ordem economica e fina', 'Direito Constitucional'],
    ['disposicoes constituci', 'Direito Constitucional'],
    ['direito das obrigacoes', 'Direito Civil'],
    ['poder constituinte ori', 'Direito Constitucional'],
    ['controle de constituci', 'Direito Constitucional'],
    ['direitos da nacionalid', 'Direito Constitucional'],
    ['funcoes essenciais a j', 'Direito Constitucional'],
    ['organizacao da adminis', 'Direito Administrativo'],
    ['parcerias publico priv', 'Direito Administrativo'],
    ['bens publicos na admin', 'Direito Administrativo'],
    ['principios da administ', 'Direito Administrativo'],
    ['agentes publicos e lei', 'Direito Administrativo'],
    ['sistema tributario nac', 'Direito Tributário'],
    ['organizacao politico a', 'Direito Constitucional'],
    ['reparticao de competen', 'Direito Constitucional'],
    ['teoria da constituicao', 'Direito Constitucional'],
    ['regime juridico admini', 'Direito Administrativo'],
    ['empresas publicas e so', 'Direito Administrativo'],
    ['atos administrativos e', 'Direito Administrativo'],
    ['inexigibilidade de lic', 'Direito Administrativo'],
    ['conceito e classificac', 'Direito Administrativo'],
    ['delegacao dos servicos', 'Direito Administrativo'],
    ['nocoes gerais e desapr', 'Direito Administrativo'],
    ['controle administrativ', 'Direito Administrativo'],
    ['poder vinculado e disc', 'Direito Administrativo'],
    ['requisitos do ato admi', 'Direito Administrativo'],
    ['contratos administrati', 'Direito Administrativo'],
    ['improbidade administra', 'Direito Administrativo'],
    ['flexao verbal de numer', 'Língua Portuguesa'],
    ['atos de improbidade ad', 'Direito Administrativo'],
    ['constituicao da relaca', 'Direito do Trabalho'],
    ['organizacao do poder j', 'Direito Constitucional'],
    ['metodos de interpretac', 'Direito Constitucional'],
    ['classificacao das norm', 'Direito Constitucional'],
    ['comissoes parlamentare', 'Direito Constitucional'],
    ['processo legislativo o', 'Direito Constitucional'],
    ['acao direta de inconst', 'Direito Constitucional'],
    ['tribunais de contas do', 'Direito Constitucional'],
    ['dos contratos de natur', 'Direito do Trabalho'],
    ['contrato de trabalho e', 'Direito do Trabalho'],
    ['efeitos e duracao do t', 'Direito do Trabalho'],
    ['cessacao do contrato d', 'Direito do Trabalho'],
    ['sistema recursal traba', 'Direito Processual do Trabalho'],
    ['embargos de declaracao', 'Direito Processual do Trabalho'],
    ['agravos de instrumento', 'Direito Processual do Trabalho'],
    ['competencia tributaria', 'Direito Tributário'],
    ['limitacoes constitucio', 'Direito Tributário'],
    ['solidariedade e respon', 'Direito Tributário'],
    ['suspensao do credito t', 'Direito Tributário'],
    ['extincao do credito tr', 'Direito Tributário'],
    ['exclusao do credito tr', 'Direito Tributário'],
    ['despesas com pessoal e', 'Direito Financeiro'],
    ['lei de responsabilidad', 'Direito Financeiro'],
    ['disposicoes gerais sob', 'Direito Tributário'],
    ['disposicao gerais sobr', 'Direito Tributário'],
    ['vigencia e aplicacao d', 'Direito Tributário'],
    ['teoria dos direitos fu', 'Direito Constitucional'],
    ['juizado especial civel', 'Direito Processual Civil'],
    ['juizado especial da fa', 'Direito Processual Civil'],
    ['suspensao e extincao d', 'Direito Processual Civil'],
    ['audiencia preliminar d', 'Direito Processual Civil'],
    ['da comunicacao dos ato', 'Direito Processual Civil'],
    ['formacao do processo e', 'Direito Processual Civil'],
    ['arguicao de impediment', 'Direito Processual Civil'],
    ['saneamento e fase de s', 'Direito Processual Civil'],
    ['producao antecipada da', 'Direito Processual Civil'],
    ['coisa julgada no proce', 'Direito Processual Civil'],
    ['principios gerais do p', 'Direito Processual Civil'],
    ['aplicacao das normas p', 'Direito Processual Civil'],
    ['conceito e caracterist', 'Direito Processual Civil'],
    ['principios inerentes a', 'Direito Processual Civil'],
    ['classificacao dos recu', 'Direito Processual Civil'],
    ['apelacao no processo c', 'Direito Processual Civil'],
    ['agravo em recurso espe', 'Direito Processual Civil'],
    ['acoes autonomas de imp', 'Direito Processual Civil'],
    ['sujeitos da relacao pr', 'Direito Processual Civil'],
    ['das partes e dos procu', 'Direito Processual Civil'],
    ['mandado de seguranca n', 'Direito Processual Civil'],
    ['tutela provisoria e tu', 'Direito Processual Civil'],
    ['advocacia publica no p', 'Direito Processual Civil'],
    ['incidente de desconsid', 'Direito Processual Civil'],
    ['competencia no process', 'Direito Processual Civil'],
    ['modificacao de compete', 'Direito Processual Civil'],
    ['da nulidade dos atos p', 'Direito Processual Civil'],
    ['procedimentos especiai', 'Direito Processual Civil'],
    ['incidente de resolucao', 'Direito Processual Civil'],
    ['demais legislacoes ext', 'Direito Processual Civil'],
    ['processos de competenc', 'Direito Processual Civil'],
    ['mandado de seguranca c', 'Direito Constitucional'],
    ['processo de execucao d', 'Direito Processual Civil'],
    ['disposicoes gerais e c', 'Direito Processual Civil'],
    ['exigibilidade da obrig', 'Direito Processual Civil'],
    ['cumprimento de sentenc', 'Direito Processual Civil'],
    ['etica e legislacao pro', 'Ética'],
    ['principios das licitac', 'Direito Administrativo'],
    ['modalidades e criterio', 'Direito Administrativo'],
    ['fases e processo licit', 'Direito Administrativo'],
    ['intervencao do estado', 'Direito Administrativo'],
    ['organizacao do estado', 'Direito Constitucional'],
    ['relacao de trabalho e', 'Direito do Trabalho'],
    ['conceitos iniciais de', 'Direito Administrativo'],
    ['associacao sindical e', 'Direito do Trabalho'],
    ['aquisicao e alienacao', 'Direito Administrativo'],
    ['concordancia verbal c', 'Língua Portuguesa'],
    ['poder normativo poder', 'Direito Administrativo'],
    ['vicios redibitorios e', 'Direito Civil'],
    ['disposicoes gerais da', 'Direito Administrativo'],
    ['demais disposicoes da', 'Direito Administrativo'],
    ['principios de direito', 'Direito do Trabalho'],
    ['especies normativas m', 'Direito Constitucional'],
    ['das relacoes laborais', 'Direito do Trabalho'],
    ['jornadas especiais de', 'Direito do Trabalho'],
    ['alteracao interrupcao', 'Direito do Trabalho'],
    ['forma tempo e lugar d', 'Direito Processual do Trabalho'],
    ['legislacao do direito', 'Direito Tributário'],
    ['normas complementares', 'Direito Tributário'],
    ['lancamento tributario', 'Direito Tributário'],
    ['dacao em pagamento de', 'Direito Tributário'],
    ['suspensao do processo', 'Direito Processual Civil'],
    ['improcedencia liminar', 'Direito Processual Civil'],
    ['julgamento conforme o', 'Direito Processual Civil'],
    ['julgamento antecipado', 'Direito Processual Civil'],
    ['teoria geral da prova', 'Direito Processual Civil'],
    ['agravo de instrumento', 'Direito Processual Civil'],
    ['defensoria publica no', 'Direito Processual Civil'],
    ['incidente de assuncao', 'Direito Processual Civil'],
    ['introducao a execucao', 'Direito Processual Civil'],
    ['execucoes especiais e', 'Direito Processual Civil'],
    ['licitacoes e lei n 14', 'Direito Administrativo'],
    ['atos administrativos', 'Direito Administrativo'],
    ['direito das coisas d', 'Direito Civil'],
    ['processo legislativo', 'Direito Constitucional'],
    ['financas publicas or', 'Direito Financeiro'],
    ['personalidade pessoa', 'Direito Civil'],
    ['cargo emprego funcao', 'Direito Administrativo'],
    ['principios legalidad', 'Direito Administrativo'],
    ['principios contradit', 'Direito Processual Civil'],
    ['direitos individuais', 'Direito Constitucional'],
    ['formas de estado est', 'Direito Constitucional'],
    ['efeitos tutela trans', 'Direito Processual Civil'],
    ['atos termos e prazos', 'Direito Processual do Trabalho'],
    ['obrigacao tributaria', 'Direito Tributário'],
    ['capacidade domicilio', 'Direito Tributário'],
    ['extincao do processo', 'Direito Processual Civil'],
    ['efeitos dos recursos', 'Direito Processual Civil'],
    ['conceito competencia', 'Direito Processual Civil'],
    ['processo de execucao', 'Direito Processual Civil'],
    ['vedacoes garantias e', 'Direito Constitucional'],
    ['mandado de seguranca', 'Direito Constitucional'],
    ['da execucao em geral', 'Direito Processual Civil'],
    ['agentes da licitacao', 'Direito Administrativo'],
    ['duracao extincao ine', 'Direito Administrativo'],
    ['duracao do trabalho', 'Direito do Trabalho'],
    ['consorcios publicos', 'Direito Administrativo'],
    ['posse teoria classi', 'Direito Civil'],
    ['direito a liberdade', 'Direito Constitucional'],
    ['indenizacao liquida', 'Direito do Trabalho'],
    ['tributos municipais', 'Direito Tributário'],
    ['tutela de evidencia', 'Direito Processual Civil'],
    ['denunciacao da lide', 'Direito Processual Civil'],
    ['processo eletronico', 'Direito Processual Civil'],
    ['mandado de injuncao', 'Direito Constitucional'],
    ['direitos politicos', 'Direito Constitucional'],
    ['contratos em geral', 'Direito Civil'],
    ['ministerio publico', 'Direito Constitucional'],
    ['recurso de revista', 'Direito Processual do Trabalho'],
    ['trabalho da mulher', 'Direito do Trabalho'],
    ['prazos processuais', 'Direito Processual Civil'],
    ['remessa necessaria', 'Direito Processual Civil'],
    ['acoes possessorias', 'Direito Processual Civil'],
    ['acao civil publica', 'Direito Processual Civil'],
    ['contratacao direta', 'Direito Administrativo'],
    ['poder legislativo', 'Direito Constitucional'],
    ['servicos publicos', 'Direito Administrativo'],
    ['morfologia verbos', 'Língua Portuguesa'],
    ['recurso ordinario', 'Direito Processual do Trabalho'],
    ['a despesa publica', 'Direito Financeiro'],
    ['tutela provisoria', 'Direito Processual Civil'],
    ['direitos sociais', 'Direito Constitucional'],
    ['poder de policia', 'Direito Administrativo'],
    ['juizado especial', 'Direito Processual Civil'],
    ['recurso especial', 'Direito Processual Civil'],
    ['atos processuais', 'Direito Processual Civil'],
    ['pessoa juridica', 'Direito Civil'],
    ['poder executivo', 'Direito Constitucional'],
    ['politica urbana', 'Direito Constitucional'],
    ['acao rescisoria', 'Direito Processual Civil'],
    ['abuso de poder', 'Direito Administrativo'],
    ['valor da causa', 'Direito Processual Civil'],
    ['agravo interno', 'Direito Processual Civil'],
    ['aviso previo', 'Direito do Trabalho'],
    ['fato gerador', 'Direito Tributário'],
    ['parte geral', 'Direito Civil'],
    ['contestacao', 'Direito Processual Civil'],
    ['habeas data', 'Direito Constitucional'],
    ['tombamento', 'Direito Administrativo'],
    ['jurisdicao', 'Direito Processual Civil'],
    ['dos prazos', 'Direito Processual Civil'],
    ['intimacoes', 'Direito Processual Civil'],
    ['reclamacao', 'Direito Processual Civil'],
    ['pontuacao', 'Língua Portuguesa'],
    ['ausencia', 'Direito Civil'],
    ['sentenca', 'Direito Processual Civil'],
    ['recursos', 'Direito Processual Civil'],
    ['sintaxe', 'Língua Portuguesa'],
    ['isencao', 'Direito Tributário'],
    ['anistia', 'Direito Tributário'],
    ['do juiz', 'Direito Processual Civil'],
    ['iptu', 'Direito Tributário'],
    ['acao', 'Direito Processual Civil'],
];

function _buscarMatchExato(normalizado) {
    if (!normalizado) return null;
    for (const [chave, materia] of CB_MATCH_EXATO) {
        // Bidirecional: o nome capturado do QC pode vir truncado de formas
        // diferentes em sincronizações diferentes (às vezes mais curto,
        // às vezes mais longo que o prefixo salvo aqui). Checar só
        // `normalizado.startsWith(chave)` perde os casos em que o texto
        // capturado ficou MAIS CURTO que o prefixo (ex: "Noções e
        // Princípios d..." truncado antes de completar "direito"), porque
        // aí é a string curta que teria que começar com a longa — nunca
        // bate. Mesma lógica já aplicada no override manual (Camada 0).
        if (normalizado.startsWith(chave) || chave.startsWith(normalizado)) return materia;
    }
    return null;
}

// Ordem importa: matérias mais "específicas" primeiro, pra não perder para
// termos genéricos de matérias mais amplas (ex: "processual do trabalho"
// tem que ser testada antes de "trabalho" sozinho).
const CB_DICIONARIO_MATERIAS = [
    {
        materia: 'Direito Processual do Trabalho',
        chaves: [
            'processual do trabalho', 'audiencia trabalhista', 'recursos trabalhistas',
            'execucao trabalhista', 'competencia da justica do trabalho'
        ]
    },
    {
        materia: 'Direito do Trabalho',
        chaves: [
            'jornada de trabalho', 'ferias', 'remuneracao', 'contrato de trabalho',
            'organizacao sindical', 'negociacao coletiva', 'clt', 'aviso previo',
            'fgts', 'rescisao'
        ]
    },
    {
        materia: 'Direito Processual Civil',
        chaves: [
            'cpc', 'tutela provisoria', 'cumprimento de sentenca', 'juizados especiais',
            'processo civil', 'peticao inicial', 'recursos civeis', 'execucao de titulo'
        ]
    },
    {
        materia: 'Direito Tributário',
        chaves: [
            'tributario', 'tributos', 'obrigacao tributaria', 'credito tributario',
            'execucao fiscal', 'ctn', 'imposto', 'taxa administrativa', 'contribuicao de melhoria'
        ]
    },
    {
        materia: 'Direito Financeiro',
        chaves: [
            'financeiro', 'responsabilidade fiscal', 'lei 4320', 'orcamento publico',
            'lrf'
        ]
    },
    {
        materia: 'Direito Administrativo',
        chaves: [
            'atos administrativos', 'processo administrativo', 'licitac', 'contratos administrativos',
            'servicos publicos', 'intervencao do estado', 'agentes publicos', 'improbidade administrativa',
            'controle da administracao', 'organizacao administrativa', 'estatais', 'lei 8 112',
            'servidor publico', 'desapropriacao', 'poder de policia', 'terceiro setor'
        ]
    },
    {
        materia: 'Direito Constitucional',
        chaves: [
            'controle de constitucionalidade', 'direitos e garantias fundamentais', 'poder legislativo',
            'poder executivo', 'poder judiciario', 'organizacao do estado', 'ordem social',
            'ordem economica', 'direitos sociais', 'poder constituinte', 'principios fundamentai',
            'acao direta de inconstitucionalidade', 'mandado de injuncao', 'habeas corpus',
            'habeas data', 'mandado de seguranca'
        ]
    },
    {
        materia: 'Direito Civil',
        chaves: [
            'responsabilidade civil', 'direito das coisas', 'direito de familia', 'direito das sucessoes',
            'lindb', 'introducao as normas', 'ato juridico', 'fato juridico', 'obrigacoes',
            'contratos em geral', 'direitos reais', 'parcelamento do solo', 'pessoa juridica',
            'pessoa natural', 'prescricao e decadencia civil', 'negocio juridico'
        ]
    },
    // Categorias genéricas comuns a quase todo concurso, não específicas de
    // Direito — ajudam quem estuda pra outras áreas (TI, saúde, técnico
    // administrativo etc). Continuam restritas a termos bem específicos por
    // segurança (mesma regra de ouro: melhor "Não classificado" que errar).
    {
        materia: 'Língua Portuguesa',
        chaves: [
            'concordancia verbal', 'concordancia nominal', 'regencia verbal', 'regencia nominal',
            'crase', 'pontuacao', 'interpretacao de texto', 'morfologia', 'sintaxe',
            'flexao verbal', 'flexao nominal', 'ortografia', 'acentuacao grafica', 'colocacao pronominal',
            'figuras de linguagem', 'coesao e coerencia', 'classes gramaticais', 'vozes verbais',
            'redacao oficial'
        ]
    },
    {
        materia: 'Matemática',
        chaves: [
            'razao e proporcao', 'regra de tres', 'porcentagem', 'juros simples', 'juros compostos',
            'progressao aritmetica', 'progressao geometrica', 'equacao do', 'sistema de equacoes',
            'analise combinatoria', 'probabilidade', 'geometria plana', 'geometria espacial',
            'matematica financeira'
        ]
    },
    {
        materia: 'Raciocínio Lógico',
        chaves: [
            'raciocinio logico', 'logica proposicional', 'logica de argumentacao', 'proposicoes logicas',
            'diagramas logicos', 'sequencias logicas', 'estruturas logicas'
        ]
    },
    {
        materia: 'Informática',
        chaves: [
            'informatica', 'excel', 'word', 'powerpoint', 'redes de computadores', 'seguranca da informacao',
            'sistema operacional', 'hardware', 'software', 'internet e navegadores'
        ]
    },
    {
        materia: 'Atualidades',
        chaves: ['atualidades', 'conhecimentos gerais']
    }
];

// Classifica um único assunto. Retorna { materia, confianca } —
// 'manual' = corrigido pelo próprio usuário (prioridade máxima, nunca
// sobrescrita pelo dicionário); 'exata'/'alta' = veio do dicionário local.
// `overrides` é um objeto { nomeNormalizado: materia }, opcional.
function classificarAssunto(nomeAssunto, overrides) {
    const normalizado = _normalizar(nomeAssunto);

    // Camada 0: correção manual do usuário — sempre vence, é a fonte da
    // verdade mais confiável que existe (a própria pessoa disse qual é).
    // Casa por PREFIXO nos dois sentidos (não igualdade exata) pelo mesmo
    // motivo da Camada 1 logo abaixo: o nome do assunto pode chegar
    // truncado de formas diferentes em sincronizações diferentes (o QC
    // corta com "..." e o ponto de corte/o texto disponível — `title` vs
    // texto visível — pode variar). Uma comparação exata faz o override
    // "não colar" silenciosamente sempre que a string mudar um caractere
    // sequer da que foi usada pra salvar a correção.
    if (overrides && normalizado) {
        const chaveOverride = Object.keys(overrides).find(
            (k) => k && (normalizado.startsWith(k) || k.startsWith(normalizado))
        );
        if (chaveOverride) {
            return { materia: overrides[chaveOverride], confianca: 'manual' };
        }
    }

    // Camada 1: match exato/prefixo contra a lista revisada manualmente —
    // mais confiável, checa primeiro.
    const materiaExata = _buscarMatchExato(normalizado);
    if (materiaExata) {
        return { materia: materiaExata, confianca: 'exata' };
    }

    // Camada 2: dicionário de palavras-chave (mais genérico, cobre casos
    // que a lista exata ainda não viu).
    for (const grupo of CB_DICIONARIO_MATERIAS) {
        for (const chave of grupo.chaves) {
            if (normalizado.includes(chave)) {
                return { materia: grupo.materia, confianca: 'alta' };
            }
        }
    }
    return { materia: 'Não classificado', confianca: null };
}

// Nomes de matéria conhecidos pelo dicionário (pra sugerir no autocomplete
// do popup quando o usuário for corrigir manualmente um assunto).
function listarMateriasConhecidas() {
    const nomes = new Set();
    CB_MATCH_EXATO.forEach(([, materia]) => nomes.add(materia));
    CB_DICIONARIO_MATERIAS.forEach(grupo => nomes.add(grupo.materia));
    return Array.from(nomes).sort();
}

// Classifica uma lista inteira de itens {nome, certas, erradas, total} e
// devolve agrupado por matéria, cada grupo já ordenado por mais erros
// primeiro (o pedido central: priorizar o que a pessoa mais erra).
// `overrides` (opcional) tem prioridade sobre qualquer dicionário.
function agruparAssuntosPorMateria(itens, overrides) {
    const grupos = {};
    itens.forEach(item => {
        const { materia } = classificarAssunto(item.nome, overrides);
        if (!grupos[materia]) grupos[materia] = [];
        grupos[materia].push(item);
    });

    Object.keys(grupos).forEach(materia => {
        grupos[materia].sort((a, b) => {
            // Prioriza quem tem mais erradas; empate desempata por menor % de acerto
            if (b.erradas !== a.erradas) return b.erradas - a.erradas;
            const pctA = a.total > 0 ? a.certas / a.total : 1;
            const pctB = b.total > 0 ? b.certas / b.total : 1;
            return pctA - pctB;
        });
    });

    // "Não classificado" sempre por último, o resto por volume de erros
    const materiasOrdenadas = Object.keys(grupos)
        .filter(m => m !== 'Não classificado')
        .sort((a, b) => {
            const errosA = grupos[a].reduce((s, i) => s + i.erradas, 0);
            const errosB = grupos[b].reduce((s, i) => s + i.erradas, 0);
            return errosB - errosA;
        });
    if (grupos['Não classificado']) materiasOrdenadas.push('Não classificado');

    return materiasOrdenadas.map(materia => ({ materia, itens: grupos[materia] }));
}

// IMPORTANTE: usar `self` em vez de `window` aqui. Este arquivo é carregado
// tanto no content script (que roda no contexto da página, onde `window`
// existe) quanto no background.js via importScripts() — e o background.js
// da Manifest V3 é um Service Worker, que NÃO tem `window`. Tentar escrever
// em `window` ali lança "ReferenceError: window is not defined" e derruba
// o carregamento inteiro do background.js (silenciosamente, sem aparecer
// pro usuário), o que quebra o handler 'sincronizar_assuntos_qc' e faz os
// assuntos nunca sincronizarem. `self` funciona nos dois ambientes: em uma
// página normal `self === window`; num Service Worker, `self` é o próprio
// escopo global.
self.CBDicionarioMaterias = {
    classificarAssunto,
    agruparAssuntosPorMateria,
    listarMateriasConhecidas,
    normalizar: _normalizar
};
