// ===================== PLANO DE ESTUDOS POR EDITAL — NÚCLEO =====================
//
// Lógica pura (sem DOM, sem chrome.*): roda igual no popup, na página do plano
// e em Node (os testes em plano/testes usam este mesmo arquivo).
//
// Divisão de responsabilidades — de propósito:
//   • A IA só LÊ o edital (cargos, data da prova, matérias e tópicos). Esse é o
//     trabalho em que ela é boa e em que um erro é visível e editável pela
//     pessoa antes de salvar.
//   • O CRONOGRAMA em si (quem estuda o quê em cada dia) é montado aqui, por
//     código determinístico. Assim "nunca juntar conteúdo grande no mesmo dia"
//     é uma regra garantida e testável, não um pedido que a IA pode esquecer.
//
// Dados guardados (chrome.storage.local):
//   planoEstudo     → o plano (ver gerarPlano)
//   planoRegistros  → { [itemId]: { feito, acertos, erros, ajusteMin } }  (escrito pela UI)
//   planoTempo      → { [itemId]: ms cronometrados }                       (escrito SÓ pelo background)
//   planoItemAtivo  → { id, materiaId, dia }  item que está recebendo o tempo do cronômetro
// Registros e tempo ficam em chaves separadas porque o background grava o tempo
// a cada segundo: se dividissem o mesmo objeto, um sobrescreveria o outro.

(function (root) {
    'use strict';

    // ----------------------------------------------------------------- constantes
    // Minutos de estudo (teoria + questões) por tamanho de tópico.
    const PESO_MIN = { 1: 30, 2: 60, 3: 120 };
    const PESO_ROTULO = { 1: 'leve', 2: 'médio', 3: 'extenso' };
    const QUESTOES_SUGERIDAS = { 1: 5, 2: 10, 3: 15 };
    const CORES_MATERIA = ['#8b5cf6', '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#ec4899', '#14b8a6', '#84cc16', '#f97316', '#6366f1'];
    const MAX_DIAS = 1200;

    // ----------------------------------------------------------------- utilidades
    const pad2 = (n) => String(n).padStart(2, '0');

    function semAcento(s) {
        return String(s == null ? '' : s).normalize('NFD').replace(/[̀-ͯ]/g, '');
    }
    function norm(s) {
        return semAcento(s).toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
    }
    function cortar(s, max) {
        const t = String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
        return t.length > max ? t.slice(0, max - 1).trimEnd() + '…' : t;
    }
    function arred5(n, modo) {
        const v = n / 5;
        return 5 * (modo === 'cima' ? Math.ceil(v - 1e-9) : Math.round(v));
    }

    // Datas como "AAAA-MM-DD" (sem fuso): toda conta passa por UTC pra não
    // errar um dia na virada do horário de verão.
    function parseData(s) {
        const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s || ''));
        if (!m) return NaN;
        return Date.UTC(+m[1], +m[2] - 1, +m[3]);
    }
    function fmtData(ms) {
        const d = new Date(ms);
        return `${d.getUTCFullYear()}-${pad2(d.getUTCMonth() + 1)}-${pad2(d.getUTCDate())}`;
    }
    function addDias(s, n) { return fmtData(parseData(s) + n * 86400000); }
    function diffDias(a, b) { return Math.round((parseData(b) - parseData(a)) / 86400000); }
    function diaSemana(s) { return new Date(parseData(s)).getUTCDay(); }
    // Date.UTC "arruma" datas impossíveis (mês 13 vira janeiro do ano seguinte),
    // então só vale se ida e volta devolverem exatamente o texto de entrada.
    function dataValida(s) {
        const ms = parseData(s);
        return Number.isFinite(ms) && fmtData(ms) === s;
    }
    function hojeStr(agora) {
        const d = agora ? new Date(agora) : new Date();
        return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
    }
    function fmtBR(s) {
        const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s || ''));
        return m ? `${m[3]}/${m[2]}/${m[1]}` : '';
    }
    const DIAS_SEM = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
    function nomeDiaSemana(s) { return DIAS_SEM[diaSemana(s)]; }

    function fmtMin(min) {
        min = Math.max(0, Math.round(min));
        const h = Math.floor(min / 60), m = min % 60;
        if (!h) return `${m} min`;
        return m ? `${h}h${pad2(m)}` : `${h}h`;
    }

    // ----------------------------------------------------------------- codificação do PDF
    // Alguns PDFs (os gerados no Mac/Word, e boa parte dos editais baixados do PCI)
    // gravam o texto em Windows-1252 mas declaram a fonte como MacRoman. O pdf.js
    // obedece à declaração e devolve "C¬MARA", "P⁄BLICO", "hor·rios", "N∫" em vez de
    // "CÂMARA", "PÚBLICO", "horários", "Nº". Sem o conserto a IA não reconhece "cargo",
    // "conteúdo programático" nem "prova", e o plano local não acha nada.
    // A conversão é bijetora: cada símbolo MacRoman volta ao byte original e é relido
    // como Windows-1252. Decide-se POR FONTE (um mesmo PDF mistura fontes certas e
    // erradas), e só quando o texto da fonte fica claramente mais português depois.
    const MAC_ALTO = '\u00c4\u00c5\u00c7\u00c9\u00d1\u00d6\u00dc\u00e1\u00e0\u00e2\u00e4\u00e3\u00e5\u00e7\u00e9\u00e8\u00ea\u00eb\u00ed\u00ec\u00ee\u00ef\u00f1\u00f3\u00f2\u00f4\u00f6\u00f5\u00fa\u00f9\u00fb\u00fc\u2020\u00b0\u00a2\u00a3\u00a7\u2022\u00b6\u00df\u00ae\u00a9\u2122\u00b4\u00a8\u2260\u00c6\u00d8\u221e\u00b1\u2264\u2265\u00a5\u00b5\u2202\u2211\u220f\u03c0\u222b\u00aa\u00ba\u03a9\u00e6\u00f8\u00bf\u00a1\u00ac\u221a\u0192\u2248\u2206\u00ab\u00bb\u2026\u00a0\u00c0\u00c3\u00d5\u0152\u0153\u2013\u2014\u201c\u201d\u2018\u2019\u00f7\u25ca\u00ff\u0178\u2044\u20ac\u2039\u203a\ufb01\ufb02\u2021\u00b7\u201a\u201e\u2030\u00c2\u00ca\u00c1\u00cb\u00c8\u00cd\u00ce\u00cf\u00cc\u00d3\u00d4\uf8ff\u00d2\u00da\u00db\u00d9\u0131\u02c6\u02dc\u00af\u02d8\u02d9\u02da\u00b8\u02dd\u02db\u02c7';
    const WIN_ALTO = '\u20ac\u0081\u201a\u0192\u201e\u2026\u2020\u2021\u02c6\u2030\u0160\u2039\u0152\u008d\u017d\u008f\u0090\u2018\u2019\u201c\u201d\u2022\u2013\u2014\u02dc\u2122\u0161\u203a\u0153\u009d\u017e\u0178\u00a0\u00a1\u00a2\u00a3\u00a4\u00a5\u00a6\u00a7\u00a8\u00a9\u00aa\u00ab\u00ac\u00ad\u00ae\u00af\u00b0\u00b1\u00b2\u00b3\u00b4\u00b5\u00b6\u00b7\u00b8\u00b9\u00ba\u00bb\u00bc\u00bd\u00be\u00bf\u00c0\u00c1\u00c2\u00c3\u00c4\u00c5\u00c6\u00c7\u00c8\u00c9\u00ca\u00cb\u00cc\u00cd\u00ce\u00cf\u00d0\u00d1\u00d2\u00d3\u00d4\u00d5\u00d6\u00d7\u00d8\u00d9\u00da\u00db\u00dc\u00dd\u00de\u00df\u00e0\u00e1\u00e2\u00e3\u00e4\u00e5\u00e6\u00e7\u00e8\u00e9\u00ea\u00eb\u00ec\u00ed\u00ee\u00ef\u00f0\u00f1\u00f2\u00f3\u00f4\u00f5\u00f6\u00f7\u00f8\u00f9\u00fa\u00fb\u00fc\u00fd\u00fe\u00ff';
    const PT_VALIDOS = new Set(('áàâãéêíóôõúüçÁÀÂÃÉÊÍÓÔÕÚÜÇ' + 'ºª°§²³«»“”‘’–—•…€·¹').split(''));
    let mapaMac = null;

    function converterMacParaWin(s) {
        if (!mapaMac) {
            mapaMac = new Map();
            for (let i = 0; i < MAC_ALTO.length; i++) mapaMac.set(MAC_ALTO[i], WIN_ALTO[i]);
        }
        return String(s).replace(/[^\x00-\x7f]/g, (c) => mapaMac.get(c) || c);
    }
    // Quantos símbolos "que não existem em português" o texto tem (¬ ⁄ ∫ Ì Ù ∂ ...).
    function contarEstranhos(s) {
        let n = 0;
        for (const c of String(s)) if (c.charCodeAt(0) > 127 && !PT_VALIDOS.has(c)) n++;
        return n;
    }
    // Uma fonte é "MacRoman por engano" quando o texto dela tem símbolos estranhos
    // e, depois de convertido, quase todos somem.
    function fonteEhMacRoman(textos) {
        const t = textos.join(' ');
        const antes = contarEstranhos(t);
        if (antes < 2) return false;
        const depois = contarEstranhos(converterMacParaWin(t));
        return depois * 4 <= antes;
    }
    // paginas: array (por página) de arrays de itens do pdf.js ({ str, fontName, ... }).
    // Devolve { paginas, corrigidas: [fontes convertidas] } e conserta os itens no lugar.
    function corrigirCodificacaoPdf(paginas) {
        const porFonte = new Map();
        (paginas || []).forEach((itens) => (itens || []).forEach((it) => {
            if (!it || typeof it.str !== 'string' || !/[^\x00-\x7f]/.test(it.str)) return;
            const f = it.fontName || '';
            if (!porFonte.has(f)) porFonte.set(f, []);
            porFonte.get(f).push(it.str);
        }));
        const corrigidas = [];
        porFonte.forEach((textos, f) => { if (fonteEhMacRoman(textos)) corrigidas.push(f); });
        if (corrigidas.length) {
            const set = new Set(corrigidas);
            (paginas || []).forEach((itens) => {
                (itens || []).forEach((it) => {
                    if (it && typeof it.str === 'string' && set.has(it.fontName || '')) it.str = converterMacParaWin(it.str);
                });
                // "Ê" maiúsculo é o byte 0xCA, que no MacRoman é o ESPAÇO DE NÃO-QUEBRA: o pdf.js o entrega
                // sozinho, numa fonte própria, e "CONCORRÊNCIA" vira "CONCORR NCIA". Espaço de não-quebra
                // colado em maiúsculas dos dois lados, num PDF já sabido como errado, é esse "Ê".
                (itens || []).forEach((it, i) => {
                    if (!it || it.str !== ' ') return;
                    const antes = String((itens[i - 1] || {}).str || '').slice(-1);
                    const depois = String((itens[i + 1] || {}).str || '').slice(0, 1);
                    if (/[A-ZÀ-ÝÇ]/.test(antes) && /[A-ZÀ-ÝÇ]/.test(depois)) it.str = 'Ê';
                });
            });
        }
        return { paginas, corrigidas };
    }

    // ----------------------------------------------------------------- texto do PDF
    // paginas: array de strings, uma por página (cada uma já com quebras de linha).
    // Remove cabeçalho/rodapé repetido (aparece em boa parte das páginas), número
    // de página solto e marcas d'água — esse lixo polui o que a IA lê.
    function prepararTexto(paginas) {
        const pags = (paginas || []).map((p) => String(p || '').split(/\r?\n/).map((l) => l.replace(/\s+/g, ' ').trim()));
        const contagem = new Map();
        pags.forEach((linhas) => {
            new Set(linhas.filter((l) => l && l.length <= 140)).forEach((l) => contagem.set(l, (contagem.get(l) || 0) + 1));
        });
        const limite = pags.length >= 6 ? Math.max(4, Math.ceil(pags.length * 0.4)) : Infinity;
        const lixo = (l) =>
            !l ||
            /^p[áa]gina\s+\d+(\s+de\s+\d+)?$/i.test(l) ||
            /^\d{1,3}$/.test(l) ||
            /^pcimark/i.test(l) ||
            /^www\.pciconcursos/i.test(l) ||
            (contagem.get(l) || 0) >= limite;
        const linhas = [];
        pags.forEach((pl) => pl.forEach((l) => { if (!lixo(l)) linhas.push(l); else if (!l && linhas.length && linhas[linhas.length - 1] !== '') linhas.push(''); }));
        return { linhas, texto: linhas.join('\n') };
    }

    // Linha "de título": quase toda em caixa alta, curta, sem pontuação de frase.
    function ehTitulo(l) {
        const t = String(l || '').trim();
        if (t.length < 3 || t.length > 110) return false;
        const letras = t.replace(/[^A-Za-zÀ-ÖØ-öø-ÿ]/g, '');
        if (letras.length < 3) return false;
        const maius = letras.replace(/[^A-ZÀ-ÖØ-Þ]/g, '').length;
        if (maius / letras.length < 0.85) return false;
        return !/[.;]\s*$/.test(t);
    }

    const RE_ANEXO = /^\s*ANEXO\s+([IVXLC]+|\d+)\b/i;
    const RE_CONTEUDO = /(conte[úu]dos?\s+program[áa]tic|programas?\s+(das?\s+)?(provas?|mat[ée]rias?|concurso)|conte[úu]dos?\s+das?\s+provas?|conte[úu]dos?\s+exigid|conhecimentos\s+exigid)/i;

    // Onde termina a seção que começa na linha i: anexo/título solto vai até o
    // próximo ANEXO; item numerado ("9.2. Conteúdo programático...") vai até o
    // próximo item de nível 1 ("10. DOS RECURSOS") ou até o próximo ANEXO.
    function fimDaSecao(linhas, i) {
        const m = /^\s*(\d+)\.?(\d+\.?)*\s/.exec(linhas[i]);
        const topo = m && !RE_ANEXO.test(linhas[i]) ? m[1] : null;
        for (let j = i + 1; j < linhas.length; j++) {
            if (RE_ANEXO.test(linhas[j])) return j;
            if (topo) {
                const n = /^\s*(\d+)\.?\s+\S/.exec(linhas[j]);
                if (n && n[1] !== topo && ehTitulo(linhas[j])) return j;
            }
        }
        return linhas.length;
    }

    // A linha i continua uma frase que o PDF quebrou? (a anterior não fecha frase nem é título)
    function continuaFrase(linhas, i) {
        let k = i - 1;
        while (k >= 0 && !linhas[k]) k--;
        if (k < 0) return false;
        const ant = linhas[k].trim();
        if (RE_ANEXO.test(ant) || ehTitulo(ant)) return false;
        return !/[.:;!?)”"]$/.test(ant);
    }

    // Acha o anexo de conteúdo programático. Entre os candidatos (o sumário do
    // edital também cita "Conteúdo Programático") vale o de seção mais longa.
    function acharAnexoConteudo(linhas) {
        let melhor = null;
        for (let i = 0; i < linhas.length; i++) {
            const l = linhas[i];
            if (l.length > 150 || !RE_CONTEUDO.test(l)) continue;
            // Cabeçalho = ANEXO, linha em caixa alta, ou item que COMEÇA falando do
            // conteúdo ("9.2. Conteúdo programático..."). Uma frase que só cita o
            // termo no meio ("5.1 A prova abrangerá os conteúdos programáticos...") não é.
            const numerada = /^\s*\d+(\.\d+)*\.?\s+/.test(l);
            const comecaComTermo = /^\s*(\d+(\.\d+)*\.?\s+)?(d[aoe]s?\s+)?(conte[úu]dos?|programas?|conhecimentos)\b/i.test(l);
            // Sem número e sem caixa alta, "Conteúdo programático constante do Anexo III deste Edital."
            // é só a 2ª linha de uma frase que o PDF quebrou ("...de acordo com o" / "conteúdo...").
            // Tratar isso como título fazia a "seção" ir dali até o fim do edital.
            const cabecalhoSolto = comecaComTermo && (numerada || !continuaFrase(linhas, i));
            const ehCabecalho = RE_ANEXO.test(l) || ehTitulo(l) || cabecalhoSolto;
            if (!ehCabecalho) continue;
            const fim = fimDaSecao(linhas, i);
            const tamanho = linhas.slice(i + 1, fim).join('\n').length;
            // "ANEXO III" numa linha e "CONTEÚDOS PROGRAMÁTICOS..." na seguinte: o anexo é o conjunto.
            const ehAnexo = RE_ANEXO.test(l) || (i > 0 && RE_ANEXO.test(linhas[i - 1]));
            if (tamanho >= 500 && (!melhor || tamanho > melhor.tamanho)) melhor = { inicio: i + 1, fim, tamanho, titulo: l, linhaTitulo: i, ehAnexo };
        }
        // Item numerado ("9.2. Conteúdo programático comum...") costuma ter irmãos
        // ("9.3. ...específico") dentro do mesmo item de nível 1: pega o nível 1 inteiro.
        if (melhor && !RE_ANEXO.test(melhor.titulo)) {
            const m = /^\s*(\d+)\./.exec(melhor.titulo);
            if (m) {
                const reTopo = new RegExp('^\\s*' + m[1] + '\\.?\\s+\\S');
                for (let k = melhor.linhaTitulo; k >= Math.max(0, melhor.linhaTitulo - 400); k--) {
                    if (reTopo.test(linhas[k]) && !/^\s*\d+\.\d/.test(linhas[k])) {
                        const fimTopo = fimDaSecao(linhas, k);
                        const tam = linhas.slice(k + 1, fimTopo).join('\n').length;
                        if (tam <= 60000) melhor = { ...melhor, inicio: k + 1, fim: fimTopo, tamanho: tam, ehAnexo: false };
                        break;
                    }
                }
            }
        }
        return melhor;
    }

    // Seção "DAS PROVAS": quando o edital não tem anexo de conteúdo, é nela que as
    // matérias costumam estar listadas (às vezes só os nomes, sem detalhar).
    function acharSecaoProvas(linhas, maxChars) {
        maxChars = maxChars || 9000;
        const reNumerada = /^\s*\d+(\.\d+)*\.?\s+(d[aoe]s?\s+)?(provas?|prova objetiva|provas objetivas|prova escrita)\b/i;
        const reSolta = /^(d[aoe]s?\s+)?(provas?|prova objetiva|provas objetivas)\b/i;
        for (let i = 0; i < linhas.length; i++) {
            const l = linhas[i];
            if (l.length > 160) continue;
            if (!reNumerada.test(l) && !(reSolta.test(l) && ehTitulo(l))) continue;
            const bloco = linhas.slice(i, i + 160).join('\n').slice(0, maxChars);
            if (/quest[õo]es|disciplinas|mat[ée]rias|conhecimentos|conte[úu]dos?\s+program/i.test(bloco)) return { inicio: i, texto: bloco };
        }
        return null;
    }

    // Quadro de questões por disciplina: acha pelos rótulos típicos da tabela
    // ("Número de questões", "Valor por questão"...) em vez de pelo título da seção.
    // Atenção ao \b: sem ele "Caderno de Questões" casava com "nº de questões" ("no de quest").
    function acharEstruturaProva(linhas, maxChars, limiteLinha) {
        maxChars = maxChars || 6500;
        // limiteLinha: primeira linha do anexo de conteúdo. O quadro de questões nunca
        // deve avançar pra dentro dele (lá está o conteúdo de OUTROS cargos).
        if (limiteLinha != null) linhas = linhas.slice(0, limiteLinha);
        const re = /\b(n[úu]mero|n[ºo°]|quantidade|qtd\.?)\s+de\s+quest|\bvalor\s+(por|da|das)\s+quest|\bpontos?\s+por\s+quest|\bpeso\s+(da|por)\s+quest|quadro\s+(de\s+)?(provas?|quest)|quadro\s+(a\s+seguir|abaixo)|distribui[çc][ãa]o\s+d[ae]s?\s+quest|\btipo\s+de\s+quest|^\s*(item\s+)?(disciplina|mat[ée]ria|[áa]rea\s+de\s+conhecimento)\b/i;
        const janelas = [];
        for (let i = 0; i < linhas.length; i++) {
            // Cabeçalhos de tabela costumam quebrar em duas linhas ("Nº de" / "Questões"):
            // testa a linha sozinha e emendada com a seguinte.
            // (não emenda com uma linha que abre item numerado: o gatilho seria dela, não desta)
            const prox = linhas[i + 1] || '';
            const proxAbreItem = /^\s*\d+(\.\d+)+\.?\s+\S/.test(prox);
            if (!re.test(linhas[i]) && !(!proxAbreItem && re.test(linhas[i] + ' ' + prox))) continue;
            // Se o próprio gatilho é um item numerado ("10.4.4 ...conforme o quadro a seguir:"),
            // ele ABRE uma seção nova: não olha pra trás e nunca se funde com a janela anterior
            // (senão a tabela de TÍTULOS se grudava na tabela de questões).
            const abreSecao = /^\s*\d+(\.\d+)+\.?\s+\S/.test(linhas[i]);
            const ini = abreSecao ? i : Math.max(0, i - 3);
            let fim = Math.min(linhas.length, i + 18);
            // A tabela acaba quando começa o próximo item numerado.
            for (let j = i + 4; j < fim; j++) {
                if (/^\s*\d+(\.\d+)+\.?\s+\S/.test(linhas[j])) { fim = j; break; }
            }
            const ult = janelas[janelas.length - 1];
            if (ult && !abreSecao && ini <= ult.fim) ult.fim = Math.max(ult.fim, fim);
            else janelas.push({ ini, fim });
        }
        // Prefere as janelas que realmente parecem a tabela de questões da prova objetiva:
        // várias linhas com números, menção a questões/objetiva — e longe da tabela de TÍTULOS.
        const pontuadas = janelas
            .map((j) => {
                const bloco = linhas.slice(j.ini, j.fim);
                const txt = bloco.join(' ');
                const comNumero = bloco.filter((l) => /\b\d{1,3}(,\d)?\b/.test(l)).length;
                const fala = /quest[õo]es|pontos/i.test(txt);
                let score = fala ? comNumero : 0;
                if (/quest[õo]es/i.test(txt)) score += 4;
                if (/objetiva/i.test(txt)) score += 3;
                if (/l[ií]ngua portuguesa|matem[áa]tica|conhecimentos/i.test(txt)) score += 3;
                if (/t[ií]tulos?|doutorado|mestrado/i.test(txt)) score -= 8;
                return { j, bloco, score };
            })
            .filter((x) => x.score >= 6);
        if (pontuadas.length) {
            const melhores = pontuadas.sort((a, b) => b.score - a.score).slice(0, 3).sort((a, b) => a.j.ini - b.j.ini);
            return melhores.map((x) => x.bloco.join('\n')).join('\n---\n').slice(0, maxChars);
        }
        const sec = acharSecaoProvas(linhas, maxChars);
        return sec ? sec.texto : '';
    }

    // Datas em três formas: 08/11/2026, 08/11/26 (cronogramas em tabela costumam
    // abreviar o ano — só com "/", pra "1.7.10" de item de edital não virar data),
    // 08.11.2026 e "8 de novembro de 2026".
    const RE_DATA = /\b(\d{1,2})\s*\/\s*(\d{1,2})\s*\/\s*(\d{4}|\d{2})\b|\b(\d{1,2})\s*\.\s*(\d{1,2})\s*\.\s*(\d{4})\b|\b(\d{1,2})\s+de\s+(janeiro|fevereiro|mar[çc]o|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)\s+de\s+(\d{4})\b/i;
    const RE_PROVA_DATA = /prova\s+(objetiva|escrita|te[óo]rica|dissertativa|discursiva)|aplica[çc][ãa]o\s+d[ae]s?\s+prova|realiza[çc][ãa]o\s+d[ae]s?\s+prova|data\s+da\s+prova|\bprova\b.*\b(ser[áa]|ser[ãa]o)\s+(realizada|aplicada)/i;
    // Linhas que falam da prova e trazem uma data — insumo pra IA achar a data da prova.
    // As de "realização/aplicação" vêm primeiro: são as que dizem o dia da prova de verdade
    // (as de gabarito, recurso e resultado também citam "prova" mas são dias depois).
    function linhasComDataDeProva(linhas, max) {
        max = max || 14;
        const achadas = [];
        for (let i = 0; i < linhas.length; i++) {
            const l = linhas[i];
            if (!RE_PROVA_DATA.test(l)) continue;
            const janela = [l, linhas[i + 1] || ''].join(' ');
            if (!RE_DATA.test(janela)) continue;
            // Pontua: "Data de Aplicação da PROVA OBJETIVA 13/09/2026" (linha de tabela que
            // começa pela realização) ganha de "...deverá indicar até 30 de julho de 2026"
            // (frase sobre outro prazo) e de gabarito/resultado.
            let pontos = 0;
            if (/^\s*(\d+(\.\d+)*\.?\s+)?(data\s+d[ae]\s+)?(realiza[çc][ãa]o|aplica[çc][ãa]o)/i.test(l)) pontos += 4;
            else if (/realiza[çc][ãa]o|aplica[çc][ãa]o|data\s+da\s+prova|ser[áa]\s+(realizada|aplicada)/i.test(l)) pontos += 2;
            if (/prova\s+objetiva/i.test(l)) pontos += 2;
            if (/\b(dever[áa]|poder[áa]|candidato|solicit|recurso|gabarito|resultado|divulga|publica)/i.test(l)) pontos -= 3;
            achadas.push({ txt: cortar(janela, 260), pontos, ordem: achadas.length });
        }
        achadas.sort((a, b) => b.pontos - a.pontos || a.ordem - b.ordem);
        return achadas.map((a) => a.txt).slice(0, max);
    }

    // Seção por título (quadro de cargos, cronograma): escolhe, entre as linhas que
    // casam com `re`, a de seção mais longa (o sumário também cita o título, mas
    // sem conteúdo embaixo). Devolve as linhas da seção (sem o título).
    function acharSecaoPorTitulo(linhas, re, maxLinhas, reExcluir, bonusDoCorpo) {
        let melhor = null;
        // Item numerado só vale como título se o termo vem LOGO no começo ("3. DO CRONOGRAMA");
        // uma frase que apenas menciona o termo ("...conforme o Cronograma - Anexo IV") não é título.
        const reNoInicio = new RegExp('^\\s*(\\d+(\\.\\d+)*\\.?\\s+)?((d[aoe]s?|o|a|os|as)\\s+)?(' + re.source + ')', 'i');
        for (let i = 0; i < linhas.length; i++) {
            const l = linhas[i];
            if (l.length > 190 || !re.test(l) || (reExcluir && reExcluir.test(l))) continue;
            // "ANEXO I" numa linha e o título ("RELAÇÃO CARGOS PÚBLICOS, COM O NÚMERO...") na seguinte,
            // às vezes longo demais pra parecer título e terminando em vírgula: o anexo garante.
            const ehTituloDeVerdade = RE_ANEXO.test(l) || ehTitulo(l) || (i > 0 && RE_ANEXO.test(linhas[i - 1]));
            // Título de verdade não termina em ponto/vírgula ("Cronograma - Anexo IV." é o fim de uma frase quebrada).
            if (!(ehTituloDeVerdade || (reNoInicio.test(l) && !/[.;,]s*$/.test(l)))) continue;
            const fim = Math.min(fimDaSecao(linhas, i), i + (maxLinhas || 80));
            const corpo = linhas.slice(i + 1, fim);
            const tam = corpo.join('\n').length;
            let peso = ehTituloDeVerdade ? tam * 1.5 : tam; // anexo/título em caixa alta ganha de item numerado
            const bonus = bonusDoCorpo ? bonusDoCorpo(corpo) : 0;
            peso += bonus;
            if (tam < 80) continue;
            // Com `bonusDoCorpo`, quem tem o sinal (ex.: linhas de tabela com salário) sempre vence
            // quem não tem, mesmo sendo mais curto: prosa longa não pode ganhar da tabela.
            const ganha = !melhor || (bonus > 0 && !(melhor.bonus > 0)) || ((bonus > 0) === (melhor.bonus > 0) && peso > melhor.peso);
            if (ganha) melhor = { tam, peso, bonus, corpo, titulo: l };
        }
        return melhor;
    }
    const RE_TIT_CARGOS = /quadros?\s+de\s+cargos|cargos\s+e\s+vagas|quadros?\s+de\s+vagas|vagas\s+(e|por)\s+cargos|cargos\s+oferecidos|rela[çc][ãa]o\s+(de\s+|dos\s+)?(cargos|empregos|fun[çc][õo]es)|dos\s+cargos\b|cargos\s+(e|,)\s+(requisitos|habilita)/i;
    // "Relação de ATRIBUIÇÕES dos cargos" também casa com "dos cargos", mas é a descrição das funções, não o quadro.
    const RE_NAO_QUADRO = /atribui[çc][õo]es|descri[çc][ãa]o\s+(das|de)\s+(fun|ativ)/i;
    const RE_TIT_CRONOGRAMA = /cronograma|calend[áa]rio\s+(de|do)|das\s+datas/i;

    function trechoCargos(linhas, maxChars) {
        // Uma seção "DOS CARGOS E DAS VAGAS" em prosa pode ser mais longa que a tabela de verdade:
        // linhas com salário ("R$ 5.403,69") ou "código + NOME EM CAIXA ALTA + número" são o sinal da tabela.
        const bonusTabela = (corpo) => corpo.filter((l) => /R\$\s*\d|^\s*\d{1,3}\s+[A-ZÁÉÍÓÚÂÊÔÃÕÇ]{3,}.*\d/.test(l)).length * 1500;
        const s = acharSecaoPorTitulo(linhas, RE_TIT_CARGOS, 60, RE_NAO_QUADRO, bonusTabela);
        return s ? cortar2(s.titulo + '\n' + s.corpo.join('\n'), maxChars || 3000) : '';
    }
    // Do cronograma só interessam as linhas com data (a tabela inteira é longa).
    function trechoCronograma(linhas, maxChars) {
        const s = acharSecaoPorTitulo(linhas, RE_TIT_CRONOGRAMA, 140);
        if (!s) return '';
        const uteis = s.corpo.filter((l) => RE_DATA.test(l) || /prova|inscri/i.test(l));
        return cortar2(s.titulo + '\n' + uteis.join('\n'), maxChars || 3500);
    }
    // Como cortar(), mas preservando quebras de linha.
    function cortar2(s, max) {
        const t = String(s == null ? '' : s).replace(/[ \t]+/g, ' ').trim();
        return t.length > max ? t.slice(0, max).trimEnd() : t;
    }

    // Todas as linhas em caixa alta do anexo — candidatas a "título de cargo".
    function titulosDoAnexo(linhasAnexo, max) {
        max = max || 140;
        const out = [];
        const vistos = new Set();
        for (const l of linhasAnexo) {
            if (!ehTitulo(l)) continue;
            const k = norm(l);
            if (vistos.has(k)) continue;
            vistos.add(k);
            out.push(l.trim());
            if (out.length >= max) break;
        }
        return out;
    }

    // Procura uma linha do anexo que corresponda a "alvo" (marcador ou nome do cargo).
    function acharLinha(linhas, alvo, desde) {
        const a = norm(alvo);
        if (!a) return -1;
        for (let i = desde || 0; i < linhas.length; i++) {
            const n = norm(linhas[i]);
            if (!n) continue;
            if (n === a) return i;
        }
        if (a.length >= 8) {
            for (let i = desde || 0; i < linhas.length; i++) {
                if (ehTitulo(linhas[i]) && norm(linhas[i]).includes(a)) return i;
            }
        }
        return -1;
    }

    // Recorta, dentro do anexo, o conteúdo do cargo escolhido e o bloco comum que
    // vem antes do primeiro cargo (Português/Matemática etc. de editais por nível).
    function fatiarConteudoDoCargo(linhasAnexo, cargo, todosCargos) {
        const pos = [];
        (todosCargos || []).forEach((c) => {
            const alvo = c.marcador || c.nome;
            const p = acharLinha(linhasAnexo, alvo, 0);
            if (p >= 0) pos.push({ nome: c.nome, p });
        });
        let meuP = -1;
        const meu = pos.find((x) => norm(x.nome) === norm(cargo.nome));
        if (meu) meuP = meu.p;
        else meuP = acharLinha(linhasAnexo, cargo.marcador || cargo.nome, 0);
        if (meuP < 0) return { encontrado: false, comum: '', especifico: '' };
        const posicoes = pos.map((x) => x.p).filter((p) => p !== meuP).sort((a, b) => a - b);
        const fim = posicoes.find((p) => p > meuP);
        const todosP = pos.map((x) => x.p).concat([meuP]);
        const primeiro = Math.min.apply(null, todosP);
        let comum = primeiro > 0 ? linhasAnexo.slice(0, primeiro).join('\n') : '';
        // Edital por nível ("1. CARGOS DE NÍVEL MÉDIO" / "2. CARGOS DE NÍVEL SUPERIOR"): cada nível tem os
        // SEUS conhecimentos gerais. O comum do cargo é o do nível dele (do título do nível até o primeiro
        // cargo daquele nível), não o do primeiro nível do anexo.
        for (let k = meuP - 1; k >= 0; k--) {
            if (/^\s*\d+\.\s+/.test(linhasAnexo[k]) && ehTitulo(linhasAnexo[k]) && /\b(n[ií]vel|ensino|escolaridade)\b/i.test(linhasAnexo[k])) {
                const primeiroDoNivel = Math.min.apply(null, todosP.filter((p) => p > k));
                if (primeiroDoNivel > k) comum = linhasAnexo.slice(k, primeiroDoNivel).join('\n');
                break;
            }
        }
        const especifico = linhasAnexo.slice(meuP, fim === undefined ? linhasAnexo.length : fim).join('\n');
        return { encontrado: true, comum, especifico };
    }

    // Parte um texto grande em pedaços de até `max` caracteres, cortando em quebra de linha.
    function dividirEmPedacos(texto, max) {
        const out = [];
        let atual = '';
        String(texto || '').split('\n').forEach((l) => {
            if (atual.length + l.length + 1 > max && atual) { out.push(atual); atual = ''; }
            if (l.length > max) {
                for (let i = 0; i < l.length; i += max) out.push(l.slice(i, i + max));
            } else {
                atual += (atual ? '\n' : '') + l;
            }
        });
        if (atual.trim()) out.push(atual);
        return out;
    }

    // Visão completa do edital, pronta pra alimentar os dois passos de IA.
    function analisarEdital(paginas) {
        const { linhas, texto } = prepararTexto(paginas);
        const anexo = acharAnexoConteudo(linhas);
        let linhasAnexo = anexo ? linhas.slice(anexo.inicio, anexo.fim) : [];
        // Sem anexo de conteúdo (editais curtos): o conteúdo é o que a seção
        // "DAS PROVAS" lista — às vezes só os nomes das matérias.
        let origemConteudo = anexo ? 'anexo' : 'provas';
        if (!anexo) {
            const sec = acharSecaoProvas(linhas, 9000);
            if (sec) linhasAnexo = sec.texto.split('\n');
            else origemConteudo = 'nenhuma';
        }
        return {
            linhas,
            texto,
            anexo,
            origemConteudo,
            linhasAnexo,
            provas: acharEstruturaProva(linhas, 6500, anexo && anexo.ehAnexo ? anexo.inicio - 1 : null),
            cabecalho: texto.slice(0, 4500),
            datas: linhasComDataDeProva(linhas),
            // Cargos e datas costumam estar em anexos de tabela (QUADRO DE CARGOS E VAGAS,
            // CRONOGRAMA) — sem estes trechos a IA não tem de onde tirar nenhum dos dois.
            quadroCargos: trechoCargos(linhas),
            cronograma: trechoCronograma(linhas),
            titulos: titulosDoAnexo(linhasAnexo),
        };
    }

    // ----------------------------------------------------------------- prompts
    const SISTEMA_IA =
        'Você extrai dados de editais de concursos públicos brasileiros. Responde APENAS com JSON válido, ' +
        'sem markdown, sem comentários e sem texto fora do JSON. Nunca inventa o que não está nos trechos.';

    function montarPromptMeta(an) {
        const titulos = an.titulos.length ? an.titulos.join('\n') : '(nenhuma)';
        const datas = an.datas.length ? an.datas.join('\n') : '(nenhuma)';
        const user =
`Leia os trechos de um EDITAL de concurso público brasileiro e extraia os dados em JSON.

TRECHO INICIAL DO EDITAL:
"""
${an.cabecalho}
"""

QUADRO DE CARGOS E VAGAS (tabela; as colunas podem vir embaralhadas):
"""
${an.quadroCargos || '(não localizado)'}
"""

CRONOGRAMA / DATAS (tabela; a data costuma estar no fim da linha, às vezes com ano de 2 dígitos, ex.: 08/11/26):
"""
${an.cronograma || '(não localizado)'}
"""

LINHAS DO EDITAL QUE CITAM A PROVA E UMA DATA:
"""
${datas}
"""

LINHAS EM CAIXA ALTA DO ANEXO DE CONTEÚDO PROGRAMÁTICO (podem ser cargos, matérias ou títulos):
"""
${titulos}
"""

Responda APENAS com JSON neste formato:
{"concurso":"nome curto (órgão + número/ano)","orgao":"órgão ou entidade","banca":"banca organizadora ou null","dataProva":"AAAA-MM-DD ou null","cargos":[{"nome":"...","marcador":"..."}]}

Regras:
- "dataProva" é a data da REALIZAÇÃO da PROVA OBJETIVA (não confunda com gabarito, recurso ou resultado, que vêm depois). Se houver mais de uma, a primeira; vale "data provável". Converta para AAAA-MM-DD (ano de 2 dígitos = 20xx). Se não aparecer, null.
- "cargos": todos os cargos/empregos/funções/áreas com vagas neste edital, com o nome como no edital (no máximo 80). Procure no QUADRO DE CARGOS E VAGAS e no início do edital. Se o edital é de um cargo/área só, liste só ele.
- "marcador": a linha EXATA, copiada da lista de caixa alta acima, que inicia o conteúdo programático desse cargo. Se o conteúdo não é separado por cargo, use null.
- Não invente nada que não esteja nos trechos.`;
        return [{ role: 'system', content: SISTEMA_IA }, { role: 'user', content: user }];
    }

    function montarPromptConteudo({ concurso, cargo, provas, comum, especifico, modoPedaco }) {
        const user =
`Monte o conteúdo de estudo do cargo "${cargo}"${concurso ? ` do concurso "${concurso}"` : ''}.

ESTRUTURA DA PROVA (trecho do edital; pode ter o quadro de questões por disciplina):
"""
${provas || '(não localizada)'}
"""
${comum ? `\nCONTEÚDO PROGRAMÁTICO COMUM (vale para vários cargos):\n"""\n${comum}\n"""\n` : ''}
CONTEÚDO PROGRAMÁTICO ${comum ? 'ESPECÍFICO DO CARGO' : 'DO EDITAL'}${modoPedaco ? ' (PARTE DO TEXTO)' : ''}:
"""
${especifico || '(vazio)'}
"""

Responda APENAS com JSON neste formato, o mais COMPACTO possível (sem espaços ou textos extras — a resposta tem limite de tamanho e, se for cortada, o que vem depois do corte se perde):
{"materias":[{"nome":"...","questoes":10,"pontos":2,"sugerido":false,"topicos":[{"titulo":"...","peso":2}]}]}

Regras:
- Inclua SOMENTE as matérias que caem na prova do cargo "${cargo}". Isso INCLUI o conteúdo comum a todos os cargos/áreas (Língua Portuguesa, Matemática, Informática, Conhecimentos Gerais etc.) sempre que o edital o prevê para este cargo. Ignore bibliografia, atribuições do cargo e regras do edital.
- Liste TODAS as matérias do cargo, mesmo que o texto seja longo. Divida o conteúdo de cada matéria em tópicos de estudo de tamanho parecido, na ordem do edital (de 4 a 8 tópicos por matéria, conforme o tamanho; NUNCA menos de 4). Cada tópico deve caber numa sessão de estudo.
- "titulo": curto (até 60 caracteres). NÃO escreva descrição do tópico.
- "peso": 1 = tópico curto ou fácil; 2 = médio; 3 = extenso ou difícil (exige várias horas).
- "questoes" e "pontos" (pontos por questão): só se constarem na estrutura da prova; senão null.
- Se o conteúdo vier de uma TABELA de duas colunas (nome da matéria à esquerda, assuntos à direita), os nomes das matérias aparecem QUEBRADOS e misturados no começo das linhas do texto (ex.: "Língua" ... "Portuguesa" ... "Matemática e" ... "Raciocínio" ... "Lógico"). Reconstitua os nomes e separe o texto de cada matéria.
- Se o conteúdo específico traz várias disciplinas numeradas (ex.: "1 Direito Constitucional: ... 2 Direito Administrativo: ..."), crie UMA matéria para cada uma, com "questoes": null (a quantidade de questões vale para o conjunto).
- Se o edital cita apenas o NOME de uma matéria, sem detalhar o conteúdo, proponha de 6 a 10 tópicos usuais dessa matéria em concursos (use a legislação vigente, ex.: CPC/2015, Código Civil de 2002) e marque "sugerido": true nela.
- Não invente matérias que não estejam no edital.`;
        return [{ role: 'system', content: SISTEMA_IA }, { role: 'user', content: user }];
    }

    // Segunda chamada quando a primeira resposta veio cortada ou deixou disciplinas de fora:
    // pede SÓ o que falta, com o texto dessas disciplinas (entrada e saída pequenas).
    function montarPromptContinuacao({ concurso, cargo, jaListadas, faltantes, textoGeral }) {
        const blocos = faltantes && faltantes.length
            ? faltantes.map((f) => '### ' + f.nome + '\n' + cortar2(f.texto, 5000)).join('\n\n')
            : cortar2(textoGeral || '', 9000);
        const user =
`Continue o trabalho de montar o conteúdo de estudo do cargo "${cargo}"${concurso ? ` do concurso "${concurso}"` : ''}.

A resposta anterior foi cortada ou esqueceu matérias. Matérias JÁ listadas (NÃO repita): ${(jaListadas || []).join('; ') || '(nenhuma)'}.

TEXTO DAS MATÉRIAS QUE FALTAM:
"""
${blocos}
"""

Responda APENAS com JSON compacto, no mesmo formato:
{"materias":[{"nome":"...","questoes":null,"pontos":null,"sugerido":false,"topicos":[{"titulo":"...","peso":2}]}]}

Regras: uma matéria para cada disciplina do texto acima, com 4 a 8 tópicos na ordem do edital; "titulo" curto (até 60 caracteres), sem descrição; "peso" 1 = curto/fácil, 2 = médio, 3 = extenso/difícil. Se não faltar nenhuma matéria, responda {"materias":[]}.`;
        return [{ role: 'system', content: SISTEMA_IA }, { role: 'user', content: user }];
    }

    // ----------------------------------------------------------------- JSON da IA
    function fecharJSON(s) {
        // Fecha colchetes/chaves que ficaram abertos num JSON cortado no meio.
        const pilha = [];
        let str = false, esc = false;
        for (const c of s) {
            if (str) { if (esc) esc = false; else if (c === '\\') esc = true; else if (c === '"') str = false; continue; }
            if (c === '"') str = true;
            else if (c === '{' || c === '[') pilha.push(c === '{' ? '}' : ']');
            else if (c === '}' || c === ']') pilha.pop();
        }
        return s + (str ? '"' : '') + pilha.reverse().join('');
    }

    // Devolve { obj, reparado }. "reparado" = o JSON veio CORTADO (o limite de tamanho da
    // resposta da IA acaba no meio) e foi fechado à força: o que vinha depois do corte
    // se perdeu. Quem usa precisa saber disso pra pedir o que faltou, em vez de
    // tratar uma lista incompleta como se fosse a lista toda.
    function extrairJSONInfo(texto) {
        let t = String(texto || '').replace(/```json|```/gi, '').trim();
        const i = t.search(/[{[]/);
        if (i < 0) throw new Error('A resposta da IA não trouxe JSON.');
        t = t.slice(i);
        const tentativas = [];
        const fimObj = Math.max(t.lastIndexOf('}'), t.lastIndexOf(']'));
        if (fimObj > 0) tentativas.push(t.slice(0, fimObj + 1));
        tentativas.push(t);
        for (const base of tentativas) {
            try { return { obj: JSON.parse(base), reparado: false }; } catch (e) { /* tenta reparar */ }
            let corte = base;
            for (let k = 0; k < 6 && corte.length > 2; k++) {
                const limpo = corte.replace(/,\s*$/, '');
                try { return { obj: JSON.parse(fecharJSON(limpo)), reparado: true }; } catch (e) { /* recua */ }
                const prox = Math.max(corte.lastIndexOf('}', corte.length - 2), corte.lastIndexOf(']', corte.length - 2));
                if (prox <= 0) break;
                corte = corte.slice(0, prox + 1);
            }
        }
        throw new Error('Não consegui interpretar a resposta da IA como JSON.');
    }
    function extrairJSON(texto) { return extrairJSONInfo(texto).obj; }

    function sanitizarMeta(obj) {
        const o = obj && typeof obj === 'object' ? obj : {};
        const cargos = [];
        const vistos = new Set();
        (Array.isArray(o.cargos) ? o.cargos : []).forEach((c) => {
            const nome = cortar(typeof c === 'string' ? c : c && c.nome, 120);
            const k = norm(nome);
            if (!nome || vistos.has(k) || cargos.length >= 120) return;
            vistos.add(k);
            const marcador = c && typeof c === 'object' && c.marcador ? cortar(c.marcador, 160) : null;
            cargos.push({ nome, marcador });
        });
        let dataProva = typeof o.dataProva === 'string' ? o.dataProva.trim() : null;
        if (dataProva && !/^\d{4}-\d{2}-\d{2}$/.test(dataProva)) dataProva = null;
        if (dataProva) {
            const ano = +dataProva.slice(0, 4);
            if (!dataValida(dataProva) || ano < 2020 || ano > 2040) dataProva = null;
        }
        const txt = (v, n) => { const s = cortar(v, n); return s && !/^(null|n\/a|—|-)$/i.test(s) ? s : ''; };
        return { concurso: txt(o.concurso, 140), orgao: txt(o.orgao, 140), banca: txt(o.banca, 100), dataProva, cargos };
    }

    function numOuNull(v, min, max) {
        const n = typeof v === 'string' ? parseFloat(v.replace(',', '.')) : v;
        return Number.isFinite(n) && n >= min && n <= max ? n : null;
    }

    function sanitizarConteudo(obj) {
        const lista = Array.isArray(obj) ? obj : obj && Array.isArray(obj.materias) ? obj.materias : [];
        const materias = [];
        lista.forEach((m) => {
            if (!m || typeof m !== 'object') return;
            const nome = cortar(m.nome, 80);
            if (!nome) return;
            const topicos = [];
            const vistos = new Set();
            (Array.isArray(m.topicos) ? m.topicos : []).forEach((t) => {
                const obj2 = typeof t === 'string' ? { titulo: t } : t || {};
                const titulo = cortar(obj2.titulo || obj2.nome, 90);
                const k = norm(titulo);
                if (!titulo || vistos.has(k) || topicos.length >= 40) return;
                vistos.add(k);
                const p = Math.round(Number(obj2.peso));
                topicos.push({ titulo, detalhe: cortar(obj2.detalhe, 240), peso: p >= 1 && p <= 3 ? p : 2 });
            });
            if (!topicos.length) return;
            materias.push({
                nome,
                questoes: numOuNull(m.questoes, 1, 300),
                pontos: numOuNull(m.pontos, 0.1, 100),
                sugerido: m.sugerido === true,
                topicos,
            });
        });
        return materias.slice(0, 40);
    }

    // Junta o resultado de vários pedaços (mesma matéria cortada em dois textos).
    function mesclarMaterias(lista) {
        const mapa = new Map();
        const ordem = [];
        lista.forEach((m) => {
            const k = norm(m.nome);
            if (!mapa.has(k)) { mapa.set(k, { ...m, topicos: [...m.topicos] }); ordem.push(k); return; }
            const alvo = mapa.get(k);
            const ja = new Set(alvo.topicos.map((t) => norm(t.titulo)));
            m.topicos.forEach((t) => { if (!ja.has(norm(t.titulo))) alvo.topicos.push(t); });
            if (alvo.questoes == null) alvo.questoes = m.questoes;
            if (alvo.pontos == null) alvo.pontos = m.pontos;
        });
        return ordem.map((k) => mapa.get(k));
    }

    // Dá ids e cor às matérias/tópicos (usados pelo cronograma e pelos registros).
    function numerarMaterias(materias) {
        let t = 0;
        return materias.map((m, i) => ({
            ...m,
            id: 'm' + (i + 1),
            cor: CORES_MATERIA[i % CORES_MATERIA.length],
            topicos: m.topicos.map((tp) => ({ ...tp, id: 't' + (++t) })),
        }));
    }

    // ----------------------------------------------------------------- conferência de matérias
    // Disciplinas numeradas no texto ("1 Direito Constitucional: ... 2 Direito Administrativo: ...").
    // Só vale uma sequência 1, 2, 3... sem pular número (assim "Lei 8 Estatuto: ..." no meio de
    // um parágrafo não vira disciplina). Serve de lista de conferência: se a IA devolveu menos
    // disciplinas do que o texto numera, sabemos exatamente quais faltam.
    function disciplinasNumeradas(texto) {
        const corrido = String(texto || '').replace(/\s+/g, ' ');
        const re = /(?:^|[\s.;])(\d{1,2})\s+([A-ZÀ-Ú][^:;\d]{3,80}?):\s/g;
        const achadas = [];
        let m, esperado = 1;
        while ((m = re.exec(corrido))) {
            if (+m[1] !== esperado) continue;
            achadas.push({ nome: cortar(m[2], 80), ini: m.index + m[0].length, marca: m.index });
            esperado++;
        }
        if (achadas.length < 2) return [];
        return achadas.map((a, i) => ({
            nome: a.nome,
            texto: corrido.slice(a.ini, i + 1 < achadas.length ? achadas[i + 1].marca : corrido.length).trim(),
        }));
    }

    const STOP_NOME = new Set(['de', 'da', 'do', 'das', 'dos', 'e', 'em', 'a', 'o', 'para', 'com']);
    function tokensDoNome(s) { return norm(s).split(' ').filter((t) => t && !STOP_NOME.has(t)); }
    // A matéria que a IA devolveu cobre a disciplina `nome` do texto? Aceita nomes diferentes
    // ("Direito Civil" vs "Direito Civil e Processual Civil") se dividem 2+ palavras-chave.
    function nomeCobre(nomeIA, nome) {
        const a = norm(nomeIA), b = norm(nome);
        if (!a || !b) return false;
        if (a.includes(b) || b.includes(a)) return true;
        const ta = new Set(tokensDoNome(nomeIA));
        const comuns = tokensDoNome(nome).filter((t) => ta.has(t)).length;
        return comuns >= 2 || (comuns === 1 && Math.min(ta.size, tokensDoNome(nome).length) === 1);
    }

    // ----------------------------------------------------------------- plano B (sem IA)
    // Se TODAS as IAs gratuitas estiverem fora do ar, ainda dá pra montar o plano:
    // matérias = linhas em caixa alta; tópicos = frases do texto agrupadas.
    function estruturarConteudoLocal(texto) {
        // Matéria em caixa alta no MEIO do parágrafo ("...Prescrição. DIREITO CONSTITUCIONAL: Princípios...")
        // também abre uma matéria nova: quebra a linha ali.
        const linhas = String(texto || '').split('\n')
            .flatMap((l) => l.trim().split(/(?<=[.;])\s+(?=[A-ZÀ-Ú][A-ZÀ-Ú0-9 ,\/&–-]{5,80}:\s)/))
            .map((l) => l.trim());
        const materias = [];
        let atual = null;
        const fechar = () => { if (atual) { materias.push(atual); atual = null; } };
        // Também não são matérias: títulos numerados ("2. CARGOS DE NÍVEL SUPERIOR", "2.1. CONHECIMENTOS GERAIS").
        const NOMES_GENERICOS = /^(ensino\s|n[ií]vel\s|anexo|conte[úu]do|conhecimentos?\s+(espec|conte|gerais)|programa|disciplina|\d+(\s\d+)*\s)/i;
        linhas.forEach((l) => {
            if (!l) return;
            // "DIREITO ADMINISTRATIVO: Ato Administrativo: conceito..." — matéria em caixa alta e o conteúdo na MESMA linha.
            const inline = /^([A-ZÀ-Ú][A-ZÀ-Ú0-9 ,\/&–-]{3,80}):\s+(\S.*)$/.exec(l);
            if (inline && ehTitulo(inline[1]) && !NOMES_GENERICOS.test(norm(inline[1]))) {
                fechar();
                atual = { nome: cortar(inline[1], 80), texto: inline[2] };
                return;
            }
            if (ehTitulo(l) && !NOMES_GENERICOS.test(norm(l))) {
                fechar();
                atual = { nome: cortar(l.replace(/[:\-–]+\s*$/, ''), 80), texto: '' };
            } else if (atual) {
                atual.texto += (atual.texto ? ' ' : '') + l;
            } else if (!NOMES_GENERICOS.test(norm(l)) && /^[A-ZÀ-Ú][^.]{3,70}[;.]?$/.test(l) && /direito|l[ií]ngua|matem|inform|racioc|portugu|hist|geograf|contab|admin|conhecim|legisl|[ée]tica/i.test(l)) {
                // lista de nomes de matéria, uma por linha (sem detalhamento)
                materias.push({ nome: cortar(l.replace(/[;.]+\s*$/, ''), 80), texto: '' });
            }
        });
        fechar();
        // Linha de cabeçalho sem conteúdo ("ADVOGADO" antes das matérias dele) não é matéria: some
        // quando existe alguma matéria com texto. Lista só de nomes (nenhuma tem texto) fica como está.
        if (materias.some((m) => m.texto)) {
            for (let i = materias.length - 1; i >= 0; i--) if (!materias[i].texto) materias.splice(i, 1);
        }
        if (!materias.length) {
            // Sem títulos em caixa alta (tabela de duas colunas, texto corrido): tenta as
            // disciplinas numeradas ("1 Direito Constitucional: ... 2 Direito Administrativo: ...");
            // senão devolve tudo como uma matéria só, que a pessoa renomeia na tela de conferência.
            const corrido = linhas.filter(Boolean).join(' ').replace(/\s+/g, ' ');
            const numeradas = disciplinasNumeradas(corrido);
            if (numeradas.length) numeradas.forEach((d) => materias.push(d));
            else if (corrido.length > 300) materias.push({ nome: 'Conteúdo programático', texto: corrido });
        }
        return materias.map(materiaDeTexto).filter((m) => m.topicos.length);
    }

    // {nome, texto} → matéria com tópicos (frases do texto agrupadas). Sem texto, tópicos genéricos.
    function materiaDeTexto(m) {
        const frases = String(m.texto || '')
            .split(/(?<=[.;])\s+(?=[A-ZÀ-Ú0-9])/)
            .map((f) => f.trim())
            .filter(Boolean);
        const topicos = [];
        let buf = '';
        const empurrar = () => {
            const t = buf.trim();
            if (!t) return;
            const titulo = cortar(t.split(/[:.;]/)[0], 70);
            const peso = t.length < 140 ? 1 : t.length < 320 ? 2 : 3;
            topicos.push({ titulo, detalhe: cortar(t, 240), peso });
            buf = '';
        };
        frases.forEach((f) => {
            if (buf && (buf + ' ' + f).length > 300) empurrar();
            buf += (buf ? ' ' : '') + f;
        });
        empurrar();
        if (!topicos.length) {
            ['Conceitos e fundamentos', 'Legislação e regras principais', 'Jurisprudência e pontos mais cobrados', 'Questões e revisão'].forEach((t) =>
                topicos.push({ titulo: `${m.nome} — ${t}`, detalhe: '', peso: 2 })
            );
            return { nome: m.nome, questoes: null, pontos: null, sugerido: true, topicos };
        }
        return { nome: m.nome, questoes: null, pontos: null, sugerido: false, topicos: topicos.slice(0, 30) };
    }

    // ----------------------------------------------------------------- orquestração da IA
    // As IAs gratuitas devolvem 429 (cota/limite por minuto) com frequência — o
    // que é "tente de novo daqui a pouco", não "não funciona". Espera e repete.
    function comRetentativas(chamarIA, { tentativas = 3, esperaMs = 12000, aoEsperar } = {}) {
        return async (mensagens) => {
            let ultimo;
            for (let i = 0; i < tentativas; i++) {
                try {
                    return await chamarIA(mensagens);
                } catch (e) {
                    ultimo = e;
                    if (i < tentativas - 1) {
                        if (aoEsperar) aoEsperar(i + 1, tentativas, esperaMs * (i + 1));
                        await new Promise((r) => setTimeout(r, esperaMs * (i + 1)));
                    }
                }
            }
            throw ultimo;
        };
    }

    // chamarIA(mensagens) → Promise<string>. Injetada por quem usa (a página usa
    // cbGerarRespostaIA; os testes em Node usam o mesmo ia-provider.js).
    async function chamarIAJson(chamarIA, mensagens, validar) {
        let ultimoErro = null;
        let ultimaResposta = '';
        for (let tentativa = 0; tentativa < 2; tentativa++) {
            const msgs = tentativa === 0
                ? mensagens
                : mensagens.concat([
                    { role: 'assistant', content: ultimaResposta.slice(0, 3000) },
                    { role: 'user', content: `Sua resposta não pôde ser lida (${ultimoErro && ultimoErro.message}). Responda de novo APENAS com o JSON pedido, sem texto antes ou depois.` },
                ]);
            try {
                ultimaResposta = await chamarIA(msgs);
                const info = extrairJSONInfo(ultimaResposta);
                return validar(info.obj, info);
            } catch (e) {
                ultimoErro = e;
            }
        }
        throw ultimoErro || new Error('Falha ao consultar a IA.');
    }

    // Primeira data encontrada nas linhas de "prova + data" (plano B quando a IA falha).
    function primeiraDataDasLinhas(linhas) {
        const MES = { janeiro: 1, fevereiro: 2, marco: 3, abril: 4, maio: 5, junho: 6, julho: 7, agosto: 8, setembro: 9, outubro: 10, novembro: 11, dezembro: 12 };
        for (const l of linhas || []) {
            // Pode haver mais de uma data na linha ("09/10 a 28/10/26", "prova 08/11/26"): tenta todas.
            const re = new RegExp(RE_DATA.source, 'gi');
            let m;
            while ((m = re.exec(l))) {
                let d, mes, a;
                if (m[1]) { d = +m[1]; mes = +m[2]; a = +m[3]; if (m[3].length === 2) a += 2000; }
                else if (m[4]) { d = +m[4]; mes = +m[5]; a = +m[6]; }
                else { d = +m[7]; mes = MES[semAcento(m[8]).toLowerCase()]; a = +m[9]; }
                const s = `${a}-${pad2(mes)}-${pad2(d)}`;
                if (dataValida(s) && a >= 2020 && a <= 2040) return s;
            }
        }
        return null;
    }

    function metaLocal(an) {
        const linhasIni = an.cabecalho.split('\n').map((l) => l.trim()).filter(Boolean);
        const titulo = linhasIni.find((l) => /concurso|processo seletivo|edital/i.test(l) && l.length < 140) || linhasIni[0] || '';
        const ignorar = /^(ensino|n[ií]vel|anexo|conte[úu]do|conhecimentos?|no[çc][õo]es|no[çc][ãa]o|l[ií]ngua|portugu|matem|racioc|inform[áa]tica|direito|legisla)/i;
        // Título numerado ("14. DOS RECURSOS", "2.2. CONHECIMENTOS ESPECÍFICOS") é seção do edital, não cargo;
        // e linha terminada em ":" ("LÍNGUA PORTUGUESA:") é matéria.
        const secao = /^\s*\d+(\.\d+)*\.?\s/;
        const cargos = an.titulos
            .filter((t) => !secao.test(t) && !/:\s*$/.test(t) && !ignorar.test(semAcento(t).trim()))
            .slice(0, 80)
            .map((t) => ({ nome: cortar(t.replace(/[:\-–]+\s*$/, ''), 120), marcador: t }));
        return sanitizarMeta({ concurso: titulo, dataProva: primeiraDataDasLinhas(an.datas), cargos });
    }

    // Passo 1: concurso, banca, data da prova e lista de cargos.
    async function extrairMeta(an, chamarIA) {
        try {
            const meta = await chamarIAJson(chamarIA, montarPromptMeta(an), sanitizarMeta);
            if (!meta.dataProva) meta.dataProva = primeiraDataDasLinhas(an.datas);
            return { meta, usouIA: true };
        } catch (e) {
            return { meta: metaLocal(an), usouIA: false, erro: e };
        }
    }

    // Passo 2: matérias e tópicos do cargo escolhido.
    // opcoes: { textoManual } — texto colado pela pessoa quando o PDF não tem anexo legível.
    async function extrairConteudo({ an, meta, cargo, chamarIA, onProgresso, textoManual }) {
        const avisos = [];
        let comum = '';
        let especifico = '';
        if (textoManual && textoManual.trim()) {
            especifico = textoManual.trim();
        } else if (an.linhasAnexo.length) {
            const dividido = (meta.cargos || []).length > 1;
            const fatia = dividido ? fatiarConteudoDoCargo(an.linhasAnexo, cargo, meta.cargos) : { encontrado: false };
            if (fatia.encontrado) {
                comum = cortar2(fatia.comum, 6000); // preserva as quebras de linha: o plano B local lê os títulos em caixa alta linha a linha
                especifico = fatia.especifico;
            } else {
                especifico = an.linhasAnexo.join('\n');
                if (dividido) avisos.push('Conteúdo deste cargo não separado no edital: confira as matérias.');
            }
        } else {
            throw new Error('SEM_CONTEUDO');
        }

        const MAX_PEDACO = 11000, MAX_PEDACOS = 8;
        let pedacos = dividirEmPedacos(especifico, MAX_PEDACO);
        if (pedacos.length > MAX_PEDACOS) {
            pedacos = pedacos.slice(0, MAX_PEDACOS);
            avisos.push('Edital muito grande: só a primeira parte foi analisada.');
        }
        const listas = [];
        let usouIA = true;
        let truncado = false;
        for (let i = 0; i < pedacos.length; i++) {
            if (onProgresso) onProgresso(pedacos.length > 1 ? `Analisando o conteúdo (${i + 1} de ${pedacos.length})...` : 'Analisando o conteúdo programático...');
            try {
                // Sem anexo, o "conteúdo" já É a seção das provas: não repete no prompt.
                const msgs = montarPromptConteudo({
                    concurso: meta.concurso, cargo: cargo.nome, provas: an.origemConteudo === 'provas' ? '' : cortar(an.provas, 5000),
                    comum: i === 0 ? comum : '', especifico: pedacos[i], modoPedaco: pedacos.length > 1,
                });
                const r = await chamarIAJson(chamarIA, msgs, (obj, info) => {
                    const mats = sanitizarConteudo(obj);
                    if (!mats.length) throw new Error('a IA não devolveu nenhuma matéria');
                    return { mats, cortado: !!(info && info.reparado) };
                });
                listas.push(...r.mats);
                if (r.cortado) truncado = true;
            } catch (e) {
                // Sem anexo, o texto é a seção "DAS PROVAS" inteira (regras, prazos...):
                // sem a IA não dá pra separar o que é matéria. Melhor falhar do que entregar lixo.
                if (an.origemConteudo === 'provas' && !(textoManual && textoManual.trim())) {
                    const err = new Error('IA_INDISPONIVEL');
                    err.detalhe = e && e.message;
                    throw err;
                }
                usouIA = false;
                avisos.push('Lido sem IA (menos preciso): confira as matérias e os tópicos.');
                listas.push(...estruturarConteudoLocal((i === 0 ? comum + '\n' : '') + pedacos[i]));
            }
        }
        let materias = mesclarMaterias(listas);
        if (!materias.length) throw new Error('SEM_CONTEUDO');

        // Conferência: a IA pode ter devolvido MENOS do que o edital lista (resposta cortada pelo
        // limite de tamanho, ou ela resumiu várias disciplinas em uma). Compara com as disciplinas
        // numeradas do texto e pede só as que faltam; se a IA falhar de novo, lê essas pelo texto.
        if (usouIA) {
            const completou = await completarMaterias({ materias, especifico, comum, meta, cargo, chamarIA, onProgresso, truncado, avisos });
            materias = completou.materias;
        }
        if (materias.some((m) => m.sugerido)) avisos.push('Tópicos “sugeridos” vieram da IA: o edital só cita o nome da matéria.');
        return { materias, avisos, usouIA };
    }

    // Garante que nenhuma disciplina do edital ficou de fora. Até 3 rodadas, 2 disciplinas por vez
    // (entrada e resposta pequenas, pra não bater no limite de tamanho de novo).
    async function completarMaterias({ materias, especifico, comum, meta, cargo, chamarIA, onProgresso, truncado, avisos }) {
        const esperadas = disciplinasNumeradas(especifico);
        const faltam = () => esperadas.filter((e) => !materias.some((m) => nomeCobre(m.nome, e.nome)));
        let pendentes = faltam();
        // Cortada, mas sem lista numerada para conferir: uma chamada genérica "continue".
        if (!pendentes.length && truncado) {
            if (onProgresso) onProgresso('Completando o que faltou...');
            try {
                const msgs = montarPromptContinuacao({ concurso: meta.concurso, cargo: cargo.nome, jaListadas: materias.map((m) => m.nome), faltantes: [], textoGeral: (comum ? comum + '\n' : '') + especifico });
                const r = await chamarIAJson(chamarIA, msgs, (obj) => sanitizarConteudo(obj));
                if (r.length) materias = mesclarMaterias(materias.concat(r));
            } catch (e) {
                avisos.push('Resposta incompleta da IA: confira se falta alguma matéria.');
            }
            return { materias };
        }
        for (let rodada = 0; rodada < 3 && pendentes.length; rodada++) {
            const lote = pendentes.slice(0, 2);
            if (onProgresso) onProgresso(`Completando: ${lote.map((l) => l.nome).join(' e ')}...`);
            try {
                const msgs = montarPromptContinuacao({ concurso: meta.concurso, cargo: cargo.nome, jaListadas: materias.map((m) => m.nome), faltantes: lote });
                const r = await chamarIAJson(chamarIA, msgs, (obj) => sanitizarConteudo(obj));
                materias = mesclarMaterias(materias.concat(r));
            } catch (e) { /* cai no plano B abaixo, só para o que ainda faltar */ }
            pendentes = faltam();
            // A IA não trouxe o lote: não insiste, lê pelo texto.
            if (pendentes.length && pendentes.slice(0, 2).every((p) => lote.includes(p))) break;
        }
        const aindaFaltam = faltam();
        if (aindaFaltam.length) {
            aindaFaltam.forEach((d) => materias.push(materiaDeTexto(d)));
            avisos.push(`Lidas sem IA (menos precisas): ${aindaFaltam.map((d) => d.nome).join(', ')}.`);
        }
        return { materias };
    }

    // ----------------------------------------------------------------- cronograma
    function pesosDeProva(materias) {
        const temQuestoes = materias.some((m) => m.questoes);
        if (!temQuestoes) return materias.map(() => 1);
        const comQ = materias.filter((m) => m.questoes);
        const media = comQ.reduce((s, m) => s + m.questoes * (m.pontos || 1), 0) / comQ.length;
        const brutos = materias.map((m) => (m.questoes ? m.questoes * (m.pontos || 1) : media));
        const mediaTotal = brutos.reduce((a, b) => a + b, 0) / brutos.length;
        return brutos.map((b) => b / mediaTotal);
    }

    // Cada tópico vira "unidades" de estudo que cabem num dia. Tópico que não cabe
    // num dia inteiro é dividido em partes (parte 1/2, 2/2) — em dias diferentes.
    function criarUnidades(materias, cap, inicioId) {
        let n = inicioId || 0;
        return materias.map((m, mi) => {
            const fila = [];
            m.topicos.forEach((t) => {
                const total = PESO_MIN[t.peso] || PESO_MIN[2];
                const partes = total > cap ? Math.ceil(total / cap) : 1;
                const min = partes === 1 ? total : Math.min(cap, arred5(total / partes, 'cima'));
                for (let p = 1; p <= partes; p++) {
                    fila.push({
                        id: 'u' + (++n),
                        tipo: 'estudo',
                        materiaId: m.id,
                        materia: m.nome,
                        topicoId: t.id,
                        topico: t.titulo,
                        detalhe: t.detalhe || '',
                        peso: t.peso,
                        grande: t.peso === 3,
                        min,
                        parte: p,
                        partes,
                        questoes: p === partes ? QUESTOES_SUGERIDAS[t.peso] || 10 : 0,
                    });
                }
            });
            return fila;
        });
    }

    function limitesDoDia(cap) {
        const maxItens = cap <= 60 ? 2 : cap <= 120 ? 3 : cap <= 240 ? 4 : 5;
        return { maxItens, maxMaterias: maxItens, maxMateriasRev: cap <= 120 ? 2 : cap <= 240 ? 3 : 4 };
    }

    const fmtItemPublico = (u) => ({
        id: u.id, tipo: u.tipo, materiaId: u.materiaId, materia: u.materia, topicoId: u.topicoId || null,
        topico: u.topico, detalhe: u.detalhe || '', peso: u.peso || null, min: u.min,
        parte: u.parte || 1, partes: u.partes || 1, questoes: u.questoes || 0,
    });

    // Preenche UM dia de estudo. Regras:
    //  • no máximo 1 tópico "extenso" (peso 3) por dia, e nunca com outro extenso;
    //  • no máximo 1 tópico por matéria (2 só se sobrarem poucas matérias);
    //  • a soma dos minutos nunca passa do tempo diário.
    function montarDiaDeEstudo(filas, materias, estado, cap, semente) {
        const lim = limitesDoDia(cap);
        const itens = semente && semente.itens ? [...semente.itens] : [];
        let usado = semente ? semente.usado : 0;
        let temGrande = semente ? semente.temGrande : false;
        const usadasHoje = {};
        itens.forEach((it) => { usadasHoje[it.materiaId] = (usadasHoje[it.materiaId] || 0) + 1; });

        const restante = filas.map((f) => f.reduce((s, u) => s + u.min, 0));
        const total = restante.reduce((a, b) => a + b, 0) || 1;
        const ordenar = () =>
            filas
                .map((f, i) => ({ i, f }))
                .filter((x) => x.f.length)
                .map((x) => {
                    const recencia = Math.min(4, estado.dia - (estado.ultimoDia[x.i] ?? -4)) * 0.03;
                    return { i: x.i, score: (restante[x.i] / total) * estado.pesoProva[x.i] + recencia };
                })
                .sort((a, b) => b.score - a.score);

        const tentar = (permitirRepetir) => {
            for (const c of ordenar()) {
                if (itens.length >= lim.maxItens) return;
                const fila = filas[c.i];
                const u = fila[0];
                if (!u) continue;
                const jaDaMateria = usadasHoje[u.materiaId] || 0;
                if (!permitirRepetir && jaDaMateria) continue;
                if (permitirRepetir && jaDaMateria >= 2) continue;
                if (itens.some((it) => it.topicoId && it.topicoId === u.topicoId)) continue;
                if (u.grande && temGrande) continue;
                if (usado + u.min > cap) continue;
                fila.shift();
                restante[c.i] -= u.min;
                itens.push(fmtItemPublico(u));
                usadasHoje[u.materiaId] = jaDaMateria + 1;
                usado += u.min;
                if (u.grande) temGrande = true;
                estado.ultimoDia[c.i] = estado.dia;
                return true;
            }
            return false;
        };
        // 1ª rodada: matérias diferentes; depois completa o tempo se sobrou bastante.
        while (itens.length < lim.maxItens && tentar(false)) { /* continua */ }
        while (usado < cap * 0.75 && itens.length < lim.maxItens && tentar(true)) { /* continua */ }
        return { itens, usado };
    }

    function montarDiaDeRevisaoSemanal(diasAnteriores, cap, materiasPorId) {
        const minPorMateria = new Map();
        diasAnteriores.forEach((d) => d.itens.forEach((it) => {
            if (it.tipo !== 'estudo') return;
            minPorMateria.set(it.materiaId, (minPorMateria.get(it.materiaId) || 0) + it.min);
        }));
        if (!minPorMateria.size) return null;
        const lim = limitesDoDia(cap);
        const top = [...minPorMateria.entries()].sort((a, b) => b[1] - a[1]).slice(0, lim.maxMateriasRev);
        const cada = Math.max(15, arred5(cap / top.length));
        return top.map(([id], k) => ({
            id: '',
            tipo: 'revisao',
            materiaId: id,
            materia: (materiasPorId[id] || {}).nome || 'Revisão',
            topico: 'Refazer resumos e questões erradas',
            min: Math.min(cada, cap),
            questoes: 10,
        })).filter((x) => x.materia);
    }

    // Agenda todas as unidades a partir de `inicio`. Devolve { dias, fimConteudo }.
    function agendarUnidades(filas, materias, o) {
        const cap = o.cap;
        const estado = { dia: 0, ultimoDia: [], pesoProva: pesosDeProva(materias) };
        const materiasPorId = {};
        materias.forEach((m) => { materiasPorId[m.id] = m; });
        const dias = [];
        let contItem = o.inicioIdItem || 0;
        let diaIdx = 0;
        let semente = o.semente || null;
        const novoId = () => 'r' + (++contItem);

        const haUnidades = () => filas.some((f) => f.length);
        while (haUnidades() && diaIdx < MAX_DIAS) {
            const data = addDias(o.inicio, diaIdx);
            estado.dia = diaIdx;
            const diaDaSemana = (o.alinharSemana ? o.indiceSemana0 + diaIdx : diaIdx) + 1;
            const semanaAnterior = dias.slice(-6);
            const ehRevisaoSemanal = o.revisaoSemanal && !semente && diaDaSemana % 7 === 0 && semanaAnterior.some((d) => d.itens.some((it) => it.tipo === 'estudo'));
            if (ehRevisaoSemanal) {
                const rev = montarDiaDeRevisaoSemanal(semanaAnterior, cap, materiasPorId);
                if (rev) {
                    rev.forEach((it) => { it.id = novoId(); });
                    dias.push({ data, fase: 'estudo', rotulo: 'Revisão da semana', itens: rev });
                    diaIdx++;
                    continue;
                }
            }
            const r = montarDiaDeEstudo(filas, materias, estado, cap, semente);
            semente = null;
            dias.push({ data, fase: 'estudo', itens: r.itens });
            diaIdx++;
        }
        const fimConteudo = dias.length ? dias[dias.length - 1].data : addDias(o.inicio, -1);
        return { dias, fimConteudo, proximoIdItem: contItem };
    }

    // Fase 2: depois do conteúdo, revisão ativa + um simulado por semana + véspera leve.
    function montarFaseRevisao(materias, o) {
        const { fimConteudo, dataProva, cap } = o;
        const lim = limitesDoDia(cap);
        const dias = [];
        let qtd;
        if (dataProva) qtd = diffDias(fimConteudo, dataProva) - 1;
        else qtd = Math.max(3, Math.round(o.diasEstudo * 0.2));
        if (qtd <= 0) return dias;
        const pesos = pesosDeProva(materias);
        const vezes = materias.map(() => 0);
        let cont = 0;
        for (let k = 0; k < qtd; k++) {
            const data = addDias(fimConteudo, k + 1);
            const ultima = k === qtd - 1;
            let itens;
            if (ultima && dataProva) {
                itens = [{ tipo: 'revisao', materiaId: null, materia: 'Véspera da prova', topico: 'Revisão leve e descanso', min: Math.min(cap, 90), questoes: 0 }];
            } else if (k % 7 === 6) {
                itens = [{ tipo: 'simulado', materiaId: null, materia: 'Simulado', topico: 'Simulado completo e correção', min: cap, questoes: 0 }];
            } else {
                const n = Math.min(lim.maxMateriasRev, materias.length);
                const ordem = materias.map((m, i) => ({ m, i, s: pesos[i] / (1 + vezes[i]) })).sort((a, b) => b.s - a.s).slice(0, n);
                const cada = Math.max(15, arred5(cap / n));
                itens = ordem.map(({ m, i }) => {
                    vezes[i]++;
                    return { tipo: 'revisao', materiaId: m.id, materia: m.nome, topico: 'Revisão ativa e questões', min: Math.min(cada, cap), questoes: 10 };
                });
            }
            itens.forEach((it) => { it.id = 'v' + (++cont) + '_' + data.replace(/-/g, ''); });
            dias.push({ data, fase: 'revisao', itens });
        }
        return dias;
    }

    function diasUteisAteProva(inicio, dataProva) {
        return dataProva ? Math.max(0, diffDias(inicio, dataProva)) : null;
    }

    // Menor tempo diário (entre as opções comuns) com que o conteúdo termina com folga
    // pra revisar antes da prova.
    function sugerirHoras(cfg) {
        const disp = diasUteisAteProva(cfg.inicio, cfg.dataProva);
        if (disp == null) return null;
        const reserva = Math.max(3, Math.ceil(disp * 0.15));
        for (const h of [1, 2, 3, 4, 5, 6, 8, 10, 12]) {
            const r = gerarPlano({ ...cfg, horasPorDia: h, _soConteudo: true });
            if (r.resumo.diasEstudo <= disp - reserva) return h;
        }
        return 12;
    }

    function validarConfig(cfg) {
        if (!cfg || !Array.isArray(cfg.materias) || !cfg.materias.length) throw new Error('Nenhuma matéria para planejar.');
        if (!dataValida(cfg.inicio)) throw new Error('Data de início inválida.');
        if (cfg.dataProva && !dataValida(cfg.dataProva)) throw new Error('Data da prova inválida.');
        if (cfg.dataProva && diffDias(cfg.inicio, cfg.dataProva) < 1) throw new Error('A data da prova precisa ser depois do início do plano.');
        const h = Number(cfg.horasPorDia);
        if (!(h >= 0.5 && h <= 16)) throw new Error('Informe um tempo diário entre 0,5 e 16 horas.');
    }

    // cfg: { concurso, orgao, banca, cargo, dataProva|null, inicio, horasPorDia, revisaoSemanal, materias }
    // materias já numeradas (numerarMaterias).
    function gerarPlano(cfg) {
        validarConfig(cfg);
        const cap = Math.max(30, arred5(cfg.horasPorDia * 60));
        const materias = cfg.materias;
        const filas = criarUnidades(materias, cap);
        const totalMin = filas.reduce((s, f) => s + f.reduce((a, u) => a + u.min, 0), 0);
        const ag = agendarUnidades(filas, materias, { inicio: cfg.inicio, cap, revisaoSemanal: cfg.revisaoSemanal !== false });
        const diasEstudo = ag.dias.length;
        let dias = ag.dias;
        const disp = diasUteisAteProva(cfg.inicio, cfg.dataProva);
        let cabe = true;
        if (!cfg._soConteudo) {
            const fase2 = montarFaseRevisao(materias, { fimConteudo: ag.fimConteudo, dataProva: cfg.dataProva, cap, diasEstudo });
            dias = dias.concat(fase2);
            if (cfg.dataProva) {
                cabe = diffDias(ag.fimConteudo, cfg.dataProva) >= 1;
                if (cabe) dias.push({ data: cfg.dataProva, fase: 'prova', itens: [{ id: 'prova', tipo: 'prova', materiaId: null, materia: 'Dia da prova', topico: 'Documento, caneta preta e chegar cedo', min: 0, questoes: 0 }] });
                else dias.forEach((d) => { if (d.data >= cfg.dataProva) d.aposProva = true; });
            }
        }
        const minPorMateria = materias.map((m, i) => ({ materiaId: m.id, nome: m.nome, min: criarUnidades([m], cap)[0].reduce((s, u) => s + u.min, 0) }));
        const resumo = {
            totalMin,
            diasEstudo,
            diasRevisao: dias.filter((d) => d.fase === 'revisao').length,
            totalDias: dias.length,
            fimConteudo: ag.fimConteudo,
            diasDisponiveis: disp,
            cabe,
            folgaDias: cfg.dataProva ? diffDias(ag.fimConteudo, cfg.dataProva) - 1 : null,
            minPorMateria,
        };
        return {
            versao: 1,
            id: 'plano_' + Date.now().toString(36),
            criadoEm: new Date().toISOString(),
            concurso: cfg.concurso || '',
            orgao: cfg.orgao || '',
            banca: cfg.banca || '',
            cargo: cfg.cargo || '',
            dataProva: cfg.dataProva || null,
            inicio: cfg.inicio,
            horasPorDia: Number(cfg.horasPorDia),
            revisaoSemanal: cfg.revisaoSemanal !== false,
            materias: materias.map((m) => ({ id: m.id, nome: m.nome, cor: m.cor, questoes: m.questoes, pontos: m.pontos, sugerido: !!m.sugerido, topicos: m.topicos })),
            dias,
            resumo,
        };
    }

    // ----------------------------------------------------------------- replanejar
    // Reorganiza o que falta a partir de `hoje` (atrasou? mudou o tempo diário?).
    // Mantém os dias passados e o que já foi feito; o resto é redistribuído.
    function replanejar(plano, registros, hoje, opcoes) {
        registros = registros || {};
        opcoes = opcoes || {};
        const horas = Number(opcoes.horasPorDia || plano.horasPorDia);
        const cap = Math.max(30, arred5(horas * 60));
        const feito = (id) => !!(registros[id] && registros[id].feito);
        const materias = plano.materias;

        const passados = [];
        const pendentes = [];
        let sementeHoje = null;
        plano.dias.forEach((d) => {
            const ehPassado = d.data < hoje;
            const ehHoje = d.data === hoje;
            const mantidos = [];
            d.itens.forEach((it) => {
                if (it.tipo !== 'estudo') { if (ehPassado || (ehHoje && feito(it.id))) mantidos.push(it); return; }
                if (feito(it.id)) mantidos.push(it);
                else pendentes.push(it);
            });
            if (ehPassado) passados.push({ ...d, itens: mantidos });
            else if (ehHoje) sementeHoje = { itens: mantidos, usado: mantidos.reduce((s, x) => s + (x.min || 0), 0), temGrande: mantidos.some((x) => x.peso === 3) };
        });

        const porMateria = materias.map(() => []);
        pendentes.forEach((it) => {
            const mi = materias.findIndex((m) => m.id === it.materiaId);
            if (mi < 0) return;
            const u = { ...it, grande: it.peso === 3 };
            if (u.min > cap) { u.min = cap; }
            porMateria[mi].push(u);
        });

        const inicioNovo = hoje < plano.inicio ? plano.inicio : hoje;
        const diaIdxAtual = Math.max(0, diffDias(plano.inicio, inicioNovo));
        const ag = agendarUnidades(porMateria, materias, {
            inicio: inicioNovo,
            cap,
            revisaoSemanal: plano.revisaoSemanal !== false,
            semente: sementeHoje && inicioNovo === hoje ? sementeHoje : null,
            alinharSemana: true,
            indiceSemana0: diaIdxAtual,
            inicioIdItem: 100000,
        });
        const diasEstudoNovos = ag.dias.length;
        const fase2 = montarFaseRevisao(materias, { fimConteudo: ag.fimConteudo, dataProva: plano.dataProva, cap, diasEstudo: diasEstudoNovos });
        let novos = ag.dias.concat(fase2);
        let cabe = true;
        if (plano.dataProva) {
            cabe = diffDias(ag.fimConteudo, plano.dataProva) >= 1;
            if (cabe) novos.push({ data: plano.dataProva, fase: 'prova', itens: [{ id: 'prova', tipo: 'prova', materiaId: null, materia: 'Dia da prova', topico: 'Documento, caneta preta e chegar cedo', min: 0, questoes: 0 }] });
            else novos.forEach((d) => { if (d.data >= plano.dataProva) d.aposProva = true; });
        }
        // Se hoje já tinha itens feitos mas a redistribuição começou em hoje, o primeiro dia novo já os contém (semente).
        const dias = passados.concat(novos);
        const resumo = {
            ...plano.resumo,
            diasEstudo: dias.filter((d) => d.fase === 'estudo').length,
            diasRevisao: dias.filter((d) => d.fase === 'revisao').length,
            totalDias: dias.length,
            fimConteudo: ag.fimConteudo,
            cabe,
            folgaDias: plano.dataProva ? diffDias(ag.fimConteudo, plano.dataProva) - 1 : null,
        };
        return { ...plano, horasPorDia: horas, dias, resumo, replanejadoEm: new Date().toISOString() };
    }

    // ----------------------------------------------------------------- consultas
    function diaDoPlano(plano, data) {
        return plano.dias.find((d) => d.data === data) || null;
    }
    function tempoDoItemMs(id, registros, tempos) {
        const auto = (tempos && tempos[id]) || 0;
        const ajuste = ((registros && registros[id] && registros[id].ajusteMin) || 0) * 60000;
        return Math.max(0, auto + ajuste);
    }
    function itensPendentesAtrasados(plano, registros, hoje) {
        const out = [];
        plano.dias.forEach((d) => {
            if (d.data >= hoje) return;
            d.itens.forEach((it) => { if (it.tipo !== 'prova' && !(registros && registros[it.id] && registros[it.id].feito)) out.push({ ...it, data: d.data }); });
        });
        return out;
    }

    // Estatísticas do painel (geral e por matéria).
    function calcularEstatisticas(plano, registros, tempos, hoje) {
        registros = registros || {};
        const porMateria = {};
        plano.materias.forEach((m) => { porMateria[m.id] = { materiaId: m.id, nome: m.nome, cor: m.cor, itens: 0, feitos: 0, minTotal: 0, minFeitos: 0, acertos: 0, erros: 0, tempoMs: 0 }; });
        let minTotal = 0, minFeitos = 0, itens = 0, feitos = 0, acertos = 0, erros = 0, tempoMs = 0, diasEstudados = 0;
        plano.dias.forEach((d) => {
            let diaTemTempo = false;
            d.itens.forEach((it) => {
                if (it.tipo === 'prova') return;
                const r = registros[it.id] || {};
                const t = tempoDoItemMs(it.id, registros, tempos);
                tempoMs += t;
                if (t > 0) diaTemTempo = true;
                const pm = it.materiaId ? porMateria[it.materiaId] : null;
                itens++; minTotal += it.min;
                if (r.feito) { feitos++; minFeitos += it.min; }
                acertos += r.acertos || 0; erros += r.erros || 0;
                if (pm) {
                    pm.itens++; pm.minTotal += it.min; pm.tempoMs += t;
                    if (r.feito) { pm.feitos++; pm.minFeitos += it.min; }
                    pm.acertos += r.acertos || 0; pm.erros += r.erros || 0;
                }
            });
            if (diaTemTempo || d.itens.some((it) => registros[it.id] && registros[it.id].feito)) diasEstudados++;
        });
        const lista = Object.values(porMateria).map((p) => ({ ...p, feitas: p.acertos + p.erros, pct: p.acertos + p.erros ? p.acertos / (p.acertos + p.erros) : null }));
        const diasParaProva = plano.dataProva ? Math.max(0, diffDias(hoje, plano.dataProva)) : null;
        const diaAtual = plano.dias.findIndex((d) => d.data >= hoje);
        return {
            itens, feitos, minTotal, minFeitos,
            avanco: minTotal ? minFeitos / minTotal : 0,
            questoes: acertos + erros, acertos, erros,
            pctAcerto: acertos + erros ? acertos / (acertos + erros) : null,
            tempoMs, diasEstudados,
            diasPassados: plano.dias.filter((d) => d.data <= hoje).length,
            diasParaProva,
            diaAtualIndex: diaAtual < 0 ? plano.dias.length : diaAtual,
            porMateria: lista,
        };
    }

    // Situação da matéria contra a meta (mesma ideia do Painel da planilha).
    function situacaoDesempenho(pct, meta, minimo) {
        if (pct == null) return { cod: 'sem', rotulo: '—' };
        if (pct >= meta) return { cod: 'ok', rotulo: '✔ na meta' };
        if (pct >= minimo) return { cod: 'quase', rotulo: '▲ quase lá' };
        return { cod: 'atencao', rotulo: '▼ atenção' };
    }

    const api = {
        corrigirCodificacaoPdf, converterMacParaWin, contarEstranhos,
        PESO_MIN, PESO_ROTULO, QUESTOES_SUGERIDAS, CORES_MATERIA,
        semAcento, norm, cortar, arred5, fmtMin,
        parseData, fmtData, addDias, diffDias, diaSemana, dataValida, hojeStr, fmtBR, nomeDiaSemana,
        prepararTexto, ehTitulo, acharAnexoConteudo, acharSecaoProvas, acharEstruturaProva, linhasComDataDeProva, titulosDoAnexo,
        acharLinha, fatiarConteudoDoCargo, dividirEmPedacos, analisarEdital,
        SISTEMA_IA, montarPromptMeta, montarPromptConteudo,
        extrairJSON, extrairJSONInfo, sanitizarMeta, sanitizarConteudo, mesclarMaterias, numerarMaterias, estruturarConteudoLocal,
        disciplinasNumeradas, nomeCobre, materiaDeTexto, montarPromptContinuacao,
        comRetentativas, chamarIAJson, primeiraDataDasLinhas, metaLocal, extrairMeta, extrairConteudo,
        gerarPlano, sugerirHoras, replanejar,
        diaDoPlano, tempoDoItemMs, itensPendentesAtrasados, calcularEstatisticas, situacaoDesempenho,
    };

    if (typeof module !== 'undefined' && module.exports) module.exports = api;
    else root.CBPlano = api;
})(typeof self !== 'undefined' ? self : this);
