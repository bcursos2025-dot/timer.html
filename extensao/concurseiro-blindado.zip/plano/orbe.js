// ===================== ESFERA 3D DE PARTÍCULAS (tela de carregamento) =====================
//
// Canvas 2D com projeção 3D feita à mão (sem biblioteca): milhares de pontos de luz sobre uma esfera
// que gira, uma casca de vidro com brilho na borda e poeira luminosa que se solta dos dois lados e
// espirala para fora. As duas metades têm cor FIXA na tela (azul à esquerda, rosa à direita): as
// partículas é que passam de uma cor para a outra ao girar, como na referência.
//
//   CBOrbe.iniciar(canvas)  → começa a animar (e escuta o ponteiro: a esfera inclina para onde ele vai)
//   CBOrbe.parar()          → para o laço (a tela escondida não gasta processador)
//
// Custo: ~4.500 pontos por quadro, desenhados com sprites pré-coloridos (drawImage) em modo aditivo.
(function (root) {
    'use strict';

    const N_CASCA = 3000, N_NUCLEO = 500, N_POEIRA = 1300, N_NEVOA = 30;
    const BINS = 30;           // sprites de cor, do azul-ciano ao rosa
    const FOCO = 0.2;          // força da perspectiva
    const TAU = Math.PI * 2;

    let est = null;

    function rng(semente) {
        let s = semente >>> 0;
        return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
    }
    const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

    // paleta: azul-ciano → anil → violeta → rosa   [posição, matiz, saturação, luminosidade]
    const PALETA = [[0, 196, 96, 62], [0.34, 222, 92, 66], [0.62, 268, 86, 72], [1, 322, 94, 72]];
    function cor(t) {
        for (let i = 1; i < PALETA.length; i++) {
            if (t <= PALETA[i][0]) {
                const a = PALETA[i - 1], b = PALETA[i], k = (t - a[0]) / (b[0] - a[0]);
                return [a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k, a[3] + (b[3] - a[3]) * k];
            }
        }
        const u = PALETA[PALETA.length - 1];
        return [u[1], u[2], u[3]];
    }
    function criarSprites() {
        const lista = [];
        for (let i = 0; i < BINS; i++) {
            const [h, s, l] = cor(i / (BINS - 1));
            const c = document.createElement('canvas');
            c.width = c.height = 32;
            const g = c.getContext('2d');
            const gr = g.createRadialGradient(16, 16, 0, 16, 16, 16);
            gr.addColorStop(0, `hsla(${h}, ${s}%, ${Math.min(97, l + 24)}%, 1)`);
            gr.addColorStop(0.28, `hsla(${h}, ${s}%, ${l}%, 0.82)`);
            gr.addColorStop(0.62, `hsla(${h}, ${s}%, ${l - 10}%, 0.16)`);
            gr.addColorStop(1, `hsla(${h}, ${s}%, ${l - 10}%, 0)`);
            g.fillStyle = gr;
            g.fillRect(0, 0, 32, 32);
            lista.push(c);
        }
        return lista;
    }
    // halo de cor: bolha macia pré-desenhada (uma vez), reaproveitada a cada quadro
    function criarHalo(rgb, a) {
        const c = document.createElement('canvas');
        c.width = c.height = 128;
        const g = c.getContext('2d');
        const gr = g.createRadialGradient(64, 64, 6, 64, 64, 64);
        gr.addColorStop(0, `rgba(${rgb},${a})`);
        gr.addColorStop(1, `rgba(${rgb},0)`);
        g.fillStyle = gr;
        g.fillRect(0, 0, 128, 128);
        return c;
    }

    function criarParticulas(r) {
        const casca = [];
        for (let i = 0; i < N_CASCA; i++) {
            const y = 1 - (2 * (i + 0.5)) / N_CASCA, q = Math.sqrt(1 - y * y), fi = i * 2.399963229728653;
            // um pouco de desordem tira o aspecto de grade
            const j = 0.012;
            let x = Math.cos(fi) * q + (r() - 0.5) * j, yy = y + (r() - 0.5) * j, z = Math.sin(fi) * q + (r() - 0.5) * j;
            const n = Math.hypot(x, yy, z); x /= n; yy /= n; z /= n;
            casca.push({ x, y: yy, z, ph: r() * TAU, tam: 0.7 + r() * 1.5, jc: (r() - 0.5) * 0.12 });
        }
        const nucleo = [];
        for (let i = 0; i < N_NUCLEO; i++) {
            const u = r(), v = r(), th = TAU * u, ph = Math.acos(2 * v - 1), raio = 0.18 + 0.72 * Math.cbrt(r());
            nucleo.push({ x: raio * Math.sin(ph) * Math.cos(th), y: raio * Math.cos(ph), z: raio * Math.sin(ph) * Math.sin(th), ph: r() * TAU, tam: 0.6 + r() * 1.1 });
        }
        const poeira = [];
        for (let i = 0; i < N_POEIRA; i++) poeira.push({ vivo: false, nasce: r() * 4 });
        const nevoa = [];
        for (let i = 0; i < N_NEVOA; i++) nevoa.push({ lado: i % 2 ? 1 : -1, ang: (r() - 0.5) * 1.7, raio: 0.95 + r() * 0.5, vel: 0.02 + r() * 0.05, ph: r() * TAU, tam: 0.5 + r() * 0.9, a: 0.03 + r() * 0.06, fase: r() });
        return { casca, nucleo, poeira, nevoa };
    }

    function nascerPoeira(p, r, t) {
        const lado = r() < 0.5 ? -1 : 1;
        const ang = (r() - 0.5) * 2.3;                       // em torno do eixo horizontal
        const raio = 0.97 + r() * 0.07;
        p.lado = lado;
        p.x = lado * Math.cos(ang) * raio;
        p.y = Math.sin(ang) * raio;
        const vel = 0.07 + r() * 0.22;
        const gira = (r() - 0.5) * 0.18;                     // espiral
        p.vx = lado * Math.cos(ang) * vel - Math.sin(ang) * gira * lado;
        p.vy = Math.sin(ang) * vel + Math.cos(ang) * gira;
        p.idade = 0;
        p.vida = 2.6 + r() * 3.2;
        p.tam = 0.8 + r() * 2.2;
        p.ph = r() * TAU;
        p.t = lado < 0 ? r() * 0.3 : 0.7 + r() * 0.3;       // posição na paleta: azul à esquerda, rosa à direita
        p.vivo = true;
    }

    function desenhar(e, agora) {
        const { ctx, W, H, sprites, nevoa } = e;
        const t = (agora - e.t0) / 1000;
        const bruto = (agora - e.ultimo) / 1000;
        const dt = clamp(bruto, 0, 0.05);
        e.ultimo = agora;
        // Regulador: se a média de 40 quadros passar de ~34 ms (menos de 30 quadros/s), desenha metade
        // das partículas (e depois um quarto), um pouco maiores. Máquina rápida nunca entra nisso.
        if (!e.medindo && bruto > 0) {
            e.somaDt += bruto; e.nq++;
            if (e.nq >= 40) { if (e.somaDt / e.nq > 0.034 && e.passo < 4) e.passo *= 2; e.somaDt = 0; e.nq = 0; }
        }
        const passo = e.passo, mais = passo > 1 ? 1.25 : 1;
        // o ponteiro inclina a esfera de leve (suavizado)
        e.px += (e.alvoX - e.px) * Math.min(1, dt * 3);
        e.py += (e.alvoY - e.py) * Math.min(1, dt * 3);

        const R = Math.min(W, H) * 0.25;
        const cx = W / 2, cy = H / 2;
        const ry = t * 0.27 + e.px * 0.7, rx = 0.3 + 0.09 * Math.sin(t * 0.37) + e.py * 0.5;
        const cY = Math.cos(ry), sY = Math.sin(ry), cX = Math.cos(rx), sX = Math.sin(rx);
        const dpr = e.dpr;

        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.clearRect(0, 0, W, H);
        ctx.globalCompositeOperation = 'lighter';

        // 1) halos de cor: um azul à esquerda e um rosa à direita, atrás de tudo
        const halo = (x0, spr) => { const d = R * 2.3; ctx.globalAlpha = 1; ctx.drawImage(spr, cx + x0 * R - d / 2, cy - d / 2, d, d); };
        halo(-0.6, e.halos[0]);
        halo(0.6, e.halos[1]);

        // 2) névoa: bolhas enormes e quase transparentes que sobem dos lados
        for (const n of nevoa) {
            const fase = (t * n.vel + n.fase) % 1;
            const raio = n.raio + fase * 0.55;
            const ang = n.ang + Math.sin(t * 0.5 + n.ph) * 0.18;
            const x = cx + n.lado * Math.cos(ang) * raio * R, y = cy + Math.sin(ang) * raio * R;
            const al = n.a * Math.sin(Math.PI * fase);
            if (al <= 0.002) continue;
            const s = n.tam * R * (0.55 + fase * 0.5);
            ctx.globalAlpha = al;
            ctx.drawImage(sprites[n.lado < 0 ? 3 : BINS - 4], x - s / 2, y - s / 2, s, s);   // bolha macia, azul à esquerda / rosa à direita
        }

        // 3) núcleo: pontos mais fracos DENTRO da esfera (dão profundidade por trás da casca)
        for (let i = 0; i < e.pts.nucleo.length; i += passo) {
            const p = e.pts.nucleo[i];
            const x = p.x * Math.cos(-t * 0.18) + p.z * Math.sin(-t * 0.18), z0 = -p.x * Math.sin(-t * 0.18) + p.z * Math.cos(-t * 0.18);
            const x1 = x * cY + z0 * sY, z1 = -x * sY + z0 * cY;
            const y2 = p.y * cX - z1 * sX, z2 = p.y * sX + z1 * cX;
            const esc = 1 / (1 - z2 * FOCO);
            const sx = cx + x1 * R * esc, sy = cy + y2 * R * esc;
            const u = clamp((x1 + 1) / 2 + 0.06 * Math.sin(t + p.ph), 0, 1);
            ctx.globalAlpha = (0.16 + 0.12 * Math.sin(t * 2 + p.ph)) * (0.5 + 0.5 * (z2 + 1) / 2);
            const s = p.tam * 3.2 * esc * dpr * mais;
            ctx.drawImage(sprites[Math.round(u * (BINS - 1))], sx - s / 2, sy - s / 2, s, s);
        }

        // 4) casca: milhares de pontos sobre a esfera; mais fortes na borda (efeito de vidro)
        for (let i = 0; i < e.pts.casca.length; i += passo) {
            const p = e.pts.casca[i];
            const respira = 1 + 0.011 * Math.sin(p.ph + t * 1.7);
            const x = p.x * respira, y = p.y * respira, z = p.z * respira;
            const x1 = x * cY + z * sY, z1 = -x * sY + z * cY;
            const y2 = y * cX - z1 * sX, z2 = y * sX + z1 * cX;
            const esc = 1 / (1 - z2 * FOCO);
            const sx = cx + x1 * R * esc, sy = cy + y2 * R * esc;
            const borda = 1 - Math.abs(z2);                         // 1 na silhueta, 0 no centro do disco
            const frente = (z2 + 1) / 2;
            const onda = 0.78 + 0.22 * Math.sin(y2 * 7 + t * 2.1 + p.ph * 0.3);   // faixas de brilho que correm
            const brilha = 0.75 + 0.25 * Math.sin(t * 3 + p.ph * 7);
            const al = (0.2 + 0.8 * Math.pow(borda, 1.5)) * (0.5 + 0.5 * frente) * onda * brilha;
            if (al < 0.05) continue;
            const u = clamp((x1 + 1) / 2 + p.jc, 0, 1);
            ctx.globalAlpha = Math.min(1, al * 0.95);
            const s = p.tam * (2.8 + 2.4 * borda) * esc * dpr * mais;
            ctx.drawImage(sprites[Math.round(u * (BINS - 1))], sx - s / 2, sy - s / 2, s, s);
        }

        // 5) poeira luminosa: nasce na borda, espirala para fora e some
        for (let i = 0; i < e.pts.poeira.length; i++) {
            const p = e.pts.poeira[i];
            if (!p.vivo) {
                p.nasce -= dt;
                if (p.nasce <= 0) nascerPoeira(p, e.r, t);
                continue;
            }
            p.idade += dt;
            if (p.idade >= p.vida) { p.vivo = false; p.nasce = e.r() * 0.6; continue; }
            // turbulência suave + arrasto
            p.vx += Math.sin(p.y * 3.2 + t * 1.3 + p.ph) * 0.03 * dt * 6;
            p.vy += Math.cos(p.x * 3.2 - t * 1.1 + p.ph) * 0.03 * dt * 6;
            const arrasto = 1 - 0.35 * dt;
            p.vx *= arrasto; p.vy *= arrasto;
            p.x += p.vx * dt; p.y += p.vy * dt;
            const k = p.idade / p.vida;
            const al = Math.pow(Math.sin(Math.PI * k), 1.1) * 0.95;
            if (i % passo) continue;                        // a poeira anda sempre; só o desenho é reduzido
            const sx = cx + p.x * R, sy = cy + p.y * R;
            ctx.globalAlpha = al;
            const s = p.tam * (2.8 + k * 2.6) * dpr * mais;
            ctx.drawImage(sprites[Math.round(clamp(p.t + 0.05 * Math.sin(t + p.ph), 0, 1) * (BINS - 1))], sx - s / 2, sy - s / 2, s, s);
        }

        // 6) casca de vidro: aro com degradê azul → rosa e um reflexo no alto à esquerda
        ctx.globalCompositeOperation = 'lighter';
        ctx.globalAlpha = 1;
        const aro = ctx.createLinearGradient(cx - R, 0, cx + R, 0);
        aro.addColorStop(0, 'rgba(110,190,255,0.7)');
        aro.addColorStop(0.5, 'rgba(150,130,255,0.18)');
        aro.addColorStop(1, 'rgba(255,120,220,0.7)');
        ctx.lineWidth = 1.6 * dpr;
        ctx.strokeStyle = aro;
        ctx.shadowColor = 'rgba(140,140,255,0.9)';
        ctx.shadowBlur = 14 * dpr;
        ctx.beginPath(); ctx.arc(cx, cy, R * 1.012, 0, TAU); ctx.stroke();
        ctx.shadowBlur = 0;
        ctx.lineWidth = 3 * dpr;
        const brilho = ctx.createLinearGradient(cx - R, cy - R, cx, cy);
        brilho.addColorStop(0, 'rgba(255,255,255,0)');
        brilho.addColorStop(0.5, 'rgba(255,255,255,0.28)');
        brilho.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.strokeStyle = brilho;
        ctx.beginPath(); ctx.arc(cx, cy, R * 0.93, Math.PI * 1.08, Math.PI * 1.46); ctx.stroke();

        ctx.globalAlpha = 1;
        ctx.globalCompositeOperation = 'source-over';
    }

    function medir(e) {
        const caixa = e.canvas.getBoundingClientRect();
        const dpr = Math.min(1.5, root.devicePixelRatio || 1);
        const w = Math.max(160, Math.round(caixa.width || 320)), h = Math.max(160, Math.round(caixa.height || 320));
        e.dpr = dpr;
        e.W = Math.round(w * dpr);
        e.H = Math.round(h * dpr);
        if (e.canvas.width !== e.W) e.canvas.width = e.W;
        if (e.canvas.height !== e.H) e.canvas.height = e.H;
    }

    function laco(e) {
        if (e !== est) return;
        desenhar(e, performance.now());
        if (!e.estatico) e.raf = requestAnimationFrame(() => laco(e));
    }

    function iniciar(canvas) {
        parar();
        if (!canvas || !canvas.getContext) return;
        const r = rng(20261012);
        const e = est = {
            canvas, ctx: canvas.getContext('2d'), r, pts: criarParticulas(r), sprites: criarSprites(), halos: [criarHalo('70,130,255', 0.26), criarHalo('255,90,210', 0.22)],
            nevoa: null, t0: performance.now(), ultimo: performance.now(), px: 0, py: 0, alvoX: 0, alvoY: 0, raf: 0, estatico: false, dpr: 1, W: 320, H: 320, passo: 1, somaDt: 0, nq: 0, medindo: false,
        };
        e.nevoa = e.pts.nevoa;
        medir(e);
        e.estatico = !!(root.matchMedia && root.matchMedia('(prefers-reduced-motion: reduce)').matches);
        // o ponteiro inclina a esfera: -1..1 em relação ao centro da janela
        e.mover = (ev) => {
            e.alvoX = clamp((ev.clientX / root.innerWidth - 0.5) * 2, -1, 1) * 0.6;
            e.alvoY = clamp((ev.clientY / root.innerHeight - 0.5) * 2, -1, 1) * 0.6;
        };
        e.redim = () => medir(e);
        root.addEventListener('pointermove', e.mover, { passive: true });
        root.addEventListener('resize', e.redim);
        // adianta a poeira para a tela já nascer cheia
        for (const p of e.pts.poeira) { if (e.r() < 0.7) { nascerPoeira(p, e.r, 0); p.idade = e.r() * p.vida * 0.8; } }
        laco(e);
    }

    function parar() {
        if (!est) return;
        cancelAnimationFrame(est.raf);
        root.removeEventListener('pointermove', est.mover);
        root.removeEventListener('resize', est.redim);
        est = null;
    }

    // Só para medir desempenho nos testes: desenha n quadros seguidos, sem esperar o navegador, e devolve ms/quadro.
    function medirQuadros(n) {
        if (!est) return null;
        est.medindo = true;
        const ini = performance.now();
        let agora = est.ultimo;
        for (let i = 0; i < n; i++) { agora += 16.7; desenhar(est, agora); }
        est.medindo = false;
        return (performance.now() - ini) / n;
    }

    root.CBOrbe = { iniciar, parar, medirQuadros };
})(typeof window !== 'undefined' ? window : globalThis);
