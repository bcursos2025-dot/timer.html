// ===================== PLANO DE ESTUDOS — PÁGINA CHEIA =====================
//
// Fluxo (nesta ordem, a pedido):
//   1. Anexar o PDF → a IA SÓ identifica quais cargos o edital tem.
//   2. A pessoa escolhe o cargo.
//   3. Só então a IA lê o conteúdo daquele cargo (matérias e tópicos).
//   4. A pessoa informa o tempo diário (1, 2, 4, 6, 8 ou mais), confere o conteúdo e o
//      plano é montado por código (plano-core.js).
//
// Dados: planoEstudo / planoRegistros / planoTempo / planoItemAtivo em chrome.storage.local
// (ver o cabeçalho de plano-core.js).

(function () {
    'use strict';

    const C = window.CBPlano;
    const $ = (id) => document.getElementById(id);
    const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const getLocal = (keys) => new Promise((r) => chrome.storage.local.get(keys, r));
    const setLocal = (obj) => new Promise((r) => chrome.storage.local.set(obj, r));
    const removeLocal = (keys) => new Promise((r) => chrome.storage.local.remove(keys, r));
    const MESES = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
    const CHECK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>';

    // Estado da tela do plano.
    const S = { plano: null, registros: {}, tempos: {}, config: { meta: 80, minimo: 60 }, filtro: 'tudo', aba: 'crono' };
    // Estado do assistente.
    const W = { horas: 2, materias: [], avisos: [], cargo: null };

    // ------------------------------------------------------------------ IA
    function chamarIAComAvisos(aoEsperar) {
        return C.comRetentativas(
            async (msgs) => {
                if (typeof window.cbGerarRespostaIA !== 'function') throw new Error('O módulo de IA não carregou.');
                return window.cbGerarRespostaIA(msgs, { timeoutMs: 180000, naoPedirChave: true });
            },
            { tentativas: 3, esperaMs: 12000, aoEsperar }
        );
    }

    // "Trabalhando": mostra a tela de carregamento (esfera animada, ver plano.css) com a etapa atual e o
    // tempo decorrido; devolve { trocar, parar }. O texto pequeno do passo fica vazio enquanto ela está
    // no ar, para não aparecer duas vezes.
    function ocupado(passo, texto) {
        const el = $('pl-status-' + passo);
        const tela = $('pl-carregando'), titulo = $('pl-carregando-titulo'), sub = $('pl-carregando-sub');
        const t0 = Date.now();
        let atual = texto;
        const pinta = () => {
            titulo.textContent = atual;
            sub.textContent = `${Math.round((Date.now() - t0) / 1000)} s · pode levar um ou dois minutos. Mantenha esta aba aberta.`;
        };
        el.className = 'pl-status';
        el.textContent = '';
        tela.hidden = false;
        if (window.CBOrbe) window.CBOrbe.iniciar($('pl-orb'));
        pinta();
        const id = setInterval(pinta, 1000);
        return {
            trocar(novo) { atual = novo; pinta(); },
            parar() { clearInterval(id); tela.hidden = true; if (window.CBOrbe) window.CBOrbe.parar(); el.textContent = ''; el.className = 'pl-status'; },
        };
    }
    function statusSimples(passo, texto, tipo) {
        const el = $('pl-status-' + passo);
        el.className = 'pl-status' + (tipo ? ' is-' + tipo : '');
        el.textContent = texto || '';
    }

    function mensagemDeErroIA(e) {
        const m = e && e.message;
        if (m === 'IA_INDISPONIVEL' || /indispon|quota|429|402|rede|fetch|abort|timeout/i.test(m || '')) {
            return 'As IAs gratuitas estão no limite de uso agora. Espere um ou dois minutos e tente de novo, ou use uma chave gratuita do Gemini.';
        }
        return m || 'Não foi possível consultar a IA.';
    }
    function botaoChaveGemini(passo, aoSalvar) {
        const el = $('pl-status-' + passo);
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'pl-btn pl-btn--sm';
        b.style.marginLeft = '12px';
        b.textContent = 'Usar chave do Gemini';
        b.addEventListener('click', async () => {
            const chave = (prompt('Cole uma chave gratuita do Google Gemini (gere em https://aistudio.google.com/apikey):') || '').trim();
            if (!chave) return;
            await setLocal({ cbGeminiApiKey: chave });
            aoSalvar();
        });
        el.appendChild(b);
    }

    // ------------------------------------------------------------------ PDF
    // Agrupa os pedaços de texto da página por linha (coordenada Y) e ordena por X:
    // assim cada linha de tabela do edital ("Matemática 05 2,0 10,00") sai inteira.
    function itensParaTexto(items) {
        const linhas = [];
        items.forEach((it) => {
            if (!it.str || !it.transform) return;
            const y = it.transform[5], x = it.transform[4];
            let l = null;
            for (let i = linhas.length - 1; i >= 0 && i >= linhas.length - 6; i--) {
                if (Math.abs(linhas[i].y - y) <= 2.5) { l = linhas[i]; break; }
            }
            if (!l) { l = { y, itens: [] }; linhas.push(l); }
            l.itens.push({ x, str: it.str, w: it.width || 0 });
        });
        linhas.sort((a, b) => b.y - a.y);
        return linhas.map((l) => {
            l.itens.sort((a, b) => a.x - b.x);
            let s = '', fim = null;
            l.itens.forEach((i) => {
                if (fim !== null && i.x - fim > 1.5 && !/^\s/.test(i.str) && !/\s$/.test(s)) s += ' ';
                s += i.str;
                fim = i.x + i.w;
            });
            return s.replace(/\s+/g, ' ').trim();
        }).join('\n');
    }

    async function extrairPaginas(buffer, aoProgredir) {
        if (!window.pdfjsLib) throw new Error('O leitor de PDF não carregou.');
        window.pdfjsLib.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('dados-config/lib/pdfjs/pdf.worker.min.js');
        const pdf = await window.pdfjsLib.getDocument({ data: buffer }).promise;
        // Primeiro junta os itens de TODAS as páginas: a correção de codificação (PDF
        // gravado em Windows-1252 mas declarado MacRoman → "P⁄BLICO") decide por fonte,
        // e uma fonte só se revela errada olhando bastante texto dela.
        const itensPorPagina = [];
        for (let i = 1; i <= pdf.numPages; i++) {
            const page = await pdf.getPage(i);
            const tc = await page.getTextContent();
            itensPorPagina.push(tc.items
                .filter((it) => typeof it.str === 'string' && it.transform)
                .map((it) => ({ str: it.str, fontName: it.fontName, transform: it.transform, width: it.width })));
            if (i % 5 === 0 || i === pdf.numPages) aoProgredir(i, pdf.numPages);
        }
        C.corrigirCodificacaoPdf(itensPorPagina);
        return itensPorPagina.map(itensParaTexto);
    }

    // ------------------------------------------------------------------ navegação entre telas
    function mostrar(view) {
        $('view-vazio').hidden = view !== 'vazio';
        $('view-wizard').hidden = view !== 'wizard';
        $('view-plano').hidden = view !== 'plano';
        $('pl-acoes').hidden = !S.plano || view === 'wizard';
        fecharMenu();
    }

    function irPasso(n) {
        [1, 2, 3].forEach((i) => { $('passo-' + i).hidden = i !== n; });
        if (n === 2) renderCargos();
        if (n === 3) iniciarPasso3();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    function abrirWizard() {
        Object.assign(W, { horas: 2, materias: [], avisos: [], cargo: null, an: null, meta: null, paginas: null });
        $('pl-arquivo').value = '';
        statusSimples(1, '');
        statusSimples(2, '');
        $('pl-cargo-manual').value = '';
        $('pl-texto-manual').value = '';
        $('pl-busca-cargo').value = '';
        mostrar('wizard');
        irPasso(1);
    }

    // ------------------------------------------------------------------ passo 1: PDF + cargos
    async function processarArquivo(file) {
        if (!file) return;
        if (file.type !== 'application/pdf' && !/\.pdf$/i.test(file.name)) {
            statusSimples(1, 'Escolha um arquivo PDF.', 'erro');
            return;
        }
        const rel = ocupado(1, 'Lendo o PDF');
        try {
            const buffer = await file.arrayBuffer();
            const paginas = await extrairPaginas(buffer, (i, n) => rel.trocar(`Lendo a página ${i} de ${n}`));
            if (paginas.join('').replace(/\s/g, '').length < 800) {
                throw new Error('Este PDF não tem texto (parece escaneado). Use um PDF com texto selecionável.');
            }
            W.nomeArquivo = file.name;
            W.paginas = paginas;
            W.an = C.analisarEdital(paginas);
            rel.trocar('Identificando os cargos');
            const chamarIA = chamarIAComAvisos((i, n, ms) => rel.trocar(`IA ocupada, nova tentativa em ${Math.round(ms / 1000)} s`));
            const r = await C.extrairMeta(W.an, chamarIA);
            W.meta = r.meta;
            W.metaPorIA = r.usouIA;
            rel.parar();
            irPasso(2);
        } catch (e) {
            rel.parar();
            statusSimples(1, e.message || 'Não consegui ler esse PDF.', 'erro');
        }
    }

    // ------------------------------------------------------------------ passo 2: escolher o cargo
    function renderCargos() {
        const meta = W.meta || { cargos: [] };
        const partes = [meta.concurso, meta.banca].filter(Boolean).map(esc);
        let html = partes.join(' · ');
        if (!W.metaPorIA) {
            html += `<div class="pl-aviso pl-aviso--warn">A IA não respondeu; esta lista pode estar incompleta. <button type="button" class="pl-btn pl-btn--sm" id="pl-retry-meta">Tentar de novo</button></div>`;
        }
        $('pl-edital-info').innerHTML = html;
        const retry = $('pl-retry-meta');
        if (retry) retry.addEventListener('click', tentarMetaDeNovo);
        $('pl-data-prova').value = meta.dataProva || '';
        $('pl-data-prova').closest('label').firstChild.textContent = meta.dataProva ? 'Data da prova' : 'Data da prova (opcional)';
        filtrarCargos();
    }

    // Repete só a consulta da IA do passo 1 (o PDF já foi lido; não precisa anexar de novo).
    async function tentarMetaDeNovo() {
        const rel = ocupado(2, 'Identificando os cargos');
        try {
            const chamarIA = chamarIAComAvisos((i, n, ms) => rel.trocar(`IA ocupada, nova tentativa em ${Math.round(ms / 1000)} s`));
            const r = await C.extrairMeta(W.an, chamarIA);
            if (r.usouIA) { W.meta = r.meta; W.metaPorIA = true; W.cargo = null; }
            rel.parar();
            renderCargos();
            atualizarBotaoLer();
            if (!r.usouIA) statusSimples(2, 'A IA ainda não respondeu. Tente de novo em um ou dois minutos, ou digite o cargo.', 'erro');
        } catch (e) {
            rel.parar();
            statusSimples(2, mensagemDeErroIA(e), 'erro');
        }
    }

    function filtrarCargos() {
        const termo = C.norm($('pl-busca-cargo').value);
        const cont = $('pl-cargos');
        const todos = (W.meta && W.meta.cargos) || [];
        const lista = todos.filter((c) => !termo || C.norm(c.nome).includes(termo));
        if (!lista.length) {
            cont.innerHTML = `<div class="pl-vazio-lista">${todos.length ? 'Nenhum cargo com esse nome.' : 'Não identifiquei cargos. Use “Meu cargo não aparece”.'}</div>`;
            return;
        }
        cont.innerHTML = lista.map((c) => {
            const sel = W.cargo && W.cargo.nome === c.nome;
            return `<label class="pl-cargo${sel ? ' is-sel' : ''}"><input type="radio" name="cargo" value="${esc(c.nome)}"${sel ? ' checked' : ''}><span class="pl-cargo-marca">${CHECK}</span><span>${esc(c.nome)}</span></label>`;
        }).join('');
    }

    function atualizarBotaoLer() {
        $('pl-ler-conteudo').disabled = !(W.cargo || $('pl-cargo-manual').value.trim());
    }

    async function lerConteudo() {
        const manual = $('pl-cargo-manual').value.trim();
        const cargo = manual ? { nome: manual, marcador: null } : W.cargo;
        if (!cargo) return;
        W.cargo = cargo;
        W.dataProva = $('pl-data-prova').value || null;
        $('pl-ler-conteudo').disabled = true;
        const rel = ocupado(2, 'Lendo o conteúdo');
        try {
            const chamarIA = chamarIAComAvisos((i, n, ms) => rel.trocar(`IA ocupada, nova tentativa em ${Math.round(ms / 1000)} s`));
            const r = await C.extrairConteudo({
                an: W.an, meta: W.meta, cargo, chamarIA,
                onProgresso: (t) => rel.trocar(t.replace(/\.+$/, '')),
                textoManual: $('pl-texto-manual').value,
            });
            W.materias = r.materias.map((m) => ({ ...m, topicos: m.topicos.map((t) => ({ ...t })) }));
            W.avisos = r.avisos;
            rel.parar();
            irPasso(3);
        } catch (e) {
            rel.parar();
            if (e.message === 'SEM_CONTEUDO') {
                statusSimples(2, 'Não achei o conteúdo programático neste PDF. Cole o texto em “Meu cargo não aparece”.', 'erro');
                document.querySelector('#passo-2 .pl-mais').open = true;
            } else {
                statusSimples(2, mensagemDeErroIA(e), 'erro');
                botaoChaveGemini(2, lerConteudo);
            }
        } finally {
            atualizarBotaoLer();
        }
    }

    // ------------------------------------------------------------------ passo 3: tempo + conteúdo
    function iniciarPasso3() {
        $('pl-inicio').value = $('pl-inicio').value || C.hojeStr();
        $('pl-data-prova-2').value = W.dataProva || '';
        marcarHoras();
        renderMaterias();
        atualizarResumo();
    }

    function marcarHoras() {
        const padrao = [1, 2, 4, 6, 8];
        document.querySelectorAll('#pl-horas button[data-h]').forEach((b) => b.classList.toggle('is-ativo', +b.dataset.h === W.horas));
        const outro = $('pl-horas-outro');
        outro.value = padrao.includes(W.horas) ? '' : W.horas;
        $('pl-horas-outro-chip').classList.toggle('is-ativo', !padrao.includes(W.horas));
    }

    function renderMaterias() {
        $('pl-avisos').innerHTML = W.avisos.map((a) => `<div class="pl-aviso pl-aviso--warn">${esc(a)}</div>`).join('');
        const nTop = W.materias.reduce((s, m) => s + m.topicos.length, 0);
        $('pl-conteudo-resumo').textContent = `${W.materias.length} matéria${W.materias.length === 1 ? '' : 's'} · ${nTop} tópicos`;
        const cont = $('pl-materias');
        if (!W.materias.length) { cont.innerHTML = '<div class="pl-vazio-lista">Nenhuma matéria. Volte e escolha outro cargo.</div>'; return; }
        const cores = C.CORES_MATERIA;
        const abertas = renderMaterias.abertas || new Set();
        cont.innerHTML = W.materias.map((m, mi) => `
            <details class="pl-mat" data-mi="${mi}"${abertas.has(mi) ? ' open' : ''}>
                <summary>
                    <span class="pl-dot" style="background:${cores[mi % cores.length]}"></span>
                    <span class="pl-mat-nome">${esc(m.nome)}</span>
                    ${m.sugerido ? '<span class="pl-tag" title="O edital só cita o nome da matéria; os tópicos foram sugeridos pela IA.">sugerido</span>' : ''}
                    <span class="pl-mat-info">${m.topicos.length} tópicos${m.questoes ? ` · ${m.questoes} questões` : ''}</span>
                </summary>
                <div class="pl-mat-corpo">
                    <div class="pl-mat-ferr">
                        <input class="pl-input" type="text" data-campo="nome" value="${esc(m.nome)}" aria-label="Nome da matéria">
                        <label>Questões <input class="pl-input" type="number" min="0" max="300" data-campo="questoes" value="${m.questoes == null ? '' : esc(m.questoes)}" placeholder="?"></label>
                        <button type="button" class="pl-link" data-acao="rm-mat" style="color:var(--bad)">Remover matéria</button>
                    </div>
                    ${m.topicos.map((t, ti) => `
                        <div class="pl-top" data-ti="${ti}">
                            <span class="pl-top-nome" title="${esc(t.detalhe || '')}">${esc(t.titulo)}</span>
                            <div class="pl-seg pl-seg--mini" role="group" aria-label="Tamanho do tópico">
                                <button type="button" data-peso="1" class="${t.peso === 1 ? 'is-ativo' : ''}" title="30 min">Leve</button>
                                <button type="button" data-peso="2" class="${t.peso === 2 ? 'is-ativo' : ''}" title="1 hora">Médio</button>
                                <button type="button" data-peso="3" class="${t.peso === 3 ? 'is-ativo' : ''}" title="2 horas">Extenso</button>
                            </div>
                            <button type="button" class="pl-x" data-acao="rm-top" title="Remover tópico" aria-label="Remover tópico">✕</button>
                        </div>`).join('')}
                </div>
            </details>`).join('');
    }

    let timerResumo = null;
    function agendarResumo() { clearTimeout(timerResumo); timerResumo = setTimeout(atualizarResumo, 120); }

    function configDoAssistente(horas) {
        const materias = C.numerarMaterias(W.materias.filter((m) => m.topicos.length));
        return {
            concurso: (W.meta && W.meta.concurso) || '',
            orgao: (W.meta && W.meta.orgao) || '',
            banca: (W.meta && W.meta.banca) || '',
            cargo: W.cargo ? W.cargo.nome : '',
            dataProva: $('pl-data-prova-2').value || null,
            inicio: $('pl-inicio').value || C.hojeStr(),
            horasPorDia: horas || W.horas,
            revisaoSemanal: $('pl-rev-semanal').checked,
            materias,
        };
    }

    function atualizarResumo() {
        const numeros = $('pl-numeros');
        const aviso = $('pl-resumo');
        try {
            const cfg = configDoAssistente();
            const plano = C.gerarPlano(cfg);
            W.previa = plano;
            const r = plano.resumo;
            const bloco = (n, rot) => `<div class="pl-numero"><b>${n}</b><span>${rot}</span></div>`;
            let html = bloco(r.diasEstudo, 'dias de estudo') + bloco(C.fmtBR(r.fimConteudo).slice(0, 5), 'fim do conteúdo');
            if (cfg.dataProva && r.cabe) html += bloco(r.folgaDias, 'dias de revisão');
            else if (!cfg.dataProva) html += bloco(r.diasRevisao, 'dias de revisão');
            numeros.innerHTML = html;
            let av = '';
            if (cfg.dataProva && !r.cabe) {
                const sug = C.sugerirHoras(cfg);
                av = `<div class="pl-aviso pl-aviso--bad">Não cabe até a prova.${sug && sug > cfg.horasPorDia ? ` <button type="button" class="pl-btn pl-btn--sm" data-acao="usar-horas" data-h="${sug}">Usar ${sug}h por dia</button>` : ''}</div>`;
            } else if (cfg.dataProva) {
                const menor = C.sugerirHoras(cfg);
                if (menor && menor < cfg.horasPorDia) av = `<div class="pl-aviso">Com ${menor}h por dia já daria tempo.</div>`;
            }
            aviso.innerHTML = av;
            $('pl-criar').disabled = false;
        } catch (e) {
            W.previa = null;
            numeros.innerHTML = '';
            aviso.innerHTML = `<div class="pl-aviso pl-aviso--bad">${esc(e.message)}</div>`;
            $('pl-criar').disabled = true;
        }
    }

    async function criarPlano() {
        if (!W.previa) return;
        if (S.plano) {
            const ok = await dialogo({ titulo: 'Substituir o plano atual?', texto: 'O plano atual e o que você marcou nele serão apagados.', confirmar: 'Substituir' });
            if (!ok) return;
        }
        const plano = C.gerarPlano(configDoAssistente());
        plano.arquivo = W.nomeArquivo || '';
        await setLocal({ planoEstudo: plano, planoRegistros: {}, planoTempo: {}, planoItemAtivo: null });
        S.plano = plano; S.registros = {}; S.tempos = {};
        S.filtro = 'tudo'; S.aba = 'crono';
        telaPlano(true);
    }

    // ------------------------------------------------------------------ tela do plano
    const fmtPct = (p) => (p == null ? '—' : Math.round(p * 100) + '%');

    function telaPlano(irParaHoje) {
        mostrar('plano');
        const p = S.plano;
        $('pl-titulo-plano').textContent = p.cargo || p.concurso || 'Plano de estudos';
        $('pl-sub').textContent = [p.cargo ? p.concurso : '', p.dataProva ? `prova em ${C.fmtBR(p.dataProva)}` : '', `${C.fmtMin(p.horasPorDia * 60)} por dia`].filter(Boolean).join(' · ');
        renderKpis();
        renderCrono();
        renderPainel();
        renderEdital();
        trocarAba(S.aba);
        if (irParaHoje) setTimeout(irParaHojeNaLista, 60);
    }

    function stats() { return C.calcularEstatisticas(S.plano, S.registros, S.tempos, C.hojeStr()); }

    function renderKpis() {
        const st = stats();
        const p = S.plano;
        const kpi = (rot, val, sub, extra) => `<div class="pl-kpi"><small>${rot}</small><b>${val}</b><span>${sub}</span>${extra || ''}</div>`;
        $('pl-kpis').innerHTML =
            kpi('Dias até a prova', st.diasParaProva == null ? '—' : st.diasParaProva, p.dataProva ? C.fmtBR(p.dataProva).slice(0, 5) : 'sem data') +
            kpi('Avanço', Math.round(st.avanco * 100) + '<i>%</i>', `${st.feitos} de ${st.itens} itens`, `<div class="pl-barra"><i style="width:${Math.round(st.avanco * 100)}%"></i></div>`) +
            kpi('Acerto', st.pctAcerto == null ? '—' : Math.round(st.pctAcerto * 100) + '<i>%</i>', `${st.questoes} questões`) +
            kpi('Tempo estudado', C.fmtMin(st.tempoMs / 60000), `${st.diasEstudados} dia${st.diasEstudados === 1 ? '' : 's'} estudado${st.diasEstudados === 1 ? '' : 's'}`);

        const hoje = C.hojeStr();
        const ultimo = p.dias.length ? p.dias[p.dias.length - 1].data : hoje;
        const atrasados = C.itensPendentesAtrasados(p, S.registros, hoje).filter((i) => i.tipo === 'estudo');
        const al = [];
        const reorg = '<button type="button" class="pl-btn pl-btn--sm" data-acao="replan">Reorganizar</button>';
        if (!p.resumo.cabe && p.dataProva) al.push(`<div class="pl-aviso pl-aviso--bad">O conteúdo não termina antes da prova. ${reorg}</div>`);
        if (atrasados.length) al.push(`<div class="pl-aviso pl-aviso--warn">${atrasados.length} pendente${atrasados.length === 1 ? '' : 's'} de dias anteriores. ${reorg}</div>`);
        if (hoje < p.inicio) al.push(`<div class="pl-aviso">O plano começa em ${C.fmtBR(p.inicio)}.</div>`);
        else if (hoje > ultimo) al.push('<div class="pl-aviso pl-aviso--ok">Período do plano encerrado.</div>');
        $('pl-alertas').innerHTML = al.join('');
    }

    function faseDoDia(d) {
        if (d.fase === 'prova') return ['pl-fase--prova', 'Prova'];
        if (d.fase === 'revisao') return ['pl-fase--revisao', 'Revisão'];
        if (d.rotulo === 'Revisão da semana') return ['pl-fase--semana', 'Revisão semanal'];
        return ['pl-fase--estudo', 'Estudo'];
    }

    function htmlItem(it, d, hoje) {
        const r = S.registros[it.id] || {};
        const mat = S.plano.materias.find((m) => m.id === it.materiaId);
        const cor = mat ? mat.cor : 'var(--faint)';
        if (it.tipo === 'prova') {
            return `<div class="item item--prova" data-id="${esc(it.id)}"><div class="item-txt"><strong>${esc(it.materia)}</strong><span>${esc(it.topico)}</span></div></div>`;
        }
        const auto = Math.round((S.tempos[it.id] || 0) / 60000);
        const totalMin = Math.round(C.tempoDoItemMs(it.id, S.registros, S.tempos) / 60000);
        const q = (r.acertos || 0) + (r.erros || 0);
        const pct = q ? Math.round(((r.acertos || 0) / q) * 100) + '%' : '—';
        const atrasado = d.data < hoje && !r.feito;
        const sub = [it.topico];
        if (it.partes > 1) sub.push(`parte ${it.parte}/${it.partes}`);
        if (it.min) sub.push(C.fmtMin(it.min));
        return `<div class="item${r.feito ? ' is-feito' : ''}${atrasado ? ' is-atrasado' : ''}" data-id="${esc(it.id)}" data-auto="${auto}">
            <label class="chk"><input type="checkbox" data-campo="feito" ${r.feito ? 'checked' : ''} aria-label="Marcar como feito"><span class="chk-box">${CHECK}</span></label>
            <div class="item-txt"><strong><span class="pl-dot" style="background:${cor}"></span>${esc(it.materia)}</strong><span title="${esc(it.detalhe || '')}">${esc(sub.join(' · '))}</span></div>
            <input class="pl-num" type="number" min="0" step="1" data-campo="min" value="${totalMin}" aria-label="Minutos estudados">
            <input class="pl-num" type="number" min="0" step="1" data-campo="acertos" value="${r.acertos == null ? '' : r.acertos}" aria-label="Acertos">
            <input class="pl-num" type="number" min="0" step="1" data-campo="erros" value="${r.erros == null ? '' : r.erros}" aria-label="Erros">
            <span class="pct">${pct}</span>
        </div>`;
    }

    function renderCrono() {
        const p = S.plano;
        const hoje = C.hojeStr();
        const cont = $('pl-lista');
        let dias = p.dias;
        if (S.filtro === 'proximos') {
            const lim = C.addDias(hoje, 14);
            dias = dias.filter((d) => d.data >= hoje && d.data <= lim);
        } else if (S.filtro === 'pendentes') {
            dias = dias.filter((d) => d.data <= hoje && d.itens.some((it) => it.tipo !== 'prova' && !(S.registros[it.id] && S.registros[it.id].feito)));
        }
        if (!dias.length) { cont.innerHTML = '<div class="pl-vazio-tab">Nada para mostrar aqui.</div>'; return; }
        cont.innerHTML = dias.map((d) => {
            const [clsFase, rotFase] = faseDoDia(d);
            const dt = C.parseData(d.data);
            const mes = MESES[new Date(dt).getUTCMonth()];
            const itens = d.itens.length ? d.itens.map((it) => htmlItem(it, d, hoje)).join('') : '<div class="pl-vazio-tab">Dia livre.</div>';
            return `<section class="dia${d.data === hoje ? ' is-hoje' : ''}" data-data="${d.data}">
                <div class="dia-lado">
                    <span class="dia-sem">${C.nomeDiaSemana(d.data).slice(0, 3)}</span>
                    <b class="dia-num">${+d.data.slice(8)}</b>
                    <span class="dia-mes">${mes}</span>
                    <span class="pl-fase ${clsFase}">${rotFase}</span>
                    ${d.data === hoje ? '<span class="pl-hoje-tag">Hoje</span>' : ''}
                </div>
                <div class="dia-itens">${itens}</div>
            </section>`;
        }).join('');
    }

    function irParaHojeNaLista() {
        const alvo = document.querySelector('.dia.is-hoje') || [...document.querySelectorAll('.dia')].find((t) => t.dataset.data >= C.hojeStr());
        if (alvo) alvo.scrollIntoView({ block: 'center', behavior: 'smooth' });
    }

    // Salva o registro de um item sem sobrescrever o que o popup possa ter gravado ao mesmo tempo.
    let filaSalvar = Promise.resolve();
    function salvarRegistro(id, patch) {
        filaSalvar = filaSalvar.then(async () => {
            const atual = (await getLocal(['planoRegistros'])).planoRegistros || {};
            atual[id] = { ...(atual[id] || {}), ...patch };
            await setLocal({ planoRegistros: atual });
            S.registros = atual;
        });
        return filaSalvar;
    }

    function aoMudarCampo(e) {
        const el = e.target;
        const campo = el.dataset && el.dataset.campo;
        const item = el.closest('.item');
        if (!campo || !item) return;
        const id = item.dataset.id;
        if (campo === 'feito') {
            item.classList.toggle('is-feito', el.checked);
            const dia = el.closest('.dia');
            if (dia && dia.dataset.data < C.hojeStr()) item.classList.toggle('is-atrasado', !el.checked);
            salvarRegistro(id, { feito: el.checked }).then(renderKpis);
            return;
        }
        const v = el.value === '' ? null : Math.max(0, Math.floor(+el.value) || 0);
        if (campo === 'min') {
            const auto = Math.round((S.tempos[id] || 0) / 60000);
            salvarRegistro(id, { ajusteMin: (v == null ? 0 : v) - auto }).then(renderKpis);
            return;
        }
        salvarRegistro(id, { [campo]: v }).then(() => {
            const r = S.registros[id] || {};
            const q = (r.acertos || 0) + (r.erros || 0);
            item.querySelector('.pct').textContent = q ? Math.round(((r.acertos || 0) / q) * 100) + '%' : '—';
            renderKpis();
            if (S.aba === 'painel') renderPainel();
        });
    }

    // ------------------------------------------------------------------ desempenho
    function renderPainel() {
        const st = stats();
        const { meta, minimo } = S.config;
        const linhas = st.porMateria.map((m) => {
            const sit = C.situacaoDesempenho(m.pct == null ? null : m.pct * 100, meta, minimo);
            const pctItens = m.itens ? Math.round((m.feitos / m.itens) * 100) : 0;
            return `<tr>
                <td><span class="pl-dot" style="background:${m.cor};display:inline-block;margin-right:10px"></span>${esc(m.nome)}</td>
                <td class="n">${m.acertos}</td><td class="n">${m.erros}</td>
                <td class="n">${fmtPct(m.pct)}</td>
                <td><span class="pl-sit pl-sit--${sit.cod}">${esc(sit.rotulo)}</span></td>
                <td class="n">${esc(C.fmtMin(m.tempoMs / 60000))}</td>
                <td>${m.feitos}/${m.itens}<span class="pl-mini-barra"><i style="width:${pctItens}%;background:${m.cor}"></i></span></td>
            </tr>`;
        }).join('');
        const sitTot = C.situacaoDesempenho(st.pctAcerto == null ? null : st.pctAcerto * 100, meta, minimo);
        $('aba-painel').innerHTML = `<div class="pl-painel">
            <div class="pl-params">
                <label>Meta de acerto <input type="number" id="pl-meta" min="1" max="100" value="${meta}"> %</label>
                <label>Atenção abaixo de <input type="number" id="pl-minimo" min="1" max="100" value="${minimo}"> %</label>
            </div>
            <table class="pl-tab">
                <thead><tr><th>Matéria</th><th class="n">Acertos</th><th class="n">Erros</th><th class="n">%</th><th>Situação</th><th class="n">Tempo</th><th>Concluído</th></tr></thead>
                <tbody>${linhas}</tbody>
                <tfoot><tr><td>Total</td><td class="n">${st.acertos}</td><td class="n">${st.erros}</td><td class="n">${fmtPct(st.pctAcerto)}</td><td><span class="pl-sit pl-sit--${sitTot.cod}">${esc(sitTot.rotulo)}</span></td><td class="n">${esc(C.fmtMin(st.tempoMs / 60000))}</td><td>${st.feitos}/${st.itens}</td></tr></tfoot>
            </table>
        </div>`;
    }

    function renderEdital() {
        const p = S.plano;
        const dado = (rot, v) => v ? `<div><small>${rot}</small>${esc(v)}</div>` : '';
        const fim = p.dias.length ? p.dias[p.dias.length - 1].data : p.inicio;
        $('aba-edital').innerHTML = `<div class="pl-painel">
            <div class="pl-edital-dados">
                ${dado('Concurso', p.concurso)}${dado('Banca', p.banca)}${dado('Cargo', p.cargo)}
                ${dado('Prova', p.dataProva ? C.fmtBR(p.dataProva) : '')}
                ${dado('Período do plano', `${C.fmtBR(p.inicio)} a ${C.fmtBR(fim)}`)}
                ${dado('Por dia', C.fmtMin(p.horasPorDia * 60))}
            </div>
            <div class="pl-lista-edital">${p.materias.map((m) => `<div><h4><span class="pl-dot" style="background:${m.cor}"></span>${esc(m.nome)}${m.questoes ? ` <small class="pl-dim">· ${m.questoes} questões</small>` : ''}${m.sugerido ? ' <span class="pl-tag">sugerido</span>' : ''}</h4><ul>${m.topicos.map((t) => `<li>${esc(t.titulo)}</li>`).join('')}</ul></div>`).join('')}</div>
        </div>`;
    }

    function trocarAba(nome) {
        S.aba = nome;
        document.querySelectorAll('.pl-abas button').forEach((b) => {
            const ativa = b.dataset.aba === nome;
            b.classList.toggle('is-ativo', ativa);
            b.setAttribute('aria-selected', ativa ? 'true' : 'false');
        });
        $('aba-crono').hidden = nome !== 'crono';
        $('aba-painel').hidden = nome !== 'painel';
        $('aba-edital').hidden = nome !== 'edital';
        if (nome === 'painel') renderPainel();
    }

    // ------------------------------------------------------------------ menu e diálogos
    function fecharMenu() {
        $('pl-menu-lista').hidden = true;
        $('pl-btn-menu').setAttribute('aria-expanded', 'false');
    }
    function alternarMenu() {
        const abrir = $('pl-menu-lista').hidden;
        $('pl-menu-lista').hidden = !abrir;
        $('pl-btn-menu').setAttribute('aria-expanded', abrir ? 'true' : 'false');
    }

    function dialogo({ titulo, texto, corpo, confirmar, cancelar }) {
        return new Promise((resolve) => {
            const box = $('pl-dialogo');
            box.innerHTML = `<div class="pl-dialogo-caixa" role="dialog" aria-modal="true" aria-label="${esc(titulo)}">
                <h3>${esc(titulo)}</h3>${texto ? `<p>${esc(texto)}</p>` : ''}<div id="pl-dialogo-corpo" style="margin-top:14px"></div>
                <div class="pl-dialogo-acoes"><button type="button" class="pl-btn pl-btn--fantasma" data-d="nao">${esc(cancelar || 'Cancelar')}</button><button type="button" class="pl-btn pl-btn--principal" data-d="sim">${esc(confirmar || 'OK')}</button></div></div>`;
            if (corpo) $('pl-dialogo-corpo').appendChild(corpo);
            box.hidden = false;
            const fechar = (v) => { box.hidden = true; box.innerHTML = ''; document.removeEventListener('keydown', aoTecla); resolve(v); };
            const aoTecla = (e) => { if (e.key === 'Escape') fechar(false); };
            document.addEventListener('keydown', aoTecla);
            box.onclick = (e) => {
                const d = e.target.dataset && e.target.dataset.d;
                if (d === 'sim') fechar(true);
                else if (d === 'nao' || e.target === box) fechar(false);
            };
            const sim = box.querySelector('[data-d="sim"]');
            if (sim) sim.focus();
        });
    }

    async function reorganizar() {
        fecharMenu();
        const corpo = document.createElement('div');
        let h = S.plano.horasPorDia;
        const padrao = [1, 2, 4, 6, 8];
        corpo.innerHTML = `<div class="pl-seg">${padrao.map((x) => `<button type="button" data-h="${x}" class="${x === h ? 'is-ativo' : ''}">${x}h</button>`).join('')}<label class="pl-seg-outro${padrao.includes(h) ? '' : ' is-ativo'}">Outro <input type="number" min="0.5" max="16" step="0.5" placeholder="10" value="${padrao.includes(h) ? '' : h}"> h</label></div>`;
        corpo.addEventListener('click', (e) => {
            const b = e.target.closest('button[data-h]');
            if (!b) return;
            h = +b.dataset.h;
            corpo.querySelectorAll('button[data-h]').forEach((c) => c.classList.toggle('is-ativo', c === b));
            corpo.querySelector('.pl-seg-outro').classList.remove('is-ativo');
            corpo.querySelector('input').value = '';
        });
        corpo.querySelector('input').addEventListener('input', (e) => {
            if (+e.target.value > 0) { h = +e.target.value; corpo.querySelectorAll('button[data-h]').forEach((c) => c.classList.remove('is-ativo')); corpo.querySelector('.pl-seg-outro').classList.add('is-ativo'); }
        });
        const ok = await dialogo({ titulo: 'Reorganizar a partir de hoje', texto: 'O que já passou e o que você marcou como feito continuam. O resto é redistribuído.', corpo, confirmar: 'Reorganizar' });
        if (!ok) return;
        try {
            const novo = C.replanejar(S.plano, S.registros, C.hojeStr(), { horasPorDia: h });
            await setLocal({ planoEstudo: novo });
            S.plano = novo;
            telaPlano(true);
        } catch (e) {
            await dialogo({ titulo: 'Não foi possível reorganizar', texto: e.message, confirmar: 'OK', cancelar: 'Fechar' });
        }
    }

    async function excluir() {
        fecharMenu();
        const ok = await dialogo({ titulo: 'Excluir o plano?', texto: 'O plano e tudo o que você marcou nele (feito, acertos, erros e tempo) serão apagados.', confirmar: 'Excluir' });
        if (!ok) return;
        await removeLocal(['planoEstudo', 'planoRegistros', 'planoTempo', 'planoItemAtivo']);
        S.plano = null; S.registros = {}; S.tempos = {};
        mostrar('vazio');
    }

    // ------------------------------------------------------------------ eventos
    function ligarEventos() {
        $('pl-vazio-comecar').addEventListener('click', abrirWizard);
        $('pl-btn-novo').addEventListener('click', abrirWizard);
        $('pl-btn-menu').addEventListener('click', (e) => { e.stopPropagation(); alternarMenu(); });
        document.addEventListener('click', (e) => { if (!e.target.closest('.pl-menu')) fecharMenu(); });
        document.addEventListener('keydown', (e) => { if (e.key === 'Escape') fecharMenu(); });
        $('pl-btn-replan').addEventListener('click', reorganizar);
        $('pl-btn-excluir').addEventListener('click', excluir);

        const arq = $('pl-arquivo');
        arq.addEventListener('change', () => processarArquivo(arq.files[0]));
        const drop = $('pl-drop');
        ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('is-sobre'); }));
        ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('is-sobre'); }));
        drop.addEventListener('drop', (e) => processarArquivo(e.dataTransfer.files[0]));

        $('pl-voltar-1').addEventListener('click', () => irPasso(1));
        $('pl-busca-cargo').addEventListener('input', filtrarCargos);
        $('pl-cargos').addEventListener('change', (e) => {
            if (e.target.name !== 'cargo') return;
            W.cargo = (W.meta.cargos.find((c) => c.nome === e.target.value)) || null;
            $('pl-cargo-manual').value = '';
            filtrarCargos();
            atualizarBotaoLer();
        });
        $('pl-cargo-manual').addEventListener('input', () => { if ($('pl-cargo-manual').value.trim()) { W.cargo = null; filtrarCargos(); } atualizarBotaoLer(); });
        $('pl-ler-conteudo').addEventListener('click', lerConteudo);

        $('pl-voltar-2').addEventListener('click', () => irPasso(2));
        $('pl-horas').addEventListener('click', (e) => {
            const b = e.target.closest('button[data-h]');
            if (!b) return;
            W.horas = +b.dataset.h; marcarHoras(); atualizarResumo();
        });
        $('pl-horas-outro').addEventListener('input', (e) => {
            const v = +e.target.value;
            if (v >= 0.5 && v <= 16) {
                W.horas = v;
                document.querySelectorAll('#pl-horas button[data-h]').forEach((b) => b.classList.remove('is-ativo'));
                $('pl-horas-outro-chip').classList.add('is-ativo');
                agendarResumo();
            }
        });
        ['pl-inicio', 'pl-data-prova-2', 'pl-rev-semanal'].forEach((id) => $(id).addEventListener('change', atualizarResumo));
        $('pl-resumo').addEventListener('click', (e) => {
            const b = e.target.closest('[data-acao="usar-horas"]');
            if (b) { W.horas = +b.dataset.h; marcarHoras(); atualizarResumo(); }
        });
        $('pl-criar').addEventListener('click', criarPlano);

        const mats = $('pl-materias');
        // Lembra quais matérias estão abertas ao redesenhar (remover um tópico não fecha tudo).
        mats.addEventListener('toggle', (e) => {
            const d = e.target.closest && e.target.closest('details.pl-mat');
            if (!d) return;
            renderMaterias.abertas = renderMaterias.abertas || new Set();
            const mi = +d.dataset.mi;
            if (d.open) renderMaterias.abertas.add(mi); else renderMaterias.abertas.delete(mi);
        }, true);
        mats.addEventListener('click', (e) => {
            const btn = e.target.closest('[data-acao], [data-peso]');
            if (!btn) return;
            const mat = btn.closest('.pl-mat');
            const mi = +mat.dataset.mi;
            if (btn.dataset.peso) {
                W.materias[mi].topicos[+btn.closest('.pl-top').dataset.ti].peso = +btn.dataset.peso;
                btn.parentElement.querySelectorAll('button').forEach((b) => b.classList.toggle('is-ativo', b === btn));
                agendarResumo();
                return;
            }
            if (btn.dataset.acao === 'rm-mat') { W.materias.splice(mi, 1); renderMaterias.abertas = new Set(); }
            else if (btn.dataset.acao === 'rm-top') W.materias[mi].topicos.splice(+btn.closest('.pl-top').dataset.ti, 1);
            W.materias = W.materias.filter((m) => m.topicos.length);
            renderMaterias(); atualizarResumo();
        });
        mats.addEventListener('change', (e) => {
            const campo = e.target.dataset.campo;
            const mat = e.target.closest('.pl-mat');
            if (!campo || !mat) return;
            const m = W.materias[+mat.dataset.mi];
            if (campo === 'nome') { m.nome = e.target.value.trim() || m.nome; mat.querySelector('.pl-mat-nome').textContent = m.nome; }
            else if (campo === 'questoes') { m.questoes = e.target.value === '' ? null : Math.max(0, +e.target.value) || null; renderMaterias(); }
            atualizarResumo();
        });

        $('pl-lista').addEventListener('change', aoMudarCampo);
        $('view-plano').addEventListener('click', (e) => { if (e.target.closest('[data-acao="replan"]')) reorganizar(); });
        document.querySelectorAll('.pl-abas button').forEach((b) => b.addEventListener('click', () => trocarAba(b.dataset.aba)));
        $('pl-filtros').addEventListener('click', (e) => {
            const b = e.target.closest('button[data-f]');
            if (!b) return;
            S.filtro = b.dataset.f;
            $('pl-filtros').querySelectorAll('button').forEach((x) => x.classList.toggle('is-ativo', x === b));
            renderCrono();
        });
        $('pl-ir-hoje').addEventListener('click', () => {
            if (S.filtro !== 'tudo') { S.filtro = 'tudo'; $('pl-filtros').querySelectorAll('button').forEach((x) => x.classList.toggle('is-ativo', x.dataset.f === 'tudo')); renderCrono(); }
            irParaHojeNaLista();
        });
        $('aba-painel').addEventListener('change', async (e) => {
            if (e.target.id !== 'pl-meta' && e.target.id !== 'pl-minimo') return;
            const meta = Math.min(100, Math.max(1, +$('pl-meta').value || 80));
            const minimo = Math.min(meta, Math.max(1, +$('pl-minimo').value || 60));
            S.config = { meta, minimo };
            await setLocal({ planoConfig: S.config });
            renderPainel(); renderKpis();
        });

        // Mudanças vindas de fora (cronômetro no background, mini tabela do popup).
        chrome.storage.onChanged.addListener((ch, area) => {
            if (area !== 'local' || !S.plano) return;
            if (ch.planoEstudo && ch.planoEstudo.newValue && ch.planoEstudo.newValue.id !== S.plano.id) { S.plano = ch.planoEstudo.newValue; telaPlano(false); return; }
            if (ch.planoEstudo && !ch.planoEstudo.newValue) { S.plano = null; mostrar('vazio'); return; }
            let mudou = false;
            if (ch.planoTempo) { S.tempos = ch.planoTempo.newValue || {}; mudou = true; }
            if (ch.planoRegistros) { S.registros = ch.planoRegistros.newValue || {}; mudou = true; }
            if (!mudou || $('view-plano').hidden) return;
            atualizarCelulasAoVivo();
            renderKpis();
            if (S.aba === 'painel') renderPainel();
        });
    }

    // Atualiza só os campos que não estão sendo digitados, sem recriar a lista.
    function atualizarCelulasAoVivo() {
        document.querySelectorAll('#pl-lista .item[data-id]').forEach((item) => {
            const id = item.dataset.id;
            const r = S.registros[id] || {};
            const foco = document.activeElement;
            const set = (campo, valor) => {
                const el = item.querySelector(`[data-campo="${campo}"]`);
                if (el && el !== foco) el.value = valor;
            };
            set('min', Math.round(C.tempoDoItemMs(id, S.registros, S.tempos) / 60000));
            set('acertos', r.acertos == null ? '' : r.acertos);
            set('erros', r.erros == null ? '' : r.erros);
            const chk = item.querySelector('[data-campo="feito"]');
            if (chk && chk !== foco) { chk.checked = !!r.feito; item.classList.toggle('is-feito', !!r.feito); }
            const q = (r.acertos || 0) + (r.erros || 0);
            const pct = item.querySelector('.pct');
            if (pct) pct.textContent = q ? Math.round(((r.acertos || 0) / q) * 100) + '%' : '—';
        });
    }

    // ------------------------------------------------------------------ início
    async function iniciar() {
        ligarEventos();
        const d = await getLocal(['planoEstudo', 'planoRegistros', 'planoTempo', 'planoConfig']);
        S.plano = d.planoEstudo || null;
        S.registros = d.planoRegistros || {};
        S.tempos = d.planoTempo || {};
        if (d.planoConfig) S.config = { ...S.config, ...d.planoConfig };
        if (location.hash === '#novo') { abrirWizard(); return; }
        if (S.plano) telaPlano(true); else mostrar('vazio');
    }
    iniciar();
})();
