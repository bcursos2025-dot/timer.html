// Monitor PCI Concursos — UI de configuração e feed.
//
// Roda em DOIS lugares com o MESMO código: na página standalone
// (pciconcursos.html, aberta em aba grande) e embutida na aba "PCI" do
// popup/dashboard principal (interface-popup/popup.html). Os dois hosts só
// precisam ter um <div id="pc-root"></div> e carregar pciconcursos.css — todo
// o resto (formulário de filtros + feed) é montado aqui via template, pra não
// duplicar HTML em dois arquivos e correr o risco deles saírem de sincronia.
//
// Lê/grava direto em chrome.storage.local (mesmas chaves usadas por
// monitor-pciconcursos.js) e manda mensagens pro background quando precisa
// disparar uma checagem ou persistir os filtros.

// Conteúdo do feed vem raspado (regex) de páginas do pciconcursos.com.br —
// texto de terceiros, não confiável. Nunca interpolar direto em innerHTML.
function pcEscapeHtml(str) {
    return String(str == null ? '' : str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

const PC_UFS = [
    'AC', 'AL', 'AM', 'AP', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MG', 'MS',
    'MT', 'PA', 'PB', 'PE', 'PI', 'PR', 'RJ', 'RN', 'RO', 'RR', 'RS', 'SC',
    'SE', 'SP', 'TO'
];

const ROTULO_TAG = {
    novo: 'Novo',
    retificacao: 'Retificado',
    prorrogacao: 'Prorrogado',
    suspensao: 'Suspenso'
};

const PC_FILTROS_PADRAO = { termos: [], ufs: [], notificar: true };
let pcFiltros = Object.assign({}, PC_FILTROS_PADRAO);

function pcTemplateHTML() {
    return `
    <div class="pc-header-row">
        <span class="pc-ultima" id="pc-ultima">—</span>
        <button type="button" id="pc-btn-verificar" class="pc-btn-primary">Verificar agora</button>
    </div>

    <div class="pc-layout">
        <div class="pc-col-principal">
            <div class="pc-card">
                <div id="pc-feed-vazio" class="pc-vazio" style="display:none;">
                    <p>Nenhuma atualização encontrada ainda.</p>
                    <p class="pc-vazio-dica">Configure seus filtros ao lado e clique em <strong>Verificar agora</strong>. As próximas checagens acontecem sozinhas em segundo plano.</p>
                </div>
                <div id="pc-feed-lista" class="pc-feed-lista"></div>
            </div>
            <a class="pc-link-externo" href="https://www.pciconcursos.com.br/concursos/" target="_blank" rel="noopener">Ver todos os concursos abertos no site do PCI Concursos →</a>
        </div>

        <div class="pc-col-lateral">
            <div class="pc-card">
                <div class="pc-card-head"><span>Cargos / palavras-chave</span></div>
                <p class="pc-hint">Ex: "Procurador Municipal". Deixe vazio pra não filtrar por cargo.</p>
                <div class="pc-chip-input-row">
                    <input type="text" id="pc-input-termo" placeholder="Digite um cargo e Enter">
                    <button type="button" id="pc-btn-add-termo" class="pc-btn-secundario">Add</button>
                </div>
                <div id="pc-chips-termos" class="pc-chips"></div>
            </div>

            <div class="pc-card" id="pc-card-estados">
                <div class="pc-card-head"><span>Estados</span></div>
                <p class="pc-hint" id="pc-uf-hint">Nenhum selecionado = todos os estados.</p>
                <div id="pc-uf-grid" class="pc-uf-grid"></div>
            </div>

            <div class="pc-card">
                <label class="pc-toggle-row">
                    <span>Avisar com notificação</span>
                    <span class="pc-switch">
                        <input type="checkbox" id="pc-chk-notificar" checked>
                        <span class="pc-switch-track"></span>
                    </span>
                </label>
            </div>
        </div>
    </div>
    `;
}

function pcFormatarQuando(ts) {
    if (!ts) return 'Nunca verificado';
    const diffMin = Math.round((Date.now() - ts) / 60000);
    if (diffMin < 1) return 'Verificado agora mesmo';
    if (diffMin < 60) return `Verificado há ${diffMin} min`;
    const diffH = Math.round(diffMin / 60);
    if (diffH < 24) return `Verificado há ${diffH}h`;
    const data = new Date(ts);
    return `Verificado em ${data.toLocaleDateString('pt-BR')} às ${data.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`;
}

function pcRenderUfGrid() {
    const grid = document.getElementById('pc-uf-grid');
    grid.innerHTML = '';
    PC_UFS.forEach(uf => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'pc-uf-opt' + (pcFiltros.ufs.includes(uf) ? ' active' : '');
        btn.textContent = uf;
        btn.addEventListener('click', () => {
            const i = pcFiltros.ufs.indexOf(uf);
            if (i === -1) pcFiltros.ufs.push(uf);
            else pcFiltros.ufs.splice(i, 1);
            pcSalvarFiltros();
            pcRenderUfGrid();
        });
        grid.appendChild(btn);
    });
}

function pcRenderChips() {
    const box = document.getElementById('pc-chips-termos');
    box.innerHTML = '';
    pcFiltros.termos.forEach((termo, idx) => {
        const chip = document.createElement('span');
        chip.className = 'pc-chip';
        const texto = document.createElement('span');
        texto.textContent = termo;
        const btnRemover = document.createElement('button');
        btnRemover.type = 'button';
        btnRemover.textContent = '×';
        btnRemover.title = 'Remover';
        btnRemover.addEventListener('click', () => {
            pcFiltros.termos.splice(idx, 1);
            pcSalvarFiltros();
            pcRenderChips();
        });
        chip.appendChild(texto);
        chip.appendChild(btnRemover);
        box.appendChild(chip);
    });
}

function pcAdicionarTermo() {
    const input = document.getElementById('pc-input-termo');
    const valor = input.value.trim();
    if (!valor) return;
    if (!pcFiltros.termos.some(t => t.toLowerCase() === valor.toLowerCase())) {
        pcFiltros.termos.push(valor);
        pcSalvarFiltros();
        pcRenderChips();
    }
    input.value = '';
    input.focus();
}

function pcSalvarFiltros() {
    chrome.runtime.sendMessage({ action: 'cbPciSalvarFiltros', filtros: pcFiltros }).catch(() => {});
}

function pcRenderFeed(feed) {
    const lista = document.getElementById('pc-feed-lista');
    const vazio = document.getElementById('pc-feed-vazio');
    lista.innerHTML = '';

    if (!feed || !feed.length) {
        vazio.style.display = 'block';
        return;
    }
    vazio.style.display = 'none';

    feed.forEach(item => {
        const a = document.createElement('a');
        a.className = 'pc-item tipo-' + item.tipo;
        // item.url vem raspado de terceiros — só aceita http(s), nunca deixa
        // um esquema tipo "javascript:" embutido no HTML virar um link vivo.
        a.href = /^https?:\/\//i.test(item.url || '') ? item.url : '#';
        a.target = '_blank';
        a.rel = 'noopener';

        const infoPartes = [item.vagas, item.cargo, item.escolaridade].filter(Boolean).map(pcEscapeHtml).join(' • ');

        a.innerHTML = `
            <div class="pc-item-top">
                <span class="pc-tag">${pcEscapeHtml(ROTULO_TAG[item.tipo] || 'Novo')}</span>
                ${item.uf ? `<span class="pc-item-uf">${pcEscapeHtml(item.uf)}</span>` : ''}
            </div>
            <div class="pc-item-org">${pcEscapeHtml(item.org || item.titulo || 'Ver detalhes')}</div>
            ${infoPartes ? `<div class="pc-item-info">${infoPartes}</div>` : ''}
            ${item.data ? `<div class="pc-item-data">Inscrições: ${pcEscapeHtml(item.data)}</div>` : ''}
        `;
        lista.appendChild(a);
    });
}

async function pcCarregarTudo() {
    const { cbPciFiltros, cbPciFeed = [], cbPciUltimaChecagem } = await chrome.storage.local.get(
        ['cbPciFiltros', 'cbPciFeed', 'cbPciUltimaChecagem']
    );
    pcFiltros = Object.assign({}, PC_FILTROS_PADRAO, cbPciFiltros || {});

    document.getElementById('pc-chk-notificar').checked = pcFiltros.notificar !== false;

    const ultimaEl = document.getElementById('pc-ultima');
    if (ultimaEl) ultimaEl.textContent = pcFormatarQuando(cbPciUltimaChecagem);

    pcRenderChips();
    pcRenderUfGrid();
    pcRenderFeed(cbPciFeed);
}

function pcInicializar() {
    const root = document.getElementById('pc-root');
    if (!root) return; // host sem o container — nada a fazer aqui
    root.innerHTML = pcTemplateHTML();

    pcCarregarTudo();

    document.getElementById('pc-btn-add-termo').addEventListener('click', pcAdicionarTermo);
    document.getElementById('pc-input-termo').addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); pcAdicionarTermo(); }
    });

    document.getElementById('pc-chk-notificar').addEventListener('change', (e) => {
        pcFiltros.notificar = e.target.checked;
        pcSalvarFiltros();
    });

    document.getElementById('pc-btn-verificar').addEventListener('click', async () => {
        const btn = document.getElementById('pc-btn-verificar');
        const textoOriginal = btn.textContent;
        btn.disabled = true;
        btn.textContent = 'Verificando...';
        try {
            await chrome.runtime.sendMessage({ action: 'cbPciChecarAgora' });
        } catch (e) {
            console.warn('[PCI Concursos] Falha ao pedir checagem:', e);
        }
        await pcCarregarTudo();
        btn.disabled = false;
        btn.textContent = textoOriginal;
    });

    // Se o background terminar uma checagem automática (alarme) enquanto essa
    // aba está aberta, atualiza a lista sozinho — sem precisar recarregar.
    chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local' && (changes.cbPciFeed || changes.cbPciUltimaChecagem)) {
            pcCarregarTudo();
        }
    });
}

document.addEventListener('DOMContentLoaded', pcInicializar);
