// ============================================================================
// MONITOR PCI CONCURSOS — checa periodicamente https://www.pciconcursos.com.br
// atrás de concursos novos e editais retificados/prorrogados, filtra pelo que
// a pessoa configurou (cargo/palavra-chave + estado) e avisa por notificação.
//
// Não existe API pública do PCI Concursos: a checagem baixa o HTML da página
// "/ultimas/" (feed único com TODO o país, já ordenado do mais recente pro
// mais antigo — inclusive editais retificados, que reaparecem lá quando são
// alterados) e extrai os itens com regex simples em cima da estrutura de
// classes do site (.na/.ca/.cc/.cd/.ce). Não usamos DOMParser porque isso
// roda dentro do Service Worker (Chrome, MV3), que não tem acesso a `document`.
//
// Carregado tanto via manifest.json (background.scripts, para o Firefox)
// quanto via importScripts() dentro de dados-config/background.js (Chrome) —
// mesmo esquema já usado para cronograma-bloqueio.js, firebase-sync.js etc.
// ============================================================================

const CB_PCI_FEED_URL = 'https://www.pciconcursos.com.br/ultimas/';
// Busca (mesmo endpoint usado pela caixa "Pesquise por nomes de cidades,
// órgãos ou instituições" do próprio site) — cobre as 26 mil+ vagas abertas
// no banco inteiro do PCI Concursos, não só as ~150 notícias mais recentes.
// Importante pra filtro por cargo: diferente da listagem, essa busca já
// indexa o texto completo de cada edital no servidor deles — então acha
// "Procurador" mesmo num edital cuja listagem só mostra "Vários Cargos"
// (o nome do cargo só aparece dentro do corpo da notícia, ver
// cbPciItemBateFiltro mais abaixo pro fallback que cobre o resto dos casos).
const CB_PCI_PESQUISA_URL = 'https://www.pciconcursos.com.br/pesquisa/';
const CB_PCI_MAX_VISTOS = 800;
const CB_PCI_MAX_FEED = 150;
const CB_PCI_ALARME = 'cb-pciconcursos-check';

// data-url + o bloco "<div class=ca><a title=... >ORG</a>" + uf (.cc) +
// vagas/cargo/escolaridade (.cd) + data de inscrição (.ce). Ver comentário
// grande acima: a estrutura foi conferida direto no site, não é suposição.
function cbPciExtrairItens(html) {
    const itens = [];
    const marcador = '<div class="na"';
    let idx = html.indexOf(marcador);

    while (idx !== -1) {
        const proximo = html.indexOf(marcador, idx + marcador.length);
        const fim = proximo === -1 ? Math.min(html.length, idx + 4000) : proximo;
        const bloco = html.slice(idx, fim);
        idx = proximo;

        const mUrl = bloco.match(/data-url="([^"]+)"/);
        const mOrg = bloco.match(/<div class="ca">\s*<a[^>]*title="([^"]*)"[^>]*>([^<]*)<\/a>/);
        if (!mUrl || !mOrg) continue; // bloco fora do padrão esperado — pula, não trava o resto

        const mUf = bloco.match(/<div class="cc">([^<]*)<\/div>/);
        const mCd = bloco.match(/<div class="cd">([\s\S]*?)<\/div>\s*<div class="ce">/);
        const mData = bloco.match(/<div class="ce">\s*<span>([^<]*)<\/span>/);

        const url = mUrl[1];
        const tituloCompleto = (mOrg[1] || '').trim();
        const org = (mOrg[2] || '').trim();
        const uf = mUf ? mUf[1].trim() : '';
        const partesCd = mCd
            ? mCd[1].replace(/<[^>]+>/g, '|').split('|').map(s => s.trim()).filter(Boolean)
            : [];
        const [vagas, cargo, escolaridade] = partesCd;
        const data = mData ? mData[1].trim() : '';

        const textoBusca = `${tituloCompleto} ${url}`.toLowerCase();
        let tipo = 'novo';
        if (textoBusca.includes('retific')) tipo = 'retificacao';
        else if (textoBusca.includes('prorroga')) tipo = 'prorrogacao';
        else if (textoBusca.includes('suspend') || textoBusca.includes('cancela')) tipo = 'suspensao';

        itens.push({
            url, org, uf,
            vagas: vagas || '',
            cargo: cargo || '',
            escolaridade: escolaridade || '',
            data,
            tipo,
            titulo: tituloCompleto
        });
    }

    return itens;
}

// Busca cada termo configurado na pessoa direto no banco de vagas abertas do
// PCI Concursos (não só nas ~150 notícias recentes) — mesma página que
// "Pesquise por nomes de cidades, órgãos ou instituições:" no site deles.
// A página de resultado usa a mesma estrutura .na/.ca/.cc/.cd/.ce da "/ultimas/",
// então cbPciExtrairItens funciona sem alteração nenhuma.
//
// Itens vindos daqui já foram encontrados pelo próprio buscador deles com
// aquele termo — inclusive quando o termo só aparece no cargo específico
// dentro de um edital "Vários Cargos" (o buscador deles indexa o texto
// completo, a listagem não). Por isso marcamos _termoGarantido: true, pra
// cbPciItemBateFiltro não precisar (e não conseguir, já que o resumo
// realmente não tem o termo) re-conferir o termo no resumo compacto.
//
// Só a primeira página de cada busca é lida (a maioria dos termos específicos
// como um cargo cabe nela; um termo muito genérico pode ter mais resultados
// que isso não pega — limitação aceita por ora).
async function cbPciBuscarPorTermos(termos) {
    const vistos = new Set();
    const todos = [];
    for (const termo of termos) {
        const termoLimpo = String(termo || '').trim();
        if (!termoLimpo) continue;
        try {
            const resp = await fetch(CB_PCI_PESQUISA_URL + encodeURIComponent(termoLimpo), { credentials: 'omit' });
            if (!resp.ok) throw new Error('HTTP ' + resp.status);
            const html = await resp.text();
            for (const item of cbPciExtrairItens(html)) {
                if (vistos.has(item.url)) continue;
                vistos.add(item.url);
                todos.push({ ...item, _termoGarantido: true });
            }
        } catch (e) {
            console.warn('[CB-PCIConcursos] Falha ao pesquisar termo "' + termoLimpo + '":', e);
        }
    }
    return todos;
}

// Cache em memória do texto completo de cada notícia já buscada nesta sessão
// do Service Worker — evita rebuscar a mesma página várias vezes (ex: a
// pessoa clica "Verificar agora" repetidas vezes, ou o mesmo item aparece
// pra mais de um termo buscado).
const cbPciTextoCompletoCache = new Map();

// Busca o texto completo da notícia (não só o resumo "Vários Cargos" que
// aparece na listagem). Necessário porque o PCI Concursos só lista os
// cargos individuais (ex: "Procurador Jurídico") dentro do corpo da
// notícia — a listagem em si mostra só um resumo genérico quando há mais
// de um cargo no mesmo edital.
async function cbPciTextoCompleto(url) {
    if (cbPciTextoCompletoCache.has(url)) return cbPciTextoCompletoCache.get(url);

    const promessa = (async () => {
        try {
            const resp = await fetch(url, { credentials: 'omit' });
            if (!resp.ok) return '';
            const html = await resp.text();
            const inicio = html.indexOf('itemprop="articleBody"');
            if (inicio === -1) return '';
            const fim = html.indexOf('</article>', inicio);
            const corpo = html.slice(inicio, fim === -1 ? html.length : fim);
            return corpo.replace(/<[^>]+>/g, ' ').toLowerCase();
        } catch (e) {
            console.warn('[CB-PCIConcursos] Falha ao buscar detalhes da notícia:', url, e);
            return '';
        }
    })();

    cbPciTextoCompletoCache.set(url, promessa);
    return promessa;
}

async function cbPciItemBateFiltro(item, filtros) {
    // Estado primeiro: é uma checagem sem rede, então descarta a maioria dos
    // itens antes de precisar buscar o texto completo de nada.
    const ufs = (filtros && filtros.ufs) || [];
    if (ufs.length && item.uf && !ufs.includes(item.uf)) return false;

    const termos = (filtros && filtros.termos) || [];
    if (!termos.length) return true;

    // Item veio da busca do próprio PCI Concursos (cbPciBuscarPorTermos): o
    // buscador deles já confirmou que o termo bate em algum lugar do edital
    // (inclusive dentro de um "Vários Cargos"), então não tem o que
    // reconferir aqui — o resumo compacto muitas vezes nem contém o termo.
    if (item._termoGarantido) return true;

    const alvoResumo = `${item.org} ${item.cargo} ${item.titulo}`.toLowerCase();
    if (termos.some(t => alvoResumo.includes(String(t).toLowerCase()))) return true;

    // Não bateu no resumo (comum quando o edital tem vários cargos e a
    // listagem só mostra "Vários Cargos") — busca o texto completo da
    // notícia antes de descartar de vez.
    const textoCompleto = await cbPciTextoCompleto(item.url);
    if (!textoCompleto) return false;
    return termos.some(t => textoCompleto.includes(String(t).toLowerCase()));
}

// Aplica cbPciItemBateFiltro numa lista inteira, com um limite de
// concorrência pras buscas de texto completo (evita disparar dezenas de
// fetches simultâneos pro mesmo site numa primeira checagem grande).
async function cbPciFiltrarAsync(itens, filtros, concorrencia = 6) {
    const resultado = new Array(itens.length);
    let proximo = 0;
    async function worker() {
        while (proximo < itens.length) {
            const i = proximo++;
            resultado[i] = (await cbPciItemBateFiltro(itens[i], filtros)) ? itens[i] : null;
        }
    }
    await Promise.all(Array.from({ length: Math.min(concorrencia, itens.length) }, worker));
    return resultado.filter(Boolean);
}

// notificationId -> url a abrir quando a pessoa clicar na notificação.
// Vive só em memória: se o Service Worker reiniciar antes do clique, o pior
// caso é o clique não abrir nada — não vale a pena persistir isso em storage.
const cbPciNotifUrls = {};

function cbPciNotificar(itens) {
    try {
        const primeiro = itens[0];
        const rotuloTipo = {
            retificacao: 'Edital retificado',
            prorrogacao: 'Inscrições prorrogadas',
            suspensao: 'Concurso suspenso/cancelado',
            novo: 'Novo concurso'
        };

        const titulo = itens.length === 1
            ? (rotuloTipo[primeiro.tipo] || rotuloTipo.novo)
            : `${itens.length} atualizações no PCI Concursos`;

        const mensagem = itens.length === 1
            ? `${primeiro.org}${primeiro.uf ? ' - ' + primeiro.uf : ''}: ${primeiro.cargo || primeiro.vagas || 'ver detalhes'}`
            : itens.slice(0, 3).map(i => i.org).join(', ') + (itens.length > 3 ? '...' : '');

        const idNotif = 'cb-pci-' + Date.now();
        chrome.notifications.create(idNotif, {
            type: 'basic',
            iconUrl: 'models/icon.png',
            title: titulo,
            message: mensagem,
            priority: 2
        });

        cbPciNotifUrls[idNotif] = itens.length === 1
            ? primeiro.url
            : chrome.runtime.getURL('pciconcursos/pciconcursos.html');
    } catch (e) {
        console.warn('[CB-PCIConcursos] Falha ao notificar:', e);
    }
}

chrome.notifications.onClicked.addListener((idNotif) => {
    const url = cbPciNotifUrls[idNotif];
    if (!url) return;
    chrome.tabs.create({ url });
    delete cbPciNotifUrls[idNotif];
});

// Faz a checagem de verdade: busca o feed, descobre o que é novo desde a
// última vez, filtra pelo que a pessoa configurou e guarda/avisa.
async function cbPciChecarAgora() {
    const {
        cbPciFiltros = {},
        cbPciVistos = [],
        cbPciChecouAlgumaVez = false
    } = await chrome.storage.local.get(['cbPciFiltros', 'cbPciVistos', 'cbPciChecouAlgumaVez']);

    // Com cargo/palavra-chave configurado, busca direto no banco de vagas
    // abertas do PCI Concursos (cbPciBuscarPorTermos) em vez de olhar só as
    // ~150 notícias recentes — assim uma vaga de "Procurador" que já está
    // aberta há semanas (e não vai aparecer de novo em "/ultimas/") é
    // encontrada mesmo assim. Sem termo configurado, não tem o que
    // pesquisar por palavra-chave: mantém o feed de notícias recentes.
    const termosConfigurados = (cbPciFiltros.termos || []).filter(Boolean);
    let itens;
    if (termosConfigurados.length) {
        itens = await cbPciBuscarPorTermos(termosConfigurados);
    } else {
        try {
            const resp = await fetch(CB_PCI_FEED_URL, { credentials: 'omit' });
            if (!resp.ok) throw new Error('HTTP ' + resp.status);
            const html = await resp.text();
            itens = cbPciExtrairItens(html);
        } catch (e) {
            console.warn('[CB-PCIConcursos] Falha ao buscar página:', e);
            return { ok: false, erro: String(e && e.message || e) };
        }
    }

    // Primeira checagem depois de instalar/ativar o monitor: não dispara
    // notificação pra cada um dos ~150 itens do feed inteiro (isso seria uma
    // enxurrada irrelevante), mas AINDA mostra na lista os itens que já
    // batem com o filtro da pessoa — senão "Verificar agora" pela primeira
    // vez parece simplesmente não achar nada, mesmo quando já existem
    // concursos abertos que combinam com o que foi buscado.
    if (!cbPciChecouAlgumaVez) {
        const correspondentes = await cbPciFiltrarAsync(itens, cbPciFiltros);
        await chrome.storage.local.set({
            cbPciVistos: itens.map(i => i.url).slice(0, CB_PCI_MAX_VISTOS),
            cbPciChecouAlgumaVez: true,
            cbPciUltimaChecagem: Date.now(),
            cbPciFeed: correspondentes.map(it => ({ ...it, encontradoEm: Date.now() })).slice(0, CB_PCI_MAX_FEED)
        });
        return { ok: true, primeiraChecagem: true, novos: 0, correspondentes: correspondentes.length };
    }

    const vistosSet = new Set(cbPciVistos);
    const novos = itens.filter(it => !vistosSet.has(it.url));

    let correspondentes = [];
    if (novos.length) {
        correspondentes = await cbPciFiltrarAsync(novos, cbPciFiltros);

        if (correspondentes.length) {
            const { cbPciFeed = [] } = await chrome.storage.local.get(['cbPciFeed']);
            const feedAtualizado = [
                ...correspondentes.map(it => ({ ...it, encontradoEm: Date.now() })),
                ...cbPciFeed
            ].slice(0, CB_PCI_MAX_FEED);
            await chrome.storage.local.set({ cbPciFeed: feedAtualizado });

            if (cbPciFiltros.notificar !== false) {
                cbPciNotificar(correspondentes);
            }
        }

        const vistosAtualizados = [...novos.map(i => i.url), ...cbPciVistos].slice(0, CB_PCI_MAX_VISTOS);
        await chrome.storage.local.set({ cbPciVistos: vistosAtualizados });
    }

    await chrome.storage.local.set({ cbPciUltimaChecagem: Date.now() });
    return { ok: true, novos: novos.length, correspondentes: correspondentes.length };
}

// cbCriarAlarmeSePreciso vem de dados-config/background.js, carregado antes
// deste arquivo (tanto na ordem do manifest.json quanto na ordem dos
// importScripts) — evita que o alarme seja recriado (e adiado) toda vez que
// o Service Worker reinicia.
cbCriarAlarmeSePreciso(CB_PCI_ALARME, { periodInMinutes: 90, delayInMinutes: 2 });

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === CB_PCI_ALARME) {
        cbPciChecarAgora();
    }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || typeof message.action !== 'string') return undefined;

    if (message.action === 'cbPciChecarAgora') {
        cbPciChecarAgora().then(sendResponse);
        return true;
    }
    if (message.action === 'cbPciSalvarFiltros') {
        chrome.storage.local.set({ cbPciFiltros: message.filtros || {} }).then(() => sendResponse({ ok: true }));
        return true;
    }
    if (message.action === 'cbPciLimparFeed') {
        chrome.storage.local.set({ cbPciFeed: [] }).then(() => sendResponse({ ok: true }));
        return true;
    }
    return undefined;
});
