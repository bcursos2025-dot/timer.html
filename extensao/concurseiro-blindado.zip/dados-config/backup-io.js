// ============================================================================
// backup-io.js — parte do backup que fala com o navegador (chrome.storage,
// chrome.downloads, chrome.permissions). Usado pelo background (backup
// automático) e pela página interface-popup/backup.html (backup manual e
// restauração). A lógica de escolher/validar/mesclar dados fica em
// backup-core.js, que é pura e tem testes.
//
// Por que o arquivo vai para a pasta Downloads: ao desinstalar a extensão o
// navegador apaga TUDO o que ela guardou (chrome.storage.local e sync). Só o que
// está fora dela sobrevive. A extensão pode escrever em Downloads pela API
// `downloads` (permissão opcional, pedida na página de backup), mas não pode
// LER o disco: restaurar exige que a pessoa escolha o arquivo uma vez.
// ============================================================================
(function (raiz) {
    'use strict';

    const Core = raiz.CBBackup;
    const K_CONFIG = 'cbBackupConfig';
    const K_ESTADO = 'cbBackupEstado';
    const LIMITE_DATA_URL = 1400000; // bytes: data: URL tem teto de ~2 MB no Chrome (base64 incha 33%)

    // ------------------------------------------------------------ utilidades
    function chamar(objeto, metodo) {
        const args = Array.prototype.slice.call(arguments, 2);
        return new Promise((resolve, reject) => {
            try {
                objeto[metodo].apply(objeto, args.concat([(r) => {
                    const e = chrome.runtime.lastError;
                    if (e) reject(new Error(e.message)); else resolve(r);
                }]));
            } catch (err) { reject(err); }
        });
    }
    const dormir = (ms) => new Promise((r) => setTimeout(r, ms));

    async function lerArea(area) {
        try { return (await chamar(chrome.storage[area], 'get', null)) || {}; } catch (e) { return {}; }
    }
    async function lerTudo() { return { local: await lerArea('local'), sync: await lerArea('sync') }; }

    async function lerConfig() {
        const r = await chamar(chrome.storage.local, 'get', [K_CONFIG]);
        return Core.normalizarConfig(r && r[K_CONFIG]);
    }
    async function salvarConfig(patch) {
        const nova = Core.normalizarConfig(Object.assign({}, await lerConfig(), patch));
        await chamar(chrome.storage.local, 'set', { [K_CONFIG]: nova });
        return nova;
    }
    async function lerEstado() {
        const r = await chamar(chrome.storage.local, 'get', [K_ESTADO]);
        return (r && r[K_ESTADO] && typeof r[K_ESTADO] === 'object') ? r[K_ESTADO] : {};
    }
    async function gravarEstado(patch) {
        const novo = Object.assign({}, await lerEstado(), patch);
        await chamar(chrome.storage.local, 'set', { [K_ESTADO]: novo });
        return novo;
    }

    function nomeDoNavegador() {
        const ua = (typeof navigator !== 'undefined' && navigator.userAgent) || '';
        let m;
        if ((m = ua.match(/Firefox\/(\d+)/))) return 'Firefox ' + m[1];
        if ((m = ua.match(/OPR\/(\d+)/))) return 'Opera ' + m[1];
        if ((m = ua.match(/Edg\/(\d+)/))) return 'Edge ' + m[1];
        if ((m = ua.match(/Chrome\/(\d+)/))) return 'Chrome ' + m[1];
        return 'desconhecido';
    }
    function versaoDaExtensao() { try { return chrome.runtime.getManifest().version; } catch (e) { return ''; } }

    // ------------------------------------------------------------ permissão
    async function temPermissaoDownloads() {
        if (!chrome.downloads) return false;
        try { return !!(await chamar(chrome.permissions, 'contains', { permissions: ['downloads'] })); } catch (e) { return false; }
    }
    /** Só funciona dentro de um clique (a página de backup chama direto do botão). */
    async function pedirPermissaoDownloads() {
        try { return !!(await chamar(chrome.permissions, 'request', { permissions: ['downloads'] })); } catch (e) { return false; }
    }

    // ------------------------------------------------------------ download
    function bytesDe(texto) { return (typeof TextEncoder !== 'undefined') ? new TextEncoder().encode(texto).length : texto.length; }

    /**
     * Firefox (página de evento) e páginas da extensão: Blob + URL.createObjectURL.
     * Service worker do Chrome/Opera: não existe createObjectURL; só arquivos pequenos passam por data: URL.
     */
    function criarUrl(texto) {
        if (typeof URL !== 'undefined' && typeof URL.createObjectURL === 'function' && typeof Blob !== 'undefined') {
            const url = URL.createObjectURL(new Blob([texto], { type: 'application/json' }));
            return { url, liberar: () => { try { URL.revokeObjectURL(url); } catch (e) { /* já liberada */ } } };
        }
        const bytes = bytesDe(texto);
        if (bytes > LIMITE_DATA_URL) {
            const e = new Error('Neste navegador o backup automático só consegue salvar arquivos pequenos (este tem ' + (bytes / 1048576).toFixed(1) + ' MB). Abra a página de Backup e use "Fazer backup agora".');
            e.codigo = 'arquivo-grande';
            throw e;
        }
        const binario = new TextEncoder().encode(texto);
        let b64 = '';
        for (let i = 0; i < binario.length; i += 0x8000) b64 += String.fromCharCode.apply(null, binario.subarray(i, i + 0x8000));
        return { url: 'data:application/json;base64,' + btoa(b64), liberar: () => {} };
    }

    async function esperarDownload(id, limiteMs) {
        const ini = Date.now();
        while (Date.now() - ini < limiteMs) {
            const lista = await chamar(chrome.downloads, 'search', { id });
            const item = lista && lista[0];
            if (item) {
                if (item.state === 'complete') return item;
                if (item.state === 'interrupted') throw new Error('O download foi interrompido (' + (item.error || 'motivo desconhecido') + ').');
            }
            await dormir(300);
        }
        throw new Error('O navegador demorou demais para salvar o arquivo.');
    }

    /** Salva o texto em Downloads/<nome> pela API downloads. */
    async function baixarComApi(texto, arq, apagarDoHistorico) {
        const { url, liberar } = criarUrl(texto);
        try {
            const id = await chamar(chrome.downloads, 'download', { url, filename: arq.nome, conflictAction: arq.conflito, saveAs: false });
            const item = await esperarDownload(id, 120000);
            const caminho = item.filename || '';
            const nomeFinal = caminho.split(/[\\/]/).pop();
            const nomePedido = arq.nome.split('/').pop();
            if (apagarDoHistorico) { try { await chamar(chrome.downloads, 'erase', { id }); } catch (e) { /* o arquivo continua no disco */ } }
            return { caminho, bytes: item.fileSize > 0 ? item.fileSize : bytesDe(texto), renomeado: !!nomeFinal && nomeFinal !== nomePedido && arq.conflito === 'overwrite' };
        } finally {
            // dá um tempo ao navegador para terminar de ler o blob
            setTimeout(liberar, 30000);
        }
    }

    /** Sem a permissão `downloads`: baixa como um link comum (cai na pasta de downloads padrão, sem subpasta). Só em páginas. */
    function salvarPorLink(texto, nome) {
        const nomeLink = 'Concurseiro-Blindado-' + nome.split('/').pop();
        const blob = new Blob([texto], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = nomeLink;
        a.style.display = 'none';
        document.body.appendChild(a);
        a.click();
        setTimeout(() => { a.remove(); URL.revokeObjectURL(url); }, 30000);
        return nomeLink;
    }

    // ------------------------------------------------------------ backup
    let emAndamento = null;

    /**
     * @param {{motivo?:'manual'|'auto'|'antes-de-restaurar', semPermissao?:boolean}} opcoes
     *   semPermissao: usa o link comum em vez da API downloads (só na página; não sabe onde o arquivo caiu)
     * @returns {Promise<{ok:boolean, pulado?:string, vazio?:boolean, erro?:string, codigo?:string, caminho?:string, bytes?:number, resumo?:object, nome?:string}>}
     */
    function fazerBackup(opcoes) {
        if (emAndamento) return emAndamento;
        emAndamento = executarBackup(opcoes || {}).finally(() => { emAndamento = null; });
        return emAndamento;
    }

    async function executarBackup(op) {
        const motivo = op.motivo || 'manual';
        const agora = Date.now();
        try {
            const cfg = await lerConfig();
            const dados = await lerTudo();
            if (Core.ehDadosVazios(dados.local, dados.sync)) {
                if (motivo !== 'antes-de-restaurar') await gravarEstado({ verificadoEm: agora });
                return { ok: false, vazio: true, erro: 'Ainda não há dados de estudo, grifos ou anotações para salvar. Nada foi escrito (assim um backup bom nunca é trocado por um vazio).' };
            }
            const backup = Core.montarBackup({
                local: dados.local, sync: dados.sync, agora, versaoExtensao: versaoDaExtensao(), navegador: nomeDoNavegador(),
                motivo, opcoes: { incluirLeis: cfg.incluirLeis }
            });
            const estado = await lerEstado();
            const hash = backup.integridade.valor;
            if (motivo === 'auto' && estado.ultimo && estado.ultimo.ok && estado.ultimo.hash === hash) {
                await gravarEstado({ verificadoEm: agora });
                return { ok: true, pulado: 'sem-mudancas' };
            }
            const texto = JSON.stringify(backup);
            const arq = Core.nomeDoArquivo(motivo, agora);
            let r;
            let nomeVisivel = arq.nome.split('/').pop();
            if (op.semPermissao) {
                nomeVisivel = salvarPorLink(texto, arq.nome);
                r = { caminho: '', bytes: bytesDe(texto), renomeado: false, porLink: true };
            } else {
                if (!(await temPermissaoDownloads())) {
                    const e = new Error('Falta permitir que a extensão salve arquivos na pasta Downloads.');
                    e.codigo = 'sem-permissao';
                    throw e;
                }
                r = await baixarComApi(texto, arq, cfg.apagarDoHistorico);
            }
            if (motivo === 'antes-de-restaurar') return { ok: true, caminho: r.caminho, bytes: r.bytes, nome: nomeVisivel };

            const patch = {
                ultimo: {
                    em: agora, ok: true, motivo, arquivo: nomeVisivel, caminho: r.caminho, bytes: r.bytes,
                    hash, resumo: backup.resumo, porLink: !!r.porLink, renomeado: !!r.renomeado
                },
                ultimaFalha: null, verificadoEm: agora
            };
            // cópia mensal: um arquivo por mês que nunca é sobrescrito
            if (!op.semPermissao && estado.ultimoMensal !== Core.mesDe(agora)) {
                try { await baixarComApi(texto, Core.nomeDoArquivo('mensal', agora), cfg.apagarDoHistorico); patch.ultimoMensal = Core.mesDe(agora); } catch (e) { /* o principal já foi salvo */ }
            }
            await gravarEstado(patch);
            return { ok: true, caminho: r.caminho, bytes: r.bytes, resumo: backup.resumo, nome: nomeVisivel, porLink: !!r.porLink, renomeado: !!r.renomeado };
        } catch (e) {
            const erro = (e && e.message) ? e.message : String(e);
            const codigo = (e && e.codigo) || '';
            if (motivo !== 'antes-de-restaurar') {
                try { await gravarEstado({ ultimaFalha: { em: agora, erro, codigo, motivo } }); } catch (e2) { /* sem como registrar */ }
            }
            return { ok: false, erro, codigo };
        }
    }

    /** Chamado pelo alarme do background. */
    async function tickAutomatico() {
        const cfg = await lerConfig();
        if (!cfg.auto) return { ok: true, pulado: 'desligado' };
        const estado = await lerEstado();
        if (!Core.estaNaHora(cfg, estado, Date.now())) return { ok: true, pulado: 'cedo' };
        return fazerBackup({ motivo: 'auto' });
    }

    // ------------------------------------------------------------ restauração
    /** Grava o plano de Core.planejarRestauracao no storage, em lotes (os grifos e desenhos podem somar vários MB). */
    async function aplicarPlano(plano) {
        const falhas = [];
        for (const area of ['local', 'sync']) {
            const entradas = Object.keys(plano.gravar[area]);
            let lote = {}; let tam = 0;
            const despejar = async () => {
                if (!Object.keys(lote).length) return;
                try { await chamar(chrome.storage[area], 'set', lote); }
                catch (e) { Object.keys(lote).forEach((k) => falhas.push({ chave: k, area, erro: e.message })); }
                lote = {}; tam = 0;
            };
            for (const chave of entradas) {
                const valor = plano.gravar[area][chave];
                const t = Core.tamanhoTexto(valor);
                // o storage.sync tem limite por item e total: grava um a um para uma falha não derrubar as outras
                if (area === 'sync' || (tam + t > 6000000 && Object.keys(lote).length)) await despejar();
                lote[chave] = valor; tam += t;
                if (area === 'sync') await despejar();
            }
            await despejar();
            if (plano.remover[area].length) {
                try { await chamar(chrome.storage[area], 'remove', plano.remover[area]); }
                catch (e) { plano.remover[area].forEach((k) => falhas.push({ chave: k, area, erro: e.message })); }
            }
        }
        return { ok: falhas.length === 0, falhas };
    }

    raiz.CBBackupIO = {
        K_CONFIG, K_ESTADO,
        lerTudo, lerConfig, salvarConfig, lerEstado, gravarEstado,
        temPermissaoDownloads, pedirPermissaoDownloads,
        fazerBackup, tickAutomatico, aplicarPlano, nomeDoNavegador, versaoDaExtensao
    };
})(typeof globalThis !== 'undefined' ? globalThis : (typeof self !== 'undefined' ? self : this));
