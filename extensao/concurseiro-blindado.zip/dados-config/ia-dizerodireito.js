// ===================== BUSCA NO BUSCADOR DIZER O DIREITO (jurisprudência comentada) =====================
//
// buscadordizerodireito.com.br é o buscador do blog "Dizer o Direito"
// (Márcio André Lopes Cavalcante) — cada julgado importante vem com tese
// firmada, categoria e um resumo curto, tudo visível de graça na própria
// página de busca (só o "informativo comentado" completo fica atrás de
// assinatura — não usamos esse conteúdo pago aqui, só a prévia pública).
// O robots.txt do site é "Allow: /" pra todo mundo, e os resultados vêm
// prontos no HTML (sem precisar rodar JavaScript), então dá pra consultar
// com fetch() igual já fazemos com planalto.gov.br em ia-planalto.js.
//
// Usado por dados-config/ia-pesquisa-externa.js (agentes em paralelo do
// toggle "Pensar").
//
// NÃO existe agente equivalente pra outros sites de jurisprudência pedidos
// junto com este, porque cada um esbarrou num problema concreto:
//   - informativos.trilhante.com.br: os resultados só aparecem depois de
//     rodar JavaScript (SPA) — um fetch() simples traz a página vazia.
//   - jurisprudencia.jt.jus.br (TST): bloqueia até o robots.txt com HTTP 403
//     (proteção anti-bot ativa) — não vale tentar contornar isso.
//   - portal.tjpr.jus.br/jurisprudencia: busca via formulário POST
//     fortemente dependente de JavaScript, sem endpoint público documentado,
//     e com trechos marcados "acesso restrito".
//   - conjur.com.br: o robots.txt do site bloqueia explicitamente bots de IA
//     ("ai-train=no", citando o ClaudeBot pelo nome) — sinal claro de que
//     não querem esse tipo de uso, então o conteúdo deles não entra aqui.

function cbHtmlParaDocDizer(html) {
  return new DOMParser().parseFromString(html, 'text/html');
}

function cbLimparTextoDizer(texto) {
  return String(texto || '').replace(/\s+/g, ' ').trim();
}

// Retorna { fonteLabel, resumo, fontes } com até 2 julgados, ou null se a
// busca não achar nada / falhar (rede fora do ar, mudança de layout etc. —
// nunca trava o chat, só segue sem essa fonte).
async function cbBuscarNoDizerODireito(pergunta) {
  try {
    const url = `https://buscadordizerodireito.com.br/jurisprudencia?palavra-chave=${encodeURIComponent(pergunta)}`;
    const resp = await fetch(url);
    if (!resp.ok) return null;
    const html = await resp.text();
    const doc = cbHtmlParaDocDizer(html);

    const cards = Array.from(doc.querySelectorAll('.card-julgado')).slice(0, 2);
    if (!cards.length) return null;

    const itens = cards.map((card) => {
      const linkEl = card.querySelector('.card-julgado__heading');
      return {
        titulo: cbLimparTextoDizer(linkEl && linkEl.textContent),
        link: (linkEl && linkEl.href) || '',
        categoria: cbLimparTextoDizer(card.querySelector('.card-julgado__categoria')?.textContent),
        resumo: cbLimparTextoDizer(card.querySelector('.card-julgado__resumo__texto')?.textContent),
        tag: cbLimparTextoDizer(card.querySelector('[class*="card-julgado__tag"]')?.textContent),
      };
    }).filter((i) => i.titulo);
    if (!itens.length) return null;

    const resumo = itens.map((i) => [
      i.tag || null,
      `Tese: ${i.titulo}`,
      i.categoria ? `Assunto: ${i.categoria}` : null,
      i.resumo ? `Resumo: ${i.resumo}` : null,
    ].filter(Boolean).join('\n')).join('\n\n---\n\n');

    const fontes = itens
      .filter((i) => i.link)
      .map((i) => ({ titulo: `Dizer o Direito — ${i.titulo.length > 70 ? `${i.titulo.slice(0, 70)}...` : i.titulo}`, url: i.link }));

    return { fonteLabel: 'Dizer o Direito (buscadordizerodireito.com.br)', resumo, fontes };
  } catch (e) {
    return null;
  }
}

window.cbBuscarNoDizerODireito = cbBuscarNoDizerODireito;
