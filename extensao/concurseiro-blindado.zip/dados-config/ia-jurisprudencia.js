// ===================== BUSCA DE JURISPRUDÊNCIA (Jurisprudências.ai) =====================
//
// Reaproveita a MESMA conta que a aba "Jus" do popup já usa (token pessoal e
// gratuito, gerado pela pessoa em jurisprudencias.ai/api-tokens, guardado em
// chrome.storage.local sob 'cbJusApiToken'). Não pede nada novo — se a
// pessoa já conectou a conta ali, o chat passa a citar jurisprudência real
// (STJ, STF etc). Se não conectou, essa busca simplesmente não acontece; a
// IA é instruída a avisar que não tem acesso a jurisprudência agora, em vez
// de inventar número de processo/REsp.
//
// AVISO DE COTA: o plano grátis do Jurisprudências.ai é de só 5 buscas/dia
// no TOTAL (compartilhado com buscas manuais na aba "Jus"), então isso só é
// chamado quando a pergunta claramente pede jurisprudência — não em toda
// pergunta de fora da extensão.

const CB_JUS_API_BASE_IA = 'https://jurisprudencias.ai/api/v1';
const CB_JUS_TOKEN_KEY_IA = 'cbJusApiToken';

const CB_PALAVRAS_JURISPRUDENCIA = [
  'jurisprudência', 'jurisprudencia', 'súmula', 'sumula',
  'informativo do stj', 'informativo de jurisprudência', 'informativo de jurisprudencia',
  'entendimento do stj', 'entendimento do stf', 'entendimento dos tribunais',
  'posição do stj', 'posicao do stj', 'posição do stf', 'posicao do stf',
  'julgado', 'acórdão', 'acordao', 'resp ', 'recurso especial', 'recurso extraordinário', 'recurso extraordinario',
  'tese firmada', 'repetitivo', 'tema stj', 'tema stf',
];

function cbEhPerguntaDeJurisprudencia(pergunta) {
  const alvo = ` ${String(pergunta || '').toLowerCase()} `;
  return CB_PALAVRAS_JURISPRUDENCIA.some((p) => alvo.includes(p));
}

function cbDetectarTribunalPergunta(pergunta) {
  const alvo = String(pergunta || '').toLowerCase();
  if (alvo.includes('stf') || alvo.includes('supremo')) return 'stf';
  if (alvo.includes('tst')) return 'tst';
  return 'stj'; // padrão
}

function cbObterTokenJurisprudencia() {
  return new Promise((resolve) => {
    chrome.storage.local.get([CB_JUS_TOKEN_KEY_IA], (res) => resolve(res[CB_JUS_TOKEN_KEY_IA] || ''));
  });
}

// ===================== CACHE DE BUSCAS (economiza a cota de 5/dia) =====================
//
// A cota do plano grátis é curta e compartilhada com a aba "Jus" do popup, e
// jurisprudência sobre um mesmo tema não muda de um dia pro outro. Então,
// antes de gastar uma busca, confere se alguém já perguntou algo parecido
// (mesmo tribunal + pergunta normalizada) e reaproveita o resultado.
// Expira em 30 dias — tempo de sobra pra não ficar reciclando jurisprudência
// desatualizada, mas suficiente pra cobrir o mesmo assunto caindo de novo em
// simulados diferentes ao longo do estudo.

const CB_JUS_CACHE_TTL_MS = 30 * 24 * 60 * 60 * 1000;

// Normaliza a pergunta pra bater cache mesmo com pequenas variações de
// redação (acentos, pontuação, maiúsculas, espaços extras).
function cbNormalizarConsultaJus(pergunta) {
  return String(pergunta || '')
    .toLowerCase()
    .normalize('NFD').replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

// Hash curto (djb2) só pra manter a chave do storage compacta.
function cbHashJus(texto) {
  let h = 5381;
  for (let i = 0; i < texto.length; i++) h = ((h * 33) ^ texto.charCodeAt(i)) >>> 0;
  return h.toString(36);
}

function cbChaveCacheJus(tribunal, pergunta) {
  const normalizada = cbNormalizarConsultaJus(pergunta);
  return `cbJusCache_${tribunal}_${cbHashJus(normalizada)}`;
}

function cbLerCacheJurisprudencia(chave) {
  return new Promise((resolve) => {
    chrome.storage.local.get([chave], (res) => {
      const cache = res[chave];
      if (cache && cache.resultado && (Date.now() - cache.buscadoEm) < CB_JUS_CACHE_TTL_MS) {
        resolve(cache.resultado);
      } else {
        resolve(null);
      }
    });
  });
}

function cbSalvarCacheJurisprudencia(chave, resultado) {
  chrome.storage.local.set({ [chave]: { resultado, buscadoEm: Date.now() } });
}

// Retorna { fonteLabel, resumo } (mesmo formato de ia-planalto/wikipedia),
// { semToken: true } se a pessoa nunca conectou a conta, ou null se a busca
// rodou mas não achou nada / falhou / cota esgotada.
async function cbBuscarJurisprudencia(pergunta) {
  const token = await cbObterTokenJurisprudencia();
  if (!token) return { semToken: true };

  const tribunal = cbDetectarTribunalPergunta(pergunta);
  const chaveCache = cbChaveCacheJus(tribunal, pergunta);

  const doCache = await cbLerCacheJurisprudencia(chaveCache);
  if (doCache) return { ...doCache, deCache: true };

  const params = new URLSearchParams({ q: pergunta, page: '0' });

  try {
    const resp = await fetch(`${CB_JUS_API_BASE_IA}/courts/${encodeURIComponent(tribunal)}/decisions?${params.toString()}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!resp.ok) return null; // 401/429/422 etc. — não trava o chat, só segue sem essa fonte
    const corpo = await resp.json().catch(() => null);
    const itens = ((corpo && corpo.data) || []).slice(0, 3);
    if (!itens.length) return null;

    const resumo = itens.map((d) => {
      const linhas = [
        d.process_number ? `Processo: ${d.process_number}` : null,
        d.adjudicating_body ? `Órgão: ${d.adjudicating_body}` : null,
        d.rapporteur ? `Relator(a): ${d.rapporteur}` : null,
        d.publication_date ? `Publicado em: ${d.publication_date}` : null,
        d.excerpt ? `Ementa/trecho: ${d.excerpt}` : null,
      ].filter(Boolean);
      return linhas.join('\n');
    }).join('\n\n---\n\n');

    const fontes = itens
      .filter((d) => d.url)
      .map((d) => ({ titulo: d.process_number || `Decisão ${tribunal.toUpperCase()}`, url: d.url }));

    const resultado = { fonteLabel: `Jurisprudências.ai — ${tribunal.toUpperCase()}`, resumo, fontes };
    cbSalvarCacheJurisprudencia(chaveCache, resultado);
    return resultado;
  } catch (e) {
    return null;
  }
}

// ===================== ACERVO PERMANENTE (informativos importados manualmente) =====================
//
// window.CBJurisprudenciaPermanente é preenchido por arquivos tipo
// ia-jurisprudencia-permanente.js (gerado a partir de um Informativo de
// Jurisprudência colado/baixado pela pessoa — ver scratchpad/parse-
// informativo.js). Zero custo de cota: é conferido ANTES da API paga do
// Jurisprudências.ai. Cresce por importação manual, nunca expira sozinho.
function cbNormalizarTextoBusca(t) {
  return String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
}

function cbBuscarNoAcervoPermanente(pergunta) {
  const acervo = window.CBJurisprudenciaPermanente;
  if (!Array.isArray(acervo) || !acervo.length) return null;

  const palavras = cbNormalizarTextoBusca(pergunta)
    .replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter((p) => p.length > 3);
  if (!palavras.length) return null;

  const candidatos = acervo.map((e) => {
    const alvo = cbNormalizarTextoBusca([e.ramo, e.tema, e.destaque, (e.legislacao || []).join(' '), (e.sumulas || []).join(' ')].join(' '));
    let score = 0;
    palavras.forEach((p) => { if (alvo.includes(p)) score += 1; });
    return { entrada: e, score };
  }).filter((c) => c.score >= 3); // exige boa sobreposição — evita citar julgado pouco relacionado

  if (!candidatos.length) return null;
  candidatos.sort((a, b) => b.score - a.score);
  const melhores = candidatos.slice(0, 2).map((c) => c.entrada);

  const resumo = melhores.map((e) => {
    const linhas = [
      `Processo: ${e.processo}${e.data ? ` (julgado em ${e.data})` : ''}`,
      e.orgao ? `Órgão: ${e.orgao}` : null,
      e.relator ? `Relator(a): ${e.relator}` : null,
      `Tema: ${e.tema}`,
      `Destaque (tese firmada): ${e.destaque}`,
      e.legislacao && e.legislacao.length ? `Legislação citada: ${e.legislacao.join('; ')}` : null,
      e.sumulas && e.sumulas.length ? `Súmulas citadas: ${e.sumulas.join('; ')}` : null,
      e.precedentesQualificados && e.precedentesQualificados.length ? `Precedentes qualificados: ${e.precedentesQualificados.join('; ')}` : null,
    ].filter(Boolean);
    return linhas.join('\n');
  }).join('\n\n---\n\n');

  const fontes = melhores.map((e) => ({ titulo: `STJ — ${e.processo}`, url: 'https://processo.stj.jus.br/jurisprudencia/externo/informativo/', interna: true }));

  return { fonteLabel: 'Acervo permanente — Informativo de Jurisprudência do STJ (importado localmente)', resumo, fontes };
}

window.cbEhPerguntaDeJurisprudencia = cbEhPerguntaDeJurisprudencia;
window.cbBuscarJurisprudencia = cbBuscarJurisprudencia;
window.cbBuscarNoAcervoPermanente = cbBuscarNoAcervoPermanente;
