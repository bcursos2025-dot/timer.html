// ===================== PERGUNTAS "DE FORA" DA EXTENSÃO: busca + verificação =====================
//
// Classifica se a pergunta é sobre os dados/funcionalidades da própria
// extensão (agenda, desempenho, tempo de estudo, leis importadas — coisas
// que já temos em dados-config/ia-contexto.js e ia-legislacao.js) ou é uma
// pergunta de conhecimento geral. Pra perguntas de fora, passa por 2 fases
// antes de responder, pra não "chutar":
//
//   1) BUSCA — procura um resumo real na Wikipédia (gratuita, sem chave, sem
//      cadastro) como base factual.
//   2) VERIFICAÇÃO — uma SEGUNDA chamada de IA, separada da primeira, cujo
//      único trabalho é conferir se o rascunho de resposta é consistente com
//      o que a busca encontrou, corrigindo ou admitindo incerteza em vez de
//      inventar quando a busca não trouxe nada confiável.
//
// Usado por interface-popup/ia-chat.js.

const CB_PALAVRAS_INTERNAS = [
  'agenda', 'cronograma', 'bloco de estudo', 'meu horário', 'meu horario',
  'desempenho', 'questõe', 'questoe', 'acerto', 'erro', 'simulado',
  'tempo de estudo', 'minha meta', 'meta diária', 'meta diaria', 'streak', 'sequência de dias', 'sequencia de dias',
  'pomodoro', 'minha matéria', 'minha materia', 'meu assunto',
  'minha lei', 'lei importada', 'esse pdf', 'esse artigo',
];

// Saudação/conversa fiada ("oi", "bom dia", "e aí, tudo bem?") e perguntas
// sobre o próprio assistente (nome, "que IA você é", data/hora de hoje) NÃO
// precisam de busca+verificação — é só o modelo respondendo direto, sem
// gastar tempo pesquisando jurisprudência/doutrina/Wikipédia pra dizer "oi"
// de volta. Usa \b só na BORDA DE ABERTURA (não .includes() como o array de
// cima), porque "oi" e "ola" são curtos demais e apareceriam dentro de
// várias palavras (histÓrIa, apOIo, viOLAr...) se fosse substring solta — e
// só conta como saudação se a mensagem inteira for curta (poucas palavras),
// pra não confundir uma pergunta de verdade que só começa com "bom dia,
// professor, ..." com um "oi" isolado.
// IMPORTANTE: sem \b de FECHAMENTO no final — em JS, \w (e portanto \b) só
// enxerga [A-Za-z0-9_], então letras acentuadas (ê, á, ã...) contam como
// "não-palavra". Um "olá" ou "você" bem no fim de uma alternativa, seguido
// de espaço/pontuação (também "não-palavra"), forma uma borda NÃO-palavra
// -> NÃO-palavra — e \b exige um lado \w — então o \b de fechamento falhava
// silenciosamente e a frase inteira deixava de casar. Já aconteceu de verdade
// com "quem é você" e "qual modelo você roda?" não sendo reconhecidos.
const CB_REGEX_SAUDACAO = /\b(oi+|e a[íi]|eae|opa|hey|hello|ol[áa]|bom dia|boa tarde|boa noite|tudo bem|como vai|beleza|obrigad[oa]|valeu|tchau|até (mais|logo))/i;
// "Modelo"/"motor"/"sistema" sozinhos são comuns em pergunta de concurso de
// verdade ("modelo de organização administrativa", "motor de busca", "modelo
// de prova da banca") — só contam como pergunta sobre o PRÓPRIO assistente
// quando aparecem perto de "você" (qualquer ordem: "qual modelo você roda",
// "você roda que motor", "que tecnologia você usa"), ou quando "você roda"/
// "você usa" aparece sozinho (isso já é specific o bastante sem precisar da
// palavra modelo/motor logo depois — cobre frases como "qual motor de IA
// você roda?", onde "motor de IA" fica entre "você" e a pergunta).
const CB_REGEX_META_ASSISTENTE = /\b(qual (é |eh )?(o )?seu nome|quem (é|eh) voc[êe]|quem te (criou|desenvolveu|fez|programou)|voc[êe]\s+(roda|usa)\b|voc[êe]\s+(é|eh)\s+(uma? )?(ia|rob[oô]|intelig[êe]ncia artificial|chatgpt|gpt|gemini)|(que|qual)\s+(modelo|motor|tecnologia|sistema)[\s\S]{0,30}voc[êe]|voc[êe][\s\S]{0,30}(que|qual)\s+(modelo|motor|tecnologia|sistema)|que dia (é|eh) hoje|qual (a )?data de hoje|que horas s[ãa]o)/i;

// Heurística simples e instantânea — não gasta chamada de IA pra classificar.
function cbClassificarPergunta(pergunta) {
  const alvo = String(pergunta || '').toLowerCase().trim();
  const poucasPalavras = alvo.split(/\s+/).filter(Boolean).length <= 6;
  if ((poucasPalavras && CB_REGEX_SAUDACAO.test(alvo)) || CB_REGEX_META_ASSISTENTE.test(alvo)) return 'interna';
  return CB_PALAVRAS_INTERNAS.some((p) => alvo.includes(p)) ? 'interna' : 'externa';
}

async function cbBuscarNaWikipedia(pergunta) {
  async function tentar(lang) {
    const urlBusca = `https://${lang}.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(pergunta)}&format=json&origin=*&srlimit=1`;
    const respBusca = await fetch(urlBusca);
    if (!respBusca.ok) return null;
    const dataBusca = await respBusca.json();
    const titulo = dataBusca && dataBusca.query && dataBusca.query.search && dataBusca.query.search[0] && dataBusca.query.search[0].title;
    if (!titulo) return null;

    const urlResumo = `https://${lang}.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(titulo)}`;
    const respResumo = await fetch(urlResumo);
    if (!respResumo.ok) return null;
    const dataResumo = await respResumo.json();
    if (!dataResumo.extract) return null;
    return {
      titulo: dataResumo.title,
      resumo: dataResumo.extract,
      url: (dataResumo.content_urls && dataResumo.content_urls.desktop && dataResumo.content_urls.desktop.page) || '',
    };
  }

  try {
    return (await tentar('pt')) || (await tentar('en'));
  } catch (e) {
    return null;
  }
}

// Ordem de prioridade pras perguntas "de fora": jurisprudência (quando a
// pergunta pede claramente um julgado/entendimento de tribunal) > texto
// oficial de lei no planalto.gov.br (quando cita um código conhecido) >
// Wikipédia (conhecimento geral, último recurso).
// onFase(texto): callback opcional pra mostrar, em tempo real, qual fonte
// está sendo tentada agora (acervo local, jurisprudência, lei, doutrina,
// Wikipédia) — em vez de um "Pesquisando..." genérico que não diz nada.
//
// Súmulas e teses do STF/STJ (ia-sumulas-teses.js, base local, sem rede nem cota) entram assim:
//   • súmula pedida pelo NÚMERO ("súmula 7 do STJ"): resposta exata, a cascata nem roda;
//   • por TEXTO ("o STJ admite reexame de provas?"): somam-se ao que a cascata achar (lei, informativo,
//     doutrina). Só substituem a Wikipédia, que é a última e mais fraca das fontes.
async function cbBuscarFonteExterna(pergunta, onFase) {
  const temSumulas = typeof window.cbBuscarSumulasETeses === 'function';

  if (temSumulas) {
    const porNumero = await window.cbBuscarSumulasETeses(pergunta, { soReferencia: true }).catch(() => null);
    if (porNumero) return porNumero;
  }

  const achado = await cbBuscarFonteExternaCascata(pergunta, onFase);
  if (!temSumulas) return achado;

  if (onFase) onFase('Consultando súmulas e teses do STF/STJ...');
  const sumulas = await window.cbBuscarSumulasETeses(pergunta).catch(() => null);
  if (!sumulas) return achado;
  if (!achado || /^Wikip/.test(achado.fonteLabel || '')) return sumulas;
  return {
    fonteLabel: `${achado.fonteLabel} + súmulas e teses do STF/STJ`,
    resumo: `${achado.resumo}\n\n---\n\n${sumulas.resumo}`,
    fontes: [...(achado.fontes || []), ...(sumulas.fontes || [])],
  };
}

async function cbBuscarFonteExternaCascata(pergunta, onFase) {
  const avisar = (msg) => { if (onFase) onFase(msg); };

  // Classificador de matéria (agente de contexto): identifica o(s) ramo(s)
  // do direito da pergunta via IA, ANTES de decidir quais arquivos abrir —
  // ver ia-classificador-materia.js. Isso cobre o caso em que a pergunta não
  // usa nenhuma palavra-chave literal (ex.: "posso ser mandado embora sem
  // motivo?" não bate com "justa causa"/"clt", mas o classificador identifica
  // "trabalhista"). Falha silenciosa: se der erro, ramos fica [] e a busca
  // por palavra-chave continua funcionando sozinha.
  const ramosClassificados = typeof window.cbClassificarMateria === 'function'
    ? await window.cbClassificarMateria(pergunta).catch(() => [])
    : [];

  // Acervo permanente primeiro: julgados importados manualmente (informativos
  // do STJ colados pela pessoa), sem custo de cota nenhum. Só usa a API paga
  // de jurisprudência ou o Planalto/Wikipédia se não achar nada bom aqui.
  avisar('Consultando acervo de jurisprudência salvo...');
  if (typeof window.cbBuscarNoAcervoPermanente === 'function') {
    const achadoPermanente = window.cbBuscarNoAcervoPermanente(pergunta);
    if (achadoPermanente) return achadoPermanente;
  }

  if (typeof window.cbEhPerguntaDeJurisprudencia === 'function' && window.cbEhPerguntaDeJurisprudencia(pergunta)) {
    avisar('Buscando jurisprudência (Jurisprudências.ai)...');
    const achadoJus = await window.cbBuscarJurisprudencia(pergunta).catch(() => null);
    if (achadoJus && achadoJus.semToken) {
      return { fonteLabel: 'aviso', resumo: 'A pessoa NÃO conectou a conta do Jurisprudências.ai (aba "Jus" do painel). Diga isso claramente e sugira conectar ali pra ter acesso a jurisprudência real — não invente número de processo, súmula ou tese.' };
    }
    if (achadoJus) return achadoJus;
    // achadoJus === null: tinha token mas a busca não achou nada / falhou / cota esgotada.
    // Cai pro Planalto/Wikipédia como segunda tentativa em vez de travar sem fonte nenhuma.
  }

  if (typeof window.cbBuscarNoPlanalto === 'function') {
    avisar('Consultando o texto oficial da lei (Planalto.gov.br)...');
    const achadoPlanalto = await window.cbBuscarNoPlanalto(pergunta).catch(() => null);
    if (achadoPlanalto) {
      const textoTrechos = achadoPlanalto.trechos
        .map((t) => `[${t.artigo || 'trecho'}]\n${t.texto}`)
        .join('\n\n');
      return { fonteLabel: `Planalto.gov.br — texto oficial (${achadoPlanalto.lei})`, resumo: textoTrechos, fontes: [{ titulo: achadoPlanalto.lei, url: achadoPlanalto.url }] };
    }
  }
  // Legislação coordenada permanente (coletâneas importadas localmente) —
  // texto de lei de verdade, mesmo não sendo o Diário Oficial/Planalto.
  // Entra antes da doutrina (opinião), depois do Planalto (fonte oficial).
  if (typeof window.cbBuscarNaLegislacaoPermanente === 'function') {
    avisar('Consultando legislação coordenada salva...');
    const achadoLegislacao = await window.cbBuscarNaLegislacaoPermanente(pergunta, ramosClassificados).catch(() => null);
    if (achadoLegislacao) {
      return { fonteLabel: achadoLegislacao.fonteLabel, resumo: `${achadoLegislacao.resumo}\n\n${achadoLegislacao.avisoTipo}`, fontes: achadoLegislacao.fontes };
    }
  }

  // Doutrina permanente (e-books de curso importados localmente) — só entra
  // se nada de mais autoritativo (jurisprudência/lei) já resolveu a pergunta.
  // Zero custo de cota também, mas é opinião de curso, não fonte oficial —
  // por isso o aviso é sempre anexado ao resumo.
  if (typeof window.cbBuscarNaDoutrinaPermanente === 'function') {
    avisar('Consultando material de doutrina salvo...');
    const achadoDoutrina = await window.cbBuscarNaDoutrinaPermanente(pergunta, ramosClassificados).catch(() => null);
    if (achadoDoutrina) {
      return { fonteLabel: achadoDoutrina.fonteLabel, resumo: `${achadoDoutrina.resumo}\n\n${achadoDoutrina.avisoTipo}`, fontes: achadoDoutrina.fontes };
    }
  }

  avisar('Pesquisando na Wikipédia...');
  const achadoWiki = await cbBuscarNaWikipedia(pergunta);
  return achadoWiki
    ? { fonteLabel: `Wikipédia ("${achadoWiki.titulo}")`, resumo: achadoWiki.resumo, fontes: [{ titulo: `Wikipédia — ${achadoWiki.titulo}`, url: achadoWiki.url }] }
    : null;
}

// Extrai números de artigo citados num texto ("Art. 12", "artigo 7º", "Art 1.043"),
// normalizados (sem "º"/"°", vírgula vira ponto) — usado pra conferir citação
// contra a fonte de busca de forma MECÂNICA, sem depender só da IA notar sozinha.
function cbExtrairNumerosArtigo(texto) {
  const re = /art(?:igo)?\.?\s*(\d+(?:[.,]\d+)?)\s*[ºª°]?/gi;
  const nums = new Set();
  let m;
  while ((m = re.exec(String(texto || '')))) nums.add(m[1].replace(',', '.'));
  return Array.from(nums);
}

// Extrai prazos/quantidades numéricas ("30 dias", "60 dias", "2 anos", "1/3",
// "10%", "5 salários mínimos") — normalizado em "numero+unidade" (ex:
// "30dias"). Existe porque o erro mais perigoso em questão de concurso não é
// só inventar um número de artigo, é inventar/trocar o PRAZO ou a QUANTIDADE
// prevista em lei mantendo o artigo certo (ex.: art. 136 CF certo, mas "60
// dias" em vez dos 30 dias reais) — isso passava batido pela checagem
// anterior, que só olhava número de artigo.
function cbExtrairPrazosEQuantidades(texto) {
  const re = /(\d+(?:[.,]\d+)?)\s*(dias?|meses|mês|anos?|horas?|minutos?|salários[- ]?mínimos?|salario[- ]?minimo|vezes|%|por\s*cento)/gi;
  const itens = new Set();
  let m;
  while ((m = re.exec(String(texto || '')))) {
    const numero = m[1].replace(',', '.');
    const unidade = m[2].toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, '');
    itens.add(`${numero}${unidade}`);
  }
  return Array.from(itens);
}

// Retorna { artigos, prazos } — cada um a lista do que foi citado no rascunho
// e NÃO aparece literalmente no texto da busca (ou null se não há como
// conferir / está tudo certo). Confere os dois tipos de invenção separados
// porque "citar o artigo certo com o prazo errado" é um erro tão grave
// quanto citar o artigo errado, e passa despercebido se só o artigo for
// conferido.
function cbChecarCitacoesContraFonte(rascunho, resumoFonte) {
  if (!resumoFonte) return null;

  const artigosCitados = cbExtrairNumerosArtigo(rascunho);
  const artigosNaFonte = new Set(cbExtrairNumerosArtigo(resumoFonte));
  const artigosNaoConfirmados = artigosCitados.filter((n) => !artigosNaFonte.has(n));

  const prazosCitados = cbExtrairPrazosEQuantidades(rascunho);
  const prazosNaFonte = new Set(cbExtrairPrazosEQuantidades(resumoFonte));
  const prazosNaoConfirmados = prazosCitados.filter((n) => !prazosNaFonte.has(n));

  if (!artigosNaoConfirmados.length && !prazosNaoConfirmados.length) return null;
  return {
    artigos: artigosNaoConfirmados.length ? artigosNaoConfirmados : null,
    prazos: prazosNaoConfirmados.length ? prazosNaoConfirmados : null,
  };
}

// ===================== MODO "PENSAR": agentes em paralelo =====================
//
// A cascata de cbBuscarFonteExterna() acima é sequencial e para no primeiro
// achado (acervo > jurisprudência > Planalto > legislação coordenada >
// doutrina > Wikípedia) — boa pra perguntas rápidas, mas deixa fontes
// complementares na mesa (ex: a lei E a doutrina sobre o mesmo tema). Quando
// a pessoa liga o toggle "Pensar", esta função dispara legislação coordenada,
// doutrina, Planalto, Dizer o Direito e jurisprudência AO MESMO TEMPO
// (Promise.all) e junta tudo que cada "agente" achar numa fonte combinada,
// em vez de usar só a primeira que respondeu.
//
// CUIDADO COM A COTA: Jurisprudências.ai libera só 5 buscas/dia no plano
// grátis (compartilhadas com a aba "Jus" — ver CB_JUS_API_BASE_IA em
// ia-jurisprudencia.js). Por isso essa busca só entra na leva paralela
// quando a pergunta claramente pede jurisprudência (mesmo teste de
// cbEhPerguntaDeJurisprudencia da cascata sequencial) E o acervo local
// (grátis, sem cota) ainda não resolveu sozinho — nunca dispara mais de UMA
// chamada à API paga por pergunta, não importa quantos "agentes" rodem. O
// buscador do Dizer o Direito (ver ia-dizerodireito.js) não tem cota
// conhecida, então roda sempre, igual doutrina e Planalto.
//
// Outros sites de jurisprudência considerados (Jusbrasil, Trilhante,
// jurisprudencia.jt.jus.br do TST, portal do TJPR, Conjur) ficaram de fora —
// cada um por um motivo concreto (API só paga, resultados só via JS, bloqueio
// anti-bot mesmo no robots.txt, formulário sem endpoint público, ou robots.txt
// que recusa bots de IA por nome). Ver comentário completo em
// ia-dizerodireito.js. Se algum desses mudar (ex: virar API paga contratada,
// ou publicarem um endpoint de busca de verdade), dá pra somar um agente novo
// aqui do mesmo jeito que os outros.
async function cbBuscarAgentesParalelos(pergunta, onFase) {
  const rotulos = { doutrina: 'doutrina', legislacao: 'legislação coordenada', lei: 'lei (Planalto)', dizer: 'Dizer o Direito', jur: 'jurisprudência', leis: 'leis importadas', sumulas: 'súmulas e teses' };
  const estado = {};
  const ordem = [];

  function marcar(chave, texto) {
    estado[chave] = texto;
    if (onFase) onFase(`Agentes em paralelo — ${ordem.map((k) => `${rotulos[k]}: ${estado[k]}`).join(' · ')}`);
  }

  // Acervo local é síncrono, local e de graça — decide ANTES de abrir a
  // chamada de rede da jurisprudência (evita gastar cota à toa quando o
  // acervo importado manualmente já resolve).
  const achadoAcervo = typeof window.cbBuscarNoAcervoPermanente === 'function'
    ? window.cbBuscarNoAcervoPermanente(pergunta)
    : null;

  // Classificador de matéria (ver ia-classificador-materia.js) — roda uma
  // vez e o resultado (ramos) é usado tanto pra legislação quanto doutrina,
  // pra não fazer duas chamadas de IA idênticas.
  const ramosClassificados = typeof window.cbClassificarMateria === 'function'
    ? await window.cbClassificarMateria(pergunta).catch(() => [])
    : [];

  ordem.push('legislacao');
  marcar('legislacao', 'pesquisando...');
  const pLegislacao = (typeof window.cbBuscarNaLegislacaoPermanente === 'function'
    ? window.cbBuscarNaLegislacaoPermanente(pergunta, ramosClassificados).catch(() => null)
    : Promise.resolve(null)
  ).then((r) => { marcar('legislacao', r ? 'achou' : 'nada'); return r; });

  ordem.push('doutrina');
  marcar('doutrina', 'pesquisando...');
  const pDoutrina = (typeof window.cbBuscarNaDoutrinaPermanente === 'function'
    ? window.cbBuscarNaDoutrinaPermanente(pergunta, ramosClassificados).catch(() => null)
    : Promise.resolve(null)
  ).then((r) => { marcar('doutrina', r ? 'achou' : 'nada'); return r; });

  // súmulas e Jurisprudência em Teses (STF/STJ): base local, instantânea e sem cota
  ordem.push('sumulas');
  marcar('sumulas', 'pesquisando...');
  const pSumulas = (typeof window.cbBuscarSumulasETeses === 'function'
    ? window.cbBuscarSumulasETeses(pergunta).catch(() => null)
    : Promise.resolve(null)
  ).then((r) => { marcar('sumulas', r ? 'achou' : 'nada'); return r; });

  ordem.push('lei');
  marcar('lei', 'pesquisando...');
  const pLei = (typeof window.cbBuscarNoPlanalto === 'function'
    ? window.cbBuscarNoPlanalto(pergunta).catch(() => null)
    : Promise.resolve(null)
  ).then((r) => { marcar('lei', r ? 'achou' : 'nada'); return r; });

  ordem.push('dizer');
  marcar('dizer', 'pesquisando...');
  const pDizer = (typeof window.cbBuscarNoDizerODireito === 'function'
    ? window.cbBuscarNoDizerODireito(pergunta).catch(() => null)
    : Promise.resolve(null)
  ).then((r) => { marcar('dizer', r ? 'achou' : 'nada'); return r; });

  // 4º agente "local" (materiais salvos): leis que a PRÓPRIA PESSOA importou
  // via PDF (ver ia-legislacao.js) — RAG local em chrome.storage, sem custo
  // de rede. Na prática, se isso já achou algo, o ia-chat.js normalmente nem
  // chega a chamar esse pipeline (usa o atalho de "temTrechoDeLei"); ainda
  // assim faz parte da leva de agentes locais pra cobrir o caso de a pessoa
  // ter mais de uma lei importada e só uma delas bater.
  ordem.push('leis');
  marcar('leis', 'pesquisando...');
  const pLeisImportadas = (typeof window.cbBuscarTrechosRelevantes === 'function'
    ? window.cbBuscarTrechosRelevantes(pergunta, 3).catch(() => [])
    : Promise.resolve([])
  ).then((r) => { marcar('leis', (r && r.length) ? 'achou' : 'nada'); return r; });

  const ehJur = typeof window.cbEhPerguntaDeJurisprudencia === 'function' && window.cbEhPerguntaDeJurisprudencia(pergunta);
  let pJur = Promise.resolve(null);
  if (ehJur && !achadoAcervo) {
    ordem.push('jur');
    marcar('jur', 'pesquisando (1 busca da cota diária)...');
    pJur = window.cbBuscarJurisprudencia(pergunta).catch(() => null)
      .then((r) => { marcar('jur', r ? (r.semToken ? 'conta não conectada' : 'achou') : 'nada'); return r; });
  }

  const [achadoLegislacao, achadoDoutrina, achadoLei, achadoDizer, achadoJur, achadoLeisImportadas, achadoSumulas] = await Promise.all([pLegislacao, pDoutrina, pLei, pDizer, pJur, pLeisImportadas, pSumulas]);

  const blocos = [];
  const fontes = [];

  if (achadoAcervo) {
    blocos.push(`[${achadoAcervo.fonteLabel}]\n${achadoAcervo.resumo}`);
    if (achadoAcervo.fontes) fontes.push(...achadoAcervo.fontes);
  } else if (achadoJur) {
    if (achadoJur.semToken) {
      blocos.push('[Jurisprudências.ai] A pessoa NÃO conectou a conta (aba "Jus" do painel) — avise isso claramente e não invente número de processo, súmula ou tese.');
    } else {
      blocos.push(`[${achadoJur.fonteLabel}]\n${achadoJur.resumo}`);
      if (achadoJur.fontes) fontes.push(...achadoJur.fontes);
    }
  }
  if (achadoSumulas) {
    blocos.push(`[${achadoSumulas.fonteLabel}]\n${achadoSumulas.resumo}`);
    if (achadoSumulas.fontes) fontes.push(...achadoSumulas.fontes);
  }
  if (achadoLei) {
    const textoTrechos = achadoLei.trechos.map((t) => `[${t.artigo || 'trecho'}]\n${t.texto}`).join('\n\n');
    blocos.push(`[Planalto.gov.br — texto oficial (${achadoLei.lei})]\n${textoTrechos}`);
    fontes.push({ titulo: achadoLei.lei, url: achadoLei.url });
  }
  if (achadoLegislacao) {
    blocos.push(`[${achadoLegislacao.fonteLabel}]\n${achadoLegislacao.resumo}\n\n${achadoLegislacao.avisoTipo}`);
    if (achadoLegislacao.fontes) fontes.push(...achadoLegislacao.fontes);
  }
  if (achadoDizer) {
    blocos.push(`[${achadoDizer.fonteLabel}]\n${achadoDizer.resumo}`);
    if (achadoDizer.fontes) fontes.push(...achadoDizer.fontes);
  }
  if (achadoDoutrina) {
    blocos.push(`[${achadoDoutrina.fonteLabel}]\n${achadoDoutrina.resumo}\n\n${achadoDoutrina.avisoTipo}`);
    if (achadoDoutrina.fontes) fontes.push(...achadoDoutrina.fontes);
  }
  if (achadoLeisImportadas && achadoLeisImportadas.length) {
    const textoTrechos = achadoLeisImportadas.map((t) => `[${t.lei}${t.artigo ? ' — ' + t.artigo : ''}]\n${t.texto}`).join('\n\n');
    blocos.push(`[Leis importadas pela pessoa]\n${textoTrechos}`);
    fontes.push(...achadoLeisImportadas.map((t) => ({ titulo: `${t.lei}${t.artigo ? ' — ' + t.artigo : ''}`, url: null, interna: true })));
  }

  if (!blocos.length) {
    if (onFase) onFase('Nada na doutrina/lei/jurisprudência — pesquisando na Wikipédia...');
    const achadoWiki = await cbBuscarNaWikipedia(pergunta);
    return achadoWiki
      ? { fonteLabel: `Wikipédia ("${achadoWiki.titulo}")`, resumo: achadoWiki.resumo, fontes: [{ titulo: `Wikipédia — ${achadoWiki.titulo}`, url: achadoWiki.url }] }
      : null;
  }

  return { fonteLabel: 'Agentes em paralelo (legislação + doutrina + lei + Dizer o Direito + jurisprudência + súmulas e teses + leis importadas)', resumo: blocos.join('\n\n---\n\n'), fontes };
}

// ===================== VOTAÇÕES DOS 3 AGENTES (Hy3 / MiMo-V2.5 / Qwen3.8-Flash) =====================
//
// Reaproveita window.cbValidarRespostaFinal (ia-provider.js) — que já dispara
// os 3 modelos da B.AI em paralelo e devolve só os que responderam — pra
// pedir um VOTO em JSON em vez de uma revisão em texto livre. Usado em dois
// pontos do pipeline (ver cbResponderComVerificacao): uma vez logo depois da
// busca, pra decidir se o material coletado é suficiente; outra vez no fim,
// pra aprovar (ou não) a resposta final antes de entregar.
//
// Extrai o primeiro bloco { ... } do texto e faz JSON.parse — tolerante a
// texto extra em volta (modelo gratuito às vezes escreve "Aqui está: {...}"
// mesmo quando instruído a responder só o JSON).
function cbExtrairJSON(texto) {
  if (!texto) return null;
  const m = String(texto).match(/\{[\s\S]*\}/);
  if (!m) return null;
  try {
    return JSON.parse(m[0]);
  } catch (e) {
    return null;
  }
}

// Pergunta aos 3 agentes se o material coletado (achado.resumo) é suficiente
// pra responder sem inventar. SEM QUÓRUM (ninguém respondeu, ou chave da B.AI
// não configurada) conta como "suficiente" — essa votação é só um reforço,
// nunca pode travar a resposta nem forçar incerteza por conta própria.
async function cbVotarSuficiencia(pergunta, resumoCombinado) {
  if (!resumoCombinado) return { suficienteMaioria: true, avisos: [] };
  const mensagens = [
    {
      role: 'system',
      content: 'Você avalia se as informações abaixo são suficientes pra responder a pergunta com segurança, sem precisar inventar número de artigo, prazo, percentual ou súmula. Responda SOMENTE em JSON válido, sem nenhum texto fora do JSON, neste formato exato: {"suficiente": true ou false, "faltando": "string curta descrevendo o que falta (ex: \'prazo exato do art. 136 CF\'), ou string vazia se suficiente"}',
    },
    { role: 'user', content: `Pergunta: ${pergunta}\n\nInformações coletadas pelos agentes de busca:\n${resumoCombinado}` },
  ];
  const respostas = typeof window.cbValidarRespostaFinal === 'function'
    ? await window.cbValidarRespostaFinal(mensagens).catch(() => [])
    : [];
  const votos = respostas.map((r) => cbExtrairJSON(r.texto)).filter(Boolean);
  if (!votos.length) return { suficienteMaioria: true, avisos: [] };

  const votosSuficiente = votos.filter((v) => v.suficiente === true).length;
  const avisos = votos.filter((v) => v.suficiente === false && v.faltando).map((v) => String(v.faltando));
  return { suficienteMaioria: votosSuficiente >= Math.ceil(votos.length / 2), avisos };
}

// Pergunta aos 3 agentes se aprovam a resposta final. Precisa ser UNÂNIME
// (todo mundo que respondeu tem que aprovar) — sem quórum conta como
// aprovado, pelo mesmo motivo da função acima (reforço, não bloqueio).
async function cbVotarAprovacaoFinal(pergunta, respostaFinal, resumoFonte) {
  const mensagens = [
    {
      role: 'system',
      content: 'Você é um revisor final. Avalie se a resposta abaixo está correta — sem número de artigo, prazo, percentual ou quantidade inventados, e sem erro conceitual grave — considerando a pergunta e a fonte de busca fornecida (se houver). Responda SOMENTE em JSON válido, sem nenhum texto fora do JSON, neste formato exato: {"aprova": true ou false, "motivo": "string curta explicando o problema, ou string vazia se aprovar"}',
    },
    { role: 'user', content: `Pergunta: ${pergunta}\n\nFonte de busca: ${resumoFonte || '(nenhuma)'}\n\nResposta final a avaliar:\n${respostaFinal}` },
  ];
  const respostas = typeof window.cbValidarRespostaFinal === 'function'
    ? await window.cbValidarRespostaFinal(mensagens).catch(() => [])
    : [];
  const votos = respostas.map((r) => cbExtrairJSON(r.texto)).filter(Boolean);
  if (!votos.length) return { unanime: true, motivos: [] };

  const unanime = votos.every((v) => v.aprova === true);
  const motivos = votos.filter((v) => v.aprova === false && v.motivo).map((v) => String(v.motivo));
  return { unanime, motivos };
}

// mensagensBase: histórico já pronto (system prompts + pergunta do usuário
// no final). Retorna { texto, fontes } — texto é a resposta final já
// verificada, fontes é [{titulo,url}] pra exibir de onde veio a informação
// (url pode ser null quando a fonte não tem link direto, ex: doutrina local).
// onFase(texto): callback opcional pra mostrar progresso na UI ("Pesquisando...", "Verificando...").
//
// usarAgentesParalelos: true quando o toggle "Pensar" está ligado. Controla
// DOIS comportamentos diferentes:
//   1) Busca: liga a cascata sequencial (para no primeiro achado) OU os
//      agentes em paralelo (junta tudo que cada fonte achar).
//   2) O SISTEMA DE 3 IAs (Hy3/MiMo-V2.5/Qwen3.8-Flash via B.AI) — votação de
//      suficiência da informação, validação da resposta e votação de
//      aprovação final — SÓ RODA quando isso é true. Sem "Pensar", mesmo no
//      modo PRO, a busca acontece mas o revisor é só a IA principal sozinha,
//      sem 3 IAs extras nem votação.
//
// achadoWeb (opcional): resultado de window.cbBuscarNaWeb quando o botão "Web" do chat está
// ligado ({ resumo, fontes, instrucao }). Entra como mais uma fonte: o texto vai junto com o das
// fontes locais, de modo que a conferência de citações e os revisores o enxergam também.
async function cbResponderComVerificacao(pergunta, mensagensBase, onFase, usarAgentesParalelos, achadoWeb) {
  let achado = usarAgentesParalelos
    ? await cbBuscarAgentesParalelos(pergunta, onFase)
    : await cbBuscarFonteExterna(pergunta, onFase);

  const temWeb = !!(achadoWeb && achadoWeb.resumo);
  if (temWeb) {
    achado = achado
      ? {
        ...achado,
        fonteLabel: `${achado.fonteLabel} + pesquisa na web`,
        resumo: `${achado.resumo}\n\n--- PESQUISA NA WEB ---\n${achadoWeb.resumo}`,
        fontes: [...(achado.fontes || []), ...(achadoWeb.fontes || [])],
      }
      : { fonteLabel: 'pesquisa na web', resumo: achadoWeb.resumo, fontes: achadoWeb.fontes || [] };
  }

  // Votação de suficiência (3 agentes) — só no modo Pensar, logo após a
  // busca: eles veem o que foi coletado e dizem se dá pra responder sem
  // chutar. Se a maioria disser que falta algo, isso vira um aviso extra no
  // prompt do rascunho, reforçando onde admitir incerteza.
  let avisoInsuficiencia = '';
  if (usarAgentesParalelos && achado) {
    if (onFase) onFase('3 agentes avaliando se as informações coletadas são suficientes...');
    const votoSuf = await cbVotarSuficiencia(pergunta, achado.resumo).catch(() => ({ suficienteMaioria: true, avisos: [] }));
    if (!votoSuf.suficienteMaioria && votoSuf.avisos.length) {
      avisoInsuficiencia = `\n\nATENÇÃO — parte dos agentes de verificação considerou a informação coletada incompleta pra: ${votoSuf.avisos.join('; ')}. Se não der pra confirmar isso com certeza no texto de busca acima, admita essa incerteza explicitamente na resposta em vez de inventar.`;
    }
  }

  const mensagensComBusca = mensagensBase.slice();
  mensagensComBusca.splice(mensagensComBusca.length - 1, 0, {
    role: 'system',
    content: (achado
      ? `RESULTADO DE BUSCA (${achado.fonteLabel}): ${achado.resumo}\n\nCITE A FONTE: quando usar uma informação do resultado acima, diga na resposta de onde ela veio, pelo nome que aparece entre colchetes (ex.: "segundo a Súmula 7 do STJ", "conforme o Tema 1.420 do STF", "de acordo com o texto da lei no Planalto", "segundo o material de doutrina salvo"). Não cite fonte que não esteja no resultado.\n\nUse isso como base, se for relevante pra pergunta. Se for texto oficial de lei (Planalto/legislação coordenada), cite o artigo exato — só cite número de artigo/parágrafo se ele estiver literalmente no texto acima. Quando a resposta envolver PRAZO, QUANTIDADE, PERCENTUAL ou VALOR previsto em lei/CF (ex.: "30 dias", "1/3", "10%"), REPRODUZA o número literalmente como aparece no texto de busca acima, entre aspas se possível — não arredonde, não dobre, não "lembre de cabeça" um número parecido. Se o número exato não estiver literalmente no texto de busca, diga que não tem certeza do valor exato em vez de arriscar. Se a fonte não for relevante pra pergunta, ignore e responda com cautela.`
      : 'A busca não encontrou nada confiável sobre esse assunto (a lei/tema pode não estar na base conectada). NÃO cite número de artigo, parágrafo, lei, súmula, prazo ou quantidade específicos de memória — se a pergunta pedir isso, diga que não tem certeza do número exato em vez de arriscar um chute.'
    ) + avisoInsuficiencia + (temWeb && achadoWeb.instrucao ? `\n\n${achadoWeb.instrucao}` : ''),
  });

  if (onFase) onFase(achado ? 'Elaborando resposta com base no que encontrei...' : 'Elaborando resposta (nenhuma fonte confiável encontrada)...');
  const rascunho = await window.cbGerarRespostaIA(mensagensComBusca);

  // Checagem mecânica (regex, sem IA) ANTES de mandar pro revisor — se o
  // rascunho citar um artigo OU um prazo/quantidade que não está literalmente
  // na busca, isso vira um aviso explícito no prompt de verificação, em vez
  // de confiar que o modelo vai notar sozinho (na prática, modelos gratuitos
  // pequenos nem sempre notam — já rolou de citar o artigo certo com o prazo
  // errado, ex.: "art. 136 CF... 60 dias" em vez dos 30 dias reais).
  const naoConfirmados = achado ? cbChecarCitacoesContraFonte(rascunho, achado.resumo) : null;

  if (onFase) onFase('Conferindo citações e revisando a resposta...');
  const avisosPartes = [];
  if (naoConfirmados && naoConfirmados.artigos) {
    avisosPartes.push(`o(s) artigo(s) ${naoConfirmados.artigos.join(', ')}`);
  }
  if (naoConfirmados && naoConfirmados.prazos) {
    avisosPartes.push(`o(s) prazo(s)/quantidade(s) ${naoConfirmados.prazos.join(', ')}`);
  }
  const avisoCitacao = avisosPartes.length
    ? `\n\nATENÇÃO — conferência automática: o rascunho cita ${avisosPartes.join(' e ')}, mas isso NÃO aparece literalmente no resultado de busca acima. Isso é um forte indício de invenção (inclusive de TROCA de prazo/quantidade mantendo o artigo certo — ex.: dobrar ou arredondar um número de dias). Corrija para o valor exato SE ele estiver no resultado de busca, reproduzindo-o literalmente, ou remova a citação e admita incerteza — não confie no número do rascunho.`
    : '';

  const mensagensVerificacao = [
    {
      role: 'system',
      content: 'Você é um revisor cético. Sua ÚNICA tarefa é conferir se a resposta abaixo é consistente com o resultado de busca fornecido (quando houver) e com fatos amplamente conhecidos. Preste atenção especial a números de artigo, lei, súmula ou processo citados na resposta, E TAMBÉM a qualquer prazo, quantidade, percentual ou valor citado (ex.: "30 dias", "1/3", "10%"): se o resultado de busca NÃO contiver esse número exato, trate a citação como não confirmada — remova a citação específica ou troque por uma ressalva de incerteza, mesmo que o resto da resposta pareça plausível. É um erro grave manter o artigo certo mas trocar o prazo/quantidade (ex.: dobrar "30 dias" para "60 dias") — confira os dois separadamente. Nunca deixe passar uma citação específica que não esteja literalmente no resultado de busca. Se a resposta estiver correta e todas as citações baterem com a busca, apenas devolva ela, possivelmente polida. Responda só com o texto final pra pessoa, em português, sem comentar seu processo de revisão nem mencionar que você é um "revisor".',
    },
    {
      role: 'user',
      content: `Pergunta original: ${pergunta}\n\nResultado de busca: ${achado ? achado.resumo : '(nenhum resultado confiável encontrado)'}\n\nRascunho de resposta a revisar:\n${rascunho}${avisoCitacao}`,
    },
  ];

  const fontes = (achado && achado.fontes) || [];

  // A partir daqui, o sistema de 3 IAs (validação + votação final) SÓ roda
  // com "Pensar" ligado. Sem Pensar, vai direto pro revisor único de sempre.
  if (!usarAgentesParalelos) {
    try {
      const respostaFinal = await window.cbGerarRespostaIA(mensagensVerificacao);
      return { texto: respostaFinal || rascunho, fontes };
    } catch (e) {
      return { texto: rascunho, fontes };
    }
  }

  // Validação com modelos de OUTRAS famílias (Hy3 / MiMo-V2.5 / Qwen3.8-
  // Flash, via B.AI), disparados TODOS AO MESMO TEMPO: cada um dá uma
  // segunda opinião independente de quem gerou o rascunho, então tem menos
  // chance de repetir o MESMO erro. Se algum dos 3 falhar (rate limit,
  // etc.), segue só com os que responderam.
  if (onFase) onFase('Validando a resposta com 3 IAs em paralelo (Hy3/MiMo-V2.5/Qwen3.8-Flash)...');
  const validacoes = await window.cbValidarRespostaFinal(mensagensVerificacao).catch(() => []);

  let respostaFinalTexto = null;
  if (validacoes.length) {
    // Entrega o rascunho + a busca + as opiniões de validação pra IA
    // principal comparar tudo e escrever UMA resposta final — em vez de
    // simplesmente devolver a opinião de um validador crua, ela "pensa"
    // sobre as 3 antes de decidir.
    const blocoValidacoes = validacoes.map((v) => `[Validação — ${v.modelo}]\n${v.texto}`).join('\n\n---\n\n');
    const mensagensSintese = [
      {
        role: 'system',
        content: 'Você recebe um rascunho de resposta, o resultado de busca que o embasou (se houver) e uma ou mais respostas de VALIDAÇÃO independentes, geradas por outras IAs sobre a MESMA pergunta. Sua tarefa é produzir UMA resposta final para a pessoa, consolidando tudo isso. Onde as validações concordam entre si e com o resultado de busca, isso reforça confiança. Onde divergem (principalmente número de artigo, prazo, quantidade ou percentual), prefira o valor que aparecer literalmente no resultado de busca; se nenhuma bater com a busca ou não houver busca, prefira a versão que mais validações confirmarem, e se ainda assim ficar incerto, admita a incerteza em vez de escolher arbitrariamente. NUNCA mencione que você está comparando respostas de outras IAs, nunca cite "validação 1/2/3" ou nomes de modelo — entregue o texto final como se fosse uma resposta só seguida, natural, em português, sem comentar esse processo.',
      },
      {
        role: 'user',
        content: `Pergunta original: ${pergunta}\n\nResultado de busca: ${achado ? achado.resumo : '(nenhum resultado confiável encontrado)'}\n\nRascunho original:\n${rascunho}${avisoCitacao}\n\nRespostas de validação independentes:\n${blocoValidacoes}`,
      },
    ];
    try {
      respostaFinalTexto = (await window.cbGerarRespostaIA(mensagensSintese)) || rascunho;
    } catch (e) {
      respostaFinalTexto = validacoes[0].texto;
    }
  } else {
    try {
      respostaFinalTexto = (await window.cbGerarRespostaIA(mensagensVerificacao)) || rascunho;
    } catch (e) {
      respostaFinalTexto = rascunho;
    }
  }

  // Votação final dos 3 agentes: aprovam a resposta que está pronta pra ir
  // pro usuário? Se não for unânime, uma rodada de correção considerando as
  // objeções, revota uma vez, e se AINDA não for unânime, deixa isso
  // explícito no texto final em vez de entregar como se estivesse tudo certo.
  if (onFase) onFase('3 agentes votando se aprovam a resposta final...');
  let votoAprov = await cbVotarAprovacaoFinal(pergunta, respostaFinalTexto, achado ? achado.resumo : '').catch(() => ({ unanime: true, motivos: [] }));

  if (!votoAprov.unanime) {
    if (onFase) onFase('Nem todos os agentes aprovaram — revisando mais uma vez...');
    const mensagensRetrabalho = [
      {
        role: 'system',
        content: 'Alguns agentes de verificação não aprovaram a resposta abaixo pelos motivos indicados. Corrija a resposta considerando essas objeções (se forem válidas), mantendo apenas o que está confirmado pela fonte de busca fornecida — remova ou troque por ressalva de incerteza qualquer dado que não esteja confirmado. Responda só com o texto final pra pessoa, em português, sem comentar esse processo de revisão.',
      },
      {
        role: 'user',
        content: `Pergunta: ${pergunta}\n\nFonte de busca: ${achado ? achado.resumo : '(nenhuma)'}\n\nResposta a corrigir:\n${respostaFinalTexto}\n\nObjeções dos agentes de verificação:\n${votoAprov.motivos.join('\n') || '(sem motivo detalhado)'}`,
      },
    ];
    try {
      const respostaCorrigida = await window.cbGerarRespostaIA(mensagensRetrabalho);
      if (respostaCorrigida) respostaFinalTexto = respostaCorrigida;
    } catch (e) {
      // correção falhou — segue com a resposta anterior.
    }

    const votoAprov2 = await cbVotarAprovacaoFinal(pergunta, respostaFinalTexto, achado ? achado.resumo : '').catch(() => ({ unanime: true, motivos: [] }));
    if (!votoAprov2.unanime && votoAprov2.motivos.length) {
      respostaFinalTexto += `\n\n⚠️ *Nem todos os agentes de verificação concordaram totalmente com esta resposta. Ponto(s) de menor certeza: ${votoAprov2.motivos.join('; ')}.*`;
    }
  }

  return { texto: respostaFinalTexto, fontes };
}

window.cbClassificarPergunta = cbClassificarPergunta;
window.cbBuscarNaWikipedia = cbBuscarNaWikipedia;
window.cbBuscarAgentesParalelos = cbBuscarAgentesParalelos;
window.cbResponderComVerificacao = cbResponderComVerificacao;
