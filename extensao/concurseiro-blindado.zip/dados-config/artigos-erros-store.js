// ============================================================================
// artigos-erros-store.js — Armazenamento dos "artigos dos meus erros", usado
// pelas três pontas do sistema: o QConcursos grava PENDENTES (artigos citados
// nos comentários de uma questão errada), o Planalto deixa a pessoa CONFIRMAR e
// SALVAR (vira item de REVISÃO, com texto do artigo e agenda), e o popup mostra
// o que revisar hoje. Tudo em chrome.storage.local, que as duas páginas e o
// popup compartilham — por isso o painel do Planalto atualiza na hora quando o
// QConcursos grava algo (storage.onChanged).
//
// Chaves:
//   cbArtigosPendentes — [{ id, lei, artigo, sufixo, detalhe, inferida, origens[], criadoEm }]
//   cbArtigosRevisao   — [{ id, lei, artigo, sufixo, detalhe, texto, url, origens[], criadoEm, srs, manual }]
//   cbArtigosErroAtivo — boolean (padrão: ligado). Desliga a captura automática no QConcursos.
//
// origem = { questaoId, questaoUrl, materia, assunto, em }
// id     = 'lei:artigo' (+ sufixo). Pendente sem lei descoberta tem id '?:279'.
// ============================================================================
(function (raiz) {
    'use strict';

    const Ref = (typeof require !== 'undefined' && typeof module !== 'undefined') ? require('./ref-artigos.js') : raiz.CBRefArtigos;
    const Srs = (typeof require !== 'undefined' && typeof module !== 'undefined') ? require('./revisao-espacada.js') : raiz.CBRevisaoEspacada;

    const K_PEND = 'cbArtigosPendentes';
    const K_REV = 'cbArtigosRevisao';
    const K_ATIVO = 'cbArtigosErroAtivo';
    const MAX_PENDENTES = 200;
    const MAX_ORIGENS = 12;

    function area() { return chrome.storage.local; }

    function ler() {
        return new Promise((resolve) => {
            area().get([K_PEND, K_REV, K_ATIVO], (res) => {
                const r = res || {};
                resolve({
                    pendentes: Array.isArray(r[K_PEND]) ? r[K_PEND] : [],
                    revisao: Array.isArray(r[K_REV]) ? r[K_REV] : [],
                    ativo: r[K_ATIVO] !== false
                });
            });
        });
    }

    // ler + alterar + gravar de uma vez (as pontas são páginas diferentes; não há trava, mas a janela é de milissegundos)
    function modificar(fn) {
        return new Promise((resolve) => {
            area().get([K_PEND, K_REV], (res) => {
                const r = res || {};
                const estado = {
                    pendentes: Array.isArray(r[K_PEND]) ? r[K_PEND] : [],
                    revisao: Array.isArray(r[K_REV]) ? r[K_REV] : []
                };
                const resultado = fn(estado);
                area().set({ [K_PEND]: estado.pendentes, [K_REV]: estado.revisao }, () => resolve(resultado));
            });
        });
    }

    function idDe(lei, artigo, sufixo) { return (lei || '?') + ':' + artigo + (sufixo || ''); }

    function juntarOrigem(item, origem) {
        if (!origem || !origem.questaoId) return false;
        item.origens = Array.isArray(item.origens) ? item.origens : [];
        if (item.origens.some((o) => o.questaoId === origem.questaoId)) return false;
        item.origens.push(origem);
        if (item.origens.length > MAX_ORIGENS) item.origens = item.origens.slice(-MAX_ORIGENS);
        return true;
    }

    // refs vindas de CBRefArtigos.extrairReferencias; contexto = { questaoId, questaoUrl, materia, assunto }
    function adicionarPendentes(refs, contexto, agora) {
        const t = agora || Date.now();
        const ctx = contexto || {};
        const origem = { questaoId: ctx.questaoId || null, questaoUrl: ctx.questaoUrl || null, materia: ctx.materia || '', assunto: ctx.assunto || '', em: t };
        return modificar((estado) => {
            const saida = { novas: [], reforcadas: [], jaPendentes: [] };
            (refs || []).forEach((ref) => {
                const id = idDe(ref.lei, ref.artigo, ref.sufixo);
                const salvo = estado.revisao.find((x) => x.id === id);
                if (salvo) {
                    // errou de novo uma questão sobre um artigo que já estava salvo: a memória falhou, reinicia a caixa
                    if (juntarOrigem(salvo, origem)) {
                        salvo.srs = Srs.reiniciar(salvo.srs || Srs.novoCartao(t), t);
                        saida.reforcadas.push(salvo);
                    }
                    return;
                }
                const pend = estado.pendentes.find((x) => x.id === id);
                if (pend) {
                    if (juntarOrigem(pend, origem)) saida.jaPendentes.push(pend);
                    if (!pend.detalhe && ref.detalhe) pend.detalhe = ref.detalhe;
                    return;
                }
                const novo = { id, lei: ref.lei || null, artigo: ref.artigo, sufixo: ref.sufixo || '', detalhe: ref.detalhe || '', inferida: !!ref.inferida, origens: [], criadoEm: t };
                juntarOrigem(novo, origem);
                estado.pendentes.push(novo);
                saida.novas.push(novo);
            });
            if (estado.pendentes.length > MAX_PENDENTES) estado.pendentes = estado.pendentes.slice(-MAX_PENDENTES);
            return saida;
        });
    }

    // a pessoa disse "esta referência é desta lei" (pendente que veio sem lei)
    function atribuirLei(idPendente, lei) {
        return modificar((estado) => {
            const i = estado.pendentes.findIndex((x) => x.id === idPendente);
            if (i < 0) return null;
            const item = estado.pendentes[i];
            const novoId = idDe(lei, item.artigo, item.sufixo);
            const existente = estado.pendentes.find((x) => x.id === novoId);
            estado.pendentes.splice(i, 1);
            if (existente) {
                (item.origens || []).forEach((o) => juntarOrigem(existente, o));
                return existente;
            }
            item.lei = lei;
            item.id = novoId;
            item.inferida = false;
            estado.pendentes.push(item);
            return item;
        });
    }

    function descartarPendente(id) {
        return modificar((estado) => {
            const antes = estado.pendentes.length;
            estado.pendentes = estado.pendentes.filter((x) => x.id !== id);
            return estado.pendentes.length !== antes;
        });
    }

    // Confirmar: o pendente (ou um artigo digitado à mão) vira item de revisão, com o texto da lei
    // capturado na página do Planalto. dados = { id?, lei, artigo, sufixo, detalhe, texto, url, manual }
    function salvarParaRevisao(dados, agora) {
        const t = agora || Date.now();
        return modificar((estado) => {
            const lei = dados.lei;
            const id = idDe(lei, dados.artigo, dados.sufixo);
            const pend = estado.pendentes.find((x) => x.id === (dados.id || id)) || estado.pendentes.find((x) => x.id === id);
            estado.pendentes = estado.pendentes.filter((x) => x !== pend);
            let item = estado.revisao.find((x) => x.id === id);
            if (item) {
                // já estava salvo: só atualiza o texto e junta as origens, sem mexer na agenda
                if (dados.texto) item.texto = dados.texto;
                if (pend) (pend.origens || []).forEach((o) => juntarOrigem(item, o));
                return item;
            }
            item = {
                id, lei, artigo: dados.artigo, sufixo: dados.sufixo || '',
                detalhe: dados.detalhe || (pend && pend.detalhe) || '',
                texto: dados.texto || '',
                url: dados.url || Ref.urlDaLei(lei, dados.artigo, dados.sufixo) || null,
                origens: pend ? (pend.origens || []).slice() : [],
                criadoEm: t,
                srs: Srs.novoCartao(t),
                manual: !!dados.manual
            };
            estado.revisao.push(item);
            return item;
        });
    }

    function removerRevisao(id) {
        return modificar((estado) => {
            const antes = estado.revisao.length;
            estado.revisao = estado.revisao.filter((x) => x.id !== id);
            return estado.revisao.length !== antes;
        });
    }

    function avaliarRevisao(id, lembrou, agora) {
        const t = agora || Date.now();
        return modificar((estado) => {
            const item = estado.revisao.find((x) => x.id === id);
            if (!item) return null;
            item.srs = Srs.avaliar(item.srs || Srs.novoCartao(t), !!lembrou, t);
            return item;
        });
    }

    function definirAtivo(ligado) {
        return new Promise((resolve) => area().set({ [K_ATIVO]: !!ligado }, () => resolve(!!ligado)));
    }

    const API = { K_PEND, K_REV, K_ATIVO, ler, adicionarPendentes, atribuirLei, descartarPendente, salvarParaRevisao, removerRevisao, avaliarRevisao, definirAtivo, idDe };
    if (typeof module !== 'undefined' && module.exports) module.exports = API;
    raiz.CBArtigosStore = API;
})(typeof window !== 'undefined' ? window : globalThis);
