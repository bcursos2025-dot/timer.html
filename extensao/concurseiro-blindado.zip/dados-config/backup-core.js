// ============================================================================
// backup-core.js — parte PURA do sistema de backup (sem chrome.*, sem DOM).
// Roda no Node (testes em dados-config/testes/backup-core.test.js), no popup,
// na página interface-popup/backup.html e no background (evento/service worker).
//
// O que ele faz:
//   • decide QUAIS chaves do storage entram no arquivo de backup (e por que as
//     outras ficam de fora: licença, chaves de API, caches, estado temporário);
//   • monta o arquivo (formato versionado, com resumo e checagem de integridade);
//   • valida um arquivo importado antes de tocar em qualquer dado;
//   • planeja a restauração: "substituir" ou "mesclar" sem apagar dado mais
//     novo às cegas (devolve um plano; quem grava é o backup-io.js).
//
// Decisões que valem lembrar:
//   • A LICENÇA PRO NÃO entra no backup (cbLicenseCode, cbLicensePayload,
//     cbPromoLifetimePro). Se entrasse, bastaria passar o arquivo para outra
//     pessoa para repassar o Pro. Como o ID da instalação (cbInstallId) entra
//     no backup e é restaurado, o código de licença que a pessoa já recebeu
//     continua valendo: é só colar de novo em Configurações → Plano e Licença.
//     A restauração ignora essas chaves mesmo que alguém as coloque num arquivo
//     editado à mão.
//   • Chaves de API de IA (cbChavesIA, cbGeminiApiKey, cbBaiApiKey, token do JUS)
//     ficam de fora: são credenciais de terceiros e o arquivo é texto puro.
//   • Caches (Corpus927, texto de lei do Planalto, jurisprudência, feed do PCI) e
//     estado temporário (sessão em andamento, pomodoro, flags de instalação) não
//     fazem sentido restaurados e podem até bagunçar o cronômetro.
//   • Qualquer chave NOVA que a extensão passar a usar entra por padrão (a lista
//     é de exclusão, não de inclusão): melhor um backup a mais do que perder dado.
// ============================================================================
(function (raiz) {
    'use strict';

    const FORMATO = 'concurseiro-blindado-backup';
    const ESQUEMA = 1;
    const PASTA = 'Concurseiro-Blindado-Backup';
    const DIAS = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sab'];

    const GRUPOS = {
        planalto: 'Planalto (grifos, comentários, desenhos, erros por artigo)',
        estudo: 'Estudo e questões',
        planejamento: 'Cronograma, metas e anotações',
        ia: 'Conversas com o assistente',
        identidade: 'Identificação desta instalação',
        ajustes: 'Configurações'
    };

    // ---------------------------------------------------------------- regras
    const LICENCA = new Set(['cbLicenseCode', 'cbLicensePayload', 'cbPromoLifetimePro']);
    const SEGREDOS = new Set(['cbChavesIA', 'cbGeminiApiKey', 'cbBaiApiKey', 'cbJusApiToken']);
    const VOLATEIS = new Set([
        // sessão e pomodoro em andamento: restaurar isso poderia "ligar" um cronômetro fantasma
        'sessionState', 'pomodoroState', 'pomodoroTimeLeft', 'pomodoroEndAt', 'pomodoroPausedAt',
        'pomodoroInteligenteCiclos', 'pauseStartedAt', 'cbTrackingStartedAt', 'sessionAtualInicio',
        'lastCheckDate', 'planoItemAtivo', 'cbLiberadosTemp', 'cbAlarmeDisparadosHoje',
        // marcas de instalação/atualização: cada instalação gera as suas
        'migratedToSyncV5', 'migratedToSyncV5Local', 'cbOnboardingPendente', 'cbOnboardingSeen',
        'cbOverlayVersionRegistrada', 'cbUpdateDisponivel', 'cbUpdateDispensadaVersao', 'cbUltimaAberturaPopup',
        // depuração, contadores de chat e outros dados que se refazem sozinhos
        'qcSyncDebug', 'qcSyncDebugAssuntos', 'qcSyncDebugDisciplinas', 'cbQcEstatAmostra', 'cbQcEstatStatus',
        'cbAntiProcDiag', 'cbJusUltimoLimite', 'cbChatNaoLidas', 'cbChatUltimoVisto', 'cbComunidadeEnviadoPorDia',
        'cbSentinelaConectada', 'cbPciFeed', 'cbPciUltimaChecagem', 'cbPciChecouAlgumaVez'
    ]);
    const CACHES = [/^cbCorpus927Cache/, /^cbPlanaltoCache_/, /^cbJusCache_/];
    const LEIS_IMPORTADAS = [/^cbLeisImportadas$/, /^cbLeisChunks_/];
    // o próprio estado do backup (último arquivo, hash) é desta instalação e não deve voltar de um arquivo velho
    const PROPRIO = [/^cbBackupEstado/];

    const IDENTIDADE = new Set([
        'cbInstallId', 'cbDeviceId', 'cbChatId', 'cbGrupoAtivo', 'cbGrupoNome', 'cbGrupoMembroId',
        'cbRankingId', 'cbRankingApelido', 'cbRankingOptIn',
        'cbAccountId', 'cbAccountApelido', 'cbAccountSenha', 'cbAccountToken'
    ]);

    // Planalto: tudo o que a pessoa criou nas páginas de lei
    const PLANALTO = [/^cbHighlights::/, /^cbDraw::/, /^cbErros::/, /^cbArtigosPendentes$/, /^cbArtigosRevisao$/];
    const ESTUDO = new Set([
        'studyHistory', 'hourlyHistory', 'siteHourlyHistory', 'siteHistory', 'disciplinaHistory', 'assuntoHistory',
        'assuntoOverrides', 'activityHistory', 'pauseHistory', 'appUsageHistory', 'totalStudyMs', 'streakCount',
        'unlockedLevelIndex', 'unlockedStreakMilestones', 'questoesAssuntos', 'questoesAssuntosRaw',
        'questoesDailyHistory', 'questoesDisciplinas', 'questoesPeriodStats', 'questoesPrioridade', 'questoesStreak',
        'cbQcEstat', 'cbCadernoErros', 'cbCadernoAcertos', 'cbEstudosRegistro', 'pdfHistory', 'cbSomUsoLog'
    ]);
    const PLANEJAMENTO = new Set([
        'cronogramaConfig', 'cronogramaProgresso', 'cronogramaAvisosDispensados', 'cronogramaCrossCheck',
        'cbCronogramaHoje', 'cbCronogramaData', 'cbCronogramaPorData', 'cbCronogramaSitesCustom',
        'planoEstudo', 'planoRegistros', 'planoTempo', 'cbPlannerTabela', 'cbSimulados', 'cbPostits',
        'cbMapasMentais', 'cbMaterias', 'cbViagemProva', 'editalConfig', 'assuntosPrioridade',
        'videoMateriaOverride', 'pdfMateriaOverride', 'cbSitesBloqueadosManual', 'cbSitesLiberados',
        'cbBloqueioManualDispensados', 'cbEscolhasExcecaoPorHost'
    ]);
    // Metas, categorias de apps e o dock do Planalto têm valor padrão gravado pela própria extensão:
    // ficam em "ajustes" para uma instalação nova não ser tomada por "cheia de dados".

    const IA = [/^cbChatConversasHistorico$/];

    // Como mesclar cada tipo de dado quando a pessoa escolhe "mesclar".
    //   lista-por-id     : junta as duas listas pelo campo id (o atual vence; a nota/comentário preenchida vence a vazia)
    //   numeros-max      : junta objetos/listas e, onde os dois têm número, fica o MAIOR (histórico de horas, contadores)
    //   objeto-por-chave : junta as chaves do objeto; se a mesma chave existe nos dois, vale a atual
    //   artigos          : "artigos que eu errei" (cbArtigosPendentes/cbArtigosRevisao): junta pelo id, soma as questões de origem
    //                      e fica com a agenda de revisão (srs) mais recente
    //   preferir-atual   : fica o que já está aqui; o backup só preenche o que falta (padrão, vale para configurações)
    //   (desenho cbDraw é uma imagem única por página: não dá para misturar duas; vale a atual se existir)
    const MESCLA_LISTA = [/^cbHighlights::/, /^cbErros::/];
    const MESCLA_ARTIGOS = [/^cbArtigosPendentes$/, /^cbArtigosRevisao$/];
    const MESCLA_LISTA_NOMES = new Set([
        'cbCadernoErros', 'cbPostits', 'cbSimulados', 'cbMapasMentais',
        'cbChatConversasHistorico', 'cbMaterias', 'cbLeisImportadas', 'pdfHistory'
    ]);
    const MESCLA_MAX = new Set([
        'cbCadernoAcertos',
        'studyHistory', 'hourlyHistory', 'siteHourlyHistory', 'siteHistory', 'disciplinaHistory', 'assuntoHistory',
        'activityHistory', 'pauseHistory', 'appUsageHistory', 'questoesDailyHistory', 'questoesStreak', 'streakCount',
        'totalStudyMs', 'unlockedLevelIndex', 'unlockedStreakMilestones', 'cronogramaProgresso', 'planoRegistros',
        'cbSomUsoLog'
    ]);
    const MESCLA_OBJETO = new Set(['cbEstudosRegistro', 'cbCronogramaPorData']);

    const testa = (lista, chave) => lista.some((re) => re.test(chave));

    /**
     * Classifica uma chave do storage.
     * @returns {{incluir:boolean, grupo:string, motivo?:string, mescla:string}}
     *   motivo (só quando fica de fora): 'licenca' | 'segredo' | 'cache' | 'temporario' | 'proprio' | 'leis' | 'invalida'
     */
    function classificarChave(chave, area, opcoes) {
        const op = opcoes || {};
        if (typeof chave !== 'string' || !chave || chave === '__proto__') return { incluir: false, grupo: 'ajustes', motivo: 'invalida', mescla: 'preferir-atual' };
        if (LICENCA.has(chave)) return { incluir: false, grupo: 'ajustes', motivo: 'licenca', mescla: 'preferir-atual' };
        if (SEGREDOS.has(chave)) return { incluir: false, grupo: 'ajustes', motivo: 'segredo', mescla: 'preferir-atual' };
        if (testa(PROPRIO, chave)) return { incluir: false, grupo: 'ajustes', motivo: 'proprio', mescla: 'preferir-atual' };
        if (VOLATEIS.has(chave)) return { incluir: false, grupo: 'ajustes', motivo: 'temporario', mescla: 'preferir-atual' };
        if (testa(CACHES, chave)) return { incluir: false, grupo: 'ajustes', motivo: 'cache', mescla: 'preferir-atual' };
        if (testa(LEIS_IMPORTADAS, chave)) {
            const r = { incluir: !!op.incluirLeis, grupo: 'ia', mescla: chave === 'cbLeisImportadas' ? 'lista-por-id' : 'preferir-atual' };
            if (!r.incluir) r.motivo = 'leis';
            return r;
        }
        let grupo = 'ajustes';
        if (IDENTIDADE.has(chave)) grupo = 'identidade';
        else if (testa(PLANALTO, chave)) grupo = 'planalto';
        else if (ESTUDO.has(chave)) grupo = 'estudo';
        else if (PLANEJAMENTO.has(chave)) grupo = 'planejamento';
        else if (testa(IA, chave)) grupo = 'ia';

        let mescla = 'preferir-atual';
        if (testa(MESCLA_ARTIGOS, chave)) mescla = 'artigos';
        else if (testa(MESCLA_LISTA, chave) || MESCLA_LISTA_NOMES.has(chave)) mescla = 'lista-por-id';
        else if (MESCLA_MAX.has(chave)) mescla = 'numeros-max';
        else if (MESCLA_OBJETO.has(chave)) mescla = 'objeto-por-chave';
        return { incluir: true, grupo, mescla };
    }

    function ehObjeto(v) { return v !== null && typeof v === 'object' && !Array.isArray(v); }

    /** Separa o que entra do que fica de fora. Devolve também a lista de exclusões (para mostrar na tela). */
    function filtrarDados(dados, opcoes) {
        const d = dados || {};
        const saida = { local: {}, sync: {}, excluidas: [] };
        ['local', 'sync'].forEach((area) => {
            const origem = ehObjeto(d[area]) ? d[area] : {};
            Object.keys(origem).forEach((chave) => {
                const c = classificarChave(chave, area, opcoes);
                if (c.incluir) {
                    if (origem[chave] !== undefined) saida[area][chave] = origem[chave];
                } else {
                    saida.excluidas.push({ chave, area, motivo: c.motivo });
                }
            });
        });
        return saida;
    }

    // ---------------------------------------------------------------- resumo
    const NUM = (v) => (typeof v === 'number' && isFinite(v) ? v : 0);
    const tamanhoTexto = (v) => { try { return JSON.stringify(v).length; } catch (e) { return 0; } };

    /**
     * Números para mostrar na tela ("12 páginas, 340 grifos, 58 comentários...").
     * Comentário = campo `nota` do grifo (é onde o marcador do Planalto guarda o texto digitado).
     */
    function resumir(local, sync) {
        const L = ehObjeto(local) ? local : {};
        const S = ehObjeto(sync) ? sync : {};
        const r = {
            // artigosParaRevisar = "artigos que eu errei" já confirmados no Planalto; artigosPendentes = ainda esperando confirmação;
            // questoesErradasLigadas = quantas questões erradas (distintas) deram origem a esses artigos
            planalto: { paginas: 0, marcacoes: 0, grifos: 0, sublinhados: 0, negritos: 0, comentarios: 0, desenhos: 0, artigosComErros: 0, errosAnotados: 0, artigosParaRevisar: 0, artigosPendentes: 0, questoesErradasLigadas: 0 },
            estudo: { diasDeEstudo: 0, primeiroDia: null, ultimoDia: null, horasTotais: 0, questoesRegistradas: 0, diasDeAutoavaliacao: 0, cadernoDeErros: 0 },
            planejamento: { postits: 0, simulados: 0, mapasMentais: 0, temCronograma: false, temEdital: false },
            ia: { conversas: 0, leisImportadas: 0 },
            chaves: { local: Object.keys(L).length, sync: Object.keys(S).length }
        };
        const questoes = new Set();
        const contarOrigens = (artigo) => {
            if (artigo && Array.isArray(artigo.origens)) artigo.origens.forEach((o) => { if (o && o.questaoId) questoes.add(String(o.questaoId)); });
        };
        Object.keys(L).forEach((chave) => {
            const v = L[chave];
            if (/^cbHighlights::/.test(chave)) {
                const lista = Array.isArray(v) ? v : [];
                if (!lista.length) return;
                r.planalto.paginas++;
                lista.forEach((g) => {
                    if (!g || typeof g !== 'object') return;
                    r.planalto.marcacoes++;
                    if (g.tipo === 'negrito') r.planalto.negritos++;
                    else if (g.tipo === 'sublinhado') r.planalto.sublinhados++;
                    else r.planalto.grifos++;
                    if (typeof g.nota === 'string' && g.nota.trim()) r.planalto.comentarios++;
                });
            } else if (/^cbDraw::/.test(chave)) {
                if (typeof v === 'string' && v.length > 100) r.planalto.desenhos++;
            } else if (/^cbErros::/.test(chave)) {
                if (Array.isArray(v) && v.length) { r.planalto.artigosComErros++; r.planalto.errosAnotados += v.length; }
            } else if (chave === 'cbArtigosRevisao') {
                if (Array.isArray(v)) { r.planalto.artigosParaRevisar = v.length; v.forEach(contarOrigens); }
            } else if (chave === 'cbArtigosPendentes') {
                if (Array.isArray(v)) { r.planalto.artigosPendentes = v.length; v.forEach(contarOrigens); }
            } else if (chave === 'cbCadernoErros') {
                r.estudo.cadernoDeErros = Array.isArray(v) ? v.length : NUM(v);
            } else if (chave === 'studyHistory') {
                if (ehObjeto(v)) {
                    const dias = Object.keys(v).filter((k) => NUM(v[k]) > 0).sort();
                    r.estudo.diasDeEstudo = dias.length;
                    r.estudo.primeiroDia = dias[0] || null;
                    r.estudo.ultimoDia = dias[dias.length - 1] || null;
                    r.estudo.horasTotais = Math.round(dias.reduce((s, k) => s + NUM(v[k]), 0) / 3600000 * 10) / 10;
                }
            } else if (chave === 'questoesDailyHistory') {
                if (ehObjeto(v)) {
                    r.estudo.questoesRegistradas = Object.keys(v).reduce((s, k) => {
                        const x = v[k];
                        if (typeof x === 'number') return s + x;
                        if (ehObjeto(x)) return s + NUM(x.total) + (x.total === undefined ? NUM(x.acertos) + NUM(x.erros) : 0);
                        return s;
                    }, 0);
                }
            } else if (chave === 'cbEstudosRegistro') {
                if (ehObjeto(v)) r.estudo.diasDeAutoavaliacao = Object.keys(v).length;
            } else if (chave === 'cbPostits') { r.planejamento.postits = Array.isArray(v) ? v.length : 0; }
            else if (chave === 'cbSimulados') { r.planejamento.simulados = Array.isArray(v) ? v.length : 0; }
            else if (chave === 'cbMapasMentais') { r.planejamento.mapasMentais = Array.isArray(v) ? v.length : (ehObjeto(v) ? Object.keys(v).length : 0); }
            else if (chave === 'cronogramaConfig') { r.planejamento.temCronograma = !!v && (!ehObjeto(v) || Object.keys(v).length > 0); }
            else if (chave === 'cbChatConversasHistorico') { r.ia.conversas = Array.isArray(v) ? v.length : 0; }
            else if (chave === 'cbLeisImportadas') { r.ia.leisImportadas = Array.isArray(v) ? v.length : 0; }
        });
        r.planalto.questoesErradasLigadas = questoes.size;
        r.planejamento.temEdital = !!S.editalConfig || !!L.editalConfig;
        return r;
    }

    function valorComConteudo(v) {
        if (v === null || v === undefined || v === false || v === '' || v === 0) return false;
        if (Array.isArray(v)) return v.length > 0;
        if (typeof v === 'object') return Object.keys(v).length > 0;
        return true;
    }

    /**
     * "Vazio" = nenhuma chave de CONTEÚDO (Planalto, estudo, planejamento, conversas) com algo dentro.
     * Configurações e identificação não contam: uma instalação nova já nasce com elas.
     */
    function ehDadosVazios(local, sync) {
        const L = ehObjeto(local) ? local : {};
        const S = ehObjeto(sync) ? sync : {};
        const algumConteudo = (obj) => Object.keys(obj).some((chave) => {
            const c = classificarChave(chave, 'local', { incluirLeis: true });
            return c.incluir && c.grupo !== 'ajustes' && c.grupo !== 'identidade' && valorComConteudo(obj[chave]);
        });
        return !algumConteudo(L) && !algumConteudo(S);
    }

    // ------------------------------------------------------------- integridade
    /** cyrb53: hash rápido de 53 bits (não é criptográfico; serve para detectar arquivo corrompido ou editado). */
    function hashTexto(str, seed) {
        let h1 = 0xdeadbeef ^ (seed || 0), h2 = 0x41c6ce57 ^ (seed || 0);
        for (let i = 0; i < str.length; i++) {
            const ch = str.charCodeAt(i);
            h1 = Math.imul(h1 ^ ch, 2654435761);
            h2 = Math.imul(h2 ^ ch, 1597334677);
        }
        h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
        h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
        return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
    }

    // ----------------------------------------------------------------- montar
    /**
     * @param {{local:object, sync:object, agora?:number, versaoExtensao?:string, navegador?:string, motivo?:string, opcoes?:{incluirLeis?:boolean}}} p
     */
    function montarBackup(p) {
        const agora = typeof p.agora === 'number' ? p.agora : Date.now();
        const opcoes = { incluirLeis: !!(p.opcoes && p.opcoes.incluirLeis) };
        const f = filtrarDados({ local: p.local, sync: p.sync }, opcoes);
        const dados = { local: f.local, sync: f.sync };
        const textoDados = JSON.stringify(dados);
        const licenca = (p.sync && (p.sync.cbLicenseCode || p.sync.cbPromoLifetimePro)) || (p.local && p.local.cbLicenseCode);
        return {
            formato: FORMATO,
            esquema: ESQUEMA,
            criadoEm: new Date(agora).toISOString(),
            origem: {
                versaoExtensao: String(p.versaoExtensao || ''),
                navegador: String(p.navegador || ''),
                motivo: String(p.motivo || 'manual'),
                // só um aviso para a tela de restauração; o código da licença NUNCA vai no arquivo
                tinhaLicenca: !!licenca
            },
            opcoes,
            resumo: resumir(f.local, f.sync),
            excluidas: f.excluidas.map((e) => e.chave),
            integridade: { algoritmo: 'cyrb53', valor: hashTexto(textoDados), caracteres: textoDados.length },
            dados
        };
    }

    // -------------------------------------------------------------- validação
    /**
     * Valida um objeto já lido do JSON. Nunca lança.
     * @returns {{ok:boolean, erros:string[], avisos:string[]}}
     */
    function validarBackup(obj) {
        const erros = [];
        const avisos = [];
        if (!ehObjeto(obj)) return { ok: false, erros: ['O arquivo não é um backup do Concurseiro Blindado (conteúdo inesperado).'], avisos };
        if (obj.formato !== FORMATO) return { ok: false, erros: ['Este arquivo não é um backup do Concurseiro Blindado.'], avisos };
        if (typeof obj.esquema !== 'number' || !isFinite(obj.esquema) || obj.esquema < 1) {
            erros.push('O arquivo não informa a versão do formato.');
        } else if (obj.esquema > ESQUEMA) {
            erros.push('Este backup foi feito por uma versão mais nova da extensão. Atualize o Concurseiro Blindado e tente de novo.');
        }
        if (!ehObjeto(obj.dados) || !ehObjeto(obj.dados.local)) {
            erros.push('O backup não tem a parte de dados (chrome.storage.local).');
        } else {
            if (obj.dados.sync !== undefined && !ehObjeto(obj.dados.sync)) erros.push('A parte de configurações (sync) do backup está malformada.');
        }
        if (erros.length) return { ok: false, erros, avisos };

        const t = Date.parse(obj.criadoEm);
        if (!isFinite(t)) avisos.push('O arquivo não tem uma data de criação válida.');
        else if (t > Date.now() + 36e5) avisos.push('A data do backup está no futuro: confira o relógio do computador.');

        if (ehObjeto(obj.integridade) && typeof obj.integridade.valor === 'string') {
            const texto = JSON.stringify({ local: obj.dados.local, sync: obj.dados.sync || {} });
            // o backup sem a parte sync é montado com sync:{}; compara das duas maneiras
            const conf = hashTexto(texto) === obj.integridade.valor || hashTexto(JSON.stringify(obj.dados)) === obj.integridade.valor;
            if (!conf) avisos.push('A checagem de integridade não confere: o arquivo foi alterado ou está corrompido. Os dados abaixo podem estar incompletos.');
        } else {
            avisos.push('O arquivo não traz checagem de integridade.');
        }
        const dentro = Object.keys(obj.dados.local).concat(Object.keys(obj.dados.sync || {}));
        if (!dentro.length) avisos.push('O backup está vazio.');
        return { ok: true, erros, avisos };
    }

    // -------------------------------------------------------------- mesclagem
    function chaveDeItem(item) {
        if (item && typeof item === 'object' && item.id !== undefined && item.id !== null) return 'id:' + String(item.id);
        try { return 'js:' + JSON.stringify(item); } catch (e) { return 'x:' + String(item); }
    }

    function mesclarListas(atual, doBackup) {
        if (!Array.isArray(atual) || !Array.isArray(doBackup)) return atual === undefined ? doBackup : atual;
        const mapa = new Map();
        atual.forEach((it) => { mapa.set(chaveDeItem(it), it); });
        doBackup.forEach((it) => {
            const k = chaveDeItem(it);
            if (!mapa.has(k)) { mapa.set(k, it); return; }
            const a = mapa.get(k);
            if (ehObjeto(a) && ehObjeto(it)) {
                const junto = Object.assign({}, it, a); // o atual vence campo a campo...
                const notaA = typeof a.nota === 'string' ? a.nota.trim() : '';
                if (!notaA && typeof it.nota === 'string' && it.nota.trim()) junto.nota = it.nota; // ...menos o comentário que o atual deixou vazio
                mapa.set(k, junto);
            }
        });
        return Array.from(mapa.values());
    }

    function mesclarMax(atual, doBackup) {
        if (atual === undefined || atual === null) return doBackup;
        if (doBackup === undefined || doBackup === null) return atual;
        if (typeof atual === 'number' && typeof doBackup === 'number') return Math.max(atual, doBackup);
        if (Array.isArray(atual) && Array.isArray(doBackup)) return mesclarListas(atual, doBackup);
        if (ehObjeto(atual) && ehObjeto(doBackup)) {
            const r = {};
            Object.keys(doBackup).forEach((k) => { if (k !== '__proto__') r[k] = doBackup[k]; });
            Object.keys(atual).forEach((k) => { if (k !== '__proto__') r[k] = k in doBackup ? mesclarMax(atual[k], doBackup[k]) : atual[k]; });
            return r;
        }
        return atual; // tipos diferentes ou textos: vale o atual
    }

    function mesclarObjetoPorChave(atual, doBackup) {
        if (!ehObjeto(atual) || !ehObjeto(doBackup)) return atual === undefined ? doBackup : atual;
        const r = {};
        Object.keys(doBackup).forEach((k) => { if (k !== '__proto__') r[k] = doBackup[k]; });
        Object.keys(atual).forEach((k) => { if (k !== '__proto__') r[k] = atual[k]; });
        return r;
    }

    const MAX_ORIGENS = 12; // mesmo teto de artigos-erros-store.js

    function juntarOrigens(a, b) {
        const lista = [];
        const vistos = new Set();
        (Array.isArray(a) ? a : []).concat(Array.isArray(b) ? b : []).forEach((o) => {
            if (!o || typeof o !== 'object') return;
            const k = o.questaoId ? 'q:' + o.questaoId : chaveDeItem(o);
            if (vistos.has(k)) return;
            vistos.add(k);
            lista.push(o);
        });
        lista.sort((x, y) => (x.em || 0) - (y.em || 0));
        return lista.length > MAX_ORIGENS ? lista.slice(-MAX_ORIGENS) : lista;
    }

    /**
     * "Artigos que eu errei": mesmo artigo nos dois lados → um só item, com as questões de origem dos dois e a agenda de
     * revisão (srs) da revisão mais recente (a que reflete o estado atual da memória). Os demais campos: vale o atual,
     * menos texto/detalhe vazios, que o backup preenche.
     */
    function mesclarArtigos(atual, doBackup) {
        if (!Array.isArray(atual) || !Array.isArray(doBackup)) return atual === undefined ? doBackup : atual;
        const mapa = new Map();
        atual.forEach((it) => { mapa.set(chaveDeItem(it), it); });
        doBackup.forEach((b) => {
            const k = chaveDeItem(b);
            if (!mapa.has(k)) { mapa.set(k, b); return; }
            const a = mapa.get(k);
            if (!ehObjeto(a) || !ehObjeto(b)) return;
            const junto = Object.assign({}, b, a);
            ['texto', 'detalhe', 'url'].forEach((campo) => { if (!a[campo] && b[campo]) junto[campo] = b[campo]; });
            if (a.origens !== undefined || b.origens !== undefined) junto.origens = juntarOrigens(a.origens, b.origens);
            if (a.criadoEm !== undefined && b.criadoEm !== undefined) junto.criadoEm = Math.min(a.criadoEm, b.criadoEm);
            if (ehObjeto(a.srs) && ehObjeto(b.srs)) {
                const ua = a.srs.ultima || 0;
                const ub = b.srs.ultima || 0;
                junto.srs = ub > ua ? b.srs : a.srs;
            } else if (!a.srs && b.srs) junto.srs = b.srs;
            mapa.set(k, junto);
        });
        return Array.from(mapa.values());
    }

    /** Mescla um valor conforme a estratégia da chave. `atual` undefined = não existe aqui. */
    function mesclarValor(estrategia, atual, doBackup) {
        if (atual === undefined) return doBackup;
        if (doBackup === undefined) return atual;
        switch (estrategia) {
            case 'artigos': return mesclarArtigos(atual, doBackup);
            case 'lista-por-id': return mesclarListas(atual, doBackup);
            case 'numeros-max': return mesclarMax(atual, doBackup);
            case 'objeto-por-chave': return mesclarObjetoPorChave(atual, doBackup);
            default: return atual;
        }
    }

    const iguais = (a, b) => { try { return JSON.stringify(a) === JSON.stringify(b); } catch (e) { return false; } };

    // ------------------------------------------------------------- restauração
    /**
     * Monta o plano de restauração SEM gravar nada.
     *   modo 'substituir': o que é dado (Planalto, estudo, planejamento, conversas) fica igual ao backup — o que existe aqui
     *                      e não está no backup é removido; configurações ausentes do backup ficam como estão.
     *   modo 'mesclar'   : junta os dois lados; nada do que existe aqui é apagado nem sobrescrito por dado mais antigo.
     *   identidade false : não mexe nas chaves de identificação desta instalação (ID do celular/comunidade/licença).
     * Sempre ignora licença, chaves de API, caches e estado temporário, mesmo que estejam no arquivo.
     */
    function planejarRestauracao(backup, atuais, opcoes) {
        const op = opcoes || {};
        const modo = op.modo === 'mesclar' ? 'mesclar' : 'substituir';
        const identidade = op.identidade !== false;
        const cur = { local: ehObjeto(atuais && atuais.local) ? atuais.local : {}, sync: ehObjeto(atuais && atuais.sync) ? atuais.sync : {} };
        const src = { local: ehObjeto(backup && backup.dados && backup.dados.local) ? backup.dados.local : {}, sync: ehObjeto(backup && backup.dados && backup.dados.sync) ? backup.dados.sync : {} };

        const plano = {
            modo, identidade,
            gravar: { local: {}, sync: {} },
            remover: { local: [], sync: [] },
            relatorio: { gravadas: 0, mescladas: 0, mantidas: 0, removidas: 0, ignoradas: [], identidadeMantida: 0 }
        };
        const rel = plano.relatorio;
        const final = { local: {}, sync: {} };

        ['local', 'sync'].forEach((area) => {
            const chavesBackup = Object.keys(src[area]);
            chavesBackup.forEach((chave) => {
                const c = classificarChave(chave, area, { incluirLeis: true });
                if (!c.incluir) { rel.ignoradas.push({ chave, area, motivo: c.motivo }); return; }
                if (c.grupo === 'identidade' && !identidade) { rel.identidadeMantida++; return; }
                const doBackup = src[area][chave];
                if (doBackup === undefined) return;
                const atual = cur[area][chave];
                if (modo === 'substituir') {
                    if (atual !== undefined && iguais(atual, doBackup)) { rel.mantidas++; return; }
                    plano.gravar[area][chave] = doBackup;
                    rel.gravadas++;
                } else {
                    if (atual === undefined) { plano.gravar[area][chave] = doBackup; rel.gravadas++; return; }
                    const m = mesclarValor(c.mescla, atual, doBackup);
                    if (iguais(m, atual)) { rel.mantidas++; return; }
                    plano.gravar[area][chave] = m;
                    rel.mescladas++;
                }
            });

            if (modo === 'substituir') {
                // remove só DADOS que o backup não tem (nunca configurações, identificação, licença ou caches)
                Object.keys(cur[area]).forEach((chave) => {
                    if (chave in src[area]) return;
                    const c = classificarChave(chave, area, { incluirLeis: true });
                    if (!c.incluir || c.grupo === 'ajustes' || c.grupo === 'identidade') return;
                    plano.remover[area].push(chave);
                    rel.removidas++;
                });
            }

            // como ficará o storage depois (para a tela mostrar "você terá…")
            Object.keys(cur[area]).forEach((chave) => { final[area][chave] = cur[area][chave]; });
            Object.keys(plano.gravar[area]).forEach((chave) => { final[area][chave] = plano.gravar[area][chave]; });
            plano.remover[area].forEach((chave) => { delete final[area][chave]; });
        });

        // Na mesclagem, um artigo já confirmado para revisão não pode continuar na fila de "pendentes" (a extensão tira da fila ao confirmar)
        if (modo === 'mesclar') {
            const rev = final.local.cbArtigosRevisao;
            const pend = final.local.cbArtigosPendentes;
            if (Array.isArray(rev) && Array.isArray(pend) && (('cbArtigosPendentes' in plano.gravar.local) || ('cbArtigosRevisao' in plano.gravar.local))) {
                const ids = new Set(rev.map((x) => x && x.id));
                const filtrada = pend.filter((x) => !(x && ids.has(x.id)));
                if (filtrada.length !== pend.length) {
                    plano.gravar.local.cbArtigosPendentes = filtrada;
                    final.local.cbArtigosPendentes = filtrada;
                }
            }
        }

        plano.resumoFinal = resumir(final.local, final.sync);
        return plano;
    }

    // ------------------------------------------------------- arquivo e agenda
    const dois = (n) => String(n).padStart(2, '0');

    /**
     * Nome do arquivo dentro da pasta de Downloads.
     *   'auto' / 'manual' → backup-<dia da semana>.json (gira em 7 arquivos, sobrescrevendo o da semana passada)
     *   'mensal'          → mensal-AAAA-MM.json (um por mês, nunca sobrescrito; protege de um problema só notado depois)
     *   'antes-de-restaurar' → antes-de-restaurar-AAAAMMDD-HHMMSS.json
     */
    function nomeDoArquivo(motivo, agora) {
        const d = new Date(typeof agora === 'number' ? agora : Date.now());
        if (motivo === 'mensal') return { nome: PASTA + '/mensal-' + d.getFullYear() + '-' + dois(d.getMonth() + 1) + '.json', conflito: 'uniquify' };
        if (motivo === 'antes-de-restaurar') {
            const stamp = '' + d.getFullYear() + dois(d.getMonth() + 1) + dois(d.getDate()) + '-' + dois(d.getHours()) + dois(d.getMinutes()) + dois(d.getSeconds());
            return { nome: PASTA + '/antes-de-restaurar-' + stamp + '.json', conflito: 'uniquify' };
        }
        return { nome: PASTA + '/backup-' + DIAS[d.getDay()] + '.json', conflito: 'overwrite' };
    }

    function mesDe(agora) { const d = new Date(agora); return d.getFullYear() + '-' + dois(d.getMonth() + 1); }

    const CONFIG_PADRAO = { auto: false, intervaloH: 12, incluirLeis: false, apagarDoHistorico: true };
    const INTERVALOS_H = [6, 12, 24];

    function normalizarConfig(c) {
        const r = Object.assign({}, CONFIG_PADRAO, ehObjeto(c) ? c : {});
        r.auto = !!r.auto;
        r.incluirLeis = !!r.incluirLeis;
        r.apagarDoHistorico = r.apagarDoHistorico !== false;
        if (INTERVALOS_H.indexOf(Number(r.intervaloH)) === -1) r.intervaloH = CONFIG_PADRAO.intervaloH;
        r.intervaloH = Number(r.intervaloH);
        return r;
    }

    /** Já passou tempo suficiente desde o último backup bem-sucedido? (com 5 min de folga para o alarme) */
    function estaNaHora(config, estado, agora) {
        const cfg = normalizarConfig(config);
        const ult = estado && estado.ultimo && estado.ultimo.ok ? estado.ultimo.em : 0;
        if (!ult) return true;
        return (agora - ult) >= (cfg.intervaloH * 3600000 - 300000);
    }

    /**
     * Situação para a tela e para o aviso do popup.
     * @returns {{nivel:'nunca'|'ok'|'antigo'|'erro', diasDesde:number|null}}
     */
    function situacao(config, estado, agora) {
        const ult = estado && estado.ultimo && estado.ultimo.ok ? estado.ultimo.em : 0;
        if (!ult) return { nivel: (estado && estado.ultimaFalha) ? 'erro' : 'nunca', diasDesde: null };
        const dias = Math.floor((agora - ult) / 86400000);
        return { nivel: dias >= 3 ? 'antigo' : 'ok', diasDesde: dias };
    }

    const api = {
        FORMATO, ESQUEMA, PASTA, GRUPOS, CONFIG_PADRAO, INTERVALOS_H,
        classificarChave, filtrarDados, resumir, ehDadosVazios, hashTexto,
        montarBackup, validarBackup, mesclarValor, planejarRestauracao,
        nomeDoArquivo, mesDe, normalizarConfig, estaNaHora, situacao, tamanhoTexto
    };
    if (typeof module !== 'undefined' && module.exports) module.exports = api;
    raiz.CBBackup = api;
})(typeof globalThis !== 'undefined' ? globalThis : (typeof self !== 'undefined' ? self : this));
