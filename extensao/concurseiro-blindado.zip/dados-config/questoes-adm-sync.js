// ============================================================================
// questoes-adm-sync.js — Envia o banco de questões de Direito Administrativo
// (carregado por questoes-administrativo.js) para o Firebase, DENTRO do nó do
// próprio dispositivo pareado. Só existe algo em
// dispositivos/<deviceId>/questoesAdm quando:
//   1) a extensão está instalada com este arquivo, E
//   2) o usuário pareou a extensão com o site (gerou deviceId).
// Sem pareamento não existe deviceId, logo não existe caminho no Firebase pra
// escrever nem pra ler — é a mesma trava que já protege Painel/Agenda.
//
// Reaproveita cbObterDeviceId() e CB_FIREBASE_URL, já definidos em
// firebase-sync.js. Carregar este arquivo DEPOIS de firebase-sync.js e
// DEPOIS de questoes-administrativo.js no manifest.json.
// ============================================================================

async function cbEnviarQuestoesAdm() {
    try {
        if (typeof CB_QUESTOES_ADM_QA === 'undefined' || typeof cbObterDeviceId !== 'function') return;

        cbObterDeviceId(async (deviceId) => {
            if (!deviceId) return; // não pareado -> não envia nada

            const payload = {
                qa: CB_QUESTOES_ADM_QA,
                ce: CB_QUESTOES_ADM_CE,
                atualizadoEm: Date.now()
            };

            try {
                const resp = await fetch(
                    `${CB_FIREBASE_URL}/dispositivos/${deviceId}/questoesAdm.json`,
                    { method: 'PUT', body: JSON.stringify(payload) }
                );
                if (!resp.ok) {
                    console.warn('[CB-QuestoesADM] Falha ao sincronizar banco:', resp.status);
                    return;
                }
                console.log('[CB-QuestoesADM] Banco sincronizado com o Firebase para', deviceId);
            } catch (e) {
                console.warn('[CB-QuestoesADM] Erro de rede ao sincronizar banco:', e);
            }
        });
    } catch (e) {
        console.warn('[CB-QuestoesADM] Erro inesperado:', e);
    }
}

// Reenvia sempre que o storage indicar que o pareamento mudou (parear/desparear),
// e uma vez ao carregar a extensão.
chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local' && changes.cbDeviceId) {
        cbEnviarQuestoesAdm();
    }
});
cbEnviarQuestoesAdm();
