// ===================== VIAGEM ATÉ A PROVA: DISTÂNCIA E CUSTO =====================
//
// A pessoa digita de onde sai e onde é a prova (cidade ou endereço). Os mapas vêm do OpenStreetMap, sem chave:
//   • Nominatim (nominatim.openstreetmap.org)  — transforma o texto em coordenadas;
//   • OSRM (router.project-osrm.org)           — distância e tempo de carro pelas ruas e estradas.
// Os dois são servidores públicos gratuitos de "uso leve": uma consulta por clique em "Calcular", nunca em
// laço. O custo não vem de mapa nenhum: é conta feita aqui com o que a pessoa informa (consumo do carro,
// preço do combustível, tarifa do ônibus, passagem de avião, pedágio).
//
// A parte pura (conta, formatação, leitura das respostas, links) roda em Node:
// dados-config/testes/viagem-prova.test.js. O final do arquivo faz as chamadas de rede no navegador.
(function (root) {
    'use strict';

    const PADROES = {
        consumoKmL: 11,           // km por litro (carro popular, estrada)
        precoLitro: 6.2,          // R$ por litro (a pessoa atualiza)
        pedagio: 0,               // R$ no trecho (manual: não há fonte gratuita confiável)
        estacionamento: 0,        // R$ por dia
        pessoasCarro: 1,          // quantas pessoas dividem o carro
        idaEVolta: true,
        onibusPorKm: 0.3,         // R$ por km: SÓ estimativa; o valor digitado da passagem vale mais
        onibusTarifa: null,       // R$ de uma passagem (ida), se a pessoa souber
        aviaoIda: null, aviaoVolta: null,   // R$
        translados: 0,            // R$ táxi/app/ônibus de ligação nos dois lados (avião e ônibus)
        hospedagem: 0,            // R$ no total (noite anterior)
        alimentacao: 0,           // R$ no total
    };

    const num = (v) => {
        if (v === null || v === undefined || v === '') return null;
        const n = Number(String(v).replace(/\s/g, '').replace(/\.(?=\d{3}(\D|$))/g, '').replace(',', '.'));
        return Number.isFinite(n) ? n : null;
    };
    const ou = (v, padrao) => { const n = num(v); return n === null ? padrao : n; };

    // distância em linha reta (km) entre dois pontos { lat, lon }: serve de reserva e para o avião
    function haversine(a, b) {
        const R = 6371;
        const rad = (g) => (g * Math.PI) / 180;
        const dLat = rad(b.lat - a.lat), dLon = rad(b.lon - a.lon);
        const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLon / 2) ** 2;
        return 2 * R * Math.asin(Math.sqrt(h));
    }

    // Nominatim → [{ nome, lat, lon }]
    function lerGeocodificacao(json) {
        return (Array.isArray(json) ? json : []).map((r) => ({ nome: String(r.display_name || ''), lat: Number(r.lat), lon: Number(r.lon) }))
            .filter((r) => r.nome && Number.isFinite(r.lat) && Number.isFinite(r.lon));
    }

    // OSRM → { km, minutos } ou null
    function lerRota(json) {
        const rota = json && json.routes && json.routes[0];
        if (!rota || !Number.isFinite(rota.distance)) return null;
        return { km: rota.distance / 1000, minutos: Math.round(rota.duration / 60) };
    }

    function urlGeocodificacao(texto) {
        const p = new URLSearchParams({ q: texto, format: 'json', limit: '4', countrycodes: 'br', 'accept-language': 'pt-BR' });
        return 'https://nominatim.openstreetmap.org/search?' + p.toString();
    }
    // Dois servidores públicos com a mesma API (OSRM): se um falhar, tenta o outro.
    const SERVIDORES_ROTA = ['https://router.project-osrm.org/route/v1/driving/', 'https://routing.openstreetmap.de/routed-car/route/v1/driving/'];
    function urlRota(a, b, servidor) {
        return `${servidor || SERVIDORES_ROTA[0]}${a.lon},${a.lat};${b.lon},${b.lat}?overview=false`;
    }

    // ---------- custos ----------
    // km: distância de UM trecho. cfg: campos de PADROES (texto ou número).
    function custoCarro(km, cfg) {
        const c = cfg || {};
        const trechos = c.idaEVolta === false ? 1 : 2;
        const consumo = Math.max(0.1, ou(c.consumoKmL, PADROES.consumoKmL));
        const combustivel = (km * trechos / consumo) * ou(c.precoLitro, PADROES.precoLitro);
        const pedagio = ou(c.pedagio, PADROES.pedagio);          // total informado (ida e volta já somados)
        const estacionamento = ou(c.estacionamento, PADROES.estacionamento);
        const total = combustivel + pedagio + estacionamento;
        const pessoas = Math.max(1, Math.round(ou(c.pessoasCarro, PADROES.pessoasCarro)));
        return { total, porPessoa: total / pessoas, combustivel, pedagio, estacionamento, litros: km * trechos / consumo, pessoas, trechos };
    }

    function custoOnibus(km, cfg) {
        const c = cfg || {};
        const trechos = c.idaEVolta === false ? 1 : 2;
        const tarifa = num(c.onibusTarifa);
        const estimado = tarifa === null;
        const porTrecho = estimado ? km * ou(c.onibusPorKm, PADROES.onibusPorKm) : tarifa;
        const translados = ou(c.translados, PADROES.translados);
        return { total: porTrecho * trechos + translados, porTrecho, estimado, translados, trechos };
    }

    function custoAviao(cfg) {
        const c = cfg || {};
        const ida = num(c.aviaoIda), volta = num(c.aviaoVolta);
        if (ida === null && volta === null) return null;       // sem preço digitado não há como estimar
        const trechos = c.idaEVolta === false ? 1 : 2;
        const passagens = (ida || 0) + (c.idaEVolta === false ? 0 : (volta === null ? (ida || 0) : volta));
        const translados = ou(c.translados, PADROES.translados);
        return { total: passagens + translados, passagens, translados, trechos };
    }

    // Soma o que é igual para qualquer meio (hospedagem, alimentação) e aponta o mais barato.
    function comparar(km, cfg) {
        const c = cfg || {};
        const extras = ou(c.hospedagem, PADROES.hospedagem) + ou(c.alimentacao, PADROES.alimentacao);
        const opcoes = [];
        const carro = custoCarro(km, c);
        opcoes.push({ meio: 'carro', nome: 'Carro', total: carro.porPessoa + extras, detalhe: carro });
        const onibus = custoOnibus(km, c);
        opcoes.push({ meio: 'onibus', nome: 'Ônibus', total: onibus.total + extras, detalhe: onibus });
        const aviao = custoAviao(c);
        if (aviao) opcoes.push({ meio: 'aviao', nome: 'Avião', total: aviao.total + extras, detalhe: aviao });
        const maisBarato = opcoes.reduce((m, o) => (o.total < m.total ? o : m), opcoes[0]);
        return { opcoes, maisBarato: maisBarato.meio, extras };
    }

    // ---------- apresentação ----------
    const brl = (v) => 'R$ ' + (Number(v) || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    function duracao(min) {
        const h = Math.floor(min / 60), m = min % 60;
        return h ? `${h} h${m ? ' ' + String(m).padStart(2, '0') + ' min' : ''}` : `${m} min`;
    }
    const km1 = (km) => km.toLocaleString('pt-BR', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + ' km';

    // Links que abrem o serviço certo, com a busca pronta (nenhum deles usa chave da extensão).
    function links(origem, destino) {
        const o = encodeURIComponent(origem), d = encodeURIComponent(destino);
        return {
            rota: `https://www.google.com/maps/dir/?api=1&origin=${o}&destination=${d}&travelmode=driving`,
            onibus: `https://www.google.com/search?q=${encodeURIComponent('passagem de ônibus de ' + origem + ' para ' + destino)}`,
            aviao: `https://www.google.com/travel/flights?q=${encodeURIComponent('voos de ' + origem + ' para ' + destino)}`,
        };
    }

    const api = { PADROES, num, haversine, lerGeocodificacao, lerRota, urlGeocodificacao, urlRota, custoCarro, custoOnibus, custoAviao, comparar, brl, duracao, km1, links };
    if (typeof module !== 'undefined' && module.exports) { module.exports = api; return; }

    // ---------- rede (navegador) ----------
    async function buscarJson(url) {
        const r = await fetch(url, { headers: { 'Accept': 'application/json' }, credentials: 'omit' });
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.json();
    }
    root.CBViagem = Object.assign({}, api, {
        async localizar(texto) {
            const lista = lerGeocodificacao(await buscarJson(urlGeocodificacao(texto)));
            if (!lista.length) throw new Error('Não encontrei “' + texto + '”. Tente o nome da cidade e o estado, por exemplo: Toledo, PR.');
            return lista;
        },
        async rota(a, b) {
            for (const servidor of SERVIDORES_ROTA) {
                try {
                    const r = lerRota(await buscarJson(urlRota(a, b, servidor)));
                    if (r) return Object.assign({ aproximada: false }, r);
                } catch (e) { /* tenta o próximo */ }
            }
            // sem rota (servidor ocupado ou sem estrada): linha reta × 1,25 de fator de curva, avisando que é aproximado
            const km = haversine(a, b) * 1.25;
            return { km, minutos: Math.round((km / 75) * 60), aproximada: true };
        },
    });
})(typeof window !== 'undefined' ? window : globalThis);
