// ============================================================================
// ref-artigos.js — Acha referências a artigos de lei dentro de um texto (os
// comentários e o gabarito comentado de uma questão do QConcursos) e sabe
// montar o link da lei no Planalto. Módulo puro (sem DOM, sem storage), usado
// por três lugares: qconcursos/artigos-erros.js (captura), planalto/artigos-erros.js
// (painel) e o popup (revisão). Por isso não depende de nada da extensão e
// também roda no Node (ver dados-config/testes/ref-artigos.test.js).
//
// As chaves de lei seguem EXATAMENTE as de CBArtigos.detectarLei()
// (planalto/cb-artigos-lista.js): 'cf88' para a Constituição e 'l' + número
// para o resto ('l13105' = CPC, 'l2848' = Código Penal, 'l5452' = CLT...).
// Assim a referência capturada no QConcursos casa com a página do Planalto
// sem nenhuma tabela de tradução no meio.
//
// Regra de ouro: melhor NÃO achar do que achar errado. Quando a lei não está
// escrita junto do artigo, só a matéria da questão pode sugerir uma (e a
// referência fica marcada como `inferida`). Sem pista nenhuma, `lei` é null e
// quem decide é a pessoa, no painel do Planalto.
// ============================================================================
(function (raiz) {
    'use strict';

    const PL = 'https://www.planalto.gov.br/ccivil_03/';
    const L = '(?<![A-Za-zÀ-ÿ])'; // não colado em letra, antes
    const R = '(?![A-Za-zÀ-ÿ])';  // não colado em letra, depois
    const NUM = '\\s*(?:n[ºo°.]*\\s*)?';
    const DL = 'Decreto-?\\s*Lei';

    // nomes: formas como a lei aparece escrita. Siglas ficam SEM a flag `i` de
    // propósito ("CC" em maiúsculo; "cc" solto não é o Código Civil).
    const LEIS = [
        { chave: 'cf88', sigla: 'CF', nome: 'Constituição Federal', url: PL + 'constituicao/constituicao.htm',
          nomes: [new RegExp(L + '(?:CF|CRFB)(?:\\s*\\/?\\s*(?:19)?88)?' + R), /Constitui[çc][ãa]o(?:\s+(?:Federal|da\s+Rep[úu]blica))?(?:\s+de\s+1988)?(?!\s+(?:Estadual|do\s+Estado))/i, /Carta\s+Magna/i],
          materias: [/constitucional/i] },
        { chave: 'l13105', sigla: 'CPC', nome: 'Código de Processo Civil', url: PL + '_ato2015-2018/2015/lei/l13105.htm',
          nomes: [new RegExp(L + 'N?CPC(?:\\s*\\/?\\s*(?:20)?15)?' + R + '(?!\\s*\\/\\s*(?:19)?73)'), /C[óo]digo\s+de\s+Processo\s+Civil(?!\s+de\s+1973)/i, new RegExp('Lei' + NUM + '13\\.?105', 'i')],
          materias: [/processual\s+civil/i] },
        { chave: 'l10406', sigla: 'CC', nome: 'Código Civil', url: PL + 'leis/2002/l10406compilada.htm',
          nomes: [new RegExp(L + 'CC(?:\\s*\\/?\\s*(?:20)?02)?' + R + '(?!\\s*\\/\\s*(?:19)?16)'), /C[óo]digo\s+Civil(?!\s+de\s+1916)/i, new RegExp('Lei' + NUM + '10\\.?406', 'i')],
          materias: [/direito\s+civil/i] },
        { chave: 'l2848', sigla: 'CP', nome: 'Código Penal', url: PL + 'decreto-lei/del2848compilado.htm',
          nomes: [new RegExp(L + 'CP' + R), /C[óo]digo\s+Penal(?!\s+Militar)/i, new RegExp(DL + NUM + '2\\.?848', 'i')],
          materias: [/direito\s+penal/i] },
        { chave: 'l3689', sigla: 'CPP', nome: 'Código de Processo Penal', url: PL + 'decreto-lei/del3689compilado.htm',
          nomes: [new RegExp(L + 'CPP' + R), /C[óo]digo\s+de\s+Processo\s+Penal(?!\s+Militar)/i, new RegExp(DL + NUM + '3\\.?689', 'i')],
          materias: [/processual\s+penal/i] },
        { chave: 'l5452', sigla: 'CLT', nome: 'CLT', url: PL + 'decreto-lei/del5452.htm',
          nomes: [new RegExp(L + 'CLT' + R), /Consolida[çc][ãa]o\s+das\s+Leis\s+do\s+Trabalho/i, new RegExp(DL + NUM + '5\\.?452', 'i')],
          materias: [/trabalho/i] },
        { chave: 'l8078', sigla: 'CDC', nome: 'Código de Defesa do Consumidor', url: PL + 'leis/l8078compilado.htm',
          nomes: [new RegExp(L + 'CDC' + R), /C[óo]digo\s+de\s+Defesa\s+do\s+Consumidor/i, new RegExp('Lei' + NUM + '8\\.?078', 'i')],
          materias: [/consumidor/i] },
        { chave: 'l5172', sigla: 'CTN', nome: 'Código Tributário Nacional', url: PL + 'leis/l5172compilado.htm',
          nomes: [new RegExp(L + 'CTN' + R), /C[óo]digo\s+Tribut[áa]rio\s+Nacional/i, new RegExp('Lei' + NUM + '5\\.?172', 'i')],
          materias: [/tribut[áa]rio/i] },
        { chave: 'l8069', sigla: 'ECA', nome: 'Estatuto da Criança e do Adolescente', url: PL + 'leis/l8069.htm',
          nomes: [new RegExp(L + 'ECA' + R), /Estatuto\s+da\s+Crian[çc]a\s+e\s+do\s+Adolescente/i, new RegExp('Lei' + NUM + '8\\.?069', 'i')],
          materias: [] },
        { chave: 'l4657', sigla: 'LINDB', nome: 'LINDB', url: PL + 'decreto-lei/del4657compilado.htm',
          nomes: [new RegExp(L + 'LINDB' + R), /Lei\s+de\s+Introdu[çc][ãa]o\s+[àa]s\s+Normas\s+do\s+Direito\s+Brasileiro/i, new RegExp(DL + NUM + '4\\.?657', 'i')],
          materias: [] },
        { chave: 'l8112', sigla: 'Lei 8.112', nome: 'Lei 8.112/90 (servidores federais)', url: PL + 'leis/l8112cons.htm',
          nomes: [new RegExp('Lei' + NUM + '8\\.?112', 'i'), /Estatuto\s+dos\s+Servidores/i, new RegExp(L + 'RJU' + R)],
          materias: [] },
        { chave: 'l9784', sigla: 'Lei 9.784', nome: 'Lei 9.784/99 (processo administrativo)', url: PL + 'leis/l9784.htm',
          nomes: [new RegExp('Lei' + NUM + '9\\.?784', 'i'), /Lei\s+do\s+Processo\s+Administrativo/i],
          materias: [] },
        { chave: 'l8429', sigla: 'Lei 8.429', nome: 'Lei 8.429/92 (improbidade)', url: PL + 'leis/l8429.htm',
          nomes: [new RegExp('Lei' + NUM + '8\\.?429', 'i'), /Lei\s+de\s+Improbidade(?:\s+Administrativa)?/i, new RegExp(L + 'LIA' + R)],
          materias: [] },
        { chave: 'l14133', sigla: 'Lei 14.133', nome: 'Lei 14.133/21 (licitações)', url: PL + '_ato2019-2022/2021/lei/l14133.htm',
          nomes: [new RegExp('Lei' + NUM + '14\\.?133', 'i'), /Nova\s+Lei\s+de\s+Licita[çc][õo]es/i],
          materias: [] },
        { chave: 'l12016', sigla: 'Lei 12.016', nome: 'Lei 12.016/09 (mandado de segurança)', url: PL + '_ato2007-2010/2009/lei/l12016.htm',
          nomes: [new RegExp('Lei' + NUM + '12\\.?016', 'i'), /Lei\s+do\s+Mandado\s+de\s+Seguran[çc]a/i],
          materias: [] },
        { chave: 'l6830', sigla: 'LEF', nome: 'Lei de Execução Fiscal', url: PL + 'leis/l6830.htm',
          nomes: [new RegExp('Lei' + NUM + '6\\.?830', 'i'), new RegExp(L + 'LEF' + R)],
          materias: [] },
        { chave: 'l9099', sigla: 'Lei 9.099', nome: 'Lei 9.099/95 (juizados especiais)', url: PL + 'leis/l9099.htm',
          nomes: [new RegExp('Lei' + NUM + '9\\.?099', 'i')],
          materias: [] },
        { chave: 'l12527', sigla: 'LAI', nome: 'Lei de Acesso à Informação', url: PL + '_ato2011-2014/2011/lei/l12527.htm',
          nomes: [new RegExp('Lei' + NUM + '12\\.?527', 'i'), /Lei\s+de\s+Acesso\s+[àa]\s+Informa[çc][ãa]o/i, new RegExp(L + 'LAI' + R)],
          materias: [] },
        { chave: 'l13709', sigla: 'LGPD', nome: 'LGPD', url: PL + '_ato2015-2018/2018/lei/l13709.htm',
          nomes: [new RegExp('Lei' + NUM + '13\\.?709', 'i'), new RegExp(L + 'LGPD' + R)],
          materias: [] }
    ];

    // formas globais pré-compiladas (a flag g guarda estado: lastIndex é zerado a cada uso)
    const NOMES_G = LEIS.map((lei) => ({
        chave: lei.chave,
        res: lei.nomes.map((re) => new RegExp(re.source, re.flags.includes('g') ? re.flags : re.flags + 'g'))
    }));
    // "Lei 12.345/2010" ou "Decreto-Lei 1.234" de uma lei fora da tabela: a chave
    // ainda é calculável ('l12345'), só não há link pronto.
    const RE_LEI_GENERICA = new RegExp('(?:' + DL + '|Lei(?:\\s+Federal|\\s+Ordin[áa]ria)?)' + NUM + '(\\d{1,2}\\.?\\d{3})(?:\\s*\\/\\s*(\\d{2,4}))?', 'gi');
    const RE_LEI_COMPLEMENTAR = /Lei\s+Complementar/i;

    const POR_CHAVE = {};
    LEIS.forEach((lei) => { POR_CHAVE[lei.chave] = lei; });

    function leiPorChave(chave) { return POR_CHAVE[chave] || null; }
    function nomeDaLei(chave) {
        const lei = leiPorChave(chave);
        if (lei) return lei.sigla;
        if (chave === null || chave === undefined) return 'Lei não identificada';
        const m = /^l(\d{3,5})$/.exec(chave);
        return m ? 'Lei ' + m[1].replace(/(\d)(?=(\d{3})$)/, '$1.') : String(chave).toUpperCase();
    }
    function nomeCompletoDaLei(chave) {
        const lei = leiPorChave(chave);
        return lei ? lei.nome : nomeDaLei(chave);
    }

    // Planalto usa âncoras #art279 (e #art311a para "311-A").
    function ancoraDoArtigo(artigo, sufixo) {
        return '#art' + String(artigo) + (sufixo ? String(sufixo).toLowerCase() : '');
    }
    function urlDaLei(chave, artigo, sufixo) {
        const lei = leiPorChave(chave);
        if (!lei) return null;
        return artigo ? lei.url + ancoraDoArtigo(artigo, sufixo) : lei.url;
    }
    // "1196" → "1.196"; de 1 a 9 leva o ordinal ("Art. 5º"), como a lei escreve
    function numeroLegivel(artigo) {
        const n = parseInt(artigo, 10);
        if (isNaN(n)) return String(artigo);
        if (n <= 9) return n + 'º';
        return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    }
    function rotuloDoArtigo(ref) {
        return 'Art. ' + numeroLegivel(ref.artigo) + (ref.sufixo ? '-' + ref.sufixo : '');
    }
    function chaveReferencia(ref) {
        return (ref.lei || '?') + ':' + ref.artigo + (ref.sufixo || '');
    }

    // Matéria da questão (ex.: "Direito Processual Civil") → lei padrão quando o
    // comentário diz só "art. 279". A ordem importa: "processual civil" antes de "civil".
    const ORDEM_MATERIAS = ['l3689', 'l13105', 'l2848', 'l10406', 'cf88', 'l5172', 'l8078', 'l5452'];
    function leiPorMateria(materia) {
        if (!materia) return null;
        const texto = String(materia);
        for (const chave of ORDEM_MATERIAS) {
            const lei = POR_CHAVE[chave];
            if (lei && lei.materias.some((re) => re.test(texto))) return chave;
        }
        return null;
    }

    function acharLeis(trecho) {
        const achados = [];
        NOMES_G.forEach((grupo) => {
            grupo.res.forEach((re) => {
                re.lastIndex = 0;
                let m;
                while ((m = re.exec(trecho))) {
                    achados.push({ chave: grupo.chave, ini: m.index, fim: m.index + m[0].length });
                    if (m[0].length === 0) re.lastIndex++;
                }
            });
        });
        // genérico: só entra o que NÃO foi coberto por uma lei da tabela
        RE_LEI_GENERICA.lastIndex = 0;
        let g;
        while ((g = RE_LEI_GENERICA.exec(trecho))) {
            const ini = g.index, fim = g.index + g[0].length;
            const coberto = achados.some((a) => a.ini <= ini && a.fim >= fim - 1);
            if (coberto) continue;
            if (RE_LEI_COMPLEMENTAR.test(trecho.slice(Math.max(0, ini - 1), fim))) continue;
            achados.push({ chave: 'l' + g[1].replace('.', ''), ini, fim });
        }
        return achados;
    }

    // ---- grupos de artigos: "art. 279", "arts. 276 a 283", "arts. 5º, 6º e 7º", "art. 311-A" ----
    // "5º"/"5o"/"5°" só conta como ordinal quando está COLADO no número (senão o "o" de
    // "art. 5 ou art. 6" viraria ordinal e comeria a palavra).
    const NUMTOK = '\\d{1,4}(?:\\.\\d{3})?(?:[ºo°](?![A-Za-zà-ÿ]))?(?:\\s*-\\s*[A-Z](?![A-Za-z]))?';
    const RE_GRUPO = new RegExp('\\b(?:arts?\\.?|artigos?)(?![a-zà-ÿ])\\s*(' + NUMTOK + '(?:\\s*(?:,|;|\\be\\b|\\ba\\b|\\bao\\b|–)\\s*' + NUMTOK + ')*)', 'gi');
    const RE_TOKEN = /(\d{1,4}(?:\.\d{3})?)(?:[ºo°](?![A-Za-zà-ÿ]))?(?:\s*-\s*([A-Z])(?![A-Za-z]))?\s*(,|;|\be\b|\ba\b|\bao\b|–)?/gi;
    const RE_DETALHE = /^[\s,;]*(caput|par[aá]grafo\s+[uú]nico|§\s*\d+\s*[ºo°]?(?:\s*,?\s*(?:inc(?:iso)?s?\.?\s*)?[IVXLC]+\b)?|inc(?:iso)?s?\.?\s*[IVXLC]+\b|al[ií]nea\s*["“]?[a-z]["”]?)/i;
    const MAX_ARTIGO = 2200;
    const MAX_RANGE = 25;

    function normalizarNumero(txt) { return parseInt(String(txt).replace('.', ''), 10); }

    function expandirGrupo(grupo) {
        const itens = [];
        const tokens = [];
        RE_TOKEN.lastIndex = 0;
        let m;
        while ((m = RE_TOKEN.exec(grupo)) && m[0].length) {
            tokens.push({ n: normalizarNumero(m[1]), sufixo: m[2] ? m[2].toUpperCase() : '', sep: (m[3] || '').toLowerCase() });
        }
        for (let i = 0; i < tokens.length; i++) {
            const t = tokens[i];
            const prox = tokens[i + 1];
            const ehIntervalo = (t.sep === 'a' || t.sep === 'ao' || t.sep === '–') && prox && !t.sufixo && !prox.sufixo
                && prox.n > t.n && prox.n - t.n <= MAX_RANGE;
            if (ehIntervalo) {
                for (let n = t.n; n <= prox.n; n++) itens.push({ n, sufixo: '' });
                i++; // o fim do intervalo já foi consumido
            } else {
                itens.push({ n: t.n, sufixo: t.sufixo });
            }
        }
        return itens.filter((x) => x.n > 0 && x.n <= MAX_ARTIGO);
    }

    function entreTrechoLimpo(entre) {
        // sem fim de frase nem outro "art." no meio: a lei citada ainda é a do artigo
        return !/[.!?]\s+[A-ZÀ-Ý]/.test(entre) && !/\bart/i.test(entre);
    }

    // lei escrita DEPOIS do artigo: "art. 279, caput, do CPC", "art. 5º da CF/88"
    function leiDepois(texto, fimGrupo) {
        const janela = texto.slice(fimGrupo, fimGrupo + 90);
        let melhor = null;
        acharLeis(janela).forEach((a) => {
            if (a.ini > 70) return;
            if (!entreTrechoLimpo(janela.slice(0, a.ini))) return;
            if (!melhor || a.ini < melhor.ini) melhor = a;
        });
        return melhor ? { chave: melhor.chave, distancia: melhor.ini } : null;
    }
    // lei escrita ANTES do artigo: "CPC, art. 279", "No CPC: art. 279"
    const RE_LIGACAO_ANTES = /^[\s,;:()\-–]*(?:(?:no|na|nos|nas|do|da|dos|das|o|a|os|as|segundo|conforme|previsto|prevista|prevê|dispõe|disp[õo]e|art(?:igos?)?\.?)\s+){0,3}$/i;
    function leiAntes(texto, iniGrupo) {
        const base = Math.max(0, iniGrupo - 60);
        const janela = texto.slice(base, iniGrupo);
        let melhor = null;
        acharLeis(janela).forEach((a) => {
            const entre = janela.slice(a.fim);
            if (entre.length > 28 || !RE_LIGACAO_ANTES.test(entre)) return;
            if (!melhor || a.fim > melhor.fim) melhor = a;
        });
        return melhor ? { chave: melhor.chave, distancia: janela.length - melhor.fim } : null;
    }

    function extrairReferencias(textoOriginal, opcoes) {
        const opts = opcoes || {};
        const texto = String(textoOriginal || '').replace(/ /g, ' ').replace(/[ \t]+/g, ' ');
        // sem lei escrita junto do artigo: primeiro a lei que o enunciado cita (opts.leiPadrao), depois a da matéria
        const leiDaMateria = opts.leiPadrao || leiPorMateria(opts.materia);

        // passada 1: cada grupo de artigos ("art. 279", "arts. 5º, 6º e 7º") com a lei que o texto escreveu junto dele
        const grupos = [];
        RE_GRUPO.lastIndex = 0;
        let m;
        while ((m = RE_GRUPO.exec(texto))) {
            const itens = expandirGrupo(m[1]);
            if (!itens.length) continue;
            const ini = m.index;
            const fim = m.index + m[0].length;
            const dep = leiDepois(texto, fim);
            const ant = leiAntes(texto, ini);
            let lei = null;
            if (dep && ant) lei = (dep.distancia <= ant.distancia ? dep : ant).chave;
            else if (dep || ant) lei = (dep || ant).chave;
            grupos.push({ ini, fim, itens, lei, explicita: !!lei, inferida: false });
        }

        // passada 2: sem lei escrita, vale a do grupo vizinho ("art. 279 e art. 280 do CPC" → os dois são do CPC);
        // por último, a lei padrão da matéria da questão (marcada como inferida)
        for (let i = grupos.length - 1; i >= 0; i--) {
            const g = grupos[i];
            if (g.lei) continue;
            const ant = grupos[i - 1];
            const prox = grupos[i + 1];
            const entreCom = (a, b) => /^[\s,;]*(?:(?:e|ou)\s+)?(?:(?:o|a|os|as)\s+)?$/i.test(texto.slice(a.fim, b.ini));
            if (ant && ant.explicita && g.ini - ant.fim < 120 && entreAntes(texto, ant, g)) g.lei = ant.lei;
            else if (prox && prox.explicita && prox.ini - g.fim <= 40 && entreCom(g, prox)) g.lei = prox.lei;
            else if (leiDaMateria) { g.lei = leiDaMateria; g.inferida = true; }
        }

        const vistos = new Map();
        const resultado = [];
        grupos.forEach((g) => {
            const det = RE_DETALHE.exec(texto.slice(g.fim, g.fim + 60));
            const detalhe = det ? det[1].replace(/\s+/g, ' ').trim() : '';
            const trecho = texto.slice(Math.max(0, g.ini - 40), Math.min(texto.length, g.fim + 70)).replace(/\s+/g, ' ').trim();
            g.itens.forEach((it, idx) => {
                const ref = { lei: g.lei, artigo: String(it.n), sufixo: it.sufixo, detalhe: idx === 0 ? detalhe : '', trecho, inferida: g.inferida };
                const chave = chaveReferencia(ref);
                const anterior = vistos.get(chave);
                if (anterior) {
                    if (!anterior.detalhe && ref.detalhe) anterior.detalhe = ref.detalhe;
                    return;
                }
                vistos.set(chave, ref);
                resultado.push(ref);
            });
        });
        return resultado;
    }

    // "CPC, art. 279 e art. 280": o grupo seguinte herda a lei do anterior só se entre os dois
    // não há fim de frase nem outra lei citada
    function entreAntes(texto, anterior, atual) {
        const entre = texto.slice(anterior.fim, atual.ini);
        if (/[.!?]\s+[A-ZÀ-Ý]/.test(entre)) return false;
        return acharLeis(entre).length === 0;
    }

    // A lei que um texto cita, se for UMA só (ex.: o enunciado "Segundo o CPC, ..."). Com duas ou
    // mais leis diferentes não dá para saber qual vale para o comentário, então devolve null.
    function leiDoTexto(texto) {
        const chaves = new Set(acharLeis(String(texto || '').replace(/\s+/g, ' ')).map((a) => a.chave));
        return chaves.size === 1 ? Array.from(chaves)[0] : null;
    }

    const API = { LEIS, leiPorChave, nomeDaLei, nomeCompletoDaLei, urlDaLei, ancoraDoArtigo, numeroLegivel, rotuloDoArtigo, chaveReferencia, leiPorMateria, leiDoTexto, extrairReferencias };
    if (typeof module !== 'undefined' && module.exports) module.exports = API;
    raiz.CBRefArtigos = API;
})(typeof window !== 'undefined' ? window : globalThis);
