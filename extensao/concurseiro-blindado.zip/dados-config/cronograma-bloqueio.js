// ===================== BLOQUEIO DE SITES — SISTEMA ÚNICO =====================
//
// ANTES existiam DOIS sistemas de bloqueio que não se conversavam:
//
//   1) "bloqueio por cronograma": uma lista fixa e ESCONDIDA de sites de
//      distração (reddit, instagram, tiktok...) que redirecionava a aba pra
//      tela escura SOZINHA sempre que um bloco do cronograma estava no ar.
//      Não tinha nenhuma tela na extensão pra ver ou editar essa lista —
//      era literalmente código-fonte. Era o "bloqueou do nada" clássico.
//
//   2) "bloqueio manual": a pergunta que aparecia DENTRO do popup da
//      extensão ("Quer bloquear este site?"), gravando em outra chave,
//      com outra regra de validade, e ainda uma TERCEIRA chave
//      (cbEscolhasExcecaoPorHost) usada só pra PDF/vídeo/legislação.
//
// Três fontes de verdade pro mesmo assunto = a pessoa respondia numa e
// continuava bloqueada pela outra.
//
// AGORA é um sistema só, com uma regra só:
//
//   • NADA é bloqueado automaticamente. Não existe mais lista secreta de
//     sites de distração, nem bloqueio automático por bloco de cronograma.
//   • Em sites de questões (QConcursos, TEC, Gran, Estratégia) a extensão
//     NUNCA pergunta e NUNCA bloqueia — é onde a pessoa deveria estar.
//   • Em QUALQUER outro site (YouTube, PDF, legislação, notícia, o que
//     for), com o cronômetro rodando, a pergunta "quer bloquear?" aparece
//     NA PRÓPRIA PÁGINA (ver cbMostrarPerguntaBloqueio em
//     overlay-global/global_overlay.js) — nunca mais dentro do popup.
//   • Só depois de a pessoa responder "Bloquear" é que a tela escura passa
//     a aparecer naquele site, e só enquanto o cronômetro estiver rodando.
//
// Chaves em chrome.storage.local (as únicas que mandam no bloqueio):
//   cbSitesBloqueadosManual     [host, ...]  → responderam "Bloquear"
//   cbSitesLiberados            [host, ...]  → responderam "Não bloquear"
//   cbBloqueioManualDispensados {host: ts}   → responderam "Agora não" (1h)
//   cbLiberadosTemp             {host: ts}   → "preciso deste site agora" (5 min)
//
// Tudo isso roda no service worker, então funciona com o popup fechado.

const CB_DISPENSA_MS = 60 * 60 * 1000; // "Agora não" cala a pergunta por 1h

function cbCronogramaHostname(url) {
    try { return new URL(url).hostname; } catch (e) { return null; }
}

// Normaliza o host do jeito que ele é gravado nas listas (sem "www.").
function cbNormalizarHost(hostname) {
    if (!hostname) return '';
    return String(hostname).trim().toLowerCase().replace(/^www\./, '');
}

// Um host "bate" com uma entrada da lista se for ele mesmo ou um subdomínio
// dele — assim bloquear "youtube.com" também cobre "m.youtube.com".
function cbHostNaLista(hostname, lista) {
    const host = cbNormalizarHost(hostname);
    if (!host) return false;
    return (lista || []).some((h) => {
        const alvo = cbNormalizarHost(h);
        return alvo && (host === alvo || host.endsWith('.' + alvo));
    });
}

// Sites de questões nunca entram no sistema de bloqueio, nem pra perguntar.
// isQuestionBankHost() vem de background.js (mesmo escopo global do service
// worker, ver importScripts lá em cima daquele arquivo).
function cbEhSiteDeQuestoes(hostname) {
    try { return isQuestionBankHost(hostname); } catch (e) { return false; }
}

function cbCronogramaHojeStr() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// Mantidas porque alarme-cronograma.js/sentinela-nativa.js ainda usam o
// cronograma pra OUTRAS coisas (avisar que o bloco começou, dizer qual
// matéria é a de agora). O cronograma só não bloqueia site nenhum mais.
function cbCronogramaMinutosAgora() {
    const agora = new Date();
    return agora.getHours() * 60 + agora.getMinutes();
}

function cbCronogramaBlocoAtivo(blocos) {
    const min = cbCronogramaMinutosAgora();
    return (blocos || []).find((b) => {
        const [ih, im] = b.inicio.split(':').map(Number);
        const [fh, fm] = b.fim.split(':').map(Number);
        return min >= (ih * 60 + im) && min < (fh * 60 + fm);
    }) || null;
}

// ===================== MIGRAÇÃO DAS CHAVES ANTIGAS =====================
// Quem já usava a versão anterior tinha decisões espalhadas em
// cbEscolhasExcecaoPorHost ('bloquear' / 'permitido'). Traz tudo pras duas
// listas novas uma única vez e apaga a chave velha, pra não sobrar um
// sistema fantasma decidindo coisa por baixo.
function cbMigrarDecisoesAntigas() {
    chrome.storage.local.get(
        ['cbEscolhasExcecaoPorHost', 'cbSitesBloqueadosManual', 'cbSitesLiberados', 'cbCronogramaSitesCustom'],
        (res) => {
            const antigas = res.cbEscolhasExcecaoPorHost;
            const listaCustomAntiga = res.cbCronogramaSitesCustom;
            if (!antigas && !listaCustomAntiga) return;

            const bloqueados = new Set((res.cbSitesBloqueadosManual || []).map(cbNormalizarHost));
            const liberados = new Set((res.cbSitesLiberados || []).map(cbNormalizarHost));

            Object.keys(antigas || {}).forEach((host) => {
                const h = cbNormalizarHost(host);
                if (!h) return;
                if (antigas[host] === 'bloquear') bloqueados.add(h);
                else if (antigas[host] === 'permitido') liberados.add(h);
            });

            // Sites que a pessoa tinha adicionado à lista antiga de
            // distração viram bloqueio normal (era isso que ela queria).
            (listaCustomAntiga || []).forEach((host) => {
                const h = cbNormalizarHost(host);
                if (h) bloqueados.add(h);
            });

            // Se um host ficou nas duas, "não bloquear" ganha — é a decisão
            // menos invasiva e a que a pessoa reclama quando é ignorada.
            liberados.forEach((h) => bloqueados.delete(h));

            chrome.storage.local.set({
                cbSitesBloqueadosManual: Array.from(bloqueados),
                cbSitesLiberados: Array.from(liberados)
            }, () => {
                chrome.storage.local.remove([
                    'cbEscolhasExcecaoPorHost',
                    'cbCronogramaSitesCustom',
                    'cbCronogramaSitesDesativados'
                ]);
            });
        }
    );
}
cbMigrarDecisoesAntigas();

// ===================== A ÚNICA REGRA DE BLOQUEIO =====================
// Bloqueia se, e só se: o cronômetro está rodando E a pessoa mandou
// bloquear esse site E ela não pediu os 5 min de liberação.
//
// COMO o bloqueio aparece: a TELA ESCURA é desenhada pelo content script
// EM CIMA da própria página (cbMostrarTelaEscura, em
// overlay-global/global_overlay.js) — a aba continua no site, só fica
// coberta. O service worker não troca mais a URL da aba.
//
// ANTES ele trocava: a aba era levada pra foco/bloqueio.html, o que fazia
// o site sumir de verdade (perdia o scroll, perdia formulário preenchido,
// e o "voltar" do navegador virava uma bagunça). Isso agora só acontece
// como PLANO B, quando o content script não consegue rodar naquela aba —
// visualizador de PDF nativo do Chrome, páginas internas do navegador,
// aba que ainda não terminou de carregar. Sem esse plano B, esses casos
// simplesmente não teriam bloqueio nenhum.
function verificarBloqueio(tabId, url) {
    if (!tabId || !url || !url.startsWith('http')) return;
    const hostname = cbCronogramaHostname(url);
    if (!hostname) return;
    if (cbEhSiteDeQuestoes(hostname)) return; // site de questões: nunca

    chrome.storage.local.get(['sessionState', 'cbSitesBloqueadosManual', 'cbLiberadosTemp'], (res) => {
        if (res.sessionState !== 'running') return;
        if (!cbHostNaLista(hostname, res.cbSitesBloqueadosManual)) return;

        const liberados = res.cbLiberadosTemp || {};
        const chave = cbNormalizarHost(hostname);
        if (liberados[chave] && liberados[chave] > Date.now()) return;

        cbPedirTelaEscura(tabId, url, chave);
    });
}

// ===================== PEDIR A TELA ESCURA (com paciência) =====================
// BUG que fazia a tela escura NUNCA aparecer:
//
// chrome.tabs.onUpdated dispara com changeInfo.url no COMMIT da navegação —
// isto é, assim que o endereço muda, muito antes da página existir. Só que
// o content script (global_overlay.js) é injetado em 'document_idle', lá no
// fim do carregamento. Resultado: o ping era mandado pra uma aba onde ainda
// não tinha ninguém pra ouvir, o sendMessage voltava com lastError, e o
// plano B (trocar a aba por foco/bloqueio.html) disparava na hora — TODA
// vez, em qualquer site. A corrida estava perdida antes de começar, então
// na prática só existia o plano B.
//
// Agora a gente insiste antes de desistir: tenta de novo algumas vezes,
// dando tempo do content script subir, e ainda tenta injetá-lo à força numa
// aba que ficou sem ele. Só se TODAS as tentativas falharem é que a página
// de bloqueio entra — que é o que deve acontecer em visualizador de PDF do
// navegador e páginas internas, onde content script realmente não roda.
const CB_ESPERAS_TELA_ESCURA = [0, 400, 1000, 2000]; // ms entre tentativas

function cbPedirTelaEscura(tabId, urlOriginal, chaveHost, tentativa) {
    const i = tentativa || 0;

    chrome.tabs.sendMessage(tabId, { action: 'cbAplicarTelaEscura' }, (resposta) => {
        const falhou = !!chrome.runtime.lastError || !resposta || !resposta.ok;
        if (!falhou) return; // content script assumiu: a aba fica no site, só escurecida

        // Talvez o script só não tenha sido injetado nesta aba (ela já estava
        // aberta antes de a permissão ser concedida, por exemplo).
        if (i === 1 && typeof cbInjetarOverlaySePreciso === 'function') {
            try { cbInjetarOverlaySePreciso(tabId); } catch (e) {}
        }

        if (i + 1 < CB_ESPERAS_TELA_ESCURA.length) {
            setTimeout(
                () => cbPedirTelaEscura(tabId, urlOriginal, chaveHost, i + 1),
                CB_ESPERAS_TELA_ESCURA[i + 1]
            );
            return;
        }

        // Esgotou: aqui content script não roda mesmo. Plano B — mas só se a
        // aba ainda estiver no mesmo site (nesses segundos todos a pessoa
        // pode ter navegado pra outro lugar, e trocar a URL dela agora seria
        // exatamente o tipo de sequestro de aba que a gente tirou fora).
        chrome.tabs.get(tabId, (tab) => {
            if (chrome.runtime.lastError || !tab || !tab.url) return;
            if (cbNormalizarHost(cbCronogramaHostname(tab.url)) !== chaveHost) return;

            const blockUrl = chrome.runtime.getURL('foco/bloqueio.html') +
                `?host=${encodeURIComponent(chaveHost)}` +
                `&url=${encodeURIComponent(tab.url)}`;
            chrome.tabs.update(tabId, { url: blockUrl });
        });
    });
}

// Nome antigo, mantido porque background.js e outros arquivos chamam por
// ele. Agora só existe uma verificação — não tem mais dois sistemas.
function verificarTodosOsBloqueios(tabId, url) {
    verificarBloqueio(tabId, url);
}
function verificarBloqueioManual(tabId, url) {
    verificarBloqueio(tabId, url);
}

// ===================== SAIR DA TELA DE BLOQUEIO QUANDO NÃO PRECISA MAIS =====================
// Se a pessoa desbloqueia o site (ou o cronômetro para) enquanto uma aba já
// está na tela escura, essa aba precisa voltar sozinha pro site — senão ela
// fica presa lá mesmo com o dado já corrigido, que é exatamente a sensação
// de "eu disse que não queria e continua bloqueando".
const CB_BLOQUEIO_HTML_PREFIXO = chrome.runtime.getURL('foco/bloqueio.html');

function cbRestaurarAbaSeNaoPrecisaMais(tab, ctx) {
    if (!tab || !tab.id || !tab.url || !tab.url.startsWith(CB_BLOQUEIO_HTML_PREFIXO)) return;
    let params;
    try { params = new URL(tab.url).searchParams; } catch (e) { return; }
    const host = params.get('host');
    const urlOriginal = params.get('url');
    if (!host || !urlOriginal) return;

    const chave = cbNormalizarHost(host);
    if (ctx.liberados[chave] && ctx.liberados[chave] > Date.now()) {
        chrome.tabs.update(tab.id, { url: urlOriginal });
        return;
    }

    const aindaBloqueado = ctx.sessionState === 'running' && cbHostNaLista(chave, ctx.listaManual);
    if (!aindaBloqueado) chrome.tabs.update(tab.id, { url: urlOriginal });
}

function cbVerificarLiberacoes() {
    chrome.storage.local.get(['sessionState', 'cbSitesBloqueadosManual', 'cbLiberadosTemp'], (res) => {
        const ctx = {
            sessionState: res.sessionState,
            listaManual: res.cbSitesBloqueadosManual || [],
            liberados: res.cbLiberadosTemp || {}
        };
        chrome.tabs.query({}, (tabs) => tabs.forEach((tab) => cbRestaurarAbaSeNaoPrecisaMais(tab, ctx)));
    });
}

// Pega toda navegação (aba nova, digitou URL, clicou link) e toda troca de aba ativa.
//
// Escuta 'status: complete' em vez de 'changeInfo.url': o evento de URL
// dispara no commit da navegação, quando a página ainda nem existe e o
// content script não foi injetado — era ali que o plano B disparava sem
// necessidade (ver comentário em cbPedirTelaEscura). Em 'complete' a página
// terminou de carregar, então o content script já está de pé e responde.
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status !== 'complete') return;
    if (!tab || !tab.url) return;
    verificarBloqueio(tabId, tab.url);
});
chrome.tabs.onActivated.addListener((activeInfo) => {
    chrome.tabs.get(activeInfo.tabId, (tab) => {
        if (chrome.runtime.lastError || !tab || !tab.url) return;
        verificarBloqueio(tab.id, tab.url);
    });
});

// Cobre a aba que já estava aberta antes de a pessoa mandar bloquear o site
// (sem isso, só pegaríamos a próxima navegação) e devolve as abas presas na
// tela escura quando o bloqueio deixa de valer.
cbCriarAlarmeSePreciso('cb-cronograma-check', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name !== 'cb-cronograma-check') return;
    chrome.tabs.query({}, (tabs) => {
        tabs.forEach((tab) => verificarBloqueio(tab.id, tab.url));
    });
    cbVerificarLiberacoes();
});

chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.sessionState || changes.cbSitesBloqueadosManual || changes.cbLiberadosTemp) {
        chrome.tabs.query({}, (tabs) => tabs.forEach((tab) => verificarBloqueio(tab.id, tab.url)));
        cbVerificarLiberacoes();
    }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || !message.action) return;

    // Resposta "Bloquear" na pergunta que aparece na própria página.
    if (message.action === 'cbBloquearSite') {
        const host = cbNormalizarHost(message.host);
        if (!host) { sendResponse({ ok: false }); return false; }
        chrome.storage.local.get(['cbSitesBloqueadosManual', 'cbSitesLiberados', 'cbBloqueioManualDispensados'], (res) => {
            const lista = (res.cbSitesBloqueadosManual || []).map(cbNormalizarHost);
            if (!lista.includes(host)) lista.push(host);
            // Sai das outras duas listas: uma decisão nova sempre substitui
            // a anterior, em vez de conviver com ela (era o bug de origem).
            const liberados = (res.cbSitesLiberados || []).map(cbNormalizarHost).filter((h) => h !== host);
            const dispensados = res.cbBloqueioManualDispensados || {};
            delete dispensados[host];
            chrome.storage.local.set({
                cbSitesBloqueadosManual: lista,
                cbSitesLiberados: liberados,
                cbBloqueioManualDispensados: dispensados
            }, () => {
                chrome.tabs.query({}, (tabs) => tabs.forEach((tab) => verificarBloqueio(tab.id, tab.url)));
                sendResponse({ ok: true });
            });
        });
        return true;
    }

    // Resposta "Não bloquear" — vale pra sempre e não pergunta mais.
    if (message.action === 'cbLiberarSite') {
        const host = cbNormalizarHost(message.host);
        if (!host) { sendResponse({ ok: false }); return false; }
        chrome.storage.local.get(['cbSitesBloqueadosManual', 'cbSitesLiberados', 'cbBloqueioManualDispensados'], (res) => {
            const lista = (res.cbSitesBloqueadosManual || []).map(cbNormalizarHost).filter((h) => h !== host);
            const liberados = (res.cbSitesLiberados || []).map(cbNormalizarHost);
            if (!liberados.includes(host)) liberados.push(host);
            const dispensados = res.cbBloqueioManualDispensados || {};
            delete dispensados[host];
            chrome.storage.local.set({
                cbSitesBloqueadosManual: lista,
                cbSitesLiberados: liberados,
                cbBloqueioManualDispensados: dispensados
            }, () => {
                cbVerificarLiberacoes();
                sendResponse({ ok: true });
            });
        });
        return true;
    }

    // Resposta "Agora não" — só cala a pergunta por 1h nesse site.
    if (message.action === 'cbAdiarPerguntaSite') {
        const host = cbNormalizarHost(message.host);
        if (!host) { sendResponse({ ok: false }); return false; }
        chrome.storage.local.get(['cbBloqueioManualDispensados'], (res) => {
            const dispensados = res.cbBloqueioManualDispensados || {};
            dispensados[host] = Date.now() + CB_DISPENSA_MS;
            chrome.storage.local.set({ cbBloqueioManualDispensados: dispensados }, () => sendResponse({ ok: true }));
        });
        return true;
    }

    // "Preciso deste site agora" na tela de bloqueio: 5 min e a aba volta.
    if (message.action === 'cronogramaLiberarHost') {
        const host = cbNormalizarHost(message.host);
        chrome.storage.local.get(['cbLiberadosTemp'], (res) => {
            const liberados = res.cbLiberadosTemp || {};
            liberados[host] = Date.now() + (message.minutos || 5) * 60 * 1000;
            chrome.storage.local.set({ cbLiberadosTemp: liberados }, () => {
                cbVerificarLiberacoes();
                sendResponse({ ok: true });
            });
        });
        return true;
    }

    // "Desbloquear de vez", clicado na própria tela de bloqueio.
    if (message.action === 'cbDesbloquearSite') {
        const host = cbNormalizarHost(message.host);
        chrome.storage.local.get(['cbSitesBloqueadosManual', 'cbSitesLiberados'], (res) => {
            const lista = (res.cbSitesBloqueadosManual || []).map(cbNormalizarHost).filter((h) => h !== host);
            const liberados = (res.cbSitesLiberados || []).map(cbNormalizarHost);
            if (host && !liberados.includes(host)) liberados.push(host);
            chrome.storage.local.set({
                cbSitesBloqueadosManual: lista,
                cbSitesLiberados: liberados
            }, () => {
                cbVerificarLiberacoes();
                sendResponse({ ok: true });
            });
        });
        return true;
    }

    // Volta um site pro estado "nunca decidido": a pergunta aparece de novo
    // na próxima visita. É o botão de desfazer que faltava antes.
    if (message.action === 'cbEsquecerDecisaoSite') {
        const host = cbNormalizarHost(message.host);
        chrome.storage.local.get(['cbSitesBloqueadosManual', 'cbSitesLiberados', 'cbBloqueioManualDispensados'], (res) => {
            const dispensados = res.cbBloqueioManualDispensados || {};
            delete dispensados[host];
            chrome.storage.local.set({
                cbSitesBloqueadosManual: (res.cbSitesBloqueadosManual || []).map(cbNormalizarHost).filter((h) => h !== host),
                cbSitesLiberados: (res.cbSitesLiberados || []).map(cbNormalizarHost).filter((h) => h !== host),
                cbBloqueioManualDispensados: dispensados
            }, () => {
                cbVerificarLiberacoes();
                sendResponse({ ok: true });
            });
        });
        return true;
    }

    // Compatibilidade: quem ainda mandar essas mensagens antigas só provoca
    // uma reverificação, sem criar bloqueio nenhum por conta própria.
    if (message.action === 'cronogramaAtualizado' || message.action === 'bloqueioManualAtualizado') {
        chrome.tabs.query({}, (tabs) => tabs.forEach((tab) => verificarBloqueio(tab.id, tab.url)));
        cbVerificarLiberacoes();
        sendResponse({ ok: true });
        return false;
    }
});
