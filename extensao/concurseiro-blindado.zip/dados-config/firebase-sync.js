// =====================================================================
// SINCRONIZAÇÃO COM O CELULAR — sem login do Google, via código de
// pareamento (como Netflix/TV faz: gera um código de 6 dígitos, o
// usuário digita no celular uma vez, e pronto).
// =====================================================================

const CB_FIREBASE_URL = "https://concurseiro-blindado-default-rtdb.firebaseio.com"; // CONFIRMAR: mesma URL exata do timer.html

console.log('[CB-Firebase] firebase-sync.js carregado.');

// ---------------------------------------------------------------------
// 1b) Grifos do Marcador de Texto (planalto/highlighter.js) — cada página
//    grifada fica numa chave própria (cbHighlights::<url>) no storage,
//    então isso não dá pra pegar com uma lista fixa de chaves como o
//    resto: precisa varrer o storage inteiro. Mesma lógica de agregação
//    já usada em planalto/paginas.js ("Central de Páginas"), só que
//    devolvendo os dados em vez de desenhar HTML.
// ---------------------------------------------------------------------
function cbColetarGrifosPlanalto(callback) {
    const PREFIXO = 'cbHighlights::';
    chrome.storage.local.get(null, (tudo) => {
        const paginas = Object.keys(tudo)
            .filter((k) => k.startsWith(PREFIXO))
            .map((k) => {
                const lista = Array.isArray(tudo[k]) ? tudo[k] : [];
                const url = k.slice(PREFIXO.length);
                const titulo = lista.length ? (lista[0].titulo || url) : url;
                const ultimaAtualizacao = lista.reduce((max, g) => Math.max(max, g.criadoEm || 0), 0);
                const grifos = lista.slice()
                    .sort((a, b) => (b.criadoEm || 0) - (a.criadoEm || 0))
                    .slice(0, 5)
                    .map((g) => ({ texto: (g.texto || '').slice(0, 280), cor: g.cor || 'amarelo', nota: (g.nota || '').slice(0, 200) }));
                return { url, titulo: (titulo || url).slice(0, 120), quantidade: lista.length, ultimaAtualizacao, grifos };
            })
            .filter((p) => p.quantidade > 0)
            .sort((a, b) => b.ultimaAtualizacao - a.ultimaAtualizacao)
            .slice(0, 15);
        callback(paginas);
    });
}

// ---------------------------------------------------------------------
// 1) deviceId — gerado UMA vez por instalação da extensão, salvo local.
//    É o identificador real dos dados; o código de 6 dígitos é só uma
//    forma temporária e descartável de "apontar" pra ele.
// ---------------------------------------------------------------------
function cbObterDeviceId(callback) {
    chrome.storage.local.get(['cbDeviceId'], (res) => {
        if (res.cbDeviceId) return callback(res.cbDeviceId);
        const novoId = 'dev_' + crypto.randomUUID();
        chrome.storage.local.set({ cbDeviceId: novoId }, () => callback(novoId));
    });
}

async function cbFirebasePut(path, valor) {
    try {
        const resp = await fetch(`${CB_FIREBASE_URL}/${path}.json`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(valor)
        });
        console.log(`[CB-Firebase] PUT ${path} → status ${resp.status}`);
    } catch (e) {
        console.warn(`[CB-Firebase] Falha ao gravar em ${path}:`, e);
    }
}

// PATCH faz uma mescla (só atualiza os campos enviados), diferente do PUT
// que substitui o nó inteiro. Usamos isso pro envio de estado porque, com
// PUT, cada atualização do PC apagava o campo "comandoRemoto" que o
// celular tivesse acabado de escrever — mesmo que a leitura da extensão
// ainda não tivesse acontecido. Com PATCH, os dois convivem em paz.
async function cbFirebasePatch(path, valor) {
    try {
        const resp = await fetch(`${CB_FIREBASE_URL}/${path}.json`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(valor)
        });
        console.log(`[CB-Firebase] PATCH ${path} → status ${resp.status}`);
    } catch (e) {
        console.warn(`[CB-Firebase] Falha ao mesclar em ${path}:`, e);
    }
}

// ---------------------------------------------------------------------
// 2) Gerar código de pareamento (chamado pelo botão "Parear celular"
//    na tela de configurações da extensão).
//    Expira sozinho: grava um timestamp e o timer.html/regra do banco
//    pode ignorar códigos com mais de, por exemplo, 10 minutos.
// ---------------------------------------------------------------------
function cbGerarCodigoPareamento(callback) {
    cbObterDeviceId((deviceId) => {
        const codigo = String(Math.floor(100000 + Math.random() * 900000)); // 6 dígitos
        cbFirebasePut(`pareamentos/${codigo}`, {
            deviceId,
            criadoEm: Date.now()
        }).then(() => callback(codigo));
    });
}

// Exemplo de uso na tela de configurações (popup/options da extensão):
//
//   document.getElementById('btnParearCelular').addEventListener('click', () => {
//       chrome.runtime.sendMessage({ action: 'cbGerarCodigoPareamento' }, (resp) => {
//           document.getElementById('codigoExibido').textContent = resp.codigo;
//       });
//   });
//
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'cbGerarCodigoPareamento') {
        cbGerarCodigoPareamento((codigo) => sendResponse({ codigo }));
        return true; // resposta assíncrona
    }
});

// ---------------------------------------------------------------------
// 3) Enviar o estado atual pro Firebase (heartbeat + mudança de estado)
// ---------------------------------------------------------------------
async function cbFirebaseEnviarEstado() {
    cbObterDeviceId((deviceId) => {
        chrome.storage.local.get(
            ['studyHistory', 'cbCronogramaHoje', 'cbCronogramaData', 'cbCronogramaPorData', 'sessionAtualInicio',
             'pomodoroMode', 'pomodoroState', 'pomodoroEndAt', 'pomodoroTimeLeft', 'streakCount',
             'cbSitesBloqueadosManual', 'cbSitesLiberados', 'unlockedLevelIndex', 'totalStudyMs', 'assuntosPrioridade',
             'questoesPeriodStats', 'questoesDailyHistory'],
            (res) => {
                // dailyGoalMs mora em chrome.storage.sync (não local) — ver options/popup.
                chrome.storage.sync.get(['dailyGoalMs', 'cbLicensePayload'], (syncRes) => {
                  cbColetarGrifosPlanalto((planaltoGrifos) => {
                    const today = getTodayKey();
                    const msHoje = (res.studyHistory && res.studyHistory[today]) || 0;

                    // Junta cbCronogramaPorData com o dia de hoje (que pode só existir no
                    // formato antigo cbCronogramaHoje/cbCronogramaData) — mesma mesclagem
                    // usada em rotina/rotina-diaria.js, pra nunca ficar dessincronizado
                    // não importa por qual tela do PC o bloco foi criado/editado.
                    const porData = res.cbCronogramaPorData ? { ...res.cbCronogramaPorData } : {};
                    if (res.cbCronogramaData === today) {
                        porData[today] = res.cbCronogramaHoje || [];
                    }
                    const blocos = porData[today] || [];
                    // Bloco ativo do cronograma agora vem só daqui — a integração com
                    // Telegram que preenchia isso foi removida (não estava mais
                    // funcionando); o celular recebe "sem bloco ativo" até esse cálculo
                    // ganhar uma fonte própria.
                    const bloco = null;

                    // Manda só uma janela de -1 a +6 dias pro celular (aba Agenda do
                    // site), em vez do histórico inteiro de cronograma — mantém o nó do
                    // Firebase pequeno independente de há quantos meses a pessoa usa.
                    const agenda = {};
                    const hoje = new Date();
                    for (let i = -1; i <= 6; i++) {
                        const d = new Date(hoje);
                        d.setDate(d.getDate() + i);
                        const chave = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
                        if (porData[chave] && porData[chave].length) agenda[chave] = porData[chave];
                    }

                    // Mesma lógica pro histórico de horas: só os últimos 35 dias, o
                    // suficiente pro painel/heatmap do site, sem crescer sem limite.
                    const historico = {};
                    const studyHistory = res.studyHistory || {};
                    for (let i = 0; i < 35; i++) {
                        const d = new Date(hoje);
                        d.setDate(d.getDate() - i);
                        const chave = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
                        if (typeof studyHistory[chave] === 'number') historico[chave] = studyHistory[chave];
                    }

                    cbFirebasePatch(`dispositivos/${deviceId}`, {
                        sessionState,
                        msHoje,
                        inicioSessao: sessionState === 'running' ? (res.sessionAtualInicio || Date.now()) : null,
                        bloco,
                        // Campos do Pomodoro — lidos do storage (fonte real usada pelo
                        // painel), pra qualquer cronômetro redondo (nova interface,
                        // celular) mostrar os MESMOS números do PC, em vez de simular
                        // uma contagem própria e ficar dessincronizado.
                        pomodoroMode: !!res.pomodoroMode,
                        pomodoroState: res.pomodoroState || 'work',
                        pomodoroEndAt: res.pomodoroEndAt || null,
                        pomodoroTimeLeft: typeof res.pomodoroTimeLeft === 'number' ? res.pomodoroTimeLeft : null,
                        // Ofensiva/streak real (o mesmo número que já aparece no
                        // badge 🔥 do popup), pra não precisar recalcular do zero
                        // no celular — reaproveita a fonte que já existe.
                        streakCount: typeof res.streakCount === 'number' ? res.streakCount : 0,
                        // ---- Novos campos, usados pela aba Painel/Agenda do site ----
                        dailyGoalMs: syncRes.dailyGoalMs || (4 * 60 * 60 * 1000),
                        unlockedLevelIndex: typeof res.unlockedLevelIndex === 'number' ? res.unlockedLevelIndex : 0,
                        totalStudyMs: typeof res.totalStudyMs === 'number' ? res.totalStudyMs : 0,
                        historico,
                        agenda,
                        sitesBloqueadosManual: res.cbSitesBloqueadosManual || [],
                        sitesLiberados: res.cbSitesLiberados || [],
                        // Desempenho real do QConcursos (raspado pelo content script,
                        // já com o score de urgência calculado em background.js) — é
                        // isso que a aba Questões do site cruza com os flashcards pra
                        // sugerir onde focar. Manda só os 30 mais urgentes, já
                        // ordenados, pra não inflar o payload.
                        assuntosPrioridadeQC: (res.assuntosPrioridade && Array.isArray(res.assuntosPrioridade.itens))
                            ? res.assuntosPrioridade.itens.slice(0, 30).map((it) => ({
                                materia: it.materia, nome: it.nome, pctAcerto: it.pctAcerto, score: it.score
                              }))
                            : [],
                        // "Hoje" real do QConcursos (vem da própria API oficial do QC,
                        // sempre atualizado — não é contagem de flashcards daqui do
                        // site) + histórico diário dos últimos 35 dias, pro gráfico da
                        // semana e pra "dias seguidos" baterem com o desempenho de
                        // verdade, não com o uso do baralho de exemplo.
                        questoesHojeQC: (res.questoesPeriodStats && res.questoesPeriodStats[1])
                            ? {
                                acertos: res.questoesPeriodStats[1].acertos || 0,
                                erros: res.questoesPeriodStats[1].erros || 0,
                                total: res.questoesPeriodStats[1].total || 0
                              }
                            : null,
                        questoesHistoricoQC: (() => {
                            const bruto = res.questoesDailyHistory || {};
                            const janela = {};
                            for (let i = 0; i < 35; i++) {
                                const d = new Date(hoje);
                                d.setDate(d.getDate() - i);
                                const chave = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
                                if (bruto[chave]) janela[chave] = bruto[chave];
                            }
                            return janela;
                        })(),
                        // Reaproveita a licença manual que já existe (license.js) pra liberar
                        // a aba Questões do site sem precisar de um sistema novo — só lê o
                        // payload já validado uma vez pelo popup.js quando o código foi
                        // aplicado, sem duplicar a chave secreta aqui.
                        questoesLiberado: (() => {
                            const payload = syncRes.cbLicensePayload;
                            if (!payload) return false;
                            if (payload.all === true) return true;
                            return Array.isArray(payload.features) && payload.features.includes('questoes');
                        })(),
                        // Leis grifadas no Planalto (Marcador de Texto) — pra aba
                        // Questões do site mostrar o que você já destacou, com um
                        // link real pra abrir a lei de verdade (não incorporada
                        // aqui: sites do governo bloqueiam iframe por segurança).
                        planaltoGrifos,
                        atualizadoEm: Date.now()
                    });
                  });
                });
            }
        );
    });
}

// Reaproveita o heartbeat de 1 min já existente.
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'cb-heartbeat') cbFirebaseEnviarEstado();
});

// Também envia na hora quando o estado muda (start/pause/stop) ou quando
// o Pomodoro muda de fase (foco → pausa curta/longa), pra manter o
// círculo do celular sempre com o número certo.
chrome.storage.onChanged.addListener((changes, area) => {
    // IMPORTANTE: "pomodoroMode" precisa estar nessa lista. Sem ele, ligar/
    // desligar o Pomodoro (sem trocar o estado da sessão no mesmo instante)
    // não disparava um envio imediato pro Firebase — o celular só recebia
    // a mudança no próximo heartbeat (até 1 minuto depois), dando a
    // impressão de que "não tem modo Pomodoro no celular".
    // O Firefox dispara onChanged mesmo quando o valor gravado é igual ao anterior (o segundo plano regrava o estado
    // o tempo todo), o que virava uma rajada de PATCH. Só conta mudança de verdade e junta várias num envio só.
    const mudou = (c) => c && JSON.stringify(c.oldValue) !== JSON.stringify(c.newValue);
    if (area === 'local' && ['sessionState', 'pomodoroMode', 'pomodoroState', 'pomodoroEndAt', 'streakCount'].some((k) => mudou(changes[k]))) {
        cbAgendarEnvioEstado();
    }
});
let cbEnvioEstadoTimer = null;
function cbAgendarEnvioEstado() {
    if (cbEnvioEstadoTimer) return;
    cbEnvioEstadoTimer = setTimeout(() => { cbEnvioEstadoTimer = null; cbFirebaseEnviarEstado(); }, 1500);
}

// ---------------------------------------------------------------------
// 3b) Comunidade — comparação anônima e agregada (não é um sistema
//    descentralizado de verdade, mas usa a mesma conta Firebase já aberta
//    pro pareamento com celular, sem precisar de servidor próprio nem de
//    login: cada instalação soma sua contribuição do dia num nó
//    compartilhado só com totais — nunca com o deviceId nem com os dados
//    de estudo em si — então dá pra calcular a média geral sem ninguém
//    conseguir ver o desempenho individual de outra pessoa.
//    Usa o operador atômico do Realtime Database ({".sv": {"increment"}})
//    pra somar com segurança mesmo com várias instalações escrevendo ao
//    mesmo tempo, sem precisar de Cloud Functions (que exigem plano pago).
// ---------------------------------------------------------------------
async function cbFirebaseIncrementar(path, incrementos) {
    const valor = {};
    for (const campo in incrementos) valor[campo] = { '.sv': { increment: incrementos[campo] } };
    return cbFirebasePatch(path, valor);
}

async function cbComunidadeEnviarContribuicao() {
    cbObterDeviceId(() => {
        chrome.storage.local.get(['studyHistory', 'questoesPeriodStats', 'cbComunidadeEnviadoPorDia'], (res) => {
            const today = getTodayKey();
            const msHoje = (res.studyHistory && res.studyHistory[today]) || 0;
            const qc = (res.questoesPeriodStats && res.questoesPeriodStats[1]) || null;
            const acertosHoje = qc ? (qc.acertos || 0) : 0;
            const totalHoje = qc ? (qc.total || 0) : 0;

            const registro = res.cbComunidadeEnviadoPorDia || {};
            const estado = registro[today] || { msEnviado: 0, acertosEnviado: 0, totalEnviado: 0, contadoEstudo: false, contadoQuestoes: false };

            // Só manda a DIFERENÇA desde o último envio (nunca o total), pra
            // incrementar o agregado da comunidade sem contar o mesmo minuto
            // de estudo duas vezes a cada heartbeat.
            const incrementos = {};
            const deltaMs = msHoje - estado.msEnviado;
            if (deltaMs > 0) incrementos.somaEstudoMs = deltaMs;
            if (!estado.contadoEstudo && msHoje > 0) incrementos.qtdEstudo = 1;

            const deltaTotal = totalHoje - estado.totalEnviado;
            const deltaAcertos = acertosHoje - estado.acertosEnviado;
            if (deltaTotal > 0) {
                incrementos.somaQuestoes = deltaTotal;
                if (deltaAcertos > 0) incrementos.somaAcertos = deltaAcertos;
            }
            if (!estado.contadoQuestoes && totalHoje > 0) incrementos.qtdQuestoes = 1;

            if (Object.keys(incrementos).length === 0) return;

            cbFirebaseIncrementar(`comunidade/${today}`, incrementos).then(() => {
                registro[today] = {
                    msEnviado: Math.max(msHoje, estado.msEnviado),
                    acertosEnviado: Math.max(acertosHoje, estado.acertosEnviado),
                    totalEnviado: Math.max(totalHoje, estado.totalEnviado),
                    contadoEstudo: estado.contadoEstudo || msHoje > 0,
                    contadoQuestoes: estado.contadoQuestoes || totalHoje > 0
                };
                // Guarda só os últimos 3 dias localmente — é só um controle de
                // "já mandei isso hoje", não precisa de histórico maior.
                const chaves = Object.keys(registro).sort();
                while (chaves.length > 3) delete registro[chaves.shift()];
                chrome.storage.local.set({ cbComunidadeEnviadoPorDia: registro });
            });
        });
    });
}

async function cbComunidadeObterHoje(callback) {
    const today = getTodayKey();
    try {
        const resp = await fetch(`${CB_FIREBASE_URL}/comunidade/${today}.json`, { signal: AbortSignal.timeout(6000) });
        const dados = await resp.json();
        callback(dados || {});
    } catch (e) {
        console.warn('[CB-Firebase] Falha ao ler comunidade:', e);
        callback({});
    }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'cbObterComunidade') {
        cbComunidadeObterHoje((dados) => sendResponse({ dados }));
        return true; // resposta assíncrona
    }
});

// Reaproveita o mesmo heartbeat de 1 min do envio de estado pro celular.
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'cb-heartbeat') cbComunidadeEnviarContribuicao();
});

// ---------------------------------------------------------------------
// 3c) Ranking opcional (opt-in) — pra quem quer se comparar com pessoas
//    individualmente, não só com a média. Duas decisões pra não virar
//    dor de cabeça depois:
//
//    1) Apelido 100% automático (Animal + Adjetivo + número), sorteado de
//       listas fixas — nunca digitado pela pessoa. Sem campo de texto
//       livre, não tem como aparecer palavrão/nome ofensivo, então não
//       precisa de moderação nenhuma.
//
//    2) Usa um ID PRÓPRIO (cbRankingId), diferente do cbDeviceId do
//       pareamento com celular, e sem nenhuma relação calculável entre
//       os dois. Isso importa porque o ranking é público (qualquer um
//       pode listar `ranking/{data}`) — se usasse o deviceId como chave,
//       daria pra pegar esse ID ali e ir direto em
//       `dispositivos/{deviceId}` puxar dados bem mais sensíveis
//       (cronograma, sites bloqueados etc.), que hoje só ficam "seguros"
//       por ninguém saber o ID, não por regra do banco.
// ---------------------------------------------------------------------
const CB_RANKING_ANIMAIS = ['Coruja', 'Falcão', 'Tartaruga', 'Formiga', 'Águia', 'Leão', 'Lobo', 'Golfinho', 'Tigre', 'Urso', 'Raposa', 'Gavião'];
const CB_RANKING_ADJETIVOS = ['Dedicado', 'Focado', 'Persistente', 'Determinado', 'Disciplinado', 'Constante', 'Aplicado', 'Estudioso', 'Resiliente', 'Concentrado', 'Motivado', 'Incansável'];

function cbHashSimples(texto) {
    let h = 0;
    for (let i = 0; i < texto.length; i++) h = (h * 31 + texto.charCodeAt(i)) >>> 0;
    return h;
}

function cbObterRankingId(callback) {
    chrome.storage.local.get(['cbRankingId', 'cbRankingApelido'], (res) => {
        if (res.cbRankingId && res.cbRankingApelido) return callback(res.cbRankingId, res.cbRankingApelido);
        const novoId = 'rk_' + crypto.randomUUID();
        const h = cbHashSimples(novoId);
        const animal = CB_RANKING_ANIMAIS[h % CB_RANKING_ANIMAIS.length];
        const adjetivo = CB_RANKING_ADJETIVOS[(h >>> 4) % CB_RANKING_ADJETIVOS.length];
        const numero = (h % 90) + 10; // 10–99, só reduz chance de dois apelidos idênticos
        const apelido = `${animal} ${adjetivo} #${numero}`;
        chrome.storage.local.set({ cbRankingId: novoId, cbRankingApelido: apelido }, () => callback(novoId, apelido));
    });
}

async function cbRankingEnviar() {
    chrome.storage.local.get(['cbRankingOptIn'], (opt) => {
        if (!opt.cbRankingOptIn) return;
        cbObterRankingId((rankingId, apelido) => {
            chrome.storage.local.get(['studyHistory', 'questoesPeriodStats'], (res) => {
                const today = getTodayKey();
                const msHoje = (res.studyHistory && res.studyHistory[today]) || 0;
                const qc = (res.questoesPeriodStats && res.questoesPeriodStats[1]) || null;
                const pct = (qc && qc.total > 0) ? Math.round((qc.acertos / qc.total) * 100) : null;
                cbFirebasePut(`ranking/${today}/${rankingId}`, {
                    apelido,
                    msEstudo: msHoje,
                    pctAcerto: pct,
                    atualizadoEm: Date.now()
                });
            });
        });
    });
}

function cbRankingSair() {
    cbObterRankingId((rankingId) => {
        // Apaga só o registro de HOJE — dias anteriores já publicados ficam
        // como estão (mesma lógica do resto do app: sem histórico
        // individual centralizado pra apagar depois).
        cbFirebasePut(`ranking/${getTodayKey()}/${rankingId}`, null);
    });
}

async function cbRankingObterHoje(callback) {
    try {
        const resp = await fetch(`${CB_FIREBASE_URL}/ranking/${getTodayKey()}.json`, { signal: AbortSignal.timeout(6000) });
        const dados = await resp.json();
        callback(dados || {});
    } catch (e) {
        console.warn('[CB-Firebase] Falha ao ler ranking:', e);
        callback({});
    }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'cbObterRanking') {
        chrome.storage.local.get(['cbRankingOptIn'], (opt) => {
            cbObterRankingId((rankingId, apelido) => {
                cbRankingObterHoje((dados) => sendResponse({ dados, rankingId, apelido, optIn: !!opt.cbRankingOptIn }));
            });
        });
        return true;
    }
    if (message.action === 'cbRankingOptIn') {
        chrome.storage.local.set({ cbRankingOptIn: true }, () => {
            cbRankingEnviar();
            sendResponse({ ok: true });
        });
        return true;
    }
    if (message.action === 'cbRankingOptOut') {
        chrome.storage.local.set({ cbRankingOptIn: false }, () => {
            cbRankingSair();
            sendResponse({ ok: true });
        });
        return true;
    }
});

// Manda a atualização do ranking (quando a pessoa optou por participar)
// no mesmo heartbeat de 1 min de tudo que já existia.
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'cb-heartbeat') cbRankingEnviar();
});

// ---------------------------------------------------------------------
// 3d) Grupos fechados por convite — "estude junto com quem você conhece".
//    Diferente do ranking anônimo acima, aqui o NOME é escolhido pela
//    própria pessoa (texto livre), porque só quem tem o código do grupo
//    consegue ver aquele grupo — um círculo pequeno e de confiança que a
//    própria pessoa formou (como convidar amigos pra um grupo do
//    WhatsApp), não o público geral da extensão. Mesmo assim, segue a
//    mesma lógica de isolamento dos outros recursos: usa um ID PRÓPRIO
//    (cbGrupoMembroId), sem nenhuma relação com o deviceId nem com o
//    rankingId.
// ---------------------------------------------------------------------
const CB_GRUPO_ALFABETO = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'; // sem 0/O e 1/I/L, pra não confundir ao digitar o código

function cbGerarCodigoGrupo() {
    let codigo = '';
    for (let i = 0; i < 6; i++) codigo += CB_GRUPO_ALFABETO[Math.floor(Math.random() * CB_GRUPO_ALFABETO.length)];
    return codigo;
}

function cbObterGrupoMembroId(callback) {
    chrome.storage.local.get(['cbGrupoMembroId'], (res) => {
        if (res.cbGrupoMembroId) return callback(res.cbGrupoMembroId);
        const novoId = 'gm_' + crypto.randomUUID();
        chrome.storage.local.set({ cbGrupoMembroId: novoId }, () => callback(novoId));
    });
}

function cbGrupoCriar(nome, callback) {
    const nomeLimpo = String(nome || '').trim().slice(0, 24) || 'Sem nome';
    const codigo = cbGerarCodigoGrupo();
    cbFirebasePut(`grupos/${codigo}/criadoEm`, Date.now()).then(() => {
        chrome.storage.local.set({ cbGrupoAtivo: codigo, cbGrupoNome: nomeLimpo }, () => {
            cbGrupoEnviarAtualizacao();
            callback({ ok: true, codigo });
        });
    });
}

async function cbGrupoEntrar(codigoBruto, nome, callback) {
    const codigo = String(codigoBruto || '').trim().toUpperCase();
    if (!codigo) return callback({ ok: false, erro: 'codigo_vazio' });
    try {
        const resp = await fetch(`${CB_FIREBASE_URL}/grupos/${codigo}/criadoEm.json`);
        const existe = await resp.json();
        if (!existe) return callback({ ok: false, erro: 'nao_encontrado' });
        const nomeLimpo = String(nome || '').trim().slice(0, 24) || 'Sem nome';
        chrome.storage.local.set({ cbGrupoAtivo: codigo, cbGrupoNome: nomeLimpo }, () => {
            cbGrupoEnviarAtualizacao();
            callback({ ok: true, codigo });
        });
    } catch (e) {
        console.warn('[CB-Firebase] Falha ao entrar no grupo:', e);
        callback({ ok: false, erro: 'rede' });
    }
}

function cbGrupoEnviarAtualizacao() {
    chrome.storage.local.get(['cbGrupoAtivo', 'cbGrupoNome', 'studyHistory'], (res) => {
        if (!res.cbGrupoAtivo) return;
        const today = getTodayKey();
        const msHoje = (res.studyHistory && res.studyHistory[today]) || 0;
        cbObterGrupoMembroId((membroId) => {
            cbFirebasePut(`grupos/${res.cbGrupoAtivo}/dias/${today}/membros/${membroId}`, {
                nome: res.cbGrupoNome || 'Sem nome',
                msEstudo: msHoje,
                atualizadoEm: Date.now()
            });
        });
    });
}

function cbGrupoSair(callback) {
    chrome.storage.local.get(['cbGrupoAtivo'], (res) => {
        const codigo = res.cbGrupoAtivo;
        chrome.storage.local.remove(['cbGrupoAtivo', 'cbGrupoNome'], () => {
            if (codigo) {
                cbObterGrupoMembroId((membroId) => {
                    // Só apaga a entrada de HOJE — dias anteriores já
                    // publicados ficam como estão pros outros membros verem
                    // o histórico do grupo, mesma lógica do ranking anônimo.
                    cbFirebasePut(`grupos/${codigo}/dias/${getTodayKey()}/membros/${membroId}`, null);
                });
            }
            callback({ ok: true });
        });
    });
}

function cbGrupoObterHoje(callback) {
    chrome.storage.local.get(['cbGrupoAtivo', 'cbGrupoNome'], (res) => {
        if (!res.cbGrupoAtivo) return callback({ ativo: false });
        cbObterGrupoMembroId(async (membroId) => {
            try {
                const resp = await fetch(`${CB_FIREBASE_URL}/grupos/${res.cbGrupoAtivo}/dias/${getTodayKey()}/membros.json`);
                const membros = await resp.json();
                callback({ ativo: true, codigo: res.cbGrupoAtivo, nome: res.cbGrupoNome, membroId, membros: membros || {} });
            } catch (e) {
                console.warn('[CB-Firebase] Falha ao ler grupo:', e);
                callback({ ativo: true, codigo: res.cbGrupoAtivo, nome: res.cbGrupoNome, membroId, membros: {} });
            }
        });
    });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'cbGrupoCriar') {
        cbGrupoCriar(message.nome, (resultado) => sendResponse(resultado));
        return true;
    }
    if (message.action === 'cbGrupoEntrar') {
        cbGrupoEntrar(message.codigo, message.nome, (resultado) => sendResponse(resultado));
        return true;
    }
    if (message.action === 'cbGrupoSair') {
        cbGrupoSair((resultado) => sendResponse(resultado));
        return true;
    }
    if (message.action === 'cbGrupoObterHoje') {
        cbGrupoObterHoje((resultado) => sendResponse(resultado));
        return true;
    }
});

// Manda a atualização do grupo (só se a pessoa estiver em algum) no mesmo
// heartbeat de 1 min de tudo mais.
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'cb-heartbeat') cbGrupoEnviarAtualizacao();
});

// ---------------------------------------------------------------------
// 3e) Chat anônimo da comunidade — só o AVISO de mensagem nova.
//    A conversa em si (enviar, apagar, contar quem viu) vive na tela:
//    interface-popup/comunidade-chat.js. Aqui, a cada minuto (mesmo
//    heartbeat de tudo mais) olhamos as últimas mensagens e contamos as
//    que chegaram DEPOIS da última vez que a pessoa abriu a conversa e que
//    não são dela. O popup pinta o ícone da comunidade de vermelho a
//    partir de cbChatNaoLidas, e a barra do navegador mostra o número.
//    Na primeira checagem (nada visto ainda) o histórico antigo não vale
//    como "novo": só marca como visto.
// ---------------------------------------------------------------------
async function cbChatChecarNovas() {
    try {
        const resp = await fetch(`${CB_FIREBASE_URL}/chat/mensagens.json?orderBy=%22%24key%22&limitToLast=30`);
        if (!resp.ok) return; // regras ainda não publicadas / sem rede: não mexe no aviso
        const dados = (await resp.json()) || {};
        const msgs = Object.keys(dados).map((id) => dados[id]).filter((m) => m && typeof m.ts === 'number');
        const maxTs = msgs.reduce((x, m) => Math.max(x, m.ts), 0);
        chrome.storage.local.get(['cbChatUltimoVisto', 'cbChatId'], (res) => {
            if (typeof res.cbChatUltimoVisto !== 'number') {
                chrome.storage.local.set({ cbChatUltimoVisto: maxTs, cbChatNaoLidas: 0 });
                cbChatMostrarEmblema(0);
                return;
            }
            const novas = msgs.filter((m) => m.ts > res.cbChatUltimoVisto && m.i !== res.cbChatId).length;
            chrome.storage.local.set({ cbChatNaoLidas: novas });
            cbChatMostrarEmblema(novas);
        });
    } catch (e) {
        console.warn('[CB-Firebase] Falha ao checar o chat:', e);
    }
}

function cbChatMostrarEmblema(n) {
    try {
        if (!chrome.action || !chrome.action.setBadgeText) return;
        chrome.action.setBadgeText({ text: n > 0 ? String(Math.min(n, 99)) : '' });
        if (n > 0 && chrome.action.setBadgeBackgroundColor) chrome.action.setBadgeBackgroundColor({ color: '#e5484d' });
    } catch (e) { /* o emblema é só um extra */ }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'cbChatChecar') {
        cbChatChecarNovas().then(() => sendResponse({ ok: true }));
        return true;
    }
});

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'cb-heartbeat') cbChatChecarNovas();
});
// Quando a pessoa abre a conversa o popup zera cbChatNaoLidas; o emblema acompanha.
chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.cbChatNaoLidas) cbChatMostrarEmblema(changes.cbChatNaoLidas.newValue || 0);
});

// ---------------------------------------------------------------------
// 4) Ouvir comandos vindos do celular (Pausar/Continuar/Parar).
//    Usa um alarme PRÓPRIO, separado do heartbeat de 1 min, pra reagir
//    rápido (o Chrome só permite intervalos abaixo de 1 min em extensões
//    carregadas via "Modo desenvolvedor" — publicada na loja, ele
//    automaticamente arredonda pra 1 min; não dá erro, só fica mais lento).
// ---------------------------------------------------------------------
// 1 minuto. Estava em ~5 s (valor de teste): o Chrome limita alarmes a 1 min, mas o Firefox obedece, então o segundo plano
// ficava acordado o tempo todo fazendo requisição ao Firebase (pesava a extensão e disputava rede com o chat).
// O alarme antigo continua salvo no navegador com o período velho: se for diferente de 1 min, recria.
chrome.alarms.get('cb-comando-remoto', (existente) => {
    if (!existente || existente.periodInMinutes !== 1) chrome.alarms.create('cb-comando-remoto', { periodInMinutes: 1 });
});
console.log('[CB-Firebase] Alarme cb-comando-remoto criado.');

async function cbFirebaseChecarComandoRemoto() {
    console.log('[CB-Firebase] Checando comando remoto...');
    cbObterDeviceId(async (deviceId) => {
        console.log('[CB-Firebase] deviceId usado na checagem:', deviceId);
        try {
            const resp = await fetch(`${CB_FIREBASE_URL}/dispositivos/${deviceId}/comandoRemoto.json`);
            const cmd = await resp.json();
            console.log('[CB-Firebase] comandoRemoto recebido:', cmd);
            if (!cmd) return;

            // A extensão controla o estado da sessão via uma única mensagem
            // interna { action: 'changeState', state: ... } — o mesmo
            // mecanismo usado pelo atalho Ctrl+M (veja chrome.commands.onCommand
            // em background.js). Reaproveitamos exatamente isso aqui.
            let novoEstado = null;
            if (cmd.acao === 'pausar')    novoEstado = 'paused_manual';
            if (cmd.acao === 'continuar') novoEstado = 'running';
            if (cmd.acao === 'parar')     novoEstado = 'stopped';

            console.log('[CB-Firebase] novoEstado calculado:', novoEstado);

            if (novoEstado) {
                // IMPORTANTE: firebase-sync.js roda no MESMO service worker que
                // background.js (carregado via importScripts), então chamamos a
                // função processMessage() diretamente em vez de usar
                // chrome.runtime.sendMessage — esse "self-messaging" (a extensão
                // mandando mensagem pra ela mesma) não é entregue de forma
                // confiável e estava falhando silenciosamente aqui.
                if (typeof hydrateState === 'function' && typeof processMessage === 'function') {
                    hydrateState().then(() => {
                        processMessage({ action: 'changeState', state: novoEstado }, null, (resp2) => {
                            console.log('[CB-Firebase] resultado do changeState (chamada direta):', resp2);
                        });
                    });
                } else {
                    console.error('[CB-Firebase] processMessage/hydrateState não encontrados — algo mudou em background.js.');
                }
            }

            // Consome o comando (apaga do Firebase) pra nunca reaplicar
            // por engano se o service worker reiniciar.
            cbFirebasePut(`dispositivos/${deviceId}/comandoRemoto`, null);
        } catch (e) {
            console.error('[CB-Firebase] Erro ao checar comando remoto:', e);
        }
    });
}

// Exposto pra dar pra testar manualmente no console do service worker,
// sem precisar esperar o alarme: digite cbFirebaseChecarComandoRemoto()
// e aperte Enter.
self.cbFirebaseChecarComandoRemoto = cbFirebaseChecarComandoRemoto;

chrome.alarms.onAlarm.addListener((alarm) => {
    console.log('[CB-Firebase] Alarme disparado:', alarm.name);
    if (alarm.name === 'cb-comando-remoto') cbFirebaseChecarComandoRemoto();
});

// ---------------------------------------------------------------------
// 5) Checagem "de carona" em eventos que já acontecem o tempo todo
//    enquanto a pessoa usa o navegador — troca de aba, página terminando
//    de carregar, o Chrome sendo aberto. Isso não substitui o alarme
//    acima (que seria a única forma de checar se o PC ficasse com o
//    Chrome parado, sem nenhuma aba sendo usada), mas na prática, com a
//    pessoa ativa no computador, o comando do celular chega em segundos
//    em vez de esperar o próximo minuto do alarme — que é o mínimo que o
//    Chrome permite pra qualquer extensão, sem exceção, então não dá pra
//    acelerar só ajustando o período do alarme.
// ---------------------------------------------------------------------
let cbUltimaChecagemComando = 0;
function cbChecarComandoComDebounce() {
    const agora = Date.now();
    if (agora - cbUltimaChecagemComando < 2000) return; // evita rajadas quase simultâneas
    cbUltimaChecagemComando = agora;
    cbFirebaseChecarComandoRemoto();
}
chrome.tabs.onActivated.addListener(() => cbChecarComandoComDebounce());
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (changeInfo.status === 'complete') cbChecarComandoComDebounce();
});
chrome.runtime.onStartup.addListener(() => cbChecarComandoComDebounce());
