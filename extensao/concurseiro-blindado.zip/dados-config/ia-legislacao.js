// ===================== BASE DE LEIS IMPORTADAS (RAG local) =====================
//
// Guarda o texto de PDFs de lei que a PESSOA importa manualmente (a extensão
// nunca lê nada do disco sozinha — só o que for escolhido num seletor de
// arquivo) e permite buscar os trechos mais relevantes pra uma pergunta, pra
// a IA citar o artigo de verdade em vez de inventar. Tudo local, em
// chrome.storage — nada disso é enviado a lugar nenhum além do provedor de
// IA, e só o trecho relevante (não a lei inteira).
//
// Quem faz o PARSING do PDF é interface-popup/ia-leis-import.js (só ali,
// porque precisa da lib pdf.js). Este arquivo só guarda/busca o que já foi
// extraído, e é usado também pelo chat (interface-popup/ia-chat.js).

const CB_LEIS_META_KEY = 'cbLeisImportadas';
const CB_LEIS_CHUNK_PREFIX = 'cbLeisChunks_';

const CB_STOPWORDS_LEI = new Set([
  'de', 'da', 'do', 'das', 'dos', 'a', 'o', 'as', 'os', 'e', 'em', 'no', 'na', 'nos', 'nas',
  'que', 'com', 'por', 'para', 'um', 'uma', 'uns', 'umas', 'se', 'sua', 'seu', 'suas', 'seus',
  'ou', 'como', 'mais', 'menos', 'ao', 'aos', 'à', 'às', 'é', 'são', 'foi', 'ser', 'tem', 'têm',
  'sobre', 'entre', 'quando', 'qual', 'quais', 'porque', 'este', 'esta', 'isso', 'aquele',
]);

function cbNormalizarTextoLei(s) {
  return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
}

function cbPalavrasChaveLei(pergunta) {
  return cbNormalizarTextoLei(pergunta)
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter((p) => p.length > 3 && !CB_STOPWORDS_LEI.has(p));
}

function cbListarLeis() {
  return new Promise((resolve) => {
    chrome.storage.local.get([CB_LEIS_META_KEY], (res) => resolve(res[CB_LEIS_META_KEY] || []));
  });
}

// chunks: [{ artigo: "Art. 186" | null, texto: "..." }, ...]
function cbSalvarLei(nome, chunks) {
  return cbListarLeis().then((leis) => {
    const id = `lei_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const nova = { id, nome: String(nome).slice(0, 120), importadoEm: Date.now(), totalChunks: chunks.length };
    return new Promise((resolve) => {
      const patch = { [CB_LEIS_META_KEY]: leis.concat(nova), [CB_LEIS_CHUNK_PREFIX + id]: chunks };
      chrome.storage.local.set(patch, () => resolve(nova));
    });
  });
}

function cbRemoverLei(id) {
  return cbListarLeis().then((leis) => {
    const novasLeis = leis.filter((l) => l.id !== id);
    return new Promise((resolve) => {
      chrome.storage.local.set({ [CB_LEIS_META_KEY]: novasLeis }, () => {
        chrome.storage.local.remove(CB_LEIS_CHUNK_PREFIX + id, () => resolve());
      });
    });
  });
}

// Retorna até maxTrechos { lei, artigo, texto } mais relevantes pra pergunta
// (busca por palavras-chave, sem IA/embeddings — simples e roda instantâneo).
// [] se não houver lei importada ou nada bater com a pergunta.
function cbBuscarTrechosRelevantes(pergunta, maxTrechos) {
  maxTrechos = maxTrechos || 3;
  const palavras = cbPalavrasChaveLei(pergunta);
  if (!palavras.length) return Promise.resolve([]);

  return cbListarLeis().then((leis) => {
    if (!leis.length) return [];
    return new Promise((resolve) => {
      const chaves = leis.map((l) => CB_LEIS_CHUNK_PREFIX + l.id);
      chrome.storage.local.get(chaves, (res) => {
        const candidatos = [];
        leis.forEach((lei) => {
          const chunks = res[CB_LEIS_CHUNK_PREFIX + lei.id] || [];
          chunks.forEach((c) => {
            const alvo = cbNormalizarTextoLei(c.texto);
            let score = 0;
            palavras.forEach((p) => { if (alvo.includes(p)) score += 1; });
            if (score > 0) candidatos.push({ lei: lei.nome, artigo: c.artigo, texto: c.texto, score });
          });
        });
        candidatos.sort((a, b) => b.score - a.score);
        resolve(candidatos.slice(0, maxTrechos));
      });
    });
  });
}

window.cbListarLeis = cbListarLeis;
window.cbSalvarLei = cbSalvarLei;
window.cbRemoverLei = cbRemoverLei;
window.cbBuscarTrechosRelevantes = cbBuscarTrechosRelevantes;
