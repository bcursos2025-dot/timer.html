// ============================================================================
// corpus927-bg.js — Busca de jurisprudência por artigo no Corpus927 (ENFAM/CNJ, corpus927.enfam.jus.br), rodando no
// serviço de fundo da extensão. É aqui, e não no script da página do Planalto, porque o Chrome/Opera não deixam um
// script de página chamar outro site (CORS); o serviço de fundo, com a permissão do site no manifest, pode.
//
// O site é público e sem login: GET /jurisprudencia/nrm:<id da norma>|art:<número> devolve um JSON de ~300 KB com
// súmulas, teses, repercussão geral, repetitivos, controle de constitucionalidade e posicionamentos do STJ. Aqui o
// JSON é ENXUGADO (texto sem HTML, trechos cortados, no máximo alguns itens por grupo) e guardado em cache por 3 dias
// (chrome.storage.local → cbCorpus927Cache, no máximo 60 artigos). Só se busca um artigo quando a pessoa clica nele;
// nunca se varre a lei.
//
// Mensagem: { action: 'corpus927_buscar', urn: 'nrm:4|art:1' }  →  { ok, dados, semDados?, doCache? } | { erro }
// ============================================================================
(function (raiz) {
    'use strict';

    const BASE = 'https://corpus927.enfam.jus.br';
    const K_CACHE = 'cbCorpus927Cache';
    const VALIDADE_MS = 3 * 24 * 3600 * 1000;
    const MAX_ENTRADAS = 60;
    const TEMPO_LIMITE_MS = 25000;
    const RE_URN = /^nrm:\d{1,4}\|art:\d{1,5}[A-Za-z]{0,2}$/;

    function limpar(t, max) {
        let s = String(t == null ? '' : t)
            .replace(/<br\s*\/?>/gi, '\n').replace(/<\/p>/gi, '\n').replace(/<[^>]+>/g, '')
            .replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"')
            .replace(/&#0?39;/g, "'").replace(/&#(\d+);/g, (m, n) => String.fromCharCode(Number(n))).replace(/&amp;/g, '&')
            .replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
        if (max && s.length > max) s = s.slice(0, max).replace(/\s+\S*$/, '') + '…';
        return s;
    }

    function item(o, max) {
        o = o || {};
        const url = /^https?:\/\//i.test(o.url_origem || '') ? String(o.url_origem) : '';
        return {
            titulo: limpar(o.titulo, 160),
            data: /^\d{4}-\d{2}-\d{2}/.test(o.data_publicacao || '') ? String(o.data_publicacao).slice(0, 10) : '',
            situacao: limpar(o.situacao, 60),
            tema: limpar(o.tema, 500),
            tese: limpar(o.tese, 900),
            texto: limpar(o.conteudo, max || 2500),
            relator: limpar(o.relator, 80),
            origem: limpar(o.origem, 20),
            semelhantes: Number(o.semelhantes) || 0,
            url,
        };
    }

    function compactar(j) {
        j = j || {};
        const J = j.jurisprudencias || {}, T = j.temas || {};
        const lista = (a, n, max) => (Array.isArray(a) ? a.slice(0, n).map((o) => item(o, max)).filter((x) => x.titulo || x.texto) : []);
        const alteracoes = Array.isArray(j.alteracoes)
            ? j.alteracoes.slice(0, 10).map((o) => ({ titulo: limpar(o && (o.titulo || o.norma || o.nome), 160), texto: limpar(o && (o.conteudo || o.texto || o.descricao), 600), data: (o && (o.data || o.data_publicacao)) || '' })).filter((x) => x.titulo || x.texto)
            : [];
        return {
            sumulasVinculantes: lista(J[100], 30),
            sumulas: lista(J[70], 30),
            teses: lista(J[110], 30),
            controle: lista(J[90], 30),
            repercussao: lista(T[80], 30),
            repetitivos: lista(T[60], 30),
            stjAgrupados: lista(j.posicionamentos_agrupados_stj, 12, 1800),
            stjIsolados: lista(j.posicionamentos_isolados_stj, 12, 1800),
            alteracoes,
        };
    }
    const vazio = (d) => Object.keys(d).every((k) => !d[k].length);

    // ---- cache ----
    const lerCache = () => new Promise((r) => { try { raiz.chrome.storage.local.get([K_CACHE], (x) => r((x && x[K_CACHE]) || {})); } catch (e) { r({}); } });
    const gravarCache = (c) => new Promise((r) => { try { raiz.chrome.storage.local.set({ [K_CACHE]: c }, () => r()); } catch (e) { r(); } });

    async function buscar(urn) {
        if (!RE_URN.test(urn)) return { erro: 'artigo inválido' };
        const cache = await lerCache();
        const antigo = cache[urn];
        if (antigo && Date.now() - antigo.ts < VALIDADE_MS) return { ok: true, dados: antigo.dados, semDados: vazio(antigo.dados), doCache: true };

        const ctl = new AbortController();
        const timer = setTimeout(() => ctl.abort(), TEMPO_LIMITE_MS);
        let r;
        try {
            r = await fetch(`${BASE}/jurisprudencia/${encodeURIComponent(urn)}`, { headers: { Accept: 'application/json' }, signal: ctl.signal });
        } catch (e) {
            return { erro: e && e.name === 'AbortError' ? 'o Corpus927 demorou demais para responder' : 'sem conexão com o Corpus927' };
        } finally { clearTimeout(timer); }
        if (r.status === 404) return { ok: true, dados: compactar({}), semDados: true };
        if (!r.ok) return { erro: `o Corpus927 respondeu ${r.status} para este artigo` };
        let json;
        try { json = await r.json(); } catch (e) { return { erro: 'resposta do Corpus927 não entendida' }; }
        const dados = compactar(json);

        cache[urn] = { ts: Date.now(), dados };
        const chaves = Object.keys(cache).sort((a, b) => cache[b].ts - cache[a].ts);
        chaves.slice(MAX_ENTRADAS).forEach((k) => { delete cache[k]; });
        await gravarCache(cache);
        return { ok: true, dados, semDados: vazio(dados) };
    }

    const api = { RE_URN, limpar, item, compactar, vazio, buscar };
    if (typeof module !== 'undefined' && module.exports) { module.exports = api; return; }

    raiz.chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
        if (!msg || msg.action !== 'corpus927_buscar') return false;
        buscar(String(msg.urn || '')).then(sendResponse).catch((e) => sendResponse({ erro: String((e && e.message) || e) }));
        return true;     // resposta assíncrona
    });
})(typeof self !== 'undefined' ? self : globalThis);
