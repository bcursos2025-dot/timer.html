// ===================== LEGISLAÇÃO PERMANENTE (coletâneas coordenadas importadas) =====================
//
// Igual em espírito ao ia-doutrina-permanente.js, mas para leis/códigos
// coordenados (não opinião doutrinária): coletâneas de legislação comentada/
// coordenada trazidas pela própria pessoa, guardadas LOCALMENTE dentro da
// extensão, em dados-config/materiais-legislacao/, e usadas como fonte de
// consulta pra IA citar o texto de lei de verdade em vez de "chutar". Zero
// custo de cota, zero rede — os arquivos já vêm empacotados na extensão.
//
// Diferença pro ia-legislacao.js: aquele é RAG por lei ÚNICA que a pessoa
// importa em tempo de execução via seletor de arquivo (guardado em
// chrome.storage). Este aqui é um ACERVO fixo, maior, de coletâneas inteiras
// (Código Civil, CPC, CPP, CTN, CLT etc.) que já vem pronto na extensão,
// igual aos e-books de materiais-doutrina/.
//
// AVISO DE DIREITO AUTORAL: essas coletâneas são material comercial
// (ex.: "Legislação 360"), não texto puro de domínio público como o do
// Planalto. Isso aqui é só um índice de busca local, pra uso pessoal de quem
// já tem o material — NÃO redistribua a pasta materiais-legislacao/ se um
// dia compartilhar essa extensão com outras pessoas.
//
// Os .txt são fruto de conversão de PDF (via pdf24), então vêm com lixo de
// paginação (números soltos, linhas de sumário) — cbLimparTextoLeiCoordenada
// tira isso antes de indexar.
//
// Carregamento é PREGUIÇOSO (só busca o arquivo .txt quando a pergunta bate
// com o ramo/código) e o texto fica em memória (cache de módulo), não em
// chrome.storage.
//
// SELEÇÃO DE LIVRO: cada entrada tem "apelidos" (palavras-chave literais,
// checadas por substring — rápido e sem custo, mas só pega quem escreveu a
// palavra "certa") E "ramo" (uma das chaves de CB_RAMOS_JURIDICOS, em
// ia-classificador-materia.js — usada quando esse classificador roda ANTES
// e diz de qual matéria a pergunta é, mesmo que a pergunta não cite nenhum
// termo técnico literal, ex.: "posso ser mandado embora sem motivo?" bate em
// "trabalhista" pelo classificador mesmo sem conter "CLT" ou "justa causa").

const CB_LEGISLACAO_LIVROS = [
  {
    chave: 'afo_360',
    arquivo: 'dados-config/materiais-legislacao/afo_legislacao_360.txt',
    nome: 'AFO — Legislação 360 (2026)',
    ramo: 'financeiro_orcamentario',
    apelidos: ['afo', 'administração financeira e orçamentária', 'administracao financeira e orcamentaria', 'direito financeiro', 'orçamento público', 'orcamento publico', 'lei de responsabilidade fiscal', 'lrf', 'lei 4.320', 'lei 4320'],
  },
  {
    chave: 'legislacao_financeira_orcamentaria',
    arquivo: 'dados-config/materiais-legislacao/legislacao_financeira_orcamentaria_coordenada.txt',
    nome: 'Legislação Financeira e Orçamentária Coordenada (2026)',
    ramo: 'financeiro_orcamentario',
    apelidos: ['afo', 'administração financeira e orçamentária', 'administracao financeira e orcamentaria', 'direito financeiro', 'orçamento público', 'orcamento publico', 'lei de responsabilidade fiscal', 'lrf', 'lei 4.320', 'lei 4320'],
  },
  {
    chave: 'codigo_civil_coordenado',
    arquivo: 'dados-config/materiais-legislacao/codigo_civil_coordenado.txt',
    nome: 'Código Civil Coordenado (2026)',
    ramo: 'civil',
    apelidos: ['código civil', 'codigo civil', 'direito civil', 'cc/2002', 'cc 2002', 'lei 10.406', 'lei 10406'],
  },
  {
    chave: 'codigo_civil_360',
    arquivo: 'dados-config/materiais-legislacao/codigo_civil_legislacao_360.txt',
    nome: 'Código Civil — Legislação 360 (2026)',
    ramo: 'civil',
    apelidos: ['código civil', 'codigo civil', 'direito civil', 'cc/2002', 'cc 2002', 'lei 10.406', 'lei 10406'],
  },
  {
    chave: 'cdc_coordenado',
    arquivo: 'dados-config/materiais-legislacao/cdc_coordenado.txt',
    nome: 'CDC Coordenado (2026)',
    ramo: 'consumidor',
    apelidos: ['código de defesa do consumidor', 'codigo de defesa do consumidor', 'cdc', 'direito do consumidor', 'lei 8.078', 'lei 8078'],
  },
  {
    chave: 'clt_coordenada',
    arquivo: 'dados-config/materiais-legislacao/clt_coordenada.txt',
    nome: 'CLT Coordenada (2026)',
    ramo: 'trabalhista',
    apelidos: ['clt', 'consolidação das leis do trabalho', 'consolidacao das leis do trabalho', 'direito do trabalho', 'direito trabalhista', 'justa causa', 'aviso prévio', 'aviso previo', 'rescisão trabalhista', 'rescisao trabalhista', 'rescisão indireta', 'rescisao indireta', 'demissão', 'demissao', 'dispensa', 'fgts', 'férias', 'ferias', 'décimo terceiro', 'decimo terceiro', 'horas extras', 'estabilidade', 'jornada de trabalho', 'contrato de trabalho', 'vínculo empregatício', 'vinculo empregaticio'],
  },
  {
    chave: 'cpc_coordenado',
    arquivo: 'dados-config/materiais-legislacao/cpc_coordenado.txt',
    nome: 'CPC Coordenado',
    ramo: 'processo_civil',
    apelidos: ['código de processo civil', 'codigo de processo civil', 'cpc', 'processo civil', 'lei 13.105', 'lei 13105'],
  },
  {
    chave: 'cpc_360',
    arquivo: 'dados-config/materiais-legislacao/cpc_legislacao_360.txt',
    nome: 'CPC — Legislação 360 (2026)',
    ramo: 'processo_civil',
    apelidos: ['código de processo civil', 'codigo de processo civil', 'cpc', 'processo civil', 'lei 13.105', 'lei 13105'],
  },
  {
    chave: 'cpp_coordenado',
    arquivo: 'dados-config/materiais-legislacao/cpp_coordenado.txt',
    nome: 'Código de Processo Penal Coordenado',
    ramo: 'processo_penal',
    apelidos: ['código de processo penal', 'codigo de processo penal', 'cpp', 'processo penal', 'decreto-lei 3.689', 'decreto lei 3689'],
  },
  {
    chave: 'cpp_360',
    arquivo: 'dados-config/materiais-legislacao/cpp_legislacao_360.txt',
    nome: 'CPP — Legislação 360 (2026)',
    ramo: 'processo_penal',
    apelidos: ['código de processo penal', 'codigo de processo penal', 'cpp', 'processo penal', 'decreto-lei 3.689', 'decreto lei 3689'],
  },
  {
    chave: 'codigo_penal_coordenado',
    arquivo: 'dados-config/materiais-legislacao/codigo_penal_coordenado.txt',
    nome: 'Código Penal Coordenado',
    ramo: 'penal',
    apelidos: ['código penal', 'codigo penal', 'direito penal', 'decreto-lei 2.848', 'decreto lei 2848'],
  },
  {
    chave: 'codigo_penal_360',
    arquivo: 'dados-config/materiais-legislacao/codigo_penal_legislacao_360.txt',
    nome: 'Código Penal — Legislação 360 (2026)',
    ramo: 'penal',
    apelidos: ['código penal', 'codigo penal', 'direito penal', 'decreto-lei 2.848', 'decreto lei 2848'],
  },
  {
    chave: 'ctn_coordenado',
    arquivo: 'dados-config/materiais-legislacao/ctn_coordenado.txt',
    nome: 'CTN Coordenado',
    ramo: 'tributario',
    apelidos: ['código tributário nacional', 'codigo tributario nacional', 'ctn', 'direito tributário', 'direito tributario', 'lei 5.172', 'lei 5172'],
  },
  {
    chave: 'legislacao_tributaria_coordenada',
    arquivo: 'dados-config/materiais-legislacao/legislacao_tributaria_coordenada.txt',
    nome: 'Legislação Tributária Coordenada (2026)',
    ramo: 'tributario',
    apelidos: ['código tributário nacional', 'codigo tributario nacional', 'ctn', 'direito tributário', 'direito tributario', 'tributo', 'imposto'],
  },
  {
    chave: 'constituicao_federal_360',
    arquivo: 'dados-config/materiais-legislacao/constituicao_federal_legislacao_360.txt',
    nome: 'Constituição Federal — Legislação 360 (2026)',
    ramo: 'constitucional',
    apelidos: ['constituição federal', 'constituicao federal', 'cf/88', 'cf 88', 'direito constitucional', 'estado de defesa', 'estado de sítio', 'estado de sitio', 'intervenção federal', 'intervencao federal', 'calamidade pública', 'calamidade publica', 'forças armadas', 'forcas armadas', 'sistema constitucional das crises'],
  },
  {
    chave: 'legislacao_constitucional_coordenada',
    arquivo: 'dados-config/materiais-legislacao/legislacao_constitucional_coordenada.txt',
    nome: 'Legislação Constitucional Coordenada (2026)',
    ramo: 'constitucional',
    apelidos: ['constituição federal', 'constituicao federal', 'cf/88', 'cf 88', 'direito constitucional', 'controle de constitucionalidade', 'direitos fundamentais', 'estado de defesa', 'estado de sítio', 'estado de sitio', 'intervenção federal', 'intervencao federal', 'calamidade pública', 'calamidade publica', 'sistema constitucional das crises'],
  },
  {
    chave: 'legislacao_administrativa_360',
    arquivo: 'dados-config/materiais-legislacao/legislacao_administrativa_360.txt',
    nome: 'Legislação Administrativa — Legislação 360 (2026)',
    ramo: 'administrativo',
    apelidos: ['direito administrativo', 'lei 8.112', 'lei 8112', 'licitação', 'licitacao', 'improbidade administrativa', 'servidor público', 'servidor publico', 'lei 14.133', 'lei 14133', 'processo administrativo'],
  },
  {
    chave: 'legislacao_administrativa_coordenada',
    arquivo: 'dados-config/materiais-legislacao/legislacao_administrativa_coordenada.txt',
    nome: 'Legislação Administrativa Coordenada (2026)',
    ramo: 'administrativo',
    apelidos: ['direito administrativo', 'lei 8.112', 'lei 8112', 'licitação', 'licitacao', 'improbidade administrativa', 'servidor público', 'servidor publico', 'lei 14.133', 'lei 14133', 'processo administrativo'],
  },
  {
    chave: 'legislacao_direitos_difusos_coletivos',
    arquivo: 'dados-config/materiais-legislacao/legislacao_direitos_difusos_coletivos.txt',
    nome: 'Legislação de Direitos Difusos e Coletivos Coordenada',
    ramo: 'difusos_coletivos',
    apelidos: ['direitos difusos', 'direitos coletivos', 'direito coletivo', 'ação civil pública', 'acao civil publica', 'processo coletivo', 'ação popular', 'acao popular', 'mandado de segurança coletivo', 'mandado de seguranca coletivo'],
  },
  {
    chave: 'legislacao_penal_especial',
    arquivo: 'dados-config/materiais-legislacao/legislacao_penal_especial.txt',
    nome: 'Legislação Penal Especial — Legislação 360 (2025)',
    ramo: 'penal_especial',
    apelidos: ['legislação penal especial', 'legislacao penal especial', 'lei de drogas', 'crimes hediondos', 'lei maria da penha', 'estatuto do desarmamento', 'abuso de autoridade', 'organização criminosa', 'organizacao criminosa', 'lavagem de dinheiro', 'lei de tortura', 'crimes ambientais'],
  },
  {
    chave: 'legislacao_previdenciaria',
    arquivo: 'dados-config/materiais-legislacao/legislacao_previdenciaria.txt',
    nome: 'Legislação Previdenciária — Legislação 360 (2024)',
    ramo: 'previdenciario',
    apelidos: ['direito previdenciário', 'direito previdenciario', 'regime geral de previdência social', 'regime geral de previdencia social', 'rgps', 'benefício previdenciário', 'beneficio previdenciario', 'lei 8.213', 'lei 8213', 'lei 8.212', 'lei 8212', 'aposentadoria', 'inss'],
  },
  {
    chave: 'ctb_legislacao_360',
    arquivo: 'dados-config/materiais-legislacao/ctb_legislacao_360.txt',
    nome: 'CTB — Legislação 360 (2026)',
    ramo: 'transito',
    apelidos: ['código de trânsito brasileiro', 'codigo de transito brasileiro', 'ctb', 'direito de trânsito', 'direito de transito', 'lei 9.503', 'lei 9503'],
  },
  {
    chave: 'sumulas_ojs_tst',
    arquivo: 'dados-config/materiais-legislacao/sumulas_ojs_tst_coordenadas.txt',
    nome: 'Súmulas e OJs do TST Coordenadas (2026)',
    ramo: 'trabalhista',
    apelidos: ['súmula do tst', 'sumula do tst', 'orientação jurisprudencial', 'orientacao jurisprudencial', 'oj do tst', 'tst', 'tribunal superior do trabalho'],
  },
  {
    chave: 'recursos_especiais_stf',
    arquivo: 'dados-config/materiais-legislacao/recursos_especiais_stf_coordenado.txt',
    nome: 'Recursos Especiais/Extraordinários — STF Coordenado (2026)',
    ramo: 'jurisprudencia',
    apelidos: ['recurso extraordinário', 'recurso extraordinario', 'repercussão geral', 'repercussao geral', 'recurso especial', 'stf', 'supremo tribunal federal'],
  },
];

// cache de módulo: chave -> texto já limpo e dividido em blocos
const cbCacheLegislacao = {};

function cbLimparTextoLeiCoordenada(texto) {
  return texto
    .split(/\r?\n/)
    .filter((l) => {
      const t = l.trim();
      if (!t) return false;
      if (/^\d+$/.test(t)) return false; // número de página solto
      if (/^\d+\.\d{2}\/\d{2}\/\d{4}$/.test(t)) return false; // timbre de rodapé
      if (/\.{2,}\s*\d+\s*$/.test(t)) return false; // linha de sumário
      return true;
    })
    .join('\n');
}

// Divide o texto em blocos de tamanho parecido (~1200 caracteres), sempre
// fechando num fim de linha, pra manter contexto coeso sem estourar o prompt.
function cbDividirEmBlocosLegislacao(texto, tamanhoAlvo) {
  const paragrafos = texto.split(/\n{1,}/).map((p) => p.trim()).filter(Boolean);
  const blocos = [];
  let atual = '';
  for (const p of paragrafos) {
    if (atual && (atual.length + p.length) > tamanhoAlvo) {
      blocos.push(atual);
      atual = p;
    } else {
      atual = atual ? `${atual}\n${p}` : p;
    }
  }
  if (atual) blocos.push(atual);
  return blocos;
}

async function cbCarregarLivroLegislacao(livro) {
  if (cbCacheLegislacao[livro.chave]) return cbCacheLegislacao[livro.chave];
  try {
    const url = chrome.runtime.getURL(livro.arquivo);
    const resp = await fetch(url);
    if (!resp.ok) return null;
    const bruto = await resp.text();
    const limpo = cbLimparTextoLeiCoordenada(bruto);
    const blocos = cbDividirEmBlocosLegislacao(limpo, 1200);
    cbCacheLegislacao[livro.chave] = blocos;
    return blocos;
  } catch (e) {
    return null;
  }
}

// ramosClassificados: array opcional de chaves de ramo (ver
// ia-classificador-materia.js) já identificadas por IA pra essa pergunta —
// um livro entra se bater por PALAVRA-CHAVE (apelido) OU por RAMO
// classificado, o que pegar mais nunca atrapalha (é só mais uma fonte
// candidata, o score de sobreposição de palavras decide o que realmente
// entra na resposta final).
function cbIdentificarLivrosLegislacao(pergunta, ramosClassificados) {
  const alvo = ` ${String(pergunta || '').toLowerCase()} `;
  const ramos = Array.isArray(ramosClassificados) ? ramosClassificados : [];
  return CB_LEGISLACAO_LIVROS.filter((livro) => (
    livro.apelidos.some((a) => alvo.includes(a)) || ramos.includes(livro.ramo)
  ));
}

// Retorna { fonteLabel, resumo, fontes } com os melhores trechos das
// coletâneas cujo código/ramo bateu com a pergunta, ou null se nada bateu ou
// nenhum trecho teve sobreposição relevante de palavras.
async function cbBuscarNaLegislacaoPermanente(pergunta, ramosClassificados) {
  const livros = cbIdentificarLivrosLegislacao(pergunta, ramosClassificados);
  if (!livros.length) return null;

  const palavras = String(pergunta || '')
    .toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter((p) => p.length > 3);
  if (!palavras.length) return null;

  const candidatos = [];
  for (const livro of livros) {
    const blocos = await cbCarregarLivroLegislacao(livro);
    if (!blocos) continue;
    blocos.forEach((bloco, indice) => {
      const alvo = bloco.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
      let score = 0;
      palavras.forEach((p) => { if (alvo.includes(p)) score += 1; });
      if (score > 0) candidatos.push({ livro: livro.nome, bloco, score, blocos, indice });
    });
  }

  if (!candidatos.length) return null;
  candidatos.sort((a, b) => b.score - a.score);
  const melhores = candidatos.slice(0, 3);

  // Puxa o bloco SEGUINTE de cada melhor achado, do mesmo livro — um artigo
  // (ex.: art. 136 CF) pode ter o caput/§1º num bloco e o §2º com o prazo
  // exato no bloco de baixo, cortado pela divisão em ~1200 caracteres. Sem
  // isso, a busca acha "o artigo certo" mas devolve um parágrafo incompleto,
  // e a IA fica sem o número que precisava (o que já aconteceu de verdade:
  // achou "o decreto determinará o tempo de duração" do §1º, mas não achou o
  // "trinta dias" do §2º, que ficou no bloco seguinte).
  const melhoresComContinuacao = melhores.map((c) => {
    const proximo = c.blocos[c.indice + 1];
    const bloco = proximo && !melhores.some((m) => m.bloco === proximo)
      ? `${c.bloco}\n${proximo}`
      : c.bloco;
    return { livro: c.livro, bloco };
  });

  const resumo = melhoresComContinuacao.map((c) => `[${c.livro}]\n${c.bloco}`).join('\n\n---\n\n');
  const fontes = Array.from(new Set(melhores.map((c) => c.livro))).map((titulo) => ({ titulo, url: null, interna: true }));
  return {
    fonteLabel: 'Legislação coordenada (coletânea importada localmente)',
    resumo,
    fontes,
    avisoTipo: 'Isto é texto de LEI/CÓDIGO extraído de uma coletânea comercial coordenada, não o Diário Oficial nem o Planalto — confira o número do artigo antes de citar como fonte oficial se a coletânea puder estar desatualizada.',
  };
}

window.cbBuscarNaLegislacaoPermanente = cbBuscarNaLegislacaoPermanente;
window.cbIdentificarLivrosLegislacao = cbIdentificarLivrosLegislacao;
window.CB_LEGISLACAO_LIVROS = CB_LEGISLACAO_LIVROS;
