// ===================== BUSCA NO PLANALTO.GOV.BR (texto oficial das leis) =====================
//
// Pra perguntas de direito, busca o texto oficial direto do planalto.gov.br
// (fonte primária) em vez de confiar só na Wikipédia. Mantém um dicionário
// pequeno dos códigos/leis mais cobrados em concurso; o texto de cada um é
// baixado uma vez e guardado em cache local (chrome.storage, expira em 7
// dias) — não busca de novo a cada pergunta.
//
// Usado por dados-config/ia-pesquisa-externa.js.

const CB_LEIS_PLANALTO = [
  { chave: 'constituicao', apelidos: ['constituição', 'constituicao', 'cf/88', 'cf 88', 'carta magna'], nome: 'Constituição Federal', url: 'https://www.planalto.gov.br/ccivil_03/constituicao/constituicao.htm' },
  { chave: 'codigo_civil', apelidos: ['código civil', 'codigo civil', 'cc/2002', 'cc 2002'], nome: 'Código Civil', url: 'https://www.planalto.gov.br/ccivil_03/leis/2002/l10406compilada.htm' },
  { chave: 'cpc', apelidos: ['código de processo civil', 'codigo de processo civil', ' cpc '], nome: 'Código de Processo Civil', url: 'https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2015/lei/l13105.htm' },
  { chave: 'codigo_penal', apelidos: ['código penal', 'codigo penal'], nome: 'Código Penal', url: 'https://www.planalto.gov.br/ccivil_03/decreto-lei/del2848compilado.htm' },
  { chave: 'cpp', apelidos: ['código de processo penal', 'codigo de processo penal', ' cpp '], nome: 'Código de Processo Penal', url: 'https://www.planalto.gov.br/ccivil_03/decreto-lei/del3689compilado.htm' },
  { chave: 'clt', apelidos: [' clt', 'consolidação das leis do trabalho', 'consolidacao das leis do trabalho'], nome: 'CLT', url: 'https://www.planalto.gov.br/ccivil_03/decreto-lei/del5452.htm' },
  { chave: 'cdc', apelidos: [' cdc', 'código de defesa do consumidor', 'codigo de defesa do consumidor'], nome: 'Código de Defesa do Consumidor', url: 'https://www.planalto.gov.br/ccivil_03/leis/l8078compilado.htm' },
  { chave: 'lei_8112', apelidos: ['lei 8.112', 'lei 8112', 'estatuto do servidor', 'regime jurídico único', 'regime juridico unico'], nome: 'Lei 8.112/1990 (Servidores Públicos)', url: 'https://www.planalto.gov.br/ccivil_03/leis/l8112cons.htm' },
  { chave: 'lei_ms', apelidos: ['mandado de segurança', 'mandado de seguranca', 'lei 12.016', 'lei 12016'], nome: 'Lei 12.016/2009 (Mandado de Segurança)', url: 'https://www.planalto.gov.br/ccivil_03/_ato2007-2010/2009/lei/l12016.htm' },
  { chave: 'lia', apelidos: ['improbidade administrativa', 'lei 8.429', 'lei 8429'], nome: 'Lei 8.429/1992 (Improbidade Administrativa)', url: 'https://www.planalto.gov.br/ccivil_03/leis/l8429.htm' },
  { chave: 'lei_9784', apelidos: ['processo administrativo federal', 'lei 9.784', 'lei 9784'], nome: 'Lei 9.784/1999 (Processo Administrativo Federal)', url: 'https://www.planalto.gov.br/ccivil_03/leis/l9784.htm' },
  { chave: 'lei_8666', apelidos: ['lei 8.666', 'lei 8666', 'lei de licitações antiga', 'lei de licitacoes antiga'], nome: 'Lei 8.666/1993 (Licitações)', url: 'https://www.planalto.gov.br/ccivil_03/leis/l8666cons.htm' },
  { chave: 'lei_14133', apelidos: ['lei 14.133', 'lei 14133', 'nova lei de licitações', 'nova lei de licitacoes'], nome: 'Lei 14.133/2021 (Nova Lei de Licitações)', url: 'https://www.planalto.gov.br/ccivil_03/_ato2019-2022/2021/lei/l14133.htm' },
  { chave: 'lei_9099', apelidos: ['juizados especiais', 'lei 9.099', 'lei 9099'], nome: 'Lei 9.099/1995 (Juizados Especiais)', url: 'https://www.planalto.gov.br/ccivil_03/leis/l9099.htm' },
  { chave: 'lacp', apelidos: ['ação civil pública', 'acao civil publica', 'lei 7.347', 'lei 7347'], nome: 'Lei 7.347/1985 (Ação Civil Pública)', url: 'https://www.planalto.gov.br/ccivil_03/leis/l7347compilada.htm' },
  { chave: 'eca', apelidos: ['estatuto da criança', 'estatuto da crianca', ' eca ', 'lei 8.069', 'lei 8069'], nome: 'Lei 8.069/1990 (ECA)', url: 'https://www.planalto.gov.br/ccivil_03/leis/l8069.htm' },
  { chave: 'lindb', apelidos: ['lindb', 'lei de introdução às normas', 'lei de introducao as normas'], nome: 'LINDB (Decreto-Lei 4.657/1942)', url: 'https://www.planalto.gov.br/ccivil_03/decreto-lei/del4657compilado.htm' },
  { chave: 'lei_13146', apelidos: ['estatuto da pessoa com deficiência', 'estatuto da pessoa com deficiencia', 'lei 13.146', 'lei 13146'], nome: 'Lei 13.146/2015 (Estatuto da Pessoa com Deficiência)', url: 'https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2015/lei/l13146.htm' },
  { chave: 'maria_da_penha', apelidos: ['maria da penha', 'lei 11.340', 'lei 11340'], nome: 'Lei 11.340/2006 (Lei Maria da Penha)', url: 'https://www.planalto.gov.br/ccivil_03/_ato2004-2006/2006/lei/l11340.htm' },
  { chave: 'ctb', apelidos: ['código de trânsito', 'codigo de transito', 'lei 9.503', 'lei 9503'], nome: 'Lei 9.503/1997 (Código de Trânsito Brasileiro)', url: 'https://www.planalto.gov.br/ccivil_03/leis/l9503compilado.htm' },
];

// ===================== AVISOS DE (IN)CONSTITUCIONALIDADE =====================
//
// O texto do Planalto é a letra pura da lei — não reflete decisões do STF que
// declararam trechos inconstitucionais sem alterar a redação oficial. Isso faz
// a IA responder "pela letra da lei" e cair em pegadinhas clássicas de
// concurso (ex.: Lei 12.016/2009, art. 7º §2º). Curadoria manual, só dos casos
// mais cobrados — cresce sob demanda.
const CB_AVISOS_INCONSTITUCIONALIDADE = [
  {
    leiChave: 'lei_ms',
    gatilhos: [
      '7º', '7°', '7o', 'art. 7', 'art 7', 'compensação de créditos', 'compensacao de creditos',
      'reclassificação ou equiparação', 'reclassificacao ou equiparacao', 'entrega de mercadorias',
      'bens provenientes do exterior', 'liminar',
    ],
    aviso: 'ATENÇÃO — jurisprudência do STF que NÃO aparece no texto puro da lei acima: na ADI 4296, o STF declarou INCONSTITUCIONAL a parte do art. 7º, §2º, da Lei 12.016/2009 que veda liminar para (i) compensação de créditos tributários, (ii) entrega de mercadorias/bens provenientes do exterior e (iii) reclassificação ou equiparação de servidores públicos. Mesmo com a redação legal ainda escrita dessa forma, é pacífico — e cobrado em concurso como pegadinha — que a vedação de liminar NÃO é mais válida para essas três hipóteses. Só a vedação quanto a "aumento ou extensão de vantagens ou pagamento de qualquer natureza" permanece válida.',
  },
  {
    leiChave: 'lei_ms',
    gatilhos: [
      '23', 'decadência', 'decadencia', 'prazo de 120', '120 dias', 'prazo decadencial',
    ],
    aviso: 'ATENÇÃO — cobrado em concurso: o art. 23 da Lei 12.016/2009 fixa prazo decadencial de 120 dias para impetrar mandado de segurança. Uma pegadinha clássica é dizer que esse prazo é inconstitucional por violar o acesso à justiça (art. 5º, XXXV, CF) — mas o STF já pacificou o contrário: pela Súmula 632, "É constitucional lei que fixa o prazo de decadência para a impetração de mandado de segurança".',
  },
  {
    leiChave: 'lia',
    gatilhos: [
      'culpa', 'culposo', 'culposa', 'dolo', 'retroage', 'retroatividade', 'retroativa',
      'lei 14.230', 'lei 14230', 'tema 1199', 'aplicação da lei no tempo',
    ],
    aviso: 'ATENÇÃO — jurisprudência do STF que altera a leitura do texto legal: a Lei 14.230/2021 reescreveu a Lei 8.429/1992 e ELIMINOU a modalidade culposa de improbidade administrativa (agora exige-se dolo, art. 1º, §§1º-2º). O STF, no Tema 1199 (RE 843.989), fixou que essa mudança é retroativa para BENEFICIAR quem praticou ato culposo antes da reforma e ainda não tem condenação transitada em julgado — ou seja, atos meramente culposos anteriores à lei nova, sem trânsito em julgado, deixam de ser puníveis como improbidade. Não presuma que a lesividade/punibilidade de um ato antigo se mede só pela redação vigente à época dos fatos.',
  },
];

function cbBuscarAvisoInconstitucionalidade(leiChave, pergunta) {
  const alvo = String(pergunta || '').toLowerCase();
  return CB_AVISOS_INCONSTITUCIONALIDADE
    .filter((a) => a.leiChave === leiChave)
    .find((a) => a.gatilhos.some((g) => alvo.includes(g)));
}

function cbIdentificarLeiPlanalto(pergunta) {
  const alvo = ` ${String(pergunta || '').toLowerCase()} `;
  return CB_LEIS_PLANALTO.find((lei) => lei.apelidos.some((a) => alvo.includes(a))) || null;
}

function cbHtmlParaTextoPlano(html) {
  const doc = new DOMParser().parseFromString(html, 'text/html');
  doc.querySelectorAll('script, style').forEach((el) => el.remove());
  return (doc.body ? doc.body.textContent : '').replace(/[ \t]+/g, ' ').replace(/\n{2,}/g, '\n').trim();
}

function cbObterTextoLeiPlanalto(lei) {
  const cacheKey = `cbPlanaltoCache_${lei.chave}`;
  const UMA_SEMANA_MS = 7 * 24 * 60 * 60 * 1000;
  return new Promise((resolve) => {
    chrome.storage.local.get([cacheKey], (res) => {
      const cache = res[cacheKey];
      if (cache && cache.texto && (Date.now() - cache.baixadoEm) < UMA_SEMANA_MS) {
        resolve(cache.texto);
        return;
      }
      fetch(lei.url)
        .then((resp) => (resp.ok ? resp.text() : Promise.reject(new Error(`http_${resp.status}`))))
        .then((html) => {
          const texto = cbHtmlParaTextoPlano(html);
          chrome.storage.local.set({ [cacheKey]: { texto, baixadoEm: Date.now() } });
          resolve(texto);
        })
        .catch(() => resolve(cache ? cache.texto : null));
    });
  });
}

// Mesma lógica de divisão por artigo de interface-popup/ia-leis-import.js,
// já com a busca por palavra-chave embutida.
function cbDividirEBuscarTrechosPlanalto(texto, pergunta, maxTrechos) {
  const re = /Art\.?\s*\d+(?:\.\d+)?[ºª°A-Za-z\-]*\.?/g;
  const matches = [...texto.matchAll(re)];
  const trechos = [];
  for (let i = 0; i < matches.length; i++) {
    const inicio = matches[i].index;
    const fim = i + 1 < matches.length ? matches[i + 1].index : texto.length;
    let trecho = texto.slice(inicio, fim).trim();
    if (trecho.length > 1500) trecho = trecho.slice(0, 1500);
    if (trecho) trechos.push({ artigo: matches[i][0].trim(), texto: trecho });
  }

  const palavras = String(pergunta || '')
    .toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter((p) => p.length > 3);

  const candidatos = trechos
    .map((t) => {
      const alvo = t.texto.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
      let score = 0;
      palavras.forEach((p) => { if (alvo.includes(p)) score += 1; });
      return { artigo: t.artigo, texto: t.texto, score };
    })
    .filter((t) => t.score > 0);

  candidatos.sort((a, b) => b.score - a.score);
  return candidatos.slice(0, maxTrechos || 3);
}

// Retorna { fonte:'planalto', lei, url, trechos:[{artigo,texto}] } ou null
// se a pergunta não bater com nenhum código conhecido, ou se algo falhar.
async function cbBuscarNoPlanalto(pergunta) {
  const lei = cbIdentificarLeiPlanalto(pergunta);
  if (!lei) return null;
  try {
    const texto = await cbObterTextoLeiPlanalto(lei);
    if (!texto) return null;
    const trechos = cbDividirEBuscarTrechosPlanalto(texto, pergunta, 3);
    if (!trechos.length) return null;
    const aviso = cbBuscarAvisoInconstitucionalidade(lei.chave, pergunta);
    if (aviso) trechos.unshift({ artigo: 'AVISO IMPORTANTE (jurisprudência do STF)', texto: aviso.aviso });
    return { fonte: 'planalto', lei: lei.nome, url: lei.url, trechos };
  } catch (e) {
    return null;
  }
}

window.cbBuscarNoPlanalto = cbBuscarNoPlanalto;
window.cbIdentificarLeiPlanalto = cbIdentificarLeiPlanalto;
