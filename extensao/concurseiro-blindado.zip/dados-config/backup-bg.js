// ============================================================================
// backup-bg.js — gancho do backup automático no background.
// Carregado depois de backup-core.js e backup-io.js (manifest "background.scripts"
// no Firefox; importScripts em background.js no Chrome/Opera).
//
// Um alarme de 60 em 60 minutos ('cb-backup-auto') só ACORDA o background; quem
// decide se já está na hora é Core.estaNaHora (intervalo escolhido na página de
// backup: 6, 12 ou 24 h) e se há mudança desde o último arquivo. O alarme é criado
// só se ainda não existir (chrome.alarms.create recria e zera a contagem: ver o
// comentário no começo de background.js).
// O backup automático só roda se a pessoa ligou a opção E permitiu a permissão
// opcional `downloads` na página de backup.
// ============================================================================
(function () {
    'use strict';
    if (typeof chrome === 'undefined' || !chrome.alarms || !chrome.runtime) return;
    const ALARME = 'cb-backup-auto';

    function garantirAlarme() {
        try {
            chrome.alarms.get(ALARME, (existente) => {
                if (chrome.runtime.lastError) return;
                if (!existente) chrome.alarms.create(ALARME, { delayInMinutes: 3, periodInMinutes: 60 });
            });
        } catch (e) { /* sem alarmes: o backup manual continua funcionando */ }
    }

    function rodar() {
        const io = globalThis.CBBackupIO;
        if (!io) return;
        io.tickAutomatico().catch((e) => console.warn('[Backup] falha no backup automático:', e));
    }

    garantirAlarme();
    if (chrome.runtime.onStartup) chrome.runtime.onStartup.addListener(garantirAlarme);
    if (chrome.runtime.onInstalled) chrome.runtime.onInstalled.addListener(garantirAlarme);
    chrome.alarms.onAlarm.addListener((alarme) => { if (alarme && alarme.name === ALARME) rodar(); });

    // Logo depois de a pessoa permitir "salvar em Downloads" e ligar o automático, faz o primeiro backup sem esperar a hora cheia.
    if (chrome.permissions && chrome.permissions.onAdded) {
        chrome.permissions.onAdded.addListener((perms) => {
            if (perms && Array.isArray(perms.permissions) && perms.permissions.indexOf('downloads') !== -1) rodar();
        });
    }
})();
