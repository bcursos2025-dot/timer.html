// ===================== CONTEXTO DE ESTUDO PARA A IA =====================
//
// Junta um resumo compacto da agenda, do desempenho em questões e do tempo
// de estudo da pessoa, pra IA responder com dados reais em vez de "chutar".
// Só LEITURA — nada aqui grava em chrome.storage.
//
// Usado por rotina/ia-cronograma.js e interface-popup/ia-chat.js.

function cbHojeStrCtx() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function cbAddDiasCtx(dataStr, n) {
  const [y, m, d] = dataStr.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  dt.setDate(dt.getDate() + n);
  return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`;
}

function cbFormatarHorasCtx(ms) {
  return `${(Number(ms || 0) / 3600000).toFixed(1)}h`;
}

function cbPctAcertoCtx(stats) {
  if (!stats || !stats.total) return 'sem dados suficientes';
  return `${Math.round((stats.acertos / stats.total) * 100)}% de acerto (${stats.acertos}/${stats.total} questões)`;
}

// Resolve um resumo em texto pronto pra entrar num prompt de IA.
function cbColetarContextoEstudo() {
  return new Promise((resolve) => {
    chrome.storage.local.get([
      'cbCronogramaPorData', 'cbCronogramaHoje', 'cbCronogramaData',
      'questoesPeriodStats', 'questoesPrioridade',
      'studyHistory', 'streakCount',
    ], (local) => {
      chrome.storage.sync.get(['dailyGoalMs', 'metaModo', 'dailyGoalQuestoes'], (sync) => {
        try {
          const hoje = cbHojeStrCtx();

          // Agenda: hoje + próximos 3 dias.
          const porData = local.cbCronogramaPorData ? { ...local.cbCronogramaPorData } : {};
          if (local.cbCronogramaData === hoje) porData[hoje] = local.cbCronogramaHoje || [];
          const linhasAgenda = [];
          for (let i = 0; i < 4; i++) {
            const ds = cbAddDiasCtx(hoje, i);
            const blocos = (porData[ds] || []).slice().sort((a, b) => (a.inicio || '').localeCompare(b.inicio || ''));
            if (!blocos.length) continue;
            const label = i === 0 ? 'Hoje' : i === 1 ? 'Amanhã' : ds;
            const itens = blocos.map((b) => `${b.inicio}-${b.fim} ${b.materia || b.tipo}${b.concluido ? ' (concluído)' : ''}`).join('; ');
            linhasAgenda.push(`${label} (${ds}): ${itens}`);
          }

          // Desempenho em questões.
          const stats7 = local.questoesPeriodStats && local.questoesPeriodStats[7];
          const stats30 = local.questoesPeriodStats && local.questoesPeriodStats[30];
          const fracas = ((local.questoesPrioridade && local.questoesPrioridade.itens) || [])
            .slice(0, 3).map((i) => i.nome).join(', ') || 'sem dados suficientes ainda';

          // Tempo de estudo.
          const studyHistory = local.studyHistory || {};
          let totalSemanaMs = 0;
          for (let i = 0; i < 7; i++) totalSemanaMs += studyHistory[cbAddDiasCtx(hoje, -i)] || 0;
          const metaMs = sync.dailyGoalMs || (4 * 3600000);
          const hojeMs = studyHistory[hoje] || 0;

          const resumo = [
            'DADOS REAIS DA PESSOA (use isso pra responder, não invente números):',
            '',
            'Agenda cadastrada nos próximos dias:',
            linhasAgenda.length ? linhasAgenda.join('\n') : 'Nenhum bloco cadastrado nos próximos dias.',
            '',
            'Desempenho em questões:',
            `- Últimos 7 dias: ${cbPctAcertoCtx(stats7)}`,
            `- Últimos 30 dias: ${cbPctAcertoCtx(stats30)}`,
            `- Matérias mais fracas/prioritárias agora: ${fracas}`,
            '',
            'Tempo de estudo:',
            `- Hoje: ${cbFormatarHorasCtx(hojeMs)} de ${cbFormatarHorasCtx(metaMs)} da meta diária`,
            `- Últimos 7 dias somados: ${cbFormatarHorasCtx(totalSemanaMs)}`,
            `- Sequência atual (streak): ${local.streakCount || 0} dia(s)`,
          ].join('\n');

          resolve(resumo);
        } catch (e) {
          resolve('DADOS REAIS DA PESSOA: indisponíveis no momento.');
        }
      });
    });
  });
}

window.cbColetarContextoEstudo = cbColetarContextoEstudo;
