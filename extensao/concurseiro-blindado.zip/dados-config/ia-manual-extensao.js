// ===================== MANUAL DA EXTENSÃO (para o assistente de iniciantes) =====================
//
// Texto que o assistente do botão "Ajuda" recebe como fonte única sobre a extensão. Foi escrito a partir do código
// (popup.js, background.js, revisao-artigos.js, highlighter.js, primeiros-dias.js). Se um recurso mudar, MUDE AQUI
// também — o assistente só responde sobre a extensão com o que estiver neste texto.
window.CB_MANUAL_EXTENSAO = `
MANUAL DO CONCURSEIRO BLINDADO (fonte única sobre a extensão)

O QUE É
Extensão de navegador para quem estuda para concursos e OAB. Reúne: cronômetro de estudo, leis do Planalto com grifos e jurisprudência, revisão dos artigos de lei dos erros em questões, metas e gráficos de desempenho, bloqueio de distrações e um assistente de I.A.

INICIAR UM ESTUDO
- O botão roxo "Iniciar Estudo" liga o cronômetro. "Pausar" para. O atalho Ctrl+M (Command+M no Mac) pausa e retoma.
- Enquanto a sessão roda, a extensão soma o tempo de estudo e alimenta os gráficos.

ONLINE E OFFLINE (automático, a pessoa não escolhe nada)
- O texto no topo do cronômetro, como "Offline · Leitura", mostra o que a extensão detectou pela aba em que você está.
- Online · Questões: você está em um site de questões (QConcursos, TecConcursos, Gran Cursos, Estratégia Concursos).
- Offline · Leitura: qualquer outro site ou atividade (PDF, livro, lei no Planalto, caderno de papel).
- A troca é automática conforme a aba ativa.

ARTIGOS DOS ERROS (o grande diferencial)
- No QConcursos, ao errar uma questão, a extensão identifica o artigo da lei cobrado e oferece salvar.
- No site do Planalto o texto da lei abre com o artigo grifado e a contagem "errou N×".
- O artigo salvo entra na revisão espaçada: ícone do livro na barra de baixo, "Artigos para revisar". Em cada artigo a pessoa marca "Lembrei" (o artigo volta em 3, 7, 14, 30 e 60 dias, subindo de etapa) ou "Esqueci" (volta no dia seguinte).
- Dá para ligar ou desligar essa captura em Configurações, seção "Artigos da lei".

LEIS NO PLANALTO (planalto.gov.br)
- A extensão acrescenta ferramentas na própria página da lei: marcador de grifos, negrito, modo leitura, artigos importantes e jurisprudência por artigo.
- Captura rápida: com a tecla G ligada, passe o mouse sobre um parágrafo e clique para marcá-lo (também dá para arrastar).

DESEMPENHO
- A barra "Cronômetro | Desempenho" na tela inicial mostra o resultado das questões resolvidas no QConcursos (acertos, erros e total) em Hoje, 7 dias e 30 dias. Só aparece depois de a pessoa resolver questões ou estudar um pouco.
- Há também as abas Histórico (tempo por dia, semana, mês), Produtividade (horários em que você rende mais) e Distrações (tempo em sites fora do estudo).

META E CONQUISTAS
- Meta diária de estudo (padrão 4 horas) com barra de progresso. A sequência mostra quantos dias seguidos a meta foi batida.
- Há níveis por horas estudadas (Calouro, Iniciante, Aprendiz, Dedicado e outros) e conquistas por sequência de dias.

OUTRAS ABAS DA TELA INICIAL
- Acalmar: exercícios de respiração (Box 4-4-4-4, 4-7-8 e calma rápida) para ansiedade.
- Foco: reset de foco de 2 minutos para sair do modo "scroll" antes de estudar.
- Sites: lista dos sites bloqueados durante o estudo. A pergunta "Quer bloquear este site?" aparece na própria página do site; aqui só se vê e se desfaz.
- PCI: monitor de concursos novos e de editais retificados, prorrogados ou suspensos, com filtro de cargo e distância da sua cidade.
- Estudos: autoavaliação diária de esforço, nota de 0 a 3, com relatório simples no fim do mês.
- JUS: busca de jurisprudência (usa um token gratuito do site jurisprudencias.ai, que a pessoa cola ali).
- Diário: busca no Diário Oficial municipal.
- Plano de hoje e Cronograma: organizam os blocos de estudo do dia e da semana; o plano pode ser montado a partir do edital.

ASSISTENTE DE I.A. COMPLETO
- Existe um chat de I.A. mais completo (ícone ao lado da meta diária, depois de liberado) que lê o resumo de estudo da pessoa, cria blocos na agenda e responde dúvidas de matéria.

PLANO PRO E FREE
- Alguns recursos (temas extras, som ambiente, Pomodoro, calendário, histórico mensal, modo hardcore, entre outros) são do plano Pro. Em Configurações, seção "Plano e Licença", a pessoa vê o plano e ativa um código. Quem ainda é Free vê no topo o botão para resgatar o Pro, quando disponível.

MODO INICIANTE (instalação nova)
- No começo a tela mostra só o cronômetro e o cartão "Comece por aqui". Os outros recursos são liberados aos poucos, conforme a pessoa usa, para ela se acostumar com a extensão.
- Liberações: 5 minutos de estudo (meta, conquistas, abas Histórico, Produtividade e Acalmar, Desempenho, botão de perfil); primeiro artigo salvo (Artigos para revisar e Questões); 3 dias de uso (Foco, Sites, Distrações, plano de hoje, dashboard, cronograma, cronômetro flutuante, aviso de backup); 1 hora de estudo (PCI, Estudos, JUS, Diário); 3 horas (assistente de I.A. completo); 5 horas (comunidade, cronômetro no celular e opções visuais avançadas).
- A tela de boas-vindas pode ser revista em Configurações, seção "Modo iniciante".

BACKUP E PRIVACIDADE
- Grifos, comentários, artigos errados e histórico ficam guardados no navegador e somem se a extensão for desinstalada. Em Configurações há o backup em arquivo, manual ou automático, e a restauração.
- A câmera de presença, quando usada, roda só no navegador e não grava imagens; serve para pausar o cronômetro quando a pessoa sai da frente da tela.

LIMITES
- Este manual não cobre preços, datas de lançamento nem promessas futuras. Para qualquer coisa fora dele, diga que não tem essa informação e sugira Configurações > Ajuda ou o botão de feedback.
`;
