// ===================== PROVEDOR DE IA (com fallback automático) =====================
//
// GERAÇÃO da resposta (cbGerarRespostaIA) encadeia as opções abaixo, na ordem,
// até uma responder (as gratuitas primeiro, as que gastam crédito por último):
//   1) Pollinations AI   — sem chave, sem cadastro
//   2) LLM7.io           — sem chave, sem cadastro (token "unused")
//   3) OVHcloud          — sem chave (2 req/min por IP e por modelo; 5 modelos em rodízio)
//   4) Kilo Code         — sem chave (~200 req/h por IP; o catálogo avisa que pode treinar
//                          com os prompts, por isso fica depois dos outros)
//   5) Groq / OpenRouter / Mistral — gratuitos com cadastro: só entram se a pessoa colou a
//                          chave em Configurações → IA (chrome.storage.local.cbChavesIA)
//   6) Google Gemini     — chave pessoal e gratuita (cbGeminiApiKey)
//   7) B.AI              — gasta créditos da conta (mesmo com desconto); só se nada acima responder
//   8) Se nada funcionou e o chamador permite, pede a chave do Gemini com prompt()
//
// As três primeiras usam uma cota COMPARTILHADA entre todo mundo que usa essa
// extensão, então podem esgotar sem aviso (já aconteceu com a Pollinations).
// A lista veio dos repositórios awesome-free-llm-apis e awesome-free-models;
// cada opção nova foi conferida com uma chamada real antes de entrar aqui.
//
// VALIDAÇÃO da resposta final (cbValidarComVariosModelosBAI) é um papel
// separado: roda Hy3, MiMo-V2.5 e Qwen3.8-Flash via B.AI EM PARALELO (não um
// atrás do outro) — cada um dá uma "segunda opinião" independente, de
// famílias de modelo diferentes da que gerou o rascunho original. Se algum
// falhar (rate limit, erro, etc.), os outros seguem normalmente — só desiste
// se os 3 falharem. As opiniões que sobrarem são entregues pra IA principal
// (cbGerarRespostaIA) comparar com o rascunho e a busca, e produzir UMA
// resposta final consolidada. Usada por ia-pesquisa-externa.js
// (cbResponderComVerificacao), não entra na geração normal.
//
// ⚠️ CHAVE DA B.AI TEMPORARIAMENTE FIXA NO CÓDIGO (BAI_API_KEY_DEV_TEMP) ⚠️
// A pedido explícito pra testes locais — REMOVER antes de publicar/distribuir
// a extensão (trocar de volta pro fluxo de prompt() por chave pessoal, que
// está comentado logo abaixo de cbGarantirChaveBAI). Nunca commitar/publicar
// esse arquivo com uma chave de verdade aqui dentro.
//
// Usado por rotina/ia-cronograma.js e interface-popup/ia-chat.js.

const POLLINATIONS_URL = 'https://text.pollinations.ai/openai';
const POLLINATIONS_MODELO = 'openai';
const POLLINATIONS_REFERRER = 'concurseiro-blindado-extension';
const LLM7_URL = 'https://api.llm7.io/v1/chat/completions';
const LLM7_MODELO = 'default';
const BAI_URL = 'https://api.b.ai/v1/chat/completions';
// Modelos de validação, rodados EM PARALELO (ver cbValidarComVariosModelosBAI)
// — IDs conferidos na resposta real de GET /v1/models da B.AI.
const BAI_MODELOS_VALIDACAO = ['hy3', 'mimo-v2.5', 'qwen3.8-flash'];
// ⚠️ TEMPORÁRIO — ver aviso grande no topo do arquivo. REMOVER antes de
// publicar: trocar de volta pro fluxo de prompt() (código comentado abaixo
// de cbGarantirChaveBAI).
const BAI_API_KEY_DEV_TEMP = ''; // chave de desenvolvimento removida na versão pública
// Modelos da B.AI usados na GERAÇÃO quando as IAs sem chave (Pollinations/LLM7)
// falham, do mais barato pro mais caro. No site chat.b.ai nenhum aparece como
// "grátis": todos são cobrados em créditos, só com desconto (MiMo-V2.6-Flash 90%,
// Qwen3.8-Flash 70%, MiMo-V2.6-Pro 50%, DeepSeek-V4.1-Flash 40%, GLM-5.3-Flash 30%).
// Os IDs seguem o padrão dos já conferidos em GET /v1/models (nome em minúsculas);
// se algum ID não existir a B.AI responde 400/404 e passamos pro próximo.
const BAI_MODELOS_GERACAO = ['mimo-v2.6-flash', 'qwen3.8-flash', 'mimo-v2.6-pro', 'deepseek-v4.1-flash', 'glm-5.3-flash'];
const CB_BAI_GERACAO_TIMEOUT_MS = 90000;
let cbBaiModeloQueFunciona = null; // lembra o último que respondeu: tenta ele primeiro na próxima
const GEMINI_URL_BASE = 'https://generativelanguage.googleapis.com/v1beta/models';
const GEMINI_MODELO = 'gemini-2.5-flash';

function cbObterChaveGemini() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['cbGeminiApiKey'], (res) => resolve(res.cbGeminiApiKey || ''));
  });
}

async function cbGarantirChaveGemini() {
  let chave = await cbObterChaveGemini();
  if (chave) return chave;
  chave = prompt(
    'O uso gratuito e sem cadastro da IA está esgotado no momento (cota compartilhada).\n\n' +
    'Cole uma chave gratuita do Google Gemini pra continuar usando a IA\n' +
    '(gere a sua em https://aistudio.google.com/apikey — leva menos de 1 minuto):'
  );
  if (!chave) return '';
  chave = chave.trim();
  if (!chave) return '';
  await new Promise((resolve) => chrome.storage.local.set({ cbGeminiApiKey: chave }, resolve));
  return chave;
}

function cbObterChaveBAI() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['cbBaiApiKey'], (res) => resolve(res.cbBaiApiKey || ''));
  });
}

// ⚠️ TEMPORÁRIO (ver aviso no topo do arquivo) — pula direto pra chave fixa
// de dev, sem perguntar nada. O fluxo original (pede chave pessoal via
// prompt(), só uma vez por sessão se recusar) fica comentado logo abaixo,
// pra restaurar fácil antes de publicar: é só apagar este bloco e
// descomentar o de baixo.
async function cbGarantirChaveBAI() {
  const chaveSalva = await cbObterChaveBAI();
  return chaveSalva || BAI_API_KEY_DEV_TEMP;
}

/* ===== FLUXO ORIGINAL (chave pessoal via prompt) — restaurar antes de publicar =====
let cbBaiRecusadoNestaSessao = false;

async function cbGarantirChaveBAI() {
  if (cbBaiRecusadoNestaSessao) return '';
  let chave = await cbObterChaveBAI();
  if (chave) return chave;
  chave = prompt(
    'Quer que a extensão valide a resposta final com uma segunda IA antes de te entregar (Hy3, MiMo-V2.5 e Qwen3.8-Flash, via B.AI)?\n\n' +
    'Cole uma chave gratuita da B.AI pra ativar essa validação extra\n' +
    '(gere a sua em https://b.ai — ATENÇÃO: esses modelos estão de graça por uma promoção por tempo limitado da própria B.AI, pode virar pago sem aviso. Cancele se não quiser usar — a resposta continua sendo entregue normalmente, só sem essa validação extra):'
  );
  if (!chave) { cbBaiRecusadoNestaSessao = true; return ''; }
  chave = chave.trim();
  if (!chave) { cbBaiRecusadoNestaSessao = true; return ''; }
  await new Promise((resolve) => chrome.storage.local.set({ cbBaiApiKey: chave }, resolve));
  return chave;
}
===== FIM DO FLUXO ORIGINAL ===== */

// Textos que a Pollinations às vezes devolve dentro do CONTEÚDO da resposta,
// com status 200 (não é um erro HTTP), quando a cota compartilhada e sem
// chave se esgota. Como não vem como erro de verdade, precisa ser detectado
// no texto pra não ser confundido com uma resposta válida da IA.
const POLLINATIONS_PADROES_ERRO = [
  'reached its budget',
  'raise the key budget',
  'enter.pollinations.ai/edit-key',
];

function cbPareceErroDeOrcamento(texto) {
  const alvo = String(texto || '').toLowerCase();
  return POLLINATIONS_PADROES_ERRO.some((p) => alvo.includes(p.toLowerCase()));
}

// "signal" é opcional: só quem passa timeoutMs em cbGerarRespostaIA (ex.: o plano
// de estudos por edital) o recebe. Sem ele, o comportamento é o de sempre.
async function cbChamarPollinations(mensagens, signal) {
  const resp = await fetch(`${POLLINATIONS_URL}?referrer=${encodeURIComponent(POLLINATIONS_REFERRER)}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: POLLINATIONS_MODELO, messages: mensagens, temperature: 0.2, top_p: 0.3 }),
    signal,
  });
  if (!resp.ok) {
    const erro = new Error(`pollinations_${resp.status}`);
    erro.status = resp.status;
    throw erro;
  }
  const data = await resp.json();
  const texto = (data?.choices?.[0]?.message?.content || '').trim();
  if (!texto || cbPareceErroDeOrcamento(texto)) {
    throw new Error('pollinations_cota_esgotada');
  }
  return texto;
}

async function cbChamarLLM7(mensagens, signal) {
  const resp = await fetch(LLM7_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer unused',
    },
    body: JSON.stringify({ model: LLM7_MODELO, messages: mensagens, temperature: 0.2, top_p: 0.3 }),
    signal,
  });
  if (!resp.ok) {
    const erro = new Error(`llm7_${resp.status}`);
    erro.status = resp.status;
    throw erro;
  }
  const data = await resp.json();
  const texto = (data?.choices?.[0]?.message?.content || '').trim();
  if (!texto || cbPareceErroDeOrcamento(texto)) {
    throw new Error('llm7_cota_esgotada');
  }
  return texto;
}

// Tempo máximo esperando UM modelo da B.AI responder antes de desistir dele
// (timeout — sem isso, um modelo travado/com rate limit deixa a pessoa
// esperando o tempo que ele quiser, já que fetch() não tem timeout próprio).
// 15s porque o tempo até o primeiro token de alguns desses modelos já passa
// de ~5s sozinho (medido em benchmark público do MiMo-V2.5), e os prompts de
// validação carregam bastante contexto (rascunho + busca dos 8 agentes) —
// 10s dava falso positivo (desativava um modelo só lento, não travado de
// verdade). Como a desativação automática (CB_BAI_MAX_FALHAS) só cobra esse
// tempo UMA vez por sessão, dá pra ser mais tolerante aqui sem acumular
// atraso nas chamadas seguintes.
const CB_BAI_TIMEOUT_MS = 15000;

// B.AI é compatível com o formato OpenAI Chat Completions (mesmo formato de
// mensagens que Pollinations/LLM7 já usam) — só muda a URL, a chave e o
// nome do modelo. "stream" fica false porque quem chama espera o texto
// inteiro de uma vez, igual aos outros provedores.
async function cbChamarBAI(mensagens, chave, modelo, timeoutMs) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs || CB_BAI_TIMEOUT_MS);
  let resp;
  try {
    resp = await fetch(BAI_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${chave}`,
      },
      body: JSON.stringify({ model: modelo, messages: mensagens, temperature: 0.2, top_p: 0.3, stream: false }),
      signal: controller.signal,
    });
  } catch (e) {
    const erro = new Error(e && e.name === 'AbortError' ? `bai_${modelo}_timeout` : `bai_${modelo}_rede`);
    erro.status = e && e.name === 'AbortError' ? 'timeout' : 'rede';
    throw erro;
  } finally {
    clearTimeout(timeoutId);
  }
  if (!resp.ok) {
    const erro = new Error(`bai_${modelo}_${resp.status}`);
    erro.status = resp.status;
    throw erro;
  }
  const data = await resp.json();
  const texto = (data?.choices?.[0]?.message?.content || '').trim();
  if (!texto) throw new Error(`bai_${modelo}_resposta_vazia`);
  return texto;
}

// Contador de falhas consecutivas por modelo, só em memória (dura enquanto o
// popup estiver aberto — reseta a cada nova sessão, igual cbBaiRecusadoNestaSessao).
// Ao bater CB_BAI_MAX_FALHAS, o modelo é IGNORADO nas próximas chamadas sem
// nem tentar de novo — resolve o caso de um modelo específico estar fora do
// ar/com rate limit, que senão atrasaria TODA pergunta pelo tempo de timeout,
// já que o pipeline completo chama a B.AI várias vezes por pergunta
// (suficiência, validação, aprovação, possível revotação).
const CB_BAI_MAX_FALHAS = 1;
const cbBaiFalhasConsecutivas = {};
BAI_MODELOS_VALIDACAO.forEach((m) => { cbBaiFalhasConsecutivas[m] = 0; });

function cbBaiModeloDisponivel(modelo) {
  return (cbBaiFalhasConsecutivas[modelo] || 0) < CB_BAI_MAX_FALHAS;
}

// Dispara (só) os modelos de BAI_MODELOS_VALIDACAO que ainda não foram
// desativados por falha repetida, AO MESMO TEMPO (Promise.allSettled — nunca
// para no primeiro erro, espera todos terminarem, sejam sucesso ou falha)
// com a MESMA chave. Retorna só os que deram certo, como [{modelo, texto},
// ...] — pode vir vazio (se os disponíveis falharem, ou se TODOS já tiverem
// sido desativados, caso em que nem chega a fazer nenhuma chamada de rede),
// mas nunca lança erro.
async function cbValidarComVariosModelosBAI(mensagens, chave) {
  const modelosATentar = BAI_MODELOS_VALIDACAO.filter(cbBaiModeloDisponivel);
  if (!modelosATentar.length) return []; // todos desativados — não espera nada

  const resultados = await Promise.allSettled(
    modelosATentar.map((modelo) => cbChamarBAI(mensagens, chave, modelo).then((texto) => {
      cbBaiFalhasConsecutivas[modelo] = 0; // sucesso reseta o contador
      return { modelo, texto };
    }))
  );

  resultados.forEach((r, i) => {
    if (r.status === 'rejected') {
      const modelo = modelosATentar[i];
      cbBaiFalhasConsecutivas[modelo] = (cbBaiFalhasConsecutivas[modelo] || 0) + 1;
    }
  });

  // 401/403 em qualquer um indica chave inválida/revogada — limpa a chave
  // salva (se houver) pra próxima vez pedir/usar outra.
  const chaveInvalida = resultados.some((r) => r.status === 'rejected' && (r.reason?.status === 401 || r.reason?.status === 403));
  if (chaveInvalida) {
    await new Promise((resolve) => chrome.storage.local.remove('cbBaiApiKey', resolve));
  }

  return resultados
    .filter((r) => r.status === 'fulfilled')
    .map((r) => r.value);
}

// ---------------------------------------------------------------------
// PROVEDORES OpenAI-compatíveis extras (ver "FILA DE PROVEDORES" no topo).
// Todos falam o mesmo formato de /chat/completions; o que muda é URL, chave
// (quando existe) e a lista de modelos. Cada provedor tenta seus modelos em
// ordem: 429/400/404/5xx/timeout → próximo modelo (o limite de uso costuma ser
// POR modelo); 401/403 → chave inválida, desiste do provedor inteiro.
// ---------------------------------------------------------------------
const CB_PROVEDORES_SEM_CHAVE = [
  // OVHcloud (Europa): anônimo, 2 req/min POR IP e POR MODELO — por isso a lista
  // de modelos: cada um tem a própria cota. Sem aviso de treino com os prompts.
  {
    id: 'ovh', nome: 'OVHcloud',
    url: 'https://oai.endpoints.kepler.ai.cloud.ovh.net/v1/chat/completions',
    modelos: ['gpt-oss-120b', 'Qwen3.8-27B', 'Meta-Llama-3_3-70B-Instruct', 'Mistral-Small-3.2-24B-Instruct-2506', 'Qwen3.5-397B-A17B'],
  },
  // Kilo Code: anônimo, ~200 req/hora por IP. ATENÇÃO: o catálogo marca TODOS os
  // modelos grátis como "mayTrainOnYourPrompts" — por isso fica por último.
  {
    id: 'kilo', nome: 'Kilo',
    url: 'https://api.kilo.ai/api/gateway/chat/completions',
    modelos: ['kilo-auto/free'],
  },
];
// Gratuitos com cadastro (sem cartão): a pessoa cola a chave em Configurações → IA.
// Ficam em chrome.storage.local.cbChavesIA = { groq, openrouter, mistral, bai }.
const CB_PROVEDORES_COM_CHAVE = [
  { id: 'groq', nome: 'Groq', url: 'https://api.groq.com/openai/v1/chat/completions', modelos: ['openai/gpt-oss-120b', 'openai/gpt-oss-20b'] },
  { id: 'openrouter', nome: 'OpenRouter', url: 'https://openrouter.ai/api/v1/chat/completions', modelos: ['openrouter/free'] },
  { id: 'mistral', nome: 'Mistral', url: 'https://api.mistral.ai/v1/chat/completions', modelos: ['mistral-small-latest'] },
];

function cbObterChavesIA() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['cbChavesIA'], (res) => resolve((res && res.cbChavesIA) || {}));
  });
}

async function cbChamarOpenAICompat(prov, modelo, chave, mensagens, signal) {
  const headers = { 'Content-Type': 'application/json' };
  if (chave) headers.Authorization = `Bearer ${chave}`;
  const resp = await fetch(prov.url, {
    method: 'POST',
    headers,
    body: JSON.stringify({ model: modelo, messages: mensagens, temperature: 0.2 }),
    signal,
  });
  if (!resp.ok) {
    const erro = new Error(`${prov.id}_${modelo}_${resp.status}`);
    erro.status = resp.status;
    throw erro;
  }
  const data = await resp.json();
  // Modelos de raciocínio às vezes deixam o "pensamento" dentro de <think>…</think>.
  const texto = String(data?.choices?.[0]?.message?.content || '').replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
  if (!texto || cbPareceErroDeOrcamento(texto)) throw new Error(`${prov.id}_${modelo}_vazia`);
  return texto;
}

async function cbGerarComProvedor(prov, chave, mensagens, novoSinal) {
  let ultimoErro = null;
  for (const modelo of prov.modelos) {
    try {
      return await cbChamarOpenAICompat(prov, modelo, chave, mensagens, novoSinal());
    } catch (e) {
      ultimoErro = e;
      if (e && (e.status === 401 || e.status === 403)) break;
    }
  }
  throw ultimoErro || new Error(`${prov.id}_indisponivel`);
}

// GERAÇÃO pela B.AI (último recurso: gasta CRÉDITOS, mesmo com desconto — no
// site chat.b.ai nenhum modelo aparece como grátis): percorre BAI_MODELOS_GERACAO
// até um responder. 401/402/403/429 valem pra conta toda (chave ruim, sem saldo,
// limite): desiste na hora. Outros erros (modelo inexistente, 5xx, timeout)
// passam pro próximo modelo. Devolve o texto ou lança o último erro.
async function cbGerarComBAI(mensagens, timeoutMs) {
  const chaves = await cbObterChavesIA();
  const chave = chaves.bai || (await cbGarantirChaveBAI());
  if (!chave) throw new Error('bai_sem_chave');
  const ordem = cbBaiModeloQueFunciona
    ? [cbBaiModeloQueFunciona].concat(BAI_MODELOS_GERACAO.filter((m) => m !== cbBaiModeloQueFunciona))
    : BAI_MODELOS_GERACAO;
  let ultimoErro = null;
  for (const modelo of ordem) {
    try {
      const texto = await cbChamarBAI(mensagens, chave, modelo, timeoutMs || CB_BAI_GERACAO_TIMEOUT_MS);
      cbBaiModeloQueFunciona = modelo;
      return texto;
    } catch (e) {
      ultimoErro = e;
      if (cbBaiModeloQueFunciona === modelo) cbBaiModeloQueFunciona = null;
      if ([401, 402, 403, 429].includes(e && e.status)) break;
    }
  }
  throw ultimoErro || new Error('bai_indisponivel');
}

// Gemini não tem "role: system" solto — funde o texto de sistema dentro da
// primeira mensagem do papel seguinte, e troca "assistant" por "model".
async function cbChamarGemini(mensagens, chave, signal) {
  const contents = [];
  let prefixoSistema = '';
  mensagens.forEach((m) => {
    if (m.role === 'system') { prefixoSistema += m.content + '\n\n'; return; }
    const texto = prefixoSistema ? prefixoSistema + m.content : m.content;
    contents.push({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: texto }] });
    prefixoSistema = '';
  });

  const resp = await fetch(`${GEMINI_URL_BASE}/${GEMINI_MODELO}:generateContent?key=${encodeURIComponent(chave)}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents,
      generationConfig: {
        temperature: 0.2,
        topP: 0.3,
        thinkingConfig: { thinkingBudget: 24576 }, // "high": orçamento máximo de pensamento do gemini-2.5-flash
      },
    }),
    signal,
  });

  if (!resp.ok) {
    const corpoErro = await resp.text().catch(() => '');
    if (resp.status === 400 || resp.status === 403) {
      // Chave inválida/revogada — limpa pra próxima tentativa pedir outra.
      await new Promise((resolve) => chrome.storage.local.remove('cbGeminiApiKey', resolve));
    }
    throw new Error(`Erro no Gemini (${resp.status}): ${corpoErro.slice(0, 200)}`);
  }

  const data = await resp.json();
  return (data?.candidates?.[0]?.content?.parts || []).map((p) => p.text || '').join('').trim();
}

// mensagens: [{role:'system'|'user'|'assistant', content:string}, ...]
// Retorna o texto puro da resposta da IA (quem chama decide o que fazer com ele).
//
// opcoes (opcional — quem não passa nada tem o comportamento de sempre):
//   timeoutMs      → desiste de CADA provedor após esse tempo e passa pro próximo
//                    (fetch sozinho não tem timeout: uma IA travada deixaria a
//                    tela esperando indefinidamente).
//   naoPedirChave  → se as duas gratuitas falharem e não houver chave do Gemini
//                    salva, lança erro em vez de abrir o prompt() pedindo a chave.
async function cbGerarRespostaIA(mensagens, opcoes) {
  const op = opcoes || {};
  const novoSinal = () => (op.timeoutMs && typeof AbortSignal !== 'undefined' && AbortSignal.timeout ? AbortSignal.timeout(op.timeoutMs) : undefined);
  const falhas = [];
  const tentar = async (nome, fn) => {
    try { return { ok: true, texto: await fn() }; } catch (e) { falhas.push(`${nome}: ${(e && e.message) || e}`); return { ok: false }; }
  };

  let r;
  if (typeof window !== 'undefined') window.cbUltimoProvedorIA = '';

  // 1) Sem chave e sem cadastro.
  r = await tentar('pollinations', () => cbChamarPollinations(mensagens, novoSinal()));
  if (r.ok) return r.texto;
  r = await tentar('llm7', () => cbChamarLLM7(mensagens, novoSinal()));
  if (r.ok) return r.texto;
  for (const prov of CB_PROVEDORES_SEM_CHAVE) {
    r = await tentar(prov.id, () => cbGerarComProvedor(prov, '', mensagens, novoSinal));
    if (r.ok) return r.texto;
  }

  // 2) Gratuitos com a chave que a pessoa colou (só os que ela configurou).
  const chaves = await cbObterChavesIA();
  for (const prov of CB_PROVEDORES_COM_CHAVE) {
    if (!chaves[prov.id]) continue;
    r = await tentar(prov.id, () => cbGerarComProvedor(prov, chaves[prov.id], mensagens, novoSinal));
    if (r.ok) return r.texto;
  }

  // 3) Gemini com a chave pessoal já salva.
  const chaveGemini = await cbObterChaveGemini();
  if (chaveGemini) {
    r = await tentar('gemini', () => cbChamarGemini(mensagens, chaveGemini, novoSinal()));
    if (r.ok) return r.texto;
  }

  // 3b) Puter: modelo de TERCEIROS, pela conta da própria pessoa e só se ela ligou (ia-puter.js). Fica
  // depois de todas as opções acima: é o que entra quando a cota gratuita do app acaba.
  if (typeof window !== 'undefined' && typeof window.cbPuterLigado === 'function' && await window.cbPuterLigado().catch(() => false)) {
    r = await tentar('puter', () => window.cbTentarPuter(mensagens, novoSinal()));
    if (r.ok) { window.cbUltimoProvedorIA = 'puter'; return r.texto; }
  }

  // 4) B.AI (créditos). Só depois de todas as gratuitas.
  r = await tentar('bai', () => cbGerarComBAI(mensagens, op.timeoutMs));
  if (r.ok) return r.texto;

  // 5) Último recurso: pedir uma chave do Gemini (a menos que o chamador não queira prompt()).
  if (!chaveGemini && !op.naoPedirChave) {
    const chave = await cbGarantirChaveGemini();
    if (chave) return cbChamarGemini(mensagens, chave, novoSinal());
  }
  const erro = new Error('As IAs gratuitas estão indisponíveis agora, e nenhuma chave alternativa funcionou.');
  erro.detalhes = falhas;
  console.warn('[IA] todas as opções falharam:', falhas);
  throw erro;
}

// mensagensVerificacao: mesmo formato de cbGerarRespostaIA — usado por
// cbResponderComVerificacao (ia-pesquisa-externa.js). Roda Hy3, MiMo-V2.5 e
// Qwen3.8-Flash em paralelo (via cbValidarComVariosModelosBAI) e retorna a
// lista de opiniões que deram certo: [{modelo, texto}, ...] — pode ser []
// (nunca null) se não tiver chave configurada ou se os 3 falharem. Quem
// chama decide o que fazer com uma lista vazia (cai pro revisor padrão).
async function cbValidarRespostaFinal(mensagensVerificacao) {
  const chave = await cbGarantirChaveBAI();
  if (!chave) return [];
  try {
    return await cbValidarComVariosModelosBAI(mensagensVerificacao, chave);
  } catch (e) {
    return [];
  }
}

window.cbGerarRespostaIA = cbGerarRespostaIA;
window.cbValidarRespostaFinal = cbValidarRespostaFinal;
