// ============================================================================
// chrome.alarms.create(nome, ...) SEMPRE cancela e recria o alarme, mesmo
// chamado com os mesmos parâmetros de novo (documentado pela própria API).
// Isso é um problema porque o Service Worker de Manifest V3 é encerrado
// depois de ~30s sem atividade — e volta do zero (reexecutando TODO o
// script, incluindo essas linhas de create()) toda vez que QUALQUER alarme
// dispara. Com 4 alarmes periódicos nesta extensão, cada disparo de UM
// deles acabava resetando o cronômetro dos OUTROS 3 pra "daqui a X min a
// partir de agora" — na prática, o alarme de comando remoto do celular
// (dispara a cada ~1 min) nunca chegava a completar um ciclo inteiro sem
// ser empurrado pra frente de novo, então o comando enviado pelo celular
// podia demorar bem mais que 1 minuto pra ser conferido, ou nunca ser
// conferido enquanto a extensão continuasse recebendo outros eventos.
// A correção: só criar o alarme se ele ainda não existir de verdade.
function cbCriarAlarmeSePreciso(nome, alarmInfo) {
    chrome.alarms.get(nome, (existente) => {
        if (!existente) chrome.alarms.create(nome, alarmInfo);
    });
}

// ============================================================================
// ALARME DE PRECISÃO DO POMODORO (correção do bug "cronômetro trava depois
// do intervalo e preciso clicar em Estudar de novo") ------------------------
//
// Antes, a ÚNICA coisa que acordava o service worker pra checar se o
// Pomodoro tinha acabado era o alarme 'cb-heartbeat', que roda no seu
// próprio ciclo de 1 em 1 minuto — sem NENHUMA relação com o instante real
// em que o foco/descanso termina. Com um Pomodoro de 55/5 isso já dava até
// ~1 min de atraso; com um Pomodoro de teste de 1 min/1 min, o atraso podia
// ser proporcionalmente enorme (o heartbeat podia ter acabado de disparar
// bem antes da pessoa clicar em Iniciar, e só ia disparar de novo quase 1
// minuto depois de o prazo já ter vencido).
//
// Este alarme aqui é DIFERENTE: é criado (ou substituído) toda vez que um
// novo prazo de Pomodoro nasce (início do foco, início do descanso, ou
// retomada depois de uma pausa), apontando exatamente pro instante em que
// aquele prazo termina (chrome.alarms.create com "when"). O Chrome ainda
// pode atrasar alarmes muito próximos do presente (mínimo de ~1 min em
// extensões publicadas), mas isso já corta o atraso máximo pela metade em
// relação a depender só do heartbeat genérico, e ELIMINA o cenário de
// "o heartbeat disparou 2s antes do prazo vencer e só vai checar de novo
// daqui a quase 1 minuto".
//
// chrome.alarms.create() SEMPRE substitui um alarme de mesmo nome (é o
// comportamento documentado da API) — o que aqui é exatamente o que
// queremos, já que cada novo prazo de Pomodoro invalida o alarme anterior.
function cbAgendarAlarmeFimPomodoro(quandoTermina) {
    try {
        if (!quandoTermina) {
            chrome.alarms.clear('cb-pomodoro-boundary');
            return;
        }
        chrome.alarms.create('cb-pomodoro-boundary', { when: quandoTermina });
    } catch (e) {
        // Nunca deixa uma falha ao agendar esse alarme de reforço derrubar o
        // resto do fluxo — o heartbeat de 1 min continua como rede de
        // segurança mesmo se isso aqui falhar.
        console.warn('[Pomodoro] Falha ao agendar alarme de precisão:', e);
    }
}

// Checagem compartilhada entre o heartbeat (1 em 1 min), o setInterval (só
// enquanto o worker está vivo) e o novo alarme de precisão acima — os três
// "gatilhos" que podem detectar o fim de um período do Pomodoro precisam
// exatamente da mesma lógica de quando é válido chamar processPomodoroTick().
// Retorna a Promise do tick (ou uma já resolvida se não havia nada a fazer)
// pra quem chama poder esperar terminar — ver cbEnfileirarOperacaoDeEstado.
function cbTickPomodoroSeAplicavel() {
    if (sessionState === 'running') {
        if (activeMethod === 'online') checkDistractionLimit();
        if (pomodoroMode) return processPomodoroTick();
    } else if (pomodoroState === 'rest' && sessionState !== 'stopped') {
        // O descanso precisa continuar contando (e voltar pro foco sozinho
        // quando acabar) não importa COMO a sessão ficou "não-running" nesse
        // meio tempo — 'paused_away' (o normal, entrada automática no
        // descanso) mas também 'paused_manual': o botão Pausar do popup e o
        // Modo Hardcore ("só dá pra pausar no intervalo do Pomodoro") os dois
        // levam a esse estado durante o descanso. Antes, só 'paused_away'
        // era aceito aqui — pausar manualmente durante o descanso travava o
        // relógio pro sempre, e o próximo foco nunca começava sozinho.
        // 'stopped' fica de fora de propósito: se a pessoa encerrou a sessão
        // de vez durante o descanso, não faz sentido a extensão religar o
        // estudo sozinha depois.
        if (pomodoroMode) return processPomodoroTick();
    }
    return Promise.resolve();
}

// ============================================================================
// FILA DE OPERAÇÕES DE ESTADO — corrige bug "às vezes trava no descanso do
// Pomodoro sem o PC ter suspendido" -------------------------------------
//
// hydrateState() relê sessionState/pomodoroState/pomodoroEndAt do
// storage.local e SOBRESCREVE as variáveis em memória — e ele roda antes de
// processar QUALQUER mensagem (inclusive coisas triviais como o check de
// câmera a cada 30s). processPomodoroTick() também lê e grava esse mesmo
// storage, de forma assíncrona (get → ... → set). Sem nenhuma trava entre
// essas duas coisas, dava pra acontecer:
//
//   1. processPomodoroTick() começa a transição descanso→foco: lê o
//      pomodoroEndAt antigo, calcula o novo estado 'work' em memória.
//   2. ANTES do storage.local.set() dessa transição terminar, uma mensagem
//      qualquer chega (ex: câmera), dispara hydrateState(), que lê o
//      storage.local AINDA COM O VALOR ANTIGO ('rest', prazo já vencido) e
//      sobrescreve sessionState/pomodoroState em memória de volta pro valor
//      velho.
//   3. O storage.set do passo 1 termina e grava 'work' corretamente — mas
//      as variáveis em memória já foram pisadas pelo passo 2 e voltaram a
//      achar que ainda está em 'rest' com prazo vencido.
//   4. O próximo tick roda de novo a transição em cima do estado errado,
//      podendo regravar 'rest' por cima do 'work' que acabara de ser
//      salvo — o Pomodoro fica preso na fase de descanso indefinidamente,
//      sem qualquer relação com o PC ter suspendido ou não.
//
// A correção: serializar hydrateState()+processMessage() e os ticks do
// Pomodoro numa fila — só uma dessas operações roda de cada vez, então
// hydrateState() nunca lê o storage no meio de uma gravação de transição
// ainda incompleta.
let cbFilaOperacaoEstado = Promise.resolve();
function cbEnfileirarOperacaoDeEstado(fn) {
    const proxima = cbFilaOperacaoEstado.then(fn, fn);
    // Nunca deixa uma falha numa operação travar a fila pras próximas —
    // cada operação já trata seus próprios erros internamente, mas isso é
    // uma rede de segurança extra.
    cbFilaOperacaoEstado = proxima.catch(() => {});
    return proxima;
}

// Classificação local (sem IA, sem custo) de assunto → matéria, usada pelo
// handler 'sincronizar_assuntos_qc' logo abaixo.
// No Chrome, o background roda como Service Worker de verdade e
// importScripts() existe. No Firefox, o background cai no fallback
// "scripts" do manifest (página de evento comum) e importScripts() NÃO
// existe — chamar sem essa guarda quebrava o carregamento do arquivo
// inteiro, derrubando toda a extensão no Firefox. Por isso o arquivo
// também foi adicionado direto no manifest.json ("background.scripts"),
// e aqui só importamos manualmente quando estamos de fato num Service
// Worker (Chrome).
if (typeof importScripts === 'function') {
    importScripts('../qconcursos/dicionario-materias.js');
    importScripts('cronograma-bloqueio.js');
    importScripts('alarme-cronograma.js');
    importScripts('anti-procrastinacao.js');
    importScripts('firebase-sync.js');
    importScripts('questoes-administrativo.js');
    importScripts('questoes-adm-sync.js');
    importScripts('corpus927-bg.js');
    importScripts('../pciconcursos/monitor-pciconcursos.js');
    // Backup dos dados (alarme + salvar em Downloads). No Firefox vêm do manifest ("background.scripts").
    importScripts('backup-core.js');
    importScripts('backup-io.js');
    importScripts('backup-bg.js');
}

// ============================================================================
// Permissão ampla (<all_urls>) — agora é OPCIONAL, não vem mais fixa no
// manifest. O global_overlay.js (cronômetro flutuante + tela de bloqueio
// offline + tela de descanso do pomodoro + painel de comando) só roda fora
// do QConcursos se o usuário autorizar explicitamente. Isso é pedido em
// popup.js, no momento em que a pessoa ativa um recurso que precisa disso,
// nunca no install. Aqui só cuidamos de (des)registrar o content script
// conforme a permissão muda, e de garantir que ele já esteja registrado ao
// abrir o navegador se a pessoa já tinha autorizado antes.
//
// CB_OVERLAY_VERSION — versão do CONTEÚDO do global_overlay.js, não da
// extensão. `chrome.scripting.registerContentScripts` com
// `persistAcrossSessions: true` guarda o registro por conta própria; se a
// gente só checar "já existe um registro com esse ID?" e pular quando sim,
// uma versão antiga do script pode ficar presa mesmo depois de trocar o
// arquivo no disco e recarregar a extensão — foi exatamente isso que
// aconteceu (dashboard antigo e novo desenhando um em cima do outro).
// Suba esse número toda vez que editar global_overlay.js pra forçar o
// Chrome a substituir o registro em vez de reaproveitar o antigo.
// ============================================================================
const CB_GLOBAL_OVERLAY_SCRIPT_ID = 'cb-global-overlay';
const CB_OVERLAY_VERSION = 18; // 17: aviso do modo anti-procrastinação. (antes: 16 = tela escura (cb-offline-overlay) de volta, agora só nos sites que a pessoa mandou bloquear)

async function cbRegistrarOverlayGlobal() {
    try {
        const { cbOverlayVersionRegistrada } = await chrome.storage.local.get(['cbOverlayVersionRegistrada']);
        const existentes = await chrome.scripting.getRegisteredContentScripts({ ids: [CB_GLOBAL_OVERLAY_SCRIPT_ID] });
        const jaRegistrado = existentes.length > 0;
        const versaoDesatualizada = cbOverlayVersionRegistrada !== CB_OVERLAY_VERSION;

        if (jaRegistrado && !versaoDesatualizada) return; // já registrado e já é a versão atual

        if (jaRegistrado) {
            // Existe um registro, mas de uma versão antiga do arquivo — troca
            // em vez de só pular. updateContentScripts substitui de fato o
            // conteúdo que o Chrome vai injetar a partir de agora.
            await chrome.scripting.updateContentScripts([{
                id: CB_GLOBAL_OVERLAY_SCRIPT_ID,
                matches: ['<all_urls>'],
                js: ['overlay-global/global_overlay.js'],
                runAt: 'document_idle',
                persistAcrossSessions: true
            }]);
        } else {
            await chrome.scripting.registerContentScripts([{
                id: CB_GLOBAL_OVERLAY_SCRIPT_ID,
                matches: ['<all_urls>'],
                js: ['overlay-global/global_overlay.js'],
                runAt: 'document_idle',
                persistAcrossSessions: true
            }]);
        }
        await chrome.storage.local.set({ cbOverlayVersionRegistrada: CB_OVERLAY_VERSION });
    } catch (e) {
        console.warn('[Concurseiro Blindado] Falha ao registrar overlay global:', e);
    }
}

async function cbDesregistrarOverlayGlobal() {
    try {
        await chrome.scripting.unregisterContentScripts({ ids: [CB_GLOBAL_OVERLAY_SCRIPT_ID] });
    } catch (e) {
        // provavelmente já não estava registrado — sem problema
    }
}

// IMPORTANTE: chrome.scripting.registerContentScripts só passa a injetar o
// script em páginas carregadas DAQUI PRA FRENTE — ele não entra
// retroativamente em abas que já estavam abertas antes do registro. Sem
// isso, quem já estava numa aba aberta quando concede a permissão (ex: ao
// arrastar o cronômetro) não vê nada até dar F5 na página. Por isso, toda
// vez que garantimos o registro, também injetamos manualmente com
// executeScript em todas as abas http(s) já abertas nesse momento.
// Verifica se o overlay já está presente na aba (evita injetar 2x — os
// `const` no topo do global_overlay.js quebrariam com "already declared"
// se o script rodasse duas vezes na mesma página).
// Verifica se o overlay já presente na aba está na versão atual. Antes essa
// checagem só olhava se `#cb-floating-timer` existia — o que fazia a aba
// ficar presa numa versão antiga pra sempre (o elemento continuava lá, então
// a extensão nunca reinjetava a versão nova). Agora o próprio
// global_overlay.js marca `window.__cbOverlayVersion` assim que roda, então
// comparamos com a versão atual e reinjetamos sempre que estiver diferente
// ou ausente. Isso é seguro porque o arquivo agora roda dentro de uma IIFE
// com guarda de versão, então rodar de novo não quebra com "already declared".
async function cbAbaJaTemOverlay(tabId) {
    try {
        const [{ result }] = await chrome.scripting.executeScript({
            target: { tabId },
            func: () => window.__cbOverlayVersion
        });
        return result === CB_OVERLAY_VERSION;
    } catch (e) {
        return true; // se nem der pra checar (aba especial), não tenta injetar
    }
}

async function cbInjetarOverlaySePreciso(tabId) {
    if (await cbAbaJaTemOverlay(tabId)) return;
    try {
        await chrome.scripting.executeScript({
            target: { tabId },
            files: ['overlay-global/global_overlay.js']
        });
    } catch (e) {
        // aba sem permissão concedida, ou página especial (Web Store etc.)
    }
}

async function cbInjetarOverlayEmAbasAbertas() {
    try {
        const abas = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] });
        for (const aba of abas) {
            if (!aba.id) continue;
            await cbInjetarOverlaySePreciso(aba.id);
        }
    } catch (e) {
        console.warn('[Concurseiro Blindado] Falha ao injetar overlay nas abas abertas:', e);
    }
}

async function cbSincronizarOverlayComPermissao() {
    const temPermissao = await chrome.permissions.contains({ origins: ['<all_urls>'] });
    if (temPermissao) {
        await cbRegistrarOverlayGlobal();
        await cbInjetarOverlayEmAbasAbertas();
    } else {
        await cbDesregistrarOverlayGlobal();
    }
}

// Garante o estado certo assim que o navegador/extensão inicia
chrome.runtime.onStartup?.addListener(cbSincronizarOverlayComPermissao);
chrome.runtime.onInstalled.addListener(cbSincronizarOverlayComPermissao);

// Marca que é uma instalação nova (não uma atualização de versão) — o
// popup usa essa flag pra decidir se mostra a tela de boas-vindas com o
// mini tutorial na primeira vez que a pessoa abrir a extensão.
chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        // cbPrimeirosDias: só instalação nova entra no modo guiado (ver interface-popup/primeiros-dias.js)
        chrome.storage.local.set({ cbOnboardingPendente: true, cbPrimeirosDias: { modo: 'novo', origem: 'instalacao', criadoEm: Date.now(), dias: [], liberado: {} } });
        // animação de boas-vindas em tela cheia (interface-popup/boas-vindas.html); dá pra rever em Configurações → Modo iniciante
        try { chrome.tabs.create({ url: chrome.runtime.getURL('interface-popup/boas-vindas.html') }); } catch (e) { /* sem aba: segue com o tutorial do popup */ }
    }
});

// Mantém sincronizado se a permissão for concedida ou revogada a qualquer
// momento (ex: pela própria página chrome://extensions)
chrome.permissions.onAdded.addListener((perms) => {
    if (perms.origins && perms.origins.includes('<all_urls>')) cbRegistrarOverlayGlobal();
});
chrome.permissions.onRemoved.addListener((perms) => {
    if (perms.origins && perms.origins.includes('<all_urls>')) cbDesregistrarOverlayGlobal();
});

// Se a permissão <all_urls> já tinha sido concedida numa sessão anterior,
// chrome.permissions.onAdded NÃO dispara de novo ao ligar o cronômetro
// flutuante agora (ela já existia). Nesse caso ninguém chama
// cbInjetarOverlayEmAbasAbertas. Como resultado, na aba que já estava
// aberta quando a pessoa arrasta o cronômetro, nada aparece. Por isso
// reforçamos aqui: sempre que floatingTimerEnabled virar true, garantimos
// que a aba ativa no momento já recebe o script, mesmo sem F5.
chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.floatingTimerEnabled || !changes.floatingTimerEnabled.newValue) return;
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
        const aba = tabs[0];
        if (!aba || !aba.id || !/^https?:\/\//.test(aba.url || '')) return;
        await cbInjetarOverlaySePreciso(aba.id);
    });
});

let sessionState = 'stopped'; 
let currentTabHostname = '';
let currentTabId = null;
let currentTabStartTime = Date.now();
let distractionAccumulator = 0; 

// Janela do navegador que está com foco no momento. Necessário porque
// chrome.tabs.onUpdated dispara pra QUALQUER aba que mudar (mesmo em outra
// janela, minimizada ou sem foco) e o campo `tab.active` só diz se aquela
// aba é a ativa DENTRO da própria janela dela — não diz nada sobre se essa
// janela é a que está em foco. Sem checar isso, uma aba de vídeo (ex:
// YouTube) rodando numa janela sem foco, ao disparar eventos de navegação
// (SPA) ou de carregamento, sobrescrevia currentTabId/currentTabHostname
// mesmo com o usuário efetivamente trabalhando noutra janela/aba (ex:
// QConcursos) — só fechando a aba de vídeo o sistema "acertava" de novo.
let focusedWindowId = chrome.windows.WINDOW_ID_NONE;
chrome.windows.getLastFocused({}, (win) => {
    if (win && win.id !== undefined) focusedWindowId = win.id;
});

// Tipo de conteúdo que o content script detectou em cada aba ('pdf' |
// 'videoaula' | undefined). Preenchido por mensagens do global_overlay.js
// (que já faz essa detecção pra decidir a pergunta de exceção) — aqui só
// aproveitamos pra separar "Leitura" de "Vídeo-aula" na aba Atividade sem
// precisar de nenhum seletor manual.
let tabTipoPagina = {};

let activeMethod = 'online';   
let activeActivity = 'questoes';

let pomodoroMode = false;
let pomodoroState = 'work';
let pomodoroTimeLeft = 30 * 60;
let pomodoroWorkMinutes = 25;
let pomodoroRestMinutes = 5;

// Pomodoro Inteligente — reaproveita o MESMO motor de ciclo work/rest acima
// (pomodoroMode continua sendo "existe algum ciclo rodando", de qualquer
// tipo), só troca de onde vêm os minutos de foco/descanso quando
// pomodoroInteligente é true. Progressão fixa, sem opção de personalizar:
// os 2 primeiros ciclos são 25/5, a partir do 3º viram 60/15 pra sempre.
let pomodoroInteligente = false;
let pomodoroInteligenteCiclos = 0;

function cbFasePomodoroInteligente(ciclosConcluidos) {
    return (ciclosConcluidos < 2) ? { work: 25, rest: 5 } : { work: 60, rest: 15 };
}

// Configurações sincronizadas via chrome.storage.sync (acompanham o usuário entre PCs)
let cameraEnabled = true;
let hardcoreMode = false;
let soundEnabled = false;
let soundType = 'none'; // 'none' | 'white' | 'rain' | 'wind' | 'thunder' | 'lofi'
let soundVolume = 0.5;

// Controles de privacidade (padrão: tudo ligado, igual sempre foi — o
// usuário é quem decide desligar)
let siteHistoryEnabled = true;

// Chaves que agora vivem no chrome.storage.sync (config leve, pequena, sem histórico)
const SYNC_KEYS_DEFAULTS = {
    dailyGoalMs: 4 * 60 * 60 * 1000,
    themePref: 'light', // Claro é o único tema liberado na versão FREE (ver data-pro-feature em popup.html); manter 'dark' aqui fazia o padrão de fábrica cair num tema PRO que o usuário FREE nem consegue selecionar.
    pomodoroWorkMinutes: 25,
    pomodoroRestMinutes: 5,
    cameraEnabled: true,
    cameraCheckIntervalMs: 3000,
    cameraDisableForQuestoes: false,
    hardcoreMode: false,
    soundEnabled: false,
    soundType: 'none',
    soundVolume: 0.5,
    siteHistoryEnabled: true,
    qcSyncEnabled: true
};

// Níveis/badges com base no total de horas acumuladas de estudo
const LEVELS = [
    { name: 'Calouro',      hours: 0 },
    { name: 'Iniciante',    hours: 50 },
    { name: 'Aprendiz',     hours: 100 },
    { name: 'Dedicado',     hours: 250 },
    { name: 'Estrategista', hours: 500 },
    { name: 'Auditor',      hours: 1000 },
    { name: 'Mestre',       hours: 2000 },
    { name: 'Lenda',        hours: 3500 }
];

const STREAK_MILESTONES = [3, 7, 14, 30, 60, 100, 180, 365];

// Sites isentos de distração (contam como tempo de estudo)
const EXEMPT_DISTRACTION_HOSTS = [
    'onenote.com',
    'onenote.officeapps.live.com',
    'aistudio.google.com',
    'onedrive.live.com',
    'live.com',
    'office.com',
    'officeapps.live.com',
    'microsoft.com',
    'sharepoint.com'
];

// Bancas/plataformas de questões reconhecidas como "estudo" no modo Online.
// QConcursos continua sendo o único com script de conteúdo dedicado (que lê
// a página pra extrair assunto/matéria da questão — isso é específico do
// HTML do QConcursos e não funciona nos outros sites sem adaptar cada um).
// Nos demais, a extensão só reconhece o tempo como estudo e não força
// redirecionamento; não tem o dicionário de assuntos nem o caderno de erros.
const QUESTION_BANK_HOSTS = [
    'qconcursos.com',
    'tecconcursos.com.br',
    'gran.com.br',
    'grancursosonline.com.br',
    'estrategiaconcursos.com.br'
];

function isQuestionBankHost(hostname) {
    if (!hostname) return false;
    return QUESTION_BANK_HOSTS.some(h => hostname.includes(h));
}

// Hosts liberados manualmente pela pessoa nesta sessão de estudo (respondeu
// "manter sem bloquear" na pergunta de PDF/vídeo de aula). Zera quando a
// sessão para, pra não virar uma liberação permanente sem querer.
let sessaoExcecoesHosts = [];

function isSessaoExcecaoHost(hostname) {
    if (!hostname) return false;
    return sessaoExcecoesHosts.some(h => hostname.includes(h));
}

function isExemptHost(hostname) {
    if (!hostname) return false;
    return EXEMPT_DISTRACTION_HOSTS.some(h => hostname.includes(h));
}

function hydrateState() {
    return new Promise((resolve) => {
        chrome.storage.local.get([
            'sessionState', 'activeMethod', 'activeActivity',
            'pomodoroMode', 'pomodoroState', 'pomodoroEndAt',
            'pomodoroInteligente', 'pomodoroInteligenteCiclos',
            'pomodoroWorkMinutes', 'pomodoroRestMinutes',
            'cbTrackingStartedAt'
        ], (localResult) => {
            chrome.storage.sync.get([
                'pomodoroWorkMinutes', 'pomodoroRestMinutes',
                'cameraEnabled', 'hardcoreMode',
                'soundEnabled', 'soundType', 'soundVolume',
                'siteHistoryEnabled'
            ], (syncResult) => {
                sessionState = localResult.sessionState || 'stopped';
                activeMethod = localResult.activeMethod || 'online';
                activeActivity = localResult.activeActivity || 'questoes';
                pomodoroMode = localResult.pomodoroMode || false;
                pomodoroState = localResult.pomodoroState || 'work';
                pomodoroInteligente = localResult.pomodoroInteligente || false;
                pomodoroInteligenteCiclos = localResult.pomodoroInteligenteCiclos || 0;
                // storage.sync não persiste de verdade em vários navegadores/perfis
                // (sem conta logada, quota, Opera etc. — ver comentário em
                // migrarConfigParaSync). local é a cópia confiável; sync só serve
                // como fallback pra quem tinha configurado antes dessa correção.
                pomodoroWorkMinutes = localResult.pomodoroWorkMinutes || syncResult.pomodoroWorkMinutes || 25;
                pomodoroRestMinutes = localResult.pomodoroRestMinutes || syncResult.pomodoroRestMinutes || 5;

                cameraEnabled = syncResult.cameraEnabled !== undefined ? syncResult.cameraEnabled : true;
                hardcoreMode = syncResult.hardcoreMode || false;
                soundEnabled = syncResult.soundEnabled || false;
                soundType = syncResult.soundType || 'none';
                soundVolume = (typeof syncResult.soundVolume === 'number') ? syncResult.soundVolume : 0.5;
                siteHistoryEnabled = syncResult.siteHistoryEnabled !== undefined ? syncResult.siteHistoryEnabled : true;

                if (localResult.pomodoroEndAt) {
                    pomodoroTimeLeft = Math.max(0, Math.round((localResult.pomodoroEndAt - Date.now()) / 1000));
                }

                // Recupera de onde o tracking parou antes do worker morrer,
                // em vez de assumir Date.now() (que faria o intervalo entre
                // a morte e o despertar simplesmente não contar pra nada).
                if (localResult.cbTrackingStartedAt) {
                    currentTabStartTime = localResult.cbTrackingStartedAt;
                } else {
                    setCurrentTabStartTime(Date.now());
                }
                resolve();
            });
        });
    });
}

// Migração única: configurações leves que existiam apenas em local passam a
// viver também no sync, assim o usuário mantém as preferências entre PCs.
function migrarConfigParaSync() {
    // A flag antiga vivia só no storage.sync — em navegadores onde o sync
    // não persiste de verdade (sem conta logada, quota, Opera, etc.), essa
    // flag nunca "gruda" e a função reroda a cada vez que o service worker
    // acorda, sobrescrevendo preferências (como o tema) de volta pro padrão.
    // Guardar a flag também no storage.local — que é confiável em qualquer
    // navegador — garante que a migração rode de verdade só uma vez.
    chrome.storage.local.get(['migratedToSyncV5Local'], (localFlag) => {
        if (localFlag.migratedToSyncV5Local) return;

        chrome.storage.sync.get(['migratedToSyncV5', 'themePref', 'dailyGoalMs', 'pomodoroWorkMinutes', 'pomodoroRestMinutes'], (syncCheck) => {
            if (syncCheck.migratedToSyncV5) {
                chrome.storage.local.set({ migratedToSyncV5Local: true });
                return;
            }

            chrome.storage.local.get([
                'dailyGoalMs', 'themePref', 'pomodoroWorkMinutes', 'pomodoroRestMinutes'
            ], (localResult) => {
                // Nunca sobrescreve um valor que já exista no sync — só
                // preenche o que estiver faltando.
                const toSync = {
                    dailyGoalMs: syncCheck.dailyGoalMs ?? (localResult.dailyGoalMs || SYNC_KEYS_DEFAULTS.dailyGoalMs),
                    themePref: syncCheck.themePref ?? (localResult.themePref || SYNC_KEYS_DEFAULTS.themePref),
                    pomodoroWorkMinutes: syncCheck.pomodoroWorkMinutes ?? (localResult.pomodoroWorkMinutes || SYNC_KEYS_DEFAULTS.pomodoroWorkMinutes),
                    pomodoroRestMinutes: syncCheck.pomodoroRestMinutes ?? (localResult.pomodoroRestMinutes || SYNC_KEYS_DEFAULTS.pomodoroRestMinutes),
                    cameraEnabled: SYNC_KEYS_DEFAULTS.cameraEnabled,
                    hardcoreMode: SYNC_KEYS_DEFAULTS.hardcoreMode,
                    soundEnabled: SYNC_KEYS_DEFAULTS.soundEnabled,
                    soundType: SYNC_KEYS_DEFAULTS.soundType,
                    soundVolume: SYNC_KEYS_DEFAULTS.soundVolume,
                    siteHistoryEnabled: SYNC_KEYS_DEFAULTS.siteHistoryEnabled,
                    qcSyncEnabled: SYNC_KEYS_DEFAULTS.qcSyncEnabled,
                    migratedToSyncV5: true
                };
                chrome.storage.sync.set(toSync, () => {
                    chrome.storage.local.set({
                        migratedToSyncV5Local: true,
                        themePref: toSync.themePref,
                        pomodoroWorkMinutes: toSync.pomodoroWorkMinutes,
                        pomodoroRestMinutes: toSync.pomodoroRestMinutes
                    });
                    hydrateState();
                });
            });
        });
    });
}

chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'sync' && changes.siteHistoryEnabled) {
        siteHistoryEnabled = changes.siteHistoryEnabled.newValue !== false;
    }
});

// ============================================================================
// AVISO DE ATUALIZAÇÃO DISPONÍVEL (via API pública da AMO)
// ----------------------------------------------------------------------------
// Nem Chrome nem Firefox dão pra extensão um jeito de forçar a checagem de
// update do navegador a rodar de hora em hora (isso é um parâmetro do
// próprio navegador, fora do alcance de qualquer WebExtension). O que dá pra
// fazer: perguntar direto pra API pública da loja da Mozilla (addons.mozilla.
// org) qual é a versão publicada mais recente, e avisar dentro do próprio
// popup se ela for mais nova que a instalada — sem depender do navegador
// notar sozinho.
//
// Usa o ID numérico da AMO (3052680), não o slug com acento da URL: o slug
// pode mudar se o nome do add-on mudar; o ID é fixo pra sempre.
// ============================================================================
const CB_AMO_ADDON_ID = '3052680';
// Tela com o passo a passo para ligar a atualização automática (não leva à loja).
const CB_ATUALIZACAO_PAGINA = 'interface-popup/atualizacao.html';

// Compara "7.5.2.1" com "7.5.2" posição a posição (numérico, não string —
// "7.5.10" > "7.5.9" mesmo comparando string dando o contrário). Falta de
// posição conta como 0 (ex: "7.5.2" == "7.5.2.0").
function cbVersaoEhMaisNova(remota, local) {
    const a = remota.split('.').map(Number);
    const b = local.split('.').map(Number);
    const tamanho = Math.max(a.length, b.length);
    for (let i = 0; i < tamanho; i++) {
        const x = a[i] || 0;
        const y = b[i] || 0;
        if (x > y) return true;
        if (x < y) return false;
    }
    return false;
}

// Depois de avisar sobre uma atualização disponível (banner dispensável no
// popup), se a pessoa passar esse tempo sem atualizar, a extensão abre sozinha,
// numa aba nova, a tela com o passo a passo da atualização automática — só uma
// vez por versão, pra não ficar reabrindo aba a cada checagem depois disso.
const CB_UPDATE_AUTO_ABRIR_APOS_MS = 48 * 60 * 60 * 1000; // 48 horas

async function cbChecarAtualizacaoAMO() {
    try {
        const resp = await fetch(`https://addons.mozilla.org/api/v5/addons/addon/${CB_AMO_ADDON_ID}/`);
        if (!resp.ok) return;
        const dados = await resp.json();
        const versaoRemota = dados?.current_version?.version;
        if (!versaoRemota) return;

        const versaoLocal = chrome.runtime.getManifest().version;
        if (cbVersaoEhMaisNova(versaoRemota, versaoLocal)) {
            const { cbUpdateDisponivel: anterior } = await chrome.storage.local.get('cbUpdateDisponivel');
            // Só carimba "desde quando" na primeira vez que essa versão é
            // detectada — se já tinha um cbUpdateDisponivel pra essa mesma
            // versão, mantém o timestamp original (senão a contagem de 48h
            // nunca fechava, porque essa função roda de novo a cada 1h).
            const desde = (anterior && anterior.versao === versaoRemota && anterior.desde)
                ? anterior.desde
                : Date.now();
            const abertaAutomaticamente = (anterior && anterior.versao === versaoRemota)
                ? !!anterior.abertaAutomaticamente
                : false;
            chrome.storage.local.set({
                cbUpdateDisponivel: { versao: versaoRemota, desde, abertaAutomaticamente }
            });
            cbChecarEscaladaAutoUpdate(versaoRemota, desde, abertaAutomaticamente);
        } else {
            chrome.storage.local.remove('cbUpdateDisponivel');
        }
    } catch (e) {
        // Sem internet, AMO fora do ar, ou o add-on ainda nem foi publicado
        // (ex: durante o desenvolvimento) — falha em silêncio, não afeta o
        // resto da extensão. Tenta de novo no próximo alarme, daqui 1h.
        console.warn('[CB-UpdateCheck] Falha ao checar atualização na AMO:', e);
    }
}

// Se já se passaram 48h desde que a atualização apareceu pela primeira vez
// (independente de a pessoa ter dispensado o banner do popup ou não — ver
// popup.js, cbUpdateDispensadaVersao), abre a tela de atualização sozinha.
function cbChecarEscaladaAutoUpdate(versao, desde, jaAbriuAutomaticamente) {
    if (jaAbriuAutomaticamente) return;
    if (Date.now() - desde < CB_UPDATE_AUTO_ABRIR_APOS_MS) return;
    chrome.tabs.create({ url: chrome.runtime.getURL(CB_ATUALIZACAO_PAGINA) });
    chrome.storage.local.set({
        cbUpdateDisponivel: { versao, desde, abertaAutomaticamente: true }
    });
}

cbCriarAlarmeSePreciso('cb-heartbeat', { periodInMinutes: 1 });
cbCriarAlarmeSePreciso('cb-daily-check', { periodInMinutes: 60 });
cbCriarAlarmeSePreciso('cb-checar-atualizacao', { periodInMinutes: 60 });
cbChecarAtualizacaoAMO(); // também checa uma vez já na inicialização, sem esperar a 1ª hora
chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name === 'cb-heartbeat') {
        // O Chrome descarta o service worker depois de ~30s sem atividade,
        // o que mata o setInterval de 1s lá embaixo — é por isso que a
        // contagem "parava sozinha". chrome.alarms é o único mecanismo que
        // o MV3 garante que vai acordar o worker de novo, então é aqui (e
        // não só no setInterval) que a lógica de tracking/pomodoro/
        // distração PRECISA rodar, usando updateTimeTracking() que calcula
        // por diferença de timestamp (não por contagem incremental), então
        // funciona certo mesmo pulando minutos inteiros de uma vez.
        // Passa pela fila (ver cbEnfileirarOperacaoDeEstado) pra não correr
        // por cima de um processPomodoroTick ainda em andamento disparado
        // por outra mensagem/alarme.
        await cbEnfileirarOperacaoDeEstado(async () => {
            await hydrateState();
            updateTimeTracking();
            setCurrentTabStartTime(Date.now());
            await cbTickPomodoroSeAplicavel();
        });
    }
    if (alarm.name === 'cb-pomodoro-boundary') {
        // Alarme de precisão (ver cbAgendarAlarmeFimPomodoro acima): dispara
        // perto do instante exato em que o foco ou o descanso do Pomodoro
        // deveria terminar, em vez de esperar o próximo pulso do heartbeat
        // genérico de 1 min. Passa pelo mesmo hydrateState() do heartbeat
        // porque o service worker pode ter sido descartado e reiniciado do
        // zero entre um alarme e outro — sem isso, as variáveis em memória
        // (sessionState, pomodoroState etc.) estariam nos valores padrão do
        // topo do arquivo, não no estado real salvo no storage.
        await cbEnfileirarOperacaoDeEstado(async () => {
            await hydrateState();
            updateTimeTracking();
            setCurrentTabStartTime(Date.now());
            await cbTickPomodoroSeAplicavel();
        });
    }
    if (alarm.name === 'cb-daily-check') {
        resetStateOnNewDay();
    }
    if (alarm.name === 'cb-checar-atualizacao') {
        cbChecarAtualizacaoAMO();
    }
});

initializeCurrentTab();
migrarConfigParaSync();
hydrateState();

chrome.runtime.onStartup.addListener(resetStateOnNewDay);
chrome.runtime.onInstalled.addListener(resetStateOnNewDay);
chrome.runtime.onInstalled.addListener(migrarConfigParaSync);

// currentTabStartTime é uma variável em memória — some toda vez que o
// service worker é descartado pelo Chrome (o que acontece rotineiramente,
// ~30s sem atividade; MV3 não tem "processo em background" de verdade).
// Por isso persistimos o timestamp também no storage.local: quando o worker
// "acorda" de novo (via alarme ou evento), recarregamos daqui em vez de
// simplesmente assumir Date.now() — senão o tempo entre a morte e o
// despertar do worker é perdido silenciosamente. Isso, junto com o
// setInterval de 1s morrendo com o worker, era o motivo da contagem
// "parar sozinha depois de alguns minutos".
function setCurrentTabStartTime(ts) {
    currentTabStartTime = ts;
    chrome.storage.local.set({ cbTrackingStartedAt: ts });
}

function initializeCurrentTab() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0] && tabs[0].url) {
            currentTabId = tabs[0].id;
            try {
                currentTabHostname = new URL(tabs[0].url).hostname;
            } catch(e) {
                currentTabHostname = 'interna';
            }
        } else {
            currentTabId = null;
            currentTabHostname = 'interna';
        }
        setCurrentTabStartTime(Date.now());
    });
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.url) delete tabTipoPagina[tabId]; // navegou pra outra página, esquece o tipo antigo
    // Só deixa essa aba virar a "aba atual" se ela for a ativa DENTRO da
    // janela com foco de verdade — senão uma aba (ex: vídeo) numa janela
    // sem foco consegue sobrescrever a detecção da aba que o usuário está
    // realmente usando (ver comentário na declaração de focusedWindowId).
    if (tab.active && tab.windowId === focusedWindowId && (changeInfo.url || changeInfo.status === 'complete')) {
        const urlToUse = changeInfo.url || tab.url;
        if (urlToUse && urlToUse.startsWith('http')) {
            updateTimeTracking(); 
            currentTabId = tabId;
            try {
                currentTabHostname = new URL(urlToUse).hostname;
            } catch (e) {
                currentTabHostname = 'interna';
            }
            setCurrentTabStartTime(Date.now());
        }
    }
});

chrome.tabs.onRemoved.addListener((tabId) => { delete tabTipoPagina[tabId]; });

chrome.commands.onCommand.addListener((command) => {
    if (command !== 'toggle-timer') return;
    // Ctrl+M: pausa se estiver rodando, retoma se estiver pausado, e começa
    // (com o método/atividade já selecionados antes) se estiver parado.
    let novoEstado;
    if (sessionState === 'running') novoEstado = 'paused_manual';
    else novoEstado = 'running';
    chrome.runtime.sendMessage({ action: 'changeState', state: novoEstado });

    // Mostra a "ilha" de comando no topo da aba ativa com o resumo do dia.
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const tab = tabs[0];
        if (!tab || !tab.id) return;
        chrome.tabs.sendMessage(tab.id, { action: 'cbShowCommandIsland', state: novoEstado }, () => {
            // Ignora "no receiving end" em abas onde o overlay global não roda
            // (chrome:// etc.) — void chrome.runtime.lastError só pra não sujar o console.
            void chrome.runtime.lastError;
        });
    });
});

chrome.tabs.onActivated.addListener(async (activeInfo) => {
    // Troca de aba ativa dentro de uma janela sem foco (ex: o usuário está
    // na Janela A, mas algo troca a aba ativa lá na Janela B) não deve
    // mexer no estado global — só a janela em foco de verdade manda.
    if (activeInfo.windowId !== focusedWindowId) return;
    updateTimeTracking();
    try {
        let tab = await chrome.tabs.get(activeInfo.tabId);
        currentTabId = activeInfo.tabId;
        if (tab.url && tab.url.startsWith('http')) {
            currentTabHostname = new URL(tab.url).hostname;
        } else {
            currentTabHostname = 'interna';
        }
        setCurrentTabStartTime(Date.now());
    } catch (e) {
        currentTabId = null;
        currentTabHostname = 'interna';
    }
});

chrome.windows.onFocusChanged.addListener((windowId) => {
    updateTimeTracking();
    focusedWindowId = windowId;
    if (windowId === chrome.windows.WINDOW_ID_NONE) {
        currentTabHostname = 'fora-do-navegador';
    } else {
        initializeCurrentTab();
    }
    setCurrentTabStartTime(Date.now());
});

// Este setInterval NÃO é a garantia da contagem — ele morre junto com o
// service worker sempre que o Chrome o descarta por inatividade (rotineiro
// em MV3). Ele só existe pra dar granularidade de 1s enquanto o worker
// acontece de estar vivo (ex: popup aberto). A garantia de verdade é o
// alarme 'cb-heartbeat' acima, que reconstrói o tempo perdido por diferença
// de timestamp sempre que o Chrome acorda o worker de novo.
setInterval(() => {
    // Enfileirado junto com os alarmes/mensagens (ver
    // cbEnfileirarOperacaoDeEstado) pra este tick nunca rodar
    // processPomodoroTick() ao mesmo tempo que um heartbeat/mensagem
    // concorrente — dois ticks simultâneos podiam se pisar e um deles
    // regravar por cima da transição de fase que o outro acabara de salvar.
    cbEnfileirarOperacaoDeEstado(async () => {
        updateTimeTracking();
        setCurrentTabStartTime(Date.now());

        // Mantém pomodoroTimeLeft sincronizado no storage para a UI — só
        // enquanto a sessão de estudo está mesmo 'running'. Fora disso o
        // relógio do Pomodoro não deve andar (ver 'togglePomodoro' acima).
        if (pomodoroMode && pomodoroState === 'work' && sessionState === 'running') {
            await new Promise((resolve) => {
                chrome.storage.local.get(['pomodoroEndAt'], (result) => {
                    if (result.pomodoroEndAt) {
                        const timeLeft = Math.max(0, Math.round((result.pomodoroEndAt - Date.now()) / 1000));
                        chrome.storage.local.set({ pomodoroTimeLeft: timeLeft }, resolve);
                    } else {
                        resolve();
                    }
                });
            });
        }

        await cbTickPomodoroSeAplicavel();
    });
}, 1000);

function getTodayKey() {
    return getDayKeyFor(Date.now());
}

function getDayKeyFor(ms) {
    const d = new Date(ms);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

// Divide um intervalo [startMs, endMs) nos pedaços que caem em cada dia
// local, cortando exatamente na meia-noite — assim um intervalo que
// atravessa a virada do dia (ex: sessão rodando às 23:58 até 00:03) credita
// o tempo certo pra cada dia, em vez de jogar tudo no dia de início ou no
// dia em que o tick aconteceu de rodar.
function dividirPorDia(startMs, endMs) {
    const pedacos = [];
    let cursor = startMs;
    while (cursor < endMs) {
        const d = new Date(cursor);
        const proximaMeiaNoite = new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1, 0, 0, 0, 0).getTime();
        const fimDoPedaco = Math.min(endMs, proximaMeiaNoite);
        pedacos.push({ dia: getDayKeyFor(cursor), ms: fimDoPedaco - cursor, fimMs: fimDoPedaco });
        cursor = fimDoPedaco;
    }
    return pedacos;
}

// ===================== RASTREAMENTO DE PAUSAS =====================
// Guarda, por dia, quanto tempo total a sessão ficou pausada (motivo
// manual, ausência da câmera ou intervalo do Pomodoro) e quantas vezes
// isso aconteceu. Persistido em chrome.storage.local (pauseHistory) e
// o timestamp de início da pausa atual (pauseStartedAt) também vai pro
// storage para sobreviver a suspensões do service worker.

function iniciarContagemPausa() {
    const today = getTodayKey();
    chrome.storage.local.get(['pauseHistory'], (result) => {
        let pauseHistory = result.pauseHistory || {};
        if (!pauseHistory[today]) pauseHistory[today] = { totalMs: 0, count: 0 };
        pauseHistory[today].count += 1;
        chrome.storage.local.set({ pauseHistory, pauseStartedAt: Date.now() });
    });
}

// Teto de sanidade: acima disso não é mais "uma pausa", é a extensão tendo
// ficado fechada/o PC hibernado por muito tempo entre um pausarPomodoroSeNecessario
// (ou parada manual) e a próxima retomada — sem esse teto, reabrir o Chrome
// depois de alguns dias credita um totalMs gigantesco e sem sentido no dia
// da retomada.
const PAUSA_MAX_CREDITAVEL_MS = 6 * 60 * 60 * 1000; // 6 horas

function finalizarContagemPausa() {
    chrome.storage.local.get(['pauseStartedAt', 'pauseHistory'], (result) => {
        if (!result.pauseStartedAt) return;
        let pauseHistory = result.pauseHistory || {};
        const agora = Date.now();
        const fimCreditavel = Math.min(agora, result.pauseStartedAt + PAUSA_MAX_CREDITAVEL_MS);
        if (fimCreditavel > result.pauseStartedAt) {
            for (const { dia, ms } of dividirPorDia(result.pauseStartedAt, fimCreditavel)) {
                if (!pauseHistory[dia]) pauseHistory[dia] = { totalMs: 0, count: 0 };
                pauseHistory[dia].totalMs += ms;
            }
        }
        chrome.storage.local.set({ pauseHistory, pauseStartedAt: null });
    });
}


function updateTimeTracking() {
    const agora = Date.now();
    const elapsedTotal = agora - currentTabStartTime;
    if (elapsedTotal <= 0) return;
    // Corta o intervalo nas meias-noites que ele atravessar, pra um tick
    // (ou uma volta do service worker) que começou num dia e terminou no
    // seguinte não jogar tudo inteiro num dia só.
    const segmentos = dividirPorDia(currentTabStartTime, agora);

    chrome.storage.local.get([
        'studyHistory',
        'siteHistory',
        'activeMethod',
        'activityHistory',
        'planoItemAtivo',
        'planoTempo',
        'cbInterfaceMode',
        'siteHourlyHistory'
    ], (result) => {
        let studyHistory = result.studyHistory || {};
        let siteHistory = result.siteHistory || {};
        // Uso de sites por HORA do dia (aba Distrações → "Horários de uso"): { 'AAAA-MM-DD': { '14': ms } }.
        // Antes esse gráfico jogava o total inteiro na hora atual, porque só existia o total por site.
        let siteHourlyHistory = result.siteHourlyHistory || {};
        let activityHistory = result.activityHistory || {};

        // Plano de estudos por edital: se a pessoa escolheu "estudar esta matéria
        // agora" (planoItemAtivo, gravado pela mini tabela do popup), o MESMO tempo
        // que conta como estudo geral é somado também no item do plano. Só este
        // trecho escreve planoTempo — a UI grava os registros em outra chave.
        // O item só vale no dia em que foi ativado (passou da meia-noite, para).
        const planoAtivo = result.planoItemAtivo;
        let planoTempo = result.planoTempo || {};
        let planoTempoMudou = false;
        const registrarPlano = (msPlano, diaPlano) => {
            if (!planoAtivo || !planoAtivo.id || planoAtivo.dia !== diaPlano) return;
            planoTempo[planoAtivo.id] = (planoTempo[planoAtivo.id] || 0) + msPlano;
            planoTempoMudou = true;
        };

        let method = result.activeMethod || 'online';

        const isBrowserSite = currentTabHostname && currentTabHostname !== 'interna' && currentTabHostname !== 'fora-do-navegador';
        const exempt = isExemptHost(currentTabHostname) || isSessaoExcecaoHost(currentTabHostname);

        // Modo "Novo": Modo e Atividade são DECIDIDOS PELA ABA — site de questões ⇒ online + questões;
        // qualquer outro site ⇒ offline + leitura. Antes quem decidia era só o popup, no instante em que
        // abria: se ele tivesse sido aberto numa página qualquer (offline/leitura) e depois a pessoa
        // resolvesse questões com o popup FECHADO, o tempo caía em "Leitura", "Questões" ficava em "—" e
        // o modo ficava errado. Agora a mesma regra roda aqui a cada tick (só para sites http de verdade:
        // páginas internas e "fora do navegador" não mudam nada). No modo "Antigo" a escolha é manual.
        let modoMudou = false;
        if (result.cbInterfaceMode !== 'antigo' && isBrowserSite) {
            const online = isQuestionBankHost(currentTabHostname);
            const novoMetodo = online ? 'online' : 'offline';
            const novaAtividade = online ? 'questoes' : 'leitura';
            if (novoMetodo !== activeMethod || novaAtividade !== activeActivity) {
                activeMethod = novoMetodo;
                activeActivity = novaAtividade;
                modoMudou = true;
            }
            method = novoMetodo;
        }
        const emPausaPomodoro = pomodoroMode && pomodoroState === 'rest';

        for (const { dia, ms, fimMs } of segmentos) {
            if (!studyHistory[dia]) studyHistory[dia] = 0;
            if (!siteHistory[dia]) siteHistory[dia] = {};
            if (!activityHistory[dia]) activityHistory[dia] = { questoes: 0, leitura: 0, videoaula: 0 };
            if (activityHistory[dia].videoaula === undefined) activityHistory[dia].videoaula = 0;

            const registrarSite = () => {
                if (!isBrowserSite) return;
                if (!siteHistoryEnabled) return;
                if (!siteHistory[dia][currentTabHostname]) {
                    siteHistory[dia][currentTabHostname] = 0;
                }
                siteHistory[dia][currentTabHostname] += ms;
                const horaSite = new Date(fimMs - 1).getHours();
                if (!siteHourlyHistory[dia]) siteHourlyHistory[dia] = {};
                siteHourlyHistory[dia][horaSite] = (siteHourlyHistory[dia][horaSite] || 0) + ms;
            };

            const registrarAtividade = (msAtividade) => {
                // O que a pessoa escolheu no popup ("Questões" ou "Leitura") é
                // só o padrão. Se a própria aba for detectada como vídeo (pelo
                // global_overlay.js), essa detecção manda — assim "Leitura"
                // continua selecionada no popup mas o tempo cai no balde certo
                // (Vídeo-aula) sem a pessoa precisar trocar nada manualmente.
                const tipoDetectado = currentTabId !== null ? tabTipoPagina[currentTabId] : undefined;
                let chave = activeActivity === 'leitura' ? 'leitura' : 'questoes';
                if (activeActivity !== 'questoes' && tipoDetectado === 'videoaula') chave = 'videoaula';
                if (!activityHistory[dia][chave]) activityHistory[dia][chave] = 0;
                activityHistory[dia][chave] += msAtividade;
            };

            if (sessionState === 'running' && !emPausaPomodoro) {
                if (method === 'offline') {
                    studyHistory[dia] += ms;
                    registrarSite();
                    registrarAtividade(ms);
                    registrarPlano(ms, dia);
                    if (isBrowserSite && !exempt) distractionAccumulator += ms;
                    registrarHoraProdutiva(dia, ms, fimMs);
                } else {
                    if (isQuestionBankHost(currentTabHostname) || exempt) {
                        studyHistory[dia] += ms;
                        registrarAtividade(ms);
                        registrarPlano(ms, dia);
                        distractionAccumulator = 0;
                        registrarHoraProdutiva(dia, ms, fimMs);
                    } else {
                        registrarSite();
                        distractionAccumulator += ms;
                    }
                }
            } else {
                // Sempre registra uso de sites para a aba de Distrações
                registrarSite();
            }
        }

        const paraGravar = { studyHistory, siteHistory, activityHistory, siteHourlyHistory };
        if (modoMudou) { paraGravar.activeMethod = activeMethod; paraGravar.activeActivity = activeActivity; }
        if (planoTempoMudou) paraGravar.planoTempo = planoTempo;
        chrome.storage.local.set(paraGravar, () => {
            // Recalcula streak em tempo real sempre que o histórico muda
            recalcularStreak();
            verificarNivel(studyHistory);
        });
    });
}

function verificarNivel(studyHistory) {
    const totalMs = Object.values(studyHistory).reduce((s, v) => s + v, 0);
    const totalHoras = totalMs / (60 * 60 * 1000);

    let nivelIdx = 0;
    for (let i = 0; i < LEVELS.length; i++) {
        if (totalHoras >= LEVELS[i].hours) nivelIdx = i;
    }

    chrome.storage.local.get(['unlockedLevelIndex'], (result) => {
        const anterior = (result.unlockedLevelIndex !== undefined) ? result.unlockedLevelIndex : 0;
        chrome.storage.local.set({ unlockedLevelIndex: nivelIdx, totalStudyMs: totalMs });
        if (nivelIdx > anterior) {
            showNotification("Novo Nível Desbloqueado!", `Parabéns! Você alcançou o nível "${LEVELS[nivelIdx].name}" (${LEVELS[nivelIdx].hours}h de estudo).`);
        }
    });
}

function registrarHoraProdutiva(today, elapsed, momentoMs) {
    const hora = new Date((momentoMs || Date.now()) - 1).getHours();
    chrome.storage.local.get(['hourlyHistory'], (result) => {
        let hourlyHistory = result.hourlyHistory || {};
        if (!hourlyHistory[today]) hourlyHistory[today] = {};
        if (!hourlyHistory[today][hora]) hourlyHistory[today][hora] = 0;
        hourlyHistory[today][hora] += elapsed;
        chrome.storage.local.set({ hourlyHistory });
    });
}

function recalcularStreak() {
    chrome.storage.sync.get(['dailyGoalMs'], (syncResult) => {
    chrome.storage.local.get(['studyHistory', 'unlockedStreakMilestones'], (result) => {
        const study = result.studyHistory || {};
        const goalMs = syncResult.dailyGoalMs || (4 * 60 * 60 * 1000);

        let streak = 0;
        let d = new Date();
        
        // Verifica se bateu a meta hoje
        let key = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
        if (study[key] >= goalMs) {
            streak++;
        }
        
        // Volta para ontem e continua verificando os dias anteriores
        d.setDate(d.getDate() - 1);
        
        while (true) {
            key = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
            if (study[key] >= goalMs) {
                streak++;
                d.setDate(d.getDate() - 1);
            } else {
                break;
            }
        }

        chrome.storage.local.set({ streakCount: streak });

        // Conquistas de ofensiva: desbloqueia uma medalha a cada marco de dias seguidos
        const unlocked = result.unlockedStreakMilestones || [];
        const novos = STREAK_MILESTONES.filter(m => streak >= m && !unlocked.includes(m));
        if (novos.length > 0) {
            const atualizados = unlocked.concat(novos);
            chrome.storage.local.set({ unlockedStreakMilestones: atualizados });
            const maior = Math.max(...novos);
            showNotification("Conquista Desbloqueada!", `Ofensiva de ${maior} dias seguidos batendo a meta. Continue assim!`);
        }
    });
    });
}

const CB_DISTRACTION_LIMIT_MS = 5 * 60 * 1000;

function checkDistractionLimit() {
    if (isExemptHost(currentTabHostname) || isSessaoExcecaoHost(currentTabHostname)) {
        cbEsconderBarraDistracaoNaAba();
        return;
    }

    if (isQuestionBankHost(currentTabHostname)) {
        cbEsconderBarraDistracaoNaAba();
    } else if (distractionAccumulator > 0) {
        // Mostra/atualiza a barrinha vermelha no topo da aba com o tempo
        // restante antes do redirecionamento automático de volta pro
        // sistema de questões.
        const restanteMs = Math.max(0, CB_DISTRACTION_LIMIT_MS - distractionAccumulator);
        const pct = Math.max(0, Math.min(100, (restanteMs / CB_DISTRACTION_LIMIT_MS) * 100));
        if (currentTabId !== null) {
            chrome.tabs.sendMessage(currentTabId, { action: 'cbUpdateDistractionBar', pct, restanteMs }).catch(() => {});
        }
    }

    // Passou de 5 min fora do sistema de questões: AVISA, mas não tira mais
    // a pessoa do site à força.
    //
    // ANTES isso trocava a URL da aba por qconcursos.com sozinho — a
    // extensão fechava a página que a pessoa estava lendo sem ela ter pedido
    // nada. Como agora nada é bloqueado automaticamente (só o que a pessoa
    // marcou respondendo a pergunta na própria página), esse sequestro de
    // aba não cabe mais: vira uma notificação e a barrinha some.
    if (distractionAccumulator >= CB_DISTRACTION_LIMIT_MS) {
        distractionAccumulator = 0;
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (!tabs[0] || !tabs[0].url) return;
            let host = '';
            try { host = new URL(tabs[0].url).hostname; } catch (e) {}
            if (!isQuestionBankHost(host) && !isSessaoExcecaoHost(host)) {
                cbEsconderBarraDistracaoNaAba();
                showNotification("5 minutos fora do foco", "Você já passou de 5 minutos fora do sistema de questões. Se esse site atrapalha, você pode bloquear ele na perguntinha que aparece na própria página.");
            }
        });
    }
}

function cbEsconderBarraDistracaoNaAba() {
    if (currentTabId !== null) {
        chrome.tabs.sendMessage(currentTabId, { action: 'cbHideDistractionBar' }).catch(() => {});
    }
}

// Só essas ações chamam sendResponse(...) de verdade dentro de
// processMessage. Para todas as outras, o canal de mensagem precisa ser
// fechado na hora (não prometer resposta) — no Firefox, prometer uma
// resposta assíncrona que nunca chega quebra a entrega da mensagem e gera
// "Promised response from onMessage listener went out of scope" no console,
// além de deixar ações como changeConfig/changeGoal/toggleCamera etc.
// silenciosamente instáveis.
const CB_ACOES_COM_RESPOSTA = new Set(['changeState', 'permitirExcecaoHost']);

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.target === 'offscreen') return false; // mensagens exclusivas do offscreen.js

    if (!CB_ACOES_COM_RESPOSTA.has(message.action)) {
        // Fogo-e-esqueço: processa depois de garantir o estado, mas não
        // deixa o Firefox esperando por um sendResponse que nunca vai vir.
        // Passa pela mesma fila do Pomodoro (cbEnfileirarOperacaoDeEstado)
        // pra este hydrateState() nunca reler o storage.local no meio de
        // uma transição de fase (work→rest/rest→work) ainda sendo gravada
        // — ver o comentário grande ali em cima.
        cbEnfileirarOperacaoDeEstado(() => hydrateState().then(() => {
            return processMessage(message, sender, () => {});
        }));
        return false;
    }

    cbEnfileirarOperacaoDeEstado(() => hydrateState().then(() => {
        return processMessage(message, sender, sendResponse);
    }));
    return true;
});

// ===================== PLAYER DE SOM (RUÍDO BRANCO / CHUVA / LO-FI) =====================
// Usa a API "offscreen" para o áudio continuar tocando mesmo com o popup fechado.

let creatingOffscreen = null;

// Detecção robusta de Firefox. Não basta checar "!chrome.offscreen": no
// Firefox, como o manifest declara a permissão "offscreen", o namespace
// chrome.offscreen (e até chrome.runtime.getContexts) pode existir como
// stub — mas ao chamar getContexts com contextTypes: ['OFFSCREEN_DOCUMENT']
// o Firefox lança "Invalid enumeration value OFFSCREEN_DOCUMENT", pois ele
// não reconhece esse valor no schema (a API Offscreen Documents em si não é
// implementada). Isso derrubava syncSoundPlayback() sempre que o estado da
// sessão mudava (ex: clicar em "Iniciar Estudo"), e por causa da promise
// rejeitada não tratada em algum ponto da cadeia, o cronômetro nunca
// chegava a iniciar. chrome.runtime.getBrowserInfo só existe no Firefox,
// então é um jeito confiável de detectar o navegador sem depender do
// namespace offscreen (que engana).
const CB_IS_FIREFOX = typeof chrome !== 'undefined'
    && !!chrome.runtime
    && typeof chrome.runtime.getBrowserInfo === 'function';

async function hasOffscreenDocument() {
    if (CB_IS_FIREFOX || !chrome.offscreen) return false;
    if (chrome.runtime.getContexts) {
        try {
            const contexts = await chrome.runtime.getContexts({
                contextTypes: ['OFFSCREEN_DOCUMENT'],
                documentUrls: [chrome.runtime.getURL('overlay-global/offscreen.html')]
            });
            return contexts.length > 0;
        } catch (e) {
            return false;
        }
    }
    return false;
}

async function ensureOffscreenDocument() {
    if (CB_IS_FIREFOX || !chrome.offscreen) return; // som ambiente fica indisponível no Firefox
    if (await hasOffscreenDocument()) return;
    if (creatingOffscreen) {
        await creatingOffscreen;
        return;
    }
    creatingOffscreen = chrome.offscreen.createDocument({
        url: 'overlay-global/offscreen.html',
        reasons: ['AUDIO_PLAYBACK'],
        justification: 'Tocar som ambiente (ruído branco, chuva ou rádio lo-fi) durante a sessão de estudo.'
    });
    try {
        await creatingOffscreen;
    } catch (e) {
        // Já pode existir por causa de uma corrida entre chamadas
    }
    creatingOffscreen = null;
}

async function closeOffscreenDocument() {
    if (CB_IS_FIREFOX || !chrome.offscreen) return;
    if (await hasOffscreenDocument()) {
        try { await chrome.offscreen.closeDocument(); } catch (e) {}
    }
}

// Toca o som assim que o usuário liga o toggle (feedback imediato — não faz
// sentido a pessoa ativar "Som ambiente" e nada acontecer só porque ela
// ainda não apertou Play). Só pausa em pausas de verdade: quando o usuário
// se afasta (câmera detectou ausência) ou durante o descanso do Pomodoro.
async function enviarComRetry(msg, tentativas = 5, atrasoMs = 120) {
    for (let i = 0; i < tentativas; i++) {
        try {
            await chrome.runtime.sendMessage(msg);
            return true;
        } catch (e) {
            // O documento offscreen pode ainda não ter terminado de registrar
            // o listener no instante em que createDocument() resolveu — isso
            // é uma condição de corrida conhecida da API offscreen. Tentamos
            // de novo algumas vezes com um pequeno atraso antes de desistir.
            await new Promise(r => setTimeout(r, atrasoMs));
        }
    }
    return false;
}

async function syncSoundPlayback() {
    // Blindagem extra: som ambiente é um recurso secundário e nunca deve
    // conseguir impedir o resto do fluxo (ex: iniciar o cronômetro) caso
    // algo dê errado aqui — por isso todo o corpo fica dentro de um
    // try/catch.
    try {
        if (CB_IS_FIREFOX) return; // som ambiente via offscreen document não é suportado no Firefox
        const emPausaReal = sessionState === 'paused_away' || (pomodoroMode && pomodoroState === 'rest');
        const deveTocar = soundEnabled && soundType !== 'none' && !emPausaReal;
        if (deveTocar) {
            const jaExistia = await hasOffscreenDocument();
            await ensureOffscreenDocument();
            // Se acabamos de criar o documento agora, espera o registro do
            // listener antes de mandar a primeira mensagem de play.
            if (!jaExistia) {
                enviarComRetry({ target: 'offscreen', action: 'offscreen_play', soundType, volume: soundVolume });
            } else {
                chrome.runtime.sendMessage({ target: 'offscreen', action: 'offscreen_play', soundType, volume: soundVolume }).catch(() => {});
            }
        } else {
            const existe = await hasOffscreenDocument();
            if (existe) {
                chrome.runtime.sendMessage({ target: 'offscreen', action: 'offscreen_stop' }).catch(() => {});
                await closeOffscreenDocument();
            }
        }
    } catch (e) {
        // Nunca deixa um erro de som ambiente propagar e travar o restante
        // do fluxo de estado da sessão/cronômetro.
    }
}

// Toca o alerta sonoro do Pomodoro pelo offscreen document — ao contrário de
// enviarMensagemParaAbas() (que só alcança a aba ativa da janela atual, e só
// se o overlay estiver injetado nela), isso funciona sempre, independente de
// qual aba/janela está em foco. 'kind' é repassado direto pro offscreen.js:
// 'foco-inicio' | 'foco-fim' | 'descanso-fim' | 'inicio' | 'fim'.
async function tocarAlertaPomodoroOffscreen(kind) {
    try {
        if (CB_IS_FIREFOX || !chrome.offscreen) return; // offscreen indisponível no Firefox
        const jaExistia = await hasOffscreenDocument();
        await ensureOffscreenDocument();
        if (!jaExistia) {
            await enviarComRetry({ target: 'offscreen', action: 'offscreen_playAlert', kind });
        } else {
            chrome.runtime.sendMessage({ target: 'offscreen', action: 'offscreen_playAlert', kind }).catch(() => {});
        }
    } catch (e) {
        // Alerta sonoro nunca pode travar o resto do fluxo do Pomodoro.
    }
}

// Devolve uma Promise que só resolve depois que a(s) gravação(ões) no
// storage terminarem de verdade — quem chama (processMessage) precisa
// esperar por ela antes de deixar a fila (cbEnfileirarOperacaoDeEstado)
// seguir pro próximo hydrateState(), senão um tick concorrente pode reler o
// storage.local ainda com o valor antigo (mesma classe de corrida descrita
// no comentário grande sobre cbEnfileirarOperacaoDeEstado lá em cima).
function pausarPomodoroSeNecessario() {
    return new Promise((resolve) => {
        if (pomodoroMode && pomodoroState === 'work') {
            chrome.storage.local.get(['pomodoroPausedAt'], (result) => {
                if (!result.pomodoroPausedAt) {
                    // Congela o tempo restante exato no momento da pausa
                    chrome.storage.local.get(['pomodoroEndAt'], (r2) => {
                        const timeLeft = Math.max(0, Math.round((r2.pomodoroEndAt - Date.now()) / 1000));
                        chrome.storage.local.set({
                            pomodoroPausedAt: Date.now(),
                            pomodoroTimeLeft: timeLeft
                        }, resolve);
                        // Prazo congelado enquanto pausado — o alarme de precisão
                        // apontando pro prazo antigo não faz mais sentido (seria
                        // um no-op inofensivo de qualquer forma, mas mais limpo
                        // não deixar um alarme fantasma agendado).
                        cbAgendarAlarmeFimPomodoro(null);
                    });
                } else {
                    resolve();
                }
            });
        } else {
            resolve();
        }
    });
}

function retomarPomodoroSeNecessario(callback) {
    if (pomodoroMode && pomodoroState === 'work') {
        chrome.storage.local.get(['pomodoroPausedAt', 'pomodoroEndAt', 'pomodoroTimeLeft'], (result) => {
            if (result.pomodoroPausedAt) {
                const pausedDuration = Date.now() - result.pomodoroPausedAt;
                // Adiciona o tempo pausado de volta ao pomodoro
                const baseEndAt = result.pomodoroEndAt || (Date.now() + (result.pomodoroTimeLeft || pomodoroWorkMinutes*60) * 1000);
                const novoEndAt = baseEndAt + pausedDuration;
                const novoTimeLeft = Math.max(0, Math.round((novoEndAt - Date.now()) / 1000));
                chrome.storage.local.set({ 
                    pomodoroEndAt: novoEndAt, 
                    pomodoroTimeLeft: novoTimeLeft,
                    pomodoroPausedAt: null 
                }, () => {
                    if (callback) callback();
                });
                return;
            }
            if (callback) callback();
        });
    } else {
        if (callback) callback();
    }
}

async function processMessage(message, sender, sendResponse) {
    // SINAL DE VIDA: Impede que o Chrome suspenda a extensão no modo Offline
    if (message.action === 'keep_alive') {
        return; 
    }

    if (message.action === 'changeState') {
        const previousState = sessionState;
        const newState = message.state;

        // MODO HARDCORE: não deixa pausar manualmente enquanto a sessão está
        // rodando (ou, no ciclo Pomodoro, enquanto ainda está na fase de foco).
        if (newState !== 'running' && previousState === 'running' && hardcoreMode) {
            const podeInterromper = pomodoroMode && pomodoroState === 'rest';
            if (!podeInterromper) {
                if (sendResponse) sendResponse({ blocked: true, reason: 'hardcore' });
                return;
            }
        }

        if (newState === 'running') {
            if (previousState === 'stopped' && pomodoroMode) {
                pomodoroState = 'work';
                // Sessão nova do zero: se for o Inteligente, reinicia a
                // progressão (volta pro 1º ciclo, 25 min) em vez de manter
                // de onde tinha parado numa sessão anterior.
                if (pomodoroInteligente) pomodoroInteligenteCiclos = 0;
                pomodoroTimeLeft = (pomodoroInteligente ? cbFasePomodoroInteligente(pomodoroInteligenteCiclos).work : pomodoroWorkMinutes) * 60;
                const pomodoroEndAt = Date.now() + pomodoroTimeLeft * 1000;
                sessionState = newState;
                // Espera a gravação terminar de verdade antes de devolver —
                // senão um tick concorrente (heartbeat/alarme de precisão)
                // pode rodar hydrateState() nesse meio-tempo, reler o
                // storage.local ainda com o valor antigo e pisar de volta
                // nessas variáveis em memória (mesma corrida do comentário
                // grande sobre cbEnfileirarOperacaoDeEstado lá em cima).
                await new Promise((resolve) => chrome.storage.local.set({ sessionState, pomodoroState, pomodoroTimeLeft, pomodoroEndAt, pomodoroPausedAt: null, pomodoroInteligenteCiclos }, resolve));
                cbAgendarAlarmeFimPomodoro(pomodoroEndAt);
                finalizarContagemPausa();
                updateTimeTracking();
                initializeCurrentTab();
                syncSoundPlayback();
                if (sendResponse) sendResponse({ ok: true });
                return;
            }

            await new Promise((resolve) => retomarPomodoroSeNecessario(resolve));
            sessionState = newState;
            await new Promise((resolve) => chrome.storage.local.set({ sessionState }, resolve));
            if (pomodoroMode && pomodoroState === 'work') {
                chrome.storage.local.get(['pomodoroEndAt'], (r) => cbAgendarAlarmeFimPomodoro(r.pomodoroEndAt));
            }
            finalizarContagemPausa();
            updateTimeTracking();
            initializeCurrentTab();
            syncSoundPlayback();
        }
        else {
            await pausarPomodoroSeNecessario();
            if (previousState === 'running') iniciarContagemPausa();
            updateTimeTracking();
            sessionState = newState;
            if (newState === 'stopped') sessaoExcecoesHosts = [];
            await new Promise((resolve) => chrome.storage.local.set({ sessionState }, resolve));
            setCurrentTabStartTime(Date.now());
            syncSoundPlayback();
        }
        if (sendResponse) sendResponse({ ok: true });
    }
    else if (message.action === 'reportarTipoPagina') {
        const tabId = sender && sender.tab ? sender.tab.id : null;
        if (tabId !== null) {
            if (message.tipo) tabTipoPagina[tabId] = message.tipo;
            else delete tabTipoPagina[tabId];
        }
    }
    else if (message.action === 'permitirExcecaoHost') {
        const hostname = (message.hostname || '').replace(/^www\./, '');
        if (hostname && !sessaoExcecoesHosts.includes(hostname)) {
            sessaoExcecoesHosts.push(hostname);
        }
        distractionAccumulator = 0;
        if (sendResponse) sendResponse({ ok: true });
    }
    else if (message.action === 'changeConfig') {
        // Fecha o pedaço de tempo rastreado com o método/atividade ANTIGOS
        // antes de trocar — senão esse pedaço acabava sendo perdido (nunca
        // creditado) ou, pior, só seria somado bem depois, na próxima
        // atualização, e aí já com a atividade nova selecionada.
        updateTimeTracking();
        activeMethod = message.method;
        activeActivity = message.activity;
        chrome.storage.local.set({ activeMethod, activeActivity });
        setCurrentTabStartTime(Date.now());
    }
    else if (message.action === 'changeGoal') {
        const horas = parseFloat(message.goalHours);
        if (!isNaN(horas) && horas > 0) {
            const dailyGoalMs = Math.round(horas * 60 * 60 * 1000);
            chrome.storage.sync.set({ dailyGoalMs }, () => {
                recalcularStreak();
            });
        }
    }
    else if (message.action === 'changeTheme') {
        // Grava nos dois: sync pra acompanhar entre PCs quando funcionar, e
        // local como cópia confiável (sync pode não persistir em todo navegador).
        chrome.storage.sync.set({ themePref: message.theme });
        chrome.storage.local.set({ themePref: message.theme });
    }
    else if (message.action === 'toggleCamera') {
        cameraEnabled = message.enabled;
        chrome.storage.sync.set({ cameraEnabled });
    }
    else if (message.action === 'toggleHardcore') {
        hardcoreMode = message.enabled;
        chrome.storage.sync.set({ hardcoreMode });
    }
    else if (message.action === 'updateSound') {
        soundEnabled = message.enabled;
        if (message.soundType) soundType = message.soundType;
        if (typeof message.volume === 'number') soundVolume = message.volume;
        chrome.storage.sync.set({ soundEnabled, soundType, soundVolume });
        syncSoundPlayback();
    }
    else if (message.action === 'togglePomodoro') {
        // Clássico e Inteligente são mutuamente exclusivos — ligar este
        // desliga a "bandeira" do Inteligente (o motor de ciclo é o mesmo,
        // só muda de onde vêm os minutos de foco/descanso).
        pomodoroInteligente = false;
        pomodoroMode = message.enabled;
        if (pomodoroMode) {
            pomodoroState = 'work';
            pomodoroTimeLeft = pomodoroWorkMinutes * 60;
            if (sessionState === 'running') {
                // Sessão já está rodando: pode começar a contar o foco agora mesmo.
                const pomodoroEndAt = Date.now() + pomodoroTimeLeft * 1000;
                chrome.storage.local.set({ pomodoroMode, pomodoroInteligente, pomodoroState, pomodoroTimeLeft, pomodoroEndAt, pomodoroPausedAt: null });
                cbAgendarAlarmeFimPomodoro(pomodoroEndAt);
            } else {
                // Sessão ainda parada/pausada: só guarda a configuração. O
                // relógio (pomodoroEndAt) só nasce quando a pessoa realmente
                // apertar iniciar/continuar (ver 'changeState' -> 'running'
                // abaixo), pra não contar tempo de foco/descanso que ninguém
                // estava estudando.
                chrome.storage.local.set({ pomodoroMode, pomodoroInteligente, pomodoroState, pomodoroTimeLeft, pomodoroEndAt: null, pomodoroPausedAt: null });
            }
            tocarAlertaPomodoroOffscreen('inicio');
        } else {
            pomodoroState = 'off';
            chrome.storage.local.set({ pomodoroMode, pomodoroInteligente, pomodoroState, pomodoroTimeLeft, pomodoroEndAt: null, pomodoroPausedAt: null });
            cbAgendarAlarmeFimPomodoro(null);
            tocarAlertaPomodoroOffscreen('fim');
        }
    }
    else if (message.action === 'togglePomodoroInteligente') {
        // Mesma ideia do 'togglePomodoro' acima, mas com a progressão fixa
        // (25/5 x2, depois 60/15 pra sempre) em vez dos minutos
        // personalizáveis — por isso NÃO mexe em pomodoroWorkMinutes nem
        // pomodoroRestMinutes (essas continuam sendo só do modo clássico).
        pomodoroMode = message.enabled;
        pomodoroInteligente = message.enabled;
        if (pomodoroMode) {
            pomodoroInteligenteCiclos = 0;
            pomodoroState = 'work';
            pomodoroTimeLeft = cbFasePomodoroInteligente(pomodoroInteligenteCiclos).work * 60;
            if (sessionState === 'running') {
                const pomodoroEndAt = Date.now() + pomodoroTimeLeft * 1000;
                chrome.storage.local.set({ pomodoroMode, pomodoroInteligente, pomodoroInteligenteCiclos, pomodoroState, pomodoroTimeLeft, pomodoroEndAt, pomodoroPausedAt: null });
                cbAgendarAlarmeFimPomodoro(pomodoroEndAt);
            } else {
                chrome.storage.local.set({ pomodoroMode, pomodoroInteligente, pomodoroInteligenteCiclos, pomodoroState, pomodoroTimeLeft, pomodoroEndAt: null, pomodoroPausedAt: null });
            }
            tocarAlertaPomodoroOffscreen('inicio');
        } else {
            pomodoroState = 'off';
            chrome.storage.local.set({ pomodoroMode, pomodoroInteligente, pomodoroState, pomodoroTimeLeft, pomodoroEndAt: null, pomodoroPausedAt: null });
            cbAgendarAlarmeFimPomodoro(null);
            tocarAlertaPomodoroOffscreen('fim');
        }
    }
    else if (message.action === 'updatePomodoro') {
        const clamp = (v, def) => {
            const n = parseInt(v, 10);
            return (Number.isFinite(n) && n >= 1 && n <= 120) ? n : def;
        };
        pomodoroWorkMinutes = clamp(message.work, pomodoroWorkMinutes);
        pomodoroRestMinutes = clamp(message.rest, pomodoroRestMinutes);
        // Grava nos dois: sync pra acompanhar entre PCs quando funcionar, e
        // local como cópia confiável (sync pode não persistir em todo navegador
        // — mesmo motivo do themePref em 'changeTheme' logo abaixo).
        chrome.storage.sync.set({ pomodoroWorkMinutes, pomodoroRestMinutes });
        chrome.storage.local.set({ pomodoroWorkMinutes, pomodoroRestMinutes });
        
        // Se estiver rodando um foco do modo clássico, reinicia o ciclo com
        // os novos tempos. Não mexe durante um descanso em andamento (senão
        // cancela a pausa que já tinha começado) nem no Inteligente (cuja
        // progressão de minutos não é essa — é calculada à parte).
        if (pomodoroMode && !pomodoroInteligente && pomodoroState === 'work' && sessionState === 'running') {
            pomodoroState = 'work';
            pomodoroTimeLeft = pomodoroWorkMinutes * 60;
            const pomodoroEndAt = Date.now() + pomodoroTimeLeft * 1000;
            chrome.storage.local.set({ pomodoroState, pomodoroTimeLeft, pomodoroEndAt, pomodoroPausedAt: null });
            cbAgendarAlarmeFimPomodoro(pomodoroEndAt);
        } else if (pomodoroMode && !pomodoroInteligente && pomodoroState === 'work') {
            // Cronômetro PARADO ou pausado: o próximo foco já nasce com o tempo novo. Sem isto o indicador
            // "Foco Pomodoro · MM:SS" acima do cronômetro continuava mostrando o tempo antigo até a pessoa
            // dar play — parecia que o "Salvar" não tinha feito nada.
            pomodoroTimeLeft = pomodoroWorkMinutes * 60;
            chrome.storage.local.get(['pomodoroPausedAt'], (r) => {
                const patch = { pomodoroTimeLeft };
                // Pausado no meio de um foco: ao retomar, o prazo é "endAt + tempo pausado" (ver
                // retomarPomodoroSeNecessario). Recomeça o foco já pausado, com o prazo novo coerente.
                if (r.pomodoroPausedAt) {
                    const agora = Date.now();
                    patch.pomodoroEndAt = agora + pomodoroTimeLeft * 1000;
                    patch.pomodoroPausedAt = agora;
                }
                chrome.storage.local.set(patch);
            });
        }
    }
    else if (message.action === 'face_status') {
        if (pomodoroState === 'rest' || activeMethod === 'offline') return;

        if (sessionState === 'running' && !message.present) {
            await pausarPomodoroSeNecessario();
            iniciarContagemPausa();
            sessionState = 'paused_away';
            await new Promise((resolve) => chrome.storage.local.set({ sessionState }, resolve));
            syncSoundPlayback();
            showNotification("Sessão Pausada", "Você saiu da frente da tela. O cronômetro foi pausado automaticamente.");
        }
        else if (sessionState === 'paused_away' && message.present) {
            await new Promise((resolve) => retomarPomodoroSeNecessario(resolve));
            sessionState = 'running';
            await new Promise((resolve) => chrome.storage.local.set({ sessionState }, resolve));
            finalizarContagemPausa();
            initializeCurrentTab();
            syncSoundPlayback();
            showNotification("Sessão Retomada", "Rosto detectado. Bons estudos!");
        }
    }
    else if (message.action === 'qc_sync_debug') {
        // Guarda o resultado da última tentativa de sincronização (sucesso
        // ou erro) pra podermos mostrar direto no popup, sem precisar de
        // DevTools/console para diagnosticar problemas.
        chrome.storage.local.set({
            qcSyncDebug: {
                atualizadoEm: Date.now(),
                origem: message.origem || '',
                ok: !!message.ok,
                erro: message.erro || null
            }
        });
    }
    else if (message.action === 'qc_sync_debug_disciplinas') {
        // Canal de debug PRÓPRIO das disciplinas (separado do debug de
        // período acima) — assim um não sobrescreve o outro, e dá pra saber
        // exatamente por que "Desempenho por Matéria" não está aparecendo.
        chrome.storage.local.set({
            qcSyncDebugDisciplinas: {
                atualizadoEm: Date.now(),
                ok: !!message.ok,
                erro: message.erro || null
            }
        });
    }
    else if (message.action === 'sincronizar_periodo_qc') {
        // Vem direto da API oficial do QC (mesma que alimenta o widget
        // "Meu Painel" do próprio site) para um período específico
        // (1=Hoje, 7=7 dias, 30=30 dias, 999=Sempre). SOBRESCREVE (nunca
        // soma) o snapshot daquele período — sempre um espelho fiel do
        // site, sem risco de duplicar contagem em re-sincronizações.
        try {
            const period = message.period;
            const dados = message.dados || {};
            if (typeof period !== 'number') return;
            chrome.storage.local.get(['questoesPeriodStats'], (result) => {
                const questoesPeriodStats = result.questoesPeriodStats || {};
                questoesPeriodStats[period] = {
                    acertos: typeof dados.acertos === 'number' ? dados.acertos : 0,
                    erros: typeof dados.erros === 'number' ? dados.erros : 0,
                    total: typeof dados.total === 'number' ? dados.total : 0,
                    atualizadoEm: Date.now()
                };
                chrome.storage.local.set({ questoesPeriodStats });
            });

            // Além do snapshot por período (que a QC sempre sobrescreve),
            // guardamos também um retrato do desempenho de "Hoje" (period=1)
            // por data, formando um histórico diário para o gráfico de
            // linha dos últimos 30 dias. Cada dia só é gravado uma vez que
            // vira "passado" — o dia de hoje é sempre atualizado/sobrescrito
            // até virar meia-noite.
            if (period === 1) {
                const d = new Date();
                const hoje = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
                const totalHoje = typeof dados.total === 'number' ? dados.total : 0;
                if (totalHoje > 0) {
                    chrome.storage.local.get(['questoesDailyHistory'], (result) => {
                        const questoesDailyHistory = result.questoesDailyHistory || {};
                        questoesDailyHistory[hoje] = {
                            acertos: typeof dados.acertos === 'number' ? dados.acertos : 0,
                            erros: typeof dados.erros === 'number' ? dados.erros : 0,
                            total: totalHoje
                        };
                        // Mantém só os últimos ~120 dias pra não crescer sem limite.
                        const chaves = Object.keys(questoesDailyHistory).sort();
                        while (chaves.length > 120) {
                            delete questoesDailyHistory[chaves.shift()];
                        }
                        chrome.storage.local.set({ questoesDailyHistory });
                    });
                }
            }
        } catch (e) {
            console.warn('[Concurseiro Blindado] Formato inesperado no histórico do QC:', e);
        }
    }
    else if (message.action === 'sincronizar_disciplinas_qc') {
        // Desempenho por matéria/disciplina, extraído da página
        // /usuario/estatisticas/disciplinas do próprio QC. SOBRESCREVE sempre
        // a lista inteira (nunca soma) — é um espelho fiel do que a página
        // mostrava no momento da sincronização, para o período que estava
        // filtrado lá.
        try {
            const itens = Array.isArray(message.itens) ? message.itens : [];
            const itensNormalizados = itens.map(it => ({
                nome: String(it.nome || '').slice(0, 80),
                certas: typeof it.certas === 'number' ? it.certas : 0,
                erradas: typeof it.erradas === 'number' ? it.erradas : 0,
                total: typeof it.total === 'number' ? it.total : 0
            }));
            chrome.storage.local.set({
                questoesDisciplinas: {
                    itens: itensNormalizados,
                    atualizadoEm: Date.now()
                }
            });

            registrarSnapshotDisciplinas(itensNormalizados);
            atualizarStreakQuestoes(itensNormalizados);
            calcularPrioridadeDisciplinas(itensNormalizados);
            checarCronogramaVsQuestoes(itensNormalizados);
        } catch (e) {
            console.warn('[Concurseiro Blindado] Formato inesperado nas disciplinas do QC:', e);
        }
    }
    else if (message.action === 'sincronizar_assuntos_qc') {
        // Desempenho por ASSUNTO, extraído de /usuario/estatisticas/assuntos.
        // Diferente da página de disciplinas, aqui os assuntos vêm todos
        // misturados (sem indicar a matéria), então classificamos cada um
        // localmente (dicionario-materias.js, sem IA e sem custo) e já
        // devolvemos agrupado por matéria, com o mais errado primeiro dentro
        // de cada grupo — é a base do "onde focar" dentro de cada matéria.
        try {
            const itens = Array.isArray(message.itens) ? message.itens : [];
            const itensNormalizados = itens.map(it => ({
                nome: String(it.nome || '').slice(0, 80),
                certas: typeof it.certas === 'number' ? it.certas : 0,
                erradas: typeof it.erradas === 'number' ? it.erradas : 0,
                total: typeof it.total === 'number' ? it.total : 0
            }));

            // Guarda a lista bruta (sem classificação) — é o que permite
            // reclassificar instantaneamente quando o usuário corrige um
            // assunto manualmente, sem precisar de uma nova sincronização.
            chrome.storage.local.set({ questoesAssuntosRaw: itensNormalizados });

            chrome.storage.local.get(['assuntoOverrides'], (result) => {
                const overrides = result.assuntoOverrides || {};
                const agrupadoPorMateria = CBDicionarioMaterias.agruparAssuntosPorMateria(itensNormalizados, overrides);
                chrome.storage.local.set({
                    questoesAssuntos: {
                        materias: agrupadoPorMateria,
                        atualizadoEm: Date.now()
                    }
                });
                registrarSnapshotAssuntos(agrupadoPorMateria);
                calcularPrioridadeAssuntos(agrupadoPorMateria);
            });
        } catch (e) {
            console.warn('[Concurseiro Blindado] Formato inesperado nos assuntos do QC:', e);
        }
    }
    else if (message.action === 'qc_sync_debug_assuntos') {
        // Canal de debug próprio dos assuntos, no mesmo padrão do de
        // disciplinas — separado pra um erro não sobrescrever o outro.
        chrome.storage.local.set({
            qcSyncDebugAssuntos: {
                atualizadoEm: Date.now(),
                ok: !!message.ok,
                erro: message.erro || null
            }
        });
    }
    else if (message.action === 'salvar_override_assunto') {
        // Correção manual do usuário: "esse assunto é da matéria X", vinda
        // do popup. Fica salva pra sempre localmente (chrome.storage.local),
        // tem prioridade sobre qualquer dicionário, e reclassifica todo o
        // conjunto na hora, sem precisar sincronizar de novo com o QC.
        try {
            const nomeOriginal = String(message.nome || '').trim();
            const materiaEscolhida = String(message.materia || '').trim();
            if (!nomeOriginal || !materiaEscolhida) return;
            const chave = CBDicionarioMaterias.normalizar(nomeOriginal);

            chrome.storage.local.get(['assuntoOverrides', 'questoesAssuntosRaw'], (result) => {
                const assuntoOverrides = result.assuntoOverrides || {};
                assuntoOverrides[chave] = materiaEscolhida;

                const itensRaw = result.questoesAssuntosRaw || [];
                const agrupadoPorMateria = CBDicionarioMaterias.agruparAssuntosPorMateria(itensRaw, assuntoOverrides);

                chrome.storage.local.set({
                    assuntoOverrides,
                    questoesAssuntos: {
                        materias: agrupadoPorMateria,
                        atualizadoEm: Date.now()
                    }
                });
                calcularPrioridadeAssuntos(agrupadoPorMateria);
            });
        } catch (e) {
            console.warn('[Concurseiro Blindado] Erro ao salvar correção manual de assunto:', e);
        }
    }
    else if (message.action === 'recalcularTudo') {
        recalcularStreak();
        chrome.storage.local.get(['studyHistory'], (result) => {
            verificarNivel(result.studyHistory || {});
        });
    }
    else if (message.action === 'camera_error') {
        if (message.reason === 'permissao') {
            showNotification("Câmera Bloqueada!", "O site não tem permissão pra usar sua câmera. Clique no cadeado ao lado da URL do QConcursos e libere a câmera.");
        } else {
            showNotification("Câmera Indisponível", "Não consegui acessar sua câmera. Verifique se ela não está sendo usada por outro programa.");
        }
    }
}

// ============================================================================
// SISTEMA DE QUESTÕES — Snapshot diário por disciplina, score de prioridade,
// cruzamento com o cronograma e streak de consistência.
// ============================================================================

function _hojeStr() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// 1) Snapshot diário local — guarda o retrato (certas/erradas/total) de cada
// disciplina no dia de hoje. Isso é o que permite comparar "essa semana vs
// semana passada" e calcular staleness (dias sem praticar uma matéria).
function registrarSnapshotDisciplinas(itens) {
    if (!Array.isArray(itens) || itens.length === 0) return;
    const hoje = _hojeStr();
    chrome.storage.local.get(['disciplinaHistory'], (result) => {
        const disciplinaHistory = result.disciplinaHistory || {};
        disciplinaHistory[hoje] = itens.map(it => ({
            nome: it.nome, certas: it.certas, erradas: it.erradas, total: it.total
        }));
        // Mantém só os últimos ~120 dias, mesmo padrão do questoesDailyHistory.
        const chaves = Object.keys(disciplinaHistory).sort();
        while (chaves.length > 120) {
            delete disciplinaHistory[chaves.shift()];
        }
        chrome.storage.local.set({ disciplinaHistory });
    });
}

// 2) Score de prioridade por disciplina — combina % de acerto (quanto menor,
// mais peso) com staleness (dias desde a última vez que a matéria teve
// questões novas resolvidas). Não depende de saber nada sobre tópicos.
function calcularPrioridadeDisciplinas(itensAtuais) {
    if (!Array.isArray(itensAtuais) || itensAtuais.length === 0) return;
    chrome.storage.local.get(['disciplinaHistory'], (result) => {
        const disciplinaHistory = result.disciplinaHistory || {};
        const datas = Object.keys(disciplinaHistory).sort(); // ascendente
        const hoje = new Date();
        hoje.setHours(0, 0, 0, 0);

        const itensComScore = itensAtuais
            .filter(it => it.total > 0)
            .map(it => {
                const pctAcerto = it.total > 0 ? (it.certas / it.total) * 100 : 0;

                // Acha a última data (antes de hoje) em que essa disciplina teve
                // um total MAIOR do que numa leitura anterior — ou seja, em que
                // a pessoa de fato resolveu questões novas dela.
                let diasSemEstudar = 999;
                let totalAnterior = null;
                for (let i = datas.length - 1; i >= 0; i--) {
                    const snapshot = disciplinaHistory[datas[i]] || [];
                    const item = snapshot.find(s => s.nome === it.nome);
                    if (!item) continue;
                    if (totalAnterior === null) totalAnterior = item.total;
                    if (totalAnterior !== null && item.total < totalAnterior) {
                        const dataSnap = new Date(datas[i] + 'T00:00:00');
                        diasSemEstudar = Math.round((hoje - dataSnap) / 86400000);
                        break;
                    }
                }
                if (diasSemEstudar === 999 && datas.length > 0) {
                    const dataMaisAntiga = new Date(datas[0] + 'T00:00:00');
                    diasSemEstudar = Math.round((hoje - dataMaisAntiga) / 86400000);
                }

                // Score: peso maior para acerto baixo (até 60 pontos) + peso pro
                // tempo parado (até ~40 pontos, satura em 20 dias sem tocar nela).
                const pesoAcerto = Math.max(0, (100 - pctAcerto)) * 0.6;
                const pesoStaleness = Math.min(diasSemEstudar, 20) * 2;
                const score = Math.round(pesoAcerto + pesoStaleness);

                return { nome: it.nome, pctAcerto: Math.round(pctAcerto), diasSemEstudar, score };
            })
            .sort((a, b) => b.score - a.score);

        chrome.storage.local.set({
            questoesPrioridade: { itens: itensComScore, atualizadoEm: Date.now() }
        });
    });
}

// 3) Mesma ideia acima, mas por ASSUNTO em vez de matéria/disciplina —
// pega a lista já agrupada por matéria (questoesAssuntos.materias, vinda
// de agruparAssuntosPorMateria em dicionario-materias.js) e achata numa
// lista única com score, pra achar "o assunto mais urgente" independente
// de qual matéria ele pertence. Reaproveita exatamente a mesma fórmula
// (erro pesa mais, tempo parado pesa um pouco, sem IA nenhuma) e soma um
// terceiro fator pequeno pra volume: um assunto com poucas questões ainda
// resolvidas fica mais na frente também, porque a taxa de acerto dele é
// pouco confiável (ex: 1 questão errada de 1 total = 0%, mas isso não diz
// muita coisa sozinho).
function registrarSnapshotAssuntos(materias) {
    if (!Array.isArray(materias) || materias.length === 0) return;
    const hoje = _hojeStr();
    chrome.storage.local.get(['assuntoHistory'], (result) => {
        const assuntoHistory = result.assuntoHistory || {};
        const snapshot = [];
        materias.forEach((grupo) => {
            (grupo.itens || []).forEach((it) => {
                snapshot.push({ chave: `${grupo.materia}::${it.nome}`, materia: grupo.materia, nome: it.nome, certas: it.certas, erradas: it.erradas, total: it.total });
            });
        });
        assuntoHistory[hoje] = snapshot;
        // Mesma janela de retenção usada pro histórico de disciplinas.
        const chaves = Object.keys(assuntoHistory).sort();
        while (chaves.length > 120) {
            delete assuntoHistory[chaves.shift()];
        }
        chrome.storage.local.set({ assuntoHistory });
    });
}

function calcularPrioridadeAssuntos(materias) {
    if (!Array.isArray(materias) || materias.length === 0) return;
    chrome.storage.local.get(['assuntoHistory'], (result) => {
        const assuntoHistory = result.assuntoHistory || {};
        const datas = Object.keys(assuntoHistory).sort(); // ascendente
        const hoje = new Date();
        hoje.setHours(0, 0, 0, 0);

        const todosItens = [];
        materias.forEach((grupo) => {
            (grupo.itens || []).forEach((it) => {
                todosItens.push({ materia: grupo.materia, nome: it.nome, certas: it.certas, erradas: it.erradas, total: it.total });
            });
        });

        const itensComScore = todosItens
            .filter(it => it.total > 0)
            .map(it => {
                const chave = `${it.materia}::${it.nome}`;
                const pctAcerto = it.total > 0 ? (it.certas / it.total) * 100 : 0;

                // Mesma lógica de staleness usada nas disciplinas, só que
                // procurando pela chave "materia::assunto" no histórico.
                let diasSemEstudar = 999;
                let totalAnterior = null;
                for (let i = datas.length - 1; i >= 0; i--) {
                    const item = (assuntoHistory[datas[i]] || []).find(s => s.chave === chave);
                    if (!item) continue;
                    if (totalAnterior === null) totalAnterior = item.total;
                    if (totalAnterior !== null && item.total < totalAnterior) {
                        const dataSnap = new Date(datas[i] + 'T00:00:00');
                        diasSemEstudar = Math.round((hoje - dataSnap) / 86400000);
                        break;
                    }
                }
                if (diasSemEstudar === 999 && datas.length > 0) {
                    const dataMaisAntiga = new Date(datas[0] + 'T00:00:00');
                    diasSemEstudar = Math.round((hoje - dataMaisAntiga) / 86400000);
                }

                const pesoAcerto = Math.max(0, (100 - pctAcerto)) * 0.6;
                const pesoStaleness = Math.min(diasSemEstudar, 20) * 2;
                // Volume baixo (poucas questões resolvidas nesse assunto
                // específico) soma um pouco de urgência — satura em 5
                // questões, pra não ficar puxando pra sempre um assunto
                // que a pessoa já tem bastante prática.
                const pesoVolume = it.total < 5 ? (5 - it.total) * 3 : 0;
                const score = Math.round(pesoAcerto + pesoStaleness + pesoVolume);

                return { materia: it.materia, nome: it.nome, pctAcerto: Math.round(pctAcerto), total: it.total, diasSemEstudar, score };
            })
            .sort((a, b) => b.score - a.score);

        chrome.storage.local.set({
            assuntosPrioridade: { itens: itensComScore, atualizadoEm: Date.now() }
        });
    });
}

// 3) Cruza o cronograma de leitura do dia com as disciplinas em que a pessoa
// de fato resolveu questões novas hoje — fecha o ciclo planejamento→execução.
function checarCronogramaVsQuestoes(itensAtuais) {
    chrome.storage.local.get(['cronogramaConfig', 'disciplinaHistory'], (result) => {
        const config = result.cronogramaConfig;
        if (!config || !Array.isArray(config.dias) || config.dias.length === 0) return;

        const hoje = new Date();
        hoje.setHours(0, 0, 0, 0);
        const inicio = new Date(config.startDate + 'T00:00:00');
        let diaIndex = Math.floor((hoje - inicio) / 86400000);
        diaIndex = Math.max(0, Math.min(config.dias.length - 1, diaIndex));
        const materiasHoje = (config.dias[diaIndex] || []).map(it => it.materia).filter(Boolean);
        if (materiasHoje.length === 0) return;

        const disciplinaHistory = result.disciplinaHistory || {};
        const chaveHoje = _hojeStr();
        const datasAnteriores = Object.keys(disciplinaHistory).filter(d => d < chaveHoje).sort();
        const snapshotOntem = datasAnteriores.length > 0
            ? disciplinaHistory[datasAnteriores[datasAnteriores.length - 1]] : [];

        const praticadasHoje = itensAtuais
            .filter(it => {
                const anterior = snapshotOntem.find(s => s.nome === it.nome);
                const totalAnterior = anterior ? anterior.total : 0;
                return it.total > totalAnterior;
            })
            .map(it => it.nome);

        // Comparação simples e tolerante (contains), já que o nome exato da
        // matéria no cronograma pode não bater 100% com o nome do QConcursos.
        const faltando = materiasHoje.filter(materiaPlano => {
            const alvo = materiaPlano.toLowerCase();
            return !praticadasHoje.some(nomeQC => {
                const nq = nomeQC.toLowerCase();
                return nq.includes(alvo) || alvo.includes(nq);
            });
        });

        chrome.storage.local.set({
            cronogramaCrossCheck: {
                data: chaveHoje,
                planoHoje: materiasHoje,
                praticadasHoje,
                faltando,
                atualizadoEm: Date.now()
            }
        });
    });
}

// 4) Streak de consistência em questões — dias seguidos em que a pessoa
// resolveu ao menos 1 questão nova (comparando com o snapshot do dia
// anterior), independente do volume.
function atualizarStreakQuestoes(itensAtuais) {
    chrome.storage.local.get(['disciplinaHistory', 'questoesStreak'], (result) => {
        const disciplinaHistory = result.disciplinaHistory || {};
        const chaveHoje = _hojeStr();
        const datasAnteriores = Object.keys(disciplinaHistory).filter(d => d < chaveHoje).sort();
        const snapshotOntem = datasAnteriores.length > 0
            ? disciplinaHistory[datasAnteriores[datasAnteriores.length - 1]] : [];
        const totalOntem = snapshotOntem.reduce((acc, s) => acc + (s.total || 0), 0);
        const totalHoje = itensAtuais.reduce((acc, it) => acc + (it.total || 0), 0);
        const resolveuAlgoHoje = totalHoje > totalOntem;

        const streakAnterior = result.questoesStreak || { dias: 0, ultimaData: null };
        let novoStreak = streakAnterior;

        if (resolveuAlgoHoje) {
            if (streakAnterior.ultimaData === chaveHoje) {
                // já contamos hoje, nada a fazer
                novoStreak = streakAnterior;
            } else {
                const ontem = new Date();
                ontem.setDate(ontem.getDate() - 1);
                const chaveOntem = `${ontem.getFullYear()}-${String(ontem.getMonth() + 1).padStart(2, '0')}-${String(ontem.getDate()).padStart(2, '0')}`;
                const continuou = streakAnterior.ultimaData === chaveOntem;
                novoStreak = {
                    dias: continuou ? streakAnterior.dias + 1 : 1,
                    ultimaData: chaveHoje
                };
            }
            chrome.storage.local.set({ questoesStreak: novoStreak });
        }
    });
}

// Retorna uma Promise que só resolve depois que o novo estado (se houve
// transição) já foi gravado no storage.local — quem chama (a fila em
// cbEnfileirarOperacaoDeEstado) espera essa Promise antes de deixar a
// próxima operação (ex: um hydrateState() de outra mensagem) rodar, pra
// nunca ler o storage no meio de uma transição ainda incompleta.
function processPomodoroTick() {
    return new Promise((resolve) => {
    chrome.storage.local.get(['pomodoroEndAt'], (result) => {
        let pomodoroEndAt = result.pomodoroEndAt;
        if (!pomodoroEndAt) {
            pomodoroEndAt = Date.now() + pomodoroTimeLeft * 1000;
        }
        pomodoroTimeLeft = Math.max(0, Math.round((pomodoroEndAt - Date.now()) / 1000));

        // CORREÇÃO DE BUG: antes, cada efeito colateral da transição (tocar
        // som, mostrar notificação, reinicializar a aba atual etc.) rodava
        // "no meio do caminho", e só DEPOIS de todos eles é que o novo
        // pomodoroState/pomodoroTimeLeft/pomodoroEndAt era gravado no
        // storage, no final da função. Se qualquer uma dessas chamadas
        // lançasse uma exceção (ex: chrome.tabs indisponível num instante
        // ruim, offscreen document num estado inesperado etc.), a gravação
        // final NUNCA rodava — o pomodoroState ficava travado na fase
        // antiga (ex: "rest") com um pomodoroEndAt já vencido no passado.
        // No próximo tick, o código detectava de novo "tempo esgotado",
        // tentava fazer a mesma transição, falhava pelo mesmo motivo, e
        // nunca saía desse ciclo sozinho — só um clique manual em
        // "Estudar" (que passa por um caminho de código diferente, em
        // 'changeState') conseguia destravar. Isso bate com o relato de
        // "o cronômetro para depois do Pomodoro e preciso clicar em
        // Estudar de novo".
        //
        // A correção: cada efeito colateral roda isolado dentro do seu
        // próprio try/catch (uma falha em UM deles não impede os outros
        // nem impede a gravação final), e o storage.set com o novo estado
        // vira UMA ÚNICA chamada, sempre executada por último,
        // incondicionalmente.
        let novoSessionState = null;

        if (pomodoroTimeLeft <= 0) {
            if (pomodoroState === 'work') {
                pomodoroState = 'rest';
                // No Inteligente, a pausa usa o número da MESMA fase que
                // acabou de rodar no foco (25→5 ou 60→15) — não recalcula
                // ainda, isso só acontece quando a pausa termina (abaixo).
                const restMin = pomodoroInteligente ? cbFasePomodoroInteligente(pomodoroInteligenteCiclos).rest : pomodoroRestMinutes;
                pomodoroTimeLeft = restMin * 60;
                pomodoroEndAt = Date.now() + pomodoroTimeLeft * 1000;
                novoSessionState = 'paused_away';

                try { iniciarContagemPausa(); } catch (e) { console.warn('[Pomodoro] iniciarContagemPausa falhou:', e); }
                try { syncSoundPlayback(); } catch (e) { console.warn('[Pomodoro] syncSoundPlayback falhou:', e); }
                try { showNotification("Intervalo Pomodoro!", `Hora de descansar! Você tem ${restMin} minutos.`); } catch (e) { console.warn('[Pomodoro] showNotification falhou:', e); }
                try { enviarMensagemParaAbas({ action: "play_pomodoro_alert" }); } catch (e) { console.warn('[Pomodoro] enviarMensagemParaAbas falhou:', e); }
                try { tocarAlertaPomodoroOffscreen('foco-fim'); } catch (e) { console.warn('[Pomodoro] tocarAlertaPomodoroOffscreen falhou:', e); }
            } else {
                // A pausa que acabou de terminar fecha um ciclo completo
                // (foco+pausa) do Inteligente — só agora recalcula a fase
                // pro PRÓXIMO foco (é o que faz virar 60/15 a partir do 3º).
                if (pomodoroInteligente) pomodoroInteligenteCiclos += 1;
                pomodoroState = 'work';
                const workMin = pomodoroInteligente ? cbFasePomodoroInteligente(pomodoroInteligenteCiclos).work : pomodoroWorkMinutes;
                pomodoroTimeLeft = workMin * 60;
                pomodoroEndAt = Date.now() + pomodoroTimeLeft * 1000;
                novoSessionState = 'running';

                try { finalizarContagemPausa(); } catch (e) { console.warn('[Pomodoro] finalizarContagemPausa falhou:', e); }
                try { initializeCurrentTab(); } catch (e) { console.warn('[Pomodoro] initializeCurrentTab falhou:', e); }
                try { syncSoundPlayback(); } catch (e) { console.warn('[Pomodoro] syncSoundPlayback falhou:', e); }
                try { showNotification("Fim do Descanso!", "Volte para os estudos focado!"); } catch (e) { console.warn('[Pomodoro] showNotification falhou:', e); }
                try { enviarMensagemParaAbas({ action: "play_pomodoro_alert" }); } catch (e) { console.warn('[Pomodoro] enviarMensagemParaAbas falhou:', e); }
                try { tocarAlertaPomodoroOffscreen('descanso-fim'); } catch (e) { console.warn('[Pomodoro] tocarAlertaPomodoroOffscreen falhou:', e); }
            }
            if (novoSessionState) sessionState = novoSessionState;
        }

        // Gravação única e incondicional — roda sempre, não importa o que
        // tenha acontecido (ou falhado) acima.
        const paraGravar = { pomodoroState, pomodoroTimeLeft, pomodoroEndAt };
        if (novoSessionState) paraGravar.sessionState = novoSessionState;
        if (pomodoroInteligente) paraGravar.pomodoroInteligenteCiclos = pomodoroInteligenteCiclos;
        chrome.storage.local.set(paraGravar, () => {
            // Reagenda o alarme de precisão pro novo prazo (seja ele o fim
            // do descanso ou o fim do próximo foco) — ver
            // cbAgendarAlarmeFimPomodoro. Só depois de confirmado no
            // storage é que resolvemos, liberando a fila de estado.
            if (pomodoroMode) cbAgendarAlarmeFimPomodoro(pomodoroEndAt);
            resolve();
        });
    });
    });
}

function enviarMensagemParaAbas(msg) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
            chrome.tabs.sendMessage(tabs[0].id, msg).catch(() => {});
        }
    });
}

function showNotification(title, message) {
    chrome.notifications.create({
        type: 'basic',
        iconUrl: 'models/icon.png',
        title: title,
        message: message,
        priority: 2
    });
}

function resetStateOnNewDay() {
    const today = getTodayKey();
    chrome.storage.local.get(['lastCheckDate'], (result) => {
        const lastCheckDate = result.lastCheckDate;

        chrome.storage.sync.get(['pomodoroWorkMinutes'], (syncResult) => {
        const workMins = syncResult.pomodoroWorkMinutes || 25;

        if (lastCheckDate && lastCheckDate !== today) {
            // Mudou o dia: recalcula streak e reseta estado
            recalcularStreak();

            if (pomodoroInteligente) pomodoroInteligenteCiclos = 0;
            // Atualiza também as variáveis em memória, não só o storage —
            // senão, se o service worker continuar vivo depois da virada do
            // dia (sem reiniciar), o motor de estado continua rodando com o
            // valor antigo (ex: ainda 'running'), e só o storage (lido pelo
            // popup/overlay) mostraria 'stopped' — uma dessincronização
            // entre o que a extensão faz de verdade e o que a UI exibe.
            sessionState = 'stopped';
            pomodoroState = 'work';
            pomodoroTimeLeft = (pomodoroInteligente ? cbFasePomodoroInteligente(0).work : workMins) * 60;
            cbAgendarAlarmeFimPomodoro(null);
            chrome.storage.local.set({
                lastCheckDate: today,
                sessionState,
                pomodoroState,
                pomodoroTimeLeft,
                pomodoroEndAt: null,
                pomodoroPausedAt: null,
                pauseStartedAt: null,
                pomodoroInteligenteCiclos
            });
        } else if (!lastCheckDate) {
            chrome.storage.local.set({ lastCheckDate: today });
        }
        });
    });
}

// ===================== MAPA MENTAL (Mermaid.js) — renderização =====================
// content scripts rodam em "isolated world" e não têm acesso a chrome.scripting,
// então quem carrega o mermaid.min.js e chama mermaid.render() é o background,
// injetando no "MAIN world" da aba (mesmo contexto JS da própria página). O
// script fica cacheado em window.mermaid entre chamadas — só carrega 1x por aba.
function cbEnsureMermaidLoadedNoMain(mermaidUrl) {
    if (window.mermaid) return Promise.resolve(true);
    if (window.__cbMermaidLoading) return window.__cbMermaidLoading;
    window.__cbMermaidLoading = new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = mermaidUrl;
        script.onload = () => resolve(true);
        script.onerror = () => reject(new Error('Falha ao carregar mermaid.min.js'));
        document.head.appendChild(script);
    });
    return window.__cbMermaidLoading;
}

async function cbRenderMermaidNoMain(definicao, elementId) {
    if (!window.mermaid) throw new Error('mermaid não carregado');
    window.mermaid.initialize({ startOnLoad: false, securityLevel: 'strict', theme: 'dark' });
    const { svg } = await window.mermaid.render(elementId, definicao);
    return svg;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action !== 'cbMermaidRender') return false;
    (async () => {
        try {
            const tabId = sender.tab && sender.tab.id;
            if (!tabId) throw new Error('Sem tabId do remetente');
            const mermaidUrl = chrome.runtime.getURL('planalto/lib/mermaid.min.js');

            await chrome.scripting.executeScript({
                target: { tabId },
                world: 'MAIN',
                func: cbEnsureMermaidLoadedNoMain,
                args: [mermaidUrl]
            });

            const [{ result }] = await chrome.scripting.executeScript({
                target: { tabId },
                world: 'MAIN',
                func: cbRenderMermaidNoMain,
                args: [message.definicao, message.elementId || ('cb-mmd-' + Date.now())]
            });

            sendResponse({ ok: true, svg: result });
        } catch (e) {
            sendResponse({ ok: false, erro: String((e && e.message) || e) });
        }
    })();
    return true; // resposta assíncrona
});