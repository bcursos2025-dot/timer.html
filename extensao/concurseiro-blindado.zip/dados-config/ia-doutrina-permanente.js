// ===================== DOUTRINA PERMANENTE (e-books importados manualmente) =====================
//
// Igual em espírito ao ia-jurisprudencia-permanente.js: material trazido pela
// própria pessoa (e-books de curso preparatório — CP Iuris / Iuris) guardado
// LOCALMENTE dentro da extensão, em dados-config/materiais-doutrina/, e usado
// como fonte de consulta pra IA não "chutar" conceitos de doutrina. Zero custo
// de cota, zero rede — os arquivos já vêm empacotados na extensão.
//
// AVISO DE DIREITO AUTORAL: esses e-books são material comercial com ISBN
// (curso pago), não texto de domínio público como a lei ou o informativo do
// STJ. Isso aqui é só um índice de busca local, pra uso pessoal de quem já
// tem o material — NÃO redistribua a pasta materiais-doutrina/ se um dia
// compartilhar essa extensão com outras pessoas.
//
// Os .txt são fruto de conversão de PDF (via pdf24), então vêm com lixo de
// paginação (números soltos, timbre repetido tipo "91554.11/03/2026", linhas
// em branco demais) — cbLimparTextoLivro tira isso antes de indexar.
//
// Carregamento é PREGUIÇOSO (só busca o arquivo .txt quando a pergunta bate
// com o ramo do livro) e o texto fica em memória (cache de módulo), não em
// chrome.storage — evita estourar a cota de armazenamento da extensão com
// ~9 MB de texto.

const CB_DOUTRINA_LIVROS = [
  {
    chave: 'civil',
    arquivo: 'dados-config/materiais-doutrina/direito_civil.txt',
    nome: 'Direito Civil — E-book CP Iuris 2026',
    ramo: 'civil',
    apelidos: ['direito civil', 'código civil', 'codigo civil', 'lindb', 'obrigações', 'obrigacoes', 'contratos', 'responsabilidade civil', 'direitos reais', 'família', 'familia', 'sucessões', 'sucessoes', 'prescrição', 'prescricao', 'decadência', 'decadencia'],
  },
  {
    chave: 'constitucional',
    arquivo: 'dados-config/materiais-doutrina/direito_constitucional.txt',
    nome: 'Direito Constitucional — Vol. 01, Iuris 2025',
    ramo: 'constitucional',
    apelidos: ['direito constitucional', 'constituição federal', 'constituicao federal', 'cf/88', 'cf 88', 'controle de constitucionalidade', 'direitos fundamentais', 'organização do estado', 'organizacao do estado'],
  },
  {
    chave: 'processual_civil',
    arquivo: 'dados-config/materiais-doutrina/direito_processual_civil.txt',
    nome: 'Direito Processual Civil — Vol. 04, Iuris 2025',
    ramo: 'processo_civil',
    apelidos: ['processo civil', 'cpc', 'processual civil', 'recursos cíveis', 'recursos civeis', 'execução civil', 'execucao civil', 'tutela provisória', 'tutela provisoria'],
  },
  {
    chave: 'processo_coletivo',
    arquivo: 'dados-config/materiais-doutrina/processo_coletivo.txt',
    nome: 'Processo Coletivo e Litígio Estrutural — Iuris 2025',
    ramo: 'difusos_coletivos',
    apelidos: ['processo coletivo', 'ação civil pública', 'acao civil publica', 'litígio estrutural', 'litigio estrutural', 'tutela coletiva', 'ação popular', 'acao popular'],
  },
  {
    chave: 'administrativo',
    arquivo: 'dados-config/materiais-doutrina/direito_administrativo.txt',
    nome: 'Direito Administrativo — E-book 2026',
    ramo: 'administrativo',
    apelidos: ['direito administrativo', 'ato administrativo', 'licitação', 'licitacao', 'servidor público', 'servidor publico', 'improbidade', 'poder de polícia', 'poder de policia', 'contrato administrativo'],
  },
  {
    chave: 'tributario',
    arquivo: 'dados-config/materiais-doutrina/direito_tributario.txt',
    nome: 'Direito Tributário — E-book 2026',
    ramo: 'tributario',
    apelidos: ['direito tributário', 'direito tributario', 'ctn', 'código tributário', 'codigo tributario', 'tributo', 'imposto', 'obrigação tributária', 'obrigacao tributaria', 'crédito tributário', 'credito tributario'],
  },
  {
    chave: 'tributario_mazza',
    arquivo: 'dados-config/materiais-doutrina/direito_tributario_mazza.txt',
    nome: 'Direito Tributário — Alexandre Mazza, 12ª ed. 2026',
    ramo: 'tributario',
    apelidos: ['direito tributário', 'direito tributario', 'ctn', 'código tributário', 'codigo tributario', 'tributo', 'imposto', 'obrigação tributária', 'obrigacao tributaria', 'crédito tributário', 'credito tributario'],
  },
];

// cache de módulo: chave -> texto já limpo e dividido em parágrafos
const cbCacheDoutrina = {};

function cbLimparTextoLivro(texto) {
  return texto
    .split(/\r?\n/)
    .filter((l) => {
      const t = l.trim();
      if (!t) return false;
      if (/^\d+$/.test(t)) return false; // número de página solto
      if (/^\d+\.\d{2}\/\d{2}\/\d{4}$/.test(t)) return false; // timbre "91554.11/03/2026"
      if (/\.{2,}\s*\d+\s*$/.test(t)) return false; // linha de sumário ("Eticidade .......... 30")
      return true;
    })
    .join('\n');
}

// Divide o texto em blocos de tamanho parecido (~1200 caracteres), sempre
// fechando num fim de linha, pra manter contexto coeso sem estourar o prompt.
function cbDividirEmBlocos(texto, tamanhoAlvo) {
  const paragrafos = texto.split(/\n{1,}/).map((p) => p.trim()).filter(Boolean);
  const blocos = [];
  let atual = '';
  for (const p of paragrafos) {
    if (atual && (atual.length + p.length) > tamanhoAlvo) {
      blocos.push(atual);
      atual = p;
    } else {
      atual = atual ? `${atual}\n${p}` : p;
    }
  }
  if (atual) blocos.push(atual);
  return blocos;
}

async function cbCarregarLivroDoutrina(livro) {
  if (cbCacheDoutrina[livro.chave]) return cbCacheDoutrina[livro.chave];
  try {
    const url = chrome.runtime.getURL(livro.arquivo);
    const resp = await fetch(url);
    if (!resp.ok) return null;
    const bruto = await resp.text();
    const limpo = cbLimparTextoLivro(bruto);
    const blocos = cbDividirEmBlocos(limpo, 1200);
    cbCacheDoutrina[livro.chave] = blocos;
    return blocos;
  } catch (e) {
    return null;
  }
}

// ramosClassificados: array opcional de chaves de ramo (ver
// ia-classificador-materia.js) já identificadas por IA — um livro entra se
// bater por palavra-chave OU por ramo classificado (ver comentário
// equivalente em ia-legislacao-permanente.js).
function cbIdentificarLivrosDoutrina(pergunta, ramosClassificados) {
  const alvo = ` ${String(pergunta || '').toLowerCase()} `;
  const ramos = Array.isArray(ramosClassificados) ? ramosClassificados : [];
  return CB_DOUTRINA_LIVROS.filter((livro) => (
    livro.apelidos.some((a) => alvo.includes(a)) || ramos.includes(livro.ramo)
  ));
}

// Retorna { fonteLabel, resumo } com os 2 melhores trechos do(s) livro(s)
// cujo ramo bateu com a pergunta, ou null se nenhum livro foi identificado ou
// nenhum trecho teve sobreposição relevante de palavras.
async function cbBuscarNaDoutrinaPermanente(pergunta, ramosClassificados) {
  const livros = cbIdentificarLivrosDoutrina(pergunta, ramosClassificados);
  if (!livros.length) return null;

  const palavras = String(pergunta || '')
    .toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter((p) => p.length > 3);
  if (!palavras.length) return null;

  const candidatos = [];
  for (const livro of livros) {
    const blocos = await cbCarregarLivroDoutrina(livro);
    if (!blocos) continue;
    for (const bloco of blocos) {
      const alvo = bloco.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
      let score = 0;
      palavras.forEach((p) => { if (alvo.includes(p)) score += 1; });
      if (score > 0) candidatos.push({ livro: livro.nome, bloco, score });
    }
  }

  if (!candidatos.length) return null;
  candidatos.sort((a, b) => b.score - a.score);
  const melhores = candidatos.slice(0, 2);

  const resumo = melhores.map((c) => `[${c.livro}]\n${c.bloco}`).join('\n\n---\n\n');
  const fontes = Array.from(new Set(melhores.map((c) => c.livro))).map((titulo) => ({ titulo, url: null, interna: true }));
  return {
    fonteLabel: 'Doutrina (e-book de curso preparatório, importado localmente)',
    resumo,
    fontes,
    avisoTipo: 'Isto é OPINIÃO DOUTRINÁRIA de um curso preparatório, não é texto de lei nem decisão judicial — trate como orientação/explicação didática, não como fonte oficial. Se a pergunta pedir número de artigo ou julgado específico, prefira confirmar contra a lei/jurisprudência antes de citar.',
  };
}

window.cbBuscarNaDoutrinaPermanente = cbBuscarNaDoutrinaPermanente;
window.cbIdentificarLivrosDoutrina = cbIdentificarLivrosDoutrina;
