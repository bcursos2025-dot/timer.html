// ============================================================================
// revisao-espacada.js — Agenda de revisão espaçada dos artigos salvos (modelo
// de caixas, estilo Leitner). Módulo puro: recebe/devolve objetos e timestamps,
// não toca em storage nem em DOM. Usado pelo popup (revisao-artigos.js) e pelo
// painel do Planalto (planalto/artigos-erros.js). Testes em
// dados-config/testes/revisao-espacada.test.js.
//
// Cartão: { nivel, proxima, ultima, acertos, erros }
//   nivel   — caixa atual (0 = acabou de entrar ou esqueceu; sobe a cada "Lembrei")
//   proxima — timestamp da meia-noite LOCAL do dia da próxima revisão
//   ultima  — timestamp da última revisão (null enquanto nunca revisou)
//
// Intervalos (em dias) por caixa: 1, 3, 7, 14, 30, 60. Artigo novo vence amanhã.
// "Lembrei" sobe uma caixa; "Esqueci" volta para a caixa 0 (revisão amanhã).
// Errar de novo uma questão que cita um artigo já salvo também reinicia a caixa:
// é sinal de que a memória falhou.
// ============================================================================
(function (raiz) {
    'use strict';

    const DIA_MS = 24 * 60 * 60 * 1000;
    const INTERVALOS_DIAS = [1, 3, 7, 14, 30, 60];

    function inicioDoDia(ts) {
        const d = new Date(ts);
        d.setHours(0, 0, 0, 0);
        return d.getTime();
    }
    // soma dias de CALENDÁRIO (não 24h), para o horário de verão não deslocar o dia
    function somarDias(ts, n) {
        const d = new Date(inicioDoDia(ts));
        d.setDate(d.getDate() + n);
        return d.getTime();
    }

    function novoCartao(agora) {
        return { nivel: 0, proxima: somarDias(agora, INTERVALOS_DIAS[0]), ultima: null, acertos: 0, erros: 0 };
    }

    function avaliar(cartao, lembrou, agora) {
        const c = Object.assign({ nivel: 0, acertos: 0, erros: 0 }, cartao);
        if (lembrou) {
            c.nivel = Math.min((c.nivel || 0) + 1, INTERVALOS_DIAS.length - 1);
            c.acertos = (c.acertos || 0) + 1;
        } else {
            c.nivel = 0;
            c.erros = (c.erros || 0) + 1;
        }
        c.proxima = somarDias(agora, INTERVALOS_DIAS[c.nivel]);
        c.ultima = agora;
        return c;
    }

    // errou de novo uma questão sobre este artigo: volta para a caixa 0, revisão amanhã
    function reiniciar(cartao, agora) {
        const c = Object.assign({ nivel: 0, acertos: 0, erros: 0 }, cartao);
        c.nivel = 0;
        c.erros = (c.erros || 0) + 1;
        c.proxima = somarDias(agora, INTERVALOS_DIAS[0]);
        return c;
    }

    // dias até a revisão: 0 = hoje, negativo = atrasado
    function diasParaRevisar(cartao, agora) {
        return Math.round((inicioDoDia(cartao.proxima) - inicioDoDia(agora)) / DIA_MS);
    }
    function vencido(cartao, agora) {
        return diasParaRevisar(cartao, agora) <= 0;
    }

    function rotuloProxima(cartao, agora) {
        const d = diasParaRevisar(cartao, agora);
        if (d < 0) return d === -1 ? 'atrasada 1 dia' : 'atrasada ' + Math.abs(d) + ' dias';
        if (d === 0) return 'hoje';
        if (d === 1) return 'amanhã';
        return 'em ' + d + ' dias';
    }

    // mais atrasados primeiro; depois por data; depois do mais antigo salvo
    function ordenarParaRevisao(itens, agora) {
        return itens.slice().sort((a, b) => {
            const da = diasParaRevisar(a.srs, agora), db = diasParaRevisar(b.srs, agora);
            if (da !== db) return da - db;
            return (a.criadoEm || 0) - (b.criadoEm || 0);
        });
    }

    function contar(itens, agora) {
        let vencidos = 0;
        itens.forEach((it) => { if (it.srs && vencido(it.srs, agora)) vencidos++; });
        return { vencidos, total: itens.length };
    }

    const API = { INTERVALOS_DIAS, inicioDoDia, somarDias, novoCartao, avaliar, reiniciar, diasParaRevisar, vencido, rotuloProxima, ordenarParaRevisao, contar };
    if (typeof module !== 'undefined' && module.exports) module.exports = API;
    raiz.CBRevisaoEspacada = API;
})(typeof window !== 'undefined' ? window : globalThis);
