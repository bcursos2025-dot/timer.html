// ===================== CLASSIFICADOR DE MATÉRIA (agente de contexto) =====================
//
// Problema que isso resolve: a busca em legislação/doutrina permanentes
// (ia-legislacao-permanente.js / ia-doutrina-permanente.js) decidia sozinha
// quais arquivos abrir SÓ por bater uma palavra-chave literal ("apelido") na
// pergunta. Isso falha toda vez que a pessoa pergunta com outras palavras —
// ex.: "quais são as formas de justa causa" tem "justa causa" (hoje já
// cadastrado), mas "posso ser mandado embora sem motivo?" não bate com nada
// e a busca simplesmente não acontece, mesmo com a CLT inteira salva local.
// Nesse vácuo, a IA "chuta" a matéria sozinha (já aconteceu: misturou CDC
// com justa causa trabalhista).
//
// Solução: antes de abrir qualquer arquivo, uma chamada de IA rápida e
// barata (mesmo provedor gratuito com fallback de ia-provider.js) lê SÓ a
// pergunta e devolve, num formato fixo e fácil de validar, quais RAMOS do
// direito ela cobre — dentre uma lista fechada (CB_RAMOS_JURIDICOS). Esse
// resultado é então cruzado com o campo "ramo" de cada livro nos dois
// acervos permanentes, então mesmo sem nenhuma palavra-chave literal bater,
// o livro certo ainda é encontrado.
//
// Importante: a lista de ramos é FECHADA e a resposta do classificador é
// filtrada contra ela (cbNormalizarRamos) — se o modelo "inventar" um ramo
// fora da lista, ou responder qualquer lixo/explicação em vez do formato
// pedido, isso é descartado e o código cai de volta pro casamento por
// palavra-chave (que continua funcionando sozinho, sem depender disso).
// Ou seja: essa camada só ADICIONA cobertura, nunca pode piorar o que já
// funcionava.

const CB_RAMOS_JURIDICOS = [
  'civil', 'constitucional', 'administrativo', 'tributario', 'penal',
  'processo_civil', 'processo_penal', 'trabalhista', 'previdenciario',
  'consumidor', 'transito', 'difusos_coletivos', 'penal_especial',
  'financeiro_orcamentario', 'jurisprudencia',
];

const CB_CLASSIFICADOR_SYSTEM_PROMPT = `Você é um classificador de matéria jurídica para concursos públicos brasileiros. Sua ÚNICA tarefa é ler a pergunta da pessoa e dizer a quais ramos do direito abaixo ela pertence.

Ramos válidos (responda usando EXATAMENTE essas palavras, em minúsculo):
civil, constitucional, administrativo, tributario, penal, processo_civil, processo_penal, trabalhista, previdenciario, consumidor, transito, difusos_coletivos, penal_especial, financeiro_orcamentario, jurisprudencia

Regras de resposta (siga à risca):
- Responda APENAS com os ramos aplicáveis, separados por vírgula, sem espaço extra, sem explicação, sem frase, sem pontuação no final. Exemplo de resposta válida: "trabalhista" ou "civil,processo_civil".
- Pode haver mais de um ramo (ex.: uma pergunta sobre prazo prescricional em ação previdenciária pode ser "previdenciario,civil").
- Se a pergunta NÃO for sobre nenhum desses ramos (português, RLM, informática, atualidades, conversa fiada, pergunta sobre a própria extensão/agenda/desempenho), responda apenas a palavra: nenhum
- Nunca responda nada além de ramos da lista separados por vírgula, ou "nenhum". Nunca escreva frases.`;

function cbNormalizarRamos(textoResposta) {
  const bruto = String(textoResposta || '').toLowerCase().trim();
  if (!bruto || bruto === 'nenhum') return [];
  const candidatos = bruto.split(',').map((s) => s.trim().replace(/[^a-z_]/g, ''));
  const validos = candidatos.filter((r) => CB_RAMOS_JURIDICOS.includes(r));
  return Array.from(new Set(validos));
}

// cache de módulo por pergunta normalizada — evita gastar uma segunda
// chamada de IA se a pessoa perguntar algo muito parecido de novo na mesma
// sessão do popup (o histórico do chat some ao fechar o popup, então esse
// cache também não precisa sobreviver além disso).
const cbCacheClassificacao = {};

function cbChaveCacheClassificacao(pergunta) {
  return String(pergunta || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim();
}

// Retorna um array de ramos (pode ser []). Nunca lança erro — qualquer falha
// (rede, formato inesperado da IA) só resulta em [] e o resto do pipeline
// cai de volta pro casamento por palavra-chave, sem quebrar nada.
async function cbClassificarMateria(pergunta) {
  const chave = cbChaveCacheClassificacao(pergunta);
  if (!chave) return [];
  if (cbCacheClassificacao[chave]) return cbCacheClassificacao[chave];

  if (typeof window.cbGerarRespostaIA !== 'function') return [];

  try {
    const resposta = await window.cbGerarRespostaIA([
      { role: 'system', content: CB_CLASSIFICADOR_SYSTEM_PROMPT },
      { role: 'user', content: String(pergunta || '').slice(0, 500) },
    ]);
    const ramos = cbNormalizarRamos(resposta);
    cbCacheClassificacao[chave] = ramos;
    return ramos;
  } catch (e) {
    return [];
  }
}

window.CB_RAMOS_JURIDICOS = CB_RAMOS_JURIDICOS;
window.cbClassificarMateria = cbClassificarMateria;
