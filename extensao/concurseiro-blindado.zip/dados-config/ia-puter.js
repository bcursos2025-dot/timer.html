// ===================== PUTER (Claude e outros modelos, pela conta da própria pessoa) =====================
//
// O Puter (puter.com) dá acesso a Claude, GPT e Gemini cobrando o uso da CONTA de quem usa ("user-pays"):
// cada conta tem uma cota mensal gratuita (1.000 créditos na conta de teste; uma pergunta curta ao Claude
// Haiku custou ~2 créditos, medido em 2026-10-13). Acabou a cota, o Puter responde 402 e a fila segue para
// as outras IAs. NUNCA há conta compartilhada nem credencial dentro da extensão: a pessoa entra com a conta
// dela na página interface-popup/puter.html e o login fica guardado no navegador, no endereço da extensão.
//
// Só entra na fila se a pessoa ligou ("cbPuterAtivo" em chrome.storage.local). O SDK oficial
// (dados-config/lib/puter/puter.js, ~520 KB, baixado de js.puter.com/v2) só é carregado quando precisa.
// O chat chama cbTentarPuter(mensagens); ele devolve o texto ou lança erro (e a fila continua).
(function (root) {
    'use strict';

    const MODELOS = {
        'claude-haiku-4-5': 'Claude Haiku 4.5 (rápido e barato)',
        'claude-sonnet-4-6': 'Claude Sonnet 4.6 (melhor, gasta mais crédito)',
    };
    const MODELO_PADRAO = 'claude-haiku-4-5';

    // A resposta do puter.ai.chat vem como { message: { content: "texto" | [{type:'text', text}] } },
    // às vezes como texto puro.
    function extrairTexto(resp) {
        if (resp == null) return '';
        if (typeof resp === 'string') return resp;
        const c = resp.message && resp.message.content !== undefined ? resp.message.content : (resp.text !== undefined ? resp.text : resp);
        if (typeof c === 'string') return c;
        if (Array.isArray(c)) return c.map((p) => (typeof p === 'string' ? p : (p && p.text) || '')).join('');
        if (c && typeof c.text === 'string') return c.text;
        return '';
    }

    // O Puter aceita role system/user/assistant; garante que o conteúdo é texto.
    function prepararMensagens(mensagens) {
        return (mensagens || []).filter((m) => m && m.content).map((m) => ({ role: m.role, content: String(m.content) }));
    }

    const api = { MODELOS, MODELO_PADRAO, extrairTexto, prepararMensagens };
    if (typeof module !== 'undefined' && module.exports) { module.exports = api; return; }

    // ---------- ligação com o navegador ----------
    let carregando = null;
    function carregarSDK() {
        if (root.puter) return Promise.resolve(root.puter);
        if (!carregando) {
            carregando = new Promise((resolve, reject) => {
                const s = document.createElement('script');
                s.src = chrome.runtime.getURL('dados-config/lib/puter/puter.js');
                s.onload = () => (root.puter ? resolve(root.puter) : reject(new Error('SDK do Puter não iniciou')));
                s.onerror = () => { carregando = null; reject(new Error('SDK do Puter não carregou')); };
                document.head.appendChild(s);
            });
        }
        return carregando;
    }

    function ler(chaves) {
        return new Promise((resolve) => chrome.storage.local.get(chaves, (r) => resolve(r || {})));
    }

    // true só se a pessoa ligou o Puter nas configurações
    root.cbPuterLigado = async function () {
        if (!root.chrome || !chrome.storage) return false;
        return !!(await ler(['cbPuterAtivo'])).cbPuterAtivo;
    };

    root.cbTentarPuter = async function (mensagens, signal) {
        const cfg = await ler(['cbPuterAtivo', 'cbPuterModelo']);
        if (!cfg.cbPuterAtivo) throw new Error('Puter desligado');
        const puter = await carregarSDK();
        if (!puter.auth.isSignedIn()) throw new Error('Puter: faça login em Configurações → Inteligência artificial');
        const modelo = MODELOS[cfg.cbPuterModelo] ? cfg.cbPuterModelo : MODELO_PADRAO;
        const chamada = puter.ai.chat(prepararMensagens(mensagens), { model: modelo });
        const resposta = await (signal ? Promise.race([chamada, new Promise((_, rej) => signal.addEventListener('abort', () => rej(new Error('tempo esgotado'))))]) : chamada);
        const texto = extrairTexto(resposta).trim();
        if (!texto) throw new Error('Puter devolveu resposta vazia');
        return texto;
    };
    root.CBPuter = api;
})(typeof window !== 'undefined' ? window : globalThis);
