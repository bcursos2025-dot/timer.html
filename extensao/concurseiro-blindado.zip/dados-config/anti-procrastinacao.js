// ===================== MODO ANTI-PROCRASTINAÇÃO =====================
//
// Quando a pessoa está num site de distração (redes sociais, streaming, vídeo curto) e NÃO está com a sessão de
// estudo rodando, depois de 10 segundos no site a extensão avisa na própria página: "volte a estudar", dá 2
// MINUTOS com a linha vermelha encolhendo no topo e, no fim, FECHA a aba sozinha. Quem está com o cronômetro
// rodando continua sob a regra de sempre (a barrinha dos 5 minutos em checkDistractionLimit): este modo só atua
// quando NÃO se está estudando.
//
// Pode ser desligado em Configurações → Modo anti-procrastinação (chrome.storage.local.cbAntiProcrastinacao;
// ligado quando a chave não existe). Na primeira vez que o aviso aparece, ele conta isso à pessoa
// (cbAntiProcVistoAviso). Só a liberação por 5 min ("Preciso deste site agora", cbLiberadosTemp) isenta um site.
//
// Roda no service worker (funciona com o popup fechado). Se o script da página não estiver instalado (a
// permissão ampla é opcional), a pessoa recebe uma notificação e a aba fecha do mesmo jeito. A parte pura
// (que site é distração, se o aviso deve começar) roda em Node: dados-config/testes/anti-procrastinacao.test.js.
(function (root) {
    'use strict';

    const DWELL_MS = 10 * 1000;          // tempo no site antes de o aviso aparecer (evita disparar num clique por engano)
    const AVISO_MS = 2 * 60 * 1000;      // prazo até a aba fechar
    const LIBERA_MS = 5 * 60 * 1000;     // "Preciso deste site agora"

    // Hosts de distração (subdomínios contam: m.facebook.com). YouTube é tratado à parte, por caminho.
    const SITES = [
        'instagram.com', 'facebook.com', 'tiktok.com', 'twitter.com', 'x.com', 'threads.net', 'snapchat.com',
        'kwai.com', 'reddit.com', '9gag.com', 'pinterest.com', 'twitch.tv', 'dailymotion.com',
        'netflix.com', 'primevideo.com', 'disneyplus.com', 'max.com', 'hbomax.com', 'globoplay.globo.com',
    ];

    function normalizar(host) { return String(host || '').trim().toLowerCase().replace(/^www\./, ''); }
    function bate(host, alvo) { return host === alvo || host.endsWith('.' + alvo); }

    // YouTube tem muita videoaula: só conta a página inicial, os Shorts e o feed de recomendações.
    function youtubeEhDistracao(host, caminho) {
        if (!(bate(host, 'youtube.com') || host === 'youtu.be')) return false;
        if (host === 'youtu.be') return false;
        const c = caminho || '/';
        return c === '/' || c === '' || c.startsWith('/shorts') || c.startsWith('/feed');
    }

    function ehSiteDeDistracao(url) {
        let u;
        try { u = new URL(url); } catch (e) { return false; }
        if (u.protocol !== 'http:' && u.protocol !== 'https:') return false;
        const host = normalizar(u.hostname);
        if (!host) return false;
        if (youtubeEhDistracao(host, u.pathname)) return true;
        return SITES.some((s) => bate(host, s));
    }

    function hostDe(url) { try { return normalizar(new URL(url).hostname); } catch (e) { return ''; } }

    // Só vale a liberação TEMPORÁRIA ("Preciso deste site agora", 5 min). A lista "Não bloquear" da pergunta que
    // aparece na página (cbSitesLiberados) é sobre bloquear DURANTE o estudo e não isenta este modo: quem
    // liberou o Reddit para estudar não quer, por isso, passar a tarde nele com o cronômetro parado.
    function liberado(host, cfg, agora) {
        const temp = cfg.cbLiberadosTemp || {};
        return Object.keys(temp).some((h) => (host === normalizar(h) || host.endsWith('.' + normalizar(h))) && temp[h] > agora);
    }

    // Decide o próximo passo. estado: { tabId, host, desde, fim } ou null.
    // → { acao: 'nada' | 'iniciar-contagem' | 'avisar' | 'cancelar', estado }
    function decidir({ ligado, estudando, url, tabId, estado, cfg, agora }) {
        if (!ligado || estudando) return { acao: estado ? 'cancelar' : 'nada', estado: null };
        const distracao = ehSiteDeDistracao(url) && !liberado(hostDe(url), cfg || {}, agora);
        if (estado && estado.fim) {
            // aviso em andamento: só sai se a aba saiu do site de distração (o prazo segue mesmo se trocou de aba)
            return distracao ? { acao: 'nada', estado } : { acao: 'cancelar', estado: null };
        }
        if (!distracao) return { acao: estado ? 'cancelar' : 'nada', estado: null };
        const host = hostDe(url);
        if (!estado || estado.tabId !== tabId || estado.host !== host) {
            return { acao: 'iniciar-contagem', estado: { tabId, host, desde: agora, fim: null } };
        }
        if (agora - estado.desde >= DWELL_MS) return { acao: 'avisar', estado: Object.assign({}, estado, { fim: agora + AVISO_MS }) };
        return { acao: 'nada', estado };
    }

    const api = { DWELL_MS, AVISO_MS, LIBERA_MS, SITES, ehSiteDeDistracao, youtubeEhDistracao, liberado, decidir, hostDe };
    if (typeof module !== 'undefined' && module.exports) { module.exports = api; return; }

    // ---------- service worker ----------
    const ALARME_FIM = 'cb-antiproc-fim';
    const K_ESTADO = 'cbAntiProcEstado';
    const lerLocal = (chaves) => new Promise((r) => chrome.storage.local.get(chaves, (x) => r(x || {})));
    const gravarLocal = (obj) => new Promise((r) => chrome.storage.local.set(obj, r));
    const tabPorId = (id) => new Promise((r) => chrome.tabs.get(id, (t) => r(chrome.runtime.lastError ? null : t)));

    function mensagemParaAba(tabId, msg) {
        return new Promise((resolve) => {
            try { chrome.tabs.sendMessage(tabId, msg, () => { void chrome.runtime.lastError; resolve(); }); } catch (e) { resolve(); }
        });
    }
    function notificar(titulo, texto) {
        try { chrome.notifications.create({ type: 'basic', iconUrl: 'models/icon.png', title: titulo, message: texto, priority: 2 }); } catch (e) { /* sem permissão de notificação */ }
    }

    async function cancelar(estado) {
        try { chrome.alarms.clear(ALARME_FIM); } catch (e) { /* ignora */ }
        await gravarLocal({ [K_ESTADO]: null });
        if (estado && estado.fim && estado.tabId != null) await mensagemParaAba(estado.tabId, { action: 'cbAntiProcStop' });
    }

    async function avisar(estado) {
        const cfg = await lerLocal(['cbAntiProcVistoAviso']);
        const primeiraVez = !cfg.cbAntiProcVistoAviso;
        await gravarLocal({ [K_ESTADO]: estado, cbAntiProcVistoAviso: true });
        try { chrome.alarms.create(ALARME_FIM, { when: estado.fim }); } catch (e) { /* o tick de 1 s cobre */ }
        await mensagemParaAba(estado.tabId, { action: 'cbAntiProcStart', fim: estado.fim, total: AVISO_MS, host: estado.host, primeiraVez });
        // sem o script da página, a notificação é o único aviso
        notificar('Hora de voltar a estudar', `Você está em ${estado.host} fora do cronômetro. Esta aba fecha em 2 minutos. Pode desativar em Configurações → Modo anti-procrastinação.`);
    }

    async function fecharSeVencido() {
        const { [K_ESTADO]: estado } = await lerLocal([K_ESTADO]);
        if (!estado || !estado.fim || Date.now() < estado.fim - 500) return;
        const aba = await tabPorId(estado.tabId);
        const cfg = await lerLocal(['cbAntiProcrastinacao', 'sessionState', 'cbSitesLiberados', 'cbLiberadosTemp']);
        const continua = aba && ehSiteDeDistracao(aba.url) && !liberado(hostDe(aba.url), cfg, Date.now());
        const ligado = cfg.cbAntiProcrastinacao !== false && cfg.sessionState !== 'running';
        await cancelar(null);
        if (continua && ligado) {
            chrome.tabs.remove(estado.tabId, () => { void chrome.runtime.lastError; });
            notificar('Aba fechada', 'Foco: hora de voltar a estudar.');
        }
    }

    async function tick() {
        const cfg = await lerLocal(['cbAntiProcrastinacao', 'sessionState', 'cbSitesLiberados', 'cbLiberadosTemp', K_ESTADO]);
        const estado = cfg[K_ESTADO] || null;
        if (estado && estado.fim && Date.now() >= estado.fim) { await fecharSeVencido(); return; }

        // Janela NORMAL usada por último (ignora o popup da extensão). Não exige que ela esteja "com foco": em
        // alguns navegadores (Opera) esse indicador vem falso mesmo com a pessoa olhando a página, e o modo
        // nunca disparava. Sem janela ou sem aba ativa, não há o que checar.
        const janela = await new Promise((r) => chrome.windows.getLastFocused({ windowTypes: ['normal'] }, (w) => r(chrome.runtime.lastError ? null : w)));
        const abas = await new Promise((r) => chrome.tabs.query({ active: true, windowId: janela ? janela.id : undefined }, (t) => r(t || [])));
        const aba = abas[0];
        const semFoco = !janela || !aba;
        const entrada = {
            ligado: cfg.cbAntiProcrastinacao !== false,
            estudando: cfg.sessionState === 'running',
            url: semFoco ? '' : aba.url,
            tabId: semFoco ? null : aba.id,
            estado: (semFoco && estado && !estado.fim) ? null : estado,
            cfg,
            agora: Date.now(),
        };
        // com aviso em andamento, quem vale é a aba do aviso (mesmo que a pessoa tenha trocado de aba)
        if (estado && estado.fim && !entrada.estudando && entrada.ligado) {
            const dela = await tabPorId(estado.tabId);
            if (!dela) { await cancelar(null); return; }
            entrada.url = dela.url; entrada.tabId = dela.id;
        }
        const r = decidir(entrada);
        // Diagnóstico visível em Configurações → Modo anti-procrastinação: por que aparece (ou não) o aviso
        const host = hostDe(entrada.url);
        await gravarLocal({
            cbAntiProcDiag: {
                ts: Date.now(), ligado: entrada.ligado, estudando: entrada.estudando, semFoco,
                host, distracao: ehSiteDeDistracao(entrada.url), liberado: host ? liberado(host, cfg, Date.now()) : false,
                acao: r.acao, desde: r.estado ? r.estado.desde : null, fim: r.estado ? r.estado.fim : null, erro: null,
            },
        });
        if (r.acao === 'cancelar') await cancelar(estado);
        else if (r.acao === 'iniciar-contagem') await gravarLocal({ [K_ESTADO]: r.estado });
        else if (r.acao === 'avisar') await avisar(r.estado);
        else if (semFoco && estado && !estado.fim) await gravarLocal({ [K_ESTADO]: null });
    }

    // Botão "Testar o aviso" das Configurações: mostra o cartão de verdade na aba ativa, por 15 s, sem fechar nada.
    async function testarAviso() {
        const janela = await new Promise((r) => chrome.windows.getLastFocused({ windowTypes: ['normal'] }, (w) => r(chrome.runtime.lastError ? null : w)));
        const abas = await new Promise((r) => chrome.tabs.query({ active: true, windowId: janela ? janela.id : undefined }, (t) => r(t || [])));
        const aba = abas[0];
        if (!aba) return { ok: false, motivo: 'Não achei uma aba aberta para mostrar o aviso.' };
        const fim = Date.now() + 15000;
        await mensagemParaAba(aba.id, { action: 'cbAntiProcStart', fim, total: 15000, host: hostDe(aba.url) || 'este site', primeiraVez: true, teste: true });
        notificar('Teste do modo anti-procrastinação', 'Se você viu este balão mas não o cartão na página, falta a permissão de “todos os sites”.');
        setTimeout(() => mensagemParaAba(aba.id, { action: 'cbAntiProcStop' }), 15500);
        return { ok: true };
    }

    root.cbAntiProcTick = () => tick().catch((e) => {
        console.warn('[AntiProc]', e);
        gravarLocal({ cbAntiProcDiag: { ts: Date.now(), erro: String((e && e.message) || e) } });
    });
    setInterval(root.cbAntiProcTick, 5000);
    // O service worker dorme quando ocioso e o setInterval morre junto. Por isso, além dos alarmes, qualquer
    // mudança de aba/site/janela acorda o worker e roda a checagem NA HORA, e um relógio curto + um alarme de
    // reserva garantem que o aviso apareça logo depois dos 10 segundos, sem esperar o próximo heartbeat de 1 min.
    const agendarDwell = () => {
        setTimeout(root.cbAntiProcTick, DWELL_MS + 400);
        try { chrome.alarms.create('cb-antiproc-dwell', { when: Date.now() + Math.max(DWELL_MS + 400, 30500) }); } catch (e) { /* ignora */ }
    };
    const aoMudar = () => { root.cbAntiProcTick(); agendarDwell(); };
    try {
        chrome.tabs.onActivated.addListener(aoMudar);
        chrome.tabs.onUpdated.addListener((id, mud) => { if (mud.url || mud.status === 'complete') aoMudar(); });
        chrome.windows.onFocusChanged.addListener(aoMudar);
    } catch (e) { /* sem esses eventos o heartbeat cobre */ }
    chrome.alarms.onAlarm.addListener((a) => {
        if (a.name === ALARME_FIM) fecharSeVencido().catch(() => {});
        else if (a.name === 'cb-heartbeat' || a.name === 'cb-antiproc-dwell') root.cbAntiProcTick();
    });
    agendarDwell();

    // Mensagens da página (botões do aviso)
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
        if (msg && msg.action === 'cbAntiProcTeste') {
            testarAviso().then((r) => sendResponse(r)).catch((e) => sendResponse({ ok: false, motivo: String((e && e.message) || e) }));
            return true;
        }
        if (!msg || !sender || !sender.tab) return;
        if (msg.action === 'cbAntiProcFecharAgora') {
            cancelar(null).then(() => chrome.tabs.remove(sender.tab.id, () => { void chrome.runtime.lastError; }));
        } else if (msg.action === 'cbAntiProcPreciso') {
            const host = hostDe(sender.tab.url);
            lerLocal(['cbLiberadosTemp']).then((c) => {
                const temp = Object.assign({}, c.cbLiberadosTemp || {});
                temp[host] = Date.now() + LIBERA_MS;
                return gravarLocal({ cbLiberadosTemp: temp });
            }).then(() => cancelar({ tabId: sender.tab.id, fim: 1 }));
        }
    });
    root.CBAntiProc = api;
})(typeof self !== 'undefined' ? self : globalThis);
