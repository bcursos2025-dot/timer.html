// ===================== ALARME DE INÍCIO DE ESTUDO =====================
// Se um bloco do cronograma de hoje começou há mais de X minutos e a
// pessoa ainda não deu play no cronômetro (sessionState !== 'running'),
// dispara uma notificação. O alarme pode ser desligado, mas a mudança só
// vale 24h depois de pedida — de propósito, pra não virar uma saída fácil
// bem na hora em que bateria a preguiça.

const CB_ALARME_TOLERANCIA_MIN = 10; // minutos de atraso tolerados antes de avisar

function cbAlarmeHojeStr() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// Aplica uma mudança pendente de "desligar alarme" se já passaram as 24h,
// e retorna o estado efetivo atual (true = alarme ligado).
function cbAlarmeAplicarPendenciaEObterEstado(callback) {
    chrome.storage.sync.get(['cbAlarmeAtivo', 'cbAlarmePendente'], (res) => {
        let ativo = res.cbAlarmeAtivo !== false; // padrão: ligado
        const pendente = res.cbAlarmePendente || null;

        if (pendente && Date.now() >= pendente.efetivoEm) {
            ativo = pendente.novoValor;
            chrome.storage.sync.set({ cbAlarmeAtivo: ativo, cbAlarmePendente: null });
            callback(ativo, null);
        } else {
            callback(ativo, pendente);
        }
    });
}

function cbAlarmeVerificarBlocos() {
    cbAlarmeAplicarPendenciaEObterEstado((ativo) => {
        if (!ativo) return;

        chrome.storage.local.get(['cbCronogramaHoje', 'cbCronogramaData', 'cbAlarmeDisparadosHoje'], (res) => {
            const hoje = cbAlarmeHojeStr();
            if (res.cbCronogramaData !== hoje) return;
            const blocos = res.cbCronogramaHoje || [];
            if (!blocos.length) return;

            const disparadosState = res.cbAlarmeDisparadosHoje || { data: hoje, ids: [] };
            const jaDisparados = disparadosState.data === hoje ? disparadosState.ids : [];

            const agoraMin = new Date().getHours() * 60 + new Date().getMinutes();

            blocos.forEach((b) => {
                if (jaDisparados.includes(b.id)) return;
                const [ih, im] = b.inicio.split(':').map(Number);
                const [fh, fm] = b.fim.split(':').map(Number);
                const ini = ih * 60 + im;
                const fim = fh * 60 + fm;
                const limiteAviso = ini + CB_ALARME_TOLERANCIA_MIN;

                if (agoraMin >= limiteAviso && agoraMin < fim && sessionState !== 'running') {
                    const tipoLabel = { leitura: 'Leitura', video: 'Vídeo-aula', questoes: 'Questões', revisao: 'Revisão' }[b.tipo] || b.tipo;
                    showNotification(
                        'Você marcou estudar agora e ainda não começou',
                        `${tipoLabel}${b.materia ? ' — ' + b.materia : ''}, das ${b.inicio} às ${b.fim}. Bora?`
                    );
                    jaDisparados.push(b.id);
                    chrome.storage.local.set({ cbAlarmeDisparadosHoje: { data: hoje, ids: jaDisparados } });
                }
            });
        });
    });
}

// Reaproveita o heartbeat de 1 min que já existe (chrome.alarms 'cb-heartbeat')
// pra também checar o alarme de cronograma, sem criar outro alarme redundante.
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'cb-heartbeat') cbAlarmeVerificarBlocos();
});

// Chamado pelo popup quando a pessoa liga/desliga o alarme em Ajustes.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'cbAlarmeSetEstado') {
        if (message.ativo === true) {
            // Ligar é imediato.
            chrome.storage.sync.set({ cbAlarmeAtivo: true, cbAlarmePendente: null }, () => sendResponse({ ok: true, efetivoEm: null }));
        } else {
            // Desligar só entra em vigor 24h depois do pedido.
            const efetivoEm = Date.now() + 24 * 60 * 60 * 1000;
            chrome.storage.sync.set({ cbAlarmePendente: { novoValor: false, efetivoEm } }, () => sendResponse({ ok: true, efetivoEm }));
        }
        return true;
    }
    if (message.action === 'cbAlarmeGetEstado') {
        cbAlarmeAplicarPendenciaEObterEstado((ativo, pendente) => sendResponse({ ativo, pendente }));
        return true;
    }
});
