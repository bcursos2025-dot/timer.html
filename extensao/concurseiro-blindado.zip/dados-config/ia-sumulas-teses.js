// ===================== SÚMULAS E TESES (STF / STJ) — BASE LOCAL =====================
//
// Fonte para o chat de IA: súmulas do STF (736), súmulas vinculantes (63), súmulas do STJ (676) e a
// Jurisprudência em Teses do STJ (284 edições, 3.526 teses). Os dados vêm da base jurídica do projeto
// "Advocacia Aberta" (https://github.com/emidio-trancoso/advocacia-aberta, MIT), que os reuniu das páginas
// oficiais do STF e do STJ; os arquivos enxutos ficam em dados-config/materiais-jurisprudencia/ e são gerados por
// dados-config/scripts/gerar-sumulas-teses.js. Zero custo de cota e zero rede: tudo vem empacotado.
//
// Dois jeitos de achar:
//   • REFERÊNCIA explícita ("súmula 7 do STJ", "súmula vinculante 11", "SV 13"): busca exata pelo número. Se a
//     pergunta cita outro tribunal (TST, TSE, TCU...), NÃO responde com o texto de STF/STJ, que seria outro
//     enunciado de mesmo número; devolve null e a conversa segue sem inventar.
//   • TEXTO ("o que o STJ entende sobre dano moral por negativação indevida"): palavras da pergunta contra o
//     enunciado, o tema e a área. Exige boa sobreposição, para não citar súmula só "parecida".
//
// A parte pura (sem DOM, sem chrome.*) roda em Node: ver dados-config/testes/ia-sumulas-teses.test.js.
// Só o final do arquivo liga isso ao navegador (carrega os JSON sob demanda).
(function (root) {
    'use strict';

    const norm = (s) => String(s == null ? '' : s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');

    // Tribunais que têm súmulas numeradas e NÃO estão nesta base.
    const OUTROS_TRIBUNAIS = ['tst', 'tse', 'tcu', 'stm', 'tnu', 'cade', 'carf', 'trf', 'trf1', 'trf2', 'trf3', 'trf4', 'trf5', 'trf6', 'tj', 'tjdft', 'tjsp', 'tjrj'];

    // ---------- referências explícitas ----------
    // → { refs: [{ numero, alvo: 'sv' | 'stf' | 'stj' | 'ambos' | 'outro' }] }
    function extrairReferencias(pergunta) {
        const t = norm(pergunta);
        const refs = [];

        // "súmula vinculante 11", "súmulas vinculantes 11 e 13", "sv 13"
        const reSv = /(?:s[uú]mulas?\s+vinculantes?|\bsvs?)\s*(?:n[o°.º]*\s*)?((?:\d{1,3}\s*(?:,|e|ou|\/)?\s*)+)/g;
        let m;
        const cobertos = [];
        while ((m = reSv.exec(t))) {
            cobertos.push([m.index, m.index + m[0].length]);
            (m[1].match(/\d{1,3}/g) || []).forEach((n) => refs.push({ numero: Number(n), alvo: 'sv' }));
        }

        // "súmula 7 do STJ", "súmulas 331 e 126", "súmula n. 13 do supremo"
        const reSum = /s[uú]mulas?\s*(?:n[o°.º]*\s*)?((?:\d{1,4}\s*(?:,|e|ou|\/)?\s*)+)/g;
        while ((m = reSum.exec(t))) {
            if (cobertos.some(([a, b]) => m.index >= a && m.index < b)) continue;
            const depois = t.slice(m.index + m[0].length, m.index + m[0].length + 34);
            const antes = t.slice(Math.max(0, m.index - 26), m.index);
            const janela = depois + ' | ' + antes;
            const alvo = alvoDoTribunal(janela);
            (m[1].match(/\d{1,4}/g) || []).forEach((n) => refs.push({ numero: Number(n), alvo }));
        }

        // "tema 1244", "Tema 1.420 do STF", "repercussão geral tema 725". Tema também existe no STJ (repetitivos),
        // que NÃO está nesta base: com STJ/repetitivo na janela vira 'outro'. Sem tribunal, só conta de 20 para cima
        // (evita "tema 3 do edital").
        const reTema = /\btemas?\s*(?:n[o°.º]*\s*)?((?:\d[\d.]{0,5}\s*(?:,|e|ou|\/)?\s*)+)/g;
        while ((m = reTema.exec(t))) {
            const depois = t.slice(m.index + m[0].length, m.index + m[0].length + 34);
            const antes = t.slice(Math.max(0, m.index - 30), m.index);
            const janela = depois + ' | ' + antes;
            let alvo;
            if (/\bstj\b|repetitiv|superior tribunal de justica/.test(janela)) alvo = 'outro';
            else if (/\bstf\b|supremo|repercuss/.test(janela)) alvo = 'rg';
            else alvo = 'rg?';
            (m[1].match(/\d[\d.]*/g) || []).forEach((n) => {
                const numero = Number(n.replace(/\./g, ''));
                if (alvo === 'rg?' && numero < 20) return;
                refs.push({ numero, alvo, tema: true });
            });
        }
        return { refs: refs.filter((r) => r.numero > 0) };
    }

    function alvoDoTribunal(janela) {
        // o que vem DEPOIS do número manda; só se não houver nada ali olha o que veio antes
        const [depois, antes] = janela.split(' | ');
        const ler = (txt) => {
            if (/\bstf\b|supremo/.test(txt)) return 'stf';
            if (/\bstj\b|superior tribunal de justica/.test(txt)) return 'stj';
            if (/tribunal superior do trabalho/.test(txt)) return 'outro';
            if (new RegExp('\\b(' + OUTROS_TRIBUNAIS.join('|') + ')\\b').test(txt)) return 'outro';
            return null;
        };
        return ler(depois) || ler(antes) || 'ambos';
    }

    // ---------- formatação ----------
    const ROTULO_STATUS = { ativa: 'em vigor', aprovada: 'em vigor', cancelada: 'CANCELADA', superada: 'SUPERADA', alterada: 'ALTERADA' };

    function statusTxt(s) {
        const r = ROTULO_STATUS[s] || String(s || '');
        return /^(CANCELADA|SUPERADA|ALTERADA)$/.test(r) ? `${r} — não use como entendimento atual` : r;
    }

    function blocoSumula(tipo, it) {
        const cab = tipo === 'sv' ? `Súmula Vinculante ${it.n} (STF)` : `Súmula ${it.n} do ${tipo === 'stf' ? 'STF' : 'STJ'}`;
        const meta = [statusTxt(it.s), it.a, it.t, it.o, it.d ? `${tipo === 'sv' ? 'aprovada' : 'editada'} em ${it.d}` : ''].filter(Boolean).join(' · ');
        return `[${cab} — ${meta}]\n${it.e}`;
    }
    function fonteSumula(tipo, it) {
        const titulo = tipo === 'sv' ? `STF — Súmula Vinculante ${it.n}` : `${tipo === 'stf' ? 'STF' : 'STJ'} — Súmula ${it.n}`;
        return { titulo, url: it.u || null, interna: true };
    }

    function blocoTese(it) {
        const cab = `Jurisprudência em Teses do STJ — Edição ${it.ed}: ${it.et} — tese ${it.n} (${it.r}${it.d ? `, publicada em ${it.d}` : ''})`;
        return `[${cab}]\n${it.e}`;
    }
    function fonteTese(it) {
        return { titulo: `STJ — Jurisprudência em Teses, ed. ${it.ed}`, url: `https://scon.stj.jus.br/SCON/GetPDFSelecaoJT?selecao_edicao=${it.ed}`, interna: true };
    }

    function blocoTema(it) {
        const meta = [it.s, it.d ? `julgado em ${it.d}` : '', it.lc, it.a].filter(Boolean).join(' · ');
        const corpo = it.e ? `Tese: ${it.e}` : `Tese ainda NÃO fixada. Questão em discussão: ${it.t}${it.q ? ' — ' + it.q : ''}`;
        const aviso = /cancelad/i.test(it.s || '') ? '\n(Tema CANCELADO — não use como entendimento atual.)' : '';
        const titulo = it.t ? `Título: ${it.t}\n` : '';
        return `[Tema ${it.n} do STF (repercussão geral) — ${meta}]\n${titulo}${corpo}${aviso}`;
    }
    function fonteTema(it) {
        return { titulo: `STF — Tema ${it.n} (repercussão geral)`, url: it.u || null, interna: true };
    }

    const AVISO_BASE = 'Base local de súmulas, teses e temas de repercussão geral (STF/STJ), reunida de fontes oficiais; pode não ter súmulas editadas ou canceladas depois da data de geração. A Jurisprudência em Teses mostra o entendimento do STJ na data da edição e pode ter sido superado. Cite só o que está literalmente acima.';

    // ---------- busca por referência ----------
    function porReferencia(refs, bases) {
        const blocos = [];
        const fontes = [];
        let semTribunal = false;
        const visto = new Set();
        const pegar = (tipo, n) => {
            const base = bases[tipo];
            if (!base) return;
            const it = base.itens.find((x) => x.n === n);
            const chave = tipo + n;
            if (!it || visto.has(chave)) return;
            visto.add(chave);
            blocos.push(tipo === 'rg' ? blocoTema(it) : blocoSumula(tipo, it));
            fontes.push(tipo === 'rg' ? fonteTema(it) : fonteSumula(tipo, it));
        };
        let temaSemTribunal = false;
        refs.forEach((r) => {
            if (r.alvo === 'outro') return;
            if (r.tema) { if (r.alvo === 'rg?') temaSemTribunal = true; pegar('rg', r.numero); return; }
            if (r.alvo === 'sv') pegar('sv', r.numero);
            else if (r.alvo === 'stf') pegar('stf', r.numero);
            else if (r.alvo === 'stj') pegar('stj', r.numero);
            else { semTribunal = true; pegar('stf', r.numero); pegar('stj', r.numero); }
        });
        if (!blocos.length) return null;
        const avisoTema = temaSemTribunal ? 'ATENÇÃO: a pessoa não disse de qual tribunal é o tema. Temas de repercussão geral são do STF; o STJ também numera temas (repetitivos), que NÃO estão nesta base. Diga que o texto acima é do STF e, se o assunto não combinar, avise que o tema pedido pode ser de repetitivo do STJ. ' : '';
        const aviso = avisoTema + (semTribunal
            ? 'ATENÇÃO: a pessoa não disse de qual tribunal é a súmula. Súmulas de mesmo número existem em vários tribunais (inclusive TST, TSE e TCU, que NÃO estão nesta base). Diga de qual tribunal é cada texto acima e, se o assunto da pergunta não combinar com ele, avise que a súmula pedida pode ser de outro tribunal em vez de forçar uma resposta.'
            : '');
        return { blocos, fontes, aviso };
    }

    // ---------- busca por texto ----------
    const STOP = new Set(('para como qual quais quando onde porque porem sobre entre apos antes desde ate pelo pela pelos pelas '
        + 'esta este estes estas essa esse essas esses isso aquele aquela aqui ali muito muita muitos pode podem posso deve devem '
        + 'quer quero queria saber explique explicar explica diga fale fala resumo resuma entendimento entende entendem tese teses '
        + 'tema temas sumula sumulas stj stf tribunal superior supremo justica federal direito caso casos tambem apenas mesmo mesma sera seria '
        + 'existe existem tem tenho voce nosso nossa dele dela deles delas cada qualquer outro outra outros outras sempre nunca '
        + 'uma umas uns seu sua seus suas depois durante conforme segundo acordo hoje atual atualmente jurisprudencia '
        + 'que com por nos nas dos das num numa').split(/\s+/));

    function palavrasChave(pergunta) {
        const vistas = new Set();
        return norm(pergunta).split(/[^a-z0-9]+/).filter((p) => p.length >= 4 && !STOP.has(p) && !/^\d+$/.test(p))
            .filter((p) => (vistas.has(p) ? false : vistas.add(p)));
    }
    // "licitacoes" e "licitacao" precisam casar: compara pelo radical da palavra.
    // Palavra curta fica inteira (evita "banco" casar com "bancário"); a longa perde o final, até 7 letras.
    function radical(p) {
        if (p.length <= 5) return p;
        if (p.length === 6) return p.slice(0, 5);
        return p.slice(0, Math.min(p.length - 2, 7));
    }

    // Texto normalizado de cada item, calculado uma vez por base (a busca passa por ~5 mil itens).
    const TEXTOS = new WeakMap();
    function textosDe(itens, campoTema) {
        let t = TEXTOS.get(itens);
        if (!t) {
            t = itens.map((it) => ({ e: norm(it.e), tema: norm(campoTema(it)) }));
            TEXTOS.set(itens, t);
        }
        return t;
    }
    const temaSumula = (it) => [it.a, it.t].join(' ');
    const temaTese = (it) => [it.et, it.r].join(' ');
    const temaRg = (it) => [it.t, it.q, it.a].join(' ');

    // Quantos itens (de todas as bases) contêm o radical: palavra rara pesa mais que "prazo" ou "administrativa".
    function pesosDasPalavras(palavras, grupos) {
        const total = grupos.reduce((n, g) => n + g.itens.length, 0);
        return palavras.map((p) => {
            const r = radical(p);
            let df = 0;
            grupos.forEach((g) => { g.textos.forEach((t) => { if (t.e.includes(r) || t.tema.includes(r)) df += 1; }); });
            return { p, r, df, peso: Math.log((total + 1) / (df + 1)) };
        });
    }

    function pontuar(pesos, texto) {
        let achado = 0;
        let nAchadas = 0;
        let raras = 0;
        pesos.forEach((w) => {
            if (texto.e.includes(w.r)) { achado += w.peso; nAchadas += 1; if (w.df <= 8 && w.p.length >= 6) raras += 1; }
            else if (texto.tema.includes(w.r)) { achado += w.peso * 0.5; nAchadas += 1; }
        });
        return { achado, nAchadas, raras };
    }

    function porTexto(pergunta, bases, opcoes) {
        const palavras = palavrasChave(pergunta);
        if (!palavras.length) return null;
        const limiteSumulas = (opcoes && opcoes.maxSumulas) || 3;
        const limiteTeses = (opcoes && opcoes.maxTeses) || 2;

        const grupos = [];
        ['stf', 'stj', 'sv'].forEach((tipo) => {
            if (bases[tipo]) grupos.push({ tipo, itens: bases[tipo].itens, textos: textosDe(bases[tipo].itens, temaSumula) });
        });
        if (bases.rg) grupos.push({ tipo: 'rg', itens: bases.rg.itens, textos: textosDe(bases.rg.itens, temaRg) });
        if (bases.jt) grupos.push({ tipo: 'jt', itens: bases.jt.itens, textos: textosDe(bases.jt.itens, temaTese) });
        if (!grupos.length) return null;

        const pesos = pesosDasPalavras(palavras, grupos);
        const pesoTotal = pesos.reduce((n, w) => n + w.peso, 0) || 1;
        // aceita com 2+ palavras que cubram metade do peso da pergunta, ou com UMA palavra rara
        // (ex.: "algemas") quando a pergunta é curta
        const serve = (r) => (r.nAchadas >= 2 && r.achado / pesoTotal >= 0.5) || (r.nAchadas >= 1 && r.raras >= 1 && palavras.length <= 3);

        const sumulas = [];
        const teses = [];
        const temas = [];
        grupos.forEach((g) => {
            g.itens.forEach((it, i) => {
                const r = pontuar(pesos, g.textos[i]);
                if (!serve(r)) return;
                if (g.tipo === 'jt') { teses.push({ it, ordem: r.achado }); return; }
                // temas são muitos e curtos: pedem mais sobreposição que as súmulas
                if (g.tipo === 'rg' && r.achado / pesoTotal < 0.65 && !(r.raras >= 1 && palavras.length <= 3)) return;
                if (g.tipo === 'rg') { temas.push({ it, ordem: r.achado - (/cancelad/i.test(it.s) ? 2 : 0) - (it.e ? 0 : 0.5) }); return; }
                const vigente = /^(ativa|aprovada)$/.test(it.s);
                sumulas.push({ tipo: g.tipo, it, ordem: r.achado - (vigente ? 0 : 2) + (g.tipo === 'sv' ? 0.3 : 0) });
            });
        });
        sumulas.sort((a, b) => b.ordem - a.ordem);
        teses.sort((a, b) => b.ordem - a.ordem);
        temas.sort((a, b) => b.ordem - a.ordem);
        const escolhidosR = temas.slice(0, 2);

        const escolhidasS = sumulas.slice(0, limiteSumulas);
        // tese que só repete o texto de uma súmula já mostrada não acrescenta nada
        const inicio = (x) => norm(x).replace(/[^a-z0-9]+/g, ' ').trim().slice(0, 70);
        const jaMostradas = new Set(escolhidasS.map((c) => inicio(c.it.e)));
        const escolhidasT = [];
        for (const c of teses) {
            if (escolhidasT.length >= limiteTeses) break;
            if (jaMostradas.has(inicio(c.it.e))) continue;
            escolhidasT.push(c);
        }
        if (!escolhidasS.length && !escolhidasT.length && !escolhidosR.length) return null;
        return {
            blocos: escolhidasS.map((c) => blocoSumula(c.tipo, c.it)).concat(escolhidosR.map((c) => blocoTema(c.it)), escolhidasT.map((c) => blocoTese(c.it))),
            fontes: escolhidasS.map((c) => fonteSumula(c.tipo, c.it)).concat(escolhidosR.map((c) => fonteTema(c.it)), escolhidasT.map((c) => fonteTese(c.it))),
            aviso: '',
        };
    }

    // ---------- ponto de entrada puro ----------
    // bases: { stf, stj, sv, rg, jt } (cada uma { itens, geradoEm }; qualquer uma pode faltar).
    // opcoes.soReferencia: não faz busca por texto (usado no começo da cascata, para só atender "súmula N").
    // → { fonteLabel, resumo, fontes } ou null
    function consultar(pergunta, bases, opcoes) {
        const { refs } = extrairReferencias(pergunta);
        let r;
        if (refs.length) r = porReferencia(refs, bases);       // citou número: só vale a busca exata
        else if (!(opcoes && opcoes.soReferencia)) r = porTexto(pergunta, bases, opcoes);
        if (!r) return null;
        const resumo = r.blocos.join('\n\n') + '\n\n' + (r.aviso ? r.aviso + '\n\n' : '') + AVISO_BASE;
        return { fonteLabel: 'Súmulas, Jurisprudência em Teses e temas de repercussão geral do STF/STJ (base local)', resumo, fontes: r.fontes };
    }

    const api = { norm, extrairReferencias, palavrasChave, consultar, AVISO_BASE };
    if (typeof module !== 'undefined' && module.exports) { module.exports = api; return; }

    // ---------- ligação com o navegador: carrega os JSON só quando a pergunta precisa ----------
    const ARQUIVOS = {
        stf: 'dados-config/materiais-jurisprudencia/sumulas_stf.json',
        stj: 'dados-config/materiais-jurisprudencia/sumulas_stj.json',
        sv: 'dados-config/materiais-jurisprudencia/sumulas_vinculantes.json',
        jt: 'dados-config/materiais-jurisprudencia/jt_stj.json',
        rg: 'dados-config/materiais-jurisprudencia/temas_rg_stf.json',
    };
    const cache = {};
    function carregar(chave) {
        if (!cache[chave]) {
            cache[chave] = fetch(chrome.runtime.getURL(ARQUIVOS[chave]))
                .then((r) => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
                .catch((e) => { delete cache[chave]; throw e; });
        }
        return cache[chave];
    }

    root.cbBuscarSumulasETeses = async function (pergunta, opcoes) {
        const { refs } = extrairReferencias(pergunta);
        const soReferencia = !!(opcoes && opcoes.soReferencia);
        if (!refs.length && (soReferencia || palavrasChave(pergunta).length < 2)) return null;
        const chaves = refs.length ? ['stf', 'stj', 'sv', 'rg'] : ['stf', 'stj', 'sv', 'rg', 'jt'];
        const bases = {};
        await Promise.all(chaves.map((c) => carregar(c).then((b) => { bases[c] = b; }).catch(() => null)));
        return consultar(pergunta, bases, opcoes);
    };
    root.CBSumulasTeses = api;
})(typeof window !== 'undefined' ? window : globalThis);
