// ============================================================================
// classificacao-apps.js — nome bonito e categoria de cada programa do PC
// ----------------------------------------------------------------------------
// O monitor do Windows manda o nome cru do processo ("msedge", "acrord32",
// "winword"). Isso e' inutil de ler numa lista. Aqui vira "Microsoft Edge",
// "Adobe Acrobat Reader", "Word".
//
// A categoria (estudo / distracao / neutro) e' um PALPITE PADRAO, nunca uma
// sentenca: a pessoa reclassifica qualquer app com um clique na aba de
// Distracoes, e a escolha dela (guardada em chrome.storage.local.appCategorias)
// sempre vence. Por isso o padrao pode errar sem estragar nada.
//
// REGRA QUE USEI PRO PADRAO: so' marco como "distracao" o que praticamente
// nao tem uso de estudo (jogos, loja de jogos, streaming de video). Coisas
// ambiguas de verdade — Spotify (muita gente estuda com musica), VLC (pode
// ser videoaula), Excel, Outlook — ficam NEUTRO. Errar pra neutro e' barato:
// a pessoa move pra distracao se quiser. Errar pra distracao e' irritante,
// porque acusa a pessoa de algo que ela nao fez.
//
// Navegador e' sempre NEUTRO aqui de proposito: o que voce faz DENTRO dele
// ja' e' medido site a site no grafico de sites da mesma aba. Marcar
// "chrome = distracao" contaria a mesma hora duas vezes, com nomes
// diferentes, e o total nao fecharia com nada.
// ============================================================================

(function (escopo) {
    'use strict';

    // ---------------------------------------------------------- nomes bonitos
    const CB_APPS_NOMES = {
        // --- leitura / PDF ---
        'acrobat': 'Adobe Acrobat',
        'acrord32': 'Adobe Acrobat Reader',
        'readerdc': 'Adobe Acrobat Reader',
        'sumatrapdf': 'SumatraPDF',
        'foxitreader': 'Foxit Reader',
        'foxitphantom': 'Foxit PhantomPDF',
        'pdfxedit': 'PDF-XChange Editor',
        'calibre': 'Calibre',
        'xodo': 'Xodo',

        // --- escrita / estudo ---
        'winword': 'Word',
        'excel': 'Excel',
        'powerpnt': 'PowerPoint',
        'onenote': 'OneNote',
        'onenoteim': 'OneNote',
        'notion': 'Notion',
        'obsidian': 'Obsidian',
        'anki': 'Anki',
        'evernote': 'Evernote',
        'wps': 'WPS Office',
        'soffice': 'LibreOffice',
        'soffice.bin': 'LibreOffice',
        'zotero': 'Zotero',
        'mendeleydesktop': 'Mendeley',
        'xmind': 'XMind',
        'freemind': 'FreeMind',

        // --- navegadores ---
        'chrome': 'Google Chrome',
        'msedge': 'Microsoft Edge',
        'firefox': 'Firefox',
        'opera': 'Opera',
        'opera_gx': 'Opera GX',
        'brave': 'Brave',
        'vivaldi': 'Vivaldi',
        'iexplore': 'Internet Explorer',

        // --- conversa ---
        'whatsapp': 'WhatsApp',
        'telegram': 'Telegram',
        'discord': 'Discord',
        'ms-teams': 'Microsoft Teams',
        'teams': 'Microsoft Teams',
        'zoom': 'Zoom',
        'olk': 'Outlook',
        'outlook': 'Outlook',
        'slack': 'Slack',
        'skype': 'Skype',

        // --- video / musica ---
        'vlc': 'VLC',
        'spotify': 'Spotify',
        'potplayermini64': 'PotPlayer',
        'mpc-hc64': 'Media Player Classic',
        'netflix': 'Netflix',
        'primevideo': 'Prime Video',
        'obs64': 'OBS Studio',

        // --- jogos e lojas ---
        'steam': 'Steam',
        'steamwebhelper': 'Steam',
        'epicgameslauncher': 'Epic Games',
        'battle.net': 'Battle.net',
        'riotclientux': 'Riot Client',
        'leagueoflegends': 'League of Legends',
        'valorant-win64-shipping': 'Valorant',
        'cs2': 'Counter-Strike 2',
        'csgo': 'CS:GO',
        'dota2': 'Dota 2',
        'minecraft': 'Minecraft',
        'javaw': 'Minecraft (Java)',
        'robloxplayerbeta': 'Roblox',
        'gta5': 'GTA V',
        'fortniteclient-win64-shipping': 'Fortnite',
        'eldenring': 'Elden Ring',
        'ubisoftgamelauncher': 'Ubisoft Connect',
        'goggalaxy': 'GOG Galaxy',

        // --- sistema / trabalho ---
        'explorer': 'Explorador de Arquivos',
        'notepad': 'Bloco de Notas',
        'notepad++': 'Notepad++',
        'code': 'VS Code',
        'devenv': 'Visual Studio',
        'windowsterminal': 'Terminal',
        'cmd': 'Prompt de Comando',
        'powershell': 'PowerShell',
        'calculator': 'Calculadora',
        'applicationframehost': 'Aplicativo do Windows',
        'systemsettings': 'Configuracoes',
        'snippingtool': 'Ferramenta de Captura',
        'photos': 'Fotos',
        'mspaint': 'Paint'
    };

    // ------------------------------------------------------ categorias padrao
    const CB_APPS_ESTUDO = [
        'acrobat', 'acrord32', 'readerdc', 'sumatrapdf', 'foxitreader',
        'foxitphantom', 'pdfxedit', 'calibre', 'xodo',
        'winword', 'powerpnt', 'onenote', 'onenoteim', 'notion', 'obsidian',
        'anki', 'evernote', 'wps', 'soffice', 'soffice.bin', 'zotero',
        'mendeleydesktop', 'xmind', 'freemind'
    ];

    const CB_APPS_DISTRACAO = [
        'steam', 'steamwebhelper', 'epicgameslauncher', 'battle.net',
        'riotclientux', 'leagueoflegends', 'valorant-win64-shipping',
        'cs2', 'csgo', 'dota2', 'minecraft', 'javaw', 'robloxplayerbeta',
        'gta5', 'fortniteclient-win64-shipping', 'eldenring',
        'ubisoftgamelauncher', 'goggalaxy',
        'whatsapp', 'telegram', 'discord', 'netflix', 'primevideo'
    ];

    // Tudo o que nao esta' em nenhuma das duas listas cai em 'neutro'.

    const CB_CATEGORIA_ROTULO = {
        estudo: 'Estudo',
        distracao: 'Distracao',
        neutro: 'Neutro'
    };

    function normalizarProcesso(proc) {
        return String(proc || '')
            .toLowerCase()
            .replace(/\.exe$/, '')
            .trim();
    }

    // Nome pra mostrar na tela. Se o programa nao esta' na tabela, devolve o
    // proprio nome do processo com a primeira letra maiuscula — melhor que
    // esconder um app que a pessoa usa muito so' porque eu nao previ ele.
    function nomeAmigavelApp(proc) {
        const p = normalizarProcesso(proc);
        if (!p) return 'Desconhecido';
        if (CB_APPS_NOMES[p]) return CB_APPS_NOMES[p];
        return p.charAt(0).toUpperCase() + p.slice(1);
    }

    // A escolha manual da pessoa (overrides) sempre ganha do padrao.
    function classificarApp(proc, overrides) {
        const p = normalizarProcesso(proc);
        if (overrides && Object.prototype.hasOwnProperty.call(overrides, p)) {
            return overrides[p];
        }
        if (CB_APPS_ESTUDO.indexOf(p) !== -1) return 'estudo';
        if (CB_APPS_DISTRACAO.indexOf(p) !== -1) return 'distracao';
        return 'neutro';
    }

    function ehNavegador(proc) {
        const p = normalizarProcesso(proc);
        return ['chrome', 'msedge', 'firefox', 'opera', 'opera_gx', 'brave', 'vivaldi', 'iexplore'].indexOf(p) !== -1;
    }

    escopo.CBClassificacaoApps = {
        nomeAmigavelApp,
        classificarApp,
        normalizarProcesso,
        ehNavegador,
        CATEGORIAS: ['estudo', 'distracao', 'neutro'],
        ROTULOS: CB_CATEGORIA_ROTULO
    };
})(typeof self !== 'undefined' ? self : window);
