// ===================== ESCRITA DE AGENDA PELA IA =====================
//
// Único ponto onde a IA pode GRAVAR blocos na agenda (chrome.storage). Segue
// o mesmo contrato de dados de rotina/rotina-diaria.js (cbCronogramaPorData
// é a fonte da verdade; cbCronogramaHoje/cbCronogramaData ficam espelhados
// pro dia de hoje pra não quebrar popup/bloqueio). Nunca é chamado sozinho —
// só depois que a pessoa confirma explicitamente na tela.

function cbHojeStrAgenda() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// propostas: [{ data:"AAAA-MM-DD", inicio:"HH:MM", fim:"HH:MM", materia, prioridade }]
function cbAdicionarBlocosAgenda(propostas) {
  return new Promise((resolve, reject) => {
    const porDataNovos = {};
    (propostas || []).forEach((p) => {
      if (!p || !p.data || !p.inicio || !p.fim) return;
      const bloco = {
        id: `crono_ia_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
        inicio: p.inicio,
        fim: p.fim,
        tipo: 'outro',
        materia: String(p.materia || 'Estudo').slice(0, 80),
        prioridade: ['alta', 'media', 'baixa'].includes(p.prioridade) ? p.prioridade : 'media',
        aviso: true,
      };
      (porDataNovos[p.data] = porDataNovos[p.data] || []).push(bloco);
    });

    const datas = Object.keys(porDataNovos);
    if (!datas.length) { reject(new Error('Nenhum bloco válido pra adicionar.')); return; }

    chrome.storage.local.get(['cbCronogramaPorData', 'cbCronogramaHoje', 'cbCronogramaData'], (res) => {
      const hoje = cbHojeStrAgenda();
      const porData = res.cbCronogramaPorData ? { ...res.cbCronogramaPorData } : {};
      if (res.cbCronogramaData === hoje) porData[hoje] = res.cbCronogramaHoje || [];

      datas.forEach((ds) => {
        const atual = (porData[ds] || []).concat(porDataNovos[ds]);
        atual.sort((a, b) => (a.inicio || '').localeCompare(b.inicio || ''));
        porData[ds] = atual;
      });

      const patch = { cbCronogramaPorData: porData };
      if (porData[hoje]) {
        patch.cbCronogramaHoje = porData[hoje];
        patch.cbCronogramaData = hoje;
      }

      chrome.storage.local.set(patch, () => {
        chrome.runtime.sendMessage({ action: 'cronogramaAtualizado' }).catch(() => {});
        resolve();
      });
    });
  });
}

window.cbAdicionarBlocosAgenda = cbAdicionarBlocosAgenda;
