// Tela escura de bloqueio. Só é aberta pelo service worker quando a pessoa
// mandou bloquear ESTE site (ver dados-config/cronograma-bloqueio.js) — não
// existe mais bloqueio automático por lista escondida nem por cronograma.

// Esta página é sempre navegada como aba própria (nunca embutida pela
// extensão) e tem um botão que pede a permissão <all_urls> (fb-perm-btn
// abaixo). Como manifest.json expõe foco/bloqueio.html a <all_urls> via
// web_accessible_resources, qualquer site poderia tentar carregá-la dentro
// de um <iframe> pra fazer clickjacking nesse botão de permissão. Sair do
// frame se algum dia formos carregados dentro de um.
if (window.top !== window.self) {
    try { window.top.location = window.self.location; } catch (e) { window.self.location = 'about:blank'; }
}

const params = new URLSearchParams(location.search);
const originalUrl = params.get('url') || '';
const host = params.get('host') || '';

const txt = document.getElementById('fb-bloco-texto');
if (txt && host) {
    txt.textContent = `Você marcou "${host}" para ficar bloqueado enquanto estuda.`;
}

// ===================== CRONÔMETRO NA TELA ESCURA =====================
// Lê o mesmo studyHistory que o cronômetro flutuante e o popup usam. O
// background atualiza esse valor de tempos em tempos; entre uma atualização
// e outra a gente só continua contando na tela, pra não ficar travado.
const timerEl = document.getElementById('fb-timer');
const timerLabelEl = document.getElementById('fb-timer-label');

let baseMs = 0;          // último valor lido do storage
let baseLidoEm = 0;      // quando esse valor foi lido
let rodando = false;

function fbHojeKey() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function fbFormatar(ms) {
    let s = Math.floor(Math.max(0, ms) / 1000);
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    s %= 60;
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

function fbLerEstado() {
    chrome.storage.local.get(['studyHistory', 'sessionState'], (res) => {
        baseMs = (res.studyHistory || {})[fbHojeKey()] || 0;
        baseLidoEm = Date.now();
        const estado = res.sessionState || 'stopped';
        rodando = estado === 'running';
        if (timerLabelEl) {
            timerLabelEl.textContent = rodando
                ? 'estudando hoje'
                : (estado.startsWith('paused') ? 'pausado' : 'cronômetro parado');
        }
        fbPintar();
    });
}

function fbPintar() {
    if (!timerEl) return;
    const extra = rodando ? (Date.now() - baseLidoEm) : 0;
    timerEl.textContent = fbFormatar(baseMs + extra);
}

fbLerEstado();
setInterval(fbPintar, 1000);
setInterval(fbLerEstado, 15000); // re-sincroniza com o valor real do background
chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && (changes.studyHistory || changes.sessionState)) fbLerEstado();
});

// ===================== POR QUE ESTA PÁGINA APARECEU =====================
// Dois motivos possíveis, e eles pedem saídas diferentes:
//   1) a extensão não tem permissão pra rodar nos sites → dá pra resolver
//      aqui mesmo, com um clique (esta é uma página da extensão, então
//      chrome.permissions.request funciona a partir deste botão);
//   2) tem permissão, mas a aba não aceita content script (visualizador de
//      PDF do navegador, páginas internas) → não tem o que fazer, e aí a
//      explicação é só informativa.
const permBox = document.getElementById('fb-perm-box');
const notaPdf = document.getElementById('fb-nota-pdf');

if (chrome.permissions && chrome.permissions.contains) {
    chrome.permissions.contains({ origins: ['<all_urls>'] }, (temPermissao) => {
        if (temPermissao) {
            if (notaPdf) notaPdf.style.display = '';
        } else if (permBox) {
            permBox.style.display = 'block';
        }
    });
} else if (notaPdf) {
    notaPdf.style.display = '';
}

const permBtn = document.getElementById('fb-perm-btn');
if (permBtn) {
    permBtn.addEventListener('click', () => {
        chrome.permissions.request({ origins: ['<all_urls>'] }, (concedida) => {
            if (!concedida) return;
            // Concedida: o background re-registra o content script
            // (chrome.permissions.onAdded) e, ao voltar pro site, a tela
            // escura aparece por cima dele em vez desta página.
            if (originalUrl) location.href = originalUrl;
        });
    });
}

// ===================== BOTÕES =====================
document.getElementById('fb-voltar').addEventListener('click', () => {
    // Fecha esta aba de bloqueio e volta o foco pro cronograma no popup.
    history.back();
    setTimeout(() => { window.close(); }, 300);
});

document.getElementById('fb-liberar').addEventListener('click', () => {
    if (!host) return;
    chrome.runtime.sendMessage({ action: 'cronogramaLiberarHost', host, minutos: 5 }, () => {
        if (originalUrl) location.href = originalUrl;
    });
});

// Faltava um jeito de desfazer a decisão sem caçar configuração. Agora dá
// pra desbloquear de vez daqui mesmo — o site sai da lista de bloqueio e a
// aba volta pra página original na hora.
document.getElementById('fb-desbloquear').addEventListener('click', () => {
    if (!host) return;
    chrome.runtime.sendMessage({ action: 'cbDesbloquearSite', host }, () => {
        if (originalUrl) location.href = originalUrl;
    });
});
