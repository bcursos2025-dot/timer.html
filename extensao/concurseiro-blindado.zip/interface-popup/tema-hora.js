// Dia/noite do cronômetro: troca a foto da Terra pela versão sem sol
// depois das 18h (e antes das 6h da manhã). Só decide uma classe no
// <html> antes da primeira pintura — quem escolhe a imagem certa por
// trás dessa classe é o planeta.css (".cb-noite"), então reabrir o
// popup mais tarde já reavalia a hora sozinho.
//
// Precisa ser um arquivo à parte, e não um <script> dentro do
// popup.html: a Content Security Policy padrão do Manifest V3 bloqueia
// script inline em silêncio (a página carrega normal, sem erro visível,
// só o script nunca roda) — foi exatamente o que aconteceu na primeira
// tentativa.
(function () {
    var hora = new Date().getHours();
    var ehNoite = hora >= 18 || hora < 6;
    document.documentElement.classList.toggle('cb-noite', ehNoite);
})();
