// ===================== VOCÊ × COMUNIDADE (por matéria e por assunto) =====================
//
// Compara o seu resultado com o da comunidade do QConcursos NAS MESMAS QUESTÕES. Os dados vêm de qconcursos/estatisticas.js
// (chrome.storage.local.cbQcEstat = { 'Q123': { pct, acertos, erros, acertei, materia, assunto, assuntos, url, ts } }),
// que busca sozinho a estatística de cada questão que você responde.
//
// Por que "nas mesmas questões": comparar o seu % geral com o % geral da comunidade engana, porque você pode estar
// resolvendo questões mais difíceis (ou mais fáceis) que a média. Aqui, para cada grupo (matéria ou assunto):
//   • você        = acertos seus ÷ questões que você respondeu naquele grupo;
//   • comunidade  = média do % de acerto da comunidade nessas MESMAS questões (o que se esperaria de uma pessoa média);
//   • diferença   = você − comunidade, em pontos percentuais. Positivo: acima da média; negativo: abaixo.
// O resultado que entra na comparação é o da PRIMEIRA vez que você respondeu a questão (quando o histórico de tentativas
// é conhecido): refazer e acertar mede memória, não domínio, e inflaria o "você". As refações têm bloco próprio.
// Além disso, mostra o seu % geral do QConcursos (páginas Estatísticas > Disciplinas/Assuntos) como contexto, quando o nome casa.
//
// Duas camadas, no mesmo molde de destaques-assuntos.js: funções puras (rodam em Node, ver
// interface-popup/testes/comparativo-comunidade.test.js) e desenho (render).
//
// Regras que evitam conclusão falsa:
//   1. Só entra questão com o seu resultado (acertou/errou) e o % da comunidade conhecidos. Com contagem da comunidade
//      conhecida, exige COMUNIDADE_MIN respostas (3 de 4 acertos não diz nada).
//   2. Grupo com poucas questões aparece marcado como "amostra pequena" (e só entra com MIN_MATERIA / MIN_ASSUNTO).
//   3. Diferença menor que RUIDO pontos é tratada como "na média" (não pinta de vermelho nem de verde).
//   4. Questão com vários assuntos conta em cada um deles (como o próprio QConcursos faz).
//   5. "Pegadinha" só quando o seu último erro foi numa alternativa que PEGADINHA_MIN % da comunidade também marcou.
(function (root) {
    'use strict';

    const MIN_MATERIA = 3;
    const MIN_ASSUNTO = 2;
    const AMOSTRA_FIRME = 10;     // abaixo disso o grupo leva o aviso de amostra pequena
    const COMUNIDADE_MIN = 10;
    const RUIDO = 5;              // pontos
    const FACIL = 70;             // % de acerto da comunidade a partir do qual a questão é "fácil"
    const DIFICIL = 30;           // ... e até o qual é "difícil"
    const POR_LISTA = 6;
    const PEGADINHA_MIN = 20;     // % da comunidade que marcou a mesma alternativa errada que você

    const norm = (t) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();

    // ------------------------------------------------------------------ cálculo
    function registros(mapa) {
        const lista = [];
        Object.keys(mapa || {}).forEach((qid) => {
            const r = mapa[qid];
            if (!r) return;
            const tentativas = (Array.isArray(r.tentativas) ? r.tentativas : []).filter((t) => t && Number.isFinite(t.ts)).sort((x, y) => x.ts - y.ts);
            const primeira = tentativas.length && typeof tentativas[0].certa === 'boolean' ? tentativas[0].certa : null;
            const eu = primeira !== null ? primeira : r.acertei;
            if (typeof eu !== 'boolean') return;
            const pct = Number(r.pct);
            if (r.pct == null || !Number.isFinite(pct) || pct < 0 || pct > 100) return;
            const total = (Number(r.acertos) || 0) + (Number(r.erros) || 0);
            if (total > 0 && total < COMUNIDADE_MIN) return;
            let assuntos = Array.isArray(r.assuntos) && r.assuntos.length ? r.assuntos : String(r.assunto || '').split(' · ').filter(Boolean);
            assuntos = assuntos.map((a) => String(a).trim()).filter(Boolean);
            lista.push({
                qid, acertei: eu, ultima: typeof r.acertei === 'boolean' ? r.acertei : eu, pct, materia: String(r.materia || '').trim(), assuntos,
                url: r.url || '', total, minha: r.minha ? String(r.minha) : '', alternativas: r.alternativas || null, tentativas,
            });
        });
        return lista;
    }

    function agregar(regs) {
        const n = regs.length;
        const meus = regs.filter((r) => r.acertei).length;
        const eu = n ? (meus / n) * 100 : 0;
        const com = n ? regs.reduce((s, r) => s + r.pct, 0) / n : 0;
        return { n, meus, eu, com, dif: eu - com };
    }

    function grupos(regs, chaves) {
        const mapa = new Map();
        regs.forEach((r) => {
            chaves(r).forEach((k) => {
                if (!k.nome) return;
                const id = norm(k.nome) + '|' + norm(k.materia || '');
                if (!mapa.has(id)) mapa.set(id, { nome: k.nome, materia: k.materia || '', regs: [] });
                mapa.get(id).regs.push(r);
            });
        });
        return Array.from(mapa.values()).map((g) => Object.assign({ nome: g.nome, materia: g.materia }, agregar(g.regs)));
    }

    const porMateria = (regs) => grupos(regs, (r) => (r.materia ? [{ nome: r.materia }] : []));
    const porAssunto = (regs) => grupos(regs, (r) => r.assuntos.map((a) => ({ nome: a, materia: r.materia })));

    // Encontra o seu desempenho geral no QConcursos: igualdade pelo nome sem acento ou um nome começando pelo outro
    // (o QC trunca nomes longos na tabela de assuntos).
    function geralDoQC(nome, lista) {
        const alvo = norm(nome);
        if (!alvo || !Array.isArray(lista)) return null;
        let achado = null;
        lista.forEach((it) => {
            if (achado || !it || !it.nome) return;
            const n = norm(it.nome);
            const casa = n === alvo || (Math.min(n.length, alvo.length) >= 15 && (n.startsWith(alvo) || alvo.startsWith(n)));
            if (casa && Number(it.total) > 0) achado = { pct: (Number(it.certas) / Number(it.total)) * 100, total: Number(it.total) };
        });
        return achado;
    }

    function faceis(regs) {
        return regs.filter((r) => !r.acertei && r.pct >= FACIL).sort((a, b) => b.pct - a.pct).slice(0, POR_LISTA);
    }
    function dificeis(regs) {
        return regs.filter((r) => r.acertei && r.pct <= DIFICIL).sort((a, b) => a.pct - b.pct).slice(0, POR_LISTA);
    }

    // % da comunidade que marcou a alternativa `op` (aceita "e" por "E" e a primeira letra de "Certo"/"Errado").
    function parteDaAlternativa(alts, op) {
        if (!alts || !op) return null;
        const alvo = String(op).toUpperCase();
        const chaves = Object.keys(alts);
        const k = chaves.find((c) => c === op) || chaves.find((c) => c.toUpperCase() === alvo) || chaves.find((c) => c.charAt(0).toUpperCase() === alvo.charAt(0));
        const v = k == null ? NaN : Number(alts[k]);
        return Number.isFinite(v) ? v : null;
    }

    // Erros em que você marcou uma alternativa que muita gente também marcou: o texto da questão induz a esse erro.
    function pegadinhas(regs) {
        return regs
            .filter((r) => !r.ultima && r.minha)
            .map((r) => ({ r, parte: parteDaAlternativa(r.alternativas, r.minha) }))
            .filter((x) => x.parte != null && x.parte >= PEGADINHA_MIN)
            .sort((a, b) => b.parte - a.parte)
            .slice(0, POR_LISTA)
            .map((x) => Object.assign({}, x.r, { parte: x.parte }));
    }

    // Questões que você respondeu mais de uma vez: quantas virou (errou e depois acertou), quantas continuam erradas.
    function refacoes(regs) {
        const conhecidas = (r) => r.tentativas.filter((t) => typeof t.certa === 'boolean');
        const refeitas = regs.filter((r) => conhecidas(r).length >= 2);
        const erros = (r) => conhecidas(r).filter((t) => t.certa === false).length;
        const ult = (r) => conhecidas(r).slice(-1)[0].certa;
        const recuperadas = refeitas.filter((r) => conhecidas(r)[0].certa === false && ult(r) === true).length;
        const teimosas = refeitas.filter((r) => erros(r) >= 2 && ult(r) === false);
        const repetidas = teimosas.slice()
            .sort((a, b) => erros(b) - erros(a) || b.pct - a.pct)
            .slice(0, POR_LISTA).map((r) => Object.assign({}, r, { vezes: erros(r) }));
        return { refeitas: refeitas.length, recuperadas, aindaErradas: teimosas.length, repetidas };
    }

    // Ordem: o pior primeiro (mais abaixo da comunidade); empate → mais questões.
    const pior = (a, b) => a.dif - b.dif || b.n - a.n || a.nome.localeCompare(b.nome, 'pt');
    const melhor = (a, b) => b.dif - a.dif || b.n - a.n || a.nome.localeCompare(b.nome, 'pt');

    function analisar(mapa) {
        const regs = registros(mapa);
        const geral = agregar(regs);
        const materias = porMateria(regs).filter((g) => g.n >= MIN_MATERIA).sort(pior);
        const assuntos = porAssunto(regs).filter((g) => g.n >= MIN_ASSUNTO);
        return {
            n: regs.length,
            geral,
            materias,
            abaixo: assuntos.filter((g) => g.dif <= -RUIDO).sort(pior).slice(0, POR_LISTA),
            acima: assuntos.filter((g) => g.dif >= RUIDO).sort(melhor).slice(0, POR_LISTA),
            assuntosConsiderados: assuntos.length,
            faceisErradas: faceis(regs),
            dificeisAcertadas: dificeis(regs),
            pegadinhas: pegadinhas(regs),
            refacoes: refacoes(regs),
        };
    }

    // ------------------------------------------------------------------ desenho
    // Tela enxuta: um cartão-resumo (você × comunidade), três abas (Matérias · Assuntos · Questões) e as explicações escondidas
    // atrás do ⓘ. Antes tudo aparecia de uma vez, com notas de rodapé e avisos em cada lista.
    const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const plural = (n, um, varios) => `${n} ${n === 1 ? um : varios}`;
    const inteiro = (x) => Math.round(x);
    const tom = (dif) => (dif >= RUIDO ? 'bom' : (dif <= -RUIDO ? 'ruim' : 'meio'));
    const numSinal = (dif) => { const v = inteiro(dif); return `${v > 0 ? '+' : (v < 0 ? '−' : '')}${Math.abs(v)}`; };
    const sinal = (dif) => `${numSinal(dif)} pts`;
    const rotuloTom = { bom: 'acima da média', ruim: 'abaixo da média', meio: 'na média' };
    const LIMITE_LINHAS = 4;       // linhas visíveis por lista; o resto fica atrás de "Mostrar mais"

    const ICON_INFO = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9.5"/><line x1="12" y1="11" x2="12" y2="16.5"/><circle cx="12" cy="7.8" r="0.7" fill="currentColor"/></svg>';

    // lembrados entre redesenhos (o popup redesenha quando chega estatística nova)
    let abaAtiva = null;
    let subAtiva = null;

    function linhaHtml(g, geralQC) {
        const t = tom(g.dif);
        const dica = `${g.nome}${g.materia ? ' (' + g.materia + ')' : ''}: você ${inteiro(g.eu)}%, comunidade ${inteiro(g.com)}% nas mesmas ${g.n} questões`
            + (geralQC ? ` · no QConcursos todo você tem ${inteiro(geralQC.pct)}% (${plural(geralQC.total, 'questão', 'questões')})` : '')
            + (g.n < AMOSTRA_FIRME ? ' · amostra pequena: a diferença pode ser sorte' : '');
        return `
            <li class="cmp-row${g.n < AMOSTRA_FIRME ? ' cmp-row--peq' : ''}" title="${esc(dica)}">
                <div class="cmp-row-top"><span class="cmp-nome">${esc(g.nome)}</span><b class="cmp-dif cmp-dif--${t}" aria-label="${sinal(g.dif)}, ${rotuloTom[t]}">${numSinal(g.dif)}</b></div>
                <div class="cmp-barra" role="img" aria-label="Você ${inteiro(g.eu)}%, comunidade ${inteiro(g.com)}%">
                    <i class="cmp-eu" style="width:${g.eu <= 0 ? 0 : Math.max(g.eu, 3)}%"></i>
                    <u class="cmp-com" style="left:${Math.min(Math.max(g.com, 0), 100)}%"></u>
                </div>
                <div class="cmp-row-sub">Você ${inteiro(g.eu)}% · Comunidade ${inteiro(g.com)}% · ${plural(g.n, 'questão', 'questões')}</div>
            </li>`;
    }

    // lista com as primeiras linhas visíveis e o resto num "Mostrar mais"
    function listaHtml(itens, fazLinha) {
        const vis = itens.slice(0, LIMITE_LINHAS), resto = itens.slice(LIMITE_LINHAS);
        return `<ol class="cmp-lista">${vis.map(fazLinha).join('')}</ol>`
            + (resto.length ? `<details class="cmp-mais"><summary>Mostrar mais ${resto.length}</summary><ol class="cmp-lista">${resto.map(fazLinha).join('')}</ol></details>` : '');
    }

    function questaoHtml(r, detalhe, dica) {
        const rot = `${esc(r.qid)}${r.materia ? ' <i>' + esc(r.materia) + '</i>' : ''}`;
        const alvo = r.url ? `<a class="cmp-q" href="https://www.qconcursos.com${esc(r.url)}" target="_blank" rel="noopener">${rot}</a>` : `<span class="cmp-q">${rot}</span>`;
        return `<li class="cmp-qrow"${dica ? ` title="${esc(dica)}"` : ''}>${alvo}<b>${detalhe}</b></li>`;
    }

    const quemAcertou = (r) => {
        const parte = r.minha && !r.ultima ? parteDaAlternativa(r.alternativas, r.minha) : null;
        return `${inteiro(r.pct)}% acertam${parte != null ? ` · você ${esc(r.minha)} (${inteiro(parte)}%)` : ''}`;
    };

    function painelQuestoes(a) {
        const f = a.refacoes;
        const grupos = [
            { id: 'faceis', rot: 'Fáceis que errei', itens: a.faceisErradas, dica: `Mais de ${FACIL}% da comunidade acerta: vale rever.`, linha: (r) => questaoHtml(r, quemAcertou(r)) },
            { id: 'pegadinhas', rot: 'Pegadinhas', itens: a.pegadinhas, dica: `Você errou numa alternativa que pelo menos ${PEGADINHA_MIN}% da comunidade também marcou.`, linha: (r) => questaoHtml(r, `${esc(r.minha)} · ${inteiro(r.parte)}% também`) },
            { id: 'refacoes', rot: 'Refações', itens: f.repetidas, dica: f.refeitas ? `${plural(f.refeitas, 'questão refeita', 'questões refeitas')}: ${f.recuperadas} ${f.recuperadas === 1 ? 'virou' : 'viraram'}, ${f.aindaErradas} ${f.aindaErradas === 1 ? 'continua errada' : 'continuam erradas'}.` : '', mostrarVazio: f.refeitas > 0, linha: (r) => questaoHtml(r, `errou ${r.vezes}×`, `${inteiro(r.pct)}% da comunidade acerta`) },
            { id: 'dificeis', rot: 'Acertos difíceis', itens: a.dificeisAcertadas, dica: `Menos de ${DIFICIL}% da comunidade acerta.`, linha: (r) => questaoHtml(r, `${inteiro(r.pct)}% acertam`) },
        ].filter((g) => g.itens.length || g.mostrarVazio);
        if (!grupos.length) return { n: 0, html: '<p class="cmp-vazio">Nada por aqui ainda.</p>' };
        if (!grupos.some((g) => g.id === subAtiva)) subAtiva = grupos[0].id;
        const chips = grupos.map((g) => `<button type="button" class="cmp-chipbtn${g.id === subAtiva ? ' cmp-on' : ''}" data-sub="${g.id}">${g.rot}<i>${g.itens.length || ''}</i></button>`).join('');
        const paineis = grupos.map((g) => `<div class="cmp-sub" data-sub="${g.id}"${g.id === subAtiva ? '' : ' hidden'}>${g.dica ? `<p class="cmp-dica">${esc(g.dica)}</p>` : ''}${g.itens.length ? listaHtml(g.itens, g.linha) : ''}</div>`).join('');
        return { n: grupos.reduce((s, g) => s + g.itens.length, 0), html: `<div class="cmp-chips">${chips}</div>${paineis}` };
    }

    // dados = { mapa: cbQcEstat, disciplinas: questoesDisciplinas.itens, assuntosRaw: questoesAssuntosRaw }
    function render(el, dados) {
        const d = dados || {};
        const a = analisar(d.mapa);
        const guardadas = Object.keys(d.mapa || {}).length;
        if (!a.n) {
            el.innerHTML = `<p class="questoes-empty">${guardadas
                ? 'Já há estatísticas guardadas, mas ainda sem o seu resultado nelas. Responda questões no QConcursos (logado) e elas aparecem aqui.'
                : 'Ainda não há dados. A extensão busca sozinha as estatísticas das questões que você responde no QConcursos (logado), sem você abrir nada. Responda algumas questões e volte aqui.'}</p>`;
            return a;
        }
        const g = a.geral;
        const t = tom(g.dif);
        const hero = `
            <div class="cmp-hero">
                <div class="cmp-hero-top">
                    <div class="cmp-big cmp-big--eu"><b>${inteiro(g.eu)}<small>%</small></b><span>Você</span></div>
                    <div class="cmp-big cmp-big--com"><b>${inteiro(g.com)}<small>%</small></b><span>Comunidade</span></div>
                    <button type="button" class="cmp-info-btn" aria-label="Como ler esta comparação" aria-expanded="false" title="Como ler">${ICON_INFO}</button>
                </div>
                <div class="cmp-duo" role="img" aria-label="Você ${inteiro(g.eu)}%, comunidade ${inteiro(g.com)}%">
                    <div class="cmp-duo-linha"><i class="cmp-duo-eu" style="width:${g.eu <= 0 ? 0 : Math.max(g.eu, 2)}%"></i></div>
                    <div class="cmp-duo-linha"><i class="cmp-duo-com" style="width:${g.com <= 0 ? 0 : Math.max(g.com, 2)}%"></i></div>
                </div>
                <div class="cmp-hero-rod">
                    <span class="cmp-chip cmp-chip--${t}">${sinal(g.dif)} · ${rotuloTom[t]}</span>
                    <span class="cmp-n">${plural(g.n, 'questão', 'questões')}${g.n < AMOSTRA_FIRME ? ' · amostra pequena' : ''}</span>
                </div>
                <div class="cmp-info" hidden>
                    <p>Você e a comunidade são comparados <b>nas mesmas questões</b>: “comunidade” é a média de acerto geral de cada questão que você respondeu.</p>
                    <p>Vale a <b>primeira vez</b> que você respondeu cada questão. As refações aparecem na aba Questões.</p>
                    <p>Diferença menor que ${RUIDO} pontos conta como “na média”. Com poucas questões, a diferença pode ser sorte.</p>
                </div>
            </div>`;

        const materias = a.materias.length
            ? listaHtml(a.materias, (m) => linhaHtml(m, geralDoQC(m.nome, d.disciplinas)))
            : `<p class="cmp-vazio">Aparece quando houver ${MIN_MATERIA} questões na mesma matéria.</p>`;
        const assuntosLista = a.abaixo.concat(a.acima);
        const assuntos = assuntosLista.length
            ? listaHtml(assuntosLista, (x) => linhaHtml(x, geralDoQC(x.nome, d.assuntosRaw)))
            : `<p class="cmp-vazio">${a.assuntosConsiderados ? 'Nenhum assunto se afasta da média da comunidade.' : `Aparece quando houver ${MIN_ASSUNTO} questões no mesmo assunto.`}</p>`;
        const q = painelQuestoes(a);

        const abas = [
            { id: 'materias', rot: 'Matérias', n: a.materias.length, html: materias },
            { id: 'assuntos', rot: 'Assuntos', n: assuntosLista.length, html: assuntos },
            { id: 'questoes', rot: 'Questões', n: q.n, html: q.html },
        ];
        if (!abas.some((x) => x.id === abaAtiva)) abaAtiva = (abas.find((x) => x.n > 0) || abas[1]).id;
        const seg = abas.map((x) => `<button type="button" class="cmp-segbtn${x.id === abaAtiva ? ' cmp-on' : ''}" data-aba="${x.id}" role="tab" aria-selected="${x.id === abaAtiva}">${x.rot}${x.n ? `<i>${x.n}</i>` : ''}</button>`).join('');
        const paineis = abas.map((x) => `<div class="cmp-painel" data-aba="${x.id}" role="tabpanel"${x.id === abaAtiva ? '' : ' hidden'}>${x.html}</div>`).join('');

        el.innerHTML = `<section class="cmp">${hero}<div class="cmp-seg" role="tablist">${seg}</div>${paineis}</section>`;
        if (el.querySelectorAll) ligar(el);
        return a;
    }

    // abas, sub-abas e o ⓘ: só mostram/escondem o que já foi desenhado
    function ligar(el) {
        const info = el.querySelector('.cmp-info'), ib = el.querySelector('.cmp-info-btn');
        if (ib && info) ib.addEventListener('click', () => { info.hidden = !info.hidden; ib.setAttribute('aria-expanded', String(!info.hidden)); });
        el.querySelectorAll('.cmp-segbtn').forEach((b) => b.addEventListener('click', () => {
            abaAtiva = b.dataset.aba;
            el.querySelectorAll('.cmp-segbtn').forEach((x) => { const on = x === b; x.classList.toggle('cmp-on', on); x.setAttribute('aria-selected', String(on)); });
            el.querySelectorAll('.cmp-painel').forEach((p) => { p.hidden = p.dataset.aba !== abaAtiva; });
        }));
        el.querySelectorAll('.cmp-chipbtn').forEach((b) => b.addEventListener('click', () => {
            subAtiva = b.dataset.sub;
            el.querySelectorAll('.cmp-chipbtn').forEach((x) => x.classList.toggle('cmp-on', x === b));
            el.querySelectorAll('.cmp-sub').forEach((p) => { p.hidden = p.dataset.sub !== subAtiva; });
        }));
    }

    const api = { MIN_MATERIA, MIN_ASSUNTO, AMOSTRA_FIRME, COMUNIDADE_MIN, RUIDO, registros, agregar, parteDaAlternativa, pegadinhas, refacoes, porMateria, porAssunto, geralDoQC, faceis, dificeis, analisar, render };
    if (typeof module !== 'undefined' && module.exports) { module.exports = api; return; }
    root.CBComparativo = api;

    // ------------------------------------------------------------------ ligação com o popup
    if (typeof document === 'undefined' || typeof chrome === 'undefined' || !chrome.storage) return;
    const alvo = () => document.getElementById('questoes-comunidade-render');
    function desenhar() {
        const el = alvo();
        if (!el) return;
        chrome.storage.local.get(['cbQcEstat', 'questoesDisciplinas', 'questoesAssuntosRaw'], (r) => {
            render(el, { mapa: r.cbQcEstat, disciplinas: r.questoesDisciplinas && r.questoesDisciplinas.itens, assuntosRaw: r.questoesAssuntosRaw });
        });
    }
    let espera = null;
    const redesenhar = () => { clearTimeout(espera); espera = setTimeout(desenhar, 250); };
    desenhar();
    chrome.storage.onChanged.addListener((mud, area) => {
        if (area === 'local' && (mud.cbQcEstat || mud.questoesDisciplinas || mud.questoesAssuntosRaw)) redesenhar();
    });
})(typeof window !== 'undefined' ? window : globalThis);
