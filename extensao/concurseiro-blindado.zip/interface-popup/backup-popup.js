// Backup no popup: o ícone de download do cartão "Meta diária" (#btn-export), o botão da tela de boas-vindas e um aviso discreto no topo.
// O popup só LEVA para interface-popup/backup.html (aba avulsa): no Firefox o seletor de arquivos e o pedido
// de permissão fecham o popup, então nada disso pode acontecer aqui dentro.
// Depende de ../dados-config/backup-core.js (CBBackup), carregado antes.
(function () {
    'use strict';
    if (typeof chrome === 'undefined' || !chrome.storage || !window.CBBackup) return;
    const Core = window.CBBackup;
    const K_ESTADO = 'cbBackupEstado';
    const K_CONFIG = 'cbBackupConfig';
    const PAGINA = 'interface-popup/backup.html';
    const SNOOZE_MS = 7 * 24 * 3600 * 1000;
    const $ = (id) => document.getElementById(id);

    function abrirPagina(hash) {
        try { chrome.tabs.create({ url: chrome.runtime.getURL(PAGINA) + (hash || '') }); } catch (e) { return; }
        const folha = $('settings-modal-overlay');
        if (folha) folha.classList.remove('open');
        try { window.close(); } catch (e) { /* popup fixado pelo navegador: fica aberto */ }
    }

    function quando(ts) {
        const d = new Date(ts);
        const hora = d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
        const hoje = new Date();
        if (d.toDateString() === hoje.toDateString()) return 'hoje às ' + hora;
        if (d.toDateString() === new Date(hoje.getTime() - 864e5).toDateString()) return 'ontem às ' + hora;
        return d.toLocaleDateString('pt-BR') + ' às ' + hora;
    }

    // Botões: o ícone de download do cartão "Meta diária" (#btn-export, que antes exportava um .CSV) e a tela de boas-vindas
    const btnMeta = $('btn-export');
    if (btnMeta) btnMeta.addEventListener('click', () => abrirPagina(''));
    const btnOnb = $('cb-onboarding-restaurar');
    if (btnOnb) btnOnb.addEventListener('click', () => abrirPagina('#restaurar'));

    // Poucas chaves pequenas bastam para saber se há dados: ler o storage inteiro abriria os desenhos do Planalto (PNG) a cada abertura do popup.
    const CHAVES = ['studyHistory', 'totalStudyMs', 'cbArtigosRevisao', 'cbArtigosPendentes', 'cbCadernoErros', 'cbPostits', 'cbSimulados',
        'cbEstudosRegistro', 'cronogramaConfig', 'questoesDailyHistory', 'cbOnboardingPendente', K_ESTADO, K_CONFIG];

    chrome.storage.local.get(CHAVES, (r) => {
        r = r || {};
        const estado = (r[K_ESTADO] && typeof r[K_ESTADO] === 'object') ? r[K_ESTADO] : {};
        const cfg = Core.normalizarConfig(r[K_CONFIG]);
        const agora = Date.now();
        const sit = Core.situacao(cfg, estado, agora);

        const semDados = Core.ehDadosVazios(r, {});

        // dica do botão (passar o mouse) e pontinho de alerta quando falta backup, está atrasado ou falhou
        if (btnMeta) {
            let dica = 'Backup dos dados: você ainda não fez nenhum.';
            if (sit.nivel === 'ok' || sit.nivel === 'antigo') dica = 'Backup dos dados · último: ' + quando(estado.ultimo.em) + (cfg.auto ? ' · automático ligado' : ' · automático desligado');
            else if (sit.nivel === 'erro') dica = 'Backup dos dados: o último não foi concluído. Toque para ver o motivo.';
            btnMeta.title = dica;
            btnMeta.setAttribute('aria-label', dica);
            if (!semDados && sit.nivel !== 'ok') btnMeta.setAttribute('data-backup-alerta', sit.nivel);
            else btnMeta.removeAttribute('data-backup-alerta');
        }

        // aviso no topo
        const banner = $('cb-backup-banner');
        if (!banner || r.cbOnboardingPendente) return; // na primeira abertura a tela de boas-vindas já oferece a restauração
        const snooze = estado.bannerDispensadoEm && (agora - estado.bannerDispensadoEm) < SNOOZE_MS;
        let tipo = null;
        if (semDados && !estado.ultimo) { if (!estado.restaurarDispensado) tipo = 'restaurar'; }
        else if (!semDados && sit.nivel !== 'ok' && !snooze) tipo = sit.nivel;
        if (!tipo) return;

        const titulo = $('cb-backup-banner-titulo'), texto = $('cb-backup-banner-texto'), acao = $('cb-backup-banner-acao');
        let hash = '';
        if (tipo === 'restaurar') {
            titulo.textContent = 'Reinstalou a extensão?';
            texto.textContent = 'Se você tem um arquivo de backup, traga de volta seus grifos e comentários do Planalto, os artigos que errou, o histórico de estudo e o cronograma.';
            acao.textContent = 'Restaurar de um backup';
            hash = '#restaurar';
        } else if (tipo === 'antigo') {
            titulo.textContent = 'Seu backup está atrasado';
            texto.textContent = 'O último foi há ' + sit.diasDesde + ' dias. Abra a tela de backup e salve um novo antes que algo se perca.';
            acao.textContent = 'Abrir backup';
        } else if (tipo === 'erro') {
            titulo.textContent = 'O backup não foi concluído';
            texto.textContent = 'Abra a tela de backup para ver o motivo e tentar de novo.';
            acao.textContent = 'Abrir backup';
        } else {
            titulo.textContent = 'Proteja seus dados com um backup';
            texto.textContent = 'Seus grifos, comentários, artigos errados e histórico somem se você desinstalar a extensão. Em 1 minuto dá para ligar o backup automático.';
            acao.textContent = 'Ativar backup';
        }
        banner.style.display = 'block';
        acao.addEventListener('click', () => abrirPagina(hash));
        $('cb-backup-banner-fechar').addEventListener('click', () => {
            banner.style.display = 'none';
            chrome.storage.local.get([K_ESTADO], (x) => {
                const e2 = (x && x[K_ESTADO] && typeof x[K_ESTADO] === 'object') ? x[K_ESTADO] : {};
                if (tipo === 'restaurar') e2.restaurarDispensado = true; else e2.bannerDispensadoEm = Date.now();
                chrome.storage.local.set({ [K_ESTADO]: e2 });
            });
        });
    });
})();
