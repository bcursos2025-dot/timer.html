// =====================================================================
// MODAL "CRONÔMETRO NO CELULAR" — abrir/fechar, copiar link, e gerar
// o código de pareamento (que chama a função pronta em firebase-sync.js,
// rodando no background/service worker).
// =====================================================================

document.addEventListener('DOMContentLoaded', () => {

    // ---- Abrir/fechar o modal (mesmo padrão usado pelo modal do Telegram) ----
    const btnOpenCelular = document.getElementById('btn-open-celular');
    const celularModalOverlay = document.getElementById('celular-modal-overlay');
    const celularModalClose = document.getElementById('celular-modal-close');

    // ---- QR Code do link do cronômetro (gerado localmente, sem depender de internet) ----
    const qrBox = document.getElementById('celular-qrcode-box');
    function cbGerarQrCodeCelular() {
        if (!qrBox || typeof qrcode !== 'function') return;
        const link = document.getElementById('celular-link-texto')?.value;
        if (!link) return;
        try {
            // Tipo 0 = a lib escolhe automaticamente o menor tamanho que
            // comporta o texto; 'M' é o nível de correção de erro padrão.
            const qr = qrcode(0, 'M');
            qr.addData(link);
            qr.make();
            qrBox.innerHTML = qr.createSvgTag({ cellSize: 4, margin: 2 });
        } catch (e) {
            qrBox.innerHTML = '';
        }
    }

    if (btnOpenCelular && celularModalOverlay) {
        btnOpenCelular.addEventListener('click', () => {
            celularModalOverlay.classList.add('open');
            cbGerarQrCodeCelular();
        });
        celularModalClose?.addEventListener('click', () => celularModalOverlay.classList.remove('open'));
        celularModalOverlay.addEventListener('click', (e) => {
            if (e.target === celularModalOverlay) celularModalOverlay.classList.remove('open');
        });
    }

    // ---- Copiar link do cronômetro ----
    const btnCopiarLink = document.getElementById('btn-copiar-link-celular');
    const inputLink = document.getElementById('celular-link-texto');
    if (btnCopiarLink && inputLink) {
        btnCopiarLink.addEventListener('click', async () => {
            try {
                await navigator.clipboard.writeText(inputLink.value);
                const textoOriginal = btnCopiarLink.textContent;
                btnCopiarLink.textContent = 'Link copiado!';
                setTimeout(() => { btnCopiarLink.textContent = textoOriginal; }, 1800);
            } catch (e) {
                // Fallback caso a API de clipboard esteja bloqueada no contexto do popup.
                inputLink.select();
                document.execCommand('copy');
            }
        });
    }

    // ---- Gerar código de pareamento ----
    const btnParear = document.getElementById('btn-parear-celular');
    const boxCodigo = document.getElementById('pareamento-codigo-box');
    const elCodigo = document.getElementById('pareamento-codigo-texto');
    const elTimer = document.getElementById('pareamento-codigo-timer');

    if (!btnParear) return; // segurança, caso o HTML mude

    let intervaloCountdown = null;

    btnParear.addEventListener('click', () => {
        btnParear.disabled = true;
        btnParear.textContent = 'Gerando...';

        chrome.runtime.sendMessage({ action: 'cbGerarCodigoPareamento' }, (resp) => {
            btnParear.disabled = false;
            btnParear.textContent = 'Gerar novo código';

            if (chrome.runtime.lastError) {
                console.error('Erro ao falar com a extensão:', chrome.runtime.lastError.message);
                alert('A extensão precisa ser recarregada (chrome://extensions → ícone de recarregar) antes de usar essa função pela primeira vez.');
                return;
            }

            if (!resp || !resp.codigo) {
                alert('Não foi possível gerar o código. Verifique sua internet e tente de novo.');
                return;
            }

            elCodigo.textContent = resp.codigo;
            boxCodigo.style.display = 'block';

            // Contagem regressiva visual de 10 minutos (o código em si
            // expira de verdade só se você implementar a checagem de
            // "criadoEm" no timer.html/regra do banco — isso aqui é
            // só pra deixar claro pro usuário que não é permanente).
            clearInterval(intervaloCountdown);
            let segundosRestantes = 10 * 60;
            elTimer.textContent = '10:00';

            intervaloCountdown = setInterval(() => {
                segundosRestantes--;
                if (segundosRestantes <= 0) {
                    clearInterval(intervaloCountdown);
                    boxCodigo.style.display = 'none';
                    return;
                }
                const m = String(Math.floor(segundosRestantes / 60)).padStart(2, '0');
                const s = String(segundosRestantes % 60).padStart(2, '0');
                elTimer.textContent = `${m}:${s}`;
            }, 1000);
        });
    });
});
