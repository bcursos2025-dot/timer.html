// Configurações → Modo anti-procrastinação: o interruptor liga/desliga o modo (dados-config/anti-procrastinacao.js).
// chrome.storage.local.cbAntiProcrastinacao: ligado quando a chave não existe (padrão); só "false" desliga.
// O aviso DENTRO das páginas precisa da permissão opcional de "todos os sites" (a mesma do cronômetro flutuante).
// Pedir essa permissão exige um clique da pessoa, por isso o botão "Permitir" aparece enquanto ela faltar.
// Também mostra o diagnóstico que o service worker grava a cada checagem (cbAntiProcDiag) e tem o botão de teste.
(function () {
    'use strict';
    const chk = document.getElementById('chk-antiproc');
    if (!chk || !window.chrome || !chrome.storage) return;
    const aviso = document.getElementById('antiproc-perm');
    const botao = document.getElementById('antiproc-permitir');
    const diag = document.getElementById('antiproc-diag');
    const testar = document.getElementById('antiproc-testar');

    function conferirPermissao() {
        if (!chrome.permissions || !aviso || !botao) return;
        chrome.permissions.contains({ origins: ['<all_urls>'] }, (tem) => {
            const falta = !tem && chk.checked;
            aviso.hidden = !falta;
            botao.hidden = !falta;
        });
    }

    // ---- diagnóstico: por que o aviso aparece (ou não) ----
    function textoDoDiagnostico(d) {
        if (!d) return 'Estado da checagem: o modo ainda não fez nenhuma checagem. Se isso não mudar em alguns segundos, o serviço da extensão não está rodando: recarregue a extensão.';
        const ha = Math.max(0, Math.round((Date.now() - d.ts) / 1000));
        if (d.erro) return `Estado da checagem (há ${ha} s): ERRO — ${d.erro}`;
        const partes = [];
        if (!d.ligado) partes.push('o modo está desligado');
        if (d.estudando) partes.push('o cronômetro está rodando (o modo só atua com ele parado)');
        if (d.semFoco) partes.push('não há janela ou aba ativa do navegador');
        if (!d.host) partes.push('a aba ativa não é um site comum');
        else if (!d.distracao) partes.push(`${d.host} não está na lista de sites de distração`);
        else if (d.liberado) partes.push(`${d.host} está liberado por 5 minutos (você clicou em “Preciso deste site agora”)`);
        const status = d.acao === 'avisar' ? 'aviso disparado'
            : d.fim ? 'aviso em andamento'
                : d.desde ? `contando: ${Math.round((Date.now() - d.desde) / 1000)} s de 10` : 'sem contagem';
        return `Estado da checagem (há ${ha} s): ${d.host || 'sem site'} — ${partes.length ? 'não atua porque ' + partes.join('; ') : status}.`;
    }
    function atualizarDiagnostico() {
        if (!diag) return;
        chrome.storage.local.get(['cbAntiProcDiag'], (r) => { diag.textContent = textoDoDiagnostico(r && r.cbAntiProcDiag); });
    }

    chrome.storage.local.get(['cbAntiProcrastinacao'], (r) => {
        chk.checked = !(r && r.cbAntiProcrastinacao === false);
        conferirPermissao();
    });
    chk.addEventListener('change', () => {
        chrome.storage.local.set({ cbAntiProcrastinacao: chk.checked });
        conferirPermissao();
    });
    if (botao) {
        botao.addEventListener('click', () => {
            chrome.permissions.request({ origins: ['<all_urls>'] }, () => conferirPermissao());
        });
    }
    if (testar) {
        testar.addEventListener('click', () => {
            testar.disabled = true;
            chrome.runtime.sendMessage({ action: 'cbAntiProcTeste' }, (resp) => {
                void chrome.runtime.lastError;
                testar.disabled = false;
                if (diag && resp && resp.ok === false) diag.textContent = 'Teste: ' + resp.motivo;
            });
        });
    }
    atualizarDiagnostico();
    setInterval(atualizarDiagnostico, 2000);
})();
