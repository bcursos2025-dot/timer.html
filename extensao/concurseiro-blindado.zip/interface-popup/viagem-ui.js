// ===================== TELA "VIAGEM ATÉ A PROVA" =====================
// Lógica pura em dados-config/viagem-prova.js (CBViagem). Aqui só a folha: campos, botão Calcular, cartões de
// custo (carro, ônibus, avião) que se refazem a cada número digitado, sem nova consulta de rede.
// O que a pessoa digitou fica salvo em chrome.storage.local.cbViagemProva.
(function () {
    'use strict';
    const V = window.CBViagem;
    const abrir = document.getElementById('hn-btn-viagem');
    const overlay = document.getElementById('viagem-modal-overlay');
    const fechar = document.getElementById('viagem-modal-close');
    if (!V || !abrir || !overlay) return;

    const $ = (id) => document.getElementById(id);
    const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const CAMPOS = ['origem', 'destino', 'consumoKmL', 'precoLitro', 'pedagio', 'estacionamento', 'pessoasCarro',
        'onibusTarifa', 'aviaoIda', 'aviaoVolta', 'translados', 'hospedagem', 'alimentacao'];

    let achados = { origem: [], destino: [] };   // resultados do Nominatim (a pessoa pode trocar)
    let escolha = { origem: 0, destino: 0 };
    let rota = null;                             // { km, minutos, aproximada }

    function lerCampos() {
        const c = {};
        CAMPOS.forEach((k) => { const el = $('vg-' + k); c[k] = el ? el.value.trim() : ''; });
        c.idaEVolta = $('vg-idaEVolta').checked;
        return c;
    }
    function guardar() {
        const c = lerCampos();
        chrome.storage.local.set({ cbViagemProva: c });
    }
    function restaurar(c) {
        if (!c) return;
        CAMPOS.forEach((k) => { const el = $('vg-' + k); if (el && c[k] != null) el.value = c[k]; });
        if (c.idaEVolta === false) $('vg-idaEVolta').checked = false;
    }

    function ponto(qual) { return achados[qual][escolha[qual]]; }

    function desenharSeletores() {
        ['origem', 'destino'].forEach((q) => {
            const alvo = $('vg-sel-' + q);
            const lista = achados[q];
            if (!lista.length) { alvo.innerHTML = ''; return; }
            alvo.innerHTML = lista.length > 1
                ? `<label>Encontrei vários lugares, confirme:<select data-q="${q}">${lista.map((l, i) => `<option value="${i}"${i === escolha[q] ? ' selected' : ''}>${esc(l.nome)}</option>`).join('')}</select></label>`
                : `<span class="vg-achado">${esc(lista[0].nome)}</span>`;
        });
    }

    function linhaCusto(o, melhor) {
        const d = o.detalhe;
        let obs = '';
        if (o.meio === 'carro') obs = `${V.km1(rota.km * d.trechos)} · ${d.litros.toLocaleString('pt-BR', { maximumFractionDigits: 1 })} L de combustível (${V.brl(d.combustivel)})${d.pedagio ? ' + pedágio ' + V.brl(d.pedagio) : ''}${d.estacionamento ? ' + estacionamento ' + V.brl(d.estacionamento) : ''}${d.pessoas > 1 ? ` · dividido por ${d.pessoas} pessoas` : ''}`;
        if (o.meio === 'onibus') obs = d.estimado ? `Estimativa de ${V.brl(d.porTrecho)} por trecho (R$ 0,30 por km). Digite o valor da passagem para ficar exato.` : `${V.brl(d.porTrecho)} por trecho${d.translados ? ' + ligações ' + V.brl(d.translados) : ''}`;
        if (o.meio === 'aviao') obs = `Passagens ${V.brl(d.passagens)}${d.translados ? ' + ligações ' + V.brl(d.translados) : ''}`;
        return `<div class="vg-custo${melhor ? ' vg-melhor' : ''}"><div class="vg-custo-topo"><b>${o.nome}</b>${melhor ? '<span class="vg-selo">mais barato</span>' : ''}<span class="vg-total">${V.brl(o.total)}</span></div><p>${esc(obs)}</p></div>`;
    }

    function desenharResultado() {
        const caixa = $('vg-resultado');
        if (!rota) { caixa.hidden = true; return; }
        caixa.hidden = false;
        const cfg = lerCampos();
        const cmp = V.comparar(rota.km, cfg);
        const origemTxt = cfg.origem, destinoTxt = cfg.destino;
        const l = V.links(origemTxt, destinoTxt);
        $('vg-resumo').innerHTML = `<div class="vg-km">${V.km1(rota.km)}</div><div class="vg-tempo">${V.duracao(rota.minutos)} de carro${rota.aproximada ? ' · <b>aproximado</b> (os mapas não responderam; é a linha reta com um fator de curva)' : ''}</div>`;
        $('vg-custos').innerHTML = cmp.opcoes.map((o) => linhaCusto(o, o.meio === cmp.maisBarato)).join('')
            + (cmp.opcoes.some((o) => o.meio === 'aviao') ? '' : '<p class="vg-nota">Avião: digite o valor das passagens acima para comparar. Não há como estimar o preço sem consultar as companhias.</p>')
            + (cmp.extras ? `<p class="vg-nota">Hospedagem e alimentação (${V.brl(cmp.extras)}) já estão somadas nas três opções.</p>` : '');
        $('vg-links').innerHTML = `<a href="${esc(l.rota)}" target="_blank" rel="noopener noreferrer">Ver rota no Google Maps</a><a href="${esc(l.onibus)}" target="_blank" rel="noopener noreferrer">Buscar ônibus</a><a href="${esc(l.aviao)}" target="_blank" rel="noopener noreferrer">Buscar voos</a>`;
    }

    async function calcular() {
        const cfg = lerCampos();
        const status = $('vg-status');
        if (!cfg.origem || !cfg.destino) { status.textContent = 'Digite de onde você sai e onde é a prova.'; return; }
        const botao = $('vg-calcular');
        botao.disabled = true;
        status.textContent = 'Procurando os lugares…';
        try {
            const origem = await V.localizar(cfg.origem);
            await new Promise((r) => setTimeout(r, 1100));        // regra do Nominatim: no máximo 1 consulta por segundo
            const destino = await V.localizar(cfg.destino);
            achados = { origem, destino };
            escolha = { origem: 0, destino: 0 };
            await recalcularRota();
        } catch (e) {
            status.textContent = (e && e.message) || 'Não consegui consultar o mapa agora. Tente de novo em instantes.';
            rota = null; desenharResultado();
        }
        botao.disabled = false;
        guardar();
    }
    async function recalcularRota() {
        $('vg-status').textContent = 'Calculando a rota…';
        rota = await V.rota(ponto('origem'), ponto('destino'));
        $('vg-status').textContent = '';
        desenharSeletores();
        desenharResultado();
    }

    abrir.addEventListener('click', () => {
        overlay.classList.add('open');
        chrome.storage.local.get(['cbViagemProva'], (r) => restaurar(r && r.cbViagemProva));
    });
    fechar.addEventListener('click', () => overlay.classList.remove('open'));
    overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.classList.remove('open'); });
    $('vg-calcular').addEventListener('click', calcular);
    ['vg-origem', 'vg-destino'].forEach((id) => $(id).addEventListener('keydown', (e) => { if (e.key === 'Enter') calcular(); }));
    overlay.addEventListener('input', (e) => {
        if (e.target.id && e.target.id.startsWith('vg-') && !/^vg-(origem|destino)$/.test(e.target.id)) { desenharResultado(); guardar(); }
    });
    overlay.addEventListener('change', (e) => {
        if (e.target.id === 'vg-idaEVolta') { desenharResultado(); guardar(); return; }
        const sel = e.target.closest('select[data-q]');
        if (sel) { escolha[sel.dataset.q] = Number(sel.value); recalcularRota().catch(() => {}); }
    });
})();
