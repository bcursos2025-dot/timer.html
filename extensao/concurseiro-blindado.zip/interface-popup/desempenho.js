// Modo de desempenho do popup: "Automático" | "Leve" | "Completo".
//
// Roda no <head>, antes da primeira pintura (arquivo à parte: a CSP do
// Manifest V3 bloqueia <script> inline). Só decide uma classe em <html>
// ('cb-lite'); quem corta animação, blur e vídeo por trás dela é o
// desempenho.css. Nunca mexe no cronômetro.
//
// Automático liga o modo leve no Firefox (backdrop-filter e blur animado
// custam bem mais lá) e em PCs com 4 núcleos ou menos / 4 GB ou menos.
(function () {
    var CHAVE = 'cbModoDesempenho';

    function ehPcFraco() {
        var ua = navigator.userAgent || '';
        if (/Firefox\//.test(ua)) return true;
        if (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4) return true;
        if (navigator.deviceMemory && navigator.deviceMemory <= 4) return true;
        try { if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return true; } catch (e) { /* sem matchMedia */ }
        return false;
    }

    function aplicar(modo) {
        var leve = modo === 'leve' || (modo !== 'completo' && ehPcFraco());
        document.documentElement.classList.toggle('cb-lite', leve);
    }

    function lerLocal() {
        try { return localStorage.getItem(CHAVE) || 'auto'; } catch (e) { return 'auto'; }
    }

    aplicar(lerLocal());

    // Reconcilia com o chrome.storage (fonte da verdade entre perfis).
    try {
        chrome.storage.local.get([CHAVE], function (r) {
            var modo = (r && r[CHAVE]) || 'auto';
            try { localStorage.setItem(CHAVE, modo); } catch (e) {}
            aplicar(modo);
        });
    } catch (e) { /* sem storage: fica com o cache local */ }

    window.cbDesempenho = {
        modo: lerLocal,
        definir: function (modo) {
            try { localStorage.setItem(CHAVE, modo); } catch (e) {}
            try { chrome.storage.local.set({ [CHAVE]: modo }); } catch (e) {}
            aplicar(modo);
        },
        leve: function () { return document.documentElement.classList.contains('cb-lite'); }
    };

    // Carrega um script só quando precisa (xlsx e pdf.js pesam ~1,2 MB e eram
    // lidos a cada abertura do popup). Devolve a mesma Promise para pedidos repetidos.
    document.addEventListener('DOMContentLoaded', function () {
        var botoes = document.querySelectorAll('#desempenho-row [data-desemp]');
        function marcar() {
            var atual = lerLocal();
            botoes.forEach(function (b) { b.classList.toggle('active', b.dataset.desemp === atual); });
        }
        botoes.forEach(function (b) {
            b.addEventListener('click', function () { window.cbDesempenho.definir(b.dataset.desemp); marcar(); });
        });
        marcar();
    });

    // Liga 'cb-folha-aberta' em <html> enquanto houver uma folha aberta (ver desempenho.css).
    document.addEventListener('DOMContentLoaded', function () {
        var folhas = document.querySelectorAll('.modal-overlay');
        function checar() {
            var aberta = false;
            for (var i = 0; i < folhas.length; i++) { if (folhas[i].classList.contains('open')) { aberta = true; break; } }
            document.documentElement.classList.toggle('cb-folha-aberta', aberta);
        }
        var obs = new MutationObserver(checar);
        folhas.forEach(function (f) { obs.observe(f, { attributes: true, attributeFilter: ['class'] }); });
        checar();
    });

    var carregados = {};
    window.cbCarregarScript = function (src) {
        if (carregados[src]) return carregados[src];
        carregados[src] = new Promise(function (ok, erro) {
            var s = document.createElement('script');
            s.src = src;
            s.onload = function () { ok(); };
            s.onerror = function () { delete carregados[src]; erro(new Error('Falha ao carregar ' + src)); };
            document.head.appendChild(s);
        });
        return carregados[src];
    };
})();
