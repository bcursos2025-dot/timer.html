// ===================== BOTÃO "DESCER" (ilha translúcida) =====================
//
// Uma bolinha de vidro com a seta para baixo, no meio da parte de baixo de qualquer área que rola. Aparece só
// quando a área rola: seta para baixo enquanto falta conteúdo (um clique desce quase uma tela, suave) e, ao
// chegar no fim, vira seta para CIMA e leva de volta ao topo.
// Vale para: folhas (.ap-sheet-body, como Configurações), modais com rolagem (.modal-body), a conversa do chat
// (.ia-chat-mensagens) e a própria janela do popup. Visual em apple.css, bloco "BOTÃO DESCER".
//
// Como não atrapalha: cada área recebe, como último filho, um suporte "sticky" de altura ZERO (o botão fica
// preso na base visível da área, sem ocupar espaço). Se o app limpar a área (innerHTML = ''), um observador
// recoloca o suporte. Respeita prefers-reduced-motion (rola sem animação).
(function () {
    'use strict';

    const SELETORES = ['.ap-sheet-body', '.modal-body', '.ia-chat-mensagens'];
    const MARGEM = 56;                       // só mostra se faltar mais que isso para o fim
    const SVG = (d) => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="' + d + '"/></svg>';
    const SETA_BAIXO = SVG('m6 9 6 6 6-6');
    const SETA_CIMA = SVG('m18 15-6-6-6 6');
    const reduzir = () => window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    function criarBotao(rotulo) {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'cb-descer';
        b.setAttribute('aria-label', rotulo || 'Descer');
        b.title = rotulo || 'Descer';
        b.innerHTML = SETA_BAIXO;
        return b;
    }

    // Mostra a seta certa: para baixo enquanto falta rolar, para cima (voltar ao topo) quando chegou no fim.
    function definir(botao, direcao) {
        if (direcao === 'fora') { botao.classList.remove('cb-descer-ver'); return; }
        if (botao.dataset.dir !== direcao) {
            botao.dataset.dir = direcao;
            botao.innerHTML = direcao === 'cima' ? SETA_CIMA : SETA_BAIXO;
            const t = direcao === 'cima' ? 'Voltar ao topo' : 'Descer';
            botao.title = t; botao.setAttribute('aria-label', t);
        }
        botao.classList.add('cb-descer-ver');
    }

    // ---- áreas com rolagem própria ----
    function ligarArea(area) {
        if (area.__cbDescer) return;
        area.__cbDescer = true;

        const suporte = document.createElement('div');
        suporte.className = 'cb-descer-suporte';
        const botao = criarBotao('Descer');
        suporte.appendChild(botao);
        area.appendChild(suporte);

        const atualizar = () => {
            const falta = area.scrollHeight - area.scrollTop - area.clientHeight;
            const rola = area.scrollHeight > area.clientHeight + MARGEM && area.clientHeight > 0;
            definir(botao, !rola ? 'fora' : (falta > MARGEM ? 'baixo' : 'cima'));
        };
        botao.addEventListener('click', (e) => {
            e.stopPropagation();
            const comportamento = reduzir() ? 'auto' : 'smooth';
            if (botao.dataset.dir === 'cima') area.scrollTo({ top: 0, behavior: comportamento });
            else area.scrollBy({ top: Math.max(120, area.clientHeight * 0.8), behavior: comportamento });
        });
        area.addEventListener('scroll', atualizar, { passive: true });
        window.addEventListener('resize', atualizar);

        // conteúdo que muda (acordeão abre, mensagem nova, lista carrega) e o suporte apagado por um innerHTML
        let agendado = false;
        new MutationObserver(() => {
            if (suporte.parentNode !== area) area.appendChild(suporte);
            else if (suporte !== area.lastElementChild) area.appendChild(suporte);
            if (agendado) return;
            agendado = true;
            requestAnimationFrame(() => { agendado = false; atualizar(); });
        }).observe(area, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'hidden', 'style'] });
        // a folha abre/fecha por classe no overlay: reavalia quando algo na página muda de tamanho
        if (window.ResizeObserver) new ResizeObserver(atualizar).observe(area);
        setTimeout(atualizar, 300);
    }

    // ---- a janela do popup ----
    function ligarJanela() {
        const botao = criarBotao('Descer');
        botao.classList.add('cb-descer-janela');
        document.body.appendChild(botao);
        const raiz = () => document.scrollingElement || document.documentElement;
        const atualizar = () => {
            const r = raiz();
            const falta = r.scrollHeight - r.scrollTop - r.clientHeight;
            // não aparece por cima de uma folha aberta (ela tem o próprio botão)
            const folhaAberta = !!document.querySelector('.modal-overlay.open');
            const rola = r.scrollHeight > r.clientHeight + MARGEM * 2;
            definir(botao, (!rola || folhaAberta) ? 'fora' : (falta > MARGEM * 2 ? 'baixo' : 'cima'));
        };
        botao.addEventListener('click', () => {
            const r = raiz();
            const comportamento = reduzir() ? 'auto' : 'smooth';
            if (botao.dataset.dir === 'cima') window.scrollTo({ top: 0, behavior: comportamento });
            else window.scrollBy({ top: Math.max(160, r.clientHeight * 0.8), behavior: comportamento });
        });
        window.addEventListener('scroll', atualizar, { passive: true });
        window.addEventListener('resize', atualizar);
        // Uma leitura de layout por quadro, não uma por mutação: antes cada mudança de classe na página agendava a sua,
        // e ler scrollHeight/clientHeight força o navegador a recalcular o layout (era o que deixava os cliques lentos).
        let janelaAgendada = false;
        new MutationObserver(() => {
            if (janelaAgendada) return;
            janelaAgendada = true;
            requestAnimationFrame(() => { janelaAgendada = false; atualizar(); });
        }).observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'hidden'] });
        setInterval(atualizar, 4000); // abas que trocam de altura sem mexer no DOM observado
        atualizar();
    }

    function varrer() {
        document.querySelectorAll(SELETORES.join(',')).forEach(ligarArea);
    }

    function iniciar() {
        varrer();
        ligarJanela();
        // folhas criadas depois (alguns modais são montados sob demanda)
        new MutationObserver(varrer).observe(document.body, { childList: true, subtree: true });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar);
    else iniciar();
})();
