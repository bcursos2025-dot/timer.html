// ===================== IMPORTAR PDF DE LEI (extração local com pdf.js) =====================
//
// A extensão NUNCA lê arquivo nenhum do disco sozinha — só processa o PDF que
// a pessoa escolhe manualmente no seletor de arquivo abaixo. Tudo roda dentro
// do próprio navegador (pdf.js embutido na extensão); o PDF não é enviado a
// nenhum servidor. O texto extraído é dividido em trechos (por artigo, quando
// dá pra reconhecer o padrão "Art. N") e salvo via
// dados-config/ia-legislacao.js (cbSalvarLei), que o chat usa depois pra
// buscar o trecho certo em vez da IA inventar.

(function () {
    const btnAbrirGerenciar = document.getElementById('ia-chat-abrir-leis');
    const overlay = document.getElementById('ia-leis-modal-overlay');
    const btnFechar = document.getElementById('ia-leis-modal-close');
    const elLista = document.getElementById('ia-leis-lista');
    const btnImportar = document.getElementById('ia-leis-importar-btn');
    const inputArquivo = document.getElementById('ia-leis-input-arquivo');
    const elStatus = document.getElementById('ia-leis-status');
    if (!overlay || !btnAbrirGerenciar) return;

    // pdf.js (320 KB + worker de 1 MB) só é carregado na primeira extração
    async function garantirPdfJs() {
        if (!window.pdfjsLib) await window.cbCarregarScript('../dados-config/lib/pdfjs/pdf.min.js');
        window.pdfjsLib.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('dados-config/lib/pdfjs/pdf.worker.min.js');
    }

    function abrirModal() {
        overlay.classList.add('open');
        renderLista();
    }
    function fecharModal() {
        overlay.classList.remove('open');
    }

    function formatarData(ts) {
        try { return new Date(ts).toLocaleDateString('pt-BR'); } catch (e) { return ''; }
    }

    async function renderLista() {
        const leis = await window.cbListarLeis();
        elLista.innerHTML = '';
        if (!leis.length) {
            elLista.innerHTML = '<p class="ia-leis-vazio">Nenhuma lei importada ainda. Importe um PDF abaixo — a IA vai citar os artigos de verdade dele nas respostas.</p>';
            return;
        }
        leis.forEach((lei) => {
            const item = document.createElement('div');
            item.className = 'ia-leis-item';
            item.innerHTML = `
                <div class="ia-leis-item-info">
                    <b>${lei.nome}</b>
                    <small>${lei.totalChunks} trechos · importado em ${formatarData(lei.importadoEm)}</small>
                </div>
            `;
            const btnRemover = document.createElement('button');
            btnRemover.type = 'button';
            btnRemover.className = 'ia-leis-item-remover';
            btnRemover.title = 'Remover';
            btnRemover.textContent = '✕';
            btnRemover.addEventListener('click', async () => {
                btnRemover.disabled = true;
                await window.cbRemoverLei(lei.id);
                renderLista();
            });
            item.appendChild(btnRemover);
            elLista.appendChild(item);
        });
    }

    async function extrairTextoPDF(arrayBuffer) {
        await garantirPdfJs();
        const pdf = await window.pdfjsLib.getDocument({ data: arrayBuffer }).promise;
        let textoCompleto = '';
        for (let i = 1; i <= pdf.numPages; i++) {
            const page = await pdf.getPage(i);
            const content = await page.getTextContent();
            textoCompleto += content.items.map((it) => it.str).join(' ') + '\n';
            if (i % 20 === 0) elStatus.textContent = `Lendo página ${i} de ${pdf.numPages}...`;
        }
        return textoCompleto;
    }

    // Tenta dividir por "Art. N" (padrão de lei brasileira). Se o PDF não
    // tiver esse padrão reconhecível, cai pra blocos de tamanho fixo.
    function dividirEmTrechos(texto) {
        const re = /Art\.?\s*\d+(?:\.\d+)?[ºª°A-Za-z\-]*\.?/g;
        const matches = [...texto.matchAll(re)];
        if (matches.length < 3) {
            const TAM = 1000;
            const blocos = [];
            for (let i = 0; i < texto.length; i += TAM) {
                const trecho = texto.slice(i, i + TAM).trim();
                if (trecho) blocos.push({ artigo: null, texto: trecho });
            }
            return blocos;
        }
        const trechos = [];
        for (let i = 0; i < matches.length; i++) {
            const inicio = matches[i].index;
            const fim = i + 1 < matches.length ? matches[i + 1].index : texto.length;
            let trecho = texto.slice(inicio, fim).trim();
            if (trecho.length > 2000) trecho = trecho.slice(0, 2000);
            if (trecho) trechos.push({ artigo: matches[i][0].trim(), texto: trecho });
        }
        return trechos;
    }

    async function importarArquivo(file) {
        if (!file || file.type !== 'application/pdf') {
            elStatus.textContent = 'Escolha um arquivo PDF.';
            return;
        }
        btnImportar.disabled = true;
        elStatus.textContent = 'Lendo o PDF...';
        try {
            const buffer = await file.arrayBuffer();
            const texto = await extrairTextoPDF(buffer);
            elStatus.textContent = 'Dividindo em artigos...';
            const trechos = dividirEmTrechos(texto);
            if (!trechos.length) throw new Error('Não consegui extrair texto desse PDF (pode ser um PDF escaneado/imagem).');
            await window.cbSalvarLei(file.name.replace(/\.pdf$/i, ''), trechos);
            elStatus.textContent = `Pronto! "${file.name}" importado com ${trechos.length} trechos.`;
            renderLista();
        } catch (err) {
            elStatus.textContent = err.message || 'Não deu pra importar esse PDF.';
        } finally {
            btnImportar.disabled = false;
            inputArquivo.value = '';
        }
    }

    btnAbrirGerenciar.addEventListener('click', abrirModal);
    btnFechar.addEventListener('click', fecharModal);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) fecharModal(); });
    btnImportar.addEventListener('click', () => inputArquivo.click());
    inputArquivo.addEventListener('change', () => importarArquivo(inputArquivo.files[0]));
})();
