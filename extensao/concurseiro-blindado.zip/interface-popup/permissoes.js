// Página "Permissões": duas telas (como liberar o acesso aos sites no Firefox / por que tantas permissões).
// A extensão não consegue abrir o about:addons sozinha, então o passo a passo é feito pela própria pessoa.
(function () {
    // Segue o tema escolhido no popup ("auto" = Claro de dia, Escuro das 18h às 6h).
    function resolver(pref) {
        if (pref === 'auto') { const h = new Date().getHours(); return (h >= 18 || h < 6) ? 'dark' : 'light'; }
        return pref || 'light';
    }
    try {
        chrome.storage.local.get(['themePref'], (r) => {
            document.documentElement.setAttribute('data-theme', resolver(r && r.themePref));
        });
    } catch (e) { /* sem storage: fica no tema padrão */ }

    const abas = { liberar: document.getElementById('aba-liberar'), porque: document.getElementById('aba-porque') };
    const telas = { liberar: document.getElementById('tela-liberar'), porque: document.getElementById('tela-porque') };

    function mostrar(qual) {
        Object.keys(abas).forEach((k) => {
            abas[k].setAttribute('aria-selected', String(k === qual));
            telas[k].hidden = k !== qual;
        });
        try { history.replaceState(null, '', qual === 'porque' ? '#porque' : location.pathname); } catch (e) { /* sem histórico */ }
        window.scrollTo(0, 0);
    }
    abas.liberar.addEventListener('click', () => mostrar('liberar'));
    abas.porque.addEventListener('click', () => mostrar('porque'));
    document.getElementById('pr-ir-porque').addEventListener('click', () => mostrar('porque'));
    document.getElementById('pr-ir-liberar').addEventListener('click', () => mostrar('liberar'));
    mostrar(location.hash === '#porque' ? 'porque' : 'liberar');
    window.addEventListener('hashchange', () => mostrar(location.hash === '#porque' ? 'porque' : 'liberar'));

    const btnCopiar = document.getElementById('pr-copiar');
    btnCopiar.addEventListener('click', async () => {
        try { await navigator.clipboard.writeText('about:addons'); } catch (e) {
            const t = document.createElement('textarea');
            t.value = 'about:addons';
            document.body.appendChild(t);
            t.select();
            try { document.execCommand('copy'); } catch (e2) { /* sem cópia: o endereço está escrito na tela */ }
            t.remove();
        }
        btnCopiar.textContent = 'Copiado ✓';
        setTimeout(() => { btnCopiar.textContent = 'Copiar about:addons'; }, 2000);
    });
})();
