// Página "Backup dos dados": fazer backup agora, backup automático, restaurar de um arquivo e explicar o que entra.
// Vive numa aba (e não no popup) porque no Firefox o seletor de arquivos e o pedido de permissão fecham o popup.
// A lógica de montar/validar/mesclar está em ../dados-config/backup-core.js (com testes); a parte que fala com o
// navegador (storage, downloads, permissões) está em ../dados-config/backup-io.js.
(function () {
    'use strict';
    const Core = window.CBBackup;
    const IO = window.CBBackupIO;
    const $ = (id) => document.getElementById(id);

    // ------------------------------------------------------------------ tema
    // Segue o tema escolhido no popup ("auto" = Claro de dia, Escuro das 18h às 6h).
    function resolverTema(pref) {
        if (pref === 'auto') { const h = new Date().getHours(); return (h >= 18 || h < 6) ? 'dark' : 'light'; }
        return pref || 'light';
    }
    try {
        chrome.storage.local.get(['themePref'], (r) => {
            document.documentElement.setAttribute('data-theme', resolverTema(r && r.themePref));
        });
    } catch (e) { /* sem storage: fica no tema padrão */ }

    // ------------------------------------------------------------------ abas
    const ABAS = { backup: 'aba-backup', restaurar: 'aba-restaurar', entra: 'aba-entra' };
    const TELAS = { backup: 'tela-backup', restaurar: 'tela-restaurar', entra: 'tela-entra' };
    const HASH = { backup: '', restaurar: '#restaurar', entra: '#o-que-entra' };
    function mostrar(qual) {
        Object.keys(ABAS).forEach((k) => {
            $(ABAS[k]).setAttribute('aria-selected', String(k === qual));
            $(TELAS[k]).hidden = k !== qual;
        });
        try { history.replaceState(null, '', HASH[qual] || location.pathname); } catch (e) { /* sem histórico */ }
        window.scrollTo(0, 0);
    }
    function abaDoHash() { return location.hash === '#restaurar' ? 'restaurar' : (location.hash === '#o-que-entra' ? 'entra' : 'backup'); }
    Object.keys(ABAS).forEach((k) => $(ABAS[k]).addEventListener('click', () => mostrar(k)));
    window.addEventListener('hashchange', () => mostrar(abaDoHash()));
    mostrar(abaDoHash());

    // ------------------------------------------------------------ formatação
    const pl = (n, um, varios) => (n === 1 ? um : varios);
    const num = (n) => '<b>' + Number(n || 0).toLocaleString('pt-BR') + '</b>';
    function bytesLegivel(n) {
        if (!n) return '—';
        if (n < 1024) return n + ' B';
        if (n < 1048576) return (n / 1024).toFixed(0) + ' KB';
        return (n / 1048576).toFixed(1).replace('.', ',') + ' MB';
    }
    function quando(ts) {
        const d = new Date(ts);
        const hora = d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
        const hoje = new Date();
        if (d.toDateString() === hoje.toDateString()) return 'hoje às ' + hora;
        const ontem = new Date(hoje.getTime() - 864e5);
        if (d.toDateString() === ontem.toDateString()) return 'ontem às ' + hora;
        return d.toLocaleDateString('pt-BR') + ' às ' + hora;
    }
    function ha(ts) {
        const min = Math.round((Date.now() - ts) / 60000);
        if (min < 2) return 'agora há pouco';
        if (min < 60) return 'há ' + min + ' minutos';
        const h = Math.round(min / 60);
        if (h < 24) return 'há ' + h + ' ' + pl(h, 'hora', 'horas');
        const dias = Math.round(h / 24);
        return 'há ' + dias + ' ' + pl(dias, 'dia', 'dias');
    }
    const diaBr = (iso) => (/^\d{4}-\d{2}-\d{2}$/.test(iso || '') ? iso.split('-').reverse().join('/') : '');

    /** Linhas "rótulo → texto" do que há num conjunto de dados. Só números entram no HTML. */
    function linhasResumo(r) {
        const p = r.planalto, e = r.estudo, pj = r.planejamento, ia = r.ia;
        const linhas = [];
        linhas.push(['Planalto', num(p.marcacoes) + ' ' + pl(p.marcacoes, 'marcação', 'marcações') + ' em ' + num(p.paginas) + ' ' + pl(p.paginas, 'página', 'páginas')
            + ' (' + num(p.grifos) + ' ' + pl(p.grifos, 'grifo colorido', 'grifos coloridos') + ', ' + num(p.negritos) + ' em negrito, ' + num(p.sublinhados) + ' ' + pl(p.sublinhados, 'sublinhado', 'sublinhados') + ')'
            + ' · ' + num(p.comentarios) + ' ' + pl(p.comentarios, 'comentário', 'comentários') + ' · ' + num(p.desenhos) + ' ' + pl(p.desenhos, 'desenho', 'desenhos')]);
        linhas.push(['Artigos que errei', num(p.artigosParaRevisar) + ' para revisar + ' + num(p.artigosPendentes) + ' aguardando confirmação'
            + ' (vindos de ' + num(p.questoesErradasLigadas) + ' ' + pl(p.questoesErradasLigadas, 'questão errada', 'questões erradas') + ') · ' + num(p.errosAnotados) + ' ' + pl(p.errosAnotados, 'anotação', 'anotações') + ' de erro em ' + num(p.artigosComErros) + ' ' + pl(p.artigosComErros, 'artigo', 'artigos')]);
        let est = num(e.diasDeEstudo) + ' ' + pl(e.diasDeEstudo, 'dia', 'dias') + ' de estudo (' + num(e.horasTotais) + ' h)';
        if (e.primeiroDia) est += ' · de ' + diaBr(e.primeiroDia) + ' a ' + diaBr(e.ultimoDia);
        est += ' · ' + num(e.cadernoDeErros) + ' ' + pl(e.cadernoDeErros, 'questão', 'questões') + ' no caderno de erros';
        linhas.push(['Estudo', est]);
        linhas.push(['Planejamento', num(pj.postits) + ' ' + pl(pj.postits, 'post-it', 'post-its') + ' · ' + num(pj.simulados) + ' ' + pl(pj.simulados, 'simulado', 'simulados') + ' · ' + num(pj.mapasMentais) + ' ' + pl(pj.mapasMentais, 'mapa mental', 'mapas mentais')
            + ' · cronograma ' + (pj.temCronograma ? 'sim' : 'não') + ' · edital ' + (pj.temEdital ? 'sim' : 'não')]);
        linhas.push(['Assistente de I.A.', num(ia.conversas) + ' ' + pl(ia.conversas, 'conversa', 'conversas')]);
        return linhas;
    }
    function preencherLista(ul, linhas) {
        ul.textContent = '';
        linhas.forEach(([rot, html]) => {
            const li = document.createElement('li');
            const a = document.createElement('span'); a.className = 'rot'; a.textContent = rot;
            const b = document.createElement('span'); b.className = 'val'; b.innerHTML = html; // só números e rótulos fixos
            li.appendChild(a); li.appendChild(b); ul.appendChild(li);
        });
    }
    const resumoDoQueEntra = (dados) => { const f = Core.filtrarDados(dados, { incluirLeis: true }); return Core.resumir(f.local, f.sync); };

    function mensagem(el, texto, tipo) {
        el.textContent = texto || '';
        el.className = el.className.replace(/\b(ok|erro)\b/g, '').trim() + (tipo ? ' ' + tipo : '');
    }

    // ------------------------------------------------------------ tela: backup
    let permissao = false;
    let ocupado = false;

    function ocupar(sim) {
        ocupado = sim;
        ['bk-agora', 'bk-link', 'bk-perm'].forEach((id) => { const b = $(id); if (b) b.disabled = sim; });
        ['bk-auto', 'bk-intervalo', 'bk-leis'].forEach((id) => { const b = $(id); if (b) b.disabled = sim; });
    }

    async function renderBackup() {
        const [cfg, estado, tudo] = await Promise.all([IO.lerConfig(), IO.lerEstado(), IO.lerTudo()]);
        permissao = await IO.temPermissaoDownloads();
        const agora = Date.now();
        const sit = Core.situacao(cfg, estado, agora);
        const card = $('bk-status');
        card.className = 'bk-status bk-status--' + sit.nivel;
        const ult = estado.ultimo && estado.ultimo.ok ? estado.ultimo : null;
        const tit = $('bk-status-tit'), sub = $('bk-status-sub');
        sub.textContent = '';
        const adicionar = (txt, negrito) => { const n = negrito ? document.createElement('b') : document.createTextNode(txt); if (negrito) n.textContent = txt; sub.appendChild(n); };

        if (sit.nivel === 'nunca') {
            tit.textContent = 'Você ainda não fez nenhum backup';
            adicionar('Se você desinstalar a extensão agora, perde tudo o que está listado abaixo. Clique em “Fazer backup agora”.');
        } else if (sit.nivel === 'erro') {
            tit.textContent = 'O backup não foi concluído';
            adicionar((estado.ultimaFalha && estado.ultimaFalha.erro) || 'Houve uma falha ao salvar.');
        } else {
            tit.textContent = sit.nivel === 'ok' ? 'Backup em dia' : 'Seu último backup tem ' + sit.diasDesde + ' ' + pl(sit.diasDesde, 'dia', 'dias');
            adicionar('Último backup: '); adicionar(quando(ult.em), true); adicionar(' (' + ha(ult.em) + '), ' + bytesLegivel(ult.bytes) + '.');
            if (ult.caminho) { adicionar(' Arquivo: '); adicionar(ult.caminho, true); adicionar('.'); }
            else if (ult.porLink) adicionar(' Foi enviado ao download do navegador (procure o arquivo na sua pasta de downloads).');
            if (estado.ultimaFalha && estado.ultimaFalha.em > ult.em) adicionar(' Depois disso, uma tentativa falhou: ' + estado.ultimaFalha.erro);
        }
        if (ult && ult.renomeado) {
            const av = document.createElement('div'); av.className = 'bk-alerta';
            av.textContent = 'O navegador gravou o arquivo com outro nome em vez de sobrescrever o do mesmo dia da semana. Os backups funcionam, mas arquivos antigos podem se acumular na pasta; apague os mais velhos de vez em quando.';
            sub.appendChild(av);
        }

        const atual = resumoDoQueEntra({ local: tudo.local, sync: tudo.sync });
        const vazio = Core.ehDadosVazios(tudo.local, tudo.sync);
        $('bk-lista-tit').textContent = vazio
            ? 'Esta instalação ainda não tem dados de estudo, grifos ou anotações. Reinstalou? Vá para a aba “Restaurar”.' : 'Dados que entram no próximo backup:';
        preencherLista($('bk-lista'), vazio ? [] : linhasResumo(atual));

        // automático
        $('bk-auto').checked = !!cfg.auto;
        $('bk-intervalo').value = String(cfg.intervaloH);
        $('bk-leis').checked = !!cfg.incluirLeis;
        let det = 'Desligado.';
        if (cfg.auto && !permissao) det = 'Ligado, mas parado: falta a permissão abaixo.';
        else if (cfg.auto) {
            const prox = ult ? Math.max(agora, ult.em + cfg.intervaloH * 3600000) : agora;
            det = 'Ligado. ' + (ult ? 'Próxima verificação a partir de ' + quando(prox) + ', e só se algo mudou.' : 'O primeiro backup sai em poucos minutos.');
        }
        $('bk-auto-det').textContent = det;
        $('bk-perm-linha').hidden = permissao;
        $('bk-perm-det').textContent = 'Sem ela a extensão não consegue gravar na pasta Downloads. No Firefox, o navegador abre um aviso para você aceitar.';
        $('bk-link').hidden = permissao;
        $('bk-pasta').textContent = Core.PASTA;
        $('bk-caminho-linha').hidden = !(ult && ult.caminho);
        if (ult && ult.caminho) $('bk-caminho').textContent = ult.caminho;
        ocupar(false);
    }

    async function fazerBackupAgora() {
        if (ocupado) return;
        const msg = $('bk-msg');
        // pedir a permissão tem que ser a PRIMEIRA coisa dentro do clique (o navegador exige gesto do usuário)
        if (!permissao) {
            const ok = await IO.pedirPermissaoDownloads();
            if (!ok) { mensagem(msg, 'Sem a permissão a extensão não pode gravar na pasta Downloads. Use “Salvar uma cópia (sem a permissão)” ou libere em about:addons → esta extensão → Permissões → Opcional.', 'erro'); return; }
            permissao = true;
        }
        ocupar(true);
        mensagem(msg, 'Salvando…');
        const r = await IO.fazerBackup({ motivo: 'manual' });
        if (r.ok) mensagem(msg, 'Backup salvo' + (r.caminho ? ' em ' + r.caminho : '') + ' (' + bytesLegivel(r.bytes) + ').', 'ok');
        else mensagem(msg, r.erro || 'Não foi possível salvar.', 'erro');
        await renderBackup();
    }

    async function salvarCopiaSemPermissao() {
        if (ocupado) return;
        ocupar(true);
        const msg = $('bk-msg');
        const r = await IO.fazerBackup({ motivo: 'manual', semPermissao: true });
        if (r.ok) mensagem(msg, 'A cópia foi enviada ao download do navegador (' + bytesLegivel(r.bytes) + '). Procure o arquivo ' + (r.nome || 'backup') + ' na sua pasta de downloads; o navegador pode perguntar onde salvar.', 'ok');
        else mensagem(msg, r.erro || 'Não foi possível salvar.', 'erro');
        await renderBackup();
    }

    $('bk-agora').addEventListener('click', fazerBackupAgora);
    $('bk-link').addEventListener('click', salvarCopiaSemPermissao);
    $('bk-perm').addEventListener('click', async () => {
        const ok = await IO.pedirPermissaoDownloads();
        mensagem($('bk-msg'), ok ? 'Permissão concedida.' : 'A permissão não foi concedida.', ok ? 'ok' : 'erro');
        await renderBackup();
    });
    // "click" (e não "change") porque o navegador só aceita o pedido de permissão dentro de um gesto do usuário
    $('bk-auto').addEventListener('click', async (ev) => {
        const ligar = ev.target.checked;
        const msg = $('bk-msg');
        if (ligar && !permissao) {
            const ok = await IO.pedirPermissaoDownloads();
            if (!ok) {
                ev.target.checked = false;
                mensagem(msg, 'O backup automático precisa da permissão para gravar em Downloads. Libere em about:addons → esta extensão → Permissões → Opcional.', 'erro');
                return;
            }
            permissao = true;
        }
        ocupar(true);
        await IO.salvarConfig({ auto: ligar });
        if (ligar) {
            mensagem(msg, 'Backup automático ligado. Fazendo o primeiro backup agora…');
            const r = await IO.fazerBackup({ motivo: 'manual' });
            if (r.ok) mensagem(msg, 'Backup automático ligado e primeiro backup salvo' + (r.caminho ? ' em ' + r.caminho : '') + '.', 'ok');
            else mensagem(msg, 'Ligado, mas o primeiro backup não saiu: ' + (r.erro || 'erro desconhecido'), 'erro');
        } else mensagem(msg, 'Backup automático desligado. O botão “Fazer backup agora” continua funcionando.', 'ok');
        await renderBackup();
    });
    $('bk-intervalo').addEventListener('change', async (ev) => { await IO.salvarConfig({ intervaloH: Number(ev.target.value) }); await renderBackup(); });
    $('bk-leis').addEventListener('click', async (ev) => { await IO.salvarConfig({ incluirLeis: ev.target.checked }); mensagem($('bk-msg'), ev.target.checked ? 'Os próximos backups vão incluir os PDFs de leis importados (arquivo maior).' : 'Os próximos backups não vão incluir os PDFs de leis importados.', 'ok'); });

    // --------------------------------------------------------- tela: restaurar
    let arquivoLido = null; // { obj, avisos }
    let atuaisNaPrevia = null;
    let vazioAqui = true;

    const LINHAS_COMPARACAO = [
        ['Marcações do Planalto', (r) => r.planalto.marcacoes],
        ['Comentários nas marcações', (r) => r.planalto.comentarios],
        ['Páginas do Planalto com marcações', (r) => r.planalto.paginas],
        ['Desenhos sobre as leis', (r) => r.planalto.desenhos],
        ['Artigos que errei (para revisar)', (r) => r.planalto.artigosParaRevisar],
        ['Artigos que errei (pendentes)', (r) => r.planalto.artigosPendentes],
        ['Anotações de erro por artigo', (r) => r.planalto.errosAnotados],
        ['Dias de estudo', (r) => r.estudo.diasDeEstudo],
        ['Questões no caderno de erros', (r) => r.estudo.cadernoDeErros],
        ['Post-its e simulados', (r) => r.planejamento.postits + r.planejamento.simulados],
        ['Conversas com o assistente', (r) => r.ia.conversas]
    ];

    function alerta(texto, tipo) {
        const d = document.createElement('div');
        d.className = 'bk-alerta' + (tipo === 'erro' ? ' bk-alerta--erro' : '');
        d.textContent = texto;
        return d;
    }

    function modoEscolhido() { const r = document.querySelector('input[name="bk-modo"]:checked'); return r ? r.value : 'mesclar'; }

    function atualizarPlano() {
        if (!arquivoLido || !atuaisNaPrevia) return;
        const plano = Core.planejarRestauracao(arquivoLido.obj, atuaisNaPrevia, { modo: modoEscolhido(), identidade: $('bk-ident').checked });
        const rel = plano.relatorio, f = plano.resumoFinal;
        $('bk-plano').innerHTML = 'Serão gravados ' + num(rel.gravadas) + ' itens, mesclados ' + num(rel.mescladas) + ', removidos ' + num(rel.removidas) + ' e ignorados ' + num(rel.ignoradas.length)
            + ' (licença, chaves de I.A., caches e estado temporário nunca são restaurados). Depois você terá ' + num(f.planalto.marcacoes) + ' marcações, ' + num(f.planalto.comentarios) + ' comentários, '
            + num(f.planalto.artigosParaRevisar + f.planalto.artigosPendentes) + ' artigos errados e ' + num(f.estudo.diasDeEstudo) + ' dias de estudo.';
    }

    async function mostrarPrevia(obj, validacao) {
        atuaisNaPrevia = await IO.lerTudo();
        vazioAqui = Core.ehDadosVazios(atuaisNaPrevia.local, atuaisNaPrevia.sync);
        arquivoLido = { obj, avisos: validacao.avisos };
        const rArq = resumoDoQueEntra(obj.dados);
        const rAtual = resumoDoQueEntra(atuaisNaPrevia);

        const t = Date.parse(obj.criadoEm);
        $('bk-rest-tit').textContent = isFinite(t) ? 'Backup de ' + quando(t) : 'Backup sem data';
        const o = obj.origem || {};
        const partes = [];
        if (isFinite(t)) partes.push(ha(t));
        if (o.versaoExtensao) partes.push('extensão v' + String(o.versaoExtensao).replace(/[^\w.\-]/g, ''));
        if (o.navegador) partes.push(String(o.navegador).slice(0, 40));
        $('bk-rest-sub').textContent = partes.join(' · ');

        const tab = $('bk-comp');
        tab.textContent = '';
        const cab = tab.createTHead().insertRow();
        ['', 'No backup', 'Agora aqui'].forEach((tx, i) => { const th = document.createElement('th'); th.textContent = tx; if (i) th.className = 'n'; cab.appendChild(th); });
        const corpo = tab.createTBody();
        LINHAS_COMPARACAO.forEach(([rot, fn]) => {
            const a = fn(rArq), b = fn(rAtual);
            if (!a && !b) return;
            const tr = corpo.insertRow();
            const th = document.createElement('th'); th.scope = 'row'; th.textContent = rot; tr.appendChild(th);
            [a, b].forEach((v) => { const td = tr.insertCell(); td.className = 'n'; td.textContent = Number(v).toLocaleString('pt-BR'); });
        });

        const alertas = $('bk-rest-alertas');
        alertas.textContent = '';
        validacao.avisos.forEach((av) => alertas.appendChild(alerta(av)));
        const temMais = rAtual.planalto.marcacoes > rArq.planalto.marcacoes || rAtual.planalto.comentarios > rArq.planalto.comentarios
            || (rAtual.planalto.artigosParaRevisar + rAtual.planalto.artigosPendentes) > (rArq.planalto.artigosParaRevisar + rArq.planalto.artigosPendentes)
            || rAtual.estudo.diasDeEstudo > rArq.estudo.diasDeEstudo;
        if (!vazioAqui && temMais) alertas.appendChild(alerta('Esta instalação tem MAIS dados do que o backup em pelo menos um item. Escolha “Mesclar” para não perder o que é mais novo.'));
        if (!vazioAqui) alertas.appendChild(alerta('Esta instalação já tem dados. Antes de qualquer mudança é salva uma cópia dos dados de agora (arquivo “antes-de-restaurar-…”).'));
        if (o.tinhaLicenca) alertas.appendChild(alerta('Este backup veio de uma instalação com o plano Pro. A licença não vai no arquivo: depois de restaurar, cole o seu código em Configurações → Plano e Licença (com a identificação restaurada, o código que você já recebeu continua valendo).'));
        if (isFinite(t) && Date.now() - t > 30 * 864e5) alertas.appendChild(alerta('Este backup tem mais de 30 dias. Se existir um mais recente na pasta, use o mais recente.'));

        const modo = vazioAqui ? 'substituir' : 'mesclar';
        document.querySelectorAll('input[name="bk-modo"]').forEach((r) => { r.checked = r.value === modo; });
        $('bk-ident').checked = vazioAqui;
        $('bk-rest-previa').hidden = false;
        $('bk-rest-resultado').hidden = true;
        resetarBotaoRestaurar();
        atualizarPlano();
    }

    async function lerArquivoEscolhido(file) {
        const msg = $('bk-rest-msg');
        $('bk-rest-previa').hidden = true;
        $('bk-rest-resultado').hidden = true;
        arquivoLido = null;
        if (!file) return;
        mensagem(msg, 'Lendo ' + file.name + '…');
        let texto;
        try { texto = await (file.text ? file.text() : new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.onerror = () => rej(fr.error); fr.readAsText(file); })); }
        catch (e) { mensagem(msg, 'Não consegui ler o arquivo: ' + (e && e.message ? e.message : e), 'erro'); return; }
        let obj;
        try { obj = JSON.parse(texto); } catch (e) { mensagem(msg, 'Este arquivo não é um JSON válido (pode estar incompleto ou ser outro tipo de arquivo).', 'erro'); return; }
        const v = Core.validarBackup(obj);
        if (!v.ok) { mensagem(msg, v.erros.join(' '), 'erro'); return; }
        mensagem(msg, 'Arquivo lido: ' + file.name + ' (' + bytesLegivel(file.size) + '). Confira abaixo e escolha como restaurar.', 'ok');
        await mostrarPrevia(obj, v);
    }

    $('bk-file').addEventListener('change', (ev) => { lerArquivoEscolhido(ev.target.files && ev.target.files[0]); });
    const drop = $('bk-drop');
    ['dragenter', 'dragover'].forEach((n) => drop.addEventListener(n, (ev) => { ev.preventDefault(); drop.classList.add('arrasta'); }));
    ['dragleave', 'drop'].forEach((n) => drop.addEventListener(n, (ev) => { ev.preventDefault(); drop.classList.remove('arrasta'); }));
    drop.addEventListener('drop', (ev) => { const f = ev.dataTransfer && ev.dataTransfer.files && ev.dataTransfer.files[0]; if (f) lerArquivoEscolhido(f); });
    document.querySelectorAll('input[name="bk-modo"]').forEach((r) => r.addEventListener('change', atualizarPlano));
    $('bk-ident').addEventListener('change', atualizarPlano);
    $('bk-cancelar').addEventListener('click', () => {
        $('bk-file').value = '';
        $('bk-rest-previa').hidden = true;
        $('bk-rest-resultado').hidden = true;
        mensagem($('bk-rest-msg'), '');
        arquivoLido = null;
    });

    let confirmando = false;
    let relogioConfirmar = null;
    function resetarBotaoRestaurar() {
        confirmando = false;
        clearTimeout(relogioConfirmar);
        const b = $('bk-restaurar');
        b.textContent = 'Restaurar agora';
        b.className = 'bk-btn';
        b.disabled = false;
    }

    async function restaurar() {
        if (!arquivoLido || ocupado) return;
        const msg = $('bk-rest-msg');
        const modo = modoEscolhido();
        const botao = $('bk-restaurar');
        const sess = await new Promise((r) => chrome.storage.local.get(['sessionState'], r));
        if (sess && sess.sessionState === 'running') {
            mensagem(msg, 'Há uma sessão de estudo em andamento. Pare o cronômetro no popup e tente de novo (assim ele não grava por cima do que for restaurado).', 'erro');
            return;
        }
        // reler o estado de agora: pode ter mudado desde que o arquivo foi escolhido
        const atuais = await IO.lerTudo();
        const temDados = !Core.ehDadosVazios(atuais.local, atuais.sync);
        if (modo === 'substituir' && temDados && !confirmando) {
            confirmando = true;
            botao.textContent = 'Confirmar: substituir meus dados atuais';
            botao.className = 'bk-btn bk-btn--perigo';
            relogioConfirmar = setTimeout(resetarBotaoRestaurar, 8000);
            mensagem(msg, 'Clique de novo para confirmar. Uma cópia dos dados atuais será salva antes.', '');
            return;
        }
        resetarBotaoRestaurar();
        ocupar(true);
        botao.disabled = true;
        try {
            if (temDados) {
                mensagem(msg, 'Salvando uma cópia dos dados atuais antes de mexer em qualquer coisa…');
                const seg = await IO.fazerBackup({ motivo: 'antes-de-restaurar', semPermissao: !(await IO.temPermissaoDownloads()) });
                if (!seg.ok && !seg.vazio) {
                    mensagem(msg, 'Não consegui salvar a cópia de segurança, então NADA foi alterado. Motivo: ' + (seg.erro || 'desconhecido'), 'erro');
                    return;
                }
            }
            const plano = Core.planejarRestauracao(arquivoLido.obj, atuais, { modo, identidade: $('bk-ident').checked });
            mensagem(msg, 'Restaurando…');
            const res = await IO.aplicarPlano(plano);
            // quem restaura já usa a extensão: não mostrar o tutorial de boas-vindas depois
            try { await new Promise((r) => chrome.storage.local.set({ cbOnboardingPendente: false, cbOnboardingSeen: true }, r)); } catch (e) { /* tanto faz */ }
            mostrarResultado(plano, res);
            $('bk-rest-previa').hidden = true;
            mensagem(msg, res.ok ? 'Restauração concluída.' : 'Restauração concluída com avisos (veja abaixo).', res.ok ? 'ok' : 'erro');
            arquivoLido = null;
            $('bk-file').value = '';
        } catch (e) {
            mensagem(msg, 'A restauração falhou: ' + (e && e.message ? e.message : e), 'erro');
        } finally {
            ocupar(false);
            await renderBackup();
        }
    }
    $('bk-restaurar').addEventListener('click', restaurar);

    function mostrarResultado(plano, res) {
        const box = $('bk-rest-resultado');
        box.textContent = '';
        box.hidden = false;
        const card = document.createElement('div');
        card.className = 'bk-status bk-status--' + (res.ok ? 'ok' : 'antigo');
        const topo = document.createElement('div'); topo.className = 'bk-status-topo';
        const ponto = document.createElement('span'); ponto.className = 'bk-ponto';
        const h = document.createElement('h2'); h.className = 'bk-status-tit'; h.textContent = res.ok ? 'Dados restaurados' : 'Restaurado, com avisos';
        topo.appendChild(ponto); topo.appendChild(h); card.appendChild(topo);
        const ul = document.createElement('ul'); ul.className = 'bk-lista';
        preencherLista(ul, linhasResumo(plano.resumoFinal));
        card.appendChild(ul);
        box.appendChild(card);

        const passos = document.createElement('div');
        passos.className = 'bk-aviso';
        passos.innerHTML = '<b>Próximos passos:</b><ul class="bk-ul" style="margin-top:6px"><li>Recarregue (F5) as páginas do Planalto e do QConcursos que estiverem abertas para ver as marcações.</li>'
            + '<li>Se você é Pro: cole seu código em Configurações → Plano e Licença' + (plano.identidade ? '.' : ' (a identificação desta instalação não foi restaurada, então o código antigo só vale se o ID for o mesmo).') + '</li>'
            + '<li>Se usava chaves de I.A., cole-as de novo: elas nunca vão no backup.</li></ul>';
        box.appendChild(passos);
        if (res.falhas && res.falhas.length) {
            const f = alerta('', 'erro');
            const b = document.createElement('b'); b.textContent = 'Não foi possível gravar ' + res.falhas.length + ' ' + pl(res.falhas.length, 'item', 'itens') + ':';
            f.appendChild(b);
            const ul2 = document.createElement('ul');
            res.falhas.slice(0, 8).forEach((x) => { const li = document.createElement('li'); li.textContent = String(x.chave).slice(0, 90) + ' (' + x.area + '): ' + x.erro; ul2.appendChild(li); });
            f.appendChild(ul2);
            box.appendChild(f);
        }
    }

    // ---------------------------------------------------------------- início
    renderBackup().catch((e) => {
        mensagem($('bk-msg'), 'Não consegui ler o estado do backup: ' + (e && e.message ? e.message : e), 'erro');
    });
    // se outra aba/o background gravar um backup enquanto esta página está aberta, atualiza o cartão
    try {
        chrome.storage.onChanged.addListener((mud, area) => {
            if (area === 'local' && mud[IO.K_ESTADO] && !ocupado) renderBackup();
        });
    } catch (e) { /* sem listener */ }
})();
