// Página de conexão com o Puter (ver dados-config/ia-puter.js). Roda numa aba da extensão, não no popup,
// porque a janela de login do Puter tira o foco e o popup fecharia.
(function () {
    const $ = (id) => document.getElementById(id);
    const log = (t) => { $('log').textContent = t; };
    const guardar = (o) => new Promise((r) => chrome.storage.local.set(o, r));
    const ler = (k) => new Promise((r) => chrome.storage.local.get(k, (x) => r(x || {})));

    if (typeof puter === 'undefined') { $('conta').textContent = 'O SDK do Puter não carregou.'; return; }

    async function atualizar() {
        const logado = puter.auth.isSignedIn();
        if (logado) {
            try { const u = await puter.auth.getUser(); $('conta').innerHTML = '<span class="ok">Conectada:</span> ' + (u.username || '(sem nome)'); }
            catch (e) { $('conta').innerHTML = '<span class="ok">Conectada</span>'; }
            $('entrar').textContent = 'Trocar de conta';
            try {
                const u = await puter.auth.getMonthlyUsage();
                const a = u.allowanceInfo || {};
                $('creditos').textContent = a.remaining != null ? `${a.remaining.toFixed(1)} de ${a.monthUsageAllowance} restantes` : JSON.stringify(u).slice(0, 120);
            } catch (e) { $('creditos').textContent = 'não consegui ler: ' + (e && e.message || e); }
        } else {
            $('conta').innerHTML = '<span class="ruim">Não conectada</span>';
            $('creditos').textContent = '—';
            $('entrar').textContent = 'Entrar no Puter';
        }
    }

    const sel = $('modelo');
    Object.entries(CBPuter.MODELOS).forEach(([id, nome]) => { const o = document.createElement('option'); o.value = id; o.textContent = nome; sel.appendChild(o); });
    ler(['cbPuterAtivo', 'cbPuterModelo']).then((c) => { $('ativo').checked = !!c.cbPuterAtivo; sel.value = CBPuter.MODELOS[c.cbPuterModelo] ? c.cbPuterModelo : CBPuter.MODELO_PADRAO; });
    $('ativo').onchange = () => {
        if ($('ativo').checked && !puter.auth.isSignedIn()) { $('ativo').checked = false; log('Entre no Puter primeiro.'); return; }
        guardar({ cbPuterAtivo: $('ativo').checked });
    };
    sel.onchange = () => guardar({ cbPuterModelo: sel.value });
    $('entrar').onclick = async () => { try { await puter.auth.signIn(); } catch (e) { log('Login cancelado ou bloqueado: ' + (e && e.message || '')); } atualizar(); };
    $('atualizar').onclick = atualizar;
    $('testar').onclick = async (ev) => {
        ev.target.disabled = true; log('Perguntando…');
        try {
            const t0 = Date.now();
            const r = await puter.ai.chat($('pergunta').value, { model: sel.value });
            log(`(${Date.now() - t0} ms) ${CBPuter.extrairTexto(r)}`);
        } catch (e) {
            const cod = e && (e.code || (e.error && e.error.code));
            log(cod === 'insufficient_funds' ? 'A cota do mês acabou (402).' : 'Erro: ' + (e && (e.message || JSON.stringify(e))));
        }
        ev.target.disabled = false; atualizar();
    };
    atualizar();
})();
