// Carrega o Assistente de I.A. só quando a pessoa chega no botão do chat.
//
// Antes, ~20 scripts da I.A. (uns 400 KB) eram lidos e executados a cada abertura do popup, mesmo por quem
// nunca abre o chat; no Firefox isso pesa. Agora ficam de fora do popup.html e entram aqui, UM DE CADA VEZ e na
// mesma ordem de antes (um depende do outro). A pessoa começa a carregar assim que o mouse chega no botão
// (ou toca nele), então no clique já está pronto; se não estiver, o clique espera o carregamento terminar e
// só então abre o chat (reenviando o clique para o ia-chat.js, que registra seu próprio ouvinte ao carregar).
(function () {
    'use strict';
    const btn = document.getElementById('btn-ia-chat');
    if (!btn || typeof window.cbCarregarScript !== 'function') return;

    // ORDEM IMPORTANTE: igual à que estava no popup.html.
    const SCRIPTS = [
        '../dados-config/ia-provider.js',
        '../dados-config/ia-contexto.js',
        '../dados-config/ia-agenda-writer.js',
        '../dados-config/ia-legislacao.js',
        '../dados-config/ia-planalto.js',
        '../dados-config/ia-jurisprudencia-permanente.js',
        '../dados-config/ia-jurisprudencia.js',
        '../dados-config/ia-doutrina-permanente.js',
        '../dados-config/ia-legislacao-permanente.js',
        '../dados-config/ia-classificador-materia.js',
        '../dados-config/ia-dizerodireito.js',
        '../dados-config/ia-sumulas-teses.js',
        '../dados-config/ia-puter.js',
        '../dados-config/ia-pesquisa-externa.js',
        '../dados-config/ia-pesquisa-aprofundada.js',
        '../dados-config/ia-busca-web.js',
        'ia-leis-import.js',
        'ia-chat.js',
        'historico-busca.js',
        'ia-chat-historico.js',
    ];

    let carregando = null;
    function carregar() {
        if (!carregando) {
            carregando = (async () => {
                for (const src of SCRIPTS) await window.cbCarregarScript(src);
            })();
            carregando.catch((e) => { console.error('[Concurseiro Blindado] falha ao carregar o assistente de I.A.:', e); carregando = null; });
        }
        return carregando;
    }

    // Modo "Completo": já deixa o assistente carregado, mas só depois que o popup apareceu (navegador ocioso),
    // para o chat abrir na hora sem atrasar a abertura. Nos modos Automático/Leve continua sob demanda.
    try {
        if (window.cbDesempenho && window.cbDesempenho.modo() === 'completo') {
            const idle = window.requestIdleCallback || ((f) => setTimeout(f, 1200));
            idle(() => { carregar().catch(() => {}); }, { timeout: 4000 });
        }
    } catch (e) { /* sem preload: segue sob demanda */ }

    ['pointerenter', 'pointerdown', 'focus', 'touchstart'].forEach((ev) => btn.addEventListener(ev, carregar, { once: true, passive: true }));

    // Captura o primeiro clique (antes de qualquer outro ouvinte), espera o carregamento e reenvia o clique.
    const interceptar = (e) => {
        e.stopImmediatePropagation();
        e.preventDefault();
        btn.removeEventListener('click', interceptar, true);   // o clique reenviado passa direto para o ia-chat.js
        carregar().then(() => btn.click()).catch(() => { /* já logado acima; o botão tenta de novo no próximo clique */
            btn.addEventListener('click', interceptar, true);
        });
    };
    btn.addEventListener('click', interceptar, true);
})();
