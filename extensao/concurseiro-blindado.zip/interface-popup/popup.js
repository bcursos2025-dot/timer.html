document.addEventListener('DOMContentLoaded', () => {
    // =====================================================================
    // PERMISSÃO AMPLA (<all_urls>) — pedida sob demanda, nunca no install
    // =====================================================================
    // Recursos como o cronômetro flutuante e a tela de bloqueio do modo
    // Offline precisam rodar em qualquer site (não só no QConcursos). Em vez
    // de já vir com essa permissão concedida na instalação, ela agora é
    // "optional_host_permissions" no manifest e só é solicitada aqui, no
    // momento em que a pessoa liga um desses recursos — com uma explicação
    // clara do porquê. Se ela recusar, o recurso simplesmente não liga.
    //
    // callback(concedida: boolean) é chamado depois da resposta do usuário.
    function cbGarantirPermissaoAmpla(motivo, callback) {
        chrome.permissions.contains({ origins: ['<all_urls>'] }, (jaTem) => {
            console.log('[Concurseiro Blindado][diagnóstico] já tem permissão <all_urls>?', jaTem);
            if (jaTem) { callback(true); return; }
            console.log('[Concurseiro Blindado][diagnóstico] pedindo permissão <all_urls> agora...');
            // No Firefox o pedido feito de dentro do popup costuma falhar (ou lançar erro): nesse caso
            // mostra a folha que ensina a ligar os interruptores em about:addons.
            const negada = () => { cbMostrarGuiaPermissao(motivo); callback(false); };
            try {
                chrome.permissions.request({ origins: ['<all_urls>'] }, (concedida) => {
                    console.log('[Concurseiro Blindado][diagnóstico] resultado do pedido:', concedida, 'lastError:', chrome.runtime.lastError);
                    if (concedida) callback(true); else negada();
                });
            } catch (e) {
                console.warn('[Concurseiro Blindado] permissions.request lançou erro:', e);
                negada();
            }
        });
    }

    // Folha "Liberar acesso aos sites": explica por que precisa, mostra o desenho dos dois interruptores
    // e como abrir a tela. O passo a passo completo (e o "por que tantas permissões") fica em
    // permissoes.html, numa aba, porque o popup fecha quando a pessoa troca para o about:addons.
    function cbMostrarGuiaPermissao(motivo) {
        const overlay = document.getElementById('perm-guia-overlay');
        if (!overlay) return;
        const motivoEl = document.getElementById('pg-motivo');
        const sanitizado = String(motivo || 'esse recurso').replace(/[<>&]/g, '');
        motivoEl.innerHTML = `Para usar <b>${sanitizado}</b>, o Firefox precisa que você libere o acesso da extensão aos sites. `
            + 'Esse acesso vem <b>desligado</b> por padrão e só você pode ligar.';
        overlay.classList.add('open');
    }
    (function cbLigarGuiaPermissao() {
        const overlay = document.getElementById('perm-guia-overlay');
        if (!overlay) return;
        const fechar = () => overlay.classList.remove('open');
        const abrirPagina = (hash) => chrome.tabs.create({ url: chrome.runtime.getURL('interface-popup/permissoes.html') + (hash || '') });
        // Primeira abertura no Firefox: o acesso a todos os sites vem desligado, então mostra o guia sem esperar
        // a pessoa clicar em Iniciar. Se ela fechar, só volta no dia seguinte (enquanto o acesso faltar).
        const hoje = new Date().toISOString().slice(0, 10);
        const adiadoHoje = () => { try { return localStorage.getItem('cbGuiaPermAdiado') === hoje; } catch (e) { return false; } };
        if (/Firefox\//.test(navigator.userAgent) && !adiadoHoje()) {
            chrome.permissions.contains({ origins: ['<all_urls>'] }, (tem) => {
                if (tem) return;
                let tentativas = 0;
                const tentar = () => {
                    const onb = document.getElementById('cb-onboarding-overlay');
                    if (onb && onb.classList.contains('is-open') && tentativas++ < 90) { setTimeout(tentar, 1000); return; }   // espera a boas-vindas terminar
                    cbMostrarGuiaPermissao('o cronômetro e os demais recursos');
                };
                setTimeout(tentar, 800);
            });
        }
        document.getElementById('perm-guia-close')?.addEventListener('click', () => {
            try { localStorage.setItem('cbGuiaPermAdiado', hoje); } catch (e) { /* sem localStorage */ }
            fechar();
        });
        overlay.addEventListener('click', (e) => { if (e.target === overlay) fechar(); });
        document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && overlay.classList.contains('open')) fechar(); });
        document.getElementById('perm-guia-passo')?.addEventListener('click', () => abrirPagina(''));
        document.getElementById('perm-guia-porque')?.addEventListener('click', () => abrirPagina('#porque'));
        const btnCopiar = document.getElementById('perm-guia-copiar');
        btnCopiar?.addEventListener('click', async () => {
            try { await navigator.clipboard.writeText('about:addons'); } catch (e) { /* sem permissão de área de transferência */ }
            const antes = btnCopiar.textContent;
            btnCopiar.textContent = 'Copiado ✓';
            setTimeout(() => { btnCopiar.textContent = antes; }, 2000);
        });
    })();

    // =====================================================================
    // PAINEL DE COMANDO (Ctrl+X) — toggle explícito nas Configurações que
    // pede a mesma permissão ampla acima, mas de forma direta e visível,
    // em vez de escondida atrás de outra ação (como acontecia até agora
    // com Modo Offline / Cronômetro Flutuante).
    // =====================================================================
    const chkCmdCenter = document.getElementById('chk-cmdcenter');
    const cmdCenterHint = document.getElementById('cmdcenter-status-hint');

    function cbAtualizarHintCmdCenter(concedida) {
        if (!cmdCenterHint) return;
        cmdCenterHint.textContent = concedida
            ? 'Ativo — aperte Ctrl+X em qualquer aba pra abrir.'
            : 'Precisa de permissão para rodar em qualquer site. Ative aqui — vai te perguntar uma vez só.';
    }

    if (chkCmdCenter) {
        chrome.permissions.contains({ origins: ['<all_urls>'] }, (jaTem) => {
            chkCmdCenter.checked = !!jaTem;
            cbAtualizarHintCmdCenter(!!jaTem);
        });

        chkCmdCenter.addEventListener('change', () => {
            if (chkCmdCenter.checked) {
                cbGarantirPermissaoAmpla('o Painel de Comando (Ctrl+X)', (concedida) => {
                    chkCmdCenter.checked = concedida;
                    cbAtualizarHintCmdCenter(concedida);
                });
            } else {
                // Revogar é opcional aqui — chrome.permissions.remove tira a
                // permissão de TODOS os recursos que dependem dela (Offline,
                // cronômetro flutuante, painel), então só avisamos em vez de
                // remover sozinho, pra não desligar os outros por engano.
                window.alert(
                    'Pra desativar de vez, é preciso remover a permissão de acesso a sites nas configurações da extensão ' +
                    '(Firefox: about:addons → Concurseiro Blindado → Permissões e dados; ' +
                    'Chrome: chrome://extensions → Detalhes → Permissões do site). ' +
                    'Isso desliga também o Modo Offline e o cronômetro flutuante, que usam a mesma permissão.'
                );
                chkCmdCenter.checked = true;
            }
        });
    }

    // =====================================================================
    // LICENÇA — FREE / PRO
    // =====================================================================
    // Troque pelo seu número (formato internacional, só dígitos, com DDI+DDD)
    const CB_WHATSAPP_NUMBER = '5545998061263';

    function cbBuildWhatsappLink(installId) {
        const msg = encodeURIComponent(
            `Olá! Quero desbloquear o Concurseiro Blindado.\nMeu ID de instalação: ${installId}`
        );
        return `https://wa.me/${CB_WHATSAPP_NUMBER}?text=${msg}`;
    }

    function cbShowUpgradeModal() {
        const overlay = document.getElementById('pro-upgrade-overlay');
        if (overlay) overlay.classList.add('open');
    }
    function cbHideUpgradeModal() {
        const overlay = document.getElementById('pro-upgrade-overlay');
        if (overlay) overlay.classList.remove('open');
    }
    document.getElementById('pro-upgrade-close')?.addEventListener('click', cbHideUpgradeModal);
    document.getElementById('pro-upgrade-overlay')?.addEventListener('click', (e) => {
        if (e.target.id === 'pro-upgrade-overlay') cbHideUpgradeModal();
    });

    // Aplica visualmente o bloqueio/desbloqueio em todos os elementos marcados
    // com data-pro-feature="chave" de acordo com o mapa de features liberadas.
    function cbApplyGates(unlockedMap) {
        document.querySelectorAll('[data-pro-feature]').forEach(el => {
            const feature = el.getAttribute('data-pro-feature');
            const unlocked = !!unlockedMap[feature];
            el.classList.toggle('pro-locked', !unlocked);
            // Some destroys o funcionamento de checkboxes/inputs internos
            // mesmo que o clique seja interceptado (defesa extra).
            el.querySelectorAll('input, select, button').forEach(child => {
                if (child.id === 'pro-upgrade-close') return;
                child.dataset.cbLockedDisabled = (!unlocked).toString();
            });
        });
        cbGarantirTemaPermitido(!!unlockedMap['themes']);
        const anyLocked = document.querySelectorAll('[data-pro-feature].pro-locked').length > 0
            || Object.values(unlockedMap).some(v => v === false);
        const allUnlocked = Object.values(unlockedMap).length > 0 && Object.values(unlockedMap).every(v => v === true);
        const someUnlocked = Object.values(unlockedMap).some(v => v === true);
        const badgeText = document.getElementById('plan-badge-text');
        const badge = document.getElementById('plan-badge');
        const isPro = Object.values(unlockedMap).some(v => v === true) && !Object.values(unlockedMap).includes(false);
        if (badgeText && badge) {
            badgeText.innerText = allUnlocked ? 'PRO' : 'FREE';
            badge.classList.toggle('plan-badge-free', !allUnlocked);
        }
        const statusText = document.getElementById('license-status-text');
        if (statusText) {
            statusText.innerText = allUnlocked ? 'Pro (completo)' : (someUnlocked ? 'Pro (parcial)' : 'Free');
        }

        // Banner "Resgatar PRO grátis e vitalício" acima do cronômetro: só
        // pra quem ainda não tem tudo liberado. Some sozinho assim que a
        // pessoa vira Pro (por esse resgate ou por qualquer outro caminho).
        const promoBanner = document.getElementById('promo-lifetime-banner');
        if (promoBanner) promoBanner.style.display = allUnlocked ? 'none' : 'flex';

        // Acordeão "Plano e Licença": quem já tem tudo liberado não precisa
        // dele (nada pra aplicar código, nem WhatsApp de desbloqueio) — só
        // ocupa espaço na lista de Configurações. Some inteiro quando vira
        // Pro completo; volta a aparecer se algum dia desbloquear menos que
        // tudo de novo (ex: licença expirada).
        const licencaAccordion = document.querySelector('.settings-accordion[data-acc="licenca"]');
        if (licencaAccordion) licencaAccordion.style.display = allUnlocked ? 'none' : '';
    }

    // Clique no botão "Resgatar versão PRO grátis e vitalícia": libera tudo
    // na hora, sem código nem WhatsApp, e some com o próprio banner.
    document.getElementById('btn-resgatar-pro-vitalicio')?.addEventListener('click', async () => {
        if (!window.CBLicense) return;
        const btn = document.getElementById('btn-resgatar-pro-vitalicio');
        const textoOriginal = btn.innerHTML;
        btn.disabled = true;
        await window.CBLicense.resgatarProVitalicio();
        btn.innerHTML = '✓ PRO liberado — aproveite!';
        await cbRefreshGates();
        setTimeout(() => {
            const banner = document.getElementById('promo-lifetime-banner');
            if (banner) banner.style.display = 'none';
            btn.disabled = false;
            btn.innerHTML = textoOriginal;
        }, 1800);
    });

    // Garante que a versão FREE nunca fica presa num tema PRO (Escuro/Marinho/
    // Vidro/Automático) — nem por um valor antigo já salvo no storage (de
    // antes do padrão de fábrica virar Claro), nem por qualquer outro jeito
    // de setar themePref. Se 'themes' não estiver liberado e o tema salvo for
    // um dos PRO, corrige na hora pra Claro (e persiste a correção).
    // "Automático" entra na lista porque à noite ele vira Escuro — sem isso
    // dava pra escapar do bloqueio do tema Escuro só selecionando Automático.
    const CB_TEMAS_PRO = ['dark', 'navy', 'glass', 'auto'];
    function cbGarantirTemaPermitido(themesLiberado) {
        if (themesLiberado) return;
        chrome.storage.local.get(['themePref'], (localResult) => {
            if (!CB_TEMAS_PRO.includes(localResult.themePref)) return;
            applyTheme('light');
            chrome.storage.local.set({ themePref: 'light' });
            chrome.storage.sync.set({ themePref: 'light' });
            chrome.runtime.sendMessage({ action: 'changeTheme', theme: 'light' });
        });
    }

    // Intercepta cliques em qualquer área travada, ANTES que o handler real
    // do recurso rode (fase de captura), e mostra o modal de upgrade em vez
    // de deixar a ação acontecer.
    document.addEventListener('click', (e) => {
        const locked = e.target.closest('[data-pro-feature].pro-locked');
        if (locked) {
            e.preventDefault();
            e.stopImmediatePropagation();
            cbShowUpgradeModal();
        }
    }, true);
    document.addEventListener('change', (e) => {
        const locked = e.target.closest('[data-pro-feature].pro-locked');
        if (locked) {
            e.preventDefault();
            e.stopImmediatePropagation();
            if (e.target.type === 'checkbox') e.target.checked = false;
            cbShowUpgradeModal();
        }
    }, true);

    async function cbInitLicenseUI() {
        if (!window.CBLicense) return; // license.js não carregado
        const installId = await window.CBLicense.getInstallId();
        const idEl = document.getElementById('license-install-id');
        if (idEl) idEl.innerText = installId;

        const waLink = document.getElementById('btn-whatsapp-unlock');
        const waLink2 = document.getElementById('pro-upgrade-whatsapp');
        const href = cbBuildWhatsappLink(installId);
        if (waLink) waLink.href = href;
        if (waLink2) waLink2.href = href;


        document.getElementById('btn-copy-install-id')?.addEventListener('click', () => {
            navigator.clipboard.writeText(installId).then(() => {
                const btn = document.getElementById('btn-copy-install-id');
                const old = btn.innerText;
                btn.innerText = 'Copiado!';
                setTimeout(() => btn.innerText = old, 1500);
            });
        });

        document.getElementById('btn-apply-license')?.addEventListener('click', async () => {
            const input = document.getElementById('input-license-code');
            const feedback = document.getElementById('license-feedback');
            const code = input.value.trim();
            if (!code) return;
            const result = await window.CBLicense.applyLicenseCode(code);
            if (result.valid) {
                feedback.className = 'license-feedback ok';
                feedback.innerText = 'Licença ativada com sucesso! Recursos liberados.';
                input.value = '';
                cbRefreshGates();
            } else {
                feedback.className = 'license-feedback err';
                feedback.innerText = result.error || 'Código inválido.';
            }
        });

        cbRefreshGates();
    }

    // Junta, pro mapa de features liberadas, o que já veio da licença com o
    // que foi destravado por conquista (nível de estudo). Quem já tem TODAS
    // as features via licença nem percebe diferença (o merge é um "no-op"
    // nesse caso) — é só pra quem ainda é FREE/parcial que isso soma algo.
    function cbFeaturesDestravadasPorConquista(unlockedLevelIndex) {
        const idx = (unlockedLevelIndex !== undefined && unlockedLevelIndex !== null) ? unlockedLevelIndex : 0;
        const set = new Set();
        for (let i = 1; i <= idx; i++) {
            (ACHIEVEMENT_FEATURE_MAP[i] || []).forEach(f => set.add(f));
        }
        return set;
    }

    async function cbRefreshGates() {
        if (!window.CBLicense) return;
        const map = await window.CBLicense.getUnlockedMap();
        chrome.storage.local.get(['unlockedLevelIndex'], (result) => {
            const conquistados = cbFeaturesDestravadasPorConquista(result.unlockedLevelIndex);
            conquistados.forEach(f => { if (f in map) map[f] = true; });
            cbApplyGates(map);
        });
    }

    cbInitLicenseUI();
    // Reaplica os gates sempre que a licença mudar em outra aba/instância
    // ou quando abas/seções forem re-renderizadas dinamicamente.
    chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'sync' && (changes.cbLicenseCode || changes.cbLicensePayload)) {
            cbRefreshGates();
        }
        if (area === 'local' && changes.unlockedLevelIndex) {
            cbRefreshGates();
        }
    });
    // rede de segurança para conteúdo re-renderizado dinamicamente (no modo leve, 1 a cada 3 batidas)
    let cbGatesBatida = 0;
    setInterval(() => {
        if (document.documentElement.classList.contains('cb-lite') && (++cbGatesBatida % 3)) return;
        cbRefreshGates();
    }, 4000);

    let timerInterval = null;
    let currentChartPeriod = 'day'; 
    let currentChartViewMode = 'period'; // 'period' | 'activity' | 'pauses'
    let currentDistPeriod = 'today';

    const statusTag = document.getElementById('status-tag');
    const timerDisplay = document.getElementById('timer-display');
    const timerDragWrap = document.getElementById('timer-drag-wrap');
    const btnFloatHandle = document.getElementById('btn-float-handle');
    const timerFloatBanner = document.getElementById('timer-float-banner');
    const btnTimerDock = document.getElementById('btn-timer-dock');
    const btnPlay = document.getElementById('btn-play');
    const btnPause = document.getElementById('btn-pause');
    const chkPomodoro = document.getElementById('chk-pomodoro');
    const pomodoroIndicator = document.getElementById('pomodoro-indicator');
    const streakCount = document.getElementById('streak-count');
    const configCard = document.getElementById('config-card');
    const sectionConfig = document.getElementById('section-config');
    const sectionMeta = document.getElementById('section-meta');
    const sectionConquistas = document.getElementById('section-conquistas');
    const sectionTabs = document.getElementById('section-tabs');
    const currentFocusLabel = document.getElementById('current-focus-label');

    const selectMethod = document.getElementById('select-method');
    const selectActivity = document.getElementById('select-activity');
    const cbModoAuto = document.getElementById('cb-modo-auto');
    const cbModoAutoText = document.getElementById('cb-modo-auto-text');
    const cbRing = document.getElementById('cb-ring');
    const cbRingProgress = document.getElementById('cb-ring-progress');

    // "Pisca duas vezes a imagem da atmosfera" ao pausar: sessionState no
    // chrome.storage às vezes é escrito por mais de uma fonte quase ao
    // mesmo tempo (checagem de presença da câmera, comando remoto do
    // celular, heartbeat) — quando isso acontece, o listener de
    // storage.onChanged dispara updateUIState() duas vezes seguidas com
    // valores diferentes (ex: running → paused_away → paused_manual), e
    // cada troca real de "is-running" reinicia do zero a animação de
    // cross-fade Terra↔planetinha, o que aparece pra quem tá vendo como
    // a cena piscando/repetindo. Em vez de aplicar a classe na hora a
    // cada chamada, empilha só o ÚLTIMO valor pedido e aplica uma vez só
    // no próximo frame — se dois (ou mais) pedidos chegarem no mesmo
    // instante (mesmo ciclo de eventos), só o resultado final é que
    // realmente toca a classList, sem nenhum "flip" intermediário visível
    // e sem atraso perceptível (1 frame, ~16ms) pra um clique normal.
    let cbFrameRingAgendado = null;
    let cbEstadoRingPendente = null;
    let cbEmPausaPomodoroPendente = false;
    let cbRodandoAnterior = null; // null = ainda não sincronizou nenhuma vez hoje
    const cbVideoIda = document.getElementById('cb-video-ida');
    const cbVideoVolta = document.getElementById('cb-video-volta');
    const cbTimerCard = document.querySelector('.card.timer-section');

    // Dá play() no vídeo certo e liga a classe passageira que o
    // planeta.css usa pra mostrar ele por cima da transição (ver
    // ".cb-video-transicao" nesse arquivo). A classe liga no CARTÃO
    // (".card.timer-section"), não em "#cb-ring" — os vídeos são irmãos
    // de ".cb-ring-wrap" no HTML, não descendentes de "#cb-ring", então
    // uma classe ligada em "#cb-ring" nunca alcançaria eles via seletor
    // CSS (isso foi um bug real: o vídeo nunca ficava visível). Quem
    // desliga a classe é o próprio vídeo, no evento "ended" — mais
    // confiável que medir a duração "no olho" com setTimeout, que
    // desincroniza se o vídeo for trocado por outro de duração diferente
    // no futuro. */
    function cbTocarVideoTransicao(video, classe) {
        if (!video || !cbTimerCard) return;
        // Círculo clássico (padrão): sem planeta.css não tem "cena" nenhuma
        // pra fazer transição entre Terra e planetinha — nem tenta tocar o
        // vídeo (ver classe "cb-timer-classico" no <html>, ligada por
        // padrão no bloco "CRONÔMETRO: CÍRCULO x PLANETA" mais abaixo).
        if (document.documentElement.classList.contains('cb-timer-classico')) return;
        // Modo leve: sem vídeo (decodificar é pesado e, escondido, a cena real nunca ficaria travada)
        if (document.documentElement.classList.contains('cb-lite')) return;
        cbTimerCard.classList.remove('cb-transicao-ida', 'cb-transicao-volta');
        void cbTimerCard.offsetWidth; // reflow: garante que reiniciar a MESMA classe reinicie a exibição
        cbTimerCard.classList.add(classe);
        // Enquanto essa classe estiver ligada, a cena real (Terra ou
        // planetinha) fica travada em opacity:0 no planeta.css — de
        // propósito, pra não sobrepor com o vídeo (ver comentário grande
        // lá sobre a tira transparente nas laterais). Isso só é seguro
        // porque ALGUÉM sempre tira essa classe de novo: normalmente o
        // evento "ended" do vídeo, mas se o play() falhar ou o vídeo
        // travar/for pausado pelo navegador antes de terminar (aba sem
        // foco, erro de decodificação etc.), "ended" nunca dispara e a
        // cena real ficaria escondida pra sempre. Esse timeout de
        // segurança (duração do vídeo + folga) garante que a classe sai
        // de qualquer jeito, mesmo se o vídeo nunca terminar.
        let saiu = false;
        const tirarClasse = () => {
            if (saiu) return;
            saiu = true;
            cbTimerCard.classList.remove(classe);
            video.removeEventListener('ended', aoTerminar);
            clearTimeout(timeoutSeguranca);
            // O clarão de saída: o vídeo some (opacity 1→0 em só 0,1s) bem
            // no mesmo instante em que a cena real por baixo já aparece de
            // vez — nesse cruzamento rápido dava pra notar um "corte" (o
            // quadro final do vídeo nunca bate pixel a pixel com o desenho
            // em CSS). Um clarão curto, no pico já de cara, cobre
            // exatamente esse instante.
            //
            // A IDA termina no planetinha (círculo + anel roxo) e a VOLTA
            // termina na foto inteira da Terra — são cenas bem diferentes,
            // então cada uma tem o SEU clarão (ver "cb-flash-final" x
            // "cb-flash-atmosfera-ativo" em planeta.css; o mesmo clarão
            // roxo e redondo nos dois sentidos deixava uma mancha roxa
            // esquisita flutuando sobre a foto azul da Terra).
            const classeClarao = classe === 'cb-transicao-ida' ? 'cb-flash-final' : 'cb-flash-atmosfera-ativo';
            // Remove/religa (em vez de só ligar) pra garantir que anima de
            // novo mesmo se a pessoa pausar/retomar rápido o bastante pra
            // essa função rodar de novo antes do clarão anterior ter
            // sumido sozinho.
            cbTimerCard.classList.remove('cb-flash-final', 'cb-flash-atmosfera-ativo');
            void cbTimerCard.offsetWidth;
            cbTimerCard.classList.add(classeClarao);
            setTimeout(() => cbTimerCard.classList.remove(classeClarao), 650);
        };
        const aoTerminar = () => tirarClasse();
        video.addEventListener('ended', aoTerminar);
        const duracaoMs = (video.duration && isFinite(video.duration) ? video.duration * 1000 : 1600) + 600;
        const timeoutSeguranca = setTimeout(tirarClasse, duracaoMs);
        try {
            video.currentTime = 0;
            const p = video.play();
            if (p && p.catch) p.catch((erro) => {
                // Não esconde mais o erro: se o autoplay falhar, não faz
                // sentido continuar com a cena real escondida esperando um
                // vídeo que nunca vai tocar — revela ela na hora, e deixa
                // rastro no console em vez de falhar em silêncio.
                console.warn('[Concurseiro Blindado] vídeo da transição não tocou:', erro && erro.name, erro && erro.message);
                tirarClasse();
            });
        } catch (e) {
            console.warn('[Concurseiro Blindado] erro ao tentar tocar vídeo da transição:', e);
            tirarClasse();
        }
    }

    function aplicarClassesRing(state, emPausaPomodoro) {
        cbEstadoRingPendente = state;
        cbEmPausaPomodoroPendente = !!emPausaPomodoro;
        if (cbFrameRingAgendado) return;
        cbFrameRingAgendado = requestAnimationFrame(() => {
            cbFrameRingAgendado = null;
            const estadoFinal = cbEstadoRingPendente;
            const emRestPendente = cbEmPausaPomodoroPendente;
            // O intervalo (rest) do Pomodoro reaproveita o mesmo
            // sessionState 'paused_away' usado quando a pessoa fica ausente
            // da tela — mas o cronômetro continua rodando de verdade durante
            // o descanso, então o anel não deve ficar com a aparência
            // "pausado" (opaco/sem brilho) nesse caso, senão parece que ele
            // travou (ver bug reportado: anel "para de funcionar" após o
            // Pomodoro).
            const estaRodando = estadoFinal === 'running' || emRestPendente;
            // O vídeo só dispara na borda ida<->volta de verdade (não na
            // primeira sincronização do dia, que é só ler o estado salvo
            // em silêncio, sem "transição" nenhuma pra mostrar).
            if (cbRodandoAnterior !== null && cbRodandoAnterior !== estaRodando) {
                if (estaRodando) cbTocarVideoTransicao(cbVideoIda, 'cb-transicao-ida');
                else cbTocarVideoTransicao(cbVideoVolta, 'cb-transicao-volta');
            }
            cbRodandoAnterior = estaRodando;
            cbRing.classList.toggle('is-running', estaRodando);
            cbRing.classList.toggle('is-paused', !emRestPendente && (estadoFinal === 'paused_manual' || estadoFinal === 'paused_away'));
            cbRing.classList.toggle('is-resting', emRestPendente);
        });
    }

    // ===================== ANEL: ANIMAÇÃO DE ABERTURA (1ª vez no dia) =====================
    // Na primeira vez que a pessoa abre o popup no dia, em vez do anel
    // violeta aparecer pronto, mostramos bolinhas brancas espalhadas em
    // círculo girando rápido, que desaceleram e se fundem no anel normal.
    // Da segunda abertura em diante (mesmo dia), o anel aparece direto,
    // sem a animação. Guardamos a data em chrome.storage.local.
    const CB_RING_INTRO_DOTS = 28;
    const CB_RING_INTRO_RADIUS = 95; // px, raio onde as bolinhas ficam (perto da borda do anel)
    const CB_RING_INTRO_STORAGE_KEY = 'cbRingIntroUltimoDia';

    function cbHojeStr() {
        return new Date().toDateString();
    }

    function cbDeveTocarIntroDoAnel(callback) {
        try {
            chrome.storage.local.get([CB_RING_INTRO_STORAGE_KEY], (res) => {
                const hoje = cbHojeStr();
                if (res && res[CB_RING_INTRO_STORAGE_KEY] === hoje) {
                    callback(false);
                } else {
                    chrome.storage.local.set({ [CB_RING_INTRO_STORAGE_KEY]: hoje });
                    callback(true);
                }
            });
        } catch (e) {
            callback(false);
        }
    }

    function cbMontarBolinhasIntro(container) {
        container.innerHTML = '';
        // o raio acompanha o tamanho do anel (95px quando ele mede 210px): se o anel mudar de tamanho
        // no CSS, as bolinhas continuam caindo em cima do trilho
        const raio = cbRing && cbRing.offsetWidth ? Math.round(cbRing.offsetWidth * 0.452) : CB_RING_INTRO_RADIUS;
        const frag = document.createDocumentFragment();
        for (let i = 0; i < CB_RING_INTRO_DOTS; i++) {
            const angulo = (360 / CB_RING_INTRO_DOTS) * i;
            const dot = document.createElement('div');
            dot.className = 'cb-ring-intro-dot';
            dot.style.setProperty('--cb-intro-angle', angulo + 'deg');
            dot.style.setProperty('--cb-intro-delay', (Math.random() * 0.15).toFixed(2) + 's');
            dot.style.setProperty('transform', 'rotate(' + angulo + 'deg) translateX(' + raio + 'px)');
            frag.appendChild(dot);
        }
        container.appendChild(frag);
    }

    function cbPlayRingIntroAnimation() {
        if (!cbRing || document.body.classList.contains('modo-antigo')) return;
        if (document.documentElement.classList.contains('cb-lite')) return;   // modo leve: sem a abertura animada
        const introWrap = document.getElementById('cb-ring-intro');
        const introDots = document.getElementById('cb-ring-intro-dots');
        if (!introWrap || !introDots) return;

        cbMontarBolinhasIntro(introDots);
        cbRing.classList.add('cb-ring-intro-active');
        introWrap.classList.add('is-active');

        // força reflow pra garantir que a animação de giro comece do zero
        void introDots.offsetWidth;
        introDots.classList.add('is-spinning');

        // depois de girar rápido e desacelerar, revela o anel violeta por
        // trás enquanto as bolinhas somem
        setTimeout(() => {
            cbRing.classList.add('cb-ring-intro-reveal');
            introWrap.classList.add('is-fading');
            setTimeout(() => {
                cbRing.classList.remove('cb-ring-intro-active', 'cb-ring-intro-reveal');
                introWrap.classList.remove('is-active', 'is-fading');
                introDots.classList.remove('is-spinning');
                introDots.innerHTML = '';
            }, 500);
        }, 1150);
    }

    // ANTES: a animação tocava uma vez por dia, ao ABRIR o popup — e como
    // ela dura 1,6 s, quem abrisse a segunda vez no mesmo dia nunca mais a
    // veria. O momento certo é outro: quando você aperta "Iniciar Estudo"
    // com o cronômetro em zero. Aí ela deixa de ser enfeite de abertura e
    // vira a marcação de um começo — as bolinhas se juntam e viram o anel
    // que vai acompanhar o dia.
    function cbTocarIntroSeComecoDoDia() {
        try {
            chrome.storage.local.get(['studyHistory'], (res) => {
                const hist = (res && res.studyHistory) || {};
                const jaEstudouHoje = (Number(hist[getTodayKey()]) || 0) > 0;
                // Só no primeiro estudo do dia. Repetir a cada play viraria
                // atraso obrigatório de 1,6 s toda vez que você despausa.
                if (!jaEstudouHoje) cbPlayRingIntroAnimation();
            });
        } catch (e) { /* sem storage, simplesmente não toca */ }
    }

    // ===================== MODO ONLINE/OFFLINE: DETECÇÃO AUTOMÁTICA =====================
    // Antes a pessoa escolhia manualmente "Online" ou "Offline". Agora o
    // próprio sistema identifica: se a aba ativa é de um site de questões
    // (QConcursos, TecConcursos ou Gran Cursos Online), o modo é Online
    // (libera câmera); qualquer outro site cai automaticamente no Offline
    // (tela bloqueada). Isso mantém 100% de compatibilidade com o resto do
    // código, que continua lendo/gravando `activeMethod` normalmente — só
    // quem decide o valor mudou.
    // Mesma lista de QUESTION_BANK_HOSTS em dados-config/background.js (o rastreador decide o modo por ela).
    const CB_DOMINIOS_ONLINE = ['qconcursos.com', 'tecconcursos.com.br', 'gran.com.br', 'grancursosonline.com.br', 'estrategiaconcursos.com.br'];

    function cbHostnameEhOnline(hostname) {
        if (!hostname) return false;
        const h = hostname.replace(/^www\./, '').toLowerCase();
        return CB_DOMINIOS_ONLINE.some(d => h === d || h.endsWith('.' + d));
    }

    function cbDetectarModoAtivo(callback) {
        try {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                let method = 'offline';
                const url = tabs && tabs[0] && tabs[0].url;
                if (url) {
                    try { method = cbHostnameEhOnline(new URL(url).hostname) ? 'online' : 'offline'; }
                    catch (e) { method = 'offline'; }
                }
                callback(method);
            });
        } catch (e) {
            callback('offline');
        }
    }

    // ===================== SITES BLOQUEADOS — LISTA (só pra rever/desfazer) =====================
    // ANTES o popup tinha DUAS coisas aqui: uma linha "Bloquear este site
    // durante o estudo offline" (só pra PDF/vídeo/legislação, gravando numa
    // chave) e, mais abaixo, um prompt "Quer bloquear este site?" (pra
    // qualquer site, gravando em OUTRA chave). As duas não se conversavam:
    // responder numa não mudava nada na outra, e o bloqueio real ainda podia
    // vir de uma terceira lista escondida no código (sites de distração do
    // cronograma). Era esse o "rolo".
    //
    // Agora a PERGUNTA acontece só na própria página do site (ver
    // overlay-global/global_overlay.js). O popup não pergunta mais nada —
    // aqui ficou só a lista do que está bloqueado, com botão de desfazer,
    // porque decisão sem botão de desfazer é exatamente o que fazia parecer
    // que a extensão bloqueava sozinha.
    const CB_BLOQUEIO_LISTA_KEY = 'cbSitesBloqueadosManual';
    const CB_LIBERADOS_KEY = 'cbSitesLiberados';
    const listaBloqueioEl = document.getElementById('cb-lista-bloqueio');

    function cbRenderizarListaBloqueio() {
        if (!listaBloqueioEl) return;
        chrome.storage.local.get([CB_BLOQUEIO_LISTA_KEY, CB_LIBERADOS_KEY], (res) => {
            const bloqueados = res[CB_BLOQUEIO_LISTA_KEY] || [];
            const liberados = res[CB_LIBERADOS_KEY] || [];
            listaBloqueioEl.innerHTML = '';

            if (bloqueados.length === 0 && liberados.length === 0) {
                const vazio = document.createElement('p');
                vazio.className = 'cb-lista-bloqueio-vazio';
                vazio.textContent = 'Você ainda não bloqueou nenhum site.';
                listaBloqueioEl.appendChild(vazio);
                return;
            }

            const criarItem = (host, estado) => {
                const item = document.createElement('div');
                item.className = 'cb-lista-bloqueio-item';

                // Favicon do site numa bolinha — mesma técnica já usada na
                // aba Distrações (".site-favicon"), só que aqui redonda de
                // propósito (ali é quadrada com cantos levemente arredondados),
                // pra combinar com o resto dos botões em cápsula da extensão.
                const favicon = document.createElement('img');
                favicon.className = 'cb-lista-bloqueio-favicon';
                favicon.src = `https://www.google.com/s2/favicons?sz=32&domain=${encodeURIComponent(host)}`;
                favicon.alt = '';
                favicon.loading = 'lazy';

                const nome = document.createElement('span');
                nome.className = 'cb-lista-bloqueio-host';
                nome.textContent = host;

                const tag = document.createElement('span');
                tag.className = 'cb-lista-bloqueio-tag cb-lista-bloqueio-tag--' + estado;
                tag.textContent = estado === 'bloqueado' ? 'bloqueado' : 'liberado';

                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'cb-lista-bloqueio-btn';
                btn.textContent = 'Desfazer';
                btn.title = 'Volta a perguntar da próxima vez que você abrir esse site';
                btn.addEventListener('click', () => {
                    chrome.runtime.sendMessage({ action: 'cbEsquecerDecisaoSite', host }, () => {
                        cbRenderizarListaBloqueio();
                    });
                });

                item.appendChild(favicon);
                item.appendChild(nome);
                item.appendChild(tag);
                item.appendChild(btn);
                listaBloqueioEl.appendChild(item);
            };

            bloqueados.forEach((h) => criarItem(h, 'bloqueado'));
            liberados.forEach((h) => criarItem(h, 'liberado'));
        });
    }

    cbRenderizarListaBloqueio();
    chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local' && (changes[CB_BLOQUEIO_LISTA_KEY] || changes[CB_LIBERADOS_KEY])) {
            cbRenderizarListaBloqueio();
        }
    });

    // ===================== PEDIDO PRA COMPARTILHAR (a cada 30 dias) =====================
    // "Não deixe esta extensão morrer" — de tempos em tempos (30 dias),
    // lembra a pessoa de indicar pra um amigo/familiar. Sem botão de fechar:
    // só arrasta pro lado (igual ao aviso de novidade), e isso já reseta a
    // contagem de 30 dias — clicar em "Compartilhar" também reseta, então
    // não repete o pedido logo em seguida de quem já compartilhou.
    (function cbAvisoCompartilharSwipe() {
        const aviso = document.getElementById('cb-compartilhar-banner');
        const link = document.getElementById('cb-compartilhar-banner-link');
        if (!aviso || !link || !chrome?.storage) return;

        const CHAVE = 'cbAvisoCompartilharUltimaExibicao';
        const TRINTA_DIAS_MS = 30 * 24 * 60 * 60 * 1000;
        const LIMIAR = 56; // px arrastados até soltar contar como "dispensar"

        const linkExtensao = 'https://addons.mozilla.org/pt-BR/firefox/addon/concurseiro-blindado-anal%C3%ADtico/';
        link.href = `https://wa.me/?text=${encodeURIComponent(`Olha essa extensão que uso pra estudar pra concurso: ${linkExtensao}`)}`;

        function resetarContagem() {
            chrome.storage.local.set({ [CHAVE]: Date.now() });
        }
        link.addEventListener('click', resetarContagem);

        chrome.storage.local.get([CHAVE], (res) => {
            const ultima = res[CHAVE];
            // Primeira vez que essa lógica roda (sem timestamp salvo): grava
            // agora e NÃO mostra ainda. Assim quem já vem usando a extensão
            // há tempos não toma esse pedido de supetão assim que atualiza
            // pra essa versão — o primeiro pedido de verdade só aparece
            // depois de 30 dias contados a partir de agora.
            if (!ultima) { resetarContagem(); return; }
            if ((Date.now() - ultima) < TRINTA_DIAS_MS) return;

            aviso.style.display = 'flex';

            let startX = 0, startY = 0, currentX = 0, dragging = false, lockedHorizontal = null, pointerId = null;

            function setX(x, animar) {
                currentX = x;
                aviso.style.transition = animar ? 'transform 0.2s cubic-bezier(.22,1,.36,1)' : 'none';
                aviso.style.transform = `translateX(${currentX}px)`;
                aviso.style.opacity = String(Math.max(0.25, 1 - Math.abs(currentX) / 160));
            }

            function dispensar(direcao) {
                aviso.style.transition = 'transform 0.18s ease-in, opacity 0.18s ease-in';
                aviso.style.transform = `translateX(${direcao * 120}%)`;
                aviso.style.opacity = '0';
                setTimeout(() => {
                    aviso.style.transition = 'max-height 0.2s ease, margin 0.2s ease, padding 0.2s ease, border-width 0.2s ease';
                    aviso.style.overflow = 'hidden';
                    aviso.style.maxHeight = aviso.scrollHeight + 'px';
                    requestAnimationFrame(() => {
                        aviso.style.maxHeight = '0px';
                        aviso.style.margin = '0';
                        aviso.style.padding = '0';
                        aviso.style.borderWidth = '0';
                    });
                    setTimeout(() => aviso.remove(), 220);
                }, 180);
                resetarContagem();
            }

            function onPointerDown(e) {
                if (e.button !== undefined && e.button !== 0) return;
                if (e.target.closest('a')) return; // deixa o link "Compartilhar" funcionar normal
                dragging = true;
                lockedHorizontal = null;
                startX = e.clientX;
                startY = e.clientY;
                pointerId = e.pointerId;
                aviso.style.transition = 'none';
            }

            function onPointerMove(e) {
                if (!dragging) return;
                const dx = e.clientX - startX;
                const dy = e.clientY - startY;

                if (lockedHorizontal === null) {
                    if (Math.abs(dx) < 6 && Math.abs(dy) < 6) return;
                    lockedHorizontal = Math.abs(dx) > Math.abs(dy);
                    if (lockedHorizontal && aviso.setPointerCapture && pointerId !== null) {
                        try { aviso.setPointerCapture(pointerId); } catch (err) {}
                    }
                }
                if (!lockedHorizontal) return; // rolagem vertical, deixa passar

                e.preventDefault();
                setX(dx, false);
            }

            function finalizarArraste() {
                if (!dragging) return;
                dragging = false;
                if (lockedHorizontal && Math.abs(currentX) >= LIMIAR) {
                    dispensar(currentX < 0 ? -1 : 1);
                } else {
                    setX(0, true);
                    aviso.style.opacity = '1';
                }
                lockedHorizontal = null;
            }

            aviso.addEventListener('pointerdown', onPointerDown);
            aviso.addEventListener('pointermove', onPointerMove);
            aviso.addEventListener('pointerup', finalizarArraste);
            aviso.addEventListener('pointercancel', finalizarArraste);
            aviso.addEventListener('pointerleave', (e) => {
                if (dragging && e.buttons === 0) finalizarArraste();
            });
        });
    })();

    // ===================== AVISO DE ATUALIZAÇÃO DISPONÍVEL =====================
    // background.js checa a cada 1h (e uma vez ao iniciar) a versão publicada
    // na AMO e grava em cbUpdateDisponivel se for mais nova que a instalada
    // (ver cbChecarAtualizacaoAMO em dados-config/background.js). O aviso NÃO leva à loja:
    // pede para a pessoa ligar "Atualizar automaticamente" em about:addons (a extensão não
    // consegue abrir essa página sozinha, por isso o botão copia o endereço) e explica por
    // que atualizar importa. "Ver passo a passo" abre atualizacao.html (mesma tela do aviso
    // de 48 h). Dispensar marca só aquela versão como "já vista" — se sair uma versão mais
    // nova ainda, o aviso volta a aparecer.
    (function cbAvisoAtualizacao() {
        const banner = document.getElementById('cb-update-banner');
        const versaoEl = document.getElementById('cb-update-versao');
        const btnFechar = document.getElementById('cb-update-fechar');
        const btnCopiar = document.getElementById('cb-update-copiar');
        const btnGuia = document.getElementById('cb-update-guia');
        if (!banner || !chrome?.storage) return;

        chrome.storage.local.get(['cbUpdateDisponivel', 'cbUpdateDispensadaVersao'], (result) => {
            const info = result.cbUpdateDisponivel;
            if (!info || !info.versao || info.versao === result.cbUpdateDispensadaVersao) return;
            versaoEl.textContent = 'v' + String(info.versao).replace(/[^\w.\-]/g, '');
            banner.style.display = 'block';
        });

        btnGuia?.addEventListener('click', () => {
            chrome.tabs.create({ url: chrome.runtime.getURL('interface-popup/atualizacao.html') });
        });

        btnCopiar?.addEventListener('click', async () => {
            try { await navigator.clipboard.writeText('about:addons'); } catch (e) { /* sem permissão de área de transferência */ }
            const antes = btnCopiar.textContent;
            btnCopiar.textContent = 'Copiado ✓';
            setTimeout(() => { btnCopiar.textContent = antes; }, 2000);
        });

        btnFechar?.addEventListener('click', () => {
            banner.style.display = 'none';
            chrome.storage.local.get(['cbUpdateDisponivel'], (result) => {
                if (result.cbUpdateDisponivel?.versao) {
                    chrome.storage.local.set({ cbUpdateDispensadaVersao: result.cbUpdateDisponivel.versao });
                }
            });
        });
    })();

    // ===================== AVISO DE INATIVIDADE ("sumiço") =====================
    // Se passou 1 dia inteiro sem abrir a extensão, mostra um aviso carinhoso
    // no topo, uma vez só (a próxima abertura já reseta a contagem — só volta
    // a aparecer se a pessoa sumir de novo por mais 1 dia). Se tiver o Modo
    // Edital Aberto configurado, menciona os dias que faltam pra prova; senão,
    // só incentiva e aponta pras abas Acalmar/Foco caso seja ansiedade/falta
    // de foco o motivo do sumiço.
    (function cbAvisoInatividade() {
        const banner = document.getElementById('cb-inatividade-banner');
        const texto = document.getElementById('cb-inatividade-texto');
        const btnFechar = document.getElementById('cb-inatividade-fechar');
        if (!banner || !texto || !chrome?.storage) return;

        const UM_DIA_MS = 24 * 60 * 60 * 1000;
        const agora = Date.now();

        chrome.storage.local.get(['cbUltimaAberturaPopup'], (result) => {
            const ultima = result.cbUltimaAberturaPopup;
            chrome.storage.local.set({ cbUltimaAberturaPopup: agora });
            if (!ultima || (agora - ultima) < UM_DIA_MS) return;

            chrome.storage.sync.get(['editalConfig'], (syncResult) => {
                const config = syncResult.editalConfig;
                const abertura = 'Está tudo bem com você? Fiquei preocupado — faz um tempo que você não estuda comigo.';
                if (config && config.examDate) {
                    const hoje = new Date(); hoje.setHours(0, 0, 0, 0);
                    const dataProva = new Date(config.examDate + 'T00:00:00');
                    const diasRestantes = Math.ceil((dataProva - hoje) / 86400000);
                    texto.innerText = diasRestantes > 0
                        ? `${abertura} Faltam ${diasRestantes} dia${diasRestantes === 1 ? '' : 's'} para a sua prova — não para agora!`
                        : abertura;
                } else {
                    texto.innerText = `${abertura} Se estiver com ansiedade ou dificuldade de foco, dá uma olhada nas abas "Acalmar" e "Foco" aqui embaixo.`;
                }
                banner.style.display = 'flex';
            });
        });

        btnFechar?.addEventListener('click', () => { banner.style.display = 'none'; });
    })();

    // ===================== SUGESTÃO DE SOM AMBIENTE (aprende com o uso) =====================
    // Olha o histórico de quando a pessoa liga o som ambiente (hora do dia,
    // atividade e qual som) e, se hoje bater com um padrão claro, sugere
    // ligar automaticamente — sem repetir a sugestão no mesmo dia se ela
    // recusar, e "aprendendo" a parar de sugerir num contexto específico se
    // for recusado muitas vezes ali.
    (function cbSugestaoSomAmbiente() {
        const banner = document.getElementById('cb-som-sugestao-banner');
        const texto = document.getElementById('cb-som-sugestao-texto');
        const btnSim = document.getElementById('cb-som-sugestao-sim');
        const btnNao = document.getElementById('cb-som-sugestao-nao');
        if (!banner || !texto || !chrome?.storage) return;

        const SOM_LABEL = { white: 'Ruído Branco', rain: 'Chuva', wind: 'Vento', thunder: 'Trovão', lofi: 'Rádio Lo-Fi' };
        const hojeStr = () => {
            const d = new Date();
            return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
        };

        chrome.storage.local.get(
            ['cbSomUsoLog', 'cbSomSugestaoDispensadaEm', 'cbSomSugestaoRecusas', 'activeActivity', 'sessionState'],
            (result) => {
                chrome.storage.sync.get(['soundEnabled'], (syncResult) => {
                    if (syncResult.soundEnabled) return; // já está ligado, nada a sugerir
                    if (result.cbSomSugestaoDispensadaEm === hojeStr()) return; // já recusou hoje

                    const log = result.cbSomUsoLog || [];
                    if (log.length < 3) return; // pouco histórico ainda pra sugerir com confiança

                    const horaAtual = new Date().getHours();
                    const atividadeAtual = result.activeActivity || 'questoes';
                    const recusas = result.cbSomSugestaoRecusas || {};

                    const porHora = log.filter(e => Math.abs(e.hora - horaAtual) <= 1 || Math.abs(e.hora - horaAtual) >= 23);
                    const porAtividade = log.filter(e => e.atividade === atividadeAtual);

                    let motivo = null, relevantes = null, chaveContexto = null;
                    if (porHora.length >= 3) { motivo = 'hora'; relevantes = porHora; chaveContexto = `hora_${horaAtual}`; }
                    else if (porAtividade.length >= 4) { motivo = 'atividade'; relevantes = porAtividade; chaveContexto = `atividade_${atividadeAtual}`; }
                    if (!motivo) return;

                    // "Aprendizado" simples: se já recusou muitas vezes exatamente
                    // nesse contexto, para de insistir nele.
                    if ((recusas[chaveContexto] || 0) >= 3) return;

                    // Som mais usado dentro do grupo relevante.
                    const contagem = {};
                    relevantes.forEach(e => { contagem[e.som] = (contagem[e.som] || 0) + 1; });
                    const somSugerido = Object.keys(contagem).sort((a, b) => contagem[b] - contagem[a])[0] || 'white';
                    const label = SOM_LABEL[somSugerido] || 'Ruído Branco';

                    texto.innerText = motivo === 'hora'
                        ? `Você costuma usar som ambiente (${label}) por volta desse horário. Quer ativar agora?`
                        : `Você costuma usar som ambiente (${label}) enquanto ${atividadeAtual === 'questoes' ? 'resolve questões' : 'lê'}. Quer ativar agora?`;
                    banner.style.display = 'block';
                    // Marca como "já mostrada hoje" assim que aparece — antes só
                    // marcava quando a pessoa clicava "Agora não", então se ela
                    // só ignorasse o banner e fechasse o popup, a sugestão
                    // voltava a aparecer TODA vez que o popup fosse reaberto no
                    // mesmo dia (o que, num popup que se reabre várias vezes por
                    // hora, parecia "ficar perguntando toda hora").
                    chrome.storage.local.set({ cbSomSugestaoDispensadaEm: hojeStr() });

                    btnSim?.addEventListener('click', () => {
                        currentSoundType = somSugerido;
                        marcarSoundTypeAtivo(currentSoundType);
                        chkSound.checked = true;
                        chkSound.dispatchEvent(new Event('change'));
                        banner.style.display = 'none';
                    }, { once: true });

                    btnNao?.addEventListener('click', () => {
                        recusas[chaveContexto] = (recusas[chaveContexto] || 0) + 1;
                        chrome.storage.local.set({
                            cbSomSugestaoDispensadaEm: hojeStr(),
                            cbSomSugestaoRecusas: recusas
                        });
                        banner.style.display = 'none';
                    }, { once: true });
                });
            }
        );
    })();

    // ===================== AVISO DE META DIÁRIA (dias seguidos sem bater) =====================
    // Só aparece quando há um padrão de verdade: 3 ou mais dias SEGUIDOS
    // (contando pra trás a partir de ontem — hoje ainda não acabou, não é
    // justo contar contra a pessoa) abaixo da meta diária. E, seguindo o
    // pedido de "nada de mensagem irritante ou desnecessária", ele sempre
    // vem com uma ação concreta: ajustar a meta pra bater com a média real
    // recente (calculada na hora, não um número arbitrário), ou ir direto
    // organizar um horário fixo de estudo. Um aviso por semana é mais que
    // suficiente pra esse tipo de padrão — bem diferente do de som
    // ambiente, que é sobre um hábito do dia a dia.
    (function cbAvisoMetaStreak() {
        const banner = document.getElementById('cb-meta-streak-banner');
        const texto = document.getElementById('cb-meta-streak-texto');
        const btnAjustar = document.getElementById('cb-meta-streak-ajustar');
        const btnOrganizar = document.getElementById('cb-meta-streak-organizar');
        const btnFechar = document.getElementById('cb-meta-streak-fechar');
        if (!banner || !texto || !chrome?.storage) return;

        const dataMenosDias = (n) => {
            const d = new Date();
            d.setDate(d.getDate() - n);
            return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
        };
        const formatarHoras = (ms) => {
            const totalMin = Math.round(ms / 60000);
            const h = Math.floor(totalMin / 60), m = totalMin % 60;
            return m ? `${h}h${String(m).padStart(2, '0')}` : `${h}h`;
        };

        chrome.storage.local.get(['studyHistory', 'cbMetaStreakAvisadoEm'], (localResult) => {
            const ultimoAviso = localResult.cbMetaStreakAvisadoEm || 0;
            if (Date.now() - ultimoAviso < 4 * 24 * 60 * 60 * 1000) return; // já avisou essa semana

            chrome.storage.sync.get(['dailyGoalMs'], (syncResult) => {
                const goalMs = syncResult.dailyGoalMs || (4 * 60 * 60 * 1000);
                const history = localResult.studyHistory || {};

                let streak = 0;
                for (let i = 1; i <= 7; i++) {
                    const dado = history[dataMenosDias(i)];
                    // Sem registro nesse dia = a extensão ainda não tinha
                    // histórico (instalação recente, por exemplo) — não dá
                    // pra tratar como "0h estudadas", senão uma instalação
                    // nova já nasce com "7 dias seguidos abaixo da meta".
                    if (dado === undefined) break;
                    if (dado < goalMs) streak++;
                    else break;
                }
                if (streak < 3) return;

                // Média real dos últimos dias com dado registrado — é a base
                // pra sugerir uma meta que a pessoa realmente consiga bater,
                // em vez de só apontar o problema sem ajudar a resolver.
                let somaMs = 0, diasComDado = 0;
                for (let i = 0; i <= 6; i++) {
                    const dado = history[dataMenosDias(i)];
                    if (dado !== undefined) { somaMs += dado; diasComDado++; }
                }
                const mediaMs = diasComDado ? somaMs / diasComDado : 0;
                const metaSugeridaHoras = Math.max(0.5, Math.floor((mediaMs / (60 * 60 * 1000)) * 2) / 2);
                const metaSugeridaMs = Math.round(metaSugeridaHoras * 60 * 60 * 1000);

                texto.innerText = `Você ficou ${streak} dias seguidos abaixo da meta diária (${formatarHoras(goalMs)}). Sua média real nos últimos dias foi ${formatarHoras(mediaMs)} — talvez seja hora de ajustar a meta ou fixar um horário de estudo.`;
                if (btnAjustar) btnAjustar.textContent = `Ajustar meta para ${formatarHoras(metaSugeridaMs)}`;
                banner.style.display = 'flex'; // o cartão agora é flex (ícone + corpo lado a lado)
                // Marca que já avisou essa semana assim que aparece na tela —
                // não só quando a pessoa responde (mesma lição do aviso de
                // som ambiente acima: senão volta a cada popup reaberto).
                chrome.storage.local.set({ cbMetaStreakAvisadoEm: Date.now() });

                btnAjustar?.addEventListener('click', () => {
                    chrome.storage.sync.set({ dailyGoalMs: metaSugeridaMs }, () => {
                        dailyGoalMs = metaSugeridaMs;
                        atualizarLabelMeta();
                        updateGoalProgress();
                        renderChart();
                        banner.style.display = 'none';
                    });
                }, { once: true });

                btnOrganizar?.addEventListener('click', () => {
                    chrome.tabs.create({ url: chrome.runtime.getURL('rotina/rotina-diaria.html') });
                    banner.style.display = 'none';
                }, { once: true });

                btnFechar?.addEventListener('click', () => { banner.style.display = 'none'; }, { once: true });
            });
        });
    })();

    // ===================== AVISO "ATIVE ANIMAÇÃO DO WINDOWS" (planeta) =====================
    // Se a pessoa desligou "Efeitos de animação" no Windows, o Chrome
    // reflete isso em prefers-reduced-motion e a animação do planeta
    // (planeta.css) simplesmente não roda — e não só a animação: os dois
    // clarões que escondem o corte entre o vídeo de transição e a cena
    // real (".cb-flash-final"/".cb-flash-atmosfera-ativo") também se
    // desligam sozinhos nesse modo (ver planeta.css, cada um tem seu
    // "@media (prefers-reduced-motion: reduce)"), deixando o corte cru,
    // visível. Por isso este aviso importa de verdade, não é só estética.
    //
    // Exibição: continua aparecendo só UMA VEZ pra cada pessoa — isso não
    // mudou. O que mudou foi COMO essa "uma vez" é decidida. ERA: uma flag
    // gravada só na instalação/atualização (chrome.runtime.onInstalled),
    // consumida na primeira abertura do popup depois disso, não importa se
    // a condição batia ou não. Frágil: se por QUALQUER motivo essa única
    // abertura não contasse direito (popup fechado rápido demais, o
    // matchMedia lido antes do Windows/Chrome terminar de sincronizar a
    // config, etc.), a flag já tinha sido consumida e o aviso não aparecia
    // NUNCA MAIS — mesmo com as animações desligadas pra sempre, quem
    // precisava do aviso ficava sem explicação nenhuma pro corte visível.
    //
    // AGORA: não depende de nenhuma flag de instalação. Toda abertura do
    // popup reavalia a condição de verdade (prefers-reduced-motion) do
    // zero; assim que ela bate pela PRIMEIRA vez, grava a flag de "já
    // mostrado" ali mesmo (antes até de esperar a pessoa interagir) e só
    // então exibe — ou seja, ele só aparece de fato quando a condição
    // realmente se aplica (nunca "gasta" a única chance à toa, tipo animação
    // já ligada), mas quando aparece, é só aquela vez mesmo, igual antes.
    // O arrastar pra dispensar continua existindo (fecha mais rápido, com
    // animação), só não é mais o que decide se ele volta — a flag já foi
    // gravada antes disso.
    (function cbAvisoAnimacaoPlanetaSwipe() {
        const aviso = document.getElementById('cb-animacao-planeta-banner');
        if (!aviso || !chrome?.storage) return;

        const CHAVE = 'cbAvisoAnimacaoDispensado';
        const LIMIAR = 56; // px arrastados até soltar contar como "dispensar"

        chrome.storage.local.get([CHAVE, 'cbEstiloTimer'], (res) => {
            // Dispensado de vez pela própria pessoa — não insiste mais.
            if (res[CHAVE]) { aviso.remove(); return; }

            // O planeta agora é OPCIONAL (padrão é o círculo clássico, sem
            // planeta.css nenhum) — pra quem está no círculo, esse aviso
            // não faz sentido nenhum, já que a animação que ele explica nem
            // roda nesse modo. Só mostra pra quem ligou "Planeta" nas
            // Configurações → Aparência.
            if (res.cbEstiloTimer !== 'planeta') { aviso.remove(); return; }

            // Só faz sentido mostrar pra quem realmente está com animações
            // do sistema desligadas AGORA — pra quem já tem tudo ligado, o
            // planeta anima normal e o aviso não se aplica. Reavaliado do
            // zero a cada abertura (não depende de nenhuma flag de
            // instalação/atualização), então funciona igual não importa
            // quando a pessoa instalou a extensão ou quantas vezes já abriu
            // o popup antes.
            const reduzMovimento = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
            if (!reduzMovimento) { aviso.remove(); return; }

            // Pra aparecer só UMA VEZ (pedido explícito — não é pra ficar
            // voltando toda abertura até alguém arrastar), marca como
            // "dispensado" imediatamente aqui, assim que a condição bate e a
            // decisão de mostrar é tomada — não só quando a pessoa arrasta
            // pra fechar. O gesto de arrastar continua funcionando (fecha
            // mais rápido, com a animação de saída), mas não é mais o que
            // decide se ele volta ou não: some da próxima vez de qualquer
            // jeito, arrastado ou não.
            chrome.storage.local.set({ [CHAVE]: true });

            aviso.style.display = 'flex';

            let startX = 0, startY = 0, currentX = 0, dragging = false, lockedHorizontal = null, pointerId = null;

            function setX(x, animar) {
                currentX = x;
                aviso.style.transition = animar ? 'transform 0.2s cubic-bezier(.22,1,.36,1)' : 'none';
                aviso.style.transform = `translateX(${currentX}px)`;
                aviso.style.opacity = String(Math.max(0.25, 1 - Math.abs(currentX) / 160));
            }

            function dispensar(direcao) {
                aviso.style.transition = 'transform 0.18s ease-in, opacity 0.18s ease-in';
                aviso.style.transform = `translateX(${direcao * 120}%)`;
                aviso.style.opacity = '0';
                setTimeout(() => {
                    aviso.style.transition = 'max-height 0.2s ease, margin 0.2s ease, padding 0.2s ease, border-width 0.2s ease';
                    aviso.style.overflow = 'hidden';
                    aviso.style.maxHeight = aviso.scrollHeight + 'px';
                    requestAnimationFrame(() => {
                        aviso.style.maxHeight = '0px';
                        aviso.style.margin = '0';
                        aviso.style.padding = '0';
                        aviso.style.borderWidth = '0';
                    });
                    setTimeout(() => aviso.remove(), 220);
                }, 180);
                // A flag já foi gravada assim que o aviso decidiu aparecer
                // (logo depois do check de prefers-reduced-motion, mais
                // acima) — ele só mostra uma vez, arrastado ou não. Regrava
                // aqui de novo só por segurança (idempotente), caso esta
                // função algum dia seja chamada por outro caminho.
                chrome.storage.local.set({ [CHAVE]: true });
            }

            function onPointerDown(e) {
                if (e.button !== undefined && e.button !== 0) return;
                dragging = true;
                lockedHorizontal = null;
                startX = e.clientX;
                startY = e.clientY;
                pointerId = e.pointerId;
                aviso.style.transition = 'none';
            }

            function onPointerMove(e) {
                if (!dragging) return;
                const dx = e.clientX - startX;
                const dy = e.clientY - startY;

                if (lockedHorizontal === null) {
                    if (Math.abs(dx) < 6 && Math.abs(dy) < 6) return;
                    lockedHorizontal = Math.abs(dx) > Math.abs(dy);
                    if (lockedHorizontal && aviso.setPointerCapture && pointerId !== null) {
                        try { aviso.setPointerCapture(pointerId); } catch (err) {}
                    }
                }
                if (!lockedHorizontal) return; // rolagem vertical, deixa passar

                e.preventDefault();
                setX(dx, false);
            }

            function finalizarArraste() {
                if (!dragging) return;
                dragging = false;
                if (lockedHorizontal && Math.abs(currentX) >= LIMIAR) {
                    dispensar(currentX < 0 ? -1 : 1);
                } else {
                    setX(0, true);
                    aviso.style.opacity = '1';
                }
                lockedHorizontal = null;
            }

            aviso.addEventListener('pointerdown', onPointerDown);
            aviso.addEventListener('pointermove', onPointerMove);
            aviso.addEventListener('pointerup', finalizarArraste);
            aviso.addEventListener('pointercancel', finalizarArraste);
            aviso.addEventListener('pointerleave', (e) => {
                if (dragging && e.buttons === 0) finalizarArraste();
            });
        });
    })();

    // ===================== AVISO "COMPARTILHE COM UM AMIGO" (a cada 7 dias; arrastar p/ sumir) =====================
    // Fica no topo do popup. Não tem botão de fechar: arrasta para qualquer lado (como um cartão de notificação de celular)
    // e ele desliza para fora. Dispensar OU tocar em "Compartilhar" reinicia a contagem: só volta depois de 7 dias.
    // A contagem começa no primeiro uso (nada de aparecer logo na instalação).
    (function cbAvisoCompartilhar() {
        const aviso = document.getElementById('cb-aviso-compartilhar');
        if (!aviso || !chrome?.storage) return;

        const CHAVE = 'cbCompartilharUltimo';          // última vez que foi dispensado ou usado
        const PRIMEIRO = 'cbCompartilharPrimeiroUso';  // primeira vez que o popup abriu
        const INTERVALO_MS = 7 * 24 * 3600 * 1000;
        const LIMIAR = 56; // px arrastados até soltar contar como "dispensar"

        const linkExtensao = 'https://addons.mozilla.org/pt-BR/firefox/addon/concurseiro-blindado-anal%C3%ADtico/';
        const botao = document.getElementById('cb-compartilhar-wa');
        if (botao) {
            botao.href = `https://wa.me/?text=${encodeURIComponent('Olha essa extensão que uso pra estudar pra concurso: ' + linkExtensao)}`;
            botao.addEventListener('click', () => chrome.storage.local.set({ [CHAVE]: Date.now() }));
        }

        chrome.storage.local.get([CHAVE, PRIMEIRO], (res) => {
            if (!res[PRIMEIRO]) { chrome.storage.local.set({ [PRIMEIRO]: Date.now() }); return; }
            if (Date.now() - (res[CHAVE] || res[PRIMEIRO]) < INTERVALO_MS) return;
            aviso.style.display = 'flex';

            let startX = 0, startY = 0, currentX = 0, dragging = false, lockedHorizontal = null, pointerId = null;

            function setX(x, animar) {
                currentX = x;
                aviso.style.transition = animar ? 'transform 0.2s cubic-bezier(.22,1,.36,1)' : 'none';
                aviso.style.transform = `translateX(${currentX}px)`;
                aviso.style.opacity = String(Math.max(0.25, 1 - Math.abs(currentX) / 160));
            }

            function dispensar(direcao) {
                aviso.style.transition = 'transform 0.18s ease-in, opacity 0.18s ease-in';
                aviso.style.transform = `translateX(${direcao * 120}%)`;
                aviso.style.opacity = '0';
                // encolhe o espaço só depois do cartão sumir, pra não dar
                // um "pulo" feio no conteúdo embaixo enquanto ainda desliza.
                setTimeout(() => {
                    aviso.style.transition = 'max-height 0.2s ease, margin 0.2s ease, padding 0.2s ease, border-width 0.2s ease';
                    aviso.style.overflow = 'hidden';
                    aviso.style.maxHeight = aviso.scrollHeight + 'px';
                    requestAnimationFrame(() => {
                        aviso.style.maxHeight = '0px';
                        aviso.style.margin = '0';
                        aviso.style.padding = '0';
                        aviso.style.borderWidth = '0';
                    });
                    setTimeout(() => aviso.remove(), 220);
                }, 180);
                chrome.storage.local.set({ [CHAVE]: Date.now() });
            }

            function onPointerDown(e) {
                if (e.button !== undefined && e.button !== 0) return;
                dragging = true;
                lockedHorizontal = null;
                startX = e.clientX;
                startY = e.clientY;
                pointerId = e.pointerId;
                aviso.style.transition = 'none';
            }

            function onPointerMove(e) {
                if (!dragging) return;
                const dx = e.clientX - startX;
                const dy = e.clientY - startY;

                if (lockedHorizontal === null) {
                    if (Math.abs(dx) < 6 && Math.abs(dy) < 6) return;
                    lockedHorizontal = Math.abs(dx) > Math.abs(dy);
                    if (lockedHorizontal && aviso.setPointerCapture && pointerId !== null) {
                        try { aviso.setPointerCapture(pointerId); } catch (err) {}
                    }
                }
                if (!lockedHorizontal) return; // rolagem vertical, deixa passar

                e.preventDefault();
                setX(dx, false);
            }

            function finalizarArraste() {
                if (!dragging) return;
                dragging = false;
                if (lockedHorizontal && Math.abs(currentX) >= LIMIAR) {
                    dispensar(currentX < 0 ? -1 : 1);
                } else {
                    setX(0, true);
                    aviso.style.opacity = '1';
                }
                lockedHorizontal = null;
            }

            aviso.addEventListener('pointerdown', onPointerDown);
            aviso.addEventListener('pointermove', onPointerMove);
            aviso.addEventListener('pointerup', finalizarArraste);
            aviso.addEventListener('pointercancel', finalizarArraste);
            aviso.addEventListener('pointerleave', (e) => {
                if (dragging && e.buttons === 0) finalizarArraste();
            });
        });
    })();

    // ===================== BOAS-VINDAS / TUTORIAL (primeira instalação) =====================
    // Só aparece uma vez, na primeira vez que a pessoa abre o popup depois
    // de instalar a extensão (flag marcada por background.js no
    // chrome.runtime.onInstalled com reason "install" — nunca dispara de
    // novo numa atualização de versão). A pessoa escolhe se quer ver um
    // tutorial rápido (3 passos) ou pular direto pro uso normal.
    (function cbOnboarding() {
        const overlay = document.getElementById('cb-onboarding-overlay');
        const sparklesWrap = document.getElementById('cb-onboarding-sparkles');
        const nav = document.getElementById('cb-onboarding-nav');
        const btnVoltar = document.getElementById('cb-onboarding-voltar');
        const btnProximo = document.getElementById('cb-onboarding-proximo');
        const btnVerTutorial = document.getElementById('cb-onboarding-ver-tutorial');
        const btnPular = document.getElementById('cb-onboarding-pular');
        const btnComecar = document.getElementById('cb-onboarding-comecar');
        const steps = overlay ? Array.from(overlay.querySelectorAll('.cb-onboarding-step')) : [];
        const dots = overlay ? Array.from(overlay.querySelectorAll('.cb-onboarding-dot')) : [];
        if (!overlay || !chrome?.storage || !steps.length) return;

        let passoAtual = 0;

        function cbOnbIrParaPasso(n) {
            passoAtual = n;
            steps.forEach(s => s.classList.toggle('is-active', Number(s.dataset.step) === n));
            dots.forEach(d => d.classList.toggle('is-active', Number(d.dataset.dot) === n));
            // A navegação Voltar/Próximo só faz sentido nos passos do meio
            // (1 e 2) — o passo 0 (boas-vindas) e o último (fechamento) já
            // têm seus próprios botões de ação.
            if (nav) nav.style.display = (n === 1 || n === 2) ? 'flex' : 'none';
            if (btnVoltar) btnVoltar.style.visibility = n <= 1 ? 'hidden' : 'visible';
        }

        function cbOnbGerarSparkles() {
            if (!sparklesWrap || sparklesWrap.childElementCount) return;
            for (let i = 0; i < 14; i++) {
                const s = document.createElement('span');
                s.className = 'cb-onboarding-spark';
                s.style.left = `${Math.round(Math.random() * 100)}%`;
                s.style.top = `${Math.round(Math.random() * 100)}%`;
                s.style.animationDelay = `${(Math.random() * 2.6).toFixed(2)}s`;
                sparklesWrap.appendChild(s);
            }
        }

        function cbOnbAbrir() {
            cbOnbIrParaPasso(0);
            cbOnbGerarSparkles();
            overlay.classList.add('is-open');
        }

        function cbOnbFechar() {
            overlay.style.opacity = '0';
            setTimeout(() => {
                overlay.classList.remove('is-open');
                overlay.style.opacity = '';
            }, 320);
            chrome.storage.local.set({ cbOnboardingPendente: false, cbOnboardingSeen: true });
        }

        btnVerTutorial?.addEventListener('click', () => cbOnbIrParaPasso(1));
        btnPular?.addEventListener('click', cbOnbFechar);
        btnComecar?.addEventListener('click', cbOnbFechar);
        btnProximo?.addEventListener('click', () => cbOnbIrParaPasso(Math.min(3, passoAtual + 1)));
        btnVoltar?.addEventListener('click', () => cbOnbIrParaPasso(Math.max(0, passoAtual - 1)));

        // Link em Configurações → Ajuda & Privacidade pra rever o tutorial
        // quando quiser — vai direto pro conteúdo (pula a telinha de "quer
        // ver o tutorial?", já que a pessoa pediu isso explicitamente).
        document.getElementById('btn-ver-tutorial-novamente')?.addEventListener('click', () => {
            document.getElementById('settings-modal-overlay')?.classList.remove('open');
            cbOnbGerarSparkles();
            cbOnbIrParaPasso(1);
            overlay.classList.add('is-open');
        });

        chrome.storage.local.get(['cbOnboardingPendente'], (result) => {
            if (result.cbOnboardingPendente) cbOnbAbrir();
        });
    })();

    // O prompt "Quer bloquear este site?" que ficava aqui foi REMOVIDO.
    // Ele agora aparece na própria página do site que você está visitando
    // (cbMostrarPerguntaBloqueio, em overlay-global/global_overlay.js), que
    // é onde a decisão faz sentido — e é uma pergunta só, gravando numa
    // lista só. Ver a lista "Sites bloqueados" na aba Foco pra desfazer.

    function cbAtualizarBadgeModo(method) {
        if (!cbModoAuto) return;
        const online = method === 'online';
        cbModoAuto.classList.toggle('is-online', online);
        cbModoAuto.classList.toggle('is-offline', !online);
        if (cbModoAutoText) {
            cbModoAutoText.textContent = online
                ? 'Online (site de questões)'
                : 'Offline (tela bloqueada)';
        }
    }

    function cbSincronizarModoAutomatico(callback) {
        chrome.storage.local.get(['cbInterfaceMode'], (modoResult) => {
            if (modoResult.cbInterfaceMode === 'antigo') {
                // No "Modo Antigo" a pessoa escolhe Modo/Atividade manualmente
                // pelos selects visíveis — não sobrescreve com a detecção
                // automática da aba ativa (essa só vale no modo "Novo").
                cbAtualizarBadgeModo(selectMethod.value);
                atualizarVisibilidadeCamera(selectMethod.value);
                if (typeof callback === 'function') callback(selectMethod.value);
                return;
            }
            cbDetectarModoAtivo((method) => {
                selectMethod.value = method;
                // Atividade segue o mesmo automatismo do Modo: site de questões
                // (Online) → "Resolução de Questões"; qualquer outro (Offline) →
                // "Leitura". Sem seleção manual, então nada aparece na tela.
                selectActivity.value = method === 'online' ? 'questoes' : 'leitura';
                cbAtualizarBadgeModo(method);
                atualizarVisibilidadeCamera(method);
                if (typeof callback === 'function') callback(method);
            });
        });
    }

    const goalText = document.getElementById('goal-text');
    const goalLabelText = document.getElementById('goal-label-text');
    const progressFill = document.getElementById('progress-fill');
    const goalIconChip = document.getElementById('goal-icon-chip');
    const btnExport = document.getElementById('btn-export');
    const btnResetToday = document.getElementById('btn-reset-today');
    const btnEditGoal = document.getElementById('btn-edit-goal');
    const goalEditRow = document.getElementById('goal-edit-row');
    const inputGoalHours = document.getElementById('input-goal-hours');
    const btnSaveGoal = document.getElementById('btn-save-goal');
    const goalModeToggle = document.getElementById('goal-mode-toggle');
    const goalFieldsTempo = document.getElementById('goal-fields-tempo');
    const goalFieldsQuestoes = document.getElementById('goal-fields-questoes');
    const inputGoalQuestoes = document.getElementById('input-goal-questoes');
    const btnSaveGoalQuestoes = document.getElementById('btn-save-goal-questoes');
    const goalMateriasBreakdown = document.getElementById('goal-materias-breakdown');
    const goalMateriasLista = document.getElementById('goal-materias-lista');
    let metaModo = 'tempo';
    let dailyGoalQuestoes = 20;

    const pomodoroSettings = document.getElementById('pomodoro-settings');
    const inputPomoWork = document.getElementById('input-pomo-work');
    const inputPomoRest = document.getElementById('input-pomo-rest');
    const btnSavePomo = document.getElementById('btn-save-pomo');

    // Steppers (+/-) dos campos Foco/Pausa do Pomodoro e da Meta Diária —
    // substituem as setinhas nativas do input[number] (feias e brancas) por
    // botões redondos violeta com seta branca, respeitando min/max/step de
    // cada campo (parseFloat + step, não só inteiros, pra caber a Meta
    // Diária que anda de 0.5 em 0.5).
    document.querySelectorAll('.pomo-stepper-btn').forEach((stepBtn) => {
        stepBtn.addEventListener('click', () => {
            const target = document.getElementById(stepBtn.dataset.target);
            if (!target) return;
            const step = target.step && target.step !== 'any' ? parseFloat(target.step) : 1;
            const casas = (String(step).split('.')[1] || '').length;
            const min = target.min !== '' ? parseFloat(target.min) : -Infinity;
            const max = target.max !== '' ? parseFloat(target.max) : Infinity;
            const atual = parseFloat(target.value) || 0;
            const delta = stepBtn.classList.contains('pomo-stepper-up') ? step : -step;
            const novo = Number(Math.min(max, Math.max(min, atual + delta)).toFixed(casas));
            target.value = novo;
            target.dispatchEvent(new Event('input', { bubbles: true }));
            target.dispatchEvent(new Event('change', { bubbles: true }));
        });
    });

    // Botão discreto do Pomodoro: fica escondida a área inteira (ciclo
    // clássico + Inteligente) até o clique.
    const btnPomoDiscreet = document.getElementById('btn-pomo-discreet');
    const pomodoroToggleBox = document.getElementById('pomodoro-toggle-box');
    const pomodoroInteligenteToggleBox = document.getElementById('pomodoro-inteligente-toggle-box');
    const chkPomodoroInteligente = document.getElementById('chk-pomodoro-inteligente');
    if (btnPomoDiscreet && pomodoroToggleBox) {
        btnPomoDiscreet.addEventListener('click', () => {
            pomodoroToggleBox.classList.remove('pomo-collapsed');
            if (pomodoroInteligenteToggleBox) pomodoroInteligenteToggleBox.classList.remove('pomo-collapsed');
            btnPomoDiscreet.classList.add('hidden');
        });
        // Se algum dos dois ciclos já estiver ativo, mostra a área aberta
        // direto (sem esconder o estado atual).
        chrome.storage.local.get(['pomodoroMode'], (res) => {
            if (res.pomodoroMode) {
                pomodoroToggleBox.classList.remove('pomo-collapsed');
                if (pomodoroInteligenteToggleBox) pomodoroInteligenteToggleBox.classList.remove('pomo-collapsed');
                btnPomoDiscreet.classList.add('hidden');
            }
        });
    }

    // Câmera / Modo Hardcore
    const chkCamera = document.getElementById('chk-camera');
    const chkCameraQuick = document.getElementById('chk-camera-quick');
    const cameraToggleRow = document.getElementById('camera-toggle-row');
    const cameraBatteryRow = document.getElementById('camera-battery-row');
    const cameraBatteryBtns = document.querySelectorAll('#camera-battery-opts button');
    const chkHardcore = document.getElementById('chk-hardcore');
    const chkCameraQuestoesOff = document.getElementById('chk-camera-questoes-off');

    // Som ambiente
    const chkSound = document.getElementById('chk-sound');
    const chkChartAnimations = document.getElementById('chk-chart-animations');
    const chkDockHover = document.getElementById('chk-dock-hover');
    const chkAtalhoCtrlWin = document.getElementById('chk-atalho-ctrl-win');
    const chkSiteHistory = document.getElementById('chk-site-history');
    const chkQcSync = document.getElementById('chk-qc-sync');
    const chkPrivacyNotice = document.getElementById('chk-privacy-notice');
    const soundSettings = document.getElementById('sound-settings');
    const soundTypeBtns = document.querySelectorAll('.sound-type-btn');
    const inputSoundVolume = document.getElementById('input-sound-volume');

    // CB-SomMini: atalho rápido no cabeçalho (ao lado do botão de perfil) pra
    // trocar o som, mexer no volume ou desligar sem abrir Configurações.
    const somMiniWrap = document.getElementById('cb-som-mini');
    const somMiniBtn = document.getElementById('cb-som-mini-btn');
    const somMiniPainel = document.getElementById('cb-som-mini-painel');
    const somMiniTipoBtns = document.querySelectorAll('.cb-som-mini-tipo');
    const somMiniVolume = document.getElementById('cb-som-mini-volume');
    const somMiniVolMenos = document.getElementById('cb-som-mini-vol-menos');
    const somMiniVolMais = document.getElementById('cb-som-mini-vol-mais');
    const somMiniDesligar = document.getElementById('cb-som-mini-desligar');
    let currentSoundType = 'white';

    // Nível / conquistas
    const levelNameText = document.getElementById('level-name-text');
    const levelHoursText = document.getElementById('level-hours-text');
    const levelProgressFill = document.getElementById('level-progress-fill');
    const levelNextText = document.getElementById('level-next-text');
    const btnOpenBadges = document.getElementById('btn-open-badges');
    const badgesModalOverlay = document.getElementById('badges-modal-overlay');
    const badgesModalBody = document.getElementById('badges-modal-body');
    const badgesModalClose = document.getElementById('badges-modal-close');

    const LEVELS = [
        { name: 'Calouro',      hours: 0 },
        { name: 'Iniciante',    hours: 50 },
        { name: 'Aprendiz',     hours: 100 },
        { name: 'Dedicado',     hours: 250 },
        { name: 'Estrategista', hours: 500 },
        { name: 'Auditor',      hours: 1000 },
        { name: 'Mestre',       hours: 2000 },
        { name: 'Lenda',        hours: 3500 }
    ];
    const STREAK_MILESTONES = [3, 7, 14, 30, 60, 100, 180, 365];

    // ===================== SITES BLOQUEADOS (mesma lista, dentro das configurações) =====================
    // ANTES esta lista lia uma chave PRÓPRIA (cbEscolhasExcecaoPorHost),
    // diferente da lista que o bloqueio realmente usava — então "Reverter"
    // aqui não desbloqueava nada de verdade. Agora ela lê e escreve na
    // ÚNICA lista que existe (cbSitesBloqueadosManual + cbSitesLiberados),
    // igual à lista da aba Foco.
    function cbRenderListaSitesBloqueio() {
        const lista = document.getElementById('lista-sites-bloqueio');
        const vazio = document.getElementById('sites-bloqueio-vazio');
        if (!lista) return;
        chrome.storage.local.get([CB_BLOQUEIO_LISTA_KEY, CB_LIBERADOS_KEY], (res) => {
            const bloqueados = res[CB_BLOQUEIO_LISTA_KEY] || [];
            const liberados = res[CB_LIBERADOS_KEY] || [];
            const todos = bloqueados.map(h => ({ host: h, estado: 'bloqueado' }))
                .concat(liberados.map(h => ({ host: h, estado: 'liberado' })));

            lista.innerHTML = '';
            if (vazio) vazio.style.display = todos.length ? 'none' : 'block';

            todos.forEach(({ host, estado }) => {
                // Visual da linha em apple.css (.cfg-site-*): fundo e cor vêm de
                // variáveis de tema, então a lista também aparece no tema Claro.
                const linha = document.createElement('div');
                linha.className = 'cfg-site-linha';

                const nome = document.createElement('span');
                nome.className = 'cfg-site-nome';
                nome.textContent = host + (estado === 'liberado' ? ' (liberado)' : '');

                const btn = document.createElement('button');
                btn.type = 'button';
                btn.className = 'cfg-site-btn';
                btn.textContent = 'Reverter';
                btn.title = 'Volta a perguntar da próxima vez que você abrir esse site';
                btn.addEventListener('click', () => {
                    chrome.runtime.sendMessage({ action: 'cbEsquecerDecisaoSite', host }, cbRenderListaSitesBloqueio);
                });

                linha.appendChild(nome);
                linha.appendChild(btn);
                lista.appendChild(linha);
            });
        });
    }
    cbRenderListaSitesBloqueio();
    chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local' && (changes[CB_BLOQUEIO_LISTA_KEY] || changes[CB_LIBERADOS_KEY])) {
            cbRenderListaSitesBloqueio();
        }
    });

    // Cada nível (a partir do 2º, "Calouro" já vem liberado) destrava, pra
    // quem é FREE, uma ou mais funções PRO específicas — na ordem da menos
    // pra mais relevante, então as funções mais "importantes" só destravam
    // lá na frente. "Questões" nunca é destravada por conquista, só por
    // licença de verdade (pedido explícito).
    const ACHIEVEMENT_FEATURE_MAP = {
        1: ['reorder_tabs', 'reorder_sections'],   // Iniciante
        2: ['themes', 'ambient_sound'],            // Aprendiz
        3: ['edit_daily_goal'],                    // Dedicado
        4: ['calendar', 'breaks_activity'],        // Estrategista
        5: ['monthly_history'],                    // Auditor
        6: ['monthly_productivity', 'hardcore_mode'], // Mestre
        7: ['pomodoro']                            // Lenda
    };

    // ===================== CORES E VISIBILIDADE DO GRÁFICO =====================
    const CHART_PERIOD_COLOR_DEFAULTS = { mad: '#172554', man: '#1e40af', tar: '#3b82f6', noi: '#93c5fd' };
    let chartPeriodColors = { ...CHART_PERIOD_COLOR_DEFAULTS };
    const CHART_STATS_VISIBILITY_DEFAULTS = { total: true, media: true, melhor: true, consistencia: true };
    let chartStatsVisibility = { ...CHART_STATS_VISIBILITY_DEFAULTS };
    let chartLegendTextHidden = false;

    function loadChartDisplayPrefs(callback) {
        chrome.storage.sync.get(['cbChartColors', 'cbChartStatsVisibility', 'cbChartLegendTextHidden'], (result) => {
            chartPeriodColors = { ...CHART_PERIOD_COLOR_DEFAULTS, ...(result.cbChartColors || {}) };
            chartStatsVisibility = { ...CHART_STATS_VISIBILITY_DEFAULTS, ...(result.cbChartStatsVisibility || {}) };
            chartLegendTextHidden = !!result.cbChartLegendTextHidden;
            if (callback) callback();
        });
    }

    let dailyGoalMs = 4 * 60 * 60 * 1000;
    let selectedBarKey = null;

    const tabs = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    const btnChartDay = document.getElementById('btn-chart-day');
    const btnChartWeek = document.getElementById('btn-chart-week');
    const btnChartMonth = document.getElementById('btn-chart-month');
    const btnChartSemester = document.getElementById('btn-chart-semester');

    const chartRender = document.getElementById('chart-render');
    const questoesRender = document.getElementById('questoes-render');
    // "o que é o traço cinza?" antes era só um `title` (tooltip nativo por
    // hover), que não é confiável dentro do popup da extensão — não abre
    // por clique/toque e some fácil. Agora é clicável de verdade: alterna
    // um card de explicação, com delegação de evento (o conteúdo do ring é
    // recriado a cada renderQuestoesPerformance(), então o listener fica no
    // container pai, que nunca é substituído).
    if (questoesRender) {
        questoesRender.addEventListener('click', (e) => {
            const hint = e.target.closest('.questoes-ring-legend-hint');
            const infoAberto = questoesRender.querySelector('.questoes-traco-info:not([hidden])');
            if (!hint) {
                if (infoAberto) { infoAberto.hidden = true; }
                return;
            }
            const info = hint.nextElementSibling;
            if (!info || !info.classList.contains('questoes-traco-info')) return;
            const estavaAberto = !info.hidden;
            if (infoAberto && infoAberto !== info) infoAberto.hidden = true;
            info.hidden = estavaAberto;
            hint.setAttribute('aria-expanded', String(!estavaAberto));
        });
    }
    const questoesPeriodBtns = document.querySelectorAll('#questoes-period-controls button');
    let currentQuestoesPeriod = 1;
    const chartSummary = document.getElementById('chart-summary');
    const chartDetail = document.getElementById('chart-detail');
    const chartLegend = document.getElementById('chart-legend');
    const chartLinesLegend = document.getElementById('chart-lines-legend');
    const chartViewModeBtns = document.querySelectorAll('.chart-viewmode-btn');
    const chartDatePicker = document.getElementById('chart-date-picker');
    const btnChartClearDate = document.getElementById('btn-chart-clear-date');

    const distractionRender = document.getElementById('distraction-render');
    const distractionChartRender = document.getElementById('distraction-chart-render');
    const distractionHourRender = document.getElementById('distraction-hour-render');
    const distractionSummary = document.getElementById('distraction-summary');
    const distDatePicker = document.getElementById('dist-date-picker');
    const btnDistClearDate = document.getElementById('btn-dist-clear-date');
    const btnDistToday = document.getElementById('btn-dist-today');
    const btnDistWeek = document.getElementById('btn-dist-week');
    const btnDistMonth = document.getElementById('btn-dist-month');
    const btnDistSemester = document.getElementById('btn-dist-semester');

    const streakTag = document.getElementById('streak-tag');
    const streakModalOverlay = document.getElementById('streak-modal-overlay');
    const streakModalBody = document.getElementById('streak-modal-body');
    const streakModalClose = document.getElementById('streak-modal-close');

    const btnComunidade = document.getElementById('btn-comunidade');
    const comunidadeModalOverlay = document.getElementById('comunidade-modal-overlay');
    const comunidadeModalBody = document.getElementById('comunidade-modal-body');
    const comunidadeModalClose = document.getElementById('comunidade-modal-close');

    const productivityRender = document.getElementById('productivity-render');
    const productivityInsight = document.getElementById('productivity-insight');
    const btnProdDay = document.getElementById('btn-prod-day');
    const btnProdWeek = document.getElementById('btn-prod-week');
    const btnProdMonth = document.getElementById('btn-prod-month');
    const btnProdSemester = document.getElementById('btn-prod-semester');
    const prodDatePicker = document.getElementById('prod-date-picker');
    const btnProdClearDate = document.getElementById('btn-prod-clear-date');
    let currentProdPeriod = 'day';

    // ===================== CONFIGURAÇÕES, TEMA E AJUDA =====================
    const btnOpenSettings = document.getElementById('btn-open-settings');
    const settingsModalOverlay = document.getElementById('settings-modal-overlay');
    const settingsModalClose = document.getElementById('settings-modal-close');
    // Só os botões de cor de tema de verdade (têm data-theme). O toggle
    // "Modo da Interface" (Novo/Antigo) reaproveita a mesma classe visual
    // .theme-opt mas não é um tema — sem esse filtro, clicar nele disparava
    // o listener de tema com theme=undefined (bug: acabava ativando o tema
    // Escuro de graça na versão Free, ver onChanged de themePref abaixo).
    const themeOpts = document.querySelectorAll('.theme-opt[data-theme]');

    // Compartilhar a extensão com amigos via WhatsApp (link da Firefox Add-ons).
    // Fica fora da lógica de licença de propósito — deve funcionar mesmo se
    // o license.js não carregar por algum motivo.
    (function cbConfigurarBotaoCompartilhar() {
        const btnCompartilhar = document.getElementById('btn-whatsapp-compartilhar');
        if (!btnCompartilhar) return;
        const linkExtensao = 'https://addons.mozilla.org/pt-BR/firefox/addon/concurseiro-blindado-anal%C3%ADtico/';
        const textoCompartilhar = `Olha essa extensão que uso pra estudar pra concurso: ${linkExtensao}`;
        btnCompartilhar.href = `https://wa.me/?text=${encodeURIComponent(textoCompartilhar)}`;
    })();

    // Abrir Dashboard (aba grande, fica aberta como referência durante o estudo)
    const btnOpenDashboard = document.getElementById('btn-open-dashboard');
    if (btnOpenDashboard) {
        if (window.top !== window.self) {
            // Estamos rodando dentro do iframe da própria página de dashboard —
            // não faz sentido abrir outro dashboard a partir daqui.
            btnOpenDashboard.style.display = 'none';
        } else {
            btnOpenDashboard.addEventListener('click', () => {
                chrome.tabs.create({ url: chrome.runtime.getURL('dashboard/dashboard.html') });
            });
        }
    }

    // Abrir "Organizar meu dia" (Agenda) — esse botão não tinha nenhum
    // listener antes, então clicar nele não fazia absolutamente nada.
    const hnBtnOrganizar = document.getElementById('hn-btn-organizar');
    if (hnBtnOrganizar) {
        hnBtnOrganizar.addEventListener('click', () => {
            chrome.tabs.create({ url: chrome.runtime.getURL('rotina/rotina-diaria.html') });
        });
    }

    // Abrir o Monitor PCI Concursos (cargos novos, editais retificados etc.)
    const hnBtnPciConcursos = document.getElementById('hn-btn-pciconcursos');
    if (hnBtnPciConcursos) {
        hnBtnPciConcursos.addEventListener('click', () => {
            chrome.tabs.create({ url: chrome.runtime.getURL('pciconcursos/pciconcursos.html') });
        });
    }

    // Abrir/Fechar Modal de Configurações
    btnOpenSettings.addEventListener('click', () => settingsModalOverlay.classList.add('open'));
    settingsModalClose.addEventListener('click', () => settingsModalOverlay.classList.remove('open'));
    settingsModalOverlay.addEventListener('click', (e) => {
        if (e.target === settingsModalOverlay) settingsModalOverlay.classList.remove('open');
    });

    // (a navegação Geral/Ajuda & Privacidade por abas foi removida — agora é
    // tudo uma lista só de acordeões dentro de #set-geral)

    // Acordeão das seções dentro de Configurações → Geral (deixa a aba menos
    // poluída: só um bloco fica expandido de cada vez, o resto some do jeito).
    // As seções ficam em cartões agrupados (.cfg-grupo), então "fechar as outras"
    // olha a lista inteira (#set-geral), não só o grupo do item clicado.
    const cfgCorpo = document.querySelector('#settings-modal-overlay .ap-sheet-body');
    document.querySelectorAll('.settings-accordion-head').forEach(head => {
        const acc = head.closest('.settings-accordion');
        head.setAttribute('aria-expanded', acc.classList.contains('open') ? 'true' : 'false');
        head.addEventListener('click', () => {
            const jaAberto = acc.classList.contains('open');
            const lista = acc.closest('.set-tab-content') || acc.parentElement;
            lista.querySelectorAll('.settings-accordion.open').forEach(other => {
                if (other !== acc) {
                    other.classList.remove('open');
                    other.querySelector('.settings-accordion-head')?.setAttribute('aria-expanded', 'false');
                }
            });
            acc.classList.toggle('open', !jaAberto);
            head.setAttribute('aria-expanded', jaAberto ? 'false' : 'true');

            // Ao abrir, as outras seções fecham ao mesmo tempo e o conteúdo se
            // desloca: depois da animação, traz a linha aberta pro topo se ela
            // tiver ficado fora da vista (senão a pessoa abre e não vê nada).
            if (!jaAberto && cfgCorpo) {
                setTimeout(() => {
                    const r = acc.getBoundingClientRect();
                    const c = cfgCorpo.getBoundingClientRect();
                    if (r.top < c.top || r.top > c.bottom - 80) {
                        const reduzir = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
                        acc.scrollIntoView({ block: 'start', behavior: reduzir ? 'auto' : 'smooth' });
                    }
                }, 340);
            }
        });
    });

    // Lógica de Tema
    // "Automático" não é um tema de verdade pro resto do app — é só um modo
    // que escolhe entre Claro e Escuro pela hora do dia (mesmo corte das 18h/
    // 6h do planeta, ver tema-hora.js). O <html data-theme> sempre recebe o
    // tema DE VERDADE (light/dark/...); só os botões da UI sabem que
    // "Automático" está selecionado, guardado à parte.
    let themePrefAtual = 'light';
    function cbTemaResolvidoAutomatico() {
        const hora = new Date().getHours();
        return (hora >= 18 || hora < 6) ? 'dark' : 'light';
    }
    function applyTheme(theme) {
        themePrefAtual = theme;
        const temaReal = theme === 'auto' ? cbTemaResolvidoAutomatico() : theme;
        document.documentElement.setAttribute('data-theme', temaReal);
        themeOpts.forEach(o => o.classList.toggle('active', o.dataset.theme === theme));
    }

    // Enquanto o popup ficar aberto com "Automático" selecionado, reavalia a
    // cada poucos minutos — sem isso, só trocaria de Claro pra Escuro (ou
    // vice-versa) da próxima vez que o popup fosse reaberto depois da virada
    // das 18h/6h.
    setInterval(() => {
        if (themePrefAtual === 'auto') applyTheme('auto');
    }, 5 * 60 * 1000);

    // Local é mais confiável entre navegadores que sync (que depende de
    // conta/sinc ativada); usamos local como fonte principal e sync só
    // como acompanhamento entre PCs quando disponível.
    chrome.storage.local.get(['themePref'], (localResult) => {
        if (localResult.themePref) {
            applyTheme(localResult.themePref);
        } else {
            chrome.storage.sync.get(['themePref'], (result) => {
                applyTheme(result.themePref || 'light');
            });
        }
    });

    themeOpts.forEach(opt => {
        opt.addEventListener('click', () => {
            const theme = opt.dataset.theme;
            applyTheme(theme);
            chrome.storage.local.set({ themePref: theme });
            chrome.storage.sync.set({ themePref: theme });
            chrome.runtime.sendMessage({ action: 'changeTheme', theme });
        });
    });

    // Filtros de data ficam ocultos por padrão (mais discretos) — o usuário
    // abre o filtro só quando quiser escolher uma data específica.
    const chartDateRow = document.getElementById('chart-date-row');
    const prodDateRow = document.getElementById('prod-date-row');
    const distDateRow = document.getElementById('dist-date-row');
    const btnChartDateToggle = document.getElementById('btn-chart-date-toggle');
    const btnProdDateToggle = document.getElementById('btn-prod-date-toggle');
    const btnDistDateToggle = document.getElementById('btn-dist-date-toggle');

    function wireDateToggle(btn, row, onClear, clearBtn) {
        btn.addEventListener('click', () => {
            const isOpen = row.classList.toggle('open');
            btn.classList.toggle('active', isOpen);
        });
        if (clearBtn) {
            clearBtn.addEventListener('click', () => {
                onClear();
                btn.classList.remove('active');
                row.classList.remove('open');
            });
        }
    }

    // sync e local são lidos ao mesmo tempo (antes era um depois do outro: no Firefox cada leitura demora
    // e a tela ficava em "Configurando Sessão..."). Se o sync não responder em 3 s, segue com os padrões.
    const cbSyncPronto = new Promise((res) => {
        const t = setTimeout(() => res({}), 3000);
        try { chrome.storage.sync.get([
            'pomodoroWorkMinutes',
            'pomodoroRestMinutes',
            'dailyGoalMs',
            'metaModo',
            'dailyGoalQuestoes',
            'cameraEnabled',
            'cameraCheckIntervalMs',
            'cameraDisableForQuestoes',
            'hardcoreMode',
            'soundEnabled',
            'soundType',
            'soundVolume',
            'siteHistoryEnabled',
            'qcSyncEnabled',
            'privacyNoticeEnabled',
            'chartAnimationsEnabled',
            'dockHoverEnabled',
            'atalhoCtrlWinAtivo'
        ], (r) => { clearTimeout(t); res(r || {}); }); }
        catch (e) { clearTimeout(t); res({}); }
    });
    chrome.storage.local.get([
        'sessionState',
        'activeMethod',
        'activeActivity',
        'pomodoroMode',
        'pomodoroState',
        'pomodoroTimeLeft',
        'pomodoroInteligente',
        'pomodoroWorkMinutes',
        'pomodoroRestMinutes',
        'streakCount'
    ], (result) => {
        // Pinta já o estado do cronômetro com o que veio do local (não espera o sync, que no Firefox pode demorar):
        // sem isso o rótulo ficava em "Configurando Sessão..." até as duas leituras terminarem.
        try { updateUIState(result.sessionState || 'stopped', !!(result.pomodoroMode && result.pomodoroState === 'rest')); } catch (e) { console.warn('[Concurseiro Blindado] updateUIState antecipado:', e); }
        cbSyncPronto.then((syncResult) => {
            const state = result.sessionState || 'stopped';
            const method = result.activeMethod || 'online';
            const activity = result.activeActivity || 'questoes';

            selectMethod.value = method;
            selectActivity.value = activity;
            cbAtualizarBadgeModo(method);
            // Recalcula com base na aba ativa agora (pode ter mudado desde a
            // última vez que o popup foi aberto) e já persiste o resultado.
            cbSincronizarModoAutomatico(() => salvarConfigSessao());
            
            const pomodoroInteligenteAtivo = !!(result.pomodoroMode && result.pomodoroInteligente);
            chkPomodoro.checked = !!(result.pomodoroMode && !result.pomodoroInteligente);
            if (pomodoroSettings) pomodoroSettings.style.display = chkPomodoro.checked ? 'flex' : 'none';
            // local é a cópia confiável (sync pode não persistir de verdade em
            // vários navegadores/perfis — ver hydrateState em background.js).
            pomoCarregarSalvo(result.pomodoroWorkMinutes || syncResult.pomodoroWorkMinutes || 25, result.pomodoroRestMinutes || syncResult.pomodoroRestMinutes || 5);
            if (chkPomodoroInteligente) {
                chkPomodoroInteligente.checked = pomodoroInteligenteAtivo;
                cbAtualizarExclusaoPomodoro();
            }

            streakCount.innerText = result.streakCount || 0;
            dailyGoalMs = syncResult.dailyGoalMs || (4 * 60 * 60 * 1000);
            dailyGoalQuestoes = syncResult.dailyGoalQuestoes || 20;
            metaModo = syncResult.metaModo === 'questoes' ? 'questoes' : 'tempo';
            aplicarModoMeta(metaModo);
            atualizarLabelMeta();

            chkCamera.checked = syncResult.cameraEnabled !== false;
            if (chkCameraQuick) chkCameraQuick.checked = chkCamera.checked;
            if (chkCameraQuestoesOff) chkCameraQuestoesOff.checked = syncResult.cameraDisableForQuestoes === true;
            if (chkAtalhoCtrlWin) chkAtalhoCtrlWin.checked = syncResult.atalhoCtrlWinAtivo !== false;
            chkHardcore.checked = syncResult.hardcoreMode || false;
            atualizarVisibilidadeCamera(method);
            marcarBateriaAtiva(syncResult.cameraCheckIntervalMs || 3000);
            atualizarEstadoLinhaBateria();

            chkSound.checked = syncResult.soundEnabled || false;
            currentSoundType = syncResult.soundType && syncResult.soundType !== 'none' ? syncResult.soundType : 'white';
            marcarSoundTypeAtivo(currentSoundType);
            inputSoundVolume.value = Math.round((typeof syncResult.soundVolume === 'number' ? syncResult.soundVolume : 0.5) * 100);
            if (somMiniVolume) somMiniVolume.value = inputSoundVolume.value;
            atualizarPreenchimentoVolume();
            soundSettings.style.display = chkSound.checked ? 'flex' : 'none';
            atualizarVisibilidadeSomMini();

            if (chkSiteHistory) chkSiteHistory.checked = syncResult.siteHistoryEnabled !== false;
            if (chkQcSync) chkQcSync.checked = syncResult.qcSyncEnabled !== false;
            if (chkPrivacyNotice) chkPrivacyNotice.checked = syncResult.privacyNoticeEnabled !== false;

            // Animações extras dos gráficos: desativadas por padrão (só liga
            // se a pessoa explicitamente marcar === true nas configurações).
            const chartAnimationsOn = syncResult.chartAnimationsEnabled === true;
            if (chkChartAnimations) chkChartAnimations.checked = chartAnimationsOn;
            document.documentElement.classList.toggle('cb-chart-anim-on', chartAnimationsOn);

            // Barra flutuante (Dock): recurso ainda não finalizado — travado
            // em desativado na UI (checkbox desmarcado e desabilitado) até
            // ficar pronto. O valor salvo em dockHoverEnabled é ignorado
            // aqui de propósito; ver CB_DOCK_TRAVADO_DESATIVADO em
            // overlay-global/global_overlay.js.
            if (chkDockHover) {
                chkDockHover.checked = false;
                chkDockHover.disabled = true;
                chkDockHover.closest('label')?.setAttribute('title', 'Em desenvolvimento — ainda não disponível.');
                const hint = chkDockHover.closest('.mini-toggle-row')?.querySelector('.mini-toggle-hint');
                if (hint && !hint.dataset.cbDockAvisoAdicionado) {
                    hint.dataset.cbDockAvisoAdicionado = '1';
                    hint.insertAdjacentHTML('afterbegin', '<strong style="color:#ff9f0a;">Em desenvolvimento, ainda não disponível. </strong>');
                }
            }

            updateUIState(state, !!(result.pomodoroMode && result.pomodoroState === 'rest'));
            updateGoalProgress();
            // O que fica em outras abas é desenhado logo depois do primeiro quadro, para o cronômetro aparecer antes.
            setTimeout(() => {
                loadChartDisplayPrefs(() => {
                    chartLegend.innerHTML = CHART_LEGENDS[currentChartViewMode] || CHART_LEGENDS.period;
                    renderChart();
                });
                renderDistractions();
                renderProductivity();
                renderLevelCard();
                renderQuestoesPerformance();
                renderQuestoesMaterias();
                renderQuestoesAssuntos();
                renderQuestoesDestaques();
                renderQuestoesPrioridade();
            }, 60);

            if (state === 'running' || (result.pomodoroMode && result.pomodoroState === 'rest')) {
                startTimerUpdate();
            } else {
                updateTimerDisplay();
            }
        });
    });

    function atualizarVisibilidadeCamera(method) {
        if (!cameraToggleRow) return;
        cameraToggleRow.style.display = method === 'online' ? 'flex' : 'none';
        if (cameraBatteryRow) cameraBatteryRow.style.display = method === 'online' ? 'block' : 'none';
    }

    function marcarBateriaAtiva(intervalMs) {
        cameraBatteryBtns.forEach(b => b.classList.toggle('active', Number(b.dataset.interval) === Number(intervalMs)));
    }

    function atualizarEstadoLinhaBateria() {
        if (!cameraBatteryRow) return;
        cameraBatteryRow.classList.toggle('disabled', !chkCamera.checked);
    }

    cameraBatteryBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const intervalMs = Number(btn.dataset.interval);
            marcarBateriaAtiva(intervalMs);
            chrome.storage.sync.set({ cameraCheckIntervalMs: intervalMs });
        });
    });

    function marcarSoundTypeAtivo(type) {
        soundTypeBtns.forEach(b => b.classList.toggle('active', b.dataset.sound === type));
        somMiniTipoBtns.forEach(b => b.classList.toggle('active', b.dataset.sound === type));
    }

    // Mostra/esconde o atalho do cabeçalho junto com o estado do som ambiente
    // nas Configurações — quando a pessoa desliga lá, o atalho some (não tem
    // o que controlar); quando liga de novo, ele volta. O bloqueio por
    // recurso PRO (data-pro-feature="ambient_sound") é tratado à parte, por
    // cbApplyGates, e tem prioridade sobre isso (CSS !important).
    function atualizarVisibilidadeSomMini() {
        if (!somMiniWrap) return;
        somMiniWrap.style.display = chkSound.checked ? 'flex' : 'none';
        if (somMiniBtn) somMiniBtn.classList.toggle('cb-som-mini-btn--tocando', chkSound.checked);
        if (!chkSound.checked && somMiniPainel) somMiniPainel.hidden = true;
    }

    selectMethod.addEventListener('change', () => {
        salvarConfigSessao();
        atualizarVisibilidadeCamera(selectMethod.value);
    });
    selectActivity.addEventListener('change', salvarConfigSessao);

    function aplicarToggleCamera(enabled) {
        chkCamera.checked = enabled;
        if (chkCameraQuick) chkCameraQuick.checked = enabled;
        chrome.runtime.sendMessage({ action: 'toggleCamera', enabled });
        atualizarEstadoLinhaBateria();
    }

    chkCamera.addEventListener('change', () => aplicarToggleCamera(chkCamera.checked));
    if (chkCameraQuick) {
        chkCameraQuick.addEventListener('change', () => aplicarToggleCamera(chkCameraQuick.checked));
    }

    if (chkCameraQuestoesOff) {
        chkCameraQuestoesOff.addEventListener('change', () => {
            chrome.storage.sync.set({ cameraDisableForQuestoes: chkCameraQuestoesOff.checked });
        });
    }

    if (chkAtalhoCtrlWin) {
        chkAtalhoCtrlWin.addEventListener('change', () => {
            chrome.storage.sync.set({ atalhoCtrlWinAtivo: chkAtalhoCtrlWin.checked });
        });
    }

    if (chkSiteHistory) {
        chkSiteHistory.addEventListener('change', () => {
            chrome.storage.sync.set({ siteHistoryEnabled: chkSiteHistory.checked });
        });
    }

    if (chkQcSync) {
        chkQcSync.addEventListener('change', () => {
            chrome.storage.sync.set({ qcSyncEnabled: chkQcSync.checked });
        });
    }

    if (chkPrivacyNotice) {
        chkPrivacyNotice.addEventListener('change', () => {
            chrome.storage.sync.set({ privacyNoticeEnabled: chkPrivacyNotice.checked });
        });
    }

    chkHardcore.addEventListener('change', () => {
        chrome.runtime.sendMessage({ action: 'toggleHardcore', enabled: chkHardcore.checked });
    });

    if (chkChartAnimations) {
        chkChartAnimations.addEventListener('change', () => {
            const enabled = chkChartAnimations.checked;
            document.documentElement.classList.toggle('cb-chart-anim-on', enabled);
            chrome.storage.sync.set({ chartAnimationsEnabled: enabled });
        });
    }

    if (chkDockHover) {
        chkDockHover.addEventListener('change', () => {
            chrome.storage.sync.set({ dockHoverEnabled: chkDockHover.checked });
        });
    }

    // ===================== PERSONALIZAÇÃO DO GRÁFICO (CORES/ESTATÍSTICAS) =====================
    function rerenderChartAfterPrefChange() {
        chartLegend.innerHTML = CHART_LEGENDS[currentChartViewMode] || CHART_LEGENDS.period;
        renderChart(false);
    }

    const chartColorInputs = {
        mad: document.getElementById('input-chartcolor-mad'),
        man: document.getElementById('input-chartcolor-man'),
        tar: document.getElementById('input-chartcolor-tar'),
        noi: document.getElementById('input-chartcolor-noi')
    };
    function refreshChartColorInputsUI() {
        Object.keys(chartColorInputs).forEach(k => {
            if (chartColorInputs[k]) chartColorInputs[k].value = chartPeriodColors[k];
        });
    }
    Object.keys(chartColorInputs).forEach(k => {
        const input = chartColorInputs[k];
        if (!input) return;
        input.addEventListener('input', () => {
            chartPeriodColors = { ...chartPeriodColors, [k]: input.value };
            chrome.storage.sync.set({ cbChartColors: chartPeriodColors });
            rerenderChartAfterPrefChange();
        });
    });
    document.getElementById('btn-chartcolor-reset')?.addEventListener('click', () => {
        chartPeriodColors = { ...CHART_PERIOD_COLOR_DEFAULTS };
        chrome.storage.sync.set({ cbChartColors: chartPeriodColors });
        refreshChartColorInputsUI();
        rerenderChartAfterPrefChange();
    });

    const chartStatChecks = {
        total: document.getElementById('chk-chartstat-total'),
        media: document.getElementById('chk-chartstat-media'),
        melhor: document.getElementById('chk-chartstat-melhor'),
        consistencia: document.getElementById('chk-chartstat-consistencia')
    };
    function refreshChartStatChecksUI() {
        Object.keys(chartStatChecks).forEach(k => {
            if (chartStatChecks[k]) chartStatChecks[k].checked = chartStatsVisibility[k];
        });
    }
    Object.keys(chartStatChecks).forEach(k => {
        const chk = chartStatChecks[k];
        if (!chk) return;
        chk.addEventListener('change', () => {
            chartStatsVisibility = { ...chartStatsVisibility, [k]: chk.checked };
            chrome.storage.sync.set({ cbChartStatsVisibility: chartStatsVisibility });
            rerenderChartAfterPrefChange();
        });
    });

    const chkChartLegendTextHide = document.getElementById('chk-chart-legendtext-hide');
    if (chkChartLegendTextHide) {
        chkChartLegendTextHide.addEventListener('change', () => {
            chartLegendTextHidden = chkChartLegendTextHide.checked;
            chrome.storage.sync.set({ cbChartLegendTextHidden: chartLegendTextHidden });
            rerenderChartAfterPrefChange();
        });
    }
    // Reflete o estado salvo assim que os prefs carregarem (a leitura em si
    // acontece no loadChartDisplayPrefs chamado durante a inicialização).
    const _origLoadChartDisplayPrefs = loadChartDisplayPrefs;
    loadChartDisplayPrefs = function (callback) {
        _origLoadChartDisplayPrefs(() => {
            refreshChartColorInputsUI();
            refreshChartStatChecksUI();
            if (chkChartLegendTextHide) chkChartLegendTextHide.checked = chartLegendTextHidden;
            if (callback) callback();
        });
    };

    // Registra cada vez que o som ambiente é ligado — hora do dia, atividade
    // (questões/leitura) e qual som — pra alimentar a sugestão automática
    // mais abaixo. Guarda só os últimos 60 registros.
    function cbRegistrarUsoSom(soundType) {
        chrome.storage.local.get(['cbSomUsoLog'], (result) => {
            const log = result.cbSomUsoLog || [];
            log.push({ hora: new Date().getHours(), atividade: selectActivity.value, som: soundType, quando: Date.now() });
            while (log.length > 60) log.shift();
            chrome.storage.local.set({ cbSomUsoLog: log });
        });
    }

    chkSound.addEventListener('change', () => {
        const enabled = chkSound.checked;
        soundSettings.style.display = enabled ? 'flex' : 'none';
        atualizarVisibilidadeSomMini();
        if (enabled) cbRegistrarUsoSom(currentSoundType);
        chrome.runtime.sendMessage({
            action: 'updateSound',
            enabled: enabled,
            soundType: currentSoundType,
            volume: inputSoundVolume.value / 100
        });
    });

    function cbSelecionarSom(tipo) {
        currentSoundType = tipo;
        marcarSoundTypeAtivo(currentSoundType);
        if (chkSound.checked) {
            cbRegistrarUsoSom(currentSoundType);
            chrome.runtime.sendMessage({
                action: 'updateSound',
                enabled: true,
                soundType: currentSoundType,
                volume: inputSoundVolume.value / 100
            });
        }
    }
    soundTypeBtns.forEach(btn => btn.addEventListener('click', () => cbSelecionarSom(btn.dataset.sound)));
    somMiniTipoBtns.forEach(btn => btn.addEventListener('click', () => cbSelecionarSom(btn.dataset.sound)));

    let soundVolumeDebounce = null;
    function atualizarPreenchimentoVolume() {
        inputSoundVolume.style.setProperty('--val', `${inputSoundVolume.value}%`);
        if (somMiniVolume) somMiniVolume.style.setProperty('--val', `${somMiniVolume.value}%`);
    }
    atualizarPreenchimentoVolume();

    // Um único ponto pra mudar o volume — usado pelo slider das Configurações
    // e por todos os controles do atalho rápido (slider e botões -/+) — assim
    // os dois lugares nunca ficam com valores diferentes na tela.
    function cbAplicarVolume(valor) {
        const v = Math.max(0, Math.min(100, Math.round(valor)));
        inputSoundVolume.value = v;
        if (somMiniVolume) somMiniVolume.value = v;
        atualizarPreenchimentoVolume();
        clearTimeout(soundVolumeDebounce);
        soundVolumeDebounce = setTimeout(() => {
            chrome.runtime.sendMessage({
                action: 'updateSound',
                enabled: chkSound.checked,
                soundType: currentSoundType,
                volume: inputSoundVolume.value / 100
            });
        }, 150);
    }
    inputSoundVolume.addEventListener('input', () => cbAplicarVolume(inputSoundVolume.value));
    if (somMiniVolume) somMiniVolume.addEventListener('input', () => cbAplicarVolume(somMiniVolume.value));
    if (somMiniVolMenos) somMiniVolMenos.addEventListener('click', () => cbAplicarVolume(Number(inputSoundVolume.value) - 10));
    if (somMiniVolMais) somMiniVolMais.addEventListener('click', () => cbAplicarVolume(Number(inputSoundVolume.value) + 10));

    if (somMiniBtn) {
        somMiniBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            somMiniPainel.hidden = !somMiniPainel.hidden;
        });
    }
    if (somMiniPainel) somMiniPainel.addEventListener('click', (e) => e.stopPropagation());
    document.addEventListener('click', () => {
        if (somMiniPainel && !somMiniPainel.hidden) somMiniPainel.hidden = true;
    });
    if (somMiniDesligar) {
        somMiniDesligar.addEventListener('click', () => {
            chkSound.checked = false;
            chkSound.dispatchEvent(new Event('change'));
        });
    }

    function salvarConfigSessao() {
        chrome.runtime.sendMessage({
            action: 'changeConfig',
            method: selectMethod.value,
            activity: selectActivity.value
        });
        atualizarLabelFoco(selectMethod.value, selectActivity.value);
    }

    function atualizarLabelFoco(method, activity) {
        const formato = method === 'online' ? 'Online' : 'Offline';
        const ativ = activity === 'questoes' ? 'Questões' : 'Leitura';
        currentFocusLabel.innerHTML = `${formato}<span class="focus-sep">·</span>${ativ}`;
    }

    function atualizarLabelMeta() {
        // O valor da meta aparece na linha do progresso ("1 h 42 min de 2 h"), então o título fica só "Meta diária".
        goalLabelText.innerText = 'Meta diária';
    }

    // Alterna a visualização entre Meta de Tempo (violeta) e Meta de
    // Questões (vermelho) — inclusive o card de desempenho por matéria,
    // que só faz sentido no modo Questões.
    function aplicarModoMeta(modo) {
        metaModo = modo;
        document.querySelectorAll('.goal-mode-opt').forEach(b => b.classList.toggle('active', b.dataset.modo === modo));
        if (goalFieldsTempo) goalFieldsTempo.style.display = modo === 'tempo' ? 'flex' : 'none';
        if (goalFieldsQuestoes) goalFieldsQuestoes.style.display = modo === 'questoes' ? 'flex' : 'none';
        if (progressFill) progressFill.classList.toggle('modo-questoes', modo === 'questoes');
        if (goalIconChip) goalIconChip.classList.toggle('modo-questoes', modo === 'questoes');
        if (goalMateriasBreakdown) goalMateriasBreakdown.style.display = modo === 'questoes' ? 'block' : 'none';
        if (modo === 'questoes') renderGoalMateriasBreakdown();
    }

    goalModeToggle?.addEventListener('click', (e) => {
        const btn = e.target.closest('.goal-mode-opt');
        // Se estiver travado (feature PRO), o interceptor global de clique
        // (capture phase) já cuidou de mostrar o modal de upgrade — não
        // troca de modo nesse caso.
        if (!btn || btn.closest('.pro-locked')) return;
        const modo = btn.dataset.modo;
        aplicarModoMeta(modo);
        chrome.storage.sync.set({ metaModo: modo });
        atualizarLabelMeta();
        updateGoalProgress();
        inputGoalQuestoes.value = String(dailyGoalQuestoes);
        atualizarPainelMeta();
    });

    function renderGoalMateriasBreakdown() {
        if (!goalMateriasLista) return;
        chrome.storage.local.get(['questoesDisciplinas'], (result) => {
            const itens = (result.questoesDisciplinas && result.questoesDisciplinas.itens) || [];
            if (!itens.length) {
                goalMateriasLista.innerHTML = '<p style="font-size:11px; color:var(--text-faint); margin:0;">Ainda sem sincronização do QConcursos — resolva questões lá que os dados aparecem aqui.</p>';
                return;
            }
            const ordenado = [...itens].filter(it => it.total > 0).sort((a, b) => b.total - a.total).slice(0, 6);
            goalMateriasLista.innerHTML = ordenado.map(it => {
                const pct = it.total > 0 ? Math.round((it.certas / it.total) * 100) : 0;
                return `<div class="goal-materia-row">
                    <span class="goal-materia-nome" title="${escapeHtmlPopup(it.nome)}">${escapeHtmlPopup(it.nome)}</span>
                    <div class="goal-materia-bar-bg"><div class="goal-materia-bar-fill" style="width:${pct}%;"></div></div>
                    <span class="goal-materia-pct">${pct}%</span>
                </div>`;
            }).join('');
        });
    }

    // Pequeno helper local (o arquivo já usa escapeHtml em outros pontos com
    // nomes diferentes por seção; este evita depender de qual está em escopo).
    function escapeHtmlPopup(str) {
        const div = document.createElement('div');
        div.textContent = String(str || '');
        return div.innerHTML;
    }

    btnEditGoal.addEventListener('click', () => {
        inputGoalHours.value = (dailyGoalMs / (60 * 60 * 1000)).toString();
        inputGoalQuestoes.value = String(dailyGoalQuestoes);
        goalEditRow.classList.toggle('open');
        // De propósito SEM .focus(): o foco automático deixava o cursor de texto piscando ao lado do número
        // sem a pessoa ter pedido. Quem quer digitar clica no número; quem usa +/− nem precisa dele.
        atualizarPainelMeta();
    });

    // ----- Painel da meta: mesmo comportamento do painel do Pomodoro -----
    // O botão só liga quando há algo novo para salvar (e diz "Salvo" quando não há), responde ao clique com
    // um "✓ Salvo" e a linha de dica mostra qual meta vale agora. Depois de um instante o painel se fecha.
    const goalDicaTempo = document.getElementById('goal-dica-tempo');
    const goalDicaQuestoes = document.getElementById('goal-dica-questoes');
    let metaTimerOk = 0;

    // "1 h 42 min", "2 h", "35 min": mais legível do que 1.7h
    function cbFmtDuracao(ms) {
        const t = Math.max(0, Math.round(ms / 60000));
        const h = Math.floor(t / 60), m = t % 60;
        if (!h) return `${m} min`;
        return m ? `${h} h ${m} min` : `${h} h`;
    }
    function metaCampoValor(modo) {
        const v = parseFloat((modo === 'questoes' ? inputGoalQuestoes : inputGoalHours).value);
        return isNaN(v) || v <= 0 ? null : v;
    }
    function metaSalvaValor(modo) {
        return modo === 'questoes' ? dailyGoalQuestoes : dailyGoalMs / (60 * 60 * 1000);
    }
    function metaTextoDica(modo, valor, mudou) {
        const prefixo = mudou ? 'Nova meta' : 'Meta atual';
        return modo === 'questoes'
            ? `${prefixo}: ${valor} questões por dia.`
            : `${prefixo}: ${cbFmtDuracao(valor * 60 * 60 * 1000)} por dia.`;
    }
    function atualizarPainelMeta() {
        [['tempo', btnSaveGoal, goalDicaTempo], ['questoes', btnSaveGoalQuestoes, goalDicaQuestoes]].forEach(([modo, btn, dica]) => {
            if (!btn) return;
            const v = metaCampoValor(modo);
            const salvo = metaSalvaValor(modo);
            const mudou = v !== null && Math.abs(v - salvo) > 1e-9;
            if (!btn.classList.contains('is-ok')) {
                btn.disabled = !mudou;
                btn.querySelector('.pomo-save-txt').textContent = mudou ? 'Salvar' : 'Salvo';
            }
            if (dica && !dica.dataset.fixa) dica.textContent = metaTextoDica(modo, v !== null ? v : salvo, mudou);
        });
    }
    function metaMostrarSalvo(btn, dica, texto) {
        clearTimeout(metaTimerOk);
        btn.classList.add('is-ok');
        btn.disabled = true;
        btn.querySelector('.pomo-save-txt').textContent = 'Salvo';
        if (dica) { dica.dataset.fixa = '1'; dica.textContent = texto; }
        metaTimerOk = setTimeout(() => {
            btn.classList.remove('is-ok');
            if (dica) delete dica.dataset.fixa;
            goalEditRow.classList.remove('open');
            atualizarPainelMeta();
        }, 1100);
    }

    btnSaveGoal.addEventListener('click', salvarMetaDiaria);
    inputGoalHours.addEventListener('input', atualizarPainelMeta);
    inputGoalHours.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !btnSaveGoal.disabled) salvarMetaDiaria();
    });
    btnSaveGoalQuestoes?.addEventListener('click', salvarMetaQuestoes);
    inputGoalQuestoes?.addEventListener('input', atualizarPainelMeta);
    inputGoalQuestoes?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !btnSaveGoalQuestoes.disabled) salvarMetaQuestoes();
    });

    function salvarMetaQuestoes() {
        const meta = parseInt(inputGoalQuestoes.value, 10);
        if (isNaN(meta) || meta <= 0) return;

        dailyGoalQuestoes = meta;
        chrome.storage.sync.set({ dailyGoalQuestoes: meta }, () => {
            atualizarLabelMeta();
            updateGoalProgress();
            metaMostrarSalvo(btnSaveGoalQuestoes, goalDicaQuestoes, `Salvo. A meta de hoje agora é de ${meta} questões.`);
        });
    }

    function salvarMetaDiaria() {
        const horas = parseFloat(inputGoalHours.value);
        if (isNaN(horas) || horas <= 0) return;

        dailyGoalMs = Math.round(horas * 60 * 60 * 1000);
        // dailyGoalMs mora em chrome.storage.sync em todo o resto do app
        // (background.js, rotina.js, firebase-sync.js) — salvar em local
        // aqui fazia a meta "voltar" pro valor antigo (ou pro padrão de 4h)
        // toda vez que o popup fosse reaberto, mesmo depois de salva.
        chrome.storage.sync.set({ dailyGoalMs }, () => {
            chrome.runtime.sendMessage({ action: 'changeGoal', goalHours: horas });
            atualizarLabelMeta();
            updateGoalProgress();
            renderChart();
            metaMostrarSalvo(btnSaveGoal, goalDicaTempo, `Salvo. A meta de hoje agora é de ${cbFmtDuracao(dailyGoalMs)}.`);
        });
    }

    chrome.storage.onChanged.addListener((changes, areaName) => {
        if (areaName === 'local') {
            if (changes.sessionState) {
                const newState = changes.sessionState.newValue;
                // BUG: 'paused_away' é usado tanto pra "usuário saiu da tela"
                // quanto pro intervalo (rest) do Pomodoro (ver background.js,
                // processPomodoroTick). Antes, qualquer coisa != 'running'
                // parava o setInterval do popup (stopTimerUpdate), inclusive
                // durante o descanso — então o anel/contador congelava até o
                // trabalho recomeçar sozinho, dando a impressão de que "o
                // cronômetro parou de funcionar depois do Pomodoro". Como
                // pomodoroState é gravado no MESMO chrome.storage.local.set
                // que sessionState nessa transição, ele chega no mesmo lote
                // de `changes` — dá pra distinguir os dois casos aqui.
                if (changes.pomodoroState) {
                    const emPausaPomodoro = changes.pomodoroState.newValue === 'rest';
                    updateUIState(newState, emPausaPomodoro);
                    if (newState === 'running' || emPausaPomodoro) {
                        startTimerUpdate();
                    } else {
                        stopTimerUpdate();
                        updateTimerDisplay();
                    }
                    updateGoalProgress();
                } else {
                    // sessionState mudou sozinho, sem pomodoroState no mesmo
                    // lote (ex: retomada manual — botão Play — clicada
                    // durante o descanso do Pomodoro: só sessionState é
                    // gravado porque pomodoroState continua 'rest', sem
                    // mudar de valor, então o Chrome não inclui essa chave
                    // em `changes`). Sem isso, a UI mostrava "Estudando"
                    // mesmo ainda em descanso. Busca o valor atual direto do
                    // storage em vez de confiar só no lote de mudanças.
                    chrome.storage.local.get(['pomodoroState'], (result) => {
                        const emPausaPomodoro = result.pomodoroState === 'rest';
                        updateUIState(newState, emPausaPomodoro);
                        if (newState === 'running' || emPausaPomodoro) {
                            startTimerUpdate();
                        } else {
                            stopTimerUpdate();
                            updateTimerDisplay();
                        }
                        updateGoalProgress();
                    });
                }
            }
            if (changes.hourlyHistory) {
                renderProductivity(false);
                renderChart(false);
            }
            if (changes.activityHistory) {
                renderChart(false);
            }
            if (changes.siteHistory) {
                renderDistractions(false);
            }
            // Dado novo chegando do monitor do Windows enquanto o popup está
            // aberto. Sem animação de propósito: a lista se atualiza a cada
            // ~20s e re-animar tudo a cada ciclo dá impressão de tela piscando.
            if (changes.appUsageHistory || changes.appCategorias) {
                renderApps(false);
            }
            if (changes.pdfHistory || changes.pdfMateriaOverride) {
                renderPdfs(false);
            }
            if (changes.appUsageHistory || changes.videoMateriaOverride) {
                renderAulas(false);
                renderRadar();
            }
            if (changes.studyHistory) {
                renderEvolucao();
                renderGeral();
            }
            if (changes.siteHistory || changes.questoesDailyHistory) {
                renderGeral();
            }
            if (changes.questoesDisciplinas) {
                renderRadar();
            }
            if (changes.pauseHistory || changes.pauseStartedAt) {
                renderChart();
            }
            if (changes.questoesPeriodStats || changes.qcSyncDebug) {
                renderQuestoesPerformance();
            }
            if (changes.questoesDisciplinas || changes.hiddenMaterias) {
                renderQuestoesMaterias();
                if (metaModo === 'questoes') renderGoalMateriasBreakdown();
            }
            if (changes.questoesDailyHistory && metaModo === 'questoes') {
                updateGoalProgress();
            }
            if (changes.questoesAssuntos || changes.qcSyncDebugAssuntos) {
                renderQuestoesAssuntos();
                renderQuestoesDestaques();
            }
            if (changes.questoesPrioridade || changes.questoesStreak || changes.cronogramaCrossCheck) {
                renderQuestoesPrioridade();
            }
            if (changes.studyHistory || changes.questoesDailyHistory) {
                renderEdital();
            }
            if (changes.cronogramaConfig || changes.cronogramaProgresso) {
                renderCronograma();
                renderCronogramaAvisos();
            }
            if (changes.cronogramaAvisosDispensados) {
                renderCronogramaAvisos();
            }
            if (changes.pomodoroState || changes.pomodoroTimeLeft) {
                renderPomodoroIndicator();
                atualizarEstadoHardcoreUI();
            }
            if (changes.pomodoroMode || changes.pomodoroInteligente) {
                // Mantém os dois checkboxes (Clássico/Inteligente) e a
                // exclusão mútua em dia se o modo mudar por qualquer outra
                // via enquanto o popup está aberto (antes, só era atualizado
                // reabrindo o popup — o checkbox podia ficar mostrando um
                // modo que não é mais o que está rodando de verdade).
                chrome.storage.local.get(['pomodoroMode', 'pomodoroInteligente'], (result) => {
                    chkPomodoro.checked = !!(result.pomodoroMode && !result.pomodoroInteligente);
                    if (pomodoroSettings) pomodoroSettings.style.display = chkPomodoro.checked ? 'flex' : 'none';
                    if (chkPomodoroInteligente) chkPomodoroInteligente.checked = !!(result.pomodoroMode && result.pomodoroInteligente);
                    cbAtualizarExclusaoPomodoro();
                    atualizarEstadoHardcoreUI();
                });
            }
            if (changes.streakCount) {
                streakCount.innerText = changes.streakCount.newValue || 0;
            }
            if (changes.unlockedLevelIndex || changes.totalStudyMs) {
                renderLevelCard();
            }
        }
        if (areaName === 'sync') {
            if (changes.dailyGoalMs) {
                dailyGoalMs = changes.dailyGoalMs.newValue || (4 * 60 * 60 * 1000);
                atualizarLabelMeta();
                updateGoalProgress();
                renderChart();
            }
            if (changes.hardcoreMode) {
                chkHardcore.checked = changes.hardcoreMode.newValue || false;
                atualizarEstadoHardcoreUI();
            }
            if (changes.cameraEnabled) {
                chkCamera.checked = changes.cameraEnabled.newValue !== false;
                if (chkCameraQuick) chkCameraQuick.checked = chkCamera.checked;
            }
            if (changes.themePref) {
                // Era "|| 'dark'" — se algum evento salvasse um valor vazio/
                // inválido, isso liberava o tema Escuro (recurso PRO) de
                // graça. O padrão seguro é sempre o tema Claro, igual ao
                // resto do app; e reforça o gate PRO logo em seguida.
                applyTheme(changes.themePref.newValue || 'light');
                cbRefreshGates();
            }
            if (changes.editalConfig) {
                renderEdital();
            }
        }
    });

    function atualizarEstadoHardcoreUI() {
        chrome.storage.local.get(['sessionState', 'pomodoroMode', 'pomodoroState'], (result) => {
            const travar = chkHardcore.checked
                && result.sessionState === 'running'
                && !(result.pomodoroMode && result.pomodoroState === 'rest');

            btnPause.disabled = travar;
            btnPause.classList.toggle('locked', travar);
            btnPause.title = travar ? 'Modo Hardcore ativo: só é possível pausar no intervalo do Pomodoro (ou desative o Modo Hardcore).' : '';

            // BUG: essa linha reescrevia "disabled" do checkbox Clássico sem
            // olhar se o Inteligente estava marcado — como isso roda toda
            // hora que pomodoroState/pomodoroTimeLeft muda (ou seja, o tempo
            // todo durante uma sessão), o Modo Hardcore desligado (o caso
            // comum) reabilitava o checkbox Clássico no meio de uma sessão
            // do Inteligente. Clicar nele mandava 'togglePomodoro' e trocava
            // o motor de verdade pro Clássico (com os minutos salvos ali,
            // ex: 60/5) sem a pessoa perceber — o cronômetro continuava
            // mostrando ~60min de foco normalmente, e só na hora do descanso
            // é que aparecia 5min em vez dos 15 esperados do Inteligente.
            // Preserva a exclusão mútua com cbAtualizarExclusaoPomodoro().
            chkPomodoro.disabled = (travar && result.pomodoroMode) || !!(chkPomodoroInteligente && chkPomodoroInteligente.checked);
        });
    }

    btnPlay.addEventListener('click', () => {
        // O vídeo tem que disparar AQUI, dentro do clique de verdade —
        // não no listener de chrome.storage.onChanged lá embaixo (que só
        // reage bem depois, de forma assíncrona). Autoplay de vídeo
        // (mesmo mudo) em popup de extensão é bem mais confiável quando
        // .play() é chamado direto dentro de um gesto real do usuário;
        // esperar o storage ir e voltar pra só então dar play() cai fora
        // dessa janela de "gesto genuíno" com frequência. Marca
        // cbRodandoAnterior aqui também, pra quando o storage.onChanged
        // disparar (por causa dessa mesma ação) ele ver que já era e não
        // tentar tocar o vídeo de novo.
        cbTocarVideoTransicao(cbVideoIda, 'cb-transicao-ida');
        cbRodandoAnterior = true;
        cbTocarIntroSeComecoDoDia();
        // Revalida o modo pela aba ativa bem na hora de iniciar (gesto real
        // de clique, necessário pro permissions.request() do Firefox), pra
        // não começar a sessão com um modo desatualizado.
        cbSincronizarModoAutomatico((method) => {
            salvarConfigSessao();
            if (method === 'offline') {
                // A tela de bloqueio do modo Offline precisa aparecer em qualquer
                // aba — por isso depende da permissão ampla.
                cbGarantirPermissaoAmpla('o cronômetro no modo Offline (tela bloqueada)', (concedida) => {
                    if (!concedida) return;   // a folha "Liberar acesso aos sites" já foi aberta por cbGarantirPermissaoAmpla
                    chrome.runtime.sendMessage({ action: 'changeState', state: 'running' });
                });
                return;
            }
            chrome.runtime.sendMessage({ action: 'changeState', state: 'running' });
        });
    });

    btnPause.addEventListener('click', () => {
        chrome.runtime.sendMessage({ action: 'changeState', state: 'paused_manual' }, (response) => {
            if (response && response.blocked) {
                // Bloqueado pelo Modo Hardcore: a sessão continua rodando de
                // verdade no background, então NÃO toca a animação de "volta"
                // nem marca cbRodandoAnterior como false — fazer isso deixava
                // a UI dessincronizada do estado real (a próxima pausa de
                // verdade, ex: por ausência detectada pela câmera, não
                // conseguia mais disparar a transição porque cbRodandoAnterior
                // já estava false).
                mostrarAvisoHardcore();
                return;
            }
            cbTocarVideoTransicao(cbVideoVolta, 'cb-transicao-volta');
            cbRodandoAnterior = false;
        });
    });

    function mostrarAvisoHardcore() {
        const original = statusTag.innerText;
        statusTag.classList.add('hardcore-flash');
        currentFocusLabel.innerText = 'Modo Hardcore: só pausa no intervalo do Pomodoro!';
        setTimeout(() => {
            statusTag.classList.remove('hardcore-flash');
            chrome.storage.local.get(['activeMethod', 'activeActivity'], (result) => {
                atualizarLabelFoco(result.activeMethod || 'online', result.activeActivity || 'questoes');
            });
        }, 2200);
    }

    // Os dois ciclos (clássico e Inteligente) são mutuamente exclusivos —
    // liga um sempre desliga o outro, e desativa visualmente o checkbox que
    // não está em uso, pra não dar a entender que os dois rodam juntos.
    function cbAtualizarExclusaoPomodoro() {
        if (!chkPomodoroInteligente) return;
        chkPomodoro.disabled = chkPomodoroInteligente.checked;
        chkPomodoroInteligente.disabled = chkPomodoro.checked;
        if (pomodoroInteligenteToggleBox) pomodoroInteligenteToggleBox.classList.toggle('pomo-disabled', chkPomodoro.checked);
        if (pomodoroToggleBox) pomodoroToggleBox.classList.toggle('pomo-disabled', chkPomodoroInteligente.checked);
    }

    chkPomodoro.addEventListener('change', () => {
        const enabled = chkPomodoro.checked;
        if (pomodoroSettings) pomodoroSettings.style.display = enabled ? 'flex' : 'none';
        chrome.runtime.sendMessage({ action: 'togglePomodoro', enabled: enabled });
        if (!enabled) cbAlternarModoAnel('total');
        if (enabled && chkPomodoroInteligente) chkPomodoroInteligente.checked = false;
        cbAtualizarExclusaoPomodoro();
    });

    if (chkPomodoroInteligente) {
        chkPomodoroInteligente.addEventListener('change', () => {
            const enabled = chkPomodoroInteligente.checked;
            chrome.runtime.sendMessage({ action: 'togglePomodoroInteligente', enabled: enabled });
            if (!enabled) cbAlternarModoAnel('total');
            if (enabled) {
                chkPomodoro.checked = false;
                if (pomodoroSettings) pomodoroSettings.style.display = 'none';
            }
            cbAtualizarExclusaoPomodoro();
        });
    }

    // ----- Salvar do Pomodoro -----
    // O botão só liga quando há algo novo para salvar (e diz "Salvo" quando não há), responde na hora ao
    // clique com um "✓ Salvo" e a linha de dica mostra qual ciclo vale agora. O indicador "Foco Pomodoro ·
    // MM:SS" acima do cronômetro é redesenhado em seguida (o fundo já atualiza o tempo do próximo foco
    // mesmo com o cronômetro parado — ver 'updatePomodoro' em background.js).
    const pomoDica = document.getElementById('pomo-dica');
    const pomoSalvo = { work: 25, rest: 5 };           // o que está gravado de verdade
    let pomoTimerOk = 0;
    function pomoValor(input, padrao) {
        const max = parseInt(input.max, 10) || 120;
        return Math.min(max, Math.max(1, parseInt(input.value, 10) || padrao));
    }
    function pomoAtualizarPainel() {
        if (!btnSavePomo || !inputPomoWork || !inputPomoRest) return;
        const w = pomoValor(inputPomoWork, pomoSalvo.work), r = pomoValor(inputPomoRest, pomoSalvo.rest);
        const mudou = w !== pomoSalvo.work || r !== pomoSalvo.rest;
        if (!btnSavePomo.classList.contains('is-ok')) {
            btnSavePomo.disabled = !mudou;
            btnSavePomo.querySelector('.pomo-save-txt').textContent = mudou ? 'Salvar' : 'Salvo';
        }
        if (pomoDica && !pomoDica.dataset.fixa) {
            pomoDica.textContent = mudou
                ? `Novo ciclo: foco de ${w} min e pausa de ${r} min.`
                : `Ciclo atual: foco de ${w} min e pausa de ${r} min.`;
        }
    }
    function pomoCarregarSalvo(work, rest) {
        pomoSalvo.work = work; pomoSalvo.rest = rest;
        if (inputPomoWork && document.activeElement !== inputPomoWork) inputPomoWork.value = work;
        if (inputPomoRest && document.activeElement !== inputPomoRest) inputPomoRest.value = rest;
        pomoAtualizarPainel();
    }
    [inputPomoWork, inputPomoRest].forEach((el) => {
        if (!el) return;
        el.addEventListener('input', () => { if (pomoDica) delete pomoDica.dataset.fixa; pomoAtualizarPainel(); });
        el.addEventListener('keydown', (e) => { if (e.key === 'Enter' && btnSavePomo && !btnSavePomo.disabled) btnSavePomo.click(); });
    });
    // o que for gravado por qualquer outro caminho (outro popup, reabrir) também vira o "valor salvo"
    chrome.storage.onChanged.addListener((mud, area) => {
        if (area !== 'local' || !(mud.pomodoroWorkMinutes || mud.pomodoroRestMinutes)) return;
        chrome.storage.local.get(['pomodoroWorkMinutes', 'pomodoroRestMinutes'], (r) => pomoCarregarSalvo(r.pomodoroWorkMinutes || pomoSalvo.work, r.pomodoroRestMinutes || pomoSalvo.rest));
    });
    if (btnSavePomo) {
        btnSavePomo.addEventListener('click', () => {
            const work = pomoValor(inputPomoWork, 25), rest = pomoValor(inputPomoRest, 5);
            inputPomoWork.value = work; inputPomoRest.value = rest;            // mostra o número já corrigido
            chrome.runtime.sendMessage({ action: 'updatePomodoro', work, rest });
            pomoSalvo.work = work; pomoSalvo.rest = rest;
            // feedback imediato
            clearTimeout(pomoTimerOk);
            btnSavePomo.classList.add('is-ok');
            btnSavePomo.disabled = true;
            btnSavePomo.querySelector('.pomo-save-txt').textContent = 'Salvo';
            chrome.storage.local.get(['sessionState', 'pomodoroState'], (st) => {
                const rodando = st.sessionState === 'running' && st.pomodoroState === 'work';
                if (pomoDica) {
                    pomoDica.dataset.fixa = '1';
                    pomoDica.textContent = rodando
                        ? `Salvo. O foco em andamento recomeçou com ${work} min.`
                        : `Salvo. O próximo foco será de ${work} min, com pausa de ${rest} min.`;
                }
            });
            // o fundo grava em milissegundos; redesenha o indicador de cima assim que isso acontecer
            [150, 600].forEach((ms) => setTimeout(renderPomodoroIndicator, ms));
            pomoTimerOk = setTimeout(() => {
                btnSavePomo.classList.remove('is-ok');
                if (pomoDica) delete pomoDica.dataset.fixa;
                pomoAtualizarPainel();
            }, 2200);
        });
    }

    btnResetToday.addEventListener('click', () => {
        const confirmar = confirm('Isso vai zerar as horas e a produtividade registradas HOJE. Tem certeza?');
        if (!confirmar) return;

        const today = getTodayKey();
        chrome.storage.local.get([
            'studyHistory', 'siteHistory', 'hourlyHistory', 'activityHistory',
            // "Zerar Hoje" tem que zerar HOJE INTEIRO. Se os apps e os PDFs
            // ficassem de fora, a pessoa zeraria a tela e continuaria vendo
            // "3h no Steam" — o botão pareceria quebrado.
            'appUsageHistory', 'pdfHistory'
        ], (result) => {
            const study = result.studyHistory || {};
            const siteHistory = result.siteHistory || {};
            const hourlyHistory = result.hourlyHistory || {};
            const activityHistory = result.activityHistory || {};
            const appUsageHistory = result.appUsageHistory || {};
            const pdfHistory = result.pdfHistory || {};

            study[today] = 0;
            delete siteHistory[today];
            delete hourlyHistory[today];
            delete activityHistory[today];
            delete appUsageHistory[today];
            delete pdfHistory[today];

            const totalStudyMs = Object.values(study).reduce((s, v) => s + v, 0);

            chrome.storage.local.set({
                studyHistory: study,
                siteHistory,
                hourlyHistory,
                activityHistory,
                appUsageHistory,
                pdfHistory,
                totalStudyMs
            }, () => {
                updateTimerDisplay();
                updateGoalProgress();
                renderChart();
                renderDistractions();
                renderProductivity();
                renderLevelCard();
                chrome.runtime.sendMessage({ action: 'recalcularTudo' });
            });
        });
    });

    // O botão de download da Meta diária (#btn-export) já exportou o histórico em .CSV. Agora ele abre o
    // backup dos dados (salvar/restaurar), ligado em backup-popup.js.

    const tabsTrack = document.getElementById('tabs-track');
    const totalPaginasAbas = tabsTrack ? tabsTrack.querySelectorAll('.tabs-page').length : 0;

    // Carrossel de N páginas (uma seta "voltar" na ponta esquerda de todas
    // menos a 1ª, uma seta "ver mais" na ponta direita de todas menos a
    // última) — em vez de só ida/volta entre 2 páginas fixas, então dá pra
    // ir acrescentando páginas (ver .tabs-page em popup.html) sem precisar
    // reescrever essa lógica de novo.
    if (tabsTrack) {
        tabsTrack.querySelectorAll('[data-tabs-dir]').forEach(btn => {
            btn.addEventListener('click', () => {
                const atual = parseInt(tabsTrack.dataset.pagina, 10) || 0;
                const alvo = Math.max(0, Math.min(totalPaginasAbas - 1, atual + parseInt(btn.dataset.tabsDir, 10)));
                tabsTrack.dataset.pagina = String(alvo);
            });
        });
    }

    // O HTML nasce com "Geral" ativa. Quem reordenou as abas tem outra na frente (ex.: Questões) e é
    // nela que o popup deve abrir. Esta marca fica ligada assim que a pessoa clica numa aba: a partir
    // daí a ordem que chega do storage (assíncrono) não puxa mais o popup para outra aba.
    let usuarioEscolheuAba = false;

    function ativarAba(tabId) {
        const btn = document.querySelector(`.tab-btn[data-tab="${tabId}"]`);
        const conteudo = document.getElementById(tabId);
        if (!btn || !conteudo) return;
        tabs.forEach(t => t.classList.remove('active'));
        tabContents.forEach(c => c.classList.remove('active'));
        btn.classList.add('active');
        conteudo.classList.add('active');
    }

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            if (!tab.dataset.tab) return; // botões de seta (prev/next) não são abas
            usuarioEscolheuAba = true;
            ativarAba(tab.dataset.tab);
        });
    });

    // ===================== ORDEM PERSONALIZADA DAS ABAS =====================
    const DEFAULT_TAB_ORDER = ['tab-geral', 'tab-chart', 'tab-productivity', 'tab-distractions', 'tab-questoes', 'tab-ansiedade', 'tab-foco', 'tab-sites', 'tab-pci', 'tab-estudos', 'tab-jus'];
    const tabOrderList = document.getElementById('tab-order-list');
    let currentTabOrder = DEFAULT_TAB_ORDER.slice();

    function tabLabelFor(tabId) {
        const btn = document.querySelector(`.tab-btn[data-tab="${tabId}"]`);
        return btn ? btn.textContent.trim() : tabId;
    }

    // Reorganiza os botões .tab-btn dentro das páginas de .tabs-page, 4 por
    // página (mesma quantidade da 1ª página desde sempre), mantendo os
    // botões de seta nas pontas de cada página intactos. Generalizado pra N
    // páginas (não só 2) — ver .tabs-page em popup.html: cada nova página
    // que for adicionada lá é preenchida automaticamente aqui, sem precisar
    // mexer nesse código de novo.
    const CB_ABAS_POR_PAGINA = 4;
    function applyTabOrderToDOM(order) {
        const paginas = Array.from(tabsTrack.querySelectorAll('.tabs-page'));
        paginas.forEach((pagina, i) => {
            // Os .tab-btn ficam dentro de um .tabs-btn-group em cada
            // página, não soltos direto na .tabs-page — ver .tabs-btn-group
            // no CSS. Os botões de seta continuam soltos na .tabs-page, por
            // isso a busca é pelo grupo, não pela página em si.
            const grupo = pagina.querySelector('.tabs-btn-group') || pagina;
            const fatia = order.slice(i * CB_ABAS_POR_PAGINA, (i + 1) * CB_ABAS_POR_PAGINA);
            fatia.forEach(tabId => {
                const btn = document.querySelector(`.tab-btn[data-tab="${tabId}"]`);
                if (btn) grupo.appendChild(btn);
            });
        });
    }

    function renderTabOrderList() {
        if (!tabOrderList) return;
        tabOrderList.innerHTML = currentTabOrder.map((tabId, idx) => `
            <div class="tab-order-item" data-tab-id="${tabId}">
                <span class="tab-order-item-name">${tabLabelFor(tabId)}</span>
                <span class="tab-order-item-actions">
                    <button class="tab-order-btn tab-order-up" data-idx="${idx}" ${idx === 0 ? 'disabled' : ''} title="Mover para cima">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m18 15-6-6-6 6"/></svg>
                    </button>
                    <button class="tab-order-btn tab-order-down" data-idx="${idx}" ${idx === currentTabOrder.length - 1 ? 'disabled' : ''} title="Mover para baixo">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
                    </button>
                </span>
            </div>
        `).join('');

        tabOrderList.querySelectorAll('.tab-order-up').forEach(btn => {
            btn.addEventListener('click', () => moveTabOrder(parseInt(btn.dataset.idx, 10), -1));
        });
        tabOrderList.querySelectorAll('.tab-order-down').forEach(btn => {
            btn.addEventListener('click', () => moveTabOrder(parseInt(btn.dataset.idx, 10), 1));
        });
    }

    let cbModoAtualOrdemAbas = 'novo';
    function cbChaveOrdemAbas(modo) { return modo === 'antigo' ? 'tabOrderAntigo' : 'tabOrderNovo'; }

    // chrome.storage é assíncrono, então sem isto o popup pintaria "Geral" primeiro e só depois
    // trocaria. O localStorage é síncrono: guardamos a última ordem usada e aplicamos já na 1ª pintura.
    const CB_CACHE_ORDEM_ABAS = 'cbOrdemAbasCache';
    function cbOrdemAbasValida(o) {
        return Array.isArray(o) && o.length === DEFAULT_TAB_ORDER.length && DEFAULT_TAB_ORDER.every(id => o.includes(id));
    }
    function cbGuardarCacheOrdemAbas(order) {
        try { localStorage.setItem(CB_CACHE_ORDEM_ABAS, JSON.stringify(order)); } catch (e) { /* sem cache: só perde o ganho de velocidade */ }
    }
    function cbAplicarOrdemAbas(order) {
        currentTabOrder = order;
        applyTabOrderToDOM(order);
        // abre na primeira aba da ordem escolhida (não em "Geral" fixa), salvo se a pessoa já clicou em outra
        if (!usuarioEscolheuAba) ativarAba(order[0]);
    }

    function moveTabOrder(idx, delta) {
        const newIdx = idx + delta;
        if (newIdx < 0 || newIdx >= currentTabOrder.length) return;
        const arr = currentTabOrder.slice();
        [arr[idx], arr[newIdx]] = [arr[newIdx], arr[idx]];
        currentTabOrder = arr;
        applyTabOrderToDOM(currentTabOrder);
        renderTabOrderList();
        cbGuardarCacheOrdemAbas(currentTabOrder);
        chrome.storage.sync.set({ [cbChaveOrdemAbas(cbModoAtualOrdemAbas)]: currentTabOrder });
    }

    function cbCarregarOrdemAbasDoModo(modo) {
        cbModoAtualOrdemAbas = modo;
        chrome.storage.sync.get([cbChaveOrdemAbas(modo), 'tabOrder'], (result) => {
            let saved = result[cbChaveOrdemAbas(modo)];
            if (!Array.isArray(saved)) saved = result.tabOrder; // migra valor antigo compartilhado
            const ordem = cbOrdemAbasValida(saved) ? saved : DEFAULT_TAB_ORDER.slice();
            cbAplicarOrdemAbas(ordem);
            cbGuardarCacheOrdemAbas(ordem);
            renderTabOrderList();
        });
    }
    window.cbAoTrocarModoInterface = window.cbAoTrocarModoInterface || [];
    window.cbAoTrocarModoInterface.push(cbCarregarOrdemAbasDoModo);
    try {
        const emCache = JSON.parse(localStorage.getItem(CB_CACHE_ORDEM_ABAS) || 'null');
        if (cbOrdemAbasValida(emCache)) cbAplicarOrdemAbas(emCache);
    } catch (e) { /* cache ilegível: vale a leitura do storage logo abaixo */ }
    cbCarregarOrdemAbasDoModo('novo');

    // ===================== ORDEM DAS SEÇÕES PRINCIPAIS =====================
    // Permite reorganizar os grandes blocos da tela principal: Modo/Atividade,
    // Meta Diária, Suas Conquistas e o bloco de Abas (Histórico/Questões/...).
    const DEFAULT_SECTION_ORDER = ['section-config', 'section-meta', 'section-conquistas', 'section-tabs'];
    const SECTION_LABELS = {
        'section-config': 'Modo / Atividade',
        'section-meta': 'Meta Diária',
        'section-conquistas': 'Suas Conquistas',
        'section-tabs': 'Abas (Histórico, Questões...)'
    };
    const sectionOrderList = document.getElementById('section-order-list');
    let currentSectionOrder = DEFAULT_SECTION_ORDER.slice();

    // Todas as seções reordenáveis são irmãs diretas dentro do mesmo pai
    // (logo depois do botão "Iniciar Estudo", que fica sempre fixo no topo).
    // Reordená-las é só reinserir os nós na nova ordem, um após o outro.
    function applySectionOrderToDOM(order) {
        const nodes = order.map(id => document.getElementById(id)).filter(Boolean);
        if (nodes.length === 0) return;
        // Âncora fixa: o botão "Iniciar Estudo" fica sempre acima das seções
        // reordenáveis. Encadeamos os nós logo depois dele, na ordem escolhida.
        // O cartão "Plano de hoje" (plano-hoje.js) mora logo abaixo do cronômetro e
        // também fica fixo: se a âncora fosse só o cronômetro, as seções seriam
        // reinseridas entre os dois e o plano acabaria no fim da página.
        const ancora = document.getElementById('plano-hoje-card') || document.querySelector('.timer-section');
        let anterior = ancora || nodes[0].parentNode.firstChild;
        nodes.forEach(node => {
            anterior.after(node);
            anterior = node;
        });
    }

    function renderSectionOrderList() {
        if (!sectionOrderList) return;
        sectionOrderList.innerHTML = currentSectionOrder.map((id, idx) => `
            <div class="tab-order-item" data-section-id="${id}">
                <span class="tab-order-item-name">${SECTION_LABELS[id] || id}</span>
                <span class="tab-order-item-actions">
                    <button class="tab-order-btn section-order-up" data-idx="${idx}" ${idx === 0 ? 'disabled' : ''} title="Mover para cima">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m18 15-6-6-6 6"/></svg>
                    </button>
                    <button class="tab-order-btn section-order-down" data-idx="${idx}" ${idx === currentSectionOrder.length - 1 ? 'disabled' : ''} title="Mover para baixo">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
                    </button>
                </span>
            </div>
        `).join('');

        sectionOrderList.querySelectorAll('.section-order-up').forEach(btn => {
            btn.addEventListener('click', () => moveSectionOrder(parseInt(btn.dataset.idx, 10), -1));
        });
        sectionOrderList.querySelectorAll('.section-order-down').forEach(btn => {
            btn.addEventListener('click', () => moveSectionOrder(parseInt(btn.dataset.idx, 10), 1));
        });
    }

    // Cada modo de interface (Novo x Antigo) guarda sua PRÓPRIA ordem de
    // seções — trocar de modo aplica a ordem salva daquele modo, sem mexer
    // na do outro. cbModoAtual é atualizado pelo bloco "MODO DE INTERFACE"
    // lá embaixo (ver cbAoTrocarModoInterface).
    let cbModoAtualOrdem = 'novo';
    function cbChaveOrdemSecoes(modo) { return modo === 'antigo' ? 'sectionOrderAntigo' : 'sectionOrderNovo'; }

    function moveSectionOrder(idx, delta) {
        const newIdx = idx + delta;
        if (newIdx < 0 || newIdx >= currentSectionOrder.length) return;
        const arr = currentSectionOrder.slice();
        [arr[idx], arr[newIdx]] = [arr[newIdx], arr[idx]];
        currentSectionOrder = arr;
        applySectionOrderToDOM(currentSectionOrder);
        renderSectionOrderList();
        chrome.storage.sync.set({ [cbChaveOrdemSecoes(cbModoAtualOrdem)]: currentSectionOrder });
    }

    function cbCarregarOrdemSecoesDoModo(modo) {
        cbModoAtualOrdem = modo;
        chrome.storage.sync.get([cbChaveOrdemSecoes(modo), 'sectionOrder'], (result) => {
            // 'sectionOrder' = valor antigo (compartilhado, de antes desta correção).
            // Se ainda não existe uma ordem específica pro modo atual, aproveita
            // esse valor como ponto de partida uma única vez.
            let saved = result[cbChaveOrdemSecoes(modo)];
            if (!Array.isArray(saved)) saved = result.sectionOrder;
            if (Array.isArray(saved) && saved.length === DEFAULT_SECTION_ORDER.length &&
                DEFAULT_SECTION_ORDER.every(id => saved.includes(id))) {
                currentSectionOrder = saved;
            } else {
                currentSectionOrder = DEFAULT_SECTION_ORDER.slice();
            }
            applySectionOrderToDOM(currentSectionOrder);
            renderSectionOrderList();
        });
    }
    window.cbAoTrocarModoInterface = window.cbAoTrocarModoInterface || [];
    window.cbAoTrocarModoInterface.push(cbCarregarOrdemSecoesDoModo);
    cbCarregarOrdemSecoesDoModo('novo'); // aplica algo de imediato; o modo real chega logo em seguida

    function setChartPeriod(period, btnAtivo) {
        currentChartPeriod = period;
        chartDatePicker.value = ''; // limpa filtro de data
        selectedBarKey = null;
        [btnChartDay, btnChartWeek, btnChartMonth, btnChartSemester].forEach(b => b.classList.remove('active'));
        btnAtivo.classList.add('active');
        renderChart();
    }
    btnChartDay.addEventListener('click', () => setChartPeriod('day', btnChartDay));
    btnChartWeek.addEventListener('click', () => setChartPeriod('week', btnChartWeek));
    btnChartMonth.addEventListener('click', () => setChartPeriod('month', btnChartMonth));
    if (btnChartSemester) btnChartSemester.addEventListener('click', () => setChartPeriod('semester', btnChartSemester));

    function buildPeriodLegendHtml() {
        return `
            <div class="legend-item"><span class="legend-dot" style="background:${chartPeriodColors.mad};"></span>Madrugada</div>
            <div class="legend-item"><span class="legend-dot" style="background:${chartPeriodColors.man};"></span>Manhã</div>
            <div class="legend-item"><span class="legend-dot" style="background:${chartPeriodColors.tar};"></span>Tarde</div>
            <div class="legend-item"><span class="legend-dot" style="background:${chartPeriodColors.noi};"></span>Noite</div>
        `;
    }

    const CHART_LEGENDS = {
        get period() { return buildPeriodLegendHtml(); },
        activity: `
            <div class="legend-item"><span class="legend-dot" style="background:#8b5cf6;"></span>Questões</div>
            <div class="legend-item"><span class="legend-dot" style="background:#fbbf24;"></span>Leitura</div>
            <div class="legend-item"><span class="legend-dot" style="background:#ef4444;"></span>Vídeo-aula</div>
        `,
        pauses: `
            <div class="legend-item"><span class="legend-dot" style="background:#f43f5e;"></span>Tempo pausado</div>
            <div class="legend-item"><span class="legend-dot" style="background:transparent;border:1px dashed #f43f5e;"></span>Nº de pausas</div>
        `
    };

    function setChartViewMode(mode, btnAtivo) {
        currentChartViewMode = mode;
        chartViewModeBtns.forEach(b => b.classList.remove('active'));
        btnAtivo.classList.add('active');
        chartLegend.innerHTML = CHART_LEGENDS[mode] || CHART_LEGENDS.period;
        renderChart();
        renderEvolucao();
    }
    chartViewModeBtns.forEach(btn => {
        btn.addEventListener('click', () => setChartViewMode(btn.dataset.view, btn));
    });

    chartDatePicker.addEventListener('change', () => {
        if (chartDatePicker.value) {
            [btnChartDay, btnChartWeek, btnChartMonth, btnChartSemester].forEach(b => b.classList.remove('active'));
            renderChart();
        }
    });
    btnChartClearDate.addEventListener('click', () => {
        chartDatePicker.value = '';
        btnChartDay.classList.add('active');
        currentChartPeriod = 'day';
        renderChart();
    });

    function setProdPeriod(period, btnAtivo) {
        currentProdPeriod = period;
        prodDatePicker.value = '';
        [btnProdDay, btnProdWeek, btnProdMonth, btnProdSemester].forEach(b => b.classList.remove('active'));
        btnAtivo.classList.add('active');
        renderProductivity();
    }
    btnProdDay.addEventListener('click', () => setProdPeriod('day', btnProdDay));
    btnProdWeek.addEventListener('click', () => setProdPeriod('week', btnProdWeek));
    btnProdMonth.addEventListener('click', () => setProdPeriod('month', btnProdMonth));
    if (btnProdSemester) btnProdSemester.addEventListener('click', () => setProdPeriod('semester', btnProdSemester));

    prodDatePicker.addEventListener('change', () => {
        if (prodDatePicker.value) {
            [btnProdDay, btnProdWeek, btnProdMonth, btnProdSemester].forEach(b => b.classList.remove('active'));
            renderProductivity();
        }
    });
    btnProdClearDate.addEventListener('click', () => {
        prodDatePicker.value = '';
        btnProdDay.classList.add('active');
        currentProdPeriod = 'day';
        renderProductivity();
    });

    function setDistPeriod(period, btnAtivo) {
        currentDistPeriod = period;
        distDatePicker.value = '';
        [btnDistToday, btnDistWeek, btnDistMonth, btnDistSemester].forEach(b => b.classList.remove('active'));
        btnAtivo.classList.add('active');
        renderDistractions();
    }
    btnDistToday.addEventListener('click', () => setDistPeriod('today', btnDistToday));
    btnDistWeek.addEventListener('click', () => setDistPeriod('week', btnDistWeek));
    btnDistMonth.addEventListener('click', () => setDistPeriod('month', btnDistMonth));
    if (btnDistSemester) btnDistSemester.addEventListener('click', () => setDistPeriod('semester', btnDistSemester));

    distDatePicker.addEventListener('change', () => {
        if (distDatePicker.value) {
            [btnDistToday, btnDistWeek, btnDistMonth, btnDistSemester].forEach(b => b.classList.remove('active'));
            renderDistractions();
        }
    });
    btnDistClearDate.addEventListener('click', () => {
        distDatePicker.value = '';
        btnDistToday.classList.add('active');
        currentDistPeriod = 'today';
        renderDistractions();
    });

    wireDateToggle(btnChartDateToggle, chartDateRow, () => btnChartClearDate.click());
    wireDateToggle(btnProdDateToggle, prodDateRow, () => btnProdClearDate.click());
    wireDateToggle(btnDistDateToggle, distDateRow, () => btnDistClearDate.click());
    chartDatePicker.addEventListener('change', () => { if (chartDatePicker.value) btnChartDateToggle.classList.add('active'); });
    prodDatePicker.addEventListener('change', () => { if (prodDatePicker.value) btnProdDateToggle.classList.add('active'); });
    distDatePicker.addEventListener('change', () => { if (distDatePicker.value) btnDistDateToggle.classList.add('active'); });

    streakTag.addEventListener('click', abrirModalStreak);
    streakModalClose.addEventListener('click', () => streakModalOverlay.classList.remove('open'));
    streakModalOverlay.addEventListener('click', (e) => {
        if (e.target === streakModalOverlay) streakModalOverlay.classList.remove('open');
    });

    // Fechar a comunidade também para a atualização da conversa (senão ela seguia consultando o servidor).
    function fecharComunidade() {
        comunidadeModalOverlay.classList.remove('open');
        if (window.CBChat) window.CBChat.parar();
    }
    btnComunidade.addEventListener('click', abrirModalComunidade);
    comunidadeModalClose.addEventListener('click', fecharComunidade);
    comunidadeModalOverlay.addEventListener('click', (e) => {
        if (e.target === comunidadeModalOverlay) fecharComunidade();
    });
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && comunidadeModalOverlay.classList.contains('open')) fecharComunidade();
    });
    let comunidadeTabAtiva = 'geral';
    let grupoSubTela = 'inicio'; // inicio | criar | entrar | ativo

    comunidadeModalBody.addEventListener('click', (e) => {
        const tabBtn = e.target.closest('[data-ctab]');
        if (tabBtn) {
            comunidadeTabAtiva = tabBtn.dataset.ctab;
            grupoSubTela = 'inicio';
            renderComunidadeAba();
            return;
        }
        if (e.target.closest('#btn-comunidade-retentar')) {
            renderComunidadeAba();
        } else if (e.target.closest('#btn-ranking-optin')) {
            chrome.storage.local.set({ cbRankingOptIn: true }, () => {
                try { chrome.runtime.sendMessage({ action: 'cbRankingOptIn' }, () => void chrome.runtime.lastError); } catch (err) { /* segundo plano dormindo: o heartbeat envia */ }
                renderComunidadeAba();
            });
        } else if (e.target.closest('#btn-ranking-optout')) {
            chrome.storage.local.set({ cbRankingOptIn: false }, () => {
                try { chrome.runtime.sendMessage({ action: 'cbRankingOptOut' }, () => void chrome.runtime.lastError); } catch (err) { /* idem */ }
                renderComunidadeAba();
            });
        } else if (e.target.closest('#btn-grupo-mostrar-criar')) {
            grupoSubTela = 'criar';
            renderComunidadeAba();
        } else if (e.target.closest('#btn-grupo-mostrar-entrar')) {
            grupoSubTela = 'entrar';
            renderComunidadeAba();
        } else if (e.target.closest('#btn-grupo-cancelar')) {
            grupoSubTela = 'inicio';
            renderComunidadeAba();
        } else if (e.target.closest('#btn-grupo-confirmar-criar')) {
            const nome = (document.getElementById('input-grupo-nome-criar') || {}).value || '';
            cbMsgComTimeout({ action: 'cbGrupoCriar', nome }, () => {
                grupoSubTela = 'ativo';
                renderComunidadeAba();
            }, CB_BG_FRIO_MS);
        } else if (e.target.closest('#btn-grupo-confirmar-entrar')) {
            const codigo = (document.getElementById('input-grupo-codigo') || {}).value || '';
            const nome = (document.getElementById('input-grupo-nome-entrar') || {}).value || '';
            const btn = e.target.closest('#btn-grupo-confirmar-entrar');
            btn.disabled = true;
            cbMsgComTimeout({ action: 'cbGrupoEntrar', codigo, nome }, (resp) => {
                if (resp && resp.ok) {
                    grupoSubTela = 'ativo';
                    renderComunidadeAba();
                } else {
                    btn.disabled = false;
                    const erroEl = document.getElementById('grupo-entrar-erro');
                    if (erroEl) erroEl.textContent = (resp && resp.erro === 'nao_encontrado') ? 'Código não encontrado — confira com quem te convidou.' : 'Não deu pra entrar agora. Tente de novo.';
                }
            }, CB_BG_FRIO_MS);
        } else if (e.target.closest('#btn-grupo-sair')) {
            cbMsgComTimeout({ action: 'cbGrupoSair' }, () => {
                grupoSubTela = 'inicio';
                renderComunidadeAba();
            }, CB_BG_FRIO_MS);
        }
    });

    // Abre na Conversa quando há mensagem nova (é por isso que o ícone está vermelho); senão, no resumo do dia.
    function abrirModalComunidade() {
        // Dispara já a busca das mensagens (0,4 s de rede) enquanto o resto da folha monta.
        if (window.CBChat && window.CBChat.prefetch) { try { window.CBChat.prefetch().catch(() => {}); } catch (e) { /* sem rede: o chat tenta de novo */ } }
        comunidadeModalOverlay.classList.add('open');
        grupoSubTela = 'inicio';
        chrome.storage.local.get(['cbChatNaoLidas'], (r) => {
            comunidadeTabAtiva = (r && r.cbChatNaoLidas > 0) ? 'conversa' : 'geral';
            renderComunidadeAba();
        });
    }

    // O controle segmentado (Conversa | Hoje | Meu grupo) mora no HTML; aqui só se marca a aba e se
    // monta o conteúdo. A Conversa tem o próprio ciclo de vida (comunidade-chat.js).
    function renderComunidadeAba() {
        comunidadeModalBody.querySelectorAll('.comunidade-tab-btn').forEach((b) => {
            const ativo = b.dataset.ctab === comunidadeTabAtiva;
            b.classList.toggle('active', ativo);
            b.setAttribute('aria-selected', String(ativo));
        });
        const alvo = document.getElementById('comunidade-tab-content');
        if (!alvo) return;
        if (window.CBChat) window.CBChat.parar();
        alvo.classList.toggle('com-conteudo--chat', comunidadeTabAtiva === 'conversa');
        alvo.innerHTML = '<p class="modal-note">Carregando…</p>';
        // Se algo quebrar ao montar a aba (já aconteceu só no Firefox), mostra o motivo na própria tela
        // em vez de deixar "Carregando…" parado sem explicação.
        const mostrarErro = (e) => {
            console.error('[Comunidade]', e);
            if (alvo.isConnected) alvo.innerHTML = `<p class="modal-note">Não consegui abrir esta aba.<br><small>${String((e && e.message) || e).replace(/</g, '&lt;')}</small></p>`;
        };
        try {
            if (comunidadeTabAtiva === 'conversa') {
                if (window.CBChat) Promise.resolve(window.CBChat.montar(alvo)).catch(mostrarErro);
            } else if (comunidadeTabAtiva === 'geral') {
                renderComunidadeTabGeral();
            } else {
                renderComunidadeTabGrupo();
            }
        } catch (e) { mostrarErro(e); }
    }

    // Comparação anônima e agregada com a comunidade — nunca mostra dados de
    // ninguém individualmente, só a média do dia (soma/contagem) que o
    // service worker mantém no Firebase via cbComunidadeEnviarContribuicao
    // (dados-config/firebase-sync.js). Sem ranking, sem lista de usuários.
    // sendMessage que sempre devolve: se o segundo plano não responder (acontece no
    // Firefox quando a página em segundo plano está dormindo ou a rede falha), o
    // callback roda com undefined em vez de deixar a tela em "Carregando…" para sempre.
    function cbMsgComTimeout(msg, cb, ms) {
        let fim = false;
        const fechar = (r) => { if (fim) return; fim = true; clearTimeout(t); cb(r); };
        const t = setTimeout(() => fechar(undefined), ms || 8000);
        try {
            chrome.runtime.sendMessage(msg, (r) => { void chrome.runtime.lastError; fechar(r); });
        } catch (e) { fechar(undefined); }
    }

    // Leituras do Firebase feitas direto aqui no popup (REST, sem login). No Firefox o segundo plano
    // é suspenso quando fica parado e leva de 10 a 30 s para acordar; se a tela dependesse dele,
    // ficaria em "Carregando…". O segundo plano continua responsável só por ESCREVER (heartbeat).
    const CB_FB_URL = 'https://concurseiro-blindado-default-rtdb.firebaseio.com';
    async function cbFbLer(caminho, ms) {
        const ctl = new AbortController();
        const t = setTimeout(() => ctl.abort(), ms || 8000);
        try {
            const r = await fetch(`${CB_FB_URL}/${caminho}.json`, { signal: ctl.signal });
            if (!r.ok) throw new Error('http_' + r.status);
            return await r.json();
        } finally { clearTimeout(t); }
    }
    function cbStorageLer(chaves) {
        return new Promise((res) => {
            let fim = false;
            const t = setTimeout(() => { if (!fim) { fim = true; res({}); } }, 4000);
            try {
                chrome.storage.local.get(chaves, (r) => { if (fim) return; fim = true; clearTimeout(t); res(r || {}); });
            } catch (e) { clearTimeout(t); res({}); }
        });
    }
    const CB_BG_FRIO_MS = 40000; // acordar o segundo plano no Firefox pode levar ~30 s

    // Ranking de hoje + identidade. Tudo local/direto; só pergunta ao segundo plano se a pessoa
    // ainda não tem apelido sorteado (primeira vez).
    async function cbObterRankingTela(today) {
        const o = await cbStorageLer(['cbRankingOptIn', 'cbRankingId', 'cbRankingApelido']);
        if (o.cbRankingId && o.cbRankingApelido) {
            const dados = await cbFbLer(`ranking/${today}`);
            return { dados: dados || {}, rankingId: o.cbRankingId, apelido: o.cbRankingApelido, optIn: !!o.cbRankingOptIn };
        }
        // Primeira vez: sorteia o apelido aqui mesmo (mesma regra do segundo plano, firebase-sync.js)
        // em vez de esperar o segundo plano acordar.
        const animais = ['Coruja', 'Falcão', 'Tartaruga', 'Formiga', 'Águia', 'Leão', 'Lobo', 'Golfinho', 'Tigre', 'Urso', 'Raposa', 'Gavião'];
        const adjetivos = ['Dedicado', 'Focado', 'Persistente', 'Determinado', 'Disciplinado', 'Constante', 'Aplicado', 'Estudioso', 'Resiliente', 'Concentrado', 'Motivado', 'Incansável'];
        const rankingId = o.cbRankingId || ('rk_' + crypto.randomUUID());
        let h = 0;
        for (let i = 0; i < rankingId.length; i++) h = (h * 31 + rankingId.charCodeAt(i)) >>> 0;
        const apelido = o.cbRankingApelido || `${animais[h % animais.length]} ${adjetivos[(h >>> 4) % adjetivos.length]} #${(h % 90) + 10}`;
        await new Promise((res) => { const t = setTimeout(res, 3000); try { chrome.storage.local.set({ cbRankingId: rankingId, cbRankingApelido: apelido }, () => { clearTimeout(t); res(); }); } catch (e) { clearTimeout(t); res(); } });
        const dados = await cbFbLer(`ranking/${today}`);
        return { dados: dados || {}, rankingId, apelido, optIn: !!o.cbRankingOptIn };
    }

    function renderComunidadeTabGeral() {
        const alvo = document.getElementById('comunidade-tab-content');
        const today = getTodayKey();
        const ativo = () => alvo && alvo.isConnected && comunidadeTabAtiva === 'geral';
        const fmtH = (ms) => (ms / 3600000).toFixed(1) + 'h';

        cbStorageLer(['studyHistory', 'questoesPeriodStats']).then((res) => {
            if (!ativo()) return;
            const msVoce = (res.studyHistory || {})[today] || 0;
            const qc = (res.questoesPeriodStats && res.questoesPeriodStats[1]) || null;
            const pctVoce = (qc && qc.total > 0) ? Math.round((qc.acertos / qc.total) * 100) : null;

            // d: undefined = carregando · null = falhou · objeto = dados da comunidade
            const comparacao = (d) => {
                const dd = d || {};
                const msMedia = dd.qtdEstudo > 0 ? (dd.somaEstudoMs / dd.qtdEstudo) : 0;
                const pctMedia = (dd.qtdQuestoes > 0 && dd.somaQuestoes > 0) ? Math.round((dd.somaAcertos / dd.somaQuestoes) * 100) : null;
                const participantes = Math.max(dd.qtdEstudo || 0, dd.qtdQuestoes || 0);
                const carregando = d === undefined;
                const txtMedia = carregando ? '…' : fmtH(msMedia);
                const txtPct = carregando ? '…' : (pctMedia !== null ? pctMedia + '%' : '—');
                const rodape = carregando ? 'Buscando a média da comunidade…'
                    : d === null ? 'Não consegui falar com a comunidade agora. <button type="button" id="btn-comunidade-retentar" class="ranking-sair-btn">Tentar de novo</button>'
                    : participantes > 0 ? `Baseado em ${participantes} pessoa${participantes > 1 ? 's' : ''} estudando hoje.`
                    : 'Ainda não há dados suficientes da comunidade hoje — volte mais tarde.';
                return `
                    ${renderComunidadeBarra('Tempo de estudo hoje', fmtH(msVoce), msVoce, txtMedia, msMedia)}
                    ${pctVoce !== null
                        ? renderComunidadeBarra('Aproveitamento em questões hoje', pctVoce + '%', pctVoce, txtPct, pctMedia || 0)
                        : '<p class="modal-note">Responda questões hoje pra também comparar seu aproveitamento.</p>'}
                    <p class="modal-note">${rodape}</p>`;
            };

            alvo.innerHTML = `
                <p class="modal-note" style="margin-top:0;">Comparação anônima com quem mais está estudando hoje pela extensão — por padrão só a média geral, sem nomes.</p>
                <div id="com-bloco-comparacao">${comparacao(undefined)}</div>
                <hr class="comunidade-divisor">
                <div id="com-bloco-ranking"><p class="modal-note">Carregando o ranking…</p></div>`;
            const pintar = (id, html) => { if (!ativo()) return; const el = alvo.querySelector('#' + id); if (el) el.innerHTML = html; };

            cbFbLer(`comunidade/${today}`).then((d) => pintar('com-bloco-comparacao', comparacao(d || {})))
                .catch((e) => { console.warn('[Comunidade]', e); pintar('com-bloco-comparacao', comparacao(null)); });
            cbObterRankingTela(today).then((r) => pintar('com-bloco-ranking', renderRankingSecao(r)))
                .catch((e) => { console.warn('[Comunidade]', e); pintar('com-bloco-ranking', '<p class="modal-note">Ranking indisponível agora.</p>'); });
        });
    }

    // Grupo fechado por convite — "estude junto com quem você conhece".
    // Diferente da aba Comunidade: o nome é escolhido pela própria pessoa,
    // porque só quem tem o código do grupo (compartilhado por quem convidou)
    // consegue ver aquele grupo — um círculo pequeno de confiança, não o
    // público geral da extensão.
    async function cbObterGrupoTela() {
        const o = await cbStorageLer(['cbGrupoAtivo', 'cbGrupoNome', 'cbGrupoMembroId']);
        if (!o.cbGrupoAtivo) return { ativo: false };
        if (!o.cbGrupoMembroId) return new Promise((res) => cbMsgComTimeout({ action: 'cbGrupoObterHoje' }, res, CB_BG_FRIO_MS));
        let membros = {};
        try { membros = (await cbFbLer(`grupos/${o.cbGrupoAtivo}/dias/${getTodayKey()}/membros`)) || {}; } catch (e) { console.warn('[Comunidade]', e); }
        return { ativo: true, codigo: o.cbGrupoAtivo, nome: o.cbGrupoNome, membroId: o.cbGrupoMembroId, membros };
    }

    function renderComunidadeTabGrupo() {
        const alvo = document.getElementById('comunidade-tab-content');
        if (!alvo) return;

        if (grupoSubTela === 'criar') {
            alvo.innerHTML = `
                <div class="grupo-form">
                    <label class="settings-label">Seu nome no grupo</label>
                    <input type="text" id="input-grupo-nome-criar" maxlength="24" placeholder="Como te chamam?">
                    <div class="grupo-form-actions">
                        <button type="button" id="btn-grupo-cancelar">Cancelar</button>
                        <button type="button" id="btn-grupo-confirmar-criar" class="organizar-dia-btn">Criar grupo</button>
                    </div>
                </div>
            `;
            return;
        }
        if (grupoSubTela === 'entrar') {
            alvo.innerHTML = `
                <div class="grupo-form">
                    <label class="settings-label">Código do grupo</label>
                    <input type="text" id="input-grupo-codigo" maxlength="6" placeholder="Ex: ABCDEF" style="text-transform:uppercase;">
                    <label class="settings-label">Seu nome no grupo</label>
                    <input type="text" id="input-grupo-nome-entrar" maxlength="24" placeholder="Como te chamam?">
                    <p id="grupo-entrar-erro" class="modal-note" style="color:var(--danger,#ef4444);"></p>
                    <div class="grupo-form-actions">
                        <button type="button" id="btn-grupo-cancelar">Cancelar</button>
                        <button type="button" id="btn-grupo-confirmar-entrar" class="organizar-dia-btn">Entrar</button>
                    </div>
                </div>
            `;
            return;
        }

        alvo.innerHTML = '<p class="modal-note">Carregando seu grupo…</p>';
        cbObterGrupoTela().then((resp) => {
            if (!alvo.isConnected || comunidadeTabAtiva !== 'grupo') return;
            if (!resp || !resp.ativo) {
                alvo.innerHTML = `
                    <p class="modal-note" style="margin-top:0;">Estude junto com quem você conhece: crie um grupo fechado (com código de convite) ou entre em um que alguém te mandou.</p>
                    <div class="grupo-inicio-btns">
                        <button type="button" id="btn-grupo-mostrar-criar" class="organizar-dia-btn">Criar grupo</button>
                        <button type="button" id="btn-grupo-mostrar-entrar" class="organizar-dia-btn">Entrar com código</button>
                    </div>
                `;
                return;
            }

            const membros = Object.entries(resp.membros || {})
                .map(([id, v]) => ({ id, nome: (v && v.nome) || '—', ms: (v && v.msEstudo) || 0 }))
                .sort((a, b) => b.ms - a.ms);

            const estudaram = membros.filter((m) => m.ms > 0).length;
            const chips = membros.map((m) => `
                <span class="grupo-chip${m.ms > 0 ? ' estudou' : ''}${m.id === resp.membroId ? ' voce' : ''}">${m.nome}${m.id === resp.membroId ? ' (você)' : ''}</span>
            `).join('') || '<span class="modal-note">Ninguém entrou no grupo ainda além de você.</span>';

            const linhas = membros.map((m, i) => `
                <div class="ranking-row${m.id === resp.membroId ? ' voce' : ''}">
                    <span class="ranking-pos">${i + 1}º</span>
                    <span class="ranking-apelido">${m.nome}${m.id === resp.membroId ? ' (você)' : ''}</span>
                    <span class="ranking-tempo">${(m.ms / 3600000).toFixed(1)}h</span>
                </div>
            `).join('');

            alvo.innerHTML = `
                <div class="grupo-ativo">
                    <div class="ranking-header-row">
                        <span>Código do grupo: <strong>${resp.codigo}</strong></span>
                        <button type="button" id="btn-grupo-sair" class="ranking-sair-btn">Sair</button>
                    </div>
                    <p class="modal-note" style="margin-top:0;">Compartilhe esse código com quem você quer no grupo.</p>
                    <div class="modal-goal-row" style="border-bottom:none;"><span>Quem estudou hoje (${estudaram}/${membros.length})</span></div>
                    <div class="grupo-chips">${chips}</div>
                    <hr class="comunidade-divisor">
                    <div class="ranking-header-row"><span>Ranking do grupo hoje</span></div>
                    ${linhas || '<p class="modal-note">Ninguém estudou no grupo hoje ainda.</p>'}
                </div>
            `;
        });
    }

    function renderRankingSecao(resp) {
        const { dados, rankingId, apelido, optIn } = resp || {};
        if (!optIn) {
            return `
                <div class="comunidade-ranking-optin">
                    <p class="modal-note" style="margin-top:0;">Quer aparecer num ranking individual, com um apelido sorteado automaticamente (tipo "${apelido || 'Coruja Persistente #42'}") — sem nome real, sem digitar nada, e sem ligação com seus outros dados?</p>
                    <button type="button" id="btn-ranking-optin" class="organizar-dia-btn">Participar do ranking</button>
                </div>
            `;
        }

        const lista = Object.entries(dados || {})
            .map(([id, v]) => ({ id, apelido: (v && v.apelido) || '—', ms: (v && v.msEstudo) || 0 }))
            .sort((a, b) => b.ms - a.ms)
            .slice(0, 15);

        const linhas = lista.map((it, i) => `
            <div class="ranking-row${it.id === rankingId ? ' voce' : ''}">
                <span class="ranking-pos">${i + 1}º</span>
                <span class="ranking-apelido">${it.apelido}${it.id === rankingId ? ' (você)' : ''}</span>
                <span class="ranking-tempo">${(it.ms / 3600000).toFixed(1)}h</span>
            </div>
        `).join('');

        const apareceNaLista = lista.some((it) => it.id === rankingId);

        return `
            <div class="comunidade-ranking-section">
                <div class="ranking-header-row">
                    <span>Ranking de hoje — você é <strong>${apelido}</strong></span>
                    <button type="button" id="btn-ranking-optout" class="ranking-sair-btn">Sair</button>
                </div>
                ${linhas || '<p class="modal-note">Ainda ninguém no ranking hoje — seja o primeiro!</p>'}
                ${(!apareceNaLista && lista.length) ? '<p class="modal-note">Sua posição ainda não apareceu — assim que a extensão sincronizar (até 1 min), você entra na lista.</p>' : ''}
            </div>
        `;
    }

    function renderComunidadeBarra(titulo, valorVoceTexto, valorVoceNum, valorMediaTexto, valorMediaNum) {
        const max = Math.max(valorVoceNum, valorMediaNum, 1);
        const pctVoceBar = Math.min(100, (valorVoceNum / max) * 100);
        const pctMediaBar = Math.min(100, (valorMediaNum / max) * 100);
        return `
            <div class="modal-goal-row comunidade-comp-row">
                <span>${titulo}</span>
                <div class="comunidade-bar-row">
                    <span class="comunidade-bar-label">Você</span>
                    <div class="comunidade-bar-bg"><div class="comunidade-bar-fill voce" style="width:${pctVoceBar}%"></div></div>
                    <span class="comunidade-bar-valor">${valorVoceTexto}</span>
                </div>
                <div class="comunidade-bar-row">
                    <span class="comunidade-bar-label">Comunidade</span>
                    <div class="comunidade-bar-bg"><div class="comunidade-bar-fill media" style="width:${pctMediaBar}%"></div></div>
                    <span class="comunidade-bar-valor">${valorMediaTexto}</span>
                </div>
            </div>
        `;
    }

    let calendarMonthOffset = 0;

    streakModalBody.addEventListener('click', (e) => {
        if (e.target.closest('#btn-cal-prev')) {
            calendarMonthOffset--;
            renderStreakCalendar();
        } else if (e.target.closest('#btn-cal-next')) {
            if (calendarMonthOffset < 0) {
                calendarMonthOffset++;
                renderStreakCalendar();
            }
        }
    });

    // Folha "Sua ofensiva" (estilo iOS): chama + número gigante, cartão da meta
    // de hoje com barra de progresso, e o calendário com dias redondos. As
    // classes ofe-* e ap-sheet-* vivem em apple.css.
    const OFE_CHAMA = '<svg viewBox="0 0 24 24" aria-hidden="true"><defs><linearGradient id="ofe-fogo" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffd166"/><stop offset="0.5" stop-color="#ff9f43"/><stop offset="1" stop-color="#ff5e3a"/></linearGradient></defs><path class="ofe-chama-forma" stroke-linejoin="round" stroke-linecap="round" d="M12 2.4c.4 2.7 1.7 4.7 3.3 6.3 1.7 1.7 3.2 3.4 3.2 6.2a6.5 6.5 0 0 1-13 0c0-1.5.5-2.8 1.3-3.7.5 1.3 1.4 2.1 2.7 2.4-.7-2.6.1-5.3 2.5-8.1.4 2.2 1.1 3.4 1.9 4.6-.2-3.1-.7-5.2-1.9-7.7Z"/></svg>';
    const OFE_SETA_ESQ = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6"/></svg>';
    const OFE_SETA_DIR = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>';

    function abrirModalStreak() {
        const today = getTodayKey();
        chrome.storage.local.get(['streakCount', 'studyHistory'], (result) => {
            const streak = result.streakCount || 0;
            const time = (result.studyHistory || {})[today] || 0;
            const ok = time >= dailyGoalMs;
            const goalHoras = dailyGoalMs / (60 * 60 * 1000);
            const goalHorasFmt = Number.isInteger(goalHoras) ? goalHoras : goalHoras.toFixed(1).replace('.', ',');
            const pct = dailyGoalMs > 0 ? Math.min(100, Math.round((time / dailyGoalMs) * 100)) : 0;
            // A chama só "acende" quando há ofensiva rodando ou a meta de hoje já foi batida.
            const acesa = streak > 0 || ok;

            const frase = ok
                ? 'Você garantiu a ofensiva de hoje. Volte amanhã para continuar.'
                : (streak === 0
                    ? 'Bata a meta hoje pra começar uma nova ofensiva!'
                    : 'Bata a meta hoje pra manter sua ofensiva. O dia só conta se a meta for batida antes da virada.');

            streakModalBody.innerHTML = `
                <section class="ofe-hero">
                    <div class="ofe-chama${acesa ? ' on' : ''}">${OFE_CHAMA}</div>
                    <div class="ofe-numero">${streak}</div>
                    <div class="ofe-rotulo">${streak === 1 ? 'dia seguido' : 'dias seguidos'}</div>
                    <p class="ofe-frase">${frase}</p>
                </section>

                <section class="ofe-card">
                    <div class="ofe-meta-topo">
                        <span class="ofe-meta-tit">Meta de hoje</span>
                        ${ok
                            ? '<span class="ofe-pilula ok"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 5 5 9-10"/></svg>Batida</span>'
                            : `<span class="ofe-pilula pend">Faltam ${formatHoursMinutes(Math.max(0, dailyGoalMs - time))}</span>`}
                    </div>
                    <div class="ofe-meta-valor">${formatHoursMinutes(time)} <small>de ${goalHorasFmt}h</small></div>
                    <div class="ofe-barra" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${pct}"><i style="width:0%" data-alvo="${pct}"></i></div>
                </section>

                <section class="ofe-card" id="streak-calendar"></section>
            `;
            calendarMonthOffset = 0;
            renderStreakCalendar();
            streakModalOverlay.classList.add('open');
            // A barra "enche" depois de aparecer — transição suave em vez de já nascer cheia.
            requestAnimationFrame(() => requestAnimationFrame(() => {
                const barra = streakModalBody.querySelector('.ofe-barra i');
                if (barra) barra.style.width = barra.dataset.alvo + '%';
            }));
        });
    }

    function renderStreakCalendar() {
        const calContainer = document.getElementById('streak-calendar');
        if (!calContainer) return;

        chrome.storage.local.get(['studyHistory'], (result) => {
            const study = result.studyHistory || {};
            const agora = new Date();
            const refDate = new Date(agora.getFullYear(), agora.getMonth() + calendarMonthOffset, 1);
            const ano = refDate.getFullYear();
            const mes = refDate.getMonth();

            const nomeMes = refDate.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' }).replace(' de ', ' ');
            const primeiroDiaSemana = new Date(ano, mes, 1).getDay();
            const diasNoMes = new Date(ano, mes + 1, 0).getDate();
            const todayKey = getTodayKey();

            let diasHtml = '';
            for (let i = 0; i < primeiroDiaSemana; i++) {
                diasHtml += `<div class="ofe-dia vazio"></div>`;
            }
            for (let dia = 1; dia <= diasNoMes; dia++) {
                const key = `${ano}-${String(mes + 1).padStart(2, '0')}-${String(dia).padStart(2, '0')}`;
                const tempo = study[key] || 0;
                const isFuture = key > todayKey;
                const isToday = key === todayKey;

                let estado = 'nada';
                if (isFuture) estado = 'futuro';
                else if (tempo >= dailyGoalMs) estado = 'met';
                else if (tempo > 0) estado = 'parcial';

                const titulo = isFuture ? '' : (tempo > 0 ? `${formatHoursMinutes(tempo)} estudadas` : 'Sem estudo');

                diasHtml += `<div class="ofe-dia ${estado}${isToday ? ' hoje' : ''}" title="${titulo}">${dia}</div>`;
            }

            calContainer.innerHTML = `
                <div class="ofe-cal-cab">
                    <span class="ofe-cal-mes">${nomeMes}</span>
                    <span class="ofe-cal-nav">
                        <button id="btn-cal-prev" title="Mês anterior" aria-label="Mês anterior">${OFE_SETA_ESQ}</button>
                        <button id="btn-cal-next" ${calendarMonthOffset >= 0 ? 'disabled' : ''} title="Próximo mês" aria-label="Próximo mês">${OFE_SETA_DIR}</button>
                    </span>
                </div>
                <div class="ofe-cal-sem">
                    <span>D</span><span>S</span><span>T</span><span>Q</span><span>Q</span><span>S</span><span>S</span>
                </div>
                <div class="ofe-cal-grid">${diasHtml}</div>
                <div class="ofe-leg">
                    <span><i class="m"></i>Meta batida</span>
                    <span><i class="p"></i>Estudou, não bateu</span>
                    <span><i class="n"></i>Sem estudo</span>
                </div>
            `;
        });
    }

    // ===================== NÍVEIS E CONQUISTAS =====================

    function renderLevelCard() {
        chrome.storage.local.get(['unlockedLevelIndex', 'totalStudyMs'], (result) => {
            const totalMs = result.totalStudyMs || 0;
            const totalHoras = totalMs / (60 * 60 * 1000);
            const idx = (result.unlockedLevelIndex !== undefined) ? result.unlockedLevelIndex : 0;
            const nivelAtual = LEVELS[idx];
            const proximoNivel = LEVELS[idx + 1];

            levelNameText.innerText = nivelAtual.name;
            levelHoursText.innerText = `${totalHoras.toFixed(1)}h estudadas`;

            if (proximoNivel) {
                const faixa = proximoNivel.hours - nivelAtual.hours;
                const progresso = Math.max(0, Math.min(100, ((totalHoras - nivelAtual.hours) / faixa) * 100));
                levelProgressFill.style.width = `${progresso}%`;
                const faltamHoras = Math.max(0, proximoNivel.hours - totalHoras).toFixed(1);
                levelNextText.innerText = `Faltam ${faltamHoras}h para o nível "${proximoNivel.name}".`;
            } else {
                levelProgressFill.style.width = '100%';
                levelNextText.innerText = 'Você alcançou o nível máximo. Lenda dos concursos!';
            }
        });
    }

    if (btnOpenBadges) {
        btnOpenBadges.addEventListener('click', abrirModalBadges);
    }
    if (badgesModalClose) {
        badgesModalClose.addEventListener('click', () => badgesModalOverlay.classList.remove('open'));
    }
    if (badgesModalOverlay) {
        badgesModalOverlay.addEventListener('click', (e) => {
            if (e.target === badgesModalOverlay) badgesModalOverlay.classList.remove('open');
        });
    }

    // Nomes amigáveis das features, usados só pra mostrar na aba de
    // conquistas o que cada nível libera pra quem ainda é FREE.
    const CB_FEATURE_LABELS = {
        themes: 'Temas extras',
        ambient_sound: 'Som ambiente',
        hardcore_mode: 'Modo hardcore',
        reorder_sections: 'Reordenar seções',
        reorder_tabs: 'Reordenar abas',
        pomodoro: 'Sistema Pomodoro',
        monthly_productivity: 'Produtividade mensal',
        monthly_history: 'Histórico mensal',
        questoes: 'Sistema de questões',
        calendar: 'Calendário/navegação',
        edit_daily_goal: 'Editar meta diária',
        breaks_activity: 'Pausas e atividade'
    };

    async function abrirModalBadges() {
        const unlockedMapAtual = window.CBLicense ? await window.CBLicense.getUnlockedMap() : {};
        // "PRO completo" = todas as features já vêm da licença de verdade;
        // nesse caso não faz sentido mostrar dica de desbloqueio por nível.
        const featureKeysAll = Object.values(window.CBLicense ? window.CBLicense.FEATURES : {});
        const isFullPro = featureKeysAll.length > 0 && featureKeysAll.every(f => unlockedMapAtual[f]);

        chrome.storage.local.get(['unlockedLevelIndex', 'totalStudyMs', 'unlockedStreakMilestones', 'streakCount'], (result) => {
            const idx = (result.unlockedLevelIndex !== undefined) ? result.unlockedLevelIndex : 0;
            const totalHoras = (result.totalStudyMs || 0) / (60 * 60 * 1000);
            const streakAtual = result.streakCount || 0;
            const milestonesDesbloqueados = result.unlockedStreakMilestones || [];

            const levelsHtml = LEVELS.map((lvl, i) => {
                const desbloqueado = i <= idx;
                const featuresDoNivel = (ACHIEVEMENT_FEATURE_MAP[i] || []).map(f => CB_FEATURE_LABELS[f] || f);
                const unlockHint = (!isFullPro && featuresDoNivel.length > 0)
                    ? `<span class="badge-unlock-hint">${desbloqueado ? 'Liberou: ' : 'Libera: '}${featuresDoNivel.join(', ')}</span>`
                    : '';
                return `
                    <div class="badge-item ${desbloqueado ? 'unlocked' : 'locked'}">
                        <span class="badge-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2 9.5 8.5 3 9l5 4.6L6.5 20 12 16.3 17.5 20 16 13.6l5-4.6-6.5-.5Z"/></svg>
                        </span>
                        <span class="badge-info">
                            <span class="badge-name">${lvl.name}</span>
                            <span class="badge-req">${lvl.hours}h de estudo</span>
                            ${unlockHint}
                        </span>
                        ${desbloqueado ? '<span class="badge-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m5 12 5 5 9-10"/></svg></span>' : ''}
                    </div>
                `;
            }).join('');

            const streakHtml = STREAK_MILESTONES.map(m => {
                const desbloqueado = milestonesDesbloqueados.includes(m);
                return `
                    <div class="badge-item ${desbloqueado ? 'unlocked' : 'locked'}">
                        <span class="badge-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8.5 14.5A2.5 2.5 0 0 0 11 17a2.5 2.5 0 0 0 2.5-2.5c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7.5 7.5 0 1 1-15 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5"/></svg>
                        </span>
                        <span class="badge-info">
                            <span class="badge-name">${m} dias de ofensiva</span>
                            <span class="badge-req">Bater a meta ${m} dias seguidos</span>
                        </span>
                        ${desbloqueado ? '<span class="badge-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m5 12 5 5 9-10"/></svg></span>' : ''}
                    </div>
                `;
            }).join('');

            badgesModalBody.innerHTML = `
                <p class="modal-note" style="margin-top:0;">Total estudado: <strong>${totalHoras.toFixed(1)}h</strong> · Ofensiva atual: <strong>${streakAtual} dia${streakAtual === 1 ? '' : 's'}</strong></p>
                <h4 class="section-title" style="margin-top:14px;">Níveis</h4>
                <div class="badge-list">${levelsHtml}</div>
                <h4 class="section-title" style="margin-top:16px;">Ofensiva</h4>
                <div class="badge-list">${streakHtml}</div>
            `;
            badgesModalOverlay.classList.add('open');
        });
    }

    function startTimerUpdate() {
        if (timerInterval) clearInterval(timerInterval);
        timerInterval = setInterval(() => {
            updateTimerDisplay();
            updateGoalProgress();
            renderPomodoroIndicator();
            cbTickModoAnel();
        }, 1000);
    }

    function stopTimerUpdate() {
        if (timerInterval) {
            clearInterval(timerInterval);
            timerInterval = null;
        }
    }

    function getTodayKey() {
        const d = new Date();
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    function updateTimerDisplay() {
        if (cbRingMode !== 'total') return;
        const today = getTodayKey();
        chrome.storage.local.get(['studyHistory'], (result) => {
            const history = result.studyHistory || {};
            const timeToday = history[today] || 0;
            timerDisplay.innerText = formatTime(timeToday);
        });
    }

    // ===================== ARRASTAR O CRONÔMETRO PARA SOLTAR NA TELA =====================
    // Como o popup fecha sozinho quando perde o foco, não dá pra "arrastar de
    // verdade" pra fora dele. O efeito é simulado: ao arrastar o ícone da mão
    // (canto superior esquerdo do card) por uma distância razoável (o
    // "fantasma" acompanha o cursor pra dar a sensação de puxar o
    // cronômetro), soltar liga um widget flutuante que o global_overlay.js
    // desenha por cima da página atual — daí sim ele fica "solto na tela",
    // inclusive depois do popup fechar.
    //
    // Antes esse gesto começava no anel inteiro, o que exigia um
    // setPointerCapture nele e acabava "sequestrando" o clique de trocar de
    // modo (violeta/Pomodoro). Agora o gesto só existe nesse botão dedicado,
    // então o anel fica livre pra só responder a clique normal.
    const CB_TIMER_DRAG_THRESHOLD = 46;

    function initTimerDragToFloat() {
        if (!btnFloatHandle || !timerDragWrap) return;
        let dragging = false, startX = 0, startY = 0, armed = false, ghost = null, pointerId = null;

        function criarGhost(x, y) {
            ghost = document.createElement('div');
            ghost.className = 'cb-timer-ghost';
            ghost.innerText = timerDisplay.innerText;
            ghost.style.left = x + 'px';
            ghost.style.top = y + 'px';
            document.body.appendChild(ghost);
        }
        function moverGhost(x, y) {
            if (ghost) { ghost.style.left = x + 'px'; ghost.style.top = y + 'px'; }
        }
        function removerGhost() {
            if (ghost) { ghost.remove(); ghost = null; }
        }

        btnFloatHandle.addEventListener('pointerdown', (e) => {
            if (e.button !== undefined && e.button !== 0) return;
            dragging = true;
            armed = false;
            startX = e.clientX;
            startY = e.clientY;
            pointerId = e.pointerId;
            btnFloatHandle.classList.add('cb-dragging');
            timerDragWrap.classList.add('cb-dragging');
            try { btnFloatHandle.setPointerCapture(pointerId); } catch (err) {}
        });

        btnFloatHandle.addEventListener('pointermove', (e) => {
            if (!dragging) return;
            const dist = Math.hypot(e.clientX - startX, e.clientY - startY);
            if (dist > 10 && !ghost) criarGhost(e.clientX, e.clientY);
            moverGhost(e.clientX, e.clientY);
            const passouLimite = dist > CB_TIMER_DRAG_THRESHOLD;
            if (passouLimite !== armed) {
                armed = passouLimite;
                timerDragWrap.classList.toggle('cb-armed', armed);
                if (ghost) ghost.style.opacity = armed ? '1' : '0.7';
            }
        });

        function finalizarArraste() {
            if (!dragging) return;
            dragging = false;
            btnFloatHandle.classList.remove('cb-dragging');
            timerDragWrap.classList.remove('cb-dragging', 'cb-armed');
            removerGhost();
            if (armed) {
                cbGarantirPermissaoAmpla('o cronômetro flutuante', (concedida) => {
                    if (!concedida) return;
                    chrome.storage.local.set({ floatingTimerEnabled: true }, () => {
                        window.close();
                    });
                });
            }
            armed = false;
        }
        btnFloatHandle.addEventListener('pointerup', finalizarArraste);
        btnFloatHandle.addEventListener('pointercancel', finalizarArraste);
    }
    initTimerDragToFloat();

    // ===================== LIGAR/DESLIGAR O RECURSO DE CRONÔMETRO FLUTUANTE =====================
    const chkFloatingTimerMaster = document.getElementById('chk-floating-timer-master');
    const ftStyleSection = document.getElementById('ft-style-section');

    function cbAplicarEstadoRecursoFlutuante(habilitado) {
        if (btnFloatHandle) btnFloatHandle.style.display = habilitado ? '' : 'none';
        if (ftStyleSection) ftStyleSection.style.opacity = habilitado ? '1' : '0.5';
        if (ftStyleSection) ftStyleSection.style.pointerEvents = habilitado ? '' : 'none';
    }

    chrome.storage.local.get(['floatingTimerFeatureEnabled'], (result) => {
        // Ausente = ligado por padrão (recurso já existia; isso só adiciona a opção de desligar).
        const habilitado = result.floatingTimerFeatureEnabled !== false;
        if (chkFloatingTimerMaster) chkFloatingTimerMaster.checked = habilitado;
        cbAplicarEstadoRecursoFlutuante(habilitado);
    });

    chkFloatingTimerMaster?.addEventListener('change', () => {
        const habilitado = chkFloatingTimerMaster.checked;
        cbAplicarEstadoRecursoFlutuante(habilitado);
        const dados = { floatingTimerFeatureEnabled: habilitado };
        // Desligando o recurso, também tira o widget de qualquer página onde
        // estivesse solto no momento (não faz sentido deixar ele lá sem como
        // reabrir o popup pra reencaixar).
        if (!habilitado) dados.floatingTimerEnabled = false;
        chrome.storage.local.set(dados, atualizarEstadoFlutuante);
    });

    function atualizarEstadoFlutuante() {
        chrome.storage.local.get(['floatingTimerEnabled'], (result) => {
            const flutuando = !!result.floatingTimerEnabled;
            if (timerDragWrap) timerDragWrap.style.display = flutuando ? 'none' : '';
            if (timerFloatBanner) timerFloatBanner.style.display = flutuando ? 'flex' : 'none';
        });
    }
    atualizarEstadoFlutuante();
    btnTimerDock?.addEventListener('click', () => {
        chrome.storage.local.set({ floatingTimerEnabled: false }, atualizarEstadoFlutuante);
    });
    chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local' && changes.floatingTimerEnabled) atualizarEstadoFlutuante();
    });

    // ===================== PERSONALIZAÇÃO DO CRONÔMETRO FLUTUANTE =====================
    const ftSizeGroup = document.getElementById('ft-size-group');
    const ftShapeGroup = document.getElementById('ft-shape-group');
    const ftColorGroup = document.getElementById('ft-color-group');
    const inputFtCustomColor = document.getElementById('input-ft-custom-color');
    const ftPreview = document.getElementById('ft-preview');

    const FT_DEFAULTS = { floatingTimerSize: 'md', floatingTimerShape: 'pill', floatingTimerColor: '#8b5cf6' };
    const FT_CORES_PRESET = ['#8b5cf6', '#3b82f6', '#8b5cf6', '#ff6c3f', '#ec4899'];

    function aplicarEstiloNaPreview(size, shape, color) {
        if (!ftPreview) return;
        ftPreview.className = `ft-preview cb-ft-size-${size} cb-ft-shape-${shape}`;
        ftPreview.style.setProperty('--cb-ft-accent', color);
        // Mesma regra do widget real: no Círculo mostra "HH:MM" (sem
        // segundos) porque é o que cabe direito numa bolinha pequena — a
        // prévia tem que bater exatamente com o resultado de verdade.
        const previewTime = ftPreview.querySelector('.ft-preview-time');
        if (previewTime) previewTime.textContent = shape === 'circle' ? '01:03' : '01:03:09';
    }

    function marcarAtivos(size, shape, color) {
        ftSizeGroup?.querySelectorAll('.ft-opt').forEach(b => b.classList.toggle('active', b.dataset.size === size));
        ftShapeGroup?.querySelectorAll('.ft-opt').forEach(b => b.classList.toggle('active', b.dataset.shape === shape));
        ftColorGroup?.querySelectorAll('.ft-color-swatch[data-color]').forEach(b => {
            const ativo = b.dataset.color.toLowerCase() === color.toLowerCase();
            b.classList.toggle('active', ativo);
            b.style.color = b.dataset.color; // usado pelo box-shadow "currentColor" quando ativo
        });
        if (inputFtCustomColor) inputFtCustomColor.value = FT_CORES_PRESET.includes(color) ? '#8b5cf6' : color;
    }

    function carregarEstiloFloatingTimer() {
        chrome.storage.local.get(['floatingTimerSize', 'floatingTimerShape', 'floatingTimerColor'], (result) => {
            const size = result.floatingTimerSize || FT_DEFAULTS.floatingTimerSize;
            const shape = result.floatingTimerShape || FT_DEFAULTS.floatingTimerShape;
            const color = result.floatingTimerColor || FT_DEFAULTS.floatingTimerColor;
            marcarAtivos(size, shape, color);
            aplicarEstiloNaPreview(size, shape, color);
        });
    }
    carregarEstiloFloatingTimer();

    ftSizeGroup?.querySelectorAll('.ft-opt').forEach(btn => {
        btn.addEventListener('click', () => {
            chrome.storage.local.set({ floatingTimerSize: btn.dataset.size }, carregarEstiloFloatingTimer);
        });
    });
    ftShapeGroup?.querySelectorAll('.ft-opt').forEach(btn => {
        btn.addEventListener('click', () => {
            chrome.storage.local.set({ floatingTimerShape: btn.dataset.shape }, carregarEstiloFloatingTimer);
        });
    });
    ftColorGroup?.querySelectorAll('.ft-color-swatch[data-color]').forEach(btn => {
        btn.addEventListener('click', () => {
            chrome.storage.local.set({ floatingTimerColor: btn.dataset.color }, carregarEstiloFloatingTimer);
        });
    });
    inputFtCustomColor?.addEventListener('input', () => {
        chrome.storage.local.set({ floatingTimerColor: inputFtCustomColor.value }, carregarEstiloFloatingTimer);
    });

    function renderPomodoroIndicator() {
        chrome.storage.local.get(['pomodoroMode', 'pomodoroState', 'pomodoroTimeLeft', 'pomodoroEndAt'], (result) => {
            if (result.pomodoroMode) {
                let timeLeft = result.pomodoroTimeLeft || 0;
                // Se tem endAt, calcula o tempo restante real em tempo real
                if (result.pomodoroEndAt && result.pomodoroState === 'work') {
                    timeLeft = Math.max(0, Math.round((result.pomodoroEndAt - Date.now()) / 1000));
                }
                const minutes = Math.floor(timeLeft / 60);
                const seconds = timeLeft % 60;
                const clock = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

                if (result.pomodoroState === 'work') {
                    pomodoroIndicator.className = 'pomodoro-indicator visible work';
                    pomodoroIndicator.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2 3 14h9l-1 8 10-12h-9l1-8Z"/></svg>Foco Pomodoro · ${clock}`;
                } else {
                    pomodoroIndicator.className = 'pomodoro-indicator visible rest';
                    pomodoroIndicator.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8h1a4 4 0 0 1 0 8h-1"/><path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4Z"/><path d="M6 1v3M10 1v3M14 1v3"/></svg>Descanso Pomodoro · ${clock}`;
                }
            } else {
                pomodoroIndicator.className = 'pomodoro-indicator';
                pomodoroIndicator.innerHTML = '';
            }
        });
    }

    function updateUIState(state, emPausaPomodoro) {
        statusTag.className = `tag ${state}`;
        // Estudando (cronômetro rodando, ou descanso do Pomodoro, igual ao "modo de estudo" logo
        // abaixo): o CSS esconde também o cartão "Plano de hoje" e a ilha de atalhos, para sobrar
        // só o cronômetro (ver "body.cb-estudando" em ajustes-visuais.css).
        document.body.classList.toggle('cb-estudando', state === 'running' || !!emPausaPomodoro);
        atualizarEstadoHardcoreUI();
        if (cbRing) {
            aplicarClassesRing(state, emPausaPomodoro);
        }
        if (state === 'running' || emPausaPomodoro) {
            statusTag.innerText = emPausaPomodoro ? "Descanso Pomodoro" : "Estudando";
            btnPlay.style.display = 'none';
            btnPause.style.display = 'block';
            configCard.style.display = 'none'; 
            // Modo de estudo ativo: esconde tudo abaixo do cronômetro para evitar distrações.
            if (sectionConfig) sectionConfig.style.display = 'none';
            if (sectionMeta) sectionMeta.style.display = 'none';
            if (sectionConquistas) sectionConquistas.style.display = 'none';
            if (sectionTabs) sectionTabs.style.display = 'none';
            if (cronogramaAlertBanner) cronogramaAlertBanner.style.display = 'none';
        } else {
            btnPlay.style.display = 'block';
            btnPause.style.display = 'none';
            configCard.style.display = 'block'; 
            // Fora do modo de estudo: restaura as seções normalmente.
            if (sectionConfig) sectionConfig.style.display = '';
            if (sectionMeta) sectionMeta.style.display = '';
            if (sectionConquistas) sectionConquistas.style.display = '';
            if (sectionTabs) sectionTabs.style.display = '';
            if (cronogramaAlertBanner) cronogramaAlertBanner.style.display = '';

            if (state === 'paused_manual') {
                statusTag.innerText = "Pausado (Manual)";
                btnPlay.innerText = "Retomar Estudos";
            } else if (state === 'paused_away') {
                statusTag.innerText = "Ausente da Tela";
                btnPlay.innerText = "Retomar Manual";
            } else {
                statusTag.innerText = "Desconectado";
                btnPlay.innerText = "Iniciar Estudo";
            }
        }
        chrome.storage.local.get(['activeMethod', 'activeActivity'], (result) => {
            atualizarLabelFoco(result.activeMethod || 'online', result.activeActivity || 'questoes');
        });
    }

    function updateGoalProgress() {
        const today = getTodayKey();
        if (metaModo === 'questoes') {
            chrome.storage.local.get(['questoesDailyHistory'], (result) => {
                const historico = result.questoesDailyHistory || {};
                const feitas = (historico[today] || {}).total || 0;
                const percent = dailyGoalQuestoes > 0 ? Math.min(Math.round((feitas / dailyGoalQuestoes) * 100), 100) : 0;
                goalText.innerHTML = `<span class="goal-pct">${percent}<small>%</small></span><span class="goal-det"><b>${feitas}</b> de ${dailyGoalQuestoes} questões</span>`;
                progressFill.style.width = `${percent}%`;
            });
            return;
        }
        chrome.storage.local.get(['studyHistory'], (result) => {
            const history = result.studyHistory || {};
            const time = history[today] || 0;
            const percent = Math.min(Math.round((time / dailyGoalMs) * 100), 100);
            goalText.innerHTML = `<span class="goal-pct">${percent}<small>%</small></span><span class="goal-det"><b>${cbFmtDuracao(time)}</b> de ${cbFmtDuracao(dailyGoalMs)}</span>`;
            progressFill.style.width = `${percent}%`;
            if (cbRingMode === 'total') cbAtualizarAnelProgresso(percent);
        });
    }

    // Anel violeta do cronômetro: mostra QUANTO DA META DIÁRIA VOCÊ JÁ FEZ.
    //
    // ANTES ele funcionava ao contrário: começava cheio e ia esvaziando, como
    // uma contagem regressiva. O efeito colateral era o pior possível — quem
    // batia a meta via o anel COMPLETAMENTE VAZIO, ou seja, o dia mais
    // produtivo do mês era desenhado como um círculo cinza apagado. E, nos
    // temas claros, "vazio" e "não existe anel nenhum" são a mesma imagem.
    //
    // Agora enche conforme você estuda, que é o que todo anel de progresso
    // faz e o que qualquer pessoa espera antes de ler qualquer legenda.
    const CB_RING_CIRCUNFERENCIA = 2 * Math.PI * 98;
    function cbAtualizarAnelProgresso(percent) {
        if (!cbRingProgress) return;
        const clamped = Math.max(0, Math.min(100, percent));
        const offset = CB_RING_CIRCUNFERENCIA * (1 - clamped / 100);
        cbRingProgress.style.strokeDashoffset = offset;
    }

    function parseKeyToDate(key) {
        const [y, m, d] = key.split('-').map(Number);
        return new Date(y, m - 1, d);
    }

    // ===================== DOIS MODOS NO MESMO ANEL: TOTAL x POMODORO =====================
    // 'total'    (violeta) -> tempo total estudado hoje (comportamento original)
    // 'pomodoro' (branco/prateado) -> contagem regressiva até a próxima troca de fase
    // Alterna tocando no anel ou nos pontinhos indicadores; só é possível ir para
    // o modo Pomodoro quando o Ciclo Pomodoro está ativado nas configurações.
    //
    // Por enquanto esse recurso fica DESATIVADO por padrão (ver opção
    // "Alternância do Cronômetro no Anel" nas configurações, travada em
    // desligado com aviso de "em breve") — o anel sempre mostra só o tempo
    // total até essa opção ser liberada de verdade numa próxima versão.
    const CB_MODO_ANEL_HABILITADO = false;
    let cbRingMode = 'total';
    const cbRingModeDots = document.querySelectorAll('#cb-ring-mode-dots .cb-ring-mode-dot');
    const cbRingSubText = document.getElementById('cb-ring-sub-text');
    const cbRingModeDotsWrap = document.getElementById('cb-ring-mode-dots');
    if (!CB_MODO_ANEL_HABILITADO && cbRingModeDotsWrap) cbRingModeDotsWrap.style.display = 'none';

    function cbMarcarDotAtivo(modo) {
        cbRingModeDots.forEach(dot => dot.classList.toggle('active', dot.dataset.mode === modo));
    }

    function cbFmtMMSS(totalSegundos) {
        const s = Math.max(0, Math.round(totalSegundos));
        const m = String(Math.floor(s / 60)).padStart(2, '0');
        const sec = String(s % 60).padStart(2, '0');
        return `${m}:${sec}`;
    }

    function cbAtualizarAnelPomodoro() {
        chrome.storage.local.get(['pomodoroMode', 'pomodoroState', 'pomodoroTimeLeft', 'pomodoroEndAt', 'sessionState'], (localRes) => {
            if (!localRes.pomodoroMode) {
                // Pomodoro foi desligado enquanto o anel estava nesse modo: volta pro total.
                cbAlternarModoAnel('total');
                return;
            }
            chrome.storage.sync.get(['pomodoroWorkMinutes', 'pomodoroRestMinutes'], (syncRes) => {
                const workMin = syncRes.pomodoroWorkMinutes || 25;
                const restMin = syncRes.pomodoroRestMinutes || 5;
                const emFoco = localRes.pomodoroState !== 'rest';
                const totalFaseSeg = (emFoco ? workMin : restMin) * 60;

                let restanteSeg;
                if (localRes.sessionState === 'running' && localRes.pomodoroEndAt) {
                    restanteSeg = Math.max(0, Math.round((localRes.pomodoroEndAt - Date.now()) / 1000));
                } else {
                    restanteSeg = localRes.pomodoroTimeLeft || totalFaseSeg;
                }

                if (cbRing) cbRing.classList.add('mode-pomodoro');
                timerDisplay.innerText = cbFmtMMSS(restanteSeg);
                if (cbRingSubText) {
                    cbRingSubText.style.display = '';
                    cbRingSubText.textContent = emFoco ? 'até o descanso' : 'até o foco';
                }
                // Repare que aqui vai o tempo QUE FALTA, e não o que já passou.
                // Os dois modos usam a mesma função e ficam com sentidos
                // opostos de propósito:
                //   meta do dia -> o anel ENCHE conforme você estuda;
                //   pomodoro    -> o anel ESVAZIA conforme a fase acaba.
                // É o que cada um significa: a meta é uma conquista que se
                // acumula, o pomodoro é uma contagem regressiva.
                const fracao = totalFaseSeg > 0 ? (restanteSeg / totalFaseSeg) * 100 : 0;
                cbAtualizarAnelProgresso(fracao);
            });
        });
    }

    function cbAtualizarAnelTotal() {
        if (cbRing) cbRing.classList.remove('mode-pomodoro');
        // "Estudado hoje" foi removido daqui por pedido — ficava redundante
        // ao lado do rótulo "Offline · Leitura" logo acima, e visualmente
        // não combinava. No modo Pomodoro o rótulo continua (linha acima),
        // porque ali ele diz algo que não dá pra saber só olhando o anel:
        // se a contagem é até o descanso ou até o próximo foco.
        if (cbRingSubText) { cbRingSubText.textContent = ''; cbRingSubText.style.display = 'none'; }
        updateTimerDisplay();
        updateGoalProgress();
    }

    function cbAlternarModoAnel(forcarModo) {
        const aplicar = (modo) => {
            cbRingMode = modo;
            cbMarcarDotAtivo(modo);
            if (modo === 'pomodoro') cbAtualizarAnelPomodoro();
            else cbAtualizarAnelTotal();
        };
        if (forcarModo === 'total') { aplicar('total'); return; }
        if (forcarModo === 'pomodoro' || cbRingMode === 'total') {
            // Só entra no modo Pomodoro se ele estiver realmente ativado.
            chrome.storage.local.get(['pomodoroMode'], (res) => {
                aplicar(res.pomodoroMode ? 'pomodoro' : 'total');
            });
        } else {
            aplicar('total');
        }
    }

    if (cbRing && CB_MODO_ANEL_HABILITADO) cbRing.addEventListener('click', () => cbAlternarModoAnel());
    if (CB_MODO_ANEL_HABILITADO) cbRingModeDots.forEach(dot => {
        dot.addEventListener('click', (e) => {
            e.stopPropagation();
            cbAlternarModoAnel(dot.dataset.mode);
        });
    });

    // Chamado a cada tick do cronômetro (ver startTimerUpdate) pra manter o
    // modo Pomodoro do anel vivo mesmo sem o usuário tocar em nada.
    function cbTickModoAnel() {
        if (cbRingMode === 'pomodoro') cbAtualizarAnelPomodoro();
    }

    function formatHoursMinutes(ms) {
        const totalMin = Math.round(ms / 60000);
        const h = Math.floor(totalMin / 60);
        const m = totalMin % 60;
        if (h === 0) return `${m}m`;
        return `${h}h ${String(m).padStart(2, '0')}m`;
    }

    function getDateKeysForPeriod(period, refDate) {
        const keys = [];
        // 'day' aqui é 1 porque a aba de Produtividade mostra a distribuição
        // POR HORÁRIO de um dia; juntar vários dias misturaria rotinas
        // diferentes num só desenho. O gráfico de Evolução, que compara dias
        // entre si, usa outra contagem — ver CB_DIAS_POR_PERIODO.
        const dias = period === 'day' ? 1
                   : (period === 'week' ? 7
                   : (period === 'semester' ? 182 : 30));
        for (let i = 0; i < dias; i++) {
            let d = new Date(refDate);
            d.setDate(refDate.getDate() - i);
            keys.push(d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'));
        }
        return keys;
    }

    const QUESTOES_PERIOD_LABELS = { 1: 'hoje', 7: 'nos últimos 7 dias', 30: 'nos últimos 30 dias' };

    // Intervalo de confiança de Wilson (95%) para uma proporção binomial.
    // É o método recomendado estatisticamente (inclusive pela literatura de
    // testes A/B e epidemiologia) em vez do intervalo normal simples,
    // porque continua confiável mesmo com poucas questões — é o que dá
    // seriedade científica ao "X% de acerto" em vez de ser só um número solto.
    function wilsonInterval(acertos, total, z = 1.959963985) {
        if (!total) return { p: 0, lo: 0, hi: 0, moe: 0 };
        const p = acertos / total;
        const z2 = z * z;
        const denom = 1 + z2 / total;
        const centro = p + z2 / (2 * total);
        const ajuste = z * Math.sqrt((p * (1 - p) + z2 / (4 * total)) / total);
        const lo = Math.max(0, (centro - ajuste) / denom);
        const hi = Math.min(1, (centro + ajuste) / denom);
        return { p, lo, hi, moe: (hi - lo) / 2 };
    }

    // Classificação da robustez estatística da amostra — usada para colorir
    // o selo de confiabilidade e para o texto de rodapé.
    function classificarConfianca(n) {
        if (n >= 100) return { nivel: 'alta', label: 'Alta confiabilidade', cor: 'ok' };
        if (n >= 30) return { nivel: 'media', label: 'Confiabilidade moderada', cor: 'mid' };
        if (n >= 8) return { nivel: 'baixa', label: 'Amostra pequena', cor: 'low' };
        return { nivel: 'minima', label: 'Amostra mínima', cor: 'low' };
    }

    function animarNumero(el, valorFinal, sufixo = '', duracaoMs = 700) {
        if (!el) return;
        if (document.documentElement.classList.contains('cb-lite')) { el.textContent = `${valorFinal}${sufixo}`; return; }
        const inicio = performance.now();
        const de = 0;
        function passo(agora) {
            const t = Math.min(1, (agora - inicio) / duracaoMs);
            const eased = 1 - Math.pow(1 - t, 3);
            const atual = Math.round(de + (valorFinal - de) * eased);
            el.textContent = `${atual}${sufixo}`;
            if (t < 1) requestAnimationFrame(passo);
        }
        requestAnimationFrame(passo);
    }

    function renderQuestoesPerformance() {
        if (!questoesRender) return;
        chrome.storage.local.get(['questoesPeriodStats', 'qcSyncDebug', 'questoesDailyHistory'], (result) => {
            const stats = result.questoesPeriodStats || {};
            const periodo = stats[currentQuestoesPeriod] || { acertos: 0, erros: 0, total: 0 };
            const total = periodo.total || (periodo.acertos + periodo.erros);

            const sempre = stats[999];
            let rodapeHtml = '';
            if (sempre && sempre.total > 0) {
                const pctSempre = Math.round((sempre.acertos / sempre.total) * 100);
                rodapeHtml = `
                    <div class="questoes-lifetime">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>
                        <span>Desde sempre no QConcursos: <strong>${sempre.total.toLocaleString('pt-BR')}</strong> questões • <strong>${pctSempre}%</strong> de acerto histórico</span>
                    </div>`;
            }

            // Diagnóstico visível sem precisar abrir o DevTools: mostra o
            // resultado da última tentativa de buscar os dados no QC.
            const debug = result.qcSyncDebug;
            let debugHtml = '';
            if (debug && debug.atualizadoEm) {
                const minutosAtras = Math.round((Date.now() - debug.atualizadoEm) / 60000);
                const quando = minutosAtras <= 0 ? 'agora mesmo' : `há ${minutosAtras} min`;
                if (debug.erro) {
                    debugHtml = `<p class="questoes-empty questoes-empty--err">Última tentativa de sincronizar (${quando}) falhou: ${debug.erro}</p>`;
                } else if (debug.ok) {
                    debugHtml = `<p class="questoes-empty">Última sincronização com o QConcursos: ${quando}.</p>`;
                }
            } else {
                debugHtml = `<p class="questoes-empty">Nenhuma tentativa de sincronização registrada ainda — abra uma página do QConcursos.com com a extensão ativa.</p>`;
            }

            if (total === 0) {
                const label = QUESTOES_PERIOD_LABELS[currentQuestoesPeriod] || 'no período';
                questoesRender.innerHTML = `
                    <div class="questoes-empty-state">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 8v4l2.5 2.5"/></svg>
                        <p class="questoes-empty">Ainda não detectamos nenhuma questão respondida ${label}. Resolva questões no QConcursos com a extensão ativa para ver suas estatísticas aqui.</p>
                    </div>
                    ${debugHtml}${rodapeHtml}`;
                return;
            }

            const { p, lo, hi } = wilsonInterval(periodo.acertos, total);
            const pct = Math.round(p * 100);
            const pctLo = Math.round(lo * 100);
            const pctHi = Math.round(hi * 100);
            const conf = classificarConfianca(total);
            // Anel do resumo (estilo iOS Fitness): trilho fino, progresso arredondado, cor da faixa.
            const RAIO = 40, circ = 2 * Math.PI * RAIO;
            const offset = circ - (pct / 100) * circ;
            const zona = pct >= 90 ? 4 : pct >= 80 ? 3 : pct >= 60 ? 2 : 1;
            const ZONAS = {
                1: ['Abaixo da zona de estudo', 'menos de 60%', 'Abaixo da meta'],
                2: ['Em desenvolvimento', '60% a 79%', 'Em evolução'],
                3: ['Zona competitiva', '80% a 89%', 'Competitiva'],
                4: ['Zona de aprovação', '90% ou mais', 'Aprovação'],
            };

            questoesRender.innerHTML = `
                <section class="qh qh-z${zona}">
                    <div class="qh-anel">
                        <div class="qh-anel-wrap">
                            <svg viewBox="0 0 100 100" class="qh-svg" aria-hidden="true">
                                <defs>
                                    <linearGradient id="qhGrad" x1="0" y1="0" x2="1" y2="1">
                                        <stop offset="0" stop-color="var(--qh-z-claro)"/>
                                        <stop offset="1" stop-color="var(--qh-z)"/>
                                    </linearGradient>
                                </defs>
                                <circle class="qh-trilho" cx="50" cy="50" r="${RAIO}"/>
                                <circle class="questoes-ring-fg qh-prog" cx="50" cy="50" r="${RAIO}"
                                    stroke-dasharray="${circ}" stroke-dashoffset="${circ}" data-target-offset="${offset}"
                                    transform="rotate(-90 50 50)"/>
                            </svg>
                            <div class="qh-centro">
                                <span class="qh-pct" id="questoes-pct-anim">0%</span>
                                <span class="qh-zona">${ZONAS[zona][2]}</span>
                            </div>
                        </div>
                        <div class="qh-sub">${periodo.acertos} de ${total} corretas</div>
                    </div>
                    <div class="qh-lista">
                        <div class="qh-linha"><span class="qh-ic qh-ic--ok"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg></span><span class="qh-rot">Acertos</span><b id="questoes-val-acertos">0</b></div>
                        <div class="qh-linha"><span class="qh-ic qh-ic--err"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg></span><span class="qh-rot">Erros</span><b id="questoes-val-erros">0</b></div>
                        <div class="qh-linha"><span class="qh-ic qh-ic--tot"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16M4 12h16M4 17h10"/></svg></span><span class="qh-rot">Total resolvidas</span><b id="questoes-val-total">0</b></div>
                    </div>
                </section>

                <section class="qh-faixas qh-z${zona}">
                    <div class="qh-faixas-topo">
                        <span class="qh-faixas-tit">Sua faixa</span>
                        <span class="qh-faixas-nome"><b>${ZONAS[zona][0]}</b> · ${ZONAS[zona][1]}</span>
                    </div>
                    <div class="qh-barra" role="img" aria-label="Taxa de acerto ${pct}%, ${ZONAS[zona][0]}">
                        <i class="z1"></i><i class="z2"></i><i class="z3"></i><i class="z4"></i>
                        <span class="qh-marca" style="left:${pct}%"></span>
                    </div>
                    <div class="qh-eixo"><span style="left:60%">60%</span><span style="left:80%">80%</span><span style="left:90%">90%</span></div>
                    <details class="qh-info">
                        <summary>Entenda as faixas</summary>
                        <p>Quanto maior a taxa de acerto nas questões, menor a chance de errar temas parecidos na prova. Abaixo de 60% costuma ser insuficiente para a maioria dos concursos: o ideal é revisar a matéria antes de avançar.</p>
                    </details>
                </section>

                <div class="conf-card">
                    <div class="conf-topo">
                        <span class="conf-tit">Confiabilidade</span>
                        <span class="conf-pilula conf-pilula--${conf.cor}">${conf.label}</span>
                    </div>
                    <div class="conf-faixa" role="img" aria-label="Acerto real provavelmente entre ${pctLo}% e ${pctHi}%">
                        <span class="conf-trilho"></span>
                        <span class="conf-intervalo" style="left:${pctLo}%; width:${Math.max(1, pctHi - pctLo)}%;"></span>
                        <span class="conf-ponto" style="left:${pct}%;"></span>
                    </div>
                    <p class="conf-texto">Seu acerto real provavelmente está entre <strong>${pctLo}%</strong> e <strong>${pctHi}%</strong>.${total < 30 ? ' Resolva mais questões para estreitar a faixa.' : ''}</p>
                </div>

                <div id="questoes-trend-render"></div>
                ${rodapeHtml}
            `;

            // Animações de entrada: contadores e o anel de progresso.
            animarNumero(document.getElementById('questoes-val-acertos'), periodo.acertos);
            animarNumero(document.getElementById('questoes-val-erros'), periodo.erros);
            animarNumero(document.getElementById('questoes-val-total'), total);
            const pctEl = document.getElementById('questoes-pct-anim');
            if (pctEl && document.documentElement.classList.contains('cb-lite')) {
                pctEl.textContent = `${Math.round(pct)}%`;
            } else if (pctEl) {
                const inicio = performance.now();
                const dur = 900;
                function passoPct(agora) {
                    const t = Math.min(1, (agora - inicio) / dur);
                    const eased = 1 - Math.pow(1 - t, 3);
                    pctEl.textContent = `${Math.round(pct * eased)}%`;
                    if (t < 1) requestAnimationFrame(passoPct);
                }
                requestAnimationFrame(passoPct);
            }
            requestAnimationFrame(() => {
                const ringFg = questoesRender.querySelector('.questoes-ring-fg');
                if (ringFg) ringFg.style.strokeDashoffset = ringFg.dataset.targetOffset;
            });

            renderQuestoesTrendChart(stats, result.questoesDailyHistory || {});
        });
    }

    // Cartão de tendência do desempenho: a estatística e o desenho vivem em tendencia.js
    // (a tendência só é afirmada quando supera a margem de erro; ver o cabeçalho de lá).
    function renderQuestoesTrendChart(stats, dailyHistory) {
        const trendEl = document.getElementById('questoes-trend-render');
        if (!trendEl) return;
        if (!window.CBTendencia) { trendEl.innerHTML = ''; return; }
        window.CBTendencia.render(trendEl, { stats, daily: dailyHistory });
        const expandBtn = document.getElementById('questoes-trend-expand-btn');
        if (expandBtn) expandBtn.addEventListener('click', () => abrirDesempenhoTelaCheia());
    }

    // ===================== DESEMPENHO EM TELA CHEIA =====================
    // Modal com uma visão bem mais rica que o cartão compacto do popup:
    // junta o anel/estatísticas do período, a curva de tendência ampliada,
    // o desempenho por matéria (ordenado por prioridade) e um mini-gráfico
    // de tempo de estudo dos últimos dias — tudo num painel só, pra dar uma
    // visão completa de corpo inteiro do progresso.
    const qfModalOverlay = document.getElementById('qf-modal-overlay');
    const qfModalBody = document.getElementById('qf-modal-body');
    const qfModalClose = document.getElementById('qf-modal-close');

    function fecharDesempenhoTelaCheia() {
        if (!qfModalOverlay) return;
        qfModalOverlay.classList.remove('open');
    }
    if (qfModalClose) qfModalClose.addEventListener('click', fecharDesempenhoTelaCheia);
    if (qfModalOverlay) {
        qfModalOverlay.addEventListener('click', (e) => {
            if (e.target === qfModalOverlay) fecharDesempenhoTelaCheia();
        });
    }
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && qfModalOverlay && qfModalOverlay.classList.contains('open')) {
            fecharDesempenhoTelaCheia();
        }
    });

    function abrirDesempenhoTelaCheia() {
        if (!qfModalOverlay || !qfModalBody) return;
        qfModalOverlay.classList.add('open');
        qfModalBody.innerHTML = `<p class="questoes-empty">Carregando visão completa...</p>`;

        chrome.storage.local.get(
            ['questoesPeriodStats', 'questoesDailyHistory', 'questoesDisciplinas', 'studyHistory', 'hiddenMaterias'],
            (result) => {
                const stats = result.questoesPeriodStats || {};
                const periodo = stats[currentQuestoesPeriod] || { acertos: 0, erros: 0, total: 0 };
                const total = periodo.total || (periodo.acertos + periodo.erros);
                const pct = total > 0 ? Math.round((periodo.acertos / total) * 100) : 0;

                // ----- Cabeçalho com o resumo do período atual -----
                const labelPeriodo = QUESTOES_PERIOD_LABELS[currentQuestoesPeriod] || '';
                let corResumo = 'var(--danger)';
                if (pct >= 90) corResumo = '#3b82f6';
                else if (pct >= 80) corResumo = 'var(--accent)';
                else if (pct >= 60) corResumo = 'var(--warning)';

                const resumoHtml = total > 0 ? `
                    <div class="qf-summary-row">
                        <div class="qf-summary-card">
                            <span class="qf-summary-pct" style="color:${corResumo}">${pct}%</span>
                            <span class="qf-summary-lbl">Acerto ${labelPeriodo}</span>
                        </div>
                        <div class="qf-summary-card">
                            <span class="qf-summary-pct">${periodo.acertos}</span>
                            <span class="qf-summary-lbl">Acertos</span>
                        </div>
                        <div class="qf-summary-card">
                            <span class="qf-summary-pct">${periodo.erros}</span>
                            <span class="qf-summary-lbl">Erros</span>
                        </div>
                        <div class="qf-summary-card">
                            <span class="qf-summary-pct">${total}</span>
                            <span class="qf-summary-lbl">Total resolvidas</span>
                        </div>
                    </div>` : `<p class="questoes-empty">Ainda não há questões resolvidas ${labelPeriodo} para resumir.</p>`;

                // ----- Desempenho por matéria (respeita matérias excluídas pelo usuário) -----
                const dadosDisciplinas = result.questoesDisciplinas;
                const hiddenMateriasModal = result.hiddenMaterias || [];
                let materiasHtml = `<p class="questoes-empty">Ainda não sincronizamos suas disciplinas. Abra "Estatísticas &gt; Disciplinas" no QConcursos.com para ver o desempenho por matéria aqui.</p>`;
                if (dadosDisciplinas && Array.isArray(dadosDisciplinas.itens) && dadosDisciplinas.itens.length > 0) {
                    const itensVisiveis = dadosDisciplinas.itens.filter(item => !hiddenMateriasModal.includes(item.nome));
                    const itensOrdenados = [...itensVisiveis].sort((a, b) => {
                        const pctA = a.total > 0 ? a.certas / a.total : 0;
                        const pctB = b.total > 0 ? b.certas / b.total : 0;
                        return pctA - pctB;
                    });
                    materiasHtml = itensOrdenados.map(item => {
                        const pctItem = item.total > 0 ? Math.round((item.certas / item.total) * 100) : 0;
                        let cor = 'var(--danger)';
                        if (pctItem >= 90) cor = '#3b82f6';
                        else if (pctItem >= 80) cor = 'var(--accent)';
                        else if (pctItem >= 60) cor = 'var(--warning)';
                        return `
                            <div class="materia-row">
                                <div class="materia-row-top">
                                    <span class="materia-nome">${item.nome}</span>
                                    <span class="materia-pct" style="color:${cor}">${pctItem}%</span>
                                </div>
                                <div class="materia-bar-track">
                                    <div class="materia-bar-fill" style="width:${pctItem}%; background:${cor};"></div>
                                </div>
                                <div class="materia-row-bottom">
                                    <span><span class="dot" style="background:var(--accent)"></span>${item.certas} certas</span>
                                    <span><span class="dot" style="background:var(--danger)"></span>${item.erradas} erradas</span>
                                    <span class="materia-total">${item.total} questões</span>
                                </div>
                            </div>`;
                    }).join('');
                }

                // ----- Tempo de estudo, últimos 14 dias -----
                const study = result.studyHistory || {};
                const dias = [];
                for (let i = 13; i >= 0; i--) {
                    const d = new Date();
                    d.setDate(d.getDate() - i);
                    const key = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
                    dias.push({ key, label: String(d.getDate()).padStart(2, '0') + '/' + String(d.getMonth() + 1).padStart(2, '0'), ms: study[key] || 0 });
                }
                const maiorMs = Math.max(1, ...dias.map(d => d.ms));
                const barrasHtml = dias.map(d => {
                    const alturaPct = Math.max(3, Math.round((d.ms / maiorMs) * 100));
                    const horas = (d.ms / 3600000);
                    const label = horas >= 0.05 ? `${horas.toFixed(1)}h` : '';
                    return `
                        <div class="qf-daybar-col" title="${d.label}: ${horas.toFixed(1)}h de estudo">
                            <span class="qf-daybar-val">${label}</span>
                            <div class="qf-daybar-track"><div class="qf-daybar-fill" style="height:${alturaPct}%;"></div></div>
                            <span class="qf-daybar-lbl">${d.label}</span>
                        </div>`;
                }).join('');

                qfModalBody.innerHTML = `
                    ${resumoHtml}
                    <h4 class="section-title qf-section-title">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>
                        Tendência de desempenho
                    </h4>
                    <div class="qf-card qf-card--tendencia"><div id="qf-trend-slot"></div></div>

                    <h4 class="section-title qf-section-title">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z"/></svg>
                        Desempenho por matéria
                    </h4>
                    <div class="qf-card qf-materias">${materiasHtml}</div>

                    <h4 class="section-title qf-section-title">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>
                        Tempo de estudo — últimos 14 dias
                    </h4>
                    <div class="qf-card qf-daybars">${barrasHtml}</div>
                `;
                const slotTendencia = document.getElementById('qf-trend-slot');
                if (slotTendencia && window.CBTendencia) {
                    window.CBTendencia.render(slotTendencia, { stats, daily: result.questoesDailyHistory || {} }, { grande: true, semExpandir: true });
                }
            }
        );
    }

    // Desempenho por matéria/disciplina — vem do scraping da página de
    // estatísticas por disciplina do próprio QC (content.js). Mostra as
    // matérias ordenadas da pior taxa de acerto pra melhor, pra destacar
    // onde vale mais a pena focar o estudo primeiro.
    const questoesMateriasRender = document.getElementById('questoes-materias-render');
    const questoesAssuntosRender = document.getElementById('questoes-assuntos-render');
    const questoesMateriasExcluidas = document.getElementById('questoes-materias-excluidas');

    function excluirMateria(nome) {
        chrome.storage.local.get(['hiddenMaterias'], (result) => {
            const hidden = result.hiddenMaterias || [];
            if (!hidden.includes(nome)) hidden.push(nome);
            chrome.storage.local.set({ hiddenMaterias: hidden }, () => renderQuestoesMaterias());
        });
    }

    function restaurarMateria(nome) {
        chrome.storage.local.get(['hiddenMaterias'], (result) => {
            const hidden = (result.hiddenMaterias || []).filter(n => n !== nome);
            chrome.storage.local.set({ hiddenMaterias: hidden }, () => renderQuestoesMaterias());
        });
    }

    // ===================== PRIORIDADE DO DIA, STREAK E CRONOGRAMA x QUESTÕES =====================
    const questoesPrioridadeRender = document.getElementById('questoes-prioridade-render');

    function renderQuestoesPrioridade() {
        if (!questoesPrioridadeRender) return;
        chrome.storage.local.get(
            ['questoesPrioridade', 'assuntosPrioridade', 'questoesStreak', 'cronogramaCrossCheck'],
            (result) => {
                const prioridade = result.questoesPrioridade;
                const assuntosPrioridade = result.assuntosPrioridade;
                const streak = result.questoesStreak;
                const cross = result.cronogramaCrossCheck;
                const hojeStr = (() => {
                    const d = new Date();
                    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
                })();

                let html = '';

                // --- Matéria sugerida do dia (score de prioridade) ---
                if (prioridade && Array.isArray(prioridade.itens) && prioridade.itens.length > 0) {
                    const top = prioridade.itens[0];
                    const diasTxt = top.diasSemEstudar >= 999
                        ? 'sem registro recente'
                        : top.diasSemEstudar <= 0 ? 'hoje' : `há ${top.diasSemEstudar} dia${top.diasSemEstudar > 1 ? 's' : ''}`;

                    // --- Assunto mais urgente dentro dessa matéria (mesmo
                    // score, só que por assunto) — cai pro top geral de
                    // assuntos se nenhum bater exatamente com a matéria
                    // sugerida, pra sempre mostrar algo acionável.
                    let assuntoHtml = '';
                    if (assuntosPrioridade && Array.isArray(assuntosPrioridade.itens) && assuntosPrioridade.itens.length > 0) {
                        const topAssunto = assuntosPrioridade.itens.find(a => a.materia === top.nome) || assuntosPrioridade.itens[0];
                        if (topAssunto) {
                            assuntoHtml = `
                            <div class="questoes-prioridade-assunto">
                                <span>Foque em:</span> <strong>${topAssunto.nome}</strong>
                                <span>(${topAssunto.pctAcerto}% de acerto${topAssunto.total < 5 ? ', poucas questões ainda' : ''})</span>
                            </div>`;
                        }
                    }

                    html += `
                        <div class="questoes-prioridade-card">
                            <div class="questoes-prioridade-head">
                                <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v20M2 12h20"/></svg>
                                <span>Matéria sugerida para hoje</span>
                            </div>
                            <div class="questoes-prioridade-nome">${top.nome}</div>
                            <div class="questoes-prioridade-meta">
                                <span>${top.pctAcerto}% de acerto</span>
                                <span>·</span>
                                <span>praticada pela última vez ${diasTxt}</span>
                            </div>${assuntoHtml}
                        </div>`;
                }

                // --- Streak de consistência ---
                if (streak && streak.dias > 0) {
                    const aindaValidoHoje = streak.ultimaData === hojeStr;
                    html += `
                        <div class="questoes-streak-card">
                            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="#f59e0b" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/></svg>
                            <span><strong>${streak.dias}</strong> dia${streak.dias > 1 ? 's' : ''} seguidos resolvendo questões${aindaValidoHoje ? '' : ' — continue hoje para manter!'}</span>
                        </div>`;
                }

                // --- Cronograma x Questões (fechamento do ciclo planejamento→execução) ---
                if (cross && cross.data === hojeStr && Array.isArray(cross.faltando)) {
                    if (cross.faltando.length > 0 && cross.planoHoje.length > 0) {
                        html += `
                            <div class="questoes-cross-card questoes-cross-card--warn">
                                <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 9v4m0 4h.01M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0Z"/></svg>
                                <span>Hoje era ${cross.faltando.join(' e ')} no cronograma, mas você ainda não resolveu questões d${cross.faltando.length > 1 ? 'essas matérias' : 'ela'}.</span>
                            </div>`;
                    } else if (cross.planoHoje.length > 0) {
                        html += `
                            <div class="questoes-cross-card questoes-cross-card--ok">
                                <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
                                <span>Você já resolveu questões de tudo que estava no cronograma de hoje. Mandou bem!</span>
                            </div>`;
                    }
                }

                questoesPrioridadeRender.innerHTML = html;
            }
        );
    }

    // ===================== TENDÊNCIA POR MATÉRIA (evolução + semana x semana) =====================
    // Usa o disciplinaHistory (snapshot diário cumulativo por disciplina) pra
    // reconstruir: 1) uma mini-linha de evolução da % de acerto ao longo do
    // tempo, e 2) quantas questões/​% de acerto essa semana vs a semana passada,
    // atribuindo a cada dia só o que foi resolvido DE NOVO naquele dia (delta
    // entre snapshots consecutivos), nunca o total acumulado.
    function calcularTendenciaMateria(nome, disciplinaHistory) {
        const datas = Object.keys(disciplinaHistory || {}).sort();
        const pontos = [];
        const deltas = [];
        let anterior = null;

        datas.forEach(data => {
            const snap = (disciplinaHistory[data] || []).find(s => s.nome === nome);
            if (!snap) return;
            pontos.push({ date: data, pct: snap.total > 0 ? (snap.certas / snap.total) * 100 : 0, total: snap.total });
            if (anterior) {
                deltas.push({
                    date: data,
                    deltaCertas: snap.certas - anterior.certas,
                    deltaTotal: snap.total - anterior.total
                });
            }
            anterior = snap;
        });

        const sparkline = pontos.filter(p => p.total > 0).slice(-14);

        const hoje = new Date();
        hoje.setHours(0, 0, 0, 0);
        function somaJanela(deOffset, ateOffset) {
            let certas = 0, total = 0;
            deltas.forEach(d => {
                if (d.deltaTotal <= 0) return; // ignora dias sem prática nova (ou ruído negativo)
                const dt = new Date(d.date + 'T00:00:00');
                const diff = Math.round((hoje - dt) / 86400000);
                if (diff >= deOffset && diff <= ateOffset) {
                    certas += d.deltaCertas;
                    total += d.deltaTotal;
                }
            });
            return { certas, total, pct: total > 0 ? Math.round((certas / total) * 100) : null };
        }

        return {
            sparkline,
            semanaAtual: somaJanela(0, 6),
            semanaPassada: somaJanela(7, 13)
        };
    }

    function montarSparklineSvg(sparkline) {
        if (!sparkline || sparkline.length < 2) return '';
        const w = 84, h = 30, pad = 4;
        const valores = sparkline.map(p => p.pct);
        const min = Math.min(...valores), max = Math.max(...valores);
        const range = (max - min) || 1;
        const stepX = (w - 2 * pad) / (sparkline.length - 1);
        const pontos = sparkline.map((p, i) => {
            const x = pad + i * stepX;
            const y = h - pad - ((p.pct - min) / range) * (h - 2 * pad);
            return `${x.toFixed(1)},${y.toFixed(1)}`;
        }).join(' ');
        const subiu = valores[valores.length - 1] >= valores[0];
        const cor = subiu ? 'var(--accent)' : 'var(--danger)';
        const fim = pontos.split(' ').pop().split(',');
        return `<svg viewBox="0 0 ${w} ${h}" width="${w}" height="${h}" class="materia-spark" role="img" aria-label="Evolução da % de acerto ao longo do tempo"><polyline points="${pontos}" fill="none" stroke="${cor}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><circle cx="${fim[0]}" cy="${fim[1]}" r="2.8" fill="${cor}"/></svg>`;
    }

    function montarTextoTendenciaSemanal(tendencia) {
        const { semanaAtual, semanaPassada } = tendencia;
        if (semanaAtual.total === 0 && semanaPassada.total === 0) return '';

        // Chip com a diferença em pontos percentuais, só quando as duas semanas têm questões para comparar.
        let chip = '';
        if (semanaAtual.total > 0 && semanaPassada.total > 0 && semanaAtual.pct !== null && semanaPassada.pct !== null) {
            const d = semanaAtual.pct - semanaPassada.pct;
            if (d > 0) chip = `<span class="mat-delta mat-delta--up">▲ ${d} pp</span>`;
            else if (d < 0) chip = `<span class="mat-delta mat-delta--down">▼ ${-d} pp</span>`;
            else chip = '<span class="mat-delta">= igual</span>';
        }
        const lado = (j) => (j.total > 0 ? `${j.pct}% em ${cbPlural(j.total, 'questão', 'questões')}` : 'sem questões');
        return `<div class="materia-trend-text">${chip}<span class="mat-linha">Esta semana: <strong>${lado(semanaAtual)}</strong></span><span class="mat-linha mat-linha--dim">Semana passada: ${lado(semanaPassada)}</span></div>`;
    }

    // ===================== SWIPE PARA EXCLUIR (arrastar p/ esquerda) =====================
    // Gesto tipo "app de e-mail": arrasta o cartão para a esquerda para revelar
    // a lixeira atrás e soltar exclui. Funciona com touch (celular) e com o
    // mouse (arrastar clicando e segurando), então cobre tanto o popup quanto
    // o dashboard ampliado.
    const CB_SWIPE_MAX = 76;       // quanto o cartão desliza no máximo (px)
    const CB_SWIPE_THRESHOLD = 46; // a partir daqui, soltar = exclui

    function ativarSwipeParaExcluir(row, onConfirmarExclusao) {
        const content = row.querySelector('.materia-row-content');
        const trash = row.querySelector('.materia-row-trash');
        if (!content) return;

        let startX = 0, startY = 0, currentX = 0, dragging = false, lockedHorizontal = null, pointerId = null;

        function setX(x, animar) {
            currentX = Math.max(-CB_SWIPE_MAX, Math.min(0, x));
            content.style.transition = animar ? 'transform 0.2s cubic-bezier(.22,1,.36,1)' : 'none';
            content.style.transform = `translateX(${currentX}px)`;
            if (trash) trash.classList.toggle('materia-row-trash--armed', currentX <= -CB_SWIPE_THRESHOLD);
        }

        function onPointerDown(e) {
            if (e.button !== undefined && e.button !== 0) return; // só botão principal do mouse
            dragging = true;
            lockedHorizontal = null;
            startX = e.clientX;
            startY = e.clientY;
            pointerId = e.pointerId;
            content.style.transition = 'none';
        }

        function onPointerMove(e) {
            if (!dragging) return;
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;

            if (lockedHorizontal === null) {
                if (Math.abs(dx) < 6 && Math.abs(dy) < 6) return; // ainda não deu pra saber a direção
                lockedHorizontal = Math.abs(dx) > Math.abs(dy);
                if (lockedHorizontal && content.setPointerCapture && pointerId !== null) {
                    try { content.setPointerCapture(pointerId); } catch (err) {}
                }
            }
            if (!lockedHorizontal) return; // é rolagem vertical, deixa passar

            e.preventDefault();
            setX(dx < 0 ? dx : dx * 0.15, false); // resistência levinha ao arrastar pra direita
        }

        function finalizarArraste() {
            if (!dragging) return;
            dragging = false;
            if (lockedHorizontal && currentX <= -CB_SWIPE_THRESHOLD) {
                // Confirma a exclusão: desliza pra fora e some antes de tirar do storage
                content.style.transition = 'transform 0.18s ease-in, opacity 0.18s ease-in';
                content.style.transform = 'translateX(-100%)';
                content.style.opacity = '0';
                row.style.transition = 'max-height 0.2s ease 0.1s, margin 0.2s ease 0.1s';
                setTimeout(() => onConfirmarExclusao(), 180);
            } else {
                setX(0, true);
            }
            lockedHorizontal = null;
        }

        content.addEventListener('pointerdown', onPointerDown);
        content.addEventListener('pointermove', onPointerMove);
        content.addEventListener('pointerup', finalizarArraste);
        content.addEventListener('pointercancel', finalizarArraste);
        content.addEventListener('pointerleave', (e) => {
            // só cancela se o botão já não estiver mais pressionado (evita
            // interromper o arraste ao passar sobre elementos filhos)
            if (dragging && e.buttons === 0) finalizarArraste();
        });

        // Clique direto na lixeira (sem precisar arrastar) também exclui —
        // útil pra quem prefere clicar em vez de arrastar.
        trash?.addEventListener('click', () => onConfirmarExclusao());
    }

    // ===================== GRÁFICO DE TUBOS — DESEMPENHO POR MATÉRIA =====================
    const questoesMateriasChartEl = document.getElementById('questoes-materias-chart');
    const materiasChartModalOverlay = document.getElementById('materias-chart-modal-overlay');
    const materiasChartModalBody = document.getElementById('materias-chart-modal-body');
    const materiasChartModalClose = document.getElementById('materias-chart-modal-close');
    const materiasChartExpandBtn = document.getElementById('materias-chart-expand-btn');
    let ultimosItensMateriasOrdenados = [];

    function corPorPercentual(pct) {
        if (pct >= 90) return '#3b82f6';
        if (pct >= 80) return 'var(--accent)';
        if (pct >= 60) return 'var(--warning)';
        return 'var(--danger)';
    }

    // Degradê de cada tubo, por faixa de acerto (mesmos cortes de corPorPercentual): [topo, base].
    // Tons de luminosidade média, sem nenhuma parada quase-branca: se um navegador reescrever as cores à
    // força (modo escuro forçado), um amarelo-claro virava marrom; um tom médio sobrevive ao filtro.
    function tonsDoTubo(pct) {
        if (pct >= 90) return ['#2f7bff', '#6aa9ff'];
        if (pct >= 80) return ['var(--accent)', 'color-mix(in srgb, var(--accent) 60%, #ffffff)'];
        if (pct >= 60) return ['#ff9f1c', '#ffc233'];
        return ['#ff4d6d', '#ffb457'];
    }

    const cbPlural = (n, um, varios) => `${n} ${n === 1 ? um : varios}`;
    const escHtmlMateria = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

    // Cada matéria é um tubo translúcido (a "sombra" mostra o 100%) com o preenchimento até o acerto.
    function montarBarrasChartHtml(itens, modal) {
        if (!itens || itens.length === 0) return '';
        const altura = modal ? 240 : 140;
        return itens.map(item => {
            const pct = item.total > 0 ? Math.round((item.certas / item.total) * 100) : 0;
            const cor = corPorPercentual(pct);
            const [topo, base] = tonsDoTubo(pct);
            const nome = escHtmlMateria(item.nome);
            const enche = pct > 0 ? `<i class="mvb-enche" style="height:${pct}%; --mvb-topo:${topo}; --mvb-base:${base};"></i>` : '';
            return `
                <div class="mvb-col">
                    <span class="mvb-pct" style="color:${cor}">${pct}%</span>
                    <div class="mvb-tubo" style="height:${altura}px" role="img" aria-label="${nome}: ${pct}% de acerto" data-tooltip="${nome}: ${item.certas}/${item.total} questões">${enche}</div>
                    <span class="mvb-name" title="${nome}">${nome}</span>
                </div>`;
        }).join('');
    }

    function renderQuestoesMateriasChart(itensOrdenados) {
        ultimosItensMateriasOrdenados = itensOrdenados || [];
        if (!questoesMateriasChartEl) return;
        if (!itensOrdenados || itensOrdenados.length === 0) {
            questoesMateriasChartEl.innerHTML = '';
            return;
        }
        questoesMateriasChartEl.innerHTML = montarBarrasChartHtml(itensOrdenados, false);
    }

    function abrirMateriasChartTelaCheia() {
        if (!materiasChartModalOverlay || !materiasChartModalBody) return;
        materiasChartModalOverlay.classList.add('open');
        if (ultimosItensMateriasOrdenados.length === 0) {
            materiasChartModalBody.innerHTML = `<p class="questoes-empty">Ainda não há matérias sincronizadas para mostrar aqui.</p>`;
            return;
        }
        materiasChartModalBody.innerHTML = `<div class="materias-vbar-chart mvb-modal">${montarBarrasChartHtml(ultimosItensMateriasOrdenados, true)}</div>`;
    }
    if (materiasChartExpandBtn) materiasChartExpandBtn.addEventListener('click', abrirMateriasChartTelaCheia);
    if (materiasChartModalClose) materiasChartModalClose.addEventListener('click', () => materiasChartModalOverlay.classList.remove('open'));
    if (materiasChartModalOverlay) {
        materiasChartModalOverlay.addEventListener('click', (e) => {
            if (e.target === materiasChartModalOverlay) materiasChartModalOverlay.classList.remove('open');
        });
    }
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && materiasChartModalOverlay && materiasChartModalOverlay.classList.contains('open')) {
            materiasChartModalOverlay.classList.remove('open');
        }
    });

    function renderQuestoesMaterias() {
        if (!questoesMateriasRender) return;
        chrome.storage.local.get(['questoesDisciplinas', 'qcSyncDebugDisciplinas', 'hiddenMaterias', 'disciplinaHistory'], (result) => {
            const dados = result.questoesDisciplinas;
            const debug = result.qcSyncDebugDisciplinas;
            const hidden = result.hiddenMaterias || [];
            const disciplinaHistory = result.disciplinaHistory || {};

            let debugHtml = '';
            if (debug && debug.atualizadoEm) {
                const minutosAtras = Math.round((Date.now() - debug.atualizadoEm) / 60000);
                const quando = minutosAtras <= 0 ? 'agora mesmo' : `há ${minutosAtras} min`;
                if (debug.erro) {
                    debugHtml = `<p class="questoes-empty questoes-empty--err">Última tentativa de sincronizar as disciplinas (${quando}) falhou: ${debug.erro}</p>`;
                }
            }

            if (!dados || !Array.isArray(dados.itens) || dados.itens.length === 0) {
                questoesMateriasRender.innerHTML = `<p class="questoes-empty">Ainda não sincronizamos suas disciplinas. Abra a página "Estatísticas &gt; Disciplinas" no QConcursos.com com a extensão ativa para ver o desempenho por matéria aqui.</p>${debugHtml}`;
                if (questoesMateriasExcluidas) questoesMateriasExcluidas.innerHTML = '';
                renderQuestoesMateriasChart([]);
                return;
            }

            const todosItens = dados.itens;
            const itensVisiveis = todosItens.filter(item => !hidden.includes(item.nome));
            const itensExcluidos = todosItens.filter(item => hidden.includes(item.nome));

            const itensOrdenados = [...itensVisiveis].sort((a, b) => {
                const pctA = a.total > 0 ? a.certas / a.total : 0;
                const pctB = b.total > 0 ? b.certas / b.total : 0;
                return pctA - pctB; // pior desempenho primeiro — é o que mais precisa de atenção
            });

            renderQuestoesMateriasChart(itensOrdenados);

            const linhas = itensOrdenados.map(item => {
                const pct = item.total > 0 ? Math.round((item.certas / item.total) * 100) : 0;
                let cor = 'var(--danger)';
                if (pct >= 90) cor = '#3b82f6';
                else if (pct >= 80) cor = 'var(--accent)';
                else if (pct >= 60) cor = 'var(--warning)';

                const tendencia = calcularTendenciaMateria(item.nome, disciplinaHistory);
                const sparklineHtml = montarSparklineSvg(tendencia.sparkline);
                const tendenciaTextoHtml = montarTextoTendenciaSemanal(tendencia);
                const semHistoricoSuficiente = tendencia.sparkline.length < 2;

                return `
                    <div class="materia-row" data-nome="${item.nome.replace(/"/g, '&quot;')}">
                        <div class="materia-row-trash">
                            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0-1 14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2L4 6"/><path d="M10 11v6M14 11v6"/></svg>
                            <span>Excluir</span>
                        </div>
                        <div class="materia-row-content">
                            <div class="materia-row-top">
                                <span class="materia-nome" title="${escHtmlMateria(item.nome)}">${escHtmlMateria(item.nome)}</span>
                                <span class="materia-pct" style="color:${cor}">${pct}<small>%</small></span>
                            </div>
                            <div class="materia-bar-track">${pct > 0 ? `<div class="materia-bar-fill" style="width:${Math.max(pct, 4)}%; --mvb-topo:${tonsDoTubo(pct)[0]}; --mvb-base:${tonsDoTubo(pct)[1]};"></div>` : ''}</div>
                            <div class="materia-row-bottom">
                                <span><span class="dot dot--certa"></span>${cbPlural(item.certas, 'certa', 'certas')}</span>
                                <span><span class="dot dot--errada"></span>${cbPlural(item.erradas, 'errada', 'erradas')}</span>
                                <span class="materia-total">${cbPlural(item.total, 'questão', 'questões')}</span>
                            </div>
                            ${(sparklineHtml || tendenciaTextoHtml) ? `
                            <div class="materia-trend-row">
                                ${sparklineHtml}
                                ${tendenciaTextoHtml}
                            </div>` : (semHistoricoSuficiente ? `
                            <div class="materia-trend-row materia-trend-row--pending">
                                <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
                                <span class="materia-trend-text">A evolução e a comparação semanal aparecem a partir do 2º dia de sincronização.</span>
                            </div>` : '')}
                        </div>
                    </div>`;
            }).join('');

            if (itensVisiveis.length === 0 && itensExcluidos.length > 0) {
                questoesMateriasRender.innerHTML = `<p class="questoes-empty">Todas as matérias sincronizadas estão excluídas da lista no momento. Restaure alguma abaixo para vê-la aqui.</p>${debugHtml}`;
            } else {
                const quando = dados.atualizadoEm ? Math.round((Date.now() - dados.atualizadoEm) / 60000) : null;
                const rodape = quando !== null
                    ? `<p class="questoes-empty">Sincronizado ${quando <= 0 ? 'agora mesmo' : `há ${quando} min`} • período conforme o último filtro usado na página de disciplinas do QC.</p>`
                    : '';
                questoesMateriasRender.innerHTML = linhas + rodape + debugHtml;
            }

            questoesMateriasRender.querySelectorAll('.materia-row').forEach(row => {
                ativarSwipeParaExcluir(row, () => excluirMateria(row.dataset.nome));
            });

            if (questoesMateriasExcluidas) {
                if (itensExcluidos.length === 0) {
                    questoesMateriasExcluidas.innerHTML = '';
                } else {
                    questoesMateriasExcluidas.innerHTML = `
                        <button class="materias-excluidas-toggle" id="btn-toggle-materias-excluidas">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
                            Matérias excluídas (${itensExcluidos.length})
                            <svg class="chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
                        </button>
                        <div class="materias-excluidas-body" id="materias-excluidas-body">
                            ${itensExcluidos.map(item => `
                                <div class="materia-excluida-row">
                                    <span class="materia-excluida-nome">${item.nome}</span>
                                    <button class="materia-restore-btn" data-nome="${item.nome.replace(/"/g, '&quot;')}">Restaurar</button>
                                </div>
                            `).join('')}
                        </div>`;

                    const toggleBtn = document.getElementById('btn-toggle-materias-excluidas');
                    const toggleBody = document.getElementById('materias-excluidas-body');
                    toggleBtn?.addEventListener('click', () => {
                        toggleBtn.classList.toggle('open');
                        toggleBody.classList.toggle('open');
                    });

                    questoesMateriasExcluidas.querySelectorAll('.materia-restore-btn').forEach(btn => {
                        btn.addEventListener('click', () => restaurarMateria(btn.dataset.nome));
                    });
                }
            }
        });
    }

    const assuntoToggleAllBtn = document.getElementById('assunto-toggle-all-btn');
    const assuntoToggleAllLabel = document.getElementById('assunto-toggle-all-label');

    // Seção "Assuntos: mais e menos acertos" (destaques-assuntos.js): os mesmos dados dos assuntos,
    // separados entre os que a pessoa mais e menos acerta.
    const questoesDestaquesRender = document.getElementById('questoes-destaques-render');
    function renderQuestoesDestaques() {
        if (!questoesDestaquesRender || !window.CBDestaques) return;
        chrome.storage.local.get(['questoesAssuntos'], (result) => {
            window.CBDestaques.render(questoesDestaquesRender, result.questoesAssuntos && result.questoesAssuntos.materias);
        });
    }

    function renderQuestoesAssuntos() {
        if (!questoesAssuntosRender) return;
        chrome.storage.local.get(['questoesAssuntos', 'qcSyncDebugAssuntos', 'cbAssuntoGruposColapsados'], (result) => {
            const dados = result.questoesAssuntos;
            const debug = result.qcSyncDebugAssuntos;
            const colapsados = result.cbAssuntoGruposColapsados || {};

            let debugHtml = '';
            if (debug && debug.atualizadoEm && debug.erro) {
                const minutosAtras = Math.round((Date.now() - debug.atualizadoEm) / 60000);
                const quando = minutosAtras <= 0 ? 'agora mesmo' : `há ${minutosAtras} min`;
                debugHtml = `<p class="questoes-empty questoes-empty--err">Última tentativa de sincronizar os assuntos (${quando}) falhou: ${debug.erro}</p>`;
            }

            if (!dados || !Array.isArray(dados.materias) || dados.materias.length === 0) {
                questoesAssuntosRender.innerHTML = `<p class="questoes-empty">Ainda não sincronizamos seus assuntos. Abra a página "Estatísticas &gt; Assuntos" no QConcursos.com com a extensão ativa para ver aqui, agrupado por matéria e priorizando o que você mais erra.</p>${debugHtml}`;
                if (assuntoToggleAllBtn) assuntoToggleAllBtn.style.display = 'none';
                return;
            }
            if (assuntoToggleAllBtn) assuntoToggleAllBtn.style.display = '';

            // Datalist de sugestões: matérias já conhecidas pelo dicionário +
            // as que já aparecem nos dados do usuário (cobre casos de matéria
            // "customizada" que a pessoa já cadastrou antes).
            const datalist = document.getElementById('cb-materias-datalist');
            if (datalist) {
                const conhecidas = new Set(
                    (window.CBDicionarioMaterias ? window.CBDicionarioMaterias.listarMateriasConhecidas() : [])
                );
                dados.materias.forEach(g => { if (g.materia !== 'Não classificado') conhecidas.add(g.materia); });
                datalist.innerHTML = Array.from(conhecidas).sort()
                    .map(m => `<option value="${m.replace(/"/g, '&quot;')}"></option>`).join('');
            }

            const corPorPct = (pct) => {
                if (pct >= 90) return '#3b82f6';
                if (pct >= 80) return 'var(--accent)';
                if (pct >= 60) return 'var(--warning)';
                return 'var(--danger)';
            };

            const gruposHtml = dados.materias.map(grupo => {
                const naoClassificado = grupo.materia === 'Não classificado';
                const totalCertas = grupo.itens.reduce((s, i) => s + i.certas, 0);
                const totalErradas = grupo.itens.reduce((s, i) => s + i.erradas, 0);

                const linhasHtml = grupo.itens.map(item => {
                    const pct = item.total > 0 ? Math.round((item.certas / item.total) * 100) : 0;
                    const cor = corPorPct(pct);
                    const nomeEscapado = item.nome.replace(/"/g, '&quot;');
                    return `
                        <div class="assunto-row" data-nome="${nomeEscapado}">
                            <div class="assunto-row-top">
                                <span class="assunto-nome" title="${nomeEscapado}">${escHtmlMateria(item.nome)}</span>
                                <div class="assunto-row-top-right">
                                    <span class="assunto-pct" style="color:${cor}">${pct}%</span>
                                    <button type="button" class="assunto-editar-btn" title="Corrigir matéria deste assunto">
                                        <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>
                                    </button>
                                </div>
                            </div>
                            <div class="assunto-bar-track">${pct > 0 ? `<div class="assunto-bar-fill" style="width:${Math.max(pct, 4)}%; --mvb-topo:${tonsDoTubo(pct)[0]}; --mvb-base:${tonsDoTubo(pct)[1]};"></div>` : ''}</div>
                            <div class="assunto-row-bottom">
                                <span>${cbPlural(item.certas, 'certa', 'certas')}</span>
                                <span>${cbPlural(item.erradas, 'errada', 'erradas')}</span>
                                <span class="assunto-total">${cbPlural(item.total, 'questão', 'questões')}</span>
                            </div>
                            <div class="assunto-editar-form" style="display:none;">
                                <input type="text" class="assunto-editar-input" list="cb-materias-datalist" placeholder="Digite a matéria certa (ex: Contabilidade)" value="${naoClassificado ? '' : grupo.materia.replace(/"/g, '&quot;')}">
                                <button type="button" class="assunto-editar-salvar">Salvar</button>
                            </div>
                        </div>`;
                }).join('');

                const materiaEscapada = grupo.materia.replace(/"/g, '&quot;');
                const grupoColapsado = !!colapsados[grupo.materia];
                return `
                    <div class="assunto-grupo-materia${grupoColapsado ? ' is-collapsed' : ''}" data-materia="${materiaEscapada}">
                        <div class="assunto-grupo-head">
                            <div class="assunto-grupo-head-left">
                                <span class="assunto-grupo-nome${naoClassificado ? ' assunto-grupo-nome--nc' : ''}">${escHtmlMateria(grupo.materia)}${naoClassificado ? ' — revisar manualmente' : ''}</span>
                                <span class="assunto-grupo-resumo">${cbPlural(totalCertas, 'certa', 'certas')} · ${cbPlural(totalErradas, 'errada', 'erradas')}</span>
                            </div>
                            <button type="button" class="assunto-grupo-eye-btn" title="Minimizar/expandir esta matéria">
                                <svg class="cb-eye-on" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                                <svg class="cb-eye-off" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a20.3 20.3 0 0 1 5.06-5.94M9.9 4.24A10.94 10.94 0 0 1 12 4c7 0 11 8 11 8a20.3 20.3 0 0 1-2.87 4.02M14.12 14.12a3 3 0 1 1-4.24-4.24"/><path d="M1 1l22 22"/></svg>
                            </button>
                        </div>
                        <div class="assunto-lista">${linhasHtml}</div>
                    </div>`;
            }).join('');

            const quando = dados.atualizadoEm ? Math.round((Date.now() - dados.atualizadoEm) / 60000) : null;
            const rodape = quando !== null
                ? `<p class="questoes-empty">Sincronizado ${quando <= 0 ? 'agora mesmo' : `há ${quando} min`} • dentro de cada matéria, os assuntos que você mais erra aparecem primeiro. "Não classificado" é o que o dicionário local não conseguiu associar com segurança — clique no lápis pra corrigir, a extensão lembra pra sempre.</p>`
                : '';

            questoesAssuntosRender.innerHTML = gruposHtml + rodape + debugHtml;

            // Liga o botão de lápis a cada linha: abre/fecha o mini-form inline.
            questoesAssuntosRender.querySelectorAll('.assunto-editar-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const row = btn.closest('.assunto-row');
                    const form = row.querySelector('.assunto-editar-form');
                    const aberto = form.style.display !== 'none';
                    questoesAssuntosRender.querySelectorAll('.assunto-editar-form').forEach(f => f.style.display = 'none');
                    if (!aberto) {
                        form.style.display = 'flex';
                        form.querySelector('.assunto-editar-input').focus();
                    }
                });
            });

            // Salva a correção: manda pro background classificar tudo de
            // novo com essa matéria fixada pra esse assunto — o resultado
            // volta sozinho via chrome.storage.onChanged (ver listener mais
            // abaixo no arquivo), então não precisamos re-renderizar aqui.
            questoesAssuntosRender.querySelectorAll('.assunto-editar-salvar').forEach(btn => {
                btn.addEventListener('click', () => {
                    const row = btn.closest('.assunto-row');
                    const input = row.querySelector('.assunto-editar-input');
                    const materia = (input.value || '').trim();
                    if (!materia) { input.focus(); return; }
                    chrome.runtime.sendMessage({
                        action: 'salvar_override_assunto',
                        nome: row.dataset.nome,
                        materia
                    });
                    row.querySelector('.assunto-editar-form').style.display = 'none';
                });
            });

            // Botão de olho de cada matéria: minimiza/expande só aquele
            // grupo, e lembra o estado (por nome de matéria) pra próxima
            // vez que a extensão abrir.
            questoesAssuntosRender.querySelectorAll('.assunto-grupo-eye-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const grupoEl = btn.closest('.assunto-grupo-materia');
                    const nomeMateria = grupoEl.dataset.materia;
                    const agoraColapsado = grupoEl.classList.toggle('is-collapsed');
                    chrome.storage.local.get(['cbAssuntoGruposColapsados'], (r2) => {
                        const atual = r2.cbAssuntoGruposColapsados || {};
                        atual[nomeMateria] = agoraColapsado;
                        chrome.storage.local.set({ cbAssuntoGruposColapsados: atual });
                    });
                    atualizarLabelToggleAll();
                });
            });

            // Clicar no resto do cabeçalho do grupo também alterna, pra não
            // precisar acertar exatamente no ícone de olho.
            questoesAssuntosRender.querySelectorAll('.assunto-grupo-head').forEach(head => {
                head.addEventListener('click', () => {
                    head.querySelector('.assunto-grupo-eye-btn')?.click();
                });
            });

            atualizarLabelToggleAll();
        });
    }

    // Atualiza o texto do botão "Minimizar todas" / "Expandir todas" de
    // acordo com o estado atual dos grupos renderizados.
    function atualizarLabelToggleAll() {
        if (!assuntoToggleAllLabel) return;
        const grupos = questoesAssuntosRender.querySelectorAll('.assunto-grupo-materia');
        if (grupos.length === 0) return;
        const todosColapsados = Array.from(grupos).every(g => g.classList.contains('is-collapsed'));
        assuntoToggleAllLabel.textContent = todosColapsados ? 'Expandir todas' : 'Minimizar todas';
    }

    // Botão do cabeçalho da seção: minimiza ou expande todas as matérias
    // de uma vez só (e persiste o estado individual de cada uma).
    if (assuntoToggleAllBtn) {
        assuntoToggleAllBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            const grupos = questoesAssuntosRender.querySelectorAll('.assunto-grupo-materia');
            if (grupos.length === 0) return;
            const todosColapsados = Array.from(grupos).every(g => g.classList.contains('is-collapsed'));
            const novoEstado = !todosColapsados; // se já estava tudo colapsado, expande; senão colapsa tudo

            const novoMapa = {};
            grupos.forEach(g => {
                g.classList.toggle('is-collapsed', novoEstado);
                novoMapa[g.dataset.materia] = novoEstado;
            });
            chrome.storage.local.get(['cbAssuntoGruposColapsados'], (r2) => {
                const atual = r2.cbAssuntoGruposColapsados || {};
                Object.assign(atual, novoMapa);
                chrome.storage.local.set({ cbAssuntoGruposColapsados: atual });
            });
            atualizarLabelToggleAll();
        });
    }

    // ===================== MODO EDITAL ABERTO =====================
    // Contagem regressiva até a prova + meta diária dinâmica de questões e
    // horas de estudo. A meta de "hoje" é sempre recalculada a partir do que
    // falta (meta total - já feito desde que o edital foi configurado) 
    // dividido pelos dias restantes — então ela se ajusta sozinha: quem
    // adianta reduz a meta de amanhã, quem atrasa vê a meta subir.
    const editalEmptyState = document.getElementById('edital-empty-state');
    const editalActiveState = document.getElementById('edital-active-state');
    const editalFormOverlay = document.getElementById('edital-form-overlay');
    const editalFormClose = document.getElementById('edital-form-close');
    const btnConfigEdital = document.getElementById('btn-config-edital');
    const btnEditEdital = document.getElementById('btn-edit-edital');
    const btnSalvarEdital = document.getElementById('btn-salvar-edital');
    const btnRemoverEdital = document.getElementById('btn-remover-edital');
    const inputEditalData = document.getElementById('input-edital-data');
    const inputEditalQuestoes = document.getElementById('input-edital-questoes');
    const inputEditalHoras = document.getElementById('input-edital-horas');

    function getDateKey(d) {
        return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    }

    function abrirFormEdital(config) {
        if (!editalFormOverlay) return;
        if (config) {
            inputEditalData.value = config.examDate || '';
            inputEditalQuestoes.value = config.metaQuestoes || '';
            inputEditalHoras.value = config.metaHoras || '';
            btnRemoverEdital.style.display = 'inline-flex';
        } else {
            inputEditalData.value = '';
            inputEditalQuestoes.value = '';
            inputEditalHoras.value = '';
            btnRemoverEdital.style.display = 'none';
        }
        editalFormOverlay.classList.add('open');
    }
    function fecharFormEdital() {
        editalFormOverlay?.classList.remove('open');
    }

    btnConfigEdital?.addEventListener('click', () => abrirFormEdital(null));
    btnEditEdital?.addEventListener('click', () => {
        chrome.storage.sync.get(['editalConfig'], (result) => abrirFormEdital(result.editalConfig || null));
    });
    editalFormClose?.addEventListener('click', fecharFormEdital);
    editalFormOverlay?.addEventListener('click', (e) => {
        if (e.target === editalFormOverlay) fecharFormEdital();
    });

    btnSalvarEdital?.addEventListener('click', () => {
        const examDate = inputEditalData.value;
        const metaQuestoes = parseInt(inputEditalQuestoes.value, 10);
        const metaHoras = parseFloat(inputEditalHoras.value);

        if (!examDate || !metaQuestoes || metaQuestoes <= 0 || !metaHoras || metaHoras <= 0) {
            alert('Preencha a data da prova e metas totais válidas (maiores que zero) para continuar.');
            return;
        }

        chrome.storage.sync.get(['editalConfig'], (result) => {
            const editalConfig = {
                examDate,
                metaQuestoes,
                metaHoras,
                // Preserva a data original de configuração ao EDITAR um edital
                // já existente — só usa "hoje" quando é a primeira vez que o
                // usuário configura um edital. Do contrário, editar (ex: corrigir
                // a data da prova) zerava todo o progresso já contado, porque
                // renderEdital() só soma dias >= configuradoEm.
                configuradoEm: result.editalConfig?.configuradoEm || getDateKey(new Date())
            };
            chrome.storage.sync.set({ editalConfig }, () => {
                fecharFormEdital();
                renderEdital();
            });
        });
    });

    btnRemoverEdital?.addEventListener('click', () => {
        chrome.storage.sync.remove('editalConfig', () => {
            fecharFormEdital();
            renderEdital();
        });
    });

    function renderEdital() {
        if (!editalEmptyState || !editalActiveState) return;
        chrome.storage.sync.get(['editalConfig'], (syncResult) => {
            const config = syncResult.editalConfig;
            if (!config || !config.examDate) {
                editalEmptyState.style.display = 'flex';
                editalActiveState.style.display = 'none';
                return;
            }

            chrome.storage.local.get(['studyHistory', 'questoesDailyHistory'], (result) => {
                const studyHistory = result.studyHistory || {};
                const dailyHistory = result.questoesDailyHistory || {};

                const hoje = new Date();
                hoje.setHours(0, 0, 0, 0);
                const dataProva = new Date(config.examDate + 'T00:00:00');
                const diasRestantes = Math.ceil((dataProva - hoje) / 86400000);

                // Data em que o edital foi configurado — só contamos o que foi
                // feito a partir daí como "progresso" das metas totais.
                const configuradoEm = config.configuradoEm || getDateKey(hoje);

                let questoesFeitas = 0;
                let horasFeitasMs = 0;
                Object.keys(dailyHistory).forEach(key => {
                    if (key >= configuradoEm) questoesFeitas += (dailyHistory[key].total || 0);
                });
                Object.keys(studyHistory).forEach(key => {
                    if (key >= configuradoEm) horasFeitasMs += (studyHistory[key] || 0);
                });
                const horasFeitas = horasFeitasMs / 3600000;

                const questoesRestantes = Math.max(0, config.metaQuestoes - questoesFeitas);
                const horasRestantes = Math.max(0, config.metaHoras - horasFeitas);
                const diasParaDividir = Math.max(1, diasRestantes);

                const metaDiariaQuestoes = Math.ceil(questoesRestantes / diasParaDividir);
                const metaDiariaHoras = horasRestantes / diasParaDividir;

                // Progresso de hoje em relação à meta diária dinâmica
                const hojeKey = getDateKey(hoje);
                const questoesHoje = (dailyHistory[hojeKey] || {}).total || 0;
                const horasHoje = (studyHistory[hojeKey] || 0) / 3600000;

                const pctQuestoesHoje = metaDiariaQuestoes > 0 ? Math.min(100, Math.round((questoesHoje / metaDiariaQuestoes) * 100)) : 100;
                const pctHorasHoje = metaDiariaHoras > 0 ? Math.min(100, Math.round((horasHoje / metaDiariaHoras) * 100)) : 100;

                editalEmptyState.style.display = 'none';
                editalActiveState.style.display = 'flex';

                const diasNumberEl = document.getElementById('edital-days-number');
                const diasCard = editalActiveState;
                if (diasRestantes < 0) {
                    diasNumberEl.textContent = '—';
                    diasCard.classList.add('edital-prova-passou');
                } else {
                    diasNumberEl.textContent = diasRestantes;
                    diasCard.classList.remove('edital-prova-passou');
                }

                const [ano, mes, dia] = config.examDate.split('-');
                document.getElementById('edital-exam-date').textContent = `Prova em ${dia}/${mes}/${ano}`;

                document.getElementById('edital-goal-questoes').textContent = diasRestantes < 0 ? '—' : `${metaDiariaQuestoes} questões`;
                document.getElementById('edital-goal-questoes-fill').style.width = `${pctQuestoesHoje}%`;
                document.getElementById('edital-goal-questoes-progress').textContent = `${questoesHoje} feitas hoje`;

                document.getElementById('edital-goal-horas').textContent = diasRestantes < 0 ? '—' : `${metaDiariaHoras.toFixed(1)}h`;
                document.getElementById('edital-goal-horas-fill').style.width = `${pctHorasHoje}%`;
                document.getElementById('edital-goal-horas-progress').textContent = `${horasHoje.toFixed(1)}h estudadas hoje`;

                document.getElementById('edital-total-questoes-feitas').textContent = questoesFeitas;
                document.getElementById('edital-total-questoes-meta').textContent = config.metaQuestoes;
                document.getElementById('edital-total-horas-feitas').textContent = Math.round(horasFeitas);
                document.getElementById('edital-total-horas-meta').textContent = config.metaHoras;
            });
        });
    }

    renderEdital();

    // ===================== CRONOGRAMA DE LEITURA (PERSONALIZADO) =====================
    // Cada usuário cola o próprio cronograma (matérias/leis a ler por dia).
    // "Dia 1" é a data de início configurada; a partir daí o dia de hoje é
    // calculado automaticamente e o app mostra o que precisa ser lido hoje,
    // com checkbox de conclusão por item e progresso geral do cronograma.
    const cronogramaEmptyState = document.getElementById('cronograma-empty-state');
    const cronogramaActiveState = document.getElementById('cronograma-active-state');
    const cronogramaFormOverlay = document.getElementById('cronograma-form-overlay');
    const cronogramaFormClose = document.getElementById('cronograma-form-close');
    const btnConfigCronograma = document.getElementById('btn-config-cronograma');
    const btnEditCronograma = document.getElementById('btn-edit-cronograma');
    const btnSalvarCronograma = document.getElementById('btn-salvar-cronograma');
    const btnRemoverCronograma = document.getElementById('btn-remover-cronograma');
    const inputCronogramaInicio = document.getElementById('input-cronograma-inicio');
    const inputCronogramaTexto = document.getElementById('input-cronograma-texto');
    const cronogramaHojeList = document.getElementById('cronograma-hoje-list');
    const inputCronogramaXlsx = document.getElementById('input-cronograma-xlsx');
    const cronogramaImportStatus = document.getElementById('cronograma-import-status');
    const btnConfirmarLeituraHoje = document.getElementById('btn-confirmar-leitura-hoje');
    const btnVerCalendario = document.getElementById('btn-ver-calendario');
    const cronogramaCalendarOverlay = document.getElementById('cronograma-calendar-overlay');
    const cronogramaCalendarClose = document.getElementById('cronograma-calendar-close');
    const cronogramaCalendarBody = document.getElementById('cronograma-calendar-body');

    // Converte o texto colado pelo usuário (um dia por linha) no formato:
    // "Matéria | Conteúdo; Matéria | Conteúdo; Matéria | Conteúdo"
    // em uma lista de dias, cada um com até 3 itens {materia, conteudo}.
    function parseCronogramaTexto(texto) {
        return texto
            .split('\n')
            .map(linha => linha.trim())
            .filter(linha => linha.length > 0)
            .map(linha => {
                return linha.split(';')
                    .map(parte => parte.trim())
                    .filter(parte => parte.length > 0 && parte !== '-')
                    .slice(0, 3)
                    .map(parte => {
                        const [materia, ...resto] = parte.split('|');
                        return {
                            materia: (materia || '').trim(),
                            conteudo: resto.join('|').trim()
                        };
                    })
                    .filter(item => item.materia.length > 0);
            })
            .filter(dia => dia.length > 0);
    }

    function cronogramaDiaParaTexto(dias) {
        return dias.map(dia => dia.map(item => `${item.materia}${item.conteudo ? ' | ' + item.conteudo : ''}`).join('; ')).join('\n');
    }

    // Converte as linhas de uma planilha (array de arrays, vindas do XLSX) no
    // mesmo formato de "dias" usado pelo cronograma manual. Aceita a estrutura
    // Dia | Semana | Matéria 1 | Conteúdo 1 | Matéria 2 | Conteúdo 2 | Matéria 3 | Conteúdo 3 | Concluído
    // mas é tolerante a colunas fora de ordem/ausentes, detectando pelo cabeçalho.
    function parseCronogramaLinhasPlanilha(linhas) {
        if (!Array.isArray(linhas) || linhas.length === 0) return [];

        let linhasDados = linhas;
        let colMaterias = [2, 4, 6]; // fallback: C/D, E/F, G/H (0-indexed 2,4,6)

        const primeira = (linhas[0] || []).map(c => String(c || '').toLowerCase().trim());
        const pareceCabecalho = primeira.some(c => c.includes('matéria') || c.includes('materia') || c.includes('dia'));
        if (pareceCabecalho) {
            linhasDados = linhas.slice(1);
            const idxMaterias = [];
            primeira.forEach((cell, idx) => {
                if (cell.includes('matéria') || cell.includes('materia')) idxMaterias.push(idx);
            });
            if (idxMaterias.length > 0) colMaterias = idxMaterias.slice(0, 3);
        }

        return linhasDados
            .filter(linha => Array.isArray(linha) && linha.some(c => String(c || '').trim().length > 0))
            .map(linha => {
                return colMaterias
                    .map(idxMateria => {
                        const materia = String(linha[idxMateria] ?? '').trim();
                        const conteudo = String(linha[idxMateria + 1] ?? '').trim();
                        return { materia, conteudo: conteudo === '-' ? '' : conteudo };
                    })
                    .filter(item => item.materia.length > 0 && item.materia !== '-');
            })
            .filter(dia => dia.length > 0);
    }

    inputCronogramaXlsx?.addEventListener('change', (e) => {
        const file = e.target.files && e.target.files[0];
        if (!file) return;

        cronogramaImportStatus.textContent = 'Lendo planilha...';
        cronogramaImportStatus.className = 'cronograma-import-status';

        // xlsx (880 KB) só é carregado aqui, na hora de importar
        (typeof XLSX === 'undefined' ? window.cbCarregarScript('xlsx.full.min.js') : Promise.resolve()).then(() => {
        const reader = new FileReader();
        reader.onload = (evt) => {
            try {
                const data = new Uint8Array(evt.target.result);
                const workbook = XLSX.read(data, { type: 'array' });
                const primeiraAba = workbook.SheetNames[0];
                const sheet = workbook.Sheets[primeiraAba];
                const linhas = XLSX.utils.sheet_to_json(sheet, { header: 1, raw: false, defval: '' });
                const dias = parseCronogramaLinhasPlanilha(linhas);

                if (dias.length === 0) {
                    cronogramaImportStatus.textContent = 'Não encontrei dias válidos nessa planilha. Confira as colunas.';
                    cronogramaImportStatus.className = 'cronograma-import-status err';
                    return;
                }

                inputCronogramaTexto.value = cronogramaDiaParaTexto(dias);
                if (!inputCronogramaInicio.value) inputCronogramaInicio.value = getDateKey(new Date());
                cronogramaImportStatus.textContent = `Planilha importada: ${dias.length} dia(s) organizados automaticamente. Confira abaixo e clique em Salvar.`;
                cronogramaImportStatus.className = 'cronograma-import-status ok';
            } catch (err) {
                console.warn('[Concurseiro Blindado] Erro ao ler planilha do cronograma:', err);
                cronogramaImportStatus.textContent = 'Erro ao ler o arquivo. Verifique se é um .xlsx válido.';
                cronogramaImportStatus.className = 'cronograma-import-status err';
            } finally {
                inputCronogramaXlsx.value = '';
            }
        };
        reader.readAsArrayBuffer(file);
        }).catch(() => {
            cronogramaImportStatus.textContent = 'Não foi possível carregar o leitor de planilhas.';
            cronogramaImportStatus.className = 'cronograma-import-status err';
            inputCronogramaXlsx.value = '';
        });
    });

    function abrirFormCronograma(config) {
        if (!cronogramaFormOverlay) return;
        if (cronogramaImportStatus) {
            cronogramaImportStatus.textContent = '';
            cronogramaImportStatus.className = 'cronograma-import-status';
        }
        if (config) {
            inputCronogramaInicio.value = config.startDate || '';
            inputCronogramaTexto.value = cronogramaDiaParaTexto(config.dias || []);
            btnRemoverCronograma.style.display = 'inline-flex';
        } else {
            inputCronogramaInicio.value = getDateKey(new Date());
            inputCronogramaTexto.value = '';
            btnRemoverCronograma.style.display = 'none';
        }
        cronogramaFormOverlay.classList.add('open');
    }
    function fecharFormCronograma() {
        cronogramaFormOverlay?.classList.remove('open');
    }

    btnConfigCronograma?.addEventListener('click', () => abrirFormCronograma(null));
    btnEditCronograma?.addEventListener('click', () => {
        chrome.storage.local.get(['cronogramaConfig'], (result) => abrirFormCronograma(result.cronogramaConfig || null));
    });
    cronogramaFormClose?.addEventListener('click', fecharFormCronograma);
    cronogramaFormOverlay?.addEventListener('click', (e) => {
        if (e.target === cronogramaFormOverlay) fecharFormCronograma();
    });

    btnSalvarCronograma?.addEventListener('click', () => {
        const startDate = inputCronogramaInicio.value;
        const dias = parseCronogramaTexto(inputCronogramaTexto.value || '');

        if (!startDate || dias.length === 0) {
            alert('Informe a data de início e pelo menos um dia de cronograma (uma linha com ao menos uma matéria).');
            return;
        }

        const cronogramaConfig = { startDate, dias };
        chrome.storage.local.set({ cronogramaConfig, cronogramaProgresso: {} }, () => {
            fecharFormCronograma();
            renderCronograma();
        });
    });

    btnRemoverCronograma?.addEventListener('click', () => {
        chrome.storage.local.remove(['cronogramaConfig', 'cronogramaProgresso'], () => {
            fecharFormCronograma();
            renderCronograma();
        });
    });

    function toggleCronogramaItem(diaIndex, itemIndex, totalItensNoDia) {
        chrome.storage.local.get(['cronogramaProgresso'], (result) => {
            const progresso = result.cronogramaProgresso || {};
            const doDia = progresso[diaIndex] || new Array(totalItensNoDia).fill(false);
            doDia[itemIndex] = !doDia[itemIndex];
            progresso[diaIndex] = doDia;
            chrome.storage.local.set({ cronogramaProgresso: progresso }, () => renderCronograma());
        });
    }

    function marcarDiaCompleto(diaIndex, totalItens, valor) {
        chrome.storage.local.get(['cronogramaProgresso'], (result) => {
            const progresso = result.cronogramaProgresso || {};
            progresso[diaIndex] = new Array(totalItens).fill(valor);
            chrome.storage.local.set({ cronogramaProgresso: progresso }, () => {
                renderCronograma();
                if (cronogramaCalendarOverlay?.classList.contains('open')) renderCronogramaCalendario();
            });
        });
    }

    btnConfirmarLeituraHoje?.addEventListener('click', () => {
        chrome.storage.local.get(['cronogramaConfig', 'cronogramaProgresso'], (result) => {
            const config = result.cronogramaConfig;
            if (!config || !Array.isArray(config.dias) || config.dias.length === 0) return;
            const hoje = new Date();
            hoje.setHours(0, 0, 0, 0);
            const inicio = new Date(config.startDate + 'T00:00:00');
            const totalDias = config.dias.length;
            let diaIndex = Math.floor((hoje - inicio) / 86400000);
            diaIndex = Math.max(0, Math.min(totalDias - 1, diaIndex));

            const itensHoje = config.dias[diaIndex] || [];
            if (itensHoje.length === 0) return;
            const progresso = result.cronogramaProgresso || {};
            const marcadosHoje = progresso[diaIndex] || [];
            const tudoMarcado = itensHoje.length > 0 && itensHoje.every((_, idx) => marcadosHoje[idx]);
            marcarDiaCompleto(diaIndex, itensHoje.length, !tudoMarcado);
        });
    });

    // ===================== CALENDÁRIO SEMANAL DO CRONOGRAMA =====================
    function fecharCronogramaCalendario() {
        cronogramaCalendarOverlay?.classList.remove('open');
    }
    btnVerCalendario?.addEventListener('click', () => {
        cronogramaCalendarOverlay?.classList.add('open');
        renderCronogramaCalendario();
    });
    cronogramaCalendarClose?.addEventListener('click', fecharCronogramaCalendario);
    cronogramaCalendarOverlay?.addEventListener('click', (e) => {
        if (e.target === cronogramaCalendarOverlay) fecharCronogramaCalendario();
    });

    function renderCronogramaCalendario() {
        if (!cronogramaCalendarBody) return;
        chrome.storage.local.get(['cronogramaConfig', 'cronogramaProgresso'], (result) => {
            const config = result.cronogramaConfig;
            if (!config || !Array.isArray(config.dias) || config.dias.length === 0) {
                cronogramaCalendarBody.innerHTML = '<p class="questoes-empty">Nenhum cronograma cadastrado.</p>';
                return;
            }
            const progresso = result.cronogramaProgresso || {};
            const inicio = new Date(config.startDate + 'T00:00:00');
            const hoje = new Date();
            hoje.setHours(0, 0, 0, 0);
            const totalDias = config.dias.length;
            const totalSemanas = Math.ceil(totalDias / 7);

            let html = '';
            for (let semana = 0; semana < totalSemanas; semana++) {
                html += `<div class="cronograma-week-block"><div class="cronograma-week-title">Semana ${semana + 1}</div><div class="cronograma-week-grid">`;
                for (let d = semana * 7; d < Math.min(semana * 7 + 7, totalDias); d++) {
                    const dataDia = new Date(inicio.getTime() + d * 86400000);
                    const itens = config.dias[d] || [];
                    const marcados = progresso[d] || [];
                    const concluidos = itens.filter((_, idx) => marcados[idx]).length;
                    let status = 'pending';
                    if (dataDia.getTime() > hoje.getTime()) status = 'future';
                    if (dataDia.getTime() === hoje.getTime()) status = 'today';
                    if (itens.length > 0 && concluidos === itens.length) status = 'done';
                    else if (concluidos > 0) status = 'partial';

                    const dataLabel = `${String(dataDia.getDate()).padStart(2, '0')}/${String(dataDia.getMonth() + 1).padStart(2, '0')}`;
                    html += `<div class="cronograma-day-cell ${status}" data-dia="${d}">
                        <span class="num">${d + 1}</span>
                        <span class="date">${dataLabel}</span>
                    </div>`;
                }
                html += `</div><div class="cronograma-day-detail" id="cronograma-day-detail-${semana}"></div></div>`;
            }
            cronogramaCalendarBody.innerHTML = html;

            let detailAberto = null;
            cronogramaCalendarBody.querySelectorAll('.cronograma-day-cell').forEach(cell => {
                cell.addEventListener('click', () => {
                    const d = parseInt(cell.dataset.dia, 10);
                    const semana = Math.floor(d / 7);
                    const detailEl = document.getElementById(`cronograma-day-detail-${semana}`);
                    if (!detailEl) return;

                    if (detailAberto === d) {
                        detailEl.classList.remove('open');
                        detailEl.innerHTML = '';
                        detailAberto = null;
                        return;
                    }
                    detailAberto = d;
                    document.querySelectorAll('.cronograma-day-detail').forEach(el => { el.classList.remove('open'); el.innerHTML = ''; });

                    const itens = config.dias[d] || [];
                    const marcados = progresso[d] || [];
                    const dataDia = new Date(inicio.getTime() + d * 86400000);
                    const dataLabel = dataDia.toLocaleDateString('pt-BR');
                    detailEl.innerHTML = `<div class="cronograma-day-detail-title">Dia ${d + 1} — ${dataLabel}</div>` +
                        (itens.map((item, idx) => {
                            const marcado = !!marcados[idx];
                            return `<label class="cronograma-item-row ${marcado ? 'done' : ''}">
                                <input type="checkbox" class="cronograma-cal-check" data-dia="${d}" data-idx="${idx}" ${marcado ? 'checked' : ''}>
                                <span class="cronograma-item-check-box"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg></span>
                                <span class="cronograma-item-text"><strong>${item.materia}</strong>${item.conteudo ? `<span>${item.conteudo}</span>` : ''}</span>
                            </label>`;
                        }).join('') || '<p class="questoes-empty">Sem itens cadastrados para este dia.</p>');
                    detailEl.classList.add('open');

                    detailEl.querySelectorAll('.cronograma-cal-check').forEach(chk => {
                        chk.addEventListener('change', () => {
                            const diaChk = parseInt(chk.dataset.dia, 10);
                            const idxChk = parseInt(chk.dataset.idx, 10);
                            toggleCronogramaItem(diaChk, idxChk, (config.dias[diaChk] || []).length);
                            setTimeout(renderCronogramaCalendario, 50);
                        });
                    });
                });
            });
        });
    }

    function renderCronograma() {
        if (!cronogramaEmptyState || !cronogramaActiveState) return;
        chrome.storage.local.get(['cronogramaConfig', 'cronogramaProgresso'], (result) => {
            const config = result.cronogramaConfig;
            const progresso = result.cronogramaProgresso || {};

            if (!config || !Array.isArray(config.dias) || config.dias.length === 0) {
                cronogramaEmptyState.style.display = 'flex';
                cronogramaActiveState.style.display = 'none';
                return;
            }

            cronogramaEmptyState.style.display = 'none';
            cronogramaActiveState.style.display = 'flex';

            const hoje = new Date();
            hoje.setHours(0, 0, 0, 0);
            const inicio = new Date(config.startDate + 'T00:00:00');
            const totalDias = config.dias.length;
            let diaIndex = Math.floor((hoje - inicio) / 86400000);
            diaIndex = Math.max(0, Math.min(totalDias - 1, diaIndex));

            document.getElementById('cronograma-dia-label').textContent =
                diaIndex >= totalDias - 1 && hoje > new Date(inicio.getTime() + (totalDias - 1) * 86400000)
                    ? `Cronograma concluído (${totalDias} dias)`
                    : `Dia ${diaIndex + 1} de ${totalDias}`;

            // Progresso geral: dia é considerado concluído quando todos os
            // itens marcados até ele estão com checkbox marcado.
            let diasConcluidos = 0;
            for (let i = 0; i <= diaIndex; i++) {
                const itens = config.dias[i] || [];
                const marcados = progresso[i] || [];
                if (itens.length > 0 && itens.every((_, idx) => marcados[idx])) diasConcluidos++;
            }
            const pctGeral = totalDias > 0 ? Math.round((diasConcluidos / totalDias) * 100) : 0;
            document.getElementById('cronograma-progress-fill').style.width = `${pctGeral}%`;
            document.getElementById('cronograma-progress-text').textContent = `${diasConcluidos} de ${totalDias} dias concluídos`;

            const itensHoje = config.dias[diaIndex] || [];
            const marcadosHoje = progresso[diaIndex] || [];
            cronogramaHojeList.innerHTML = itensHoje.map((item, idx) => {
                const marcado = !!marcadosHoje[idx];
                return `
                    <label class="cronograma-item-row ${marcado ? 'done' : ''}">
                        <input type="checkbox" class="cronograma-item-check" data-idx="${idx}" ${marcado ? 'checked' : ''}>
                        <span class="cronograma-item-check-box">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
                        </span>
                        <span class="cronograma-item-text">
                            <strong>${item.materia}</strong>
                            ${item.conteudo ? `<span>${item.conteudo}</span>` : ''}
                        </span>
                    </label>`;
            }).join('') || '<p class="questoes-empty">Sem itens cadastrados para este dia.</p>';

            cronogramaHojeList.querySelectorAll('.cronograma-item-check').forEach(chk => {
                chk.addEventListener('change', () => toggleCronogramaItem(diaIndex, parseInt(chk.dataset.idx, 10), itensHoje.length));
            });

            if (btnConfirmarLeituraHoje) {
                const tudoMarcado = itensHoje.length > 0 && itensHoje.every((_, idx) => marcadosHoje[idx]);
                btnConfirmarLeituraHoje.style.display = itensHoje.length > 0 ? 'flex' : 'none';
                btnConfirmarLeituraHoje.classList.toggle('all-done', tudoMarcado);
                btnConfirmarLeituraHoje.innerHTML = tudoMarcado
                    ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg> Leitura de hoje confirmada'
                    : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg> Confirmar leitura de hoje';
            }
        });
    }

    renderCronograma();

    // ===================== AVISO DE PENDÊNCIA DE LEITURA =====================
    // Se um dia anterior ao de hoje ficou com item(ns) não marcado(s) como
    // lido, mostra um aviso no topo do popup. Cada aviso pode ser confirmado
    // (marca o dia como lido) ou dispensado (some e não volta a aparecer).
    const cronogramaAlertBanner = document.getElementById('cronograma-alert-banner');

    function renderCronogramaAvisos() {
        if (!cronogramaAlertBanner) return;
        chrome.storage.local.get(['cronogramaConfig', 'cronogramaProgresso', 'cronogramaAvisosDispensados'], (result) => {
            const config = result.cronogramaConfig;
            if (!config || !Array.isArray(config.dias) || config.dias.length === 0) {
                cronogramaAlertBanner.style.display = 'none';
                cronogramaAlertBanner.innerHTML = '';
                return;
            }
            const progresso = result.cronogramaProgresso || {};
            const dispensados = result.cronogramaAvisosDispensados || {};

            const hoje = new Date();
            hoje.setHours(0, 0, 0, 0);
            const inicio = new Date(config.startDate + 'T00:00:00');
            const totalDias = config.dias.length;
            let diaAtualIndex = Math.floor((hoje - inicio) / 86400000);
            diaAtualIndex = Math.max(0, Math.min(totalDias - 1, diaAtualIndex));

            const pendencias = [];
            for (let i = 0; i < diaAtualIndex; i++) {
                if (dispensados[i]) continue;
                const itens = config.dias[i] || [];
                if (itens.length === 0) continue;
                const marcados = progresso[i] || [];
                const tudoMarcado = itens.every((_, idx) => marcados[idx]);
                if (!tudoMarcado) {
                    const dataDia = new Date(inicio.getTime() + i * 86400000);
                    pendencias.push({
                        diaIndex: i,
                        dataLabel: dataDia.toLocaleDateString('pt-BR'),
                        totalItens: itens.length
                    });
                }
            }

            if (pendencias.length === 0) {
                cronogramaAlertBanner.style.display = 'none';
                cronogramaAlertBanner.innerHTML = '';
                return;
            }

            cronogramaAlertBanner.style.display = 'flex';
            cronogramaAlertBanner.innerHTML = pendencias.map(p => `
                <div class="cronograma-alert-item" data-dia="${p.diaIndex}">
                    <svg class="cronograma-alert-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0Z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>
                    <span class="cronograma-alert-text">
                        <strong>Leitura do dia ${p.diaIndex + 1} não confirmada</strong>
                        <span>${p.dataLabel} — você não marcou essa leitura como concluída.</span>
                    </span>
                    <span class="cronograma-alert-actions">
                        <button class="cronograma-alert-confirm" data-dia="${p.diaIndex}" data-total="${p.totalItens}">Marcar como lido</button>
                        <button class="cronograma-alert-dismiss" data-dia="${p.diaIndex}" title="Apagar notificação">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
                        </button>
                    </span>
                </div>
            `).join('');

            cronogramaAlertBanner.querySelectorAll('.cronograma-alert-confirm').forEach(btn => {
                btn.addEventListener('click', () => {
                    const dia = parseInt(btn.dataset.dia, 10);
                    const total = parseInt(btn.dataset.total, 10);
                    marcarDiaCompleto(dia, total, true);
                });
            });
            cronogramaAlertBanner.querySelectorAll('.cronograma-alert-dismiss').forEach(btn => {
                btn.addEventListener('click', () => {
                    const dia = parseInt(btn.dataset.dia, 10);
                    chrome.storage.local.get(['cronogramaAvisosDispensados'], (r) => {
                        const disp = r.cronogramaAvisosDispensados || {};
                        disp[dia] = true;
                        chrome.storage.local.set({ cronogramaAvisosDispensados: disp }, () => renderCronogramaAvisos());
                    });
                });
            });
        });
    }

    renderCronogramaAvisos();

    function setQuestoesPeriod(period, btnAtivo) {
        currentQuestoesPeriod = period;
        questoesPeriodBtns.forEach(b => b.classList.remove('active'));
        btnAtivo.classList.add('active');
        renderQuestoesPerformance();
    }
    questoesPeriodBtns.forEach(btn => {
        btn.addEventListener('click', () => setQuestoesPeriod(parseInt(btn.dataset.period, 10), btn));
    });

    function renderChart(animate = true) {
        // A curva segue o mesmo filtro de periodo das barras.
        renderEvolucao();

        chrome.storage.local.get(['studyHistory', 'hourlyHistory', 'activityHistory', 'pauseHistory', 'pauseStartedAt', 'sessionState'], (result) => {
            const study = result.studyHistory || {};
            const hourlyHistory = result.hourlyHistory || {};
            const activityHistory = result.activityHistory || {};
            const pauseHistory = result.pauseHistory || {};
            // Se existe uma pausa em andamento agora, soma o tempo dela em
            // tempo real (só é gravada no histórico quando a pausa termina).
            const todayKeyForPause = getTodayKey();
            const livePauseStartedAt = (result.sessionState !== 'running' && result.pauseStartedAt) ? result.pauseStartedAt : null;
            chartRender.innerHTML = '';
            chartRender.classList.toggle('animate-in', animate);
            const goalMs = dailyGoalMs;

            let dataPoints = [];
            const today = new Date();

            // Se tem data selecionada no date picker, usa ela como referência
            const selectedDate = chartDatePicker.value ? new Date(chartDatePicker.value + 'T12:00:00') : today;

            if (currentChartPeriod === 'day') {
                for (let i = 2; i >= 0; i--) {
                    let d = new Date(selectedDate); d.setDate(selectedDate.getDate() - i);
                    let key = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
                    const isSelected = chartDatePicker.value && i === 0;
                    // Formato curto (ex: "06/08") para o rótulo nunca quebrar em duas
                    // linhas dentro da coluna estreita da barra — um rótulo com "6 de
                    // ago." quebrando em 2 linhas empurrava só aquela barra para uma
                    // posição vertical diferente das demais, causando o desalinhamento.
                    const labelCurto = String(d.getDate()).padStart(2, '0') + '/' + String(d.getMonth() + 1).padStart(2, '0');
                    dataPoints.push({ label: isSelected ? "Selec." : (i === 0 && !chartDatePicker.value ? "Hoje" : labelCurto), key: key });
                }
            } 
            else if (currentChartPeriod === 'week') {
                for (let i = 6; i >= 0; i--) {
                    let d = new Date(selectedDate); d.setDate(selectedDate.getDate() - i);
                    let key = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
                    dataPoints.push({ label: i === 0 && !chartDatePicker.value ? "Hoje" : d.toLocaleDateString('pt-BR', {weekday: 'short'}).toUpperCase().replace('.', ''), key: key });
                }
            } 
            else if (currentChartPeriod === 'month') {
                for (let i = 3; i >= 0; i--) {
                    let keys = [];
                    for (let j = 6; j >= 0; j--) {
                        let d = new Date(selectedDate); d.setDate(selectedDate.getDate() - (i * 7 + j));
                        keys.push(d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'));
                    }
                    dataPoints.push({ label: `Sem. ${4-i}`, keys: keys });
                }
            }
            else if (currentChartPeriod === 'semester') {
                // Seis meses, um balde por mês. Não dá pra usar "30 dias
                // atrás" seis vezes: os meses têm tamanhos diferentes e as
                // colunas ficariam desalinhadas do calendário real, então
                // "Mar" acabaria contendo pedaço de fevereiro.
                const MES_CURTO = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun',
                                   'jul', 'ago', 'set', 'out', 'nov', 'dez'];
                for (let i = 5; i >= 0; i--) {
                    const ref = new Date(selectedDate.getFullYear(), selectedDate.getMonth() - i, 1);
                    const ultimoDia = new Date(ref.getFullYear(), ref.getMonth() + 1, 0).getDate();
                    const keys = [];
                    for (let dia = 1; dia <= ultimoDia; dia++) {
                        keys.push(ref.getFullYear() + '-' +
                                  String(ref.getMonth() + 1).padStart(2, '0') + '-' +
                                  String(dia).padStart(2, '0'));
                    }
                    dataPoints.push({ label: MES_CURTO[ref.getMonth()], keys: keys });
                }
            }

            dataPoints.forEach(dp => {
                let totalTime = 0, mad = 0, man = 0, tar = 0, noi = 0, daysMet = 0;
                let questoesMs = 0, leituraMs = 0, videoaulaMs = 0;
                let pauseMs = 0, pauseCount = 0;

                const processKey = (k) => {
                    const t = study[k] || 0;
                    totalTime += t;
                    if (t >= goalMs) daysMet++;
                    if (hourlyHistory[k]) {
                        for (let h = 0; h < 24; h++) {
                            let val = hourlyHistory[k][h] || 0;
                            if (h >= 0 && h < 6) mad += val;
                            else if (h >= 6 && h < 12) man += val;
                            else if (h >= 12 && h < 18) tar += val;
                            else noi += val;
                        }
                    }
                    if (activityHistory[k]) {
                        questoesMs += activityHistory[k].questoes || 0;
                        leituraMs += activityHistory[k].leitura || 0;
                        videoaulaMs += activityHistory[k].videoaula || 0;
                    }
                    if (pauseHistory[k]) {
                        pauseMs += pauseHistory[k].totalMs || 0;
                        pauseCount += pauseHistory[k].count || 0;
                    }
                };

                if (dp.keys) dp.keys.forEach(processKey);
                else processKey(dp.key);

                if (totalTime > 0 && (mad + man + tar + noi) === 0) tar = totalTime;

                dp.totalTime = totalTime; dp.mad = mad; dp.man = man; dp.tar = tar; dp.noi = noi;
                dp.daysMet = daysMet;
                dp.questoesMs = questoesMs; dp.leituraMs = leituraMs; dp.videoaulaMs = videoaulaMs;
                dp.pauseMs = pauseMs; dp.pauseCount = pauseCount;
                if (dp.key === todayKeyForPause && livePauseStartedAt) {
                    dp.pauseMs += Math.max(0, Date.now() - livePauseStartedAt);
                }
            });

            const totalPeriodo = dataPoints.reduce((sum, dp) => sum + dp.totalTime, 0);
            const mediaPeriodo = totalPeriodo / dataPoints.length;
            let bestIdx = 0;
            dataPoints.forEach((dp, idx) => { if (dp.totalTime > dataPoints[bestIdx].totalTime) bestIdx = idx; });
            const unidade = currentChartPeriod === 'month' ? 'semana' : 'dia';

            const unidadesComMeta = dataPoints.filter(dp => dp.key ? dp.totalTime >= goalMs : dp.daysMet >= Math.ceil((dp.keys ? dp.keys.length : 7) / 2)).length;
            const consistencia = Math.round((unidadesComMeta / dataPoints.length) * 100);

            const statsHtmlParts = [];
            if (chartStatsVisibility.total) {
                statsHtmlParts.push(`
                <div class="chart-stat">
                    <span class="chart-stat-label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg><span>Total</span></span>
                    <span class="chart-stat-value">${formatHoursMinutes(totalPeriodo)}</span>
                </div>`);
            }
            if (chartStatsVisibility.media) {
                statsHtmlParts.push(`
                <div class="chart-stat">
                    <span class="chart-stat-label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 20V10M12 20V4M20 20v-6"/></svg><span>Média/${unidade}</span></span>
                    <span class="chart-stat-value">${formatHoursMinutes(mediaPeriodo)}</span>
                </div>`);
            }
            if (chartStatsVisibility.melhor) {
                statsHtmlParts.push(`
                <div class="chart-stat">
                    <span class="chart-stat-label gold"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2 9.5 8.5 3 9l5 4.6L6.5 20 12 16.3 17.5 20 16 13.6l5-4.6-6.5-.5Z"/></svg><span>Melhor ${unidade}</span></span>
                    <span class="chart-stat-value gold">${dataPoints[bestIdx].totalTime > 0 ? dataPoints[bestIdx].label : '—'}</span>
                </div>`);
            }
            if (chartStatsVisibility.consistencia) {
                statsHtmlParts.push(`
                <div class="chart-stat">
                    <span class="chart-stat-label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m5 12 5 5 9-10"/></svg><span>Consistência</span></span>
                    <span class="chart-stat-value">${consistencia}%</span>
                </div>`);
            }
            chartSummary.innerHTML = statsHtmlParts.join('');
            chartSummary.style.display = statsHtmlParts.length ? '' : 'none';

            const maxTotal = currentChartViewMode === 'pauses'
                ? Math.max(...dataPoints.map(dp => dp.pauseMs), 1)
                // Antes só considerava o maior valor entre as barras — se a
                // meta diária (definida em Ajustes) fosse maior que todos os
                // dias exibidos, a linha da meta ficava "fora da escala" e
                // simplesmente não aparecia (só um texto avisando isso).
                // Incluindo a meta aqui, a escala sempre acomoda os dois: as
                // barras ficam proporcionalmente um pouco menores, mas a
                // linha da meta sempre é desenhada de verdade.
                : Math.max(...dataPoints.map(dp => dp.totalTime), goalMs || 0, 1);
            // Só decide aqui SE a linha da meta cabe na escala atual (usado na
            // legenda logo abaixo). A posição real das linhas (em pixels) só
            // é calculada mais adiante, depois que as barras — e a "régua"
            // real do .chart-bar-track — já existem no DOM. Ver comentário
            // grande depois do forEach das barras: as linhas usavam % do
            // .chart-container inteiro (172px), mas as barras usam % do
            // .chart-bar-track, que é MENOR (desconta o número em cima e o
            // rótulo do dia embaixo). Isso fazia a linha da meta/média ficar
            // desenhada mais alta do que deveria em relação às barras.
            const goalLineDesenhada = currentChartViewMode !== 'pauses' && goalMs > 0 && (goalMs / maxTotal) * 100 <= 100;

            // Legenda explicando as duas linhas tracejadas: a azul (média) é
            // calculada a partir dos próprios dias mostrados no gráfico; a
            // amarela (meta) é fixa, vem da meta diária definida em Ajustes.
            if (chartLinesLegend) {
                if (currentChartViewMode !== 'pauses' && !chartLegendTextHidden) {
                    const metaHorasTxt = formatHoursMinutes(goalMs);
                    chartLinesLegend.innerHTML = `
                        <span class="legend-item" style="color:var(--accent)"><span class="legend-line"></span>Média: tempo médio estudado nesse período</span>
                        <span class="legend-item" style="color:#fbbf24"><span class="legend-line"></span>Meta do dia: ${metaHorasTxt} definidos em Ajustes</span>
                    `;
                } else {
                    chartLinesLegend.innerHTML = '';
                }
            }

            const maxPauseCount = Math.max(...dataPoints.map(dp => dp.pauseCount || 0), 1);

            dataPoints.forEach((dp, idx) => {
                let heightPct, partsHtml, valorLabel;

                if (currentChartViewMode === 'activity') {
                    // Verde = tempo em Questões, Amarelo = tempo em Leitura
                    heightPct = (dp.totalTime / maxTotal) * 100;
                    valorLabel = dp.totalTime > 0 ? formatHoursMinutes(dp.totalTime) : '';
                    const pQuestoes = dp.totalTime > 0 ? (dp.questoesMs / dp.totalTime) * 100 : 0;
                    const pLeitura = dp.totalTime > 0 ? (dp.leituraMs / dp.totalTime) * 100 : 0;
                    const pVideoaula = dp.totalTime > 0 ? ((dp.videoaulaMs || 0) / dp.totalTime) * 100 : 0;
                    partsHtml = '';
                    if (dp.questoesMs > 0) partsHtml += `<div class="time-part" style="height: ${pQuestoes}%; background: #8b5cf6;" data-tooltip="Questões: ${formatHoursMinutes(dp.questoesMs)}"></div>`;
                    if (dp.leituraMs > 0) partsHtml += `<div class="time-part" style="height: ${pLeitura}%; background: #fbbf24;" data-tooltip="Leitura: ${formatHoursMinutes(dp.leituraMs)}"></div>`;
                    if (dp.videoaulaMs > 0) partsHtml += `<div class="time-part" style="height: ${pVideoaula}%; background: #ef4444;" data-tooltip="Vídeo-aula: ${formatHoursMinutes(dp.videoaulaMs)}"></div>`;
                } else if (currentChartViewMode === 'pauses') {
                    // Vermelho = tempo total pausado; a etiqueta acima mostra
                    // também a quantidade de pausas no período.
                    heightPct = (dp.pauseMs / maxTotal) * 100;
                    valorLabel = dp.pauseMs > 0 ? formatHoursMinutes(dp.pauseMs) : '';
                    partsHtml = `<div class="time-part" style="height: 100%; background: #f43f5e;" data-tooltip="Pausado: ${formatHoursMinutes(dp.pauseMs)} · ${dp.pauseCount || 0}x"></div>`;
                } else {
                    // Modo padrão: distribuição por período do dia
                    heightPct = (dp.totalTime / maxTotal) * 100;
                    valorLabel = dp.totalTime > 0 ? formatHoursMinutes(dp.totalTime) : '';
                    const pMad = dp.totalTime > 0 ? (dp.mad / dp.totalTime) * 100 : 0;
                    const pMan = dp.totalTime > 0 ? (dp.man / dp.totalTime) * 100 : 0;
                    const pTar = dp.totalTime > 0 ? (dp.tar / dp.totalTime) * 100 : 0;
                    const pNoi = dp.totalTime > 0 ? (dp.noi / dp.totalTime) * 100 : 0;
                    partsHtml = '';
                    if (dp.mad > 0) partsHtml += `<div class="time-part" style="height: ${pMad}%; background: ${chartPeriodColors.mad};" data-tooltip="Madrugada: ${formatHoursMinutes(dp.mad)}"></div>`;
                    if (dp.man > 0) partsHtml += `<div class="time-part" style="height: ${pMan}%; background: ${chartPeriodColors.man};" data-tooltip="Manhã: ${formatHoursMinutes(dp.man)}"></div>`;
                    if (dp.tar > 0) partsHtml += `<div class="time-part" style="height: ${pTar}%; background: ${chartPeriodColors.tar};" data-tooltip="Tarde: ${formatHoursMinutes(dp.tar)}"></div>`;
                    if (dp.noi > 0) partsHtml += `<div class="time-part" style="height: ${pNoi}%; background: ${chartPeriodColors.noi};" data-tooltip="Noite: ${formatHoursMinutes(dp.noi)}"></div>`;
                }

                const isToday = dp.key && dp.label === 'Hoje';
                const isSelectedDate = chartDatePicker.value && dp.label === 'Selec.';

                const pauseBadge = currentChartViewMode === 'pauses'
                    ? `<div class="chart-pause-badge"${dp.pauseCount > 0 ? ` style="opacity:${0.35 + 0.65 * (dp.pauseCount / maxPauseCount)}"` : ' style="opacity:0"'}>${dp.pauseCount > 0 ? dp.pauseCount + 'x' : '0x'}</div>`
                    : '';

                const barWrapper = document.createElement('div');
                barWrapper.className = 'chart-bar-wrapper' + (isToday ? ' is-today' : '') + (isSelectedDate ? ' is-selected' : '') + (currentChartViewMode === 'pauses' ? ' is-pauses-mode' : '');
                barWrapper.style.setProperty('--i', idx);
                barWrapper.innerHTML = `
                    <div class="chart-val-lbl">${valorLabel}</div>
                    ${pauseBadge}
                    <div class="chart-bar-track">
                        <div class="chart-bar-stacked" style="height: ${Math.max(heightPct, 4)}%;">
                            ${partsHtml}
                        </div>
                    </div>
                    <div class="chart-day-lbl">${dp.label}</div>
                `;
                barWrapper.addEventListener('click', () => selecionarBarra(idx, dataPoints));
                chartRender.appendChild(barWrapper);
            });

            // As barras já estão no DOM agora, então dá pra medir a régua real
            // do .chart-bar-track (a "caixinha" onde a barra de fato desenha
            // sua altura) e usar essa régua — em pixels — pra posicionar as
            // linhas de grade/média/meta, em vez de usar % do .chart-container
            // inteiro (que é maior, por causa do número em cima e do rótulo
            // do dia embaixo de cada barra). Sem isso, uma barra em 100% e
            // uma linha em "100%" acabavam em alturas visuais diferentes.
            const trackRefEl = chartRender.querySelector('.chart-bar-track');
            const containerRect = chartRender.getBoundingClientRect();
            const trackRect = trackRefEl ? trackRefEl.getBoundingClientRect() : null;
            // Distância, em pixels, entre a base do container e a base real
            // da "régua" das barras (normalmente a altura do rótulo do dia).
            const trackBaseOffsetPx = trackRect ? Math.max(0, containerRect.bottom - trackRect.bottom) : 0;
            const trackHeightPx = trackRect ? trackRect.height : containerRect.height;

            const bottomPxParaValor = valor => `${trackBaseOffsetPx + Math.min(valor, maxTotal) / maxTotal * trackHeightPx}px`;

            [25, 50, 75].forEach(p => {
                const gridLine = document.createElement('div');
                gridLine.className = 'chart-gridline';
                gridLine.style.bottom = bottomPxParaValor((p / 100) * maxTotal);
                chartRender.appendChild(gridLine);
            });

            const avgLine = document.createElement('div');
            avgLine.className = 'chart-avg-line';
            avgLine.style.bottom = bottomPxParaValor(mediaPeriodo);
            avgLine.innerHTML = `<span class="chart-avg-label">média</span>`;
            if (currentChartViewMode !== 'pauses') {
                // Na visão de Pausas a escala do gráfico é outra (tempo pausado,
                // não tempo estudado), então a linha de "média" de estudo não
                // faz sentido nesse modo — só aparece nos outros dois.
                chartRender.appendChild(avgLine);
            }

            // Linha da meta diária configurada em Ajustes (mesma métrica que a
            // barra "Meta de hoje" usa). Só faz sentido nos modos de tempo de
            // estudo (não em Pausas) — a escala do gráfico (maxTotal, lá em
            // cima) já é calculada considerando a meta, então ela sempre cabe.
            if (goalLineDesenhada) {
                const goalLine = document.createElement('div');
                goalLine.className = 'chart-goal-line';
                goalLine.style.bottom = bottomPxParaValor(goalMs);
                goalLine.innerHTML = `<span class="chart-goal-label">meta do dia</span>`;
                chartRender.appendChild(goalLine);
            }

            let idxParaSelecionar = dataPoints.length - 1;
            if (selectedBarKey) {
                const idxEncontrado = dataPoints.findIndex(dp => keyDoPonto(dp) === selectedBarKey);
                if (idxEncontrado !== -1) idxParaSelecionar = idxEncontrado;
            }
            selecionarBarra(idxParaSelecionar, dataPoints);
        });
    }

    function keyDoPonto(dp) {
        return dp.key || (dp.keys ? dp.keys.join(',') : null);
    }

    function selecionarBarra(idx, dataPoints) {
        const wrappers = chartRender.querySelectorAll('.chart-bar-wrapper');
        wrappers.forEach((w, i) => w.classList.toggle('selected', i === idx));

        const dp = dataPoints[idx];
        selectedBarKey = keyDoPonto(dp);
        const goalMs = dailyGoalMs;

        // ---- cabeçalho: dia, data por extenso e o total ----
        let dateLine = '';
        let metaPct = 0;           // 0–100: o quanto da meta foi cumprido
        let metaOk = false;
        let metaTexto = '';
        const horasMeta = goalMs / 3600000;
        const horasMetaFmt = Number.isInteger(horasMeta) ? String(horasMeta) : horasMeta.toFixed(1).replace('.', ',');
        if (dp.key) {
            const dateObj = parseKeyToDate(dp.key);
            const porExtenso = dateObj.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });
            dateLine = porExtenso.charAt(0).toUpperCase() + porExtenso.slice(1);
            metaOk = dp.totalTime >= goalMs;
            metaPct = goalMs > 0 ? Math.min(100, Math.round((dp.totalTime / goalMs) * 100)) : 0;
            metaTexto = `${fmtTempoDetalhe(dp.totalTime, true)} de ${horasMetaFmt}h`;
        } else if (dp.keys) {
            const curto = (k) => parseKeyToDate(k).toLocaleDateString('pt-BR', { day: 'numeric', month: 'short' });
            dateLine = `Semana de ${curto(dp.keys[0])} a ${curto(dp.keys[dp.keys.length - 1])}`;
            metaOk = dp.daysMet >= Math.ceil(dp.keys.length / 2);
            metaPct = Math.round((dp.daysMet / dp.keys.length) * 100);
            metaTexto = `${dp.daysMet} de ${dp.keys.length} dias bateram a meta`;
        }

        const iconeOk = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 5 5 9-10"/></svg>';

        // Uma barra empilhada (como o Tempo de Uso do iPhone) + a legenda com os valores.
        // O comprimento da barra é o quanto da META foi cumprido (a cor divide esse trecho entre os itens): estudar
        // mais enche a barra; passou da meta, ela fecha. Na semana/mês a meta é a soma dos dias do período.
        const escalaMeta = goalMs * (dp.keys ? dp.keys.length : 1);
        const rotuloMeta = dp.keys ? `${horasMetaFmt}h × ${dp.keys.length} dias` : `${horasMetaFmt}h`;
        const blocoEmpilhado = (titulo, itens, base) => {
            const total = base > 0 ? base : 1;
            const fracMeta = base > 0 && escalaMeta > 0 ? Math.max(0.04, Math.min(1, base / escalaMeta)) : 0;
            const segmentos = itens.filter((r) => r.val > 0).map((r) =>
                `<i style="flex:${r.val};background:${r.color}" title="${r.label}: ${fmtTempoDetalhe(r.val)}"></i>`).join('');
            const legenda = itens.map((r) => `
                <li class="${r.val > 0 ? '' : 'vazio'}">
                    <span class="dd-ponto" style="background:${r.color}"></span>
                    <span class="dd-rot">${r.label}</span>
                    <span class="dd-pct">${r.val > 0 ? Math.round((r.val / total) * 100) + '%' : ''}</span>
                    <b class="dd-val">${r.val > 0 ? fmtTempoDetalhe(r.val) : '—'}</b>
                </li>`).join('');
            return `
                <section class="dd-bloco">
                    <h4 class="dd-tit">${titulo}</h4>
                    <div class="dd-pilha${base > 0 ? '' : ' dd-pilha--vazia'}" role="img" aria-label="${titulo}: ${Math.round(fracMeta * 100)}% da meta">
                        <div class="dd-pilha-cheia" style="width:${fracMeta * 100}%">${segmentos}</div>
                    </div>
                    <div class="dd-escala"><span>0</span><span>meta ${rotuloMeta}</span></div>
                    <ul class="dd-leg">${legenda}</ul>
                </section>`;
        };

        const periodos = [
            { label: 'Madrugada', val: dp.mad, color: chartPeriodColors.mad },
            { label: 'Manhã', val: dp.man, color: chartPeriodColors.man },
            { label: 'Tarde', val: dp.tar, color: chartPeriodColors.tar },
            { label: 'Noite', val: dp.noi, color: chartPeriodColors.noi },
        ];
        const atividades = [
            { label: 'Questões', val: dp.questoesMs || 0, color: '#8b5cf6' },
            { label: 'Leitura', val: dp.leituraMs || 0, color: '#f2b705' },
            { label: 'Vídeo-aula', val: dp.videoaulaMs || 0, color: '#ef4444' },
        ];
        const baseAtividade = atividades.reduce((s, r) => s + r.val, 0);

        const temEstudo = dp.totalTime > 0;
        // Sem estudo mas com pausa: o motivo mais comum é o cronômetro não estar rodando — vale dizer isso.
        const aviso = (dp.totalTime < 60000 && dp.pauseMs > 0)
            ? `<p class="dd-aviso">O cronômetro ficou pausado por ${fmtTempoDetalhe(dp.pauseMs)} e o tempo só conta com ele rodando. Se você resolveu questões nesse período, inicie o cronômetro antes.</p>`
            : (!temEstudo ? '<p class="dd-aviso dd-aviso--neutro">Nenhum tempo de estudo registrado neste período.</p>' : '');

        const pausas = (dp.pauseMs > 0 || dp.pauseCount > 0) ? `
            <section class="dd-bloco">
                <h4 class="dd-tit">Pausas</h4>
                <div class="dd-pausas">
                    <div class="dd-tile"><b>${dp.pauseMs > 0 ? fmtTempoDetalhe(dp.pauseMs) : '—'}</b><span>Tempo pausado</span></div>
                    <div class="dd-tile"><b>${dp.pauseCount || 0}</b><span>${(dp.pauseCount || 0) === 1 ? 'Pausa' : 'Pausas'}</span></div>
                </div>
            </section>` : '';

        chartDetail.innerHTML = `
            <div class="dd">
                <div class="dd-topo">
                    <div>
                        <div class="dd-dia">${dp.label}</div>
                        <div class="dd-data">${dateLine}</div>
                    </div>
                    <div class="dd-total">${fmtTempoDetalhe(dp.totalTime, true)}</div>
                </div>
                <div class="dd-meta">
                    <div class="dd-meta-topo">
                        <span class="dd-meta-tit">Meta</span>
                        <span class="dd-pilula ${metaOk ? 'ok' : 'pend'}">${metaOk ? iconeOk + 'Batida' : 'Não batida'}</span>
                    </div>
                    <div class="dd-barra" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${metaPct}"><i style="width:${metaPct}%"></i></div>
                    <div class="dd-meta-txt">${metaTexto}</div>
                </div>
                ${aviso}
                ${temEstudo ? blocoEmpilhado('Por período do dia', periodos, dp.totalTime) : ''}
                ${baseAtividade > 0 ? blocoEmpilhado('Por atividade', atividades, baseAtividade) : ''}
                ${pausas}
            </div>
        `;
    }

    // "0m" para 20 segundos confundia (parecia que nada foi registrado): abaixo de 1 min mostra "< 1 min".
    function fmtTempoDetalhe(ms, zeroComoTraco) {
        if (!ms || ms <= 0) return zeroComoTraco ? '0m' : '—';
        if (ms < 60000) return '< 1 min';
        return formatHoursMinutes(ms);
    }

    function renderProductivity(animate = true) {
        // Mesma ideia da aba de Distrações: a leitura de PDF e as aulas em
        // vídeo respeitam o filtro Diário/Semanal/Mensal desta aba, então
        // acompanham o render dela.
        renderPdfs(animate);
        renderAulas(animate);
        renderRadar();

        chrome.storage.local.get(['hourlyHistory'], (result) => {
            const hourlyHistory = result.hourlyHistory || {};

            let dateKeys = [];
            const selectedDate = prodDatePicker.value ? new Date(prodDatePicker.value + 'T12:00:00') : new Date();

            if (prodDatePicker.value) {
                dateKeys = [prodDatePicker.value];
            } else {
                dateKeys = getDateKeysForPeriod(currentProdPeriod, selectedDate);
            }

            const porHora = {};
            dateKeys.forEach(dateKey => {
                const diaTempo = hourlyHistory[dateKey] || {};
                Object.entries(diaTempo).forEach(([hora, ms]) => {
                    if (!porHora[hora]) porHora[hora] = 0;
                    porHora[hora] += ms;
                });
            });

            productivityRender.innerHTML = '';
            productivityRender.classList.toggle('animate-in', animate);
            const horasOrdenadas = Object.keys(porHora).map(Number).sort((a, b) => a - b);

            const productivityStats = document.getElementById('productivity-stats');
            const totalPeriodoProd = Object.values(porHora).reduce((s, v) => s + v, 0);
            let pMad = 0, pMan = 0, pTar = 0, pNoi = 0;
            horasOrdenadas.forEach(h => {
                const v = porHora[h];
                if (h >= 0 && h < 6) pMad += v;
                else if (h >= 6 && h < 12) pMan += v;
                else if (h >= 12 && h < 18) pTar += v;
                else pNoi += v;
            });
            const periodos = [
                { label: 'Madrugada', val: pMad },
                { label: 'Manhã', val: pMan },
                { label: 'Tarde', val: pTar },
                { label: 'Noite', val: pNoi }
            ];
            const periodoTop = periodos.reduce((a, b) => (b.val > a.val ? b : a), periodos[0]);

            if (productivityStats) {
                productivityStats.innerHTML = `
                    <div class="distraction-stat">
                        <span class="distraction-stat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg></span>
                        <span class="distraction-stat-label">Total no período</span>
                        <span class="distraction-stat-value">${totalPeriodoProd > 0 ? formatHoursMinutes(totalPeriodoProd) : '—'}</span>
                    </div>
                    <div class="distraction-stat">
                        <span class="distraction-stat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 2 3 14h9l-1 8 10-12h-9l1-8Z"/></svg></span>
                        <span class="distraction-stat-label">Horário de pico</span>
                        <span class="distraction-stat-value">${melhorHoraSafe(horasOrdenadas, porHora)}</span>
                    </div>
                    <div class="distraction-stat">
                        <span class="distraction-stat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.2" fill="currentColor" stroke="none"/></svg></span>
                        <span class="distraction-stat-label">Período mais forte</span>
                        <span class="distraction-stat-value">${periodoTop.val > 0 ? periodoTop.label : '—'}</span>
                    </div>
                `;
            }

            if (horasOrdenadas.length === 0) {
                productivityRender.innerHTML = `
                    <div class="empty-state" style="margin:auto;">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><path d="M7 15v3M12 10v8M17 6v12"/></svg>
                        Ainda sem dados de horário neste período.
                    </div>`;
                productivityInsight.innerHTML = '';
                return;
            }

            const maxTempo = Math.max(...horasOrdenadas.map(h => porHora[h]), 1);
            let melhorHora = null, melhorTempo = -1;

            horasOrdenadas.forEach((hora) => {
                if (porHora[hora] > melhorTempo) {
                    melhorTempo = porHora[hora];
                    melhorHora = hora;
                }
            });

            // ANTES: uma barra por hora, com rótulo em cima de cada uma. Como
            // um dia pode ter 15 horas com registro, virava uma fileira longa
            // que só cabia com barra de rolagem horizontal — e barra de
            // rolagem dentro de um popup é onde a informação vai morrer.
            //
            // AGORA: curva contínua. Horário é uma grandeza CONTÍNUA (as 15h
            // vêm logo depois das 14h), e curva é a forma certa pra isso —
            // barras separadas sugerem categorias independentes, que horas
            // não são. De quebra, as 24 horas cabem sem rolagem e o formato
            // do dia aparece de relance: onde sobe, onde afunda.
            const serie = horasOrdenadas.map((hora) => ({
                rotulo: String(hora).padStart(2, '0') + 'h',
                valor: porHora[hora]
            }));

            if (self.CBGraficos && serie.length >= 2) {
                productivityRender.innerHTML = self.CBGraficos.cbAreaSuave(serie, {
                    altura: 160,
                    titulo: 'Tempo de estudo por horário do dia',
                    formatar: (ms) => {
                        const min = Math.round(ms / 60000);
                        if (min < 60) return min + 'm';
                        const h = min / 60;
                        return (h % 1 === 0 ? h : h.toFixed(1)) + 'h';
                    }
                });
                productivityRender.classList.add('cb-grafico-caixa');
            } else {
                // Uma hora só não faz curva. Nesse caso, o número direto diz
                // mais do que qualquer desenho.
                productivityRender.classList.remove('cb-grafico-caixa');
                productivityRender.innerHTML = serie.length === 1
                    ? `<div class="cb-prod-unico">
                         <strong>${formatHoursMinutes(serie[0].valor)}</strong>
                         <span>às ${cbEscapar(serie[0].rotulo)}</span>
                       </div>`
                    : '';
            }

            if (melhorHora !== null) {
                productivityInsight.innerHTML = `
                    <div class="insight">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18h6"/><path d="M10 22h4"/><path d="M12 2a6 6 0 0 0-4 10.5c.6.5 1 1.3 1 2.5h6c0-1.2.4-2 1-2.5A6 6 0 0 0 12 2Z"/></svg>
                        Você mais estuda às ${String(melhorHora).padStart(2, '0')}h — considere reservar esse horário todo dia.
                    </div>`;
            } else {
                productivityInsight.innerHTML = '';
            }
        });
    }

    function melhorHoraSafe(horasOrdenadas, porHora) {
        if (!horasOrdenadas.length) return '—';
        let melhor = horasOrdenadas[0], melhorVal = -1;
        horasOrdenadas.forEach(h => { if (porHora[h] > melhorVal) { melhorVal = porHora[h]; melhor = h; } });
        return `${String(melhor).padStart(2, '0')}h`;
    }

    // "4h 38m"; abaixo de 1 min mostra segundos ("45s"), para a lista não mostrar "0m"
    function distTempo(ms) {
        return ms < 60000 ? `${Math.max(1, Math.round(ms / 1000))}s` : formatHoursMinutes(ms);
    }

    // O ícone do site vem do serviço de favicons do Google. Se não carregar (páginas internas do navegador,
    // domínios sem ícone), vira um quadradinho com a inicial, em vez de um buraco quebrado.
    function distLigarFavicons(raiz) {
        raiz.querySelectorAll('img.site-favicon').forEach((img) => {
            const trocar = () => {
                const letra = document.createElement('span');
                letra.className = 'site-favicon site-favicon--letra';
                letra.textContent = String(img.dataset.site || '?').replace(/^www\./, '').charAt(0).toUpperCase();
                img.replaceWith(letra);
            };
            img.addEventListener('error', trocar, { once: true });
        });
    }
    const distFavicon = (site) => `<img class="site-favicon" data-site="${cbEscapar(site)}" src="https://www.google.com/s2/favicons?sz=64&domain=${encodeURIComponent(site)}" alt="">`;

    function distRotuloPeriodo() {
        if (distDatePicker.value) {
            const [a, m, d] = distDatePicker.value.split('-');
            return `${d}/${m}/${a}`;
        }
        return { today: 'Hoje', week: 'Últimos 7 dias', month: 'Últimos 30 dias', semester: 'Últimos 6 meses' }[currentDistPeriod] || 'Período';
    }

    function renderDistractions(animate = true) {
        // Os apps do PC seguem o MESMO filtro de período/data desta aba, então
        // basta pendurar aqui: qualquer coisa que já redesenhava as distrações
        // passa a redesenhar os apps junto, sem eu ter que caçar cada botão.
        renderApps(animate);

        chrome.storage.local.get(['siteHistory', 'siteHourlyHistory'], (result) => {
            const siteHistory = result.siteHistory || {};
            const siteHourly = result.siteHourlyHistory || {};

            let dateKeys = [];
            const selectedDate = distDatePicker.value ? new Date(distDatePicker.value + 'T12:00:00') : new Date();

            if (distDatePicker.value) {
                dateKeys = [distDatePicker.value];
            } else {
                const dias = currentDistPeriod === 'today' ? 1
                           : (currentDistPeriod === 'week' ? 7
                           : (currentDistPeriod === 'semester' ? 182 : 30));
                for (let i = 0; i < dias; i++) {
                    let d = new Date(selectedDate);
                    d.setDate(selectedDate.getDate() - i);
                    dateKeys.push(d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'));
                }
            }

            // Agrega os sites de todos os dias do período
            const sitesAgregados = {};
            let totalDistractionTime = 0;
            dateKeys.forEach(dateKey => {
                Object.entries(siteHistory[dateKey] || {}).forEach(([site, timeMs]) => {
                    sitesAgregados[site] = (sitesAgregados[site] || 0) + timeMs;
                    totalDistractionTime += timeMs;
                });
            });

            // Horas do dia (0–23): vêm de siteHourlyHistory, que o fundo grava a cada tick. Dias anteriores a esse
            // registro não têm detalhe por hora (só o total por site), então o gráfico avisa quando for parcial.
            const horaTotais = new Array(24).fill(0);
            let msComHora = 0;
            dateKeys.forEach((k) => {
                const doDia = siteHourly[k] || {};
                Object.keys(doDia).forEach((h) => {
                    const n = Number(h);
                    const ms = Number(doDia[h]) || 0;
                    if (n >= 0 && n < 24 && ms > 0) { horaTotais[n] += ms; msComHora += ms; }
                });
            });

            const sortedSites = Object.entries(sitesAgregados).sort((a, b) => b[1] - a[1]);
            const topSite = sortedSites.length > 0 ? sortedSites[0] : null;

            // ------------------------------------------------------------ resumo
            distractionSummary.innerHTML = `
                <div class="distraction-summary-grid dist-resumo${animate ? ' animate-in' : ''}">
                    <div class="dist-hero">
                        <span class="dist-hero-rot">Tempo em sites · ${cbEscapar(distRotuloPeriodo())}</span>
                        <b class="dist-hero-num">${formatHoursMinutes(totalDistractionTime)}</b>
                    </div>
                    <div class="dist-tile">
                        <span>Sites acessados</span>
                        <b>${sortedSites.length}</b>
                    </div>
                    <div class="dist-tile">
                        <span>Maior distração</span>
                        <b title="${topSite ? cbEscapar(topSite[0]) : ''}">${topSite ? cbEscapar(topSite[0]) : '—'}</b>
                        ${topSite ? `<small>${formatHoursMinutes(topSite[1])}</small>` : ''}
                    </div>
                </div>
            `;

            // ------------------------------------------------- sites mais acessados
            distractionChartRender.innerHTML = '';
            distractionChartRender.classList.toggle('animate-in', animate);
            if (sortedSites.length === 0) {
                distractionChartRender.innerHTML = `
                    <div class="empty-state">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="m8.5 12.5 2.2 2.2 4.8-4.8"/></svg>
                        Nenhuma distração registrada neste período. Foco total!
                    </div>`;
            } else {
                const maxSiteTime = Math.max(...sortedSites.map(s => s[1]), 1);
                sortedSites.slice(0, 8).forEach(([site, timeMs], idx) => {
                    const pct = Math.max(2, (timeMs / maxSiteTime) * 100);
                    const row = document.createElement('div');
                    row.className = 'distraction-chart-row dist-site';
                    row.style.setProperty('--i', idx);
                    row.innerHTML = `
                        ${distFavicon(site)}
                        <div class="dist-site-corpo">
                            <div class="dist-site-linha">
                                <span class="dist-site-nome" title="${cbEscapar(site)}">${cbEscapar(site)}</span>
                                <span class="dist-site-tempo">${distTempo(timeMs)}</span>
                            </div>
                            <div class="distraction-chart-bar-bg">
                                <div class="distraction-chart-bar" style="width: ${pct}%;"></div>
                            </div>
                        </div>
                    `;
                    distractionChartRender.appendChild(row);
                });
                distLigarFavicons(distractionChartRender);
            }

            // ------------------------------------------------------ horários de uso
            distractionHourRender.innerHTML = '';
            distractionHourRender.classList.toggle('animate-in', animate);
            if (msComHora <= 0) {
                distractionHourRender.innerHTML = `
                    <div class="empty-state">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>
                        ${totalDistractionTime > 0
                            ? 'O horário de uso dos sites passou a ser registrado agora. Volte mais tarde para ver em que horas você mais se distrai.'
                            : 'Sem dados de horário para este período.'}
                    </div>`;
            } else {
                const maxHora = Math.max(...horaTotais, 1);
                const pico = horaTotais.indexOf(maxHora);
                const colunas = horaTotais.map((ms, h) => {
                    const hh = String(h).padStart(2, '0');
                    if (ms <= 0) return `<div class="distraction-hour-bar-wrapper dh-col" title="${hh}h: sem uso"><i class="dh-b dh-b--vazio"></i></div>`;
                    const altura = Math.max(7, (ms / maxHora) * 100);
                    const opac = (0.5 + 0.5 * (ms / maxHora)).toFixed(2);
                    return `<div class="distraction-hour-bar-wrapper dh-col" style="--i:${h}" title="${hh}h: ${distTempo(ms)}"><i class="distraction-hour-bar dh-b" style="height:${altura}%; opacity:${opac};"></i></div>`;
                }).join('');
                const eixo = [0, 6, 12, 18].map((h) => `<span style="left:${(h / 24) * 100}%">${h}h</span>`).join('');
                const parcial = msComHora < totalDistractionTime * 0.9;
                distractionHourRender.innerHTML = `
                    <div class="dh" role="img" aria-label="Uso de sites por hora do dia. Pico às ${String(pico).padStart(2, '0')}h, com ${distTempo(maxHora)}.">
                        <div class="dh-topo">
                            <span class="dh-pico">Pico às <b>${String(pico).padStart(2, '0')}h</b></span>
                            <span class="dh-pico-val">${distTempo(maxHora)}</span>
                        </div>
                        <div class="dh-barras">${colunas}</div>
                        <div class="dh-eixo" aria-hidden="true">${eixo}</div>
                        ${parcial ? '<p class="dh-nota">O horário só é registrado a partir desta versão: o tempo de dias anteriores aparece nos totais, mas não neste gráfico.</p>' : ''}
                    </div>`;
            }

            // ------------------------------------------- histórico do dia selecionado
            const displayDate = distDatePicker.value || getTodayKey();
            const sitesDisplay = siteHistory[displayDate] || {};
            const sortedDisplay = Object.entries(sitesDisplay).sort((a, b) => b[1] - a[1]);

            distractionRender.innerHTML = '';
            if (sortedDisplay.length === 0) {
                distractionRender.innerHTML = `
                    <div class="empty-state">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="m8.5 12.5 2.2 2.2 4.8-4.8"/></svg>
                        Nenhuma distração registrada ${distDatePicker.value ? 'nesta data' : 'hoje'}. Foco total.
                    </div>`;
                return;
            }

            sortedDisplay.forEach(([site, timeMs]) => {
                const item = document.createElement('div');
                item.className = 'distraction-item';
                item.innerHTML = `
                    <span class="site-info">
                        ${distFavicon(site)}
                        <span class="site-name" title="${cbEscapar(site)}">${cbEscapar(site)}</span>
                    </span>
                    <span class="site-time">${distTempo(timeMs)}</span>
                `;
                distractionRender.appendChild(item);
            });
            distLigarFavicons(distractionRender);
        });
    }

    // ========================================================================
    //        APPS DO PC E LEITURA DE PDF (vindos do monitor do Windows)
    // ========================================================================
    // Estes dois blocos vivem escondidos e só aparecem quando existe dado de
    // verdade. Se a pessoa não instalou o monitor do Windows, as abas ficam
    // exatamente como sempre foram — sem caixa vazia, sem propaganda de
    // "instale o complemento". Quem não tem, não vê que falta.
    //
    // As duas fontes:
    //   appUsageHistory[data][processo] = { total, titulos: { titulo: ms } }
    //   pdfHistory[data][arquivo]       = { app, tempo, totalPaginas, paginas: { n: ms } }
    // Ambas escritas por dados-config/sentinela-nativa.js.

    // Guarda quais apps estão com a lista de títulos aberta, pra não fechar
    // tudo a cada re-render (o render roda de novo a cada 20s quando chega
    // dado novo do monitor — perder a expansão no meio da leitura irrita).
    const cbAppsExpandidos = new Set();

    function cbEscapar(txt) {
        return String(txt == null ? '' : txt)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    }

    function cbChavesDeDataDist() {
        if (distDatePicker && distDatePicker.value) return [distDatePicker.value];
        const ref = new Date();
        const dias = currentDistPeriod === 'today' ? 1
                           : (currentDistPeriod === 'week' ? 7
                           : (currentDistPeriod === 'semester' ? 182 : 30));
        const keys = [];
        for (let i = 0; i < dias; i++) {
            const d = new Date(ref);
            d.setDate(ref.getDate() - i);
            keys.push(d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'));
        }
        return keys;
    }

    function cbChavesDeDataProd() {
        if (prodDatePicker && prodDatePicker.value) return [prodDatePicker.value];
        return getDateKeysForPeriod(currentProdPeriod, new Date());
    }

    // ================== MATÉRIA DE UM PDF: A LISTA É DO USUÁRIO =============
    // Os PDFs que a pessoa tem na máquina não têm nada a ver com uma lista
    // fixa de matérias que eu tenha inventado — são os arquivos DELA, do
    // concurso DELA. Então a lista de matérias vem de onde ela já escreveu
    // as próprias matérias, em três lugares que já existem no app:
    //
    //   1. cbCronogramaPorData / cbCronogramaHoje -> o campo "matéria" dos
    //      blocos do cronograma, que ela digita livremente;
    //   2. questoesDisciplinas.itens -> as disciplinas que vieram do
    //      QConcursos, ou seja, o edital de verdade dela;
    //   3. pdfMateriaOverride -> matérias que ela já atribuiu a outros PDFs.
    //
    // Nada aqui é chumbado. Se ela estuda para um concurso de Nutrição, a
    // lista é de Nutrição. E sempre existe a opção de digitar uma nova.
    function cbColetarMateriasDoUsuario(callback) {
        chrome.storage.local.get(
            ['cbCronogramaPorData', 'cbCronogramaHoje', 'questoesDisciplinas', 'pdfMateriaOverride'],
            (res) => {
                const vistas = new Map(); // normalizada -> grafia original

                const adicionar = (nome) => {
                    const limpo = String(nome || '').trim();
                    if (limpo.length < 2) return;
                    const chave = limpo.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
                    if (!vistas.has(chave)) vistas.set(chave, limpo);
                };

                const porData = res.cbCronogramaPorData || {};
                Object.keys(porData).forEach((d) => {
                    (porData[d] || []).forEach((bloco) => adicionar(bloco && bloco.materia));
                });
                (res.cbCronogramaHoje || []).forEach((bloco) => adicionar(bloco && bloco.materia));

                const itens = (res.questoesDisciplinas && res.questoesDisciplinas.itens) || [];
                itens.forEach((it) => adicionar(it && (it.materia || it.nome)));

                const overrides = res.pdfMateriaOverride || {};
                Object.keys(overrides).forEach((k) => adicionar(overrides[k]));

                callback(Array.from(vistas.values()).sort((a, b) => a.localeCompare(b, 'pt-BR')));
            }
        );
    }

    function cbNormalizarTexto(txt) {
        return String(txt || '')
            .toLowerCase()
            .normalize('NFD').replace(/[̀-ͯ]/g, '')
            .replace(/[^a-z0-9]+/g, ' ')
            .trim();
    }

    // Abreviações e números de lei que aparecem em nome de arquivo. Isto NÃO
    // é uma lista de matérias: cada entrada só vira uma palavra extra no nome
    // do arquivo, pra ele conseguir casar com a matéria que a PESSOA escreveu.
    // "CF88.pdf" ganha a palavra "constituicao" e passa a casar com o
    // "Direito Constitucional" dela — mas se ela não tiver essa matéria,
    // nada é inventado.
    const CB_PISTAS_ARQUIVO = [
        [/\bcf\s*88\b|\bcf\b|\bconstituic/, 'constituicao constitucional'],
        [/\b8112\b|\b8429\b|\b9784\b|\b14133\b|\b8666\b|licitac|improbidade|servidor/, 'administrativo administracao'],
        [/\bctn\b|\btributari/, 'tributario'],
        [/\bclt\b/, 'trabalho trabalhista'],
        [/\bcpc\b/, 'processual civil'],
        [/\bcpp\b/, 'processual penal'],
        [/\bcdc\b|\b8078\b/, 'consumidor'],
        [/\blrf\b|\b4320\b|\b101\s*2000\b/, 'financeiro orcamentario'],
        [/\b8080\b|\bsus\b/, 'saude'],
        [/\b8069\b|\beca\b/, 'crianca adolescente'],
        [/\b10257\b|estatuto da cidade/, 'urbanistico urbanismo'],
        [/\bcodigo penal\b|\bcp\b/, 'penal'],
        [/\bcodigo civil\b|\bcc\b/, 'civil'],
        [/portugues|gramatica|redacao|crase/, 'portuguesa portugues'],
        [/\brlm\b|raciocinio/, 'raciocinio logico'],
        [/informatica|excel|windows/, 'informatica']
    ];

    // Casa por PREFIXO de palavra, não por igualdade: "constitucional" e
    // "constituicao" são a mesma ideia escrita diferente, e "administrativo"
    // x "administracao" idem.
    //
    // Seis caracteres, não oito: com oito, "processual" (da matéria) não casava
    // com "processo" (do nome do arquivo) — divergem justamente na oitava letra
    // —, e "Processo Civil.pdf" ia parar em "Direito Civil". Com seis, "proces"
    // resolve, e continua cobrindo admini/consti/tribut/portug/munici/nutric
    // sem misturar matérias diferentes.
    const CB_PREFIXO_MINIMO = 6;

    function cbPalavrasCasam(palavraMateria, palavrasArquivo) {
        return palavrasArquivo.some((pa) => {
            const n = Math.min(palavraMateria.length, pa.length);
            if (n < 4) return palavraMateria === pa;
            const prefixo = Math.min(CB_PREFIXO_MINIMO, n);
            return palavraMateria.slice(0, prefixo) === pa.slice(0, prefixo);
        });
    }

    // Palavras que aparecem em quase toda matéria de concurso e por isso não
    // servem pra distinguir nada. Sem isso, "Direito Penal" casaria com
    // qualquer arquivo que tivesse a palavra "direito" no nome — e "Língua
    // Portuguesa" nunca casaria com "resumo portugues.pdf", porque a palavra
    // "língua" não aparece em nome de arquivo nenhum.
    const CB_PALAVRAS_VAZIAS = new Set([
        'direito', 'direitos', 'legislacao', 'lei', 'leis', 'lingua', 'idioma',
        'nocoes', 'conhecimentos', 'basico', 'basicos', 'geral', 'gerais',
        'de', 'do', 'da', 'dos', 'das', 'e', 'em', 'para', 'sao', 'com'
    ]);

    function cbAdivinharMateria(nomeArquivo, materiasDoUsuario) {
        if (!materiasDoUsuario || materiasDoUsuario.length === 0) return null;

        let texto = cbNormalizarTexto(nomeArquivo.replace(/\.pdf$/i, ''));
        CB_PISTAS_ARQUIVO.forEach(([padrao, extras]) => {
            if (padrao.test(texto)) texto += ' ' + extras;
        });
        const palavrasArquivo = texto.split(' ').filter(Boolean);

        // ANTES eu exigia que TODAS as palavras da matéria aparecessem no nome
        // do arquivo. Era rígido demais e errava em casos óbvios: "Nutrição e
        // Saúde Pública" nunca casava com "Manual de Nutricao Clinica.pdf",
        // porque faltavam "saúde" e "pública". Agora conto QUANTAS palavras
        // casaram e fico com a matéria de maior pontuação — o que, de quebra,
        // resolve sozinho a disputa entre "Direito Civil" e "Direito
        // Processual Civil": para um arquivo de CPC, a segunda casa duas
        // palavras e a primeira só uma, então a mais específica ganha.
        let melhor = null;
        let melhorCasadas = 0;
        let melhorProporcao = 0;

        materiasDoUsuario.forEach((materia) => {
            const palavras = cbNormalizarTexto(materia).split(' ')
                .filter((p) => p.length >= 4 && !CB_PALAVRAS_VAZIAS.has(p));
            if (palavras.length === 0) return;

            const casadas = palavras.filter((p) => cbPalavrasCasam(p, palavrasArquivo)).length;
            if (casadas === 0) return;
            const proporcao = casadas / palavras.length;

            // O desempate leva dois critérios, nesta ordem, e os dois são
            // necessários — testei com um só e errava:
            //
            //   1º) mais palavras casadas. "CPC_2015.pdf" casa "processual" e
            //       "civil" (2) contra só "civil" (1), então a matéria mais
            //       específica ganha, que é o certo.
            //
            //   2º) empatou no número, vence quem casou a MAIOR PROPORÇÃO do
            //       próprio nome. "Codigo Civil.pdf" casa 1 palavra nas duas,
            //       mas é 1 de 1 em "Direito Civil" e 1 de 2 em "Direito
            //       Processual Civil" — ou seja, a segunda ficou com metade do
            //       nome sem confirmação. Antes eu desempatava pelo nome mais
            //       longo e justamente este caso saía errado.
            if (casadas > melhorCasadas ||
                (casadas === melhorCasadas && proporcao > melhorProporcao)) {
                melhorCasadas = casadas;
                melhorProporcao = proporcao;
                melhor = materia;
            }
        });

        return melhor;
    }

    // ========================================================================
    //           AULAS EM VÍDEO NO YOUTUBE (qualquer navegador)
    // ========================================================================
    // Não precisou de nada novo do lado do Windows: o monitor já grava o
    // título da janela em primeiro plano, e o título de uma aba do YouTube é
    // "Aula 03 - Direito Civil - YouTube" (o nome do navegador já sai na
    // normalização do monitor). Ou seja, o dado já estava aqui — o que faltava
    // era interpretá-lo. Isso também vale para trás: qualquer tempo que o
    // monitor já tenha juntado entra nesta conta assim que a extensão atualiza.
    //
    // LIMITAÇÃO QUE VALE DIZER: isso mede o vídeo em PRIMEIRO PLANO, não o
    // vídeo tocando. Aula rodando numa aba de fundo enquanto você lê um PDF
    // não é contada aqui — e, para tempo de estudo, isso é mais certo do que
    // errado: conta o que você assistiu, não o que ficou tocando sozinho.

    function cbEhTituloYoutube(titulo) {
        // O YouTube Music fica de fora de propósito: é música, não aula.
        if (/(?:^|\s)[-–—]\s*youtube\s+music\s*$/i.test(titulo)) return false;
        return /(?:^|\s)[-–—]\s*youtube\s*$/i.test(titulo);
    }

    function cbNomeDoVideo(titulo) {
        return titulo.replace(/\s*[-–—]\s*youtube\s*$/i, '').trim();
    }

    // Palavras que praticamente só aparecem em conteúdo de estudo. Servem pra
    // pegar a aula cujo título não cita a matéria ("Aula 12 — continuação").
    const CB_SINAIS_DE_AULA = new RegExp([
        'aula', 'videoaula', 'video aula', 'curso', 'modulo', 'apostila',
        'revisao', 'resumo', 'teoria', 'questoes', 'comentad', 'resolucao',
        'concurso', 'professor', 'prof\\.', 'esquematizad', 'mapa mental',
        'simulado', 'correcao', 'maratona', 'intensivao', 'reta final',
        'edital', 'banca', 'cebraspe', 'cespe', 'vunesp', 'fgv', 'fcc',
        'jurisprudencia', 'doutrina', 'sumula', 'art\\s*\\.?\\s*\\d',
        'lei\\s*n', 'oab', 'enem', 'vestibular', 'gabarito', 'flashcard'
    ].join('|'), 'i');

    // Sinais fortes de que NÃO é aula, mesmo que o título cite uma matéria.
    // Ex.: um gameplay chamado "GTA — advogado de defesa" não é Direito Penal.
    const CB_SINAIS_DE_NAO_AULA = new RegExp([
        'gameplay', 'trailer', 'clipe oficial', 'official music video',
        'official video', 'videoclipe', 'reaction', 'react ', 'unboxing',
        'vlog', 'melhores momentos', 'compilacao', 'lyric', 'cover ',
        'ep\\s*\\.?\\s*\\d+\\s*[-–—]', 'temporada \\d', 'shorts'
    ].join('|'), 'i');

    // Decide o que é cada vídeo. Devolve sempre um motivo, porque é isso que
    // permite explicar a decisão na tela em vez de pedir fé no palpite.
    function cbClassificarVideo(nomeVideo, materiasDoUsuario, overrides) {
        const marcado = overrides && overrides[nomeVideo];
        if (marcado === '__nao_aula__') {
            return { ehAula: false, materia: null, motivo: 'você marcou que não é aula' };
        }
        if (marcado) {
            return { ehAula: true, materia: marcado, motivo: 'matéria definida por você', manual: true };
        }

        const texto = cbNormalizarTexto(nomeVideo);
        const materia = cbAdivinharMateria(nomeVideo, materiasDoUsuario);
        const temSinalDeAula = CB_SINAIS_DE_AULA.test(texto);
        const temSinalContrario = CB_SINAIS_DE_NAO_AULA.test(texto);

        // Casou com uma matéria SUA: é o sinal mais forte que existe, porque a
        // lista de matérias é do seu edital. Só um sinal contrário bem
        // explícito derruba isso.
        if (materia && !temSinalContrario) {
            return { ehAula: true, materia, motivo: 'o título cita "' + materia + '"' };
        }
        // Sem matéria, mas com cara de aula: entra como aula a classificar, em
        // vez de sumir. Você atribui a matéria num clique.
        if (temSinalDeAula && !temSinalContrario) {
            return { ehAula: true, materia: null, motivo: 'o título tem cara de aula, mas não diz a matéria' };
        }
        return { ehAula: false, materia: null, motivo: 'não parece aula' };
    }

    // Varre os títulos de janela já coletados e devolve os vídeos do YouTube
    // do período, com tempo somado. O mesmo vídeo assistido em dias
    // diferentes, ou em navegadores diferentes, vira uma linha só.
    function cbColetarVideos(appUsageHistory, chavesDeData) {
        const porVideo = {};
        let msYoutubeTotal = 0;

        chavesDeData.forEach((data) => {
            const doDia = appUsageHistory[data];
            if (!doDia) return;
            Object.keys(doDia).forEach((proc) => {
                const titulos = (doDia[proc] && doDia[proc].titulos) || {};
                Object.keys(titulos).forEach((titulo) => {
                    if (!cbEhTituloYoutube(titulo)) return;
                    const ms = Number(titulos[titulo]) || 0;
                    if (ms <= 0) return;
                    msYoutubeTotal += ms;
                    const nome = cbNomeDoVideo(titulo);
                    if (!nome) return;
                    if (!porVideo[nome]) porVideo[nome] = { nome, ms: 0, apps: new Set() };
                    porVideo[nome].ms += ms;
                    porVideo[nome].apps.add(proc);
                });
            });
        });

        return { videos: Object.values(porVideo), msYoutubeTotal };
    }

    // ------------------------------------------------------------- APPS DO PC
    function renderApps(animate = true) {
        const bloco = document.getElementById('cb-apps-bloco');
        const resumoEl = document.getElementById('cb-apps-resumo');
        const listaEl = document.getElementById('cb-apps-render');
        if (!bloco || !resumoEl || !listaEl) return;

        chrome.storage.local.get(
            ['appUsageHistory', 'appCategorias', 'cbSentinelaConectada', 'videoMateriaOverride'],
            (res) => {
          cbColetarMateriasDoUsuario((materiasDoUsuario) => {
            const historico = res.appUsageHistory || {};
            const overrides = res.appCategorias || {};
            const videoOverrides = res.videoMateriaOverride || {};
            const Classif = self.CBClassificacaoApps;

            // Junta todos os dias do período num só mapa por processo.
            const porApp = {};
            cbChavesDeDataDist().forEach((data) => {
                const doDia = historico[data];
                if (!doDia) return;
                Object.keys(doDia).forEach((proc) => {
                    const reg = doDia[proc] || {};
                    if (!porApp[proc]) porApp[proc] = { total: 0, titulos: {} };
                    porApp[proc].total += Number(reg.total) || 0;
                    const titulos = reg.titulos || {};
                    Object.keys(titulos).forEach((t) => {
                        porApp[proc].titulos[t] = (porApp[proc].titulos[t] || 0) + (Number(titulos[t]) || 0);
                    });
                });
            });

            const ordenados = Object.keys(porApp)
                .map((proc) => ({
                    proc,
                    total: porApp[proc].total,
                    titulos: porApp[proc].titulos,
                    nome: Classif ? Classif.nomeAmigavelApp(proc) : proc,
                    categoria: Classif ? Classif.classificarApp(proc, overrides) : 'neutro'
                }))
                .filter((a) => a.total >= 20000) // menos de 20s é ruído de alt-tab
                .sort((a, b) => b.total - a.total);

            if (ordenados.length === 0) {
                // Sem dado de app, existem DOIS motivos muito diferentes, e
                // esconder a seção nos dois casos foi um erro meu de desenho:
                // a pessoa não tinha como distinguir "não instalei" de
                // "instalei e não funciona". Agora a seção fala.
                //
                // "Conectado" aqui quer dizer que o sentinela-host.exe
                // respondeu — o que NÃO garante que o monitor-total.ps1 esteja
                // rodando. São duas peças separadas, e é justamente essa a
                // diferença que a mensagem abaixo ajuda a enxergar.
                const temAlgumDado = Object.keys(historico).length > 0;
                if (res.cbSentinelaConectada || temAlgumDado) {
                    bloco.style.display = '';
                    resumoEl.innerHTML = '';
                    listaEl.innerHTML = `
                        <div class="empty-state">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg>
                            A ponte com o Windows respondeu, mas o monitor ainda não mandou nada.<br>
                            Rode <strong>INSTALAR-MONITOR-TOTAL.bat</strong> e espere uns 40 segundos.
                        </div>`;
                } else {
                    bloco.style.display = 'none';
                }
                return;
            }
            bloco.style.display = '';

            // ------------------------------------------------------- resumo
            let msEstudo = 0, msDistracao = 0, msNeutro = 0;
            ordenados.forEach((a) => {
                if (a.categoria === 'estudo') msEstudo += a.total;
                else if (a.categoria === 'distracao') msDistracao += a.total;
                else msNeutro += a.total;
            });
            const msTotal = msEstudo + msDistracao + msNeutro;
            const maiorDistracao = ordenados.find((a) => a.categoria === 'distracao');

            resumoEl.innerHTML = `
                <div class="distraction-summary-grid dist-resumo">
                    <div class="dist-hero">
                        <span class="dist-hero-rot">Tempo no PC · ${cbEscapar(distRotuloPeriodo())}</span>
                        <b class="dist-hero-num">${formatHoursMinutes(msTotal)}</b>
                    </div>
                    <div class="dist-tile">
                        <span>Em distração</span>
                        <b>${msDistracao > 0 ? formatHoursMinutes(msDistracao) : '—'}</b>
                    </div>
                    <div class="dist-tile">
                        <span>Maior vilão</span>
                        <b title="${maiorDistracao ? cbEscapar(maiorDistracao.nome) : ''}">${maiorDistracao ? cbEscapar(maiorDistracao.nome) : '—'}</b>
                        ${maiorDistracao ? `<small>${formatHoursMinutes(maiorDistracao.total)}</small>` : ''}
                    </div>
                </div>
            `;

            // -------------------------------------------------------- lista
            const maior = Math.max(ordenados[0].total, 1);
            listaEl.innerHTML = '';
            listaEl.classList.toggle('animate-in', animate);

            ordenados.slice(0, 15).forEach((app, idx) => {
                const pct = (app.total / maior) * 100;
                const aberto = cbAppsExpandidos.has(app.proc);

                const topTitulos = Object.keys(app.titulos)
                    .map((t) => ({ t, ms: app.titulos[t] }))
                    .sort((a, b) => b.ms - a.ms)
                    .slice(0, 6);

                // Quanto do tempo deste navegador foi aula reconhecida. Sem
                // isso, a mesma hora apareceria como "distração" aqui e como
                // "estudo" na aba de Produtividade, e os dois números se
                // contradiriam na cara da pessoa sem nenhuma explicação.
                let msAulasNoApp = 0;
                if (Classif && Classif.ehNavegador(app.proc)) {
                    Object.keys(app.titulos).forEach((t) => {
                        if (!cbEhTituloYoutube(t)) return;
                        const c = cbClassificarVideo(cbNomeDoVideo(t), materiasDoUsuario, videoOverrides);
                        if (c.ehAula) msAulasNoApp += app.titulos[t];
                    });
                }

                const linha = document.createElement('div');
                linha.className = 'cb-app-row cat-' + app.categoria + (aberto ? ' aberto' : '');
                linha.style.setProperty('--i', idx);
                linha.innerHTML = `
                    <div class="cb-app-head" data-proc="${cbEscapar(app.proc)}" role="button" tabindex="0"
                         title="Clique para ver as janelas mais usadas deste programa">
                        <span class="cb-app-chevron">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>
                        </span>
                        <span class="cb-app-nome">${cbEscapar(app.nome)}</span>
                        ${msAulasNoApp > 0
                            ? `<span class="cb-app-aula-tag" title="Reconhecido como aula e contado na aba Produtividade">${formatHoursMinutes(msAulasNoApp)} em aula</span>`
                            : ''}
                        <span class="cb-app-tempo">${formatHoursMinutes(app.total)}</span>
                    </div>
                    <div class="cb-app-barra-bg">
                        <div class="cb-app-barra" style="width:${pct}%"></div>
                    </div>
                    <div class="cb-app-rodape">
                        <select class="cb-app-cat" data-proc="${cbEscapar(app.proc)}"
                                title="Como este programa deve ser contado">
                            <option value="estudo" ${app.categoria === 'estudo' ? 'selected' : ''}>Estudo</option>
                            <option value="distracao" ${app.categoria === 'distracao' ? 'selected' : ''}>Distração</option>
                            <option value="neutro" ${app.categoria === 'neutro' ? 'selected' : ''}>Neutro</option>
                        </select>
                        <span class="cb-app-proc">${cbEscapar(app.proc)}.exe</span>
                    </div>
                    <div class="cb-app-titulos" ${aberto ? '' : 'hidden'}>
                        ${topTitulos.map((x) => `
                            <div class="cb-app-titulo-item">
                                <span class="cb-app-titulo-txt" title="${cbEscapar(x.t)}">${cbEscapar(x.t)}</span>
                                <span class="cb-app-titulo-ms">${formatHoursMinutes(x.ms)}</span>
                            </div>`).join('')}
                    </div>
                `;
                listaEl.appendChild(linha);
            });

            // Expandir/recolher os títulos de janela.
            listaEl.querySelectorAll('.cb-app-head').forEach((el) => {
                const alternar = () => {
                    const proc = el.getAttribute('data-proc');
                    if (cbAppsExpandidos.has(proc)) cbAppsExpandidos.delete(proc);
                    else cbAppsExpandidos.add(proc);
                    renderApps(false);
                };
                el.addEventListener('click', alternar);
                el.addEventListener('keydown', (ev) => {
                    if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); alternar(); }
                });
            });

            // Reclassificar um app. Grava só a diferença em relação ao padrão,
            // então a tabela padrão pode crescer numa versão futura sem
            // atropelar o que a pessoa já escolheu à mão.
            listaEl.querySelectorAll('.cb-app-cat').forEach((sel) => {
                sel.addEventListener('click', (ev) => ev.stopPropagation());
                sel.addEventListener('change', () => {
                    const proc = sel.getAttribute('data-proc');
                    chrome.storage.local.get(['appCategorias'], (r) => {
                        const mapa = r.appCategorias || {};
                        mapa[proc] = sel.value;
                        chrome.storage.local.set({ appCategorias: mapa }, () => renderApps(false));
                    });
                });
            });
          });
        });
    }

    // --------------------------------------------------------- LEITURA DE PDF
    function renderPdfs(animate = true) {
        const bloco = document.getElementById('cb-pdf-bloco');
        const resumoEl = document.getElementById('cb-pdf-resumo');
        const listaEl = document.getElementById('cb-pdf-render');
        if (!bloco || !resumoEl || !listaEl) return;

        chrome.storage.local.get(['pdfHistory', 'pdfMateriaOverride', 'cbSentinelaConectada'], (res) => {
          cbColetarMateriasDoUsuario((materiasDoUsuario) => {
            const historico = res.pdfHistory || {};
            const overrides = res.pdfMateriaOverride || {};
            const Classif = self.CBClassificacaoApps;

            // Junta o período. As páginas são um CONJUNTO: se você leu a
            // página 40 na segunda e de novo na quarta, ela conta uma vez só
            // no total de páginas distintas, mas o tempo das duas soma.
            const porDoc = {};
            cbChavesDeDataProd().forEach((data) => {
                const doDia = historico[data];
                if (!doDia) return;
                Object.keys(doDia).forEach((doc) => {
                    const reg = doDia[doc] || {};
                    if (!porDoc[doc]) porDoc[doc] = { app: reg.app, tempo: 0, totalPaginas: 0, paginas: {} };
                    const alvo = porDoc[doc];
                    if (reg.app) alvo.app = reg.app;
                    alvo.tempo += Number(reg.tempo) || 0;
                    if ((Number(reg.totalPaginas) || 0) > alvo.totalPaginas) {
                        alvo.totalPaginas = Number(reg.totalPaginas) || 0;
                    }
                    const pgs = reg.paginas || {};
                    Object.keys(pgs).forEach((n) => {
                        alvo.paginas[n] = (alvo.paginas[n] || 0) + (Number(pgs[n]) || 0);
                    });
                });
            });

            const docs = Object.keys(porDoc)
                .map((doc) => {
                    const reg = porDoc[doc];
                    const lidas = Object.keys(reg.paginas).length;

                    // A matéria: a correção manual da pessoa vence sempre.
                    // Sem correção, tenta casar o nome do arquivo com as
                    // matérias que ela própria escreveu (cronograma e
                    // QConcursos). Se ela ainda não tem matéria nenhuma
                    // cadastrada, fica "Não classificado" e ela digita — eu
                    // não tenho como saber para que concurso ela estuda.
                    let materia = overrides[doc] || null;
                    const manual = !!materia;
                    if (!materia) materia = cbAdivinharMateria(doc, materiasDoUsuario);
                    if (!materia) materia = 'Não classificado';

                    return {
                        doc, materia, manual,
                        tempo: reg.tempo,
                        lidas,
                        totalPaginas: reg.totalPaginas,
                        app: reg.app,
                        appNome: Classif ? Classif.nomeAmigavelApp(reg.app) : reg.app
                    };
                })
                .filter((d) => d.tempo >= 20000)
                .sort((a, b) => b.tempo - a.tempo);

            if (docs.length === 0) {
                // ANTES eu simplesmente escondia o bloco aqui, sempre. O
                // efeito colateral foi ruim: quem instalou o monitor e abriu
                // um PDF não tinha como saber se estava esperando ou se algo
                // tinha quebrado — a tela ficava calada. Agora, quando o
                // monitor está conectado, a seção aparece e DIZ o que falta.
                // Quem nunca instalou continua não vendo nada, que era o
                // ponto original.
                if (res.cbSentinelaConectada) {
                    bloco.style.display = '';
                    resumoEl.innerHTML = '';
                    listaEl.innerHTML = `
                        <div class="empty-state">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg>
                            Monitor do Windows conectado, mas nenhum PDF registrado ainda.<br>
                            Abra um PDF no Adobe Acrobat ou no Edge e deixe uns 40 segundos.
                        </div>`;
                } else {
                    bloco.style.display = 'none';
                }
                return;
            }
            bloco.style.display = '';

            const msTotal = docs.reduce((s, d) => s + d.tempo, 0);
            const pagsTotal = docs.reduce((s, d) => s + d.lidas, 0);

            resumoEl.innerHTML = `
                <div class="distraction-summary-grid">
                    <div class="distraction-stat">
                        <span class="distraction-stat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg></span>
                        <span class="distraction-stat-label">Lendo PDF</span>
                        <span class="distraction-stat-value">${formatHoursMinutes(msTotal)}</span>
                    </div>
                    <div class="distraction-stat">
                        <span class="distraction-stat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg></span>
                        <span class="distraction-stat-label">Páginas lidas</span>
                        <span class="distraction-stat-value">${pagsTotal > 0 ? pagsTotal : '—'}</span>
                    </div>
                    <div class="distraction-stat">
                        <span class="distraction-stat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5V6a2 2 0 0 1 2-2h13"/><path d="M6 15h14v5H6a2 2 0 0 1 0-4h14"/></svg></span>
                        <span class="distraction-stat-label">Documentos</span>
                        <span class="distraction-stat-value">${docs.length}</span>
                    </div>
                </div>
            `;

            listaEl.innerHTML = '';
            listaEl.classList.toggle('animate-in', animate);

            docs.slice(0, 20).forEach((d, idx) => {
                // Só desenho a barra de progresso quando sei o total de
                // páginas. Sem o total, uma barra seria um número inventado —
                // prefiro mostrar só "23 páginas lidas" e ser honesto.
                const temTotal = d.totalPaginas > 0;
                const pctLido = temTotal ? Math.min(100, (d.lidas / d.totalPaginas) * 100) : 0;

                // As opções são as matérias DELA. "Outra…" abre um campo pra
                // digitar qualquer nome — a partir daí aquele nome passa a
                // fazer parte da lista, porque cbColetarMateriasDoUsuario
                // também lê os overrides já salvos.
                const opcoes = ['Não classificado'];
                materiasDoUsuario.forEach((m) => { if (opcoes.indexOf(m) === -1) opcoes.push(m); });
                if (d.materia && opcoes.indexOf(d.materia) === -1) opcoes.push(d.materia);

                const linha = document.createElement('div');
                linha.className = 'cb-pdf-row';
                linha.style.setProperty('--i', idx);
                linha.innerHTML = `
                    <div class="cb-pdf-head">
                        <span class="cb-pdf-icone">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg>
                        </span>
                        <span class="cb-pdf-nome" title="${cbEscapar(d.doc)}">${cbEscapar(d.doc)}</span>
                        <span class="cb-pdf-tempo">${formatHoursMinutes(d.tempo)}</span>
                    </div>

                    <div class="cb-pdf-meta">
                        <select class="cb-pdf-materia ${d.manual ? 'manual' : ''}" data-doc="${cbEscapar(d.doc)}"
                                title="${d.manual ? 'Matéria definida por você' : 'Palpite pelo nome do arquivo — clique para corrigir'}">
                            ${opcoes.map((m) => `<option value="${cbEscapar(m)}" ${m === d.materia ? 'selected' : ''}>${cbEscapar(m)}</option>`).join('')}
                            <option value="__nova__">✏️ Outra matéria…</option>
                        </select>
                        <span class="cb-pdf-app">${cbEscapar(d.appNome || '')}</span>
                    </div>

                    <div class="cb-pdf-paginas">
                        ${d.lidas > 0
                            ? (temTotal
                                ? `<div class="cb-pdf-prog-bg"><div class="cb-pdf-prog" style="width:${pctLido}%"></div></div>
                                   <span class="cb-pdf-prog-txt"><strong>${d.lidas}</strong> de ${d.totalPaginas} páginas</span>`
                                : `<span class="cb-pdf-prog-txt"><strong>${d.lidas}</strong> ${d.lidas === 1 ? 'página lida' : 'páginas lidas'}</span>`)
                            : `<span class="cb-pdf-prog-txt sem-dado">páginas não detectadas neste programa</span>`}
                    </div>
                `;
                listaEl.appendChild(linha);
            });

            listaEl.querySelectorAll('.cb-pdf-materia').forEach((sel) => {
                const valorAnterior = sel.value;
                sel.addEventListener('change', () => {
                    const doc = sel.getAttribute('data-doc');
                    let escolha = sel.value;

                    if (escolha === '__nova__') {
                        // Matéria que ainda não existe em lugar nenhum do app.
                        // Depois de salva ela entra na lista de todos os PDFs,
                        // porque cbColetarMateriasDoUsuario relê os overrides.
                        const digitada = window.prompt(
                            'Nome da matéria para este PDF:\n\n' + doc, '');
                        if (!digitada || !digitada.trim()) {
                            sel.value = valorAnterior; // desistiu: nada muda
                            return;
                        }
                        escolha = digitada.trim();
                    }

                    // Guarda-chuva: se por qualquer motivo a escolha vier
                    // vazia, não grava matéria em branco — isso deixaria o PDF
                    // com um rótulo invisível, pior que "Não classificado".
                    if (!escolha) { sel.value = valorAnterior; return; }

                    chrome.storage.local.get(['pdfMateriaOverride'], (r) => {
                        const mapa = r.pdfMateriaOverride || {};
                        mapa[doc] = escolha;
                        chrome.storage.local.set({ pdfMateriaOverride: mapa }, () => renderPdfs(false));
                    });
                });
            });
          });
        });
    }

    // ========================================================================
    //                            PAINEL DE PERFIL
    // ------------------------------------------------------------------------
    // Recolhe o que estava espalhado pelo alto da tela inicial — a barra de
    // ícones, a ofensiva e o organizador do dia — e deixa a tela inicial só
    // com o cronômetro, que é o motivo de a pessoa abrir o popup.
    //
    // Os elementos foram MOVIDOS no HTML, não recriados: os ids continuam os
    // mesmos, então todos os listeners que já existiam (abrir dashboard,
    // celular, configurações, conta, organizador) seguem funcionando sem uma
    // linha de código nova. Recriá-los teria duplicado comportamento e criado
    // dois lugares pra corrigir cada bug.
    // ========================================================================
    // A "barra vazia" entre o perfil e o cronômetro: é o cartão que segurava o
    // "Organizar meu dia". Depois que ele mudou pro painel de perfil, sobraram
    // ali só blocos que nascem ocultos (contagem para a prova, foco do dia,
    // sequência) — e um `.card` sem nada dentro ainda desenha fundo, borda e
    // padding. Resultado: um retângulo cinza sem conteúdo.
    //
    // Tentei resolver com `:has()` no CSS e não bastou: alguns blocos são
    // exibidos com `style.display = ''`, outros com classe, e um seletor que
    // adivinha o formato do atributo `style` quebra sozinho na próxima
    // alteração. Medir a altura real do elemento é o único teste que não
    // depende de COMO ele foi escondido.
    function cbAjustarCartaoInicial() {
        const cartao = document.getElementById('home-novo-panel');
        if (!cartao) return;
        const temConteudo = Array.from(cartao.children)
            .some((filho) => filho.offsetHeight > 0 || filho.offsetWidth > 0);
        cartao.style.display = temConteudo ? '' : 'none';
    }

    (function vigiarCartaoInicial() {
        cbAjustarCartaoInicial();
        // Os blocos aparecem quando o storage responde, que é depois desta
        // primeira checagem. Um observador é mais confiável que tentar
        // adivinhar todos os pontos do código que mexem neles.
        const cartao = document.getElementById('home-novo-panel');
        if (!cartao || typeof MutationObserver === 'undefined') return;
        const obs = new MutationObserver(() => cbAjustarCartaoInicial());
        obs.observe(cartao, { attributes: true, childList: true, subtree: true,
                              attributeFilter: ['style', 'class'] });
    })();

    (function painelDePerfil() {
        const btn = document.getElementById('btn-perfil');
        const overlay = document.getElementById('perfil-modal-overlay');
        const fechar = document.getElementById('perfil-modal-close');
        if (!btn || !overlay) return;

        const DIAS_CURTOS = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
        const MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho',
                       'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];

        function saudacao() {
            const h = new Date().getHours();
            if (h < 5) return 'Boa madrugada';
            if (h < 12) return 'Bom dia';
            if (h < 18) return 'Boa tarde';
            return 'Boa noite';
        }

        function chaveDeData(d) {
            return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') +
                   '-' + String(d.getDate()).padStart(2, '0');
        }

        // Faixa dos 7 dias da semana corrente, com hoje destacado. Serve de
        // âncora temporal: sem ela, "Seu dia" é uma lista solta no vazio.
        function renderSemana() {
            const alvo = document.getElementById('cb-semana');
            if (!alvo) return;
            const hoje = new Date();
            const inicio = new Date(hoje);
            inicio.setDate(hoje.getDate() - hoje.getDay());

            chrome.storage.local.get(['studyHistory'], (res) => {
                const study = res.studyHistory || {};
                let html = '';
                for (let i = 0; i < 7; i++) {
                    const d = new Date(inicio);
                    d.setDate(inicio.getDate() + i);
                    const ehHoje = chaveDeData(d) === chaveDeData(hoje);
                    // Ponto embaixo do dia = houve estudo registrado. É o
                    // resumo mais barato possível da semana inteira.
                    const estudou = (Number(study[chaveDeData(d)]) || 0) > 0;
                    html += `<div class="cb-semana-dia${ehHoje ? ' hoje' : ''}">
                                <span class="cb-semana-num">${d.getDate()}</span>
                                <span class="cb-semana-lbl">${DIAS_CURTOS[d.getDay()]}</span>
                                <span class="cb-semana-ponto${estudou ? ' on' : ''}"></span>
                             </div>`;
                }
                alvo.innerHTML = html;
            });
        }

        const TIPO_ROTULO = {
            leitura: 'Leitura', video: 'Vídeo-aula',
            questoes: 'Questões', revisao: 'Revisão'
        };

        function renderDia() {
            const alvo = document.getElementById('cb-dia-lista');
            const olaEl = document.getElementById('cb-perfil-ola');
            const dataEl = document.getElementById('cb-perfil-data');
            if (!alvo) return;

            const hoje = new Date();
            if (olaEl) olaEl.textContent = saudacao();
            if (dataEl) {
                dataEl.textContent = DIAS_CURTOS[hoje.getDay()] + ', ' +
                    hoje.getDate() + ' de ' + MESES[hoje.getMonth()];
            }

            chrome.storage.local.get(['cbCronogramaHoje', 'cbCronogramaData'], (res) => {
                const hojeStr = chaveDeData(hoje);
                const blocos = (res.cbCronogramaData === hojeStr)
                    ? (res.cbCronogramaHoje || []) : [];

                if (blocos.length === 0) {
                    alvo.innerHTML = `
                        <div class="cb-dia-vazio">
                            Nenhum bloco montado para hoje.<br>
                            <span>Abrir o organizador leva menos de um minuto.</span>
                        </div>`;
                    return;
                }

                const agoraMin = hoje.getHours() * 60 + hoje.getMinutes();
                const emMinutos = (hhmm) => {
                    const [h, m] = String(hhmm || '0:0').split(':').map(Number);
                    return (h || 0) * 60 + (m || 0);
                };

                alvo.innerHTML = blocos.map((b) => {
                    const ini = emMinutos(b.inicio), fim = emMinutos(b.fim);
                    // Três estados, e a diferença entre eles é o que faz a
                    // lista ser útil de relance: o que já foi, o que está no
                    // ar agora, e o que ainda vem.
                    const estado = agoraMin >= fim ? 'passou'
                                 : (agoraMin >= ini ? 'agora' : 'futuro');
                    return `
                        <div class="cb-dia-bloco ${estado}">
                            <div class="cb-dia-hora">
                                <span>${cbEscapar(b.inicio || '')}</span>
                                <span class="cb-dia-hora-fim">${cbEscapar(b.fim || '')}</span>
                            </div>
                            <div class="cb-dia-corpo">
                                <span class="cb-dia-materia">${cbEscapar(b.materia || 'Sem matéria')}</span>
                                <span class="cb-dia-tipo">${cbEscapar(TIPO_ROTULO[b.tipo] || b.tipo || '')}</span>
                            </div>
                            ${estado === 'agora' ? '<span class="cb-dia-agora-selo">agora</span>' : ''}
                        </div>`;
                }).join('');
            });
        }

        // Contador de dias até a prova — só existe se a pessoa já configurou
        // o Modo Edital Aberto (aba Questões → Edital: data da prova + metas
        // totais). Reaproveita o MESMO "editalConfig" que aquele modo já
        // salva e o mesmo cálculo de dias restantes (ver renderEdital(),
        // mais abaixo neste arquivo) — não é um contador separado, é o
        // mesmo número mostrado aqui, num lugar que dá pra ver de relance.
        function renderContadorProva() {
            const bloco = document.getElementById('cb-perfil-prova');
            const numEl = document.getElementById('cb-perfil-prova-num');
            const lblEl = document.getElementById('cb-perfil-prova-lbl');
            if (!bloco || !numEl || !lblEl) return;

            chrome.storage.sync.get(['editalConfig'], (syncResult) => {
                const config = syncResult.editalConfig;
                if (!config || !config.examDate) {
                    bloco.style.display = 'none';
                    return;
                }

                const hoje = new Date();
                hoje.setHours(0, 0, 0, 0);
                const dataProva = new Date(config.examDate + 'T00:00:00');
                const diasRestantes = Math.ceil((dataProva - hoje) / 86400000);

                // Prova já passou e ninguém apagou o edital configurado —
                // não faz sentido continuar contando "dias negativos".
                if (diasRestantes < 0) {
                    bloco.style.display = 'none';
                    return;
                }

                bloco.style.display = 'flex';
                bloco.classList.toggle('cb-perfil-prova-hoje', diasRestantes === 0);
                if (diasRestantes === 0) {
                    numEl.textContent = 'Hoje';
                    lblEl.textContent = 'é o dia da prova!';
                } else if (diasRestantes === 1) {
                    numEl.textContent = '1';
                    lblEl.textContent = 'dia para a prova';
                } else {
                    numEl.textContent = String(diasRestantes);
                    lblEl.textContent = 'dias para a prova';
                }
            });
        }

        // Linha "Minha conta" no topo do painel: mostra o apelido (ou o ID) para
        // a pessoa saber de qual conta se trata antes de abrir o gerenciador.
        // A conta só é criada quando o modal de conta é aberto pela 1ª vez (conta.js).
        function renderConta() {
            const nomeEl = document.getElementById('cb-perfil-conta-nome');
            const idEl = document.getElementById('cb-perfil-conta-id');
            if (!nomeEl || !idEl) return;
            chrome.storage.local.get(['cbAccountApelido', 'cbAccountId'], (res) => {
                const apelido = (res.cbAccountApelido || '').trim();
                nomeEl.textContent = apelido || 'Minha conta';
                idEl.textContent = res.cbAccountId ? `ID ${res.cbAccountId}` : 'ID, apelido e senha';
            });
        }

        function abrir() {
            renderSemana();
            renderDia();
            renderContadorProva();
            renderConta();
            overlay.classList.add('open');
        }
        function fecharPainel() { overlay.classList.remove('open'); }

        btn.addEventListener('click', abrir);
        if (fechar) fechar.addEventListener('click', fecharPainel);
        overlay.addEventListener('click', (e) => { if (e.target === overlay) fecharPainel(); });
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && overlay.classList.contains('open')) fecharPainel();
        });

        // Os atalhos que abrem OUTRO modal (configurações, conta) precisam
        // fechar este antes, senão ficam dois painéis empilhados e o de baixo
        // captura cliques que pareciam ser do de cima.
        ['btn-open-settings', 'btn-open-account', 'btn-open-dashboard',
         'btn-open-celular', 'hn-btn-organizar'].forEach((id) => {
            const el = document.getElementById(id);
            if (el) el.addEventListener('click', fecharPainel);
        });

        // Mantém a prévia em dia enquanto o painel está aberto.
        chrome.storage.onChanged.addListener((changes, area) => {
            if (!overlay.classList.contains('open')) return;
            if (area === 'local') {
                if (changes.cbCronogramaHoje || changes.cbCronogramaData) renderDia();
                if (changes.studyHistory) renderSemana();
            }
            // "editalConfig" fica em chrome.storage.sync (mesma área que o
            // resto do Modo Edital Aberto usa), não em "local" como os outros
            // dois acima — por isso o "if" separado.
            if (area === 'sync' && changes.editalConfig) renderContadorProva();
        });
    })();

    // ========================================================================
    //          CURVA DE EVOLUÇÃO  e  RADAR DE EQUILÍBRIO POR MATÉRIA
    // ========================================================================

    // ======================= ABA GERAL: TUDO NUM GRÁFICO ====================
    // Quatro medidas que hoje moram em abas separadas, sobrepostas para
    // responder a pergunta que nenhuma delas responde sozinha: o que anda
    // junto com o quê. Distração subiu na semana em que o desempenho caiu?
    // As horas aumentaram mas o acerto não? Isso só aparece sobrepondo.
    //
    // As unidades são incompatíveis de propósito (horas, contagem, %), então
    // cada linha vai normalizada pelo próprio máximo — ver o comentário longo
    // em graficos.js. Os valores reais só aparecem no balão.
    let cbGeralPeriodo = 'week';
    let cbGeralApi = null;
    const cbGeralOcultas = new Set();

    const CB_GERAL_SERIES = [
        { chave: 'estudo',     nome: 'Estudo',     cor: '#8b5cf6' },
        { chave: 'questoes',   nome: 'Questões',   cor: '#3ecf8e' },
        { chave: 'desempenho', nome: 'Desempenho', cor: '#e6bb6f' },
        { chave: 'distracao',  nome: 'Distração',  cor: '#f2566d' }
    ];

    function cbGeralBaldes(periodo, ref) {
        const chaveDe = (d) => d.getFullYear() + '-' +
            String(d.getMonth() + 1).padStart(2, '0') + '-' +
            String(d.getDate()).padStart(2, '0');
        const DIA_SEM = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
        const MES_CURTO = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun',
                           'jul', 'ago', 'set', 'out', 'nov', 'dez'];
        const baldes = [];

        // Os mesmos recortes das outras abas, de propósito: trocar de aba não
        // pode trocar o significado de "Semanal".
        if (periodo === 'semester') {
            for (let i = 5; i >= 0; i--) {
                const m = new Date(ref.getFullYear(), ref.getMonth() - i, 1);
                const ultimo = new Date(m.getFullYear(), m.getMonth() + 1, 0).getDate();
                const chaves = [];
                for (let dia = 1; dia <= ultimo; dia++) {
                    chaves.push(m.getFullYear() + '-' +
                                String(m.getMonth() + 1).padStart(2, '0') + '-' +
                                String(dia).padStart(2, '0'));
                }
                baldes.push({ rotulo: MES_CURTO[m.getMonth()], chaves });
            }
        } else if (periodo === 'month') {
            for (let i = 3; i >= 0; i--) {
                const chaves = [];
                for (let j = 6; j >= 0; j--) {
                    const d = new Date(ref); d.setDate(ref.getDate() - (i * 7 + j));
                    chaves.push(chaveDe(d));
                }
                baldes.push({ rotulo: 'Sem. ' + (4 - i), chaves });
            }
        } else {
            const dias = periodo === 'week' ? 7 : 3;
            for (let i = dias - 1; i >= 0; i--) {
                const d = new Date(ref); d.setDate(ref.getDate() - i);
                baldes.push({
                    rotulo: dias > 3 ? DIA_SEM[d.getDay()]
                          : (String(d.getDate()).padStart(2, '0') + '/' +
                             String(d.getMonth() + 1).padStart(2, '0')),
                    chaves: [chaveDe(d)]
                });
            }
        }
        return baldes;
    }

    function renderGeral() {
        const alvo = document.getElementById('cb-geral-render');
        const legendaEl = document.getElementById('cb-geral-legenda');
        const vazioEl = document.getElementById('cb-geral-vazio');
        if (!alvo || !self.CBGraficos) return;

        chrome.storage.local.get(
            ['studyHistory', 'questoesDailyHistory', 'siteHistory'],
            (res) => {
                const study = res.studyHistory || {};
                const quest = res.questoesDailyHistory || {};
                const sites = res.siteHistory || {};
                const baldes = cbGeralBaldes(cbGeralPeriodo, new Date());

                const estudo = [], questoes = [], desempenho = [], distracao = [];
                baldes.forEach((b) => {
                    let ms = 0, qTot = 0, qAcertos = 0, distMs = 0;
                    b.chaves.forEach((k) => {
                        ms += Number(study[k]) || 0;
                        const q = quest[k];
                        if (q) { qTot += Number(q.total) || 0; qAcertos += Number(q.acertos) || 0; }
                        const dia = sites[k];
                        if (dia) Object.keys(dia).forEach((s) => { distMs += Number(dia[s]) || 0; });
                    });
                    estudo.push(ms);
                    questoes.push(qTot);
                    // Sem questões no balde, o percentual não existe — e 0%
                    // seria uma afirmação falsa ("errou tudo") em vez de
                    // ausência de dado. Vai zero, mas o balão mostra "—".
                    desempenho.push(qTot > 0 ? Math.round((qAcertos / qTot) * 100) : 0);
                    distracao.push(distMs);
                });

                const temAlgo = [estudo, questoes, distracao]
                    .some((arr) => arr.some((v) => v > 0));
                if (!temAlgo) {
                    alvo.innerHTML = '';
                    if (legendaEl) legendaEl.innerHTML = '';
                    if (vazioEl) vazioEl.innerHTML = `
                        <div class="empty-state">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><path d="m7 14 4-4 3 3 5-6"/></svg>
                            Sem dados neste período ainda.<br>
                            Estude um pouco e volte aqui — as quatro linhas aparecem sozinhas.
                        </div>`;
                    return;
                }
                if (vazioEl) vazioEl.innerHTML = '';

                const fmtH = (ms) => {
                    const min = Math.round(ms / 60000);
                    if (min === 0) return '—';
                    if (min < 60) return min + 'm';
                    const h = min / 60;
                    return (h % 1 === 0 ? h : h.toFixed(1)) + 'h';
                };

                const dados = { estudo, questoes, desempenho, distracao };
                // Os valores vão CURTOS de propósito. A primeira versão escrevia
                // "95 questões" e "81% de acerto" — mas o nome da série já está
                // na coluna ao lado, então a palavra se repetia e ainda forçava
                // o balão a quebrar cada valor em três linhas. O rótulo diz o
                // que é; o valor só precisa dizer quanto.
                const formatos = {
                    estudo: fmtH,
                    distracao: fmtH,
                    questoes: (v) => (v > 0 ? String(v) : '—'),
                    desempenho: (v) => (v > 0 ? v + '%' : '—')
                };

                const series = CB_GERAL_SERIES.map((s) => ({
                    nome: s.nome,
                    cor: s.cor,
                    valores: dados[s.chave],
                    formatar: formatos[s.chave],
                    oculta: cbGeralOcultas.has(s.chave)
                }));

                cbGeralApi = self.CBGraficos.cbMultiLinha(alvo, {
                    rotulos: baldes.map((b) => b.rotulo),
                    series
                });

                // AVISO DE DADOS RALOS.
                // Cada linha é normalizada pelo próprio máximo. Com um único
                // dia preenchido, esse dia é 100% e todos os outros são 0% —
                // o desenho vira uma reta no chão e um paredão no fim, e as
                // quatro linhas ficam idênticas, empilhadas.
                //
                // Isso não é defeito do gráfico, é o que dois pontos parecem.
                // Mas deixar a pessoa achando que o gráfico está quebrado é
                // pior do que dizer a verdade, então a tela diz.
                const preenchidos = baldes.filter((_, i) =>
                    estudo[i] > 0 || questoes[i] > 0 || distracao[i] > 0).length;
                if (vazioEl) {
                    vazioEl.innerHTML = preenchidos < 3
                        ? `<div class="cb-geral-aviso">
                             <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16h.01"/></svg>
                             <span>Só <strong>${preenchidos}</strong> ${preenchidos === 1 ? 'dia tem' : 'dias têm'} registro neste período.
                             Como cada linha é medida contra o próprio máximo, um único dia com dados
                             vira 100% e o resto vira zero — daí a subida em paredão.
                             Com uns quatro dias a curva começa a ter forma.</span>
                           </div>`
                        : '';
                }

                if (legendaEl) {
                    legendaEl.innerHTML = CB_GERAL_SERIES.map((s, i) => `
                        <button type="button" class="cb-ml-leg${cbGeralOcultas.has(s.chave) ? ' off' : ''}"
                                data-i="${i}" data-chave="${s.chave}">
                            <span class="cb-ml-leg-cor" style="background:${s.cor}"></span>
                            ${cbEscapar(s.nome)}
                        </button>`).join('');

                    legendaEl.querySelectorAll('.cb-ml-leg').forEach((b) => {
                        b.addEventListener('click', () => {
                            const chave = b.getAttribute('data-chave');
                            const i = Number(b.getAttribute('data-i'));
                            // Impede esconder a última linha visível: um
                            // gráfico vazio parece quebrado, não filtrado.
                            if (!cbGeralOcultas.has(chave) &&
                                cbGeralOcultas.size >= CB_GERAL_SERIES.length - 1) return;
                            if (cbGeralOcultas.has(chave)) cbGeralOcultas.delete(chave);
                            else cbGeralOcultas.add(chave);
                            b.classList.toggle('off');
                            if (cbGeralApi) cbGeralApi.alternarSerie(i);
                        });
                    });
                }
            }
        );
    }

    (function ligarAbaGeral() {
        const ctr = document.getElementById('geral-controls');
        if (!ctr) return;
        ctr.addEventListener('click', (ev) => {
            const b = ev.target.closest('button[data-p]');
            if (!b) return;
            cbGeralPeriodo = b.getAttribute('data-p');
            ctr.querySelectorAll('button').forEach((x) => x.classList.remove('active'));
            b.classList.add('active');
            renderGeral();
        });
        renderGeral();
    })();

    // ------------------------------------------- 1) EVOLUÇÃO (aba Histórico)
    // Convive com as barras de propósito: elas respondem "quanto em cada dia",
    // a curva responde "a tendência está subindo ou caindo". São perguntas
    // diferentes sobre o mesmo dado, e a curva é ruim pra ler valor exato —
    // por isso ela fica ao lado das barras, não no lugar delas.
    function renderEvolucao() {
        const alvo = document.getElementById('cb-evolucao-render');
        const bloco = document.getElementById('cb-evolucao-bloco');
        if (!alvo || !bloco || !self.CBGraficos) return;

        chrome.storage.local.get(['studyHistory', 'activityHistory', 'pauseHistory'], (res) => {
            // A curva agora responde ao botão Período / Atividade / Pausas
            // logo acima dela. ANTES ela desenhava tempo de estudo sempre, o
            // que dava a cena mais confusa possível: você clicava em "Pausas",
            // as barras mudavam, e a curva ficava exatamente igual — parecia
            // que o clique não tinha funcionado.
            const study = res.studyHistory || {};
            const atividade = res.activityHistory || {};
            const pausas = res.pauseHistory || {};

            const modo = (typeof currentChartViewMode !== 'undefined') ? currentChartViewMode : 'period';
            const valorDoDia = (k) => {
                if (modo === 'activity') {
                    const a = atividade[k];
                    if (!a) return 0;
                    // Soma das três formas de estudo. O detalhe de cada uma
                    // continua nas barras; a curva mostra o total, porque três
                    // curvas sobrepostas aqui competiriam com a aba Geral,
                    // que existe justamente pra isso.
                    return (Number(a.questoes) || 0) + (Number(a.leitura) || 0) + (Number(a.videoaula) || 0);
                }
                if (modo === 'pauses') {
                    const pz = pausas[k];
                    return pz ? (Number(pz.totalMs) || 0) : 0;
                }
                return Number(study[k]) || 0;
            };

            // A curva agora usa EXATAMENTE os mesmos pontos das barras logo
            // acima. Antes eu tinha inventado uma contagem própria (7/14/30) e
            // o resultado era o pior tipo de erro num painel: escolher
            // "Diário" mostrava 3 barras e 7 pontos na curva, lado a lado, sem
            // nenhuma explicação. Dois gráficos do mesmo dado discordando na
            // mesma tela destrói a confiança nos dois.
            const ref = chartDatePicker && chartDatePicker.value
                ? new Date(chartDatePicker.value + 'T12:00:00')
                : new Date();
            const chaveDe = (d) => d.getFullYear() + '-' +
                String(d.getMonth() + 1).padStart(2, '0') + '-' +
                String(d.getDate()).padStart(2, '0');
            const DIA_SEM = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
            const MES_CURTO = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun',
                               'jul', 'ago', 'set', 'out', 'nov', 'dez'];

            const pontos = [];
            const somaDias = (chaves) => chaves.reduce((t, k) => t + valorDoDia(k), 0);

            if (currentChartPeriod === 'semester') {
                for (let i = 5; i >= 0; i--) {
                    const m = new Date(ref.getFullYear(), ref.getMonth() - i, 1);
                    const ultimo = new Date(m.getFullYear(), m.getMonth() + 1, 0).getDate();
                    const chaves = [];
                    for (let dia = 1; dia <= ultimo; dia++) {
                        chaves.push(m.getFullYear() + '-' +
                                    String(m.getMonth() + 1).padStart(2, '0') + '-' +
                                    String(dia).padStart(2, '0'));
                    }
                    pontos.push({ rotulo: MES_CURTO[m.getMonth()], valor: somaDias(chaves) });
                }
            } else if (currentChartPeriod === 'month') {
                for (let i = 3; i >= 0; i--) {
                    const chaves = [];
                    for (let j = 6; j >= 0; j--) {
                        const d = new Date(ref);
                        d.setDate(ref.getDate() - (i * 7 + j));
                        chaves.push(chaveDe(d));
                    }
                    pontos.push({ rotulo: 'Sem. ' + (4 - i), valor: somaDias(chaves) });
                }
            } else {
                const dias = currentChartPeriod === 'week' ? 7 : 3;
                for (let i = dias - 1; i >= 0; i--) {
                    const d = new Date(ref);
                    d.setDate(ref.getDate() - i);
                    pontos.push({
                        rotulo: dias > 3
                            ? DIA_SEM[d.getDay()]
                            : (String(d.getDate()).padStart(2, '0') + '/' +
                               String(d.getMonth() + 1).padStart(2, '0')),
                        valor: valorDoDia(chaveDe(d))
                    });
                }
            }

            // Sem nenhum minuto no período, uma linha reta no zero não informa
            // nada e ainda ocupa espaço.
            if (pontos.every((p) => p.valor === 0)) {
                bloco.style.display = 'none';
                return;
            }
            bloco.style.display = '';

            // O título muda junto: um gráfico que troca de conteúdo sem
            // trocar de rótulo é a receita pra pessoa ler o número errado.
            const TITULOS = {
                period: 'Evolução do tempo de estudo',
                activity: 'Evolução do tempo por atividade',
                pauses: 'Evolução do tempo pausado'
            };
            const tituloEl = bloco.querySelector('.section-title span, .section-title');
            if (tituloEl && tituloEl.classList.contains('section-title')) {
                const svgTit = tituloEl.querySelector('svg');
                tituloEl.textContent = '';
                if (svgTit) tituloEl.appendChild(svgTit);
                tituloEl.appendChild(document.createTextNode(
                    ' ' + (modo === 'period' ? 'Evolução'
                         : (modo === 'activity' ? 'Evolução · Atividade' : 'Evolução · Pausas'))));
            }
            // Pausa é a única das três em que MAIS é PIOR — então ela é a
            // única desenhada em vermelho. Usar a cor da marca aqui faria
            // "duas horas paradas" parecer conquista.
            bloco.classList.toggle('cb-evolucao-negativa', modo === 'pauses');

            alvo.innerHTML = self.CBGraficos.cbAreaSuave(pontos, {
                altura: 150,
                titulo: TITULOS[modo] || TITULOS.period,
                formatar: (ms) => {
                    const min = Math.round(ms / 60000);
                    if (min < 60) return min + 'm';
                    const h = min / 60;
                    return (h % 1 === 0 ? h : h.toFixed(1)) + 'h';
                }
            });
        });
    }

    // -------------------------------------- 2) RADAR (aba Produtividade)
    // Dois modos, porque as duas fontes respondem coisas diferentes:
    //   Desempenho -> % de acerto por disciplina (vem do QConcursos). Funciona
    //                 sem o monitor do Windows, e mostra ONDE VOCÊ ERRA.
    //   Tempo      -> minutos por matéria (PDF + aulas em vídeo). Precisa do
    //                 monitor, e mostra ONDE VOCÊ INVESTE.
    // Um modo sem dado simplesmente não é oferecido, em vez de aparecer vazio.
    let cbRadarModo = 'questoes';

    function renderRadar() {
        const bloco = document.getElementById('cb-radar-bloco');
        const alvo = document.getElementById('cb-radar-render');
        const legenda = document.getElementById('cb-radar-legenda');
        const modos = document.getElementById('cb-radar-modos');
        if (!bloco || !alvo || !self.CBGraficos) return;

        chrome.storage.local.get(
            ['questoesDisciplinas', 'pdfHistory', 'appUsageHistory',
             'pdfMateriaOverride', 'videoMateriaOverride'],
            (res) => {
              cbColetarMateriasDoUsuario((materiasDoUsuario) => {
                const chaves = cbChavesDeDataProd();

                // ---- fonte A: desempenho em questões ----
                const itens = ((res.questoesDisciplinas && res.questoesDisciplinas.itens) || [])
                    .filter((it) => it && it.total > 0);
                const eixosQuestoes = itens
                    .map((it) => ({
                        rotulo: it.nome,
                        valor: Math.round((it.certas / it.total) * 100),
                        extra: it.total
                    }))
                    // Mais questões resolvidas primeiro: são as matérias em que
                    // a porcentagem significa alguma coisa. 100% de 2 questões
                    // não é informação, é ruído.
                    .sort((a, b) => b.extra - a.extra)
                    .slice(0, 8);

                // ---- fonte B: tempo por matéria ----
                const tempoPorMateria = {};
                const somar = (materia, ms) => {
                    if (!materia || ms <= 0) return;
                    tempoPorMateria[materia] = (tempoPorMateria[materia] || 0) + ms;
                };

                const pdfHist = res.pdfHistory || {};
                const pdfOv = res.pdfMateriaOverride || {};
                chaves.forEach((data) => {
                    const doDia = pdfHist[data];
                    if (!doDia) return;
                    Object.keys(doDia).forEach((doc) => {
                        const m = pdfOv[doc] || cbAdivinharMateria(doc, materiasDoUsuario);
                        somar(m, Number(doDia[doc].tempo) || 0);
                    });
                });

                const videoOv = res.videoMateriaOverride || {};
                const coleta = cbColetarVideos(res.appUsageHistory || {}, chaves);
                coleta.videos.forEach((v) => {
                    const c = cbClassificarVideo(v.nome, materiasDoUsuario, videoOv);
                    if (c.ehAula && c.materia) somar(c.materia, v.ms);
                });

                const eixosTempo = Object.keys(tempoPorMateria)
                    .map((m) => ({ rotulo: m, valor: tempoPorMateria[m] }))
                    .sort((a, b) => b.valor - a.valor)
                    .slice(0, 8);

                // Um radar precisa de 3 eixos pra ser um polígono. Com menos,
                // vira um traço e engana mais do que informa.
                const temQuestoes = eixosQuestoes.length >= 3;
                const temTempo = eixosTempo.length >= 3;

                if (!temQuestoes && !temTempo) { bloco.style.display = 'none'; return; }
                bloco.style.display = '';

                if (!temQuestoes) cbRadarModo = 'tempo';
                if (!temTempo && cbRadarModo === 'tempo') cbRadarModo = 'questoes';

                // Esconde o seletor quando só existe um modo — botão que não
                // leva a lugar nenhum é pior que botão nenhum.
                if (modos) {
                    modos.style.display = (temQuestoes && temTempo) ? '' : 'none';
                    modos.querySelectorAll('button').forEach((b) => {
                        b.classList.toggle('active', b.getAttribute('data-modo') === cbRadarModo);
                    });
                }

                if (cbRadarModo === 'questoes') {
                    if (legenda) legenda.textContent =
                        'Percentual de acerto por disciplina, do QConcursos. Quanto mais para a borda, melhor. Um lado murcho é a matéria que precisa de você.';
                    alvo.innerHTML = self.CBGraficos.cbRadar(eixosQuestoes, {
                        max: 100,
                        titulo: 'Desempenho por matéria',
                        formatar: (v) => v + '%'
                    });
                } else {
                    if (legenda) legenda.textContent =
                        'Tempo por matéria, somando PDF e aulas em vídeo no período. Mostra onde o esforço foi, não o resultado.';
                    alvo.innerHTML = self.CBGraficos.cbRadar(eixosTempo, {
                        titulo: 'Tempo por matéria',
                        formatar: (ms) => {
                            const min = Math.round(ms / 60000);
                            return min < 60 ? min + 'm' : (min / 60).toFixed(1) + 'h';
                        }
                    });
                }
              });
            }
        );
    }

    // Seletor Desempenho / Tempo do radar.
    (function ligarModosDoRadar() {
        const modos = document.getElementById('cb-radar-modos');
        if (!modos) return;
        modos.addEventListener('click', (ev) => {
            const btn = ev.target.closest('button[data-modo]');
            if (!btn) return;
            cbRadarModo = btn.getAttribute('data-modo');
            renderRadar();
        });
    })();

    // ---------------------------------------------------- AULAS EM VÍDEO (UI)
    const cbMateriasExpandidas = new Set();
    const CB_SEM_MATERIA = '__a_classificar__';

    function renderAulas(animate = true) {
        const bloco = document.getElementById('cb-aulas-bloco');
        const resumoEl = document.getElementById('cb-aulas-resumo');
        const listaEl = document.getElementById('cb-aulas-render');
        if (!bloco || !resumoEl || !listaEl) return;

        chrome.storage.local.get(
            ['appUsageHistory', 'videoMateriaOverride', 'cbSentinelaConectada'],
            (res) => {
              cbColetarMateriasDoUsuario((materiasDoUsuario) => {
                const historico = res.appUsageHistory || {};
                const overrides = res.videoMateriaOverride || {};

                const coleta = cbColetarVideos(historico, cbChavesDeDataProd());

                // Agrupa por matéria. Aula sem matéria identificada vai para um
                // grupo próprio em vez de sumir — sumir esconderia justamente
                // as aulas que precisam da sua ajuda para serem classificadas.
                const porMateria = {};
                let msAulas = 0;

                coleta.videos.forEach((v) => {
                    const c = cbClassificarVideo(v.nome, materiasDoUsuario, overrides);
                    if (!c.ehAula) return;
                    const chave = c.materia || CB_SEM_MATERIA;
                    if (!porMateria[chave]) porMateria[chave] = { chave, ms: 0, videos: [] };
                    porMateria[chave].ms += v.ms;
                    porMateria[chave].videos.push({ nome: v.nome, ms: v.ms, motivo: c.motivo, manual: !!c.manual });
                    msAulas += v.ms;
                });

                const grupos = Object.values(porMateria).sort((a, b) => b.ms - a.ms);

                if (grupos.length === 0) {
                    if (coleta.msYoutubeTotal > 0) {
                        // Houve YouTube, mas nada foi reconhecido como aula.
                        // Dizer isso é melhor que sumir: pode ser que você
                        // realmente só tenha visto outra coisa, ou que os
                        // títulos das suas aulas não citem a matéria.
                        bloco.style.display = '';
                        resumoEl.innerHTML = '';
                        listaEl.innerHTML = `
                            <div class="empty-state">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m10 15 5-3-5-3z"/><rect x="2" y="4" width="20" height="16" rx="3"/></svg>
                                ${formatHoursMinutes(coleta.msYoutubeTotal)} de YouTube no período, mas nenhum vídeo
                                reconhecido como aula.<br>
                                O reconhecimento usa as matérias do seu cronograma — cadastre-as para o filtro funcionar.
                            </div>`;
                    } else {
                        bloco.style.display = 'none';
                    }
                    return;
                }
                bloco.style.display = '';

                const topo = grupos[0];
                const nomeTopo = topo.chave === CB_SEM_MATERIA ? 'A classificar' : topo.chave;
                const pctDoYoutube = coleta.msYoutubeTotal > 0
                    ? Math.round((msAulas / coleta.msYoutubeTotal) * 100) : 0;

                resumoEl.innerHTML = `
                    <div class="distraction-summary-grid">
                        <div class="distraction-stat">
                            <span class="distraction-stat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg></span>
                            <span class="distraction-stat-label">Em aulas</span>
                            <span class="distraction-stat-value">${formatHoursMinutes(msAulas)}</span>
                        </div>
                        <div class="distraction-stat">
                            <span class="distraction-stat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5V6a2 2 0 0 1 2-2h13"/><path d="M6 15h14v5H6a2 2 0 0 1 0-4h14"/></svg></span>
                            <span class="distraction-stat-label">Matéria mais vista</span>
                            <span class="distraction-stat-value">${cbEscapar(nomeTopo)}</span>
                        </div>
                        <div class="distraction-stat">
                            <span class="distraction-stat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m10 15 5-3-5-3z"/><rect x="2" y="4" width="20" height="16" rx="3"/></svg></span>
                            <span class="distraction-stat-label">Do YouTube</span>
                            <span class="distraction-stat-value">${pctDoYoutube}%</span>
                        </div>
                    </div>
                `;

                const maior = Math.max(grupos[0].ms, 1);
                listaEl.innerHTML = '';
                listaEl.classList.toggle('animate-in', animate);

                grupos.forEach((g, idx) => {
                    const aberto = cbMateriasExpandidas.has(g.chave);
                    const semMateria = g.chave === CB_SEM_MATERIA;
                    const rotulo = semMateria ? 'Aulas a classificar' : g.chave;
                    const pct = (g.ms / maior) * 100;
                    const videos = g.videos.slice().sort((a, b) => b.ms - a.ms);

                    const opcoes = ['__nao_aula__'].concat(materiasDoUsuario);

                    const linha = document.createElement('div');
                    linha.className = 'cb-aula-grupo' + (aberto ? ' aberto' : '') + (semMateria ? ' sem-materia' : '');
                    linha.style.setProperty('--i', idx);
                    linha.innerHTML = `
                        <div class="cb-aula-head" data-materia="${cbEscapar(g.chave)}" role="button" tabindex="0"
                             title="Clique para ver os vídeos desta matéria">
                            <span class="cb-app-chevron">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>
                            </span>
                            <span class="cb-aula-materia">${cbEscapar(rotulo)}</span>
                            <span class="cb-aula-qtd">${videos.length} ${videos.length === 1 ? 'vídeo' : 'vídeos'}</span>
                            <span class="cb-aula-tempo">${formatHoursMinutes(g.ms)}</span>
                        </div>
                        <div class="cb-aula-barra-bg"><div class="cb-aula-barra" style="width:${pct}%"></div></div>
                        <div class="cb-aula-videos" ${aberto ? '' : 'hidden'}>
                            ${videos.map((v) => `
                                <div class="cb-aula-video">
                                    <div class="cb-aula-video-linha">
                                        <span class="cb-aula-video-nome" title="${cbEscapar(v.nome)}">${cbEscapar(v.nome)}</span>
                                        <span class="cb-aula-video-ms">${formatHoursMinutes(v.ms)}</span>
                                    </div>
                                    <div class="cb-aula-video-meta">
                                        <span class="cb-aula-motivo">${v.manual ? '✓ ' : ''}${cbEscapar(v.motivo)}</span>
                                        <select class="cb-aula-select" data-video="${cbEscapar(v.nome)}">
                                            <option value="">Reclassificar…</option>
                                            <option value="__nao_aula__">Não é aula</option>
                                            ${materiasDoUsuario.map((m) => `<option value="${cbEscapar(m)}">${cbEscapar(m)}</option>`).join('')}
                                            <option value="__nova__">✏️ Outra matéria…</option>
                                        </select>
                                    </div>
                                </div>`).join('')}
                        </div>
                    `;
                    listaEl.appendChild(linha);
                });

                listaEl.querySelectorAll('.cb-aula-head').forEach((el) => {
                    const alternar = () => {
                        const m = el.getAttribute('data-materia');
                        if (cbMateriasExpandidas.has(m)) cbMateriasExpandidas.delete(m);
                        else cbMateriasExpandidas.add(m);
                        renderAulas(false);
                    };
                    el.addEventListener('click', alternar);
                    el.addEventListener('keydown', (ev) => {
                        if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); alternar(); }
                    });
                });

                listaEl.querySelectorAll('.cb-aula-select').forEach((sel) => {
                    sel.addEventListener('click', (ev) => ev.stopPropagation());
                    sel.addEventListener('change', () => {
                        const video = sel.getAttribute('data-video');
                        let escolha = sel.value;
                        if (!escolha) return;

                        if (escolha === '__nova__') {
                            const digitada = window.prompt('Matéria deste vídeo:\n\n' + video, '');
                            if (!digitada || !digitada.trim()) { sel.value = ''; return; }
                            escolha = digitada.trim();
                        }

                        chrome.storage.local.get(['videoMateriaOverride'], (r) => {
                            const mapa = r.videoMateriaOverride || {};
                            mapa[video] = escolha;
                            chrome.storage.local.set({ videoMateriaOverride: mapa }, () => renderAulas(false));
                        });
                    });
                });
              });
            }
        );
    }

    function formatTime(ms) {
        let seconds = Math.floor(ms / 1000);
        let minutes = Math.floor(seconds / 60);
        let hours = Math.floor(minutes / 60);
        seconds %= 60;
        minutes %= 60;
        return `${String(hours).padStart(2, '0')}h ${String(minutes).padStart(2, '0')}m ${String(seconds).padStart(2, '0')}s`;
    }

    // ===================== ACALMAR A ANSIEDADE (RESPIRAÇÃO GUIADA) =====================
    // Padrões de respiração com evidência de uso clínico/popular para reduzir
    // ansiedade e estresse agudo (cada fase em segundos):
    //  - Box (4-4-4-4): usada em contextos de alta pressão (inclusive treinamento
    //    militar), 4 fases iguais — inspira, segura, expira, segura.
    //  - 4-7-8: expiração bem mais longa que a inspiração, efeito mais sedativo,
    //    boa para desacelerar antes de tentar dormir ou em pico de ansiedade.
    //  - Calma rápida (4-2-6): expiração mais longa que a inspiração ativa o
    //    sistema nervoso parassimpático mais rápido, útil quando o tempo é curto.
    const BREATHING_PATTERNS = {
        box: [
            { label: 'Inspire', seg: 4 },
            { label: 'Segure', seg: 4 },
            { label: 'Expire', seg: 4 },
            { label: 'Segure', seg: 4 },
        ],
        relax: [
            { label: 'Inspire', seg: 4 },
            { label: 'Segure', seg: 7 },
            { label: 'Expire', seg: 8 },
        ],
        calma: [
            { label: 'Inspire', seg: 4 },
            { label: 'Segure', seg: 2 },
            { label: 'Expire', seg: 6 },
        ],
    };
    let breathingPatternAtual = 'box';
    let breathingAtiva = false;
    let breathingTimeoutId = null;
    let breathingTickId = null;
    let breathingCiclos = 0;

    const calmPatternBtns = document.querySelectorAll('#calm-pattern-controls button');
    const breathingCircleEl = document.getElementById('breathing-circle');
    const breathingPhaseEl = document.getElementById('breathing-phase');
    const breathingCountEl = document.getElementById('breathing-count');
    const breathingCyclesEl = document.getElementById('breathing-cycles');
    const btnBreathingToggle = document.getElementById('btn-breathing-toggle');

    calmPatternBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            if (breathingAtiva) pararRespiracao();
            calmPatternBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            breathingPatternAtual = btn.dataset.pattern;
        });
    });

    function pararRespiracao() {
        breathingAtiva = false;
        clearTimeout(breathingTimeoutId);
        clearInterval(breathingTickId);
        breathingCircleEl.className = 'breathing-circle';
        breathingPhaseEl.textContent = 'Pronto?';
        breathingCountEl.textContent = '';  // parado: sem número (o traço "—" em 40px parecia um risco no meio do cartão)
        btnBreathingToggle.textContent = 'Iniciar respiração';
    }

    function rodarFaseRespiracao(fases, indice) {
        if (!breathingAtiva) return;
        const fase = fases[indice % fases.length];
        if (indice > 0 && indice % fases.length === 0) {
            breathingCiclos++;
            breathingCyclesEl.textContent = `${breathingCiclos} ciclo${breathingCiclos === 1 ? '' : 's'} completo${breathingCiclos === 1 ? '' : 's'}`;
        }

        breathingPhaseEl.textContent = fase.label;
        breathingCircleEl.className = 'breathing-circle';
        void breathingCircleEl.offsetWidth; // reinicia a animação CSS
        let classeAnim;
        if (fase.label === 'Inspire') {
            classeAnim = 'inspirando';
        } else if (fase.label === 'Expire') {
            classeAnim = 'expirando';
        } else {
            // "Segure" existe em dois momentos diferentes do ciclo (depois de
            // inspirar OU depois de expirar — o padrão Box tem os dois) e
            // cada um precisa manter o tamanho de onde a bolinha "parou":
            // grande se acabou de inspirar, pequena se acabou de expirar.
            // Olha a fase ANTERIOR (com wrap-around pro fim do array, pro
            // caso da própria primeira fase do ciclo ser "Segure") pra saber
            // qual das duas.
            const faseAnterior = fases[(indice - 1 + fases.length) % fases.length];
            classeAnim = faseAnterior.label === 'Expire' ? 'segurando-vazio' : 'segurando-cheio';
        }
        breathingCircleEl.classList.add(classeAnim);
        breathingCircleEl.style.transitionDuration = `${fase.seg}s`;

        let restante = fase.seg;
        breathingCountEl.textContent = restante;
        clearInterval(breathingTickId);
        breathingTickId = setInterval(() => {
            restante--;
            if (restante > 0) breathingCountEl.textContent = restante;
        }, 1000);

        breathingTimeoutId = setTimeout(() => {
            clearInterval(breathingTickId);
            rodarFaseRespiracao(fases, indice + 1);
        }, fase.seg * 1000);
    }

    function iniciarRespiracao() {
        breathingAtiva = true;
        breathingCiclos = 0;
        breathingCyclesEl.textContent = '0 ciclos completos';
        btnBreathingToggle.textContent = 'Parar';
        rodarFaseRespiracao(BREATHING_PATTERNS[breathingPatternAtual], 0);
    }

    btnBreathingToggle?.addEventListener('click', () => {
        if (breathingAtiva) pararRespiracao();
        else iniciarRespiracao();
    });

    // ----- Aterramento 5-4-3-2-1 -----
    const GROUNDING_STEPS = [
        { n: 5, sentido: 'coisas que você consegue VER ao seu redor agora', icone: '👀' },
        { n: 4, sentido: 'coisas que você consegue TOCAR perto de você', icone: '✋' },
        { n: 3, sentido: 'sons que você consegue OUVIR neste momento', icone: '👂' },
        { n: 2, sentido: 'cheiros que você consegue perceber (ou de que gosta)', icone: '👃' },
        { n: 1, sentido: 'coisa boa que você pode dizer sobre si mesmo agora', icone: '💚' },
    ];
    let groundingStepAtual = 0;
    const groundingStepRender = document.getElementById('grounding-step-render');
    const btnGroundingToggle = document.getElementById('btn-grounding-toggle');
    const calmGroundingBody = document.getElementById('calm-grounding-body');

    function renderGroundingStep() {
        if (groundingStepAtual >= GROUNDING_STEPS.length) {
            groundingStepRender.innerHTML = `
                <div class="grounding-done">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="m8.5 12.5 2.2 2.2 4.8-4.8"/></svg>
                    <span>Exercício concluído. Repare como você está agora, comparado a antes de começar.</span>
                </div>
                <button class="breathing-btn breathing-btn--ghost" id="btn-grounding-restart">Recomeçar</button>
            `;
            document.getElementById('btn-grounding-restart')?.addEventListener('click', () => {
                groundingStepAtual = 0;
                renderGroundingStep();
            });
            return;
        }
        const step = GROUNDING_STEPS[groundingStepAtual];
        groundingStepRender.innerHTML = `
            <div class="grounding-step">
                <span class="grounding-step-num">${step.icone} ${step.n}</span>
                <p>Nomeie <strong>${step.n}</strong> ${step.sentido}.</p>
                <button class="breathing-btn" id="btn-grounding-next">${groundingStepAtual === GROUNDING_STEPS.length - 1 ? 'Concluir' : 'Próximo'}</button>
            </div>
        `;
        document.getElementById('btn-grounding-next')?.addEventListener('click', () => {
            groundingStepAtual++;
            renderGroundingStep();
        });
    }
    renderGroundingStep();

    btnGroundingToggle?.addEventListener('click', () => {
        calmGroundingBody.classList.toggle('open');
        btnGroundingToggle.classList.toggle('open');
    });

    // ===================== RECUPERAR O FOCO =====================
    // Reset de foco de 2 minutos: transição curta entre "modo scroll" (vídeos
    // curtos, estímulo constante) e foco sustentado, combinando três passos com
    // apoio em pesquisa — desacelerar a respiração, soltar o olhar de perto
    // (relaxa o sistema visual acostumado a telas) e escolher uma única tarefa
    // antes de recomeçar, em vez de alternar entre várias.
    const FOCUS_RESET_STEPS = [
        { seg: 20, texto: 'Olhe para o ponto mais distante que conseguir ver (janela, fim da sala). Solte o foco de perto por alguns segundos.' },
        { seg: 60, texto: 'Respire devagar: inspire por 4s, expire por 6s. Deixe os pensamentos passarem sem seguir nenhum.' },
        { seg: 40, texto: 'Escolha mentalmente UMA única coisa para fazer nos próximos minutos. Só essa. O resto espera.' },
    ];
    let focusResetAtivo = false;
    let focusResetIntervalId = null;
    const focusResetTimeEl = document.getElementById('focus-reset-time');
    const focusResetInstructionEl = document.getElementById('focus-reset-instruction');
    const focusResetFillEl = document.getElementById('focus-reset-fill');
    const btnFocusReset = document.getElementById('btn-focus-reset');

    function formatMMSS(totalSeg) {
        const m = Math.floor(totalSeg / 60);
        const s = totalSeg % 60;
        return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    }

    function pararFocusReset(concluido) {
        focusResetAtivo = false;
        clearInterval(focusResetIntervalId);
        btnFocusReset.textContent = 'Iniciar reset de foco';
        focusResetFillEl.style.width = '0%';
        focusResetTimeEl.textContent = '02:00';
        focusResetInstructionEl.textContent = concluido
            ? 'Feito! Agora aproveite esse foco e comece a tarefa que você escolheu, sem abrir redes sociais antes.'
            : 'Um exercício curto pra sair do modo "scroll" antes de voltar a estudar: olhar longe, respirar devagar e escolher uma única tarefa.';
    }

    function iniciarFocusReset() {
        focusResetAtivo = true;
        btnFocusReset.textContent = 'Cancelar';
        const totalSeg = FOCUS_RESET_STEPS.reduce((s, p) => s + p.seg, 0);
        let decorrido = 0;
        let stepIdx = 0;
        let restanteStep = FOCUS_RESET_STEPS[0].seg;
        focusResetInstructionEl.textContent = FOCUS_RESET_STEPS[0].texto;

        focusResetIntervalId = setInterval(() => {
            decorrido++;
            restanteStep--;
            const restanteTotal = totalSeg - decorrido;
            focusResetTimeEl.textContent = formatMMSS(Math.max(0, restanteTotal));
            focusResetFillEl.style.width = `${Math.min(100, (decorrido / totalSeg) * 100)}%`;

            if (restanteStep <= 0 && stepIdx < FOCUS_RESET_STEPS.length - 1) {
                stepIdx++;
                restanteStep = FOCUS_RESET_STEPS[stepIdx].seg;
                focusResetInstructionEl.textContent = FOCUS_RESET_STEPS[stepIdx].texto;
            }
            if (decorrido >= totalSeg) {
                pararFocusReset(true);
            }
        }, 1000);
    }

    btnFocusReset?.addEventListener('click', () => {
        if (focusResetAtivo) pararFocusReset(false);
        else iniciarFocusReset();
    });

    // ===================== SEÇÕES COLAPSÁVEIS DA ABA QUESTÕES (olhinho) =====================
    // Cada bloco (.cb-collapsible) tem um cabeçalho com um botão de "olho"
    // que encolhe/expande o conteúdo. O estado de cada seção fica salvo em
    // chrome.storage.local (cbCollapsedSections) e é reaplicado toda vez
    // que a aba Questões é aberta de novo.
    function cbInitCollapsibles() {
        const wrappers = Array.from(document.querySelectorAll('.cb-collapsible[data-cb-section]'));
        if (wrappers.length === 0) return;

        chrome.storage.local.get(['cbCollapsedSections'], (result) => {
            const estadoSalvo = result.cbCollapsedSections || {};

            wrappers.forEach((wrapper) => {
                const chave = wrapper.dataset.cbSection;
                const head = wrapper.querySelector('.cb-collapsible-head');
                const eyeBtn = wrapper.querySelector('.cb-eye-btn');
                if (!head || !eyeBtn) return;

                if (estadoSalvo[chave]) {
                    wrapper.classList.add('is-collapsed');
                }

                const alternar = () => {
                    const colapsado = wrapper.classList.toggle('is-collapsed');
                    chrome.storage.local.get(['cbCollapsedSections'], (r2) => {
                        const atual = r2.cbCollapsedSections || {};
                        atual[chave] = colapsado;
                        chrome.storage.local.set({ cbCollapsedSections: atual });
                    });
                };

                // O olho alterna sozinho; clicar no resto do cabeçalho também
                // alterna, pra não precisar acertar exatamente no ícone.
                eyeBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    alternar();
                });
                head.addEventListener('click', alternar);
            });
        });
    }
    cbInitCollapsibles();

    // ===================== FIXAR SEÇÃO NO TOPO (alfinete discreto) =====================
    // Cada bloco (.cb-collapsible) ganha um ícone de alfinete no cabeçalho.
    // Clicar fixa/desafixa aquele bloco especificamente dentro do grupo de
    // irmãos onde ele vive (ex: os blocos da aba Questões entre si, e o
    // bloco "Detalhes do Dia" da aba Histórico separadamente — cada seção
    // só compete por posição com quem já divide o mesmo pai no HTML).
    // Guardado em chrome.storage.local (é preferência de layout local, não
    // precisa sincronizar entre PCs) como um array de chaves fixadas.
    function cbInitPinnable() {
        const wrappers = Array.from(document.querySelectorAll('.cb-collapsible[data-cb-section]'));
        if (wrappers.length === 0) return;

        chrome.storage.local.get(['cbPinnedSections'], (result) => {
            const pinned = new Set(Array.isArray(result.cbPinnedSections) ? result.cbPinnedSections : []);

            function aplicarEstadoVisual() {
                wrappers.forEach((wrapper) => {
                    const chave = wrapper.dataset.cbSection;
                    const pinBtn = wrapper.querySelector('.cb-pin-btn');
                    const estaFixado = pinned.has(chave);
                    wrapper.classList.toggle('cb-is-pinned', estaFixado);
                    if (pinBtn) pinBtn.classList.toggle('is-pinned', estaFixado);
                });
            }

            function reordenarNoDOM() {
                // Agrupa por pai real (grupos diferentes de irmãos não se misturam)
                const porPai = new Map();
                wrappers.forEach((wrapper) => {
                    const pai = wrapper.parentElement;
                    if (!porPai.has(pai)) porPai.set(pai, []);
                    porPai.get(pai).push(wrapper);
                });
                porPai.forEach((irmaos) => {
                    const fixados = irmaos.filter(w => pinned.has(w.dataset.cbSection));
                    const resto = irmaos.filter(w => !pinned.has(w.dataset.cbSection));
                    const ordemFinal = [...fixados, ...resto];
                    // Reinsere na nova ordem sem tirar os nós do lugar à toa
                    // (evita perder listeners/estado interno de cada seção).
                    let referencia = null;
                    ordemFinal.forEach((wrapper) => {
                        if (referencia) referencia.after(wrapper);
                        else wrapper.parentElement.prepend(wrapper);
                        referencia = wrapper;
                    });
                });
            }

            aplicarEstadoVisual();
            reordenarNoDOM();

            wrappers.forEach((wrapper) => {
                const chave = wrapper.dataset.cbSection;
                const pinBtn = wrapper.querySelector('.cb-pin-btn');
                if (!pinBtn) return;
                pinBtn.addEventListener('click', (e) => {
                    e.stopPropagation(); // não deixa o clique também colapsar/expandir a seção
                    if (pinned.has(chave)) pinned.delete(chave);
                    else pinned.add(chave);
                    chrome.storage.local.set({ cbPinnedSections: Array.from(pinned) });
                    aplicarEstadoVisual();
                    reordenarNoDOM();
                });
            });
        });
    }
    cbInitPinnable();
});

// ===================== CRONÔMETRO: CÍRCULO x PLANETA =====================
// Bloco independente e aditivo, no mesmo molde do "MODO DE INTERFACE" logo
// abaixo: só decide se planeta.css fica ativo ou não, sem mexer em mais
// nada. Padrão é SEMPRE o círculo clássico (o <html> já nasce com a classe
// "cb-timer-classico" e o <link> de planeta.css já nasce "disabled" — ver
// popup.html) — aqui só troca pra "planeta" se a pessoa tiver escolhido
// isso explicitamente nas Configurações, e volta pro padrão em qualquer
// outro caso (primeira instalação, valor inesperado no storage etc).
document.addEventListener('DOMContentLoaded', () => {
    const linkPlaneta = document.getElementById('planeta-css-link');
    const btnClassico = document.getElementById('btn-timer-classico');
    const btnPlaneta = document.getElementById('btn-timer-planeta');

    function aplicarEstiloTimer(estilo) {
        const planeta = estilo === 'planeta';
        if (linkPlaneta) linkPlaneta.disabled = !planeta;
        document.documentElement.classList.toggle('cb-timer-classico', !planeta);
        btnClassico?.classList.toggle('active', !planeta);
        btnPlaneta?.classList.toggle('active', planeta);
    }

    if (chrome?.storage?.local) {
        chrome.storage.local.get(['cbEstiloTimer'], (result) => {
            aplicarEstiloTimer(result.cbEstiloTimer === 'planeta' ? 'planeta' : 'classico');
        });
    } else {
        aplicarEstiloTimer('classico');
    }

    btnClassico?.addEventListener('click', () => {
        chrome.storage.local.set({ cbEstiloTimer: 'classico' });
        // Mantém o cache síncrono (lido no <script> inline do <head>, antes
        // de qualquer pintura) em dia — sem isso, a PRÓXIMA abertura do
        // popup voltaria a mostrar o estilo antigo por uma fração de
        // segundo até o chrome.storage.local.get() corrigir.
        try { localStorage.setItem('cbEstiloTimer', 'classico'); } catch (e) {}
        aplicarEstiloTimer('classico');
    });
    btnPlaneta?.addEventListener('click', () => {
        chrome.storage.local.set({ cbEstiloTimer: 'planeta' });
        try { localStorage.setItem('cbEstiloTimer', 'planeta'); } catch (e) {}
        aplicarEstiloTimer('planeta');
    });
});

// ===================== MODO DE INTERFACE: NOVO x ANTIGO (Home resumida) =====================
// Bloco independente e aditivo: só lê o que já existe na tela (não recalcula nada),
// então não interfere na lógica original mesmo se algum elemento não existir.
document.addEventListener('DOMContentLoaded', () => {
    const body = document.body;
    const btnNovo = document.getElementById('btn-modo-novo');
    const btnAntigo = document.getElementById('btn-modo-antigo');

    function aplicarModoInterface(modo) {
        body.classList.remove('modo-novo', 'modo-antigo');
        body.classList.add(modo === 'antigo' ? 'modo-antigo' : 'modo-novo');
        btnNovo?.classList.toggle('active', modo !== 'antigo');
        btnAntigo?.classList.toggle('active', modo === 'antigo');
        (window.cbAoTrocarModoInterface || []).forEach(fn => fn(modo === 'antigo' ? 'antigo' : 'novo'));
    }

    if (chrome?.storage?.local) {
        chrome.storage.local.get(['cbInterfaceMode'], (result) => {
            aplicarModoInterface(result.cbInterfaceMode || 'novo');
        });
    } else {
        aplicarModoInterface('novo');
    }

    btnNovo?.addEventListener('click', () => {
        chrome.storage.local.set({ cbInterfaceMode: 'novo' });
        aplicarModoInterface('novo');
    });
    btnAntigo?.addEventListener('click', () => {
        chrome.storage.local.set({ cbInterfaceMode: 'antigo' });
        aplicarModoInterface('antigo');
    });

    // ---------- Espelhamento de dados para o painel "Home Novo" ----------
    const hnEditalRow = document.getElementById('hn-edital-row');
    const hnEditalDias = document.getElementById('hn-edital-dias');
    const hnBlockPriority = document.getElementById('hn-block-priority');
    const hnFocoNome = document.getElementById('hn-foco-nome');
    const hnFocoMeta = document.getElementById('hn-foco-meta');
    const hnBlockStreak = document.getElementById('hn-block-streak');
    const hnStreakTexto = document.getElementById('hn-streak-texto');

    function copiarEdital() {
        const dias = document.getElementById('edital-days-number');
        const ativo = document.getElementById('edital-active-state');
        const ativoVisivel = ativo && ativo.style.display !== 'none';
        if (dias && ativoVisivel && dias.textContent.trim() !== '') {
            hnEditalDias.textContent = dias.textContent.trim();
            hnEditalRow.style.display = 'flex';
        } else if (hnEditalRow) {
            hnEditalRow.style.display = 'none';
        }
    }

    // ---------- Arrastar "Foco de hoje" pra esquerda pra dispensar o dia ----------
    const CB_FOCO_HOJE_DISPENSADO_KEY = 'cbFocoHojeDispensadoData';
    function cbHojeStr() {
        const d = new Date();
        return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
    }
    let focoHojeDispensadoHoje = false;
    if (chrome?.storage?.local) {
        chrome.storage.local.get([CB_FOCO_HOJE_DISPENSADO_KEY], (result) => {
            focoHojeDispensadoHoje = result[CB_FOCO_HOJE_DISPENSADO_KEY] === cbHojeStr();
            if (focoHojeDispensadoHoje && hnBlockPriority) hnBlockPriority.style.display = 'none';
        });
    }

    if (hnBlockPriority) {
        let arrastando = false, xInicial = 0, deltaX = 0;
        hnBlockPriority.style.touchAction = 'pan-y';
        hnBlockPriority.addEventListener('pointerdown', (e) => {
            if (e.target.closest('#hn-btn-estudar')) return; // não atrapalha o clique no botão
            arrastando = true;
            xInicial = e.clientX;
            hnBlockPriority.setPointerCapture(e.pointerId);
            hnBlockPriority.style.transition = 'none';
        });
        hnBlockPriority.addEventListener('pointermove', (e) => {
            if (!arrastando) return;
            deltaX = Math.min(0, e.clientX - xInicial); // só permite arrastar pra esquerda
            hnBlockPriority.style.transform = `translateX(${deltaX}px)`;
            hnBlockPriority.style.opacity = String(Math.max(0.15, 1 + deltaX / 220));
        });
        function finalizarArrasto() {
            if (!arrastando) return;
            arrastando = false;
            hnBlockPriority.style.transition = 'transform 0.25s ease, opacity 0.25s ease';
            if (deltaX < -90) {
                // Passou do limite: some da tela e não volta hoje.
                hnBlockPriority.style.transform = 'translateX(-140%)';
                hnBlockPriority.style.opacity = '0';
                focoHojeDispensadoHoje = true;
                chrome.storage.local.set({ [CB_FOCO_HOJE_DISPENSADO_KEY]: cbHojeStr() });
                setTimeout(() => { hnBlockPriority.style.display = 'none'; }, 250);
            } else {
                // Não passou do limite: volta pro lugar.
                hnBlockPriority.style.transform = 'translateX(0)';
                hnBlockPriority.style.opacity = '1';
            }
            deltaX = 0;
        }
        hnBlockPriority.addEventListener('pointerup', finalizarArrasto);
        hnBlockPriority.addEventListener('pointercancel', finalizarArrasto);
    }

    function copiarPrioridade() {
        if (focoHojeDispensadoHoje) return; // usuário já dispensou o card de hoje arrastando
        const nome = document.querySelector('#questoes-prioridade-render .questoes-prioridade-nome');
        const meta = document.querySelector('#questoes-prioridade-render .questoes-prioridade-meta');
        if (hnBlockPriority) {
            if (nome) {
                if (hnFocoNome) hnFocoNome.textContent = nome.textContent.trim();
                if (hnFocoMeta) hnFocoMeta.textContent = meta ? meta.textContent.replace(/\s+/g, ' ').trim() : '';
                hnBlockPriority.style.display = 'block';
            } else {
                hnBlockPriority.style.display = 'none';
            }
        }

        const streak = document.querySelector('#questoes-prioridade-render .questoes-streak-card span');
        if (hnBlockStreak) {
            if (streak) {
                if (hnStreakTexto) hnStreakTexto.textContent = streak.textContent.trim();
                hnBlockStreak.style.display = 'block';
            } else {
                hnBlockStreak.style.display = 'none';
            }
        }
    }

    function copiarMeta() {
        // "Seu dia" (mini barra de progresso) foi removido do painel inicial
        // — a meta diária completa já aparece no cartão "Meta Diária" logo
        // abaixo. Função mantida vazia (chamada por sincronizarHomeNovo) só
        // pra não quebrar o observer, caso algo volte a depender dela.
    }

    function sincronizarHomeNovo() {
        copiarEdital();
        copiarPrioridade();
        copiarMeta();
    }

    // Observa os elementos originais e replica no painel novo, sem duplicar
    // a lógica de cálculo já existente no restante do popup.js.
    const alvoEdital = document.getElementById('edital-card');
    const alvoPrioridade = document.getElementById('questoes-prioridade-render');
    const alvoGoal = document.getElementById('goal-text');

    if (alvoEdital) new MutationObserver(sincronizarHomeNovo).observe(alvoEdital, { childList: true, subtree: true, attributes: true, characterData: true });
    if (alvoPrioridade) new MutationObserver(sincronizarHomeNovo).observe(alvoPrioridade, { childList: true, subtree: true, characterData: true });
    if (alvoGoal) new MutationObserver(sincronizarHomeNovo).observe(alvoGoal, { childList: true, characterData: true, subtree: true });

    // Cópia inicial (os dados originais chegam de forma assíncrona via chrome.storage)
    setTimeout(sincronizarHomeNovo, 400);
    setTimeout(sincronizarHomeNovo, 1200);

    // ---------- Ações rápidas do painel novo ----------
    // Antes só tentava clicar numa aba interna do popup (tab-questoes), o que
    // na prática não "abria" nada de útil pra estudar — o pedido é ir direto
    // pro site de questões de verdade. Se já tiver uma aba de um site de
    // questões aberta em qualquer janela, foca nela; senão abre uma nova.
    document.getElementById('hn-btn-estudar')?.addEventListener('click', () => {
        // Esse é o "site da extensão" — o painel companheiro (Cronômetro/
        // Questões/Painel/Agenda) usado também pro pareamento do celular,
        // mesmo link já cadastrado em #celular-link-texto.
        const CB_URL_ESTUDAR = 'https://bcursos2025-dot.github.io/timer.html/timer.html';
        if (!chrome?.tabs) { window.open(CB_URL_ESTUDAR, '_blank'); return; }
        chrome.tabs.query({}, (tabs) => {
            const existente = (tabs || []).find(t => {
                if (!t.url) return false;
                try { return new URL(t.url).hostname.replace(/^www\./, '') === 'bcursos2025-dot.github.io'; }
                catch (e) { return false; }
            });
            if (existente) {
                chrome.tabs.update(existente.id, { active: true, url: CB_URL_ESTUDAR });
                if (existente.windowId != null && chrome.windows?.update) {
                    chrome.windows.update(existente.windowId, { focused: true });
                }
            } else {
                chrome.tabs.create({ url: CB_URL_ESTUDAR });
            }
            window.close();
        });
    });
});

// ===================== TEXTOS DE EXPLICAÇÃO MINIMIZÁVEIS =====================
// Os parágrafos ".tab-hint" (o texto explicando o gráfico "Geral", etc.)
// ficavam sempre visíveis e tomando espaço fixo. Agora eles nascem
// escondidos atrás de um botãozinho de olho — quem quiser reler, clica.
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.tab-hint').forEach((hint) => {
        if (hint.dataset.hintWrapped) return;
        hint.dataset.hintWrapped = '1';

        const wrap = document.createElement('div');
        wrap.className = 'tab-hint-wrap';
        hint.parentNode.insertBefore(wrap, hint);

        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'tab-hint-toggle';
        btn.title = 'Mostrar/ocultar explicação';
        btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7Z"/><circle cx="12" cy="12" r="3"/></svg>';

        hint.classList.add('collapsed');
        wrap.appendChild(btn);
        wrap.appendChild(hint);

        btn.addEventListener('click', () => {
            hint.classList.toggle('collapsed');
            btn.classList.toggle('active');
        });
    });
});

// ===================== METEOROS NOTURNOS =====================
// Um risquinho de luz cruzando o céu da Terra à noite, de vez em quando —
// nunca em ritmo previsível (a cada 2 a 5 minutos), e quase sempre um só,
// raramente dois quase juntos. Só tem efeito visual quando <html> está
// com a classe "cb-noite" e o cronômetro está parado (a aparência em si
// já cuida disso lá no planeta.css); aqui só decide QUANDO disparar.
(function () {
    const prefereReduzido = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefereReduzido) return;

    function criarMeteoro(container) {
        const span = document.createElement('span');
        span.className = 'cb-meteoro';
        const topo = 6 + Math.random() * 46;    // % — fica na faixa de céu, não desce pro chão/oceano
        const esquerda = Math.random() * 68;    // % — nasce sem já sair correndo pela borda direita
        const angulo = 18 + Math.random() * 20; // leve variação de inclinação, pra não ficar sempre igual
        span.style.top = topo + '%';
        span.style.left = esquerda + '%';
        span.style.transform = 'rotate(' + angulo + 'deg)';

        const risco = document.createElement('span');
        risco.className = 'cb-meteoro-riscoo';
        risco.style.animationDuration = (750 + Math.random() * 500) + 'ms';
        span.appendChild(risco);

        container.appendChild(span);
        setTimeout(() => span.remove(), 1600);
    }

    function disparar() {
        document.querySelectorAll('.cb-meteoros').forEach((container) => {
            if (document.visibilityState === 'hidden') return;
            const rect = container.getBoundingClientRect();
            if (!rect.width || !rect.height) return; // card fora da tela/colapsado agora

            criarMeteoro(container);
            // Na maior parte das vezes passa só um; de vez em quando, dois
            // quase juntos — como estrelas cadentes de verdade costumam vir.
            if (Math.random() < 0.3) {
                setTimeout(() => criarMeteoro(container), 200 + Math.random() * 350);
            }
        });
    }

    function agendarProximo() {
        const espera = 120000 + Math.random() * 180000; // 2 a 5 minutos
        setTimeout(() => {
            disparar();
            agendarProximo();
        }, espera);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', agendarProximo);
    } else {
        agendarProximo();
    }
})();

// ===================== SATÉLITE — 00h/12h =====================
// Um pontinho pequeno cruzando o card na diagonal, rápido, às 00:00 e
// 12:00 no horário do computador — a aparência (planeta.css, "cb-satelite")
// já cuida de deixar isso discreto; aqui só decide QUANDO e por ONDE
// ele passa. Diferente do meteoro, não é aleatório: por isso confere o
// relógio (a cada 15s é suficiente pra não perder a virada do minuto)
// e guarda no localStorage a última hora em que já disparou, pra nunca
// repetir duas vezes na mesma janela — sem isso, cada checagem dentro
// do minuto 00 criaria um satélite novo.
(function () {
    const prefereReduzido = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefereReduzido) return;

    function criarSatelite(container) {
        const rect = container.getBoundingClientRect();
        if (!rect.width || !rect.height) return; // card fora da tela/colapsado agora

        const sat = document.createElement('div');
        sat.className = 'cb-satelite';

        // Sempre de canto a canto (nasce e morre fora do card, um pouco
        // além da borda), sorteando a diagonal pra não repetir sempre o
        // mesmo sentido nas duas passagens do dia.
        const deCimaPraBaixo = Math.random() < 0.5;
        const x0 = -14, x1 = rect.width + 14;
        const y0 = deCimaPraBaixo ? -14 : rect.height + 14;
        const y1 = deCimaPraBaixo ? rect.height + 14 : -14;

        sat.style.setProperty('--sx0', x0 + 'px');
        sat.style.setProperty('--sy0', y0 + 'px');
        sat.style.setProperty('--sx1', x1 + 'px');
        sat.style.setProperty('--sy1', y1 + 'px');
        sat.style.animationDuration = (1700 + Math.random() * 400) + 'ms'; // rápido, bem longe

        container.appendChild(sat);
        setTimeout(() => sat.remove(), 2400);
    }

    function disparar() {
        document.querySelectorAll('.cb-satelites').forEach((container) => {
            if (document.visibilityState === 'hidden') return;
            criarSatelite(container);
        });
    }

    function checarHorario() {
        const agora = new Date();
        const h = agora.getHours();
        const m = agora.getMinutes();
        if (m !== 0 || (h !== 0 && h !== 12)) return;

        const chave = 'cbSateliteUltimaPassagem';
        const marcador = agora.toDateString() + '-' + h; // 1x por dia por horário (00h e 12h)
        if (localStorage.getItem(chave) === marcador) return;
        localStorage.setItem(chave, marcador);
        disparar();
    }

    function iniciar() {
        checarHorario();
        setInterval(checarHorario, 15000);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', iniciar);
    } else {
        iniciar();
    }
})();

// ===================== MODO DE ECONOMIA (monitor de CPU/RAM) =====================
// Mesmo mecanismo do content script global (ver overlay-global/global_overlay.js,
// bloco "MODO DE ECONOMIA") aplicado aqui dentro do popup: mede o tempo real
// entre frames via requestAnimationFrame como proxy de carga do processador
// (não existe API de extensão pra ler CPU/RAM do sistema), e some com o
// glow/blur decorativo do anel por alguns minutos quando o aparelho está
// visivelmente sufocado. NUNCA mexe no cronômetro em si — só na classe CSS
// 'cb-perf-safe-mode' em <html>, que style.css usa pra desligar animação e
// backdrop-filter (ver ".cb-ring-aura" etc. logo abaixo do bloco
// prefers-reduced-motion).
(function cbMonitorDesempenhoPopup() {
    const JANELA_AMOSTRAS = 30;
    const LIMIAR_MS = 42;
    const CONFIRMACOES_NECESSARIAS = 3;
    const SAFE_MODE_DURACAO_MS = 3 * 60 * 1000;

    let amostras = [];
    let ultimoFrame = 0;
    let confirmacoesRuins = 0;
    let safeModeAteTs = 0;
    let safeModeAtivo = false;

    function checarMemoria() {
        const mem = performance.memory;
        if (!mem || !mem.jsHeapSizeLimit) return false;
        return (mem.usedJSHeapSize / mem.jsHeapSizeLimit) > 0.92;
    }

    function ativarSafeMode() {
        safeModeAteTs = Date.now() + SAFE_MODE_DURACAO_MS;
        if (safeModeAtivo) return;
        safeModeAtivo = true;
        document.documentElement.classList.add('cb-perf-safe-mode');
    }

    function checarFimSafeMode() {
        if (safeModeAtivo && Date.now() >= safeModeAteTs) {
            safeModeAtivo = false;
            document.documentElement.classList.remove('cb-perf-safe-mode');
        }
    }

    function frameTick(agora) {
        if (ultimoFrame) {
            const delta = agora - ultimoFrame;
            amostras.push(delta);
            if (amostras.length >= JANELA_AMOSTRAS) {
                const media = amostras.reduce((a, b) => a + b, 0) / amostras.length;
                amostras = [];
                if (media > LIMIAR_MS || checarMemoria()) {
                    confirmacoesRuins++;
                    if (confirmacoesRuins >= CONFIRMACOES_NECESSARIAS) ativarSafeMode();
                } else {
                    confirmacoesRuins = 0;
                }
            }
        }
        ultimoFrame = agora;
        checarFimSafeMode();
        requestAnimationFrame(frameTick);
    }

    // Modo leve já corta tudo que o monitor cortaria: não mantém o laço de frames rodando.
    if (!document.documentElement.classList.contains('cb-lite')) requestAnimationFrame(frameTick);
})();

// ===================== ABA JUS: BUSCA DE JURISPRUDÊNCIA =====================
// Usa a API REST pública do Jurisprudências.ai (jurisprudencias.ai/api).
// Cada pessoa gera seu próprio token gratuito em jurisprudencias.ai/api-tokens
// e cola na aba — o token fica só em chrome.storage.local, nunca é enviado
// pra nenhum servidor além da própria jurisprudencias.ai (ver host_permissions
// no manifest.json). Bloco independente e aditivo: não mexe em nada do resto
// do popup, só lê seus próprios elementos (#cb-jus-*).
document.addEventListener('DOMContentLoaded', () => {
    const CB_JUS_API_BASE = 'https://jurisprudencias.ai/api/v1';
    const CB_JUS_TOKEN_KEY = 'cbJusApiToken';

    const CB_JUS_TRIBUNAIS = [
        { id: 'stf', nome: 'STF — Supremo Tribunal Federal' },
        { id: 'stj', nome: 'STJ — Superior Tribunal de Justiça' },
        { id: 'tst', nome: 'TST — Tribunal Superior do Trabalho' },
        { id: 'trt1', nome: 'TRT 1ª Região (RJ)' },
        { id: 'trt2', nome: 'TRT 2ª Região (SP)' },
        { id: 'trt3', nome: 'TRT 3ª Região (MG)' },
        { id: 'trt4', nome: 'TRT 4ª Região (RS)' },
        { id: 'trt5', nome: 'TRT 5ª Região (BA)' },
        { id: 'trt6', nome: 'TRT 6ª Região (PE)' },
        { id: 'trt7', nome: 'TRT 7ª Região (CE)' },
        { id: 'trt8', nome: 'TRT 8ª Região (PA/AP)' },
        { id: 'trt9', nome: 'TRT 9ª Região (PR)' },
        { id: 'trt10', nome: 'TRT 10ª Região (DF/TO)' },
        { id: 'trt13', nome: 'TRT 13ª Região (PB)' },
        { id: 'trt14', nome: 'TRT 14ª Região (RO/AC)' },
        { id: 'trt16', nome: 'TRT 16ª Região (MA)' },
        { id: 'trt17', nome: 'TRT 17ª Região (ES)' },
        { id: 'trt18', nome: 'TRT 18ª Região (GO)' },
        { id: 'trt19', nome: 'TRT 19ª Região (AL)' },
        { id: 'trt20', nome: 'TRT 20ª Região (SE)' },
        { id: 'trt22', nome: 'TRT 22ª Região (PI)' },
        { id: 'trt23', nome: 'TRT 23ª Região (MT)' },
        { id: 'trt24', nome: 'TRT 24ª Região (MS)' },
        { id: 'trf1', nome: 'TRF 1ª Região' },
        { id: 'trf2', nome: 'TRF 2ª Região' },
        { id: 'trf3', nome: 'TRF 3ª Região' },
        { id: 'trf4', nome: 'TRF 4ª Região' },
        { id: 'trf5', nome: 'TRF 5ª Região' },
        { id: 'trf6', nome: 'TRF 6ª Região' },
        { id: 'tjac', nome: 'TJ-AC' }, { id: 'tjap', nome: 'TJ-AP' }, { id: 'tjba', nome: 'TJ-BA' },
        { id: 'tjce', nome: 'TJ-CE' }, { id: 'tjdft', nome: 'TJ-DFT' }, { id: 'tjes', nome: 'TJ-ES' },
        { id: 'tjgo', nome: 'TJ-GO' }, { id: 'tjma', nome: 'TJ-MA' }, { id: 'tjmg', nome: 'TJ-MG' },
        { id: 'tjms', nome: 'TJ-MS' }, { id: 'tjmt', nome: 'TJ-MT' }, { id: 'tjpa', nome: 'TJ-PA' },
        { id: 'tjpb', nome: 'TJ-PB' }, { id: 'tjpe', nome: 'TJ-PE' }, { id: 'tjpr', nome: 'TJ-PR' },
        { id: 'tjrj', nome: 'TJ-RJ' }, { id: 'tjrn', nome: 'TJ-RN' }, { id: 'tjro', nome: 'TJ-RO' },
        { id: 'tjrr', nome: 'TJ-RR' }, { id: 'tjrs', nome: 'TJ-RS' }, { id: 'tjsc', nome: 'TJ-SC' },
        { id: 'tjse', nome: 'TJ-SE' }, { id: 'tjsp', nome: 'TJ-SP' }, { id: 'tjto', nome: 'TJ-TO' },
        { id: 'carf', nome: 'CARF' },
    ];

    const elTab = document.getElementById('tab-jus');
    if (!elTab) return; // aba não existe nesta versão do popup.html — não quebra o resto

    const elConta = document.getElementById('cb-jus-conta');
    const elContaPonto = document.getElementById('cb-jus-conta-ponto');
    const elContaTexto = document.getElementById('cb-jus-conta-texto');
    const elContaBtn = document.getElementById('cb-jus-conta-btn');
    const elContaForm = document.getElementById('cb-jus-conta-form');
    const elTokenInput = document.getElementById('cb-jus-token-input');
    const elTokenMostrar = document.getElementById('cb-jus-token-mostrar');
    const elTribunal = document.getElementById('cb-jus-tribunal');
    const elQuery = document.getElementById('cb-jus-query');
    const elBuscar = document.getElementById('cb-jus-buscar');
    const elToggleFiltros = document.getElementById('cb-jus-toggle-filtros');
    const elFiltros = document.getElementById('cb-jus-filtros');
    const elPubFrom = document.getElementById('cb-jus-pub-from');
    const elPubTo = document.getElementById('cb-jus-pub-to');
    const elTrialFrom = document.getElementById('cb-jus-trial-from');
    const elTrialTo = document.getElementById('cb-jus-trial-to');
    const elSort = document.getElementById('cb-jus-sort');
    const elLimite = document.getElementById('cb-jus-limite');
    const elLimiteFill = document.getElementById('cb-jus-limite-fill');
    const elLimiteTexto = document.getElementById('cb-jus-limite-texto');
    const elStatus = document.getElementById('cb-jus-status');
    const elResultados = document.getElementById('cb-jus-resultados');
    const elPaginacao = document.getElementById('cb-jus-paginacao');
    const elPagAnterior = document.getElementById('cb-jus-pag-anterior');
    const elPagProxima = document.getElementById('cb-jus-pag-proxima');
    const elPagAtual = document.getElementById('cb-jus-pag-atual');

    let cbJusPaginaAtual = 0;
    let cbJusTemProximaPagina = false;
    let cbJusBuscando = false;
    let cbJusTokenValido = false;
    let cbJusValidandoTimer = null;

    function cbJusEscapeHtml(s) {
        const div = document.createElement('div');
        div.textContent = s || '';
        return div.innerHTML;
    }

    const CB_JUS_TODOS_SENTINELA = '__todos__';
    elTribunal.innerHTML =
        `<option value="${CB_JUS_TODOS_SENTINELA}">🔎 Todos os tribunais</option>` +
        CB_JUS_TRIBUNAIS.map(t => `<option value="${t.id}">${cbJusEscapeHtml(t.nome)}</option>`).join('');
    elTribunal.value = 'stj';

    function cbJusNomeTribunal(id) {
        const t = CB_JUS_TRIBUNAIS.find(x => x.id === id);
        return t ? t.nome : (id || '').toUpperCase();
    }

    // --------------------------------------------------------------------
    // CONEXÃO DA CONTA — gerar o token exige entrar em jurisprudencias.ai
    // (e-mail ou Google/Microsoft), então isso não dá pra automatizar por
    // fora com segurança. O que a extensão faz por você: abre a página
    // certa numa aba nova (cbJusAbrirConexao) e, assim que o token é colado
    // aqui, valida contra a API sozinha e salva — sem precisar clicar em
    // "Salvar" nem nada.
    // --------------------------------------------------------------------
    function cbJusAtualizarStatusConta(estado, mensagem) {
        elContaPonto.className = 'cb-jus-conta-ponto ' + estado; // 'ok' | 'erro' | '' (neutro)
        elContaTexto.textContent = mensagem;
    }

    function cbJusAbrirFormConexao() {
        elContaForm.hidden = false;
        elTokenInput.focus();
    }

    async function cbJusValidarToken(token) {
        try {
            const resp = await fetch(`${CB_JUS_API_BASE}/courts`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            return resp.ok;
        } catch (e) {
            return null; // sem internet / API fora do ar — não dá pra confirmar nem negar
        }
    }

    async function cbJusChecarESalvarToken(token, { silencioso } = {}) {
        if (!token) {
            chrome.storage.local.remove(CB_JUS_TOKEN_KEY);
            cbJusTokenValido = false;
            cbJusAtualizarStatusConta('', 'Conecte sua conta pra começar a buscar');
            elContaBtn.textContent = 'Conectar';
            return;
        }
        if (!silencioso) cbJusAtualizarStatusConta('', 'Conferindo token...');
        const ok = await cbJusValidarToken(token);
        if (ok === true) {
            chrome.storage.local.set({ [CB_JUS_TOKEN_KEY]: token });
            cbJusTokenValido = true;
            cbJusAtualizarStatusConta('ok', 'Conta conectada');
            elContaBtn.textContent = 'Trocar';
            elContaForm.hidden = true;
        } else if (ok === false) {
            cbJusTokenValido = false;
            cbJusAtualizarStatusConta('erro', 'Token inválido — confira se copiou certo');
        } else if (!silencioso) {
            cbJusAtualizarStatusConta('erro', 'Sem conexão pra conferir o token agora');
        }
    }

    chrome.storage.local.get([CB_JUS_TOKEN_KEY], (result) => {
        const tokenSalvo = result[CB_JUS_TOKEN_KEY];
        if (tokenSalvo) {
            elTokenInput.value = tokenSalvo;
            // Confia no que já tava salvo (não gasta cota de API toda vez
            // que o popup abre) — só reconfere de verdade se o token salvo
            // vier a falhar numa busca de verdade (ver cbJusBuscarDecisoes).
            cbJusTokenValido = true;
            cbJusAtualizarStatusConta('ok', 'Conta conectada');
            elContaBtn.textContent = 'Trocar';
        } else {
            cbJusAtualizarStatusConta('', 'Conecte sua conta pra começar a buscar');
        }
    });

    elContaBtn.addEventListener('click', () => {
        chrome.tabs.create({ url: 'https://jurisprudencias.ai/api-tokens' });
        cbJusAbrirFormConexao();
    });

    elTokenMostrar.addEventListener('click', () => {
        elTokenInput.type = elTokenInput.type === 'password' ? 'text' : 'password';
    });

    // Auto-salva: valida um pouquinho depois de parar de digitar/colar, sem
    // precisar de um botão "Salvar" separado — cola e pronto.
    elTokenInput.addEventListener('input', () => {
        clearTimeout(cbJusValidandoTimer);
        const token = elTokenInput.value.trim();
        if (!token) {
            cbJusChecarESalvarToken('');
            return;
        }
        cbJusValidandoTimer = setTimeout(() => cbJusChecarESalvarToken(token), 500);
    });

    elToggleFiltros.addEventListener('click', () => {
        elFiltros.hidden = !elFiltros.hidden;
        elToggleFiltros.classList.toggle('aberto', !elFiltros.hidden);
    });

    // --------------------------------------------------------------------
    // BARRA DE COTA DIÁRIA — a API devolve X-RateLimit-Limit/Remaining em
    // toda resposta (ver docs do Jurisprudências.ai). Guarda o último valor
    // visto em chrome.storage.local pra já mostrar a barra assim que a aba
    // abre, mesmo antes da pessoa buscar de novo naquela sessão do popup.
    // --------------------------------------------------------------------
    const CB_JUS_LIMITE_KEY = 'cbJusUltimoLimite';

    function cbJusPintarLimite(limite, restante) {
        if (limite == null || restante == null || !isFinite(limite) || limite <= 0) {
            elLimite.hidden = true;
            return;
        }
        const usado = Math.max(0, limite - restante);
        const pct = Math.min(100, Math.round((usado / limite) * 100));
        elLimiteFill.style.width = pct + '%';
        elLimiteFill.classList.toggle('cb-jus-limite-alerta', restante <= Math.max(1, Math.ceil(limite * 0.2)));
        elLimiteFill.classList.toggle('cb-jus-limite-esgotado', restante <= 0);
        elLimiteTexto.textContent = `${usado}/${limite} buscas usadas hoje`;
        elLimite.hidden = false;
    }

    function cbJusAtualizarLimite(resp) {
        const restante = parseInt(resp.headers.get('X-RateLimit-Remaining'), 10);
        const limite = parseInt(resp.headers.get('X-RateLimit-Limit'), 10);
        if (isNaN(restante) || isNaN(limite)) return;
        chrome.storage.local.set({ [CB_JUS_LIMITE_KEY]: { limite, restante, ts: Date.now() } });
        cbJusPintarLimite(limite, restante);
    }

    chrome.storage.local.get([CB_JUS_LIMITE_KEY], (result) => {
        const info = result[CB_JUS_LIMITE_KEY];
        // Só mostra o que já tava salvo se for de menos de 24h atrás — a
        // cota reseta por dia (fuso de Brasília), então um número de ontem
        // ia só confundir em vez de ajudar.
        if (info && (Date.now() - info.ts) < 24 * 60 * 60 * 1000) {
            cbJusPintarLimite(info.limite, info.restante);
        }
    });

    function cbJusMensagemErro(status, corpo) {
        if (status === 401) return 'Token inválido ou expirado — clique em "Trocar" e conecte de novo.';
        if (status === 429) return 'Limite diário de buscas atingido. Volta amanhã ou assina um plano maior em jurisprudencias.ai.';
        if (status === 422) return 'Parâmetros de busca inválidos — revise o termo ou as datas.';
        if (status === 404) return 'Nada encontrado.';
        return (corpo && corpo.error && corpo.error.message) || `Erro ao buscar (HTTP ${status}).`;
    }

    function cbJusRenderResultados(itens) {
        if (!itens || !itens.length) {
            elResultados.innerHTML = '<div class="cb-jus-vazio">Nenhuma decisão encontrada para essa busca.</div>';
            return;
        }
        elResultados.innerHTML = itens.map((d) => `
            <div class="cb-jus-card">
                <div class="cb-jus-card-top">
                    <span class="cb-jus-processo">${cbJusEscapeHtml(d.process_number || '')}</span>
                    ${d.publication_date ? `<span class="cb-jus-data">Publicado em ${cbJusEscapeHtml(d.publication_date)}</span>` : ''}
                </div>
                ${d._tribunalNome ? `<div class="cb-jus-tribunal-badge">${cbJusEscapeHtml(d._tribunalNome)}</div>` : ''}
                ${(d.adjudicating_body || d.rapporteur) ? `<div class="cb-jus-meta">${[d.adjudicating_body, d.rapporteur].filter(Boolean).map(cbJusEscapeHtml).join(' · ')}</div>` : ''}
                ${d.excerpt ? `<div class="cb-jus-trecho">${cbJusEscapeHtml(d.excerpt)}</div>` : ''}
                ${d.url ? `<a class="cb-jus-link" href="${cbJusEscapeHtml(d.url)}" target="_blank" rel="noopener">Ver íntegra ↗</a>` : ''}
            </div>
        `).join('');
    }

    // --------------------------------------------------------------------
    // "Todos os tribunais" — a API não tem endpoint de busca cross-tribunal
    // (cada busca é sempre /courts/:id/decisions, um tribunal por vez), então
    // pra cobrir todos precisamos de uma chamada por tribunal. Isso consome
    // uma unidade de cota POR TRIBUNAL (52 no total) — pesado até pra quem
    // paga, e praticamente impossível no plano grátis (5 buscas/dia). Por
    // isso avisa e pede confirmação antes de disparar, roda em lotes
    // pequenos (não 52 de uma vez) e para na hora se a cota acabar no meio
    // (HTTP 429), mostrando o que já tinha achado até ali em vez de jogar
    // fora.
    // --------------------------------------------------------------------
    const CB_JUS_LOTE_CONCORRENCIA = 4;

    async function cbJusBuscarEmTodosOsTribunais(token, termo, params, pagina) {
        const totalTribunais = CB_JUS_TRIBUNAIS.length;
        if (pagina === 0) {
            const ok = confirm(
                `Buscar em todos os ${totalTribunais} tribunais faz uma busca separada em cada um — ` +
                `isso consome ${totalTribunais} unidades da sua cota diária de uma vez só. ` +
                `Quer continuar?`
            );
            if (!ok) return null;
        }

        const fila = CB_JUS_TRIBUNAIS.slice();
        const encontrados = [];
        let pararPorCota = false;
        let ultimaResp = null;

        async function processarUm(tribunal) {
            if (pararPorCota) return;
            try {
                const resp = await fetch(
                    `${CB_JUS_API_BASE}/courts/${encodeURIComponent(tribunal.id)}/decisions?${params.toString()}`,
                    { headers: { Authorization: `Bearer ${token}` } }
                );
                ultimaResp = resp;
                cbJusAtualizarLimite(resp);
                if (resp.status === 429) { pararPorCota = true; return; }
                if (!resp.ok) return; // um tribunal falhando não derruba a busca inteira
                const corpo = await resp.json().catch(() => null);
                (corpo && corpo.data || []).forEach(d => {
                    d._tribunalNome = tribunal.nome;
                    d._tribunalId = tribunal.id;
                    encontrados.push(d);
                });
            } catch (e) {
                // um tribunal fora do ar não deve travar os outros
            }
        }

        while (fila.length && !pararPorCota) {
            const lote = fila.splice(0, CB_JUS_LOTE_CONCORRENCIA);
            await Promise.all(lote.map(processarUm));
        }

        const campoData = elSort.value === 'trial_date' ? 'trial_date' : 'publication_date';
        encontrados.sort((a, b) => new Date(b[campoData] || 0) - new Date(a[campoData] || 0));

        return { itens: encontrados, pararPorCota, ultimaResp, tribunaisConsultados: totalTribunais - fila.length };
    }

    async function cbJusBuscarDecisoes(pagina) {
        if (cbJusBuscando) return;
        const token = elTokenInput.value.trim();
        const termo = elQuery.value.trim();
        if (!token) {
            cbJusAbrirFormConexao();
            elStatus.textContent = 'Conecte sua conta antes de buscar.';
            return;
        }
        if (!termo) {
            elStatus.textContent = 'Digite um termo de busca (ex: "dano moral").';
            return;
        }

        cbJusBuscando = true;
        elBuscar.disabled = true;
        elStatus.textContent = 'Buscando...';
        elResultados.innerHTML = '';
        elPaginacao.hidden = true;

        const params = new URLSearchParams({ q: termo, page: String(pagina) });
        if (elSort.value) params.set('sort_by', elSort.value);
        if (elPubFrom.value) params.set('pub_from', elPubFrom.value);
        if (elPubTo.value) params.set('pub_to', elPubTo.value);
        if (elTrialFrom.value) params.set('trial_from', elTrialFrom.value);
        if (elTrialTo.value) params.set('trial_to', elTrialTo.value);

        const tribunal = elTribunal.value;

        // Modo "todos os tribunais" — sem paginação de verdade (mistura 52
        // fontes diferentes), só busca a 1ª página de cada um e junta tudo.
        if (tribunal === CB_JUS_TODOS_SENTINELA) {
            try {
                const resultado = await cbJusBuscarEmTodosOsTribunais(token, termo, params, pagina);
                if (!resultado) { elStatus.textContent = 'Busca cancelada.'; return; } // confirm() negado
                cbJusRenderResultados(resultado.itens);
                elPaginacao.hidden = true;
                if (resultado.pararPorCota) {
                    elStatus.textContent = `Cota diária esgotada no meio da busca — ${resultado.itens.length} resultado(s) de ${resultado.tribunaisConsultados} tribunal(is) consultado(s) antes de parar.`;
                } else {
                    elStatus.textContent = `${resultado.itens.length} resultado(s) em ${resultado.tribunaisConsultados} tribunais.`;
                }
            } catch (e) {
                elStatus.textContent = 'Falha de conexão com a API do Jurisprudências.ai. Confira sua internet e tente de novo.';
                console.warn('[CB-JUS] erro ao buscar em todos os tribunais:', e);
            } finally {
                cbJusBuscando = false;
                elBuscar.disabled = false;
            }
            return;
        }

        try {
            const resp = await fetch(`${CB_JUS_API_BASE}/courts/${encodeURIComponent(tribunal)}/decisions?${params.toString()}`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            let corpo = null;
            try { corpo = await resp.json(); } catch (e) { /* resposta sem corpo JSON */ }
            cbJusAtualizarLimite(resp);

            if (!resp.ok) {
                elStatus.textContent = cbJusMensagemErro(resp.status, corpo);
                if (resp.status === 401) {
                    cbJusTokenValido = false;
                    cbJusAtualizarStatusConta('erro', 'Token inválido — reconecte sua conta');
                    elContaBtn.textContent = 'Conectar';
                }
                return;
            }

            cbJusPaginaAtual = pagina;
            cbJusTemProximaPagina = !!(corpo && corpo.meta && corpo.meta.has_next_page);
            cbJusRenderResultados(corpo && corpo.data);

            const qtd = (corpo && corpo.data && corpo.data.length) || 0;
            elStatus.textContent = `${qtd} resultado(s) em ${cbJusNomeTribunal(tribunal)} — página ${pagina + 1}.`;

            elPagAtual.textContent = `Página ${cbJusPaginaAtual + 1}`;
            elPagAnterior.disabled = cbJusPaginaAtual === 0;
            elPagProxima.disabled = !cbJusTemProximaPagina;
            elPaginacao.hidden = false;
        } catch (e) {
            elStatus.textContent = 'Falha de conexão com a API do Jurisprudências.ai. Confira sua internet e tente de novo.';
            console.warn('[CB-JUS] erro ao buscar decisões:', e);
        } finally {
            cbJusBuscando = false;
            elBuscar.disabled = false;
        }
    }

    elBuscar.addEventListener('click', () => cbJusBuscarDecisoes(0));
    elQuery.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') cbJusBuscarDecisoes(0);
    });
    elPagAnterior.addEventListener('click', () => {
        if (cbJusPaginaAtual > 0) cbJusBuscarDecisoes(cbJusPaginaAtual - 1);
    });
    elPagProxima.addEventListener('click', () => {
        if (cbJusTemProximaPagina) cbJusBuscarDecisoes(cbJusPaginaAtual + 1);
    });
});

// ===================== ABA DIÁRIO: BUSCA NO DIÁRIO OFICIAL MUNICIPAL =====================
// Usa a API REST pública do Querido Diário (Open Knowledge Brasil):
// https://queridodiario.ok.org.br/api — gratuita, sem chave/token, sem
// cadastro. Bloco independente e aditivo, igual ao da aba JUS: só lê seus
// próprios elementos (#cb-dou-*), não mexe em mais nada do popup.
document.addEventListener('DOMContentLoaded', () => {
    const CB_DOU_API_BASE = 'https://queridodiario.ok.org.br/api';
    const CB_DOU_MUNICIPIO_KEY = 'cbDouMunicipio';
    const CB_DOU_TAMANHO_PAGINA = 10;

    const elTab = document.getElementById('tab-dou');
    if (!elTab) return; // aba não existe nesta versão do popup.html — não quebra o resto

    const elMunicipioAtual = document.getElementById('cb-dou-municipio-atual');
    const elMunicipioPonto = document.getElementById('cb-dou-municipio-ponto');
    const elMunicipioTexto = document.getElementById('cb-dou-municipio-texto');
    const elTrocarMunicipio = document.getElementById('cb-dou-trocar-municipio');
    const elMunicipioForm = document.getElementById('cb-dou-municipio-form');
    const elMunicipioInput = document.getElementById('cb-dou-municipio-input');
    const elMunicipioBuscar = document.getElementById('cb-dou-municipio-buscar');
    const elMunicipioResultados = document.getElementById('cb-dou-municipio-resultados');
    const elQuery = document.getElementById('cb-dou-query');
    const elBuscar = document.getElementById('cb-dou-buscar');
    const elStatus = document.getElementById('cb-dou-status');
    const elResultados = document.getElementById('cb-dou-resultados');
    const elCarregarMais = document.getElementById('cb-dou-carregar-mais');

    let cbDouMunicipio = null; // { territory_id, territory_name, state_code }
    let cbDouOffsetAtual = 0;
    let cbDouTotalDisponivel = 0;
    let cbDouBuscando = false;

    function cbDouEscapeHtml(s) {
        const div = document.createElement('div');
        div.textContent = s || '';
        return div.innerHTML;
    }

    // O Querido Diário NÃO cobre todos os municípios: cada cidade da API traz
    // "availability_date" (desde quando há diários) e, quando vem vazio, a cidade existe
    // na lista mas não tem nenhum diário — qualquer busca volta com 0, mesmo sem termo.
    // Sem este aviso, "0 publicações" parecia um erro da busca. (availability_date
    // ausente = ainda não consultado: não afirma nada.)
    function cbDouSemCobertura(m) {
        return !!m && typeof m.availability_date === 'string' && m.availability_date === '';
    }

    function cbDouAtualizarChipMunicipio() {
        if (cbDouMunicipio) {
            elMunicipioPonto.className = 'cb-jus-conta-ponto' + (cbDouSemCobertura(cbDouMunicipio) ? '' : ' ok');
            elMunicipioTexto.textContent = `${cbDouMunicipio.territory_name} — ${cbDouMunicipio.state_code}` + (cbDouSemCobertura(cbDouMunicipio) ? ' · sem diários disponíveis' : '');
            elTrocarMunicipio.textContent = 'Trocar';
        } else {
            elMunicipioPonto.className = 'cb-jus-conta-ponto';
            elMunicipioTexto.textContent = 'Nenhum município selecionado';
            elTrocarMunicipio.textContent = 'Escolher';
        }
    }

    chrome.storage.local.get([CB_DOU_MUNICIPIO_KEY], (res) => {
        if (res && res[CB_DOU_MUNICIPIO_KEY]) {
            cbDouMunicipio = res[CB_DOU_MUNICIPIO_KEY];
            cbDouAtualizarChipMunicipio();
        }
    });

    elTrocarMunicipio.addEventListener('click', () => {
        elMunicipioForm.hidden = !elMunicipioForm.hidden;
        if (!elMunicipioForm.hidden) elMunicipioInput.focus();
    });

    async function cbDouBuscarMunicipios() {
        const nome = elMunicipioInput.value.trim();
        if (!nome) return;
        elMunicipioResultados.innerHTML = '<div class="cb-jus-vazio">Buscando…</div>';
        try {
            const url = `${CB_DOU_API_BASE}/cities?city_name=${encodeURIComponent(nome)}`;
            const resp = await fetch(url);
            if (!resp.ok) throw new Error('HTTP ' + resp.status);
            const corpo = await resp.json();
            const cidades = (corpo && corpo.cities) || [];
            if (!cidades.length) {
                elMunicipioResultados.innerHTML = '<div class="cb-jus-vazio">Nenhum município encontrado com esse nome.</div>';
                return;
            }
            elMunicipioResultados.innerHTML = cidades.slice(0, 15).map((c) => `
                <div class="cb-jus-card cb-dou-municipio-item" data-territory-id="${cbDouEscapeHtml(c.territory_id)}" data-territory-name="${cbDouEscapeHtml(c.territory_name)}" data-state-code="${cbDouEscapeHtml(c.state_code)}" data-availability="${cbDouEscapeHtml(c.availability_date || '')}" style="cursor:pointer;${c.availability_date ? '' : 'opacity:.6;'}">
                    <div class="cb-jus-card-top">
                        <span class="cb-jus-processo">${cbDouEscapeHtml(c.territory_name)}</span>
                        <span class="cb-jus-data">${cbDouEscapeHtml(c.state_code)} · ${c.availability_date ? 'diários desde ' + cbDouEscapeHtml(String(c.availability_date).slice(0, 4)) : 'sem diários'}</span>
                    </div>
                </div>
            `).join('');
            elMunicipioResultados.querySelectorAll('.cb-dou-municipio-item').forEach((el) => {
                el.addEventListener('click', () => {
                    cbDouMunicipio = {
                        territory_id: el.dataset.territoryId,
                        territory_name: el.dataset.territoryName,
                        state_code: el.dataset.stateCode,
                        availability_date: el.dataset.availability
                    };
                    chrome.storage.local.set({ [CB_DOU_MUNICIPIO_KEY]: cbDouMunicipio });
                    cbDouAtualizarChipMunicipio();
                    elMunicipioForm.hidden = true;
                    elMunicipioResultados.innerHTML = '';
                    elMunicipioInput.value = '';
                });
            });
        } catch (e) {
            elMunicipioResultados.innerHTML = '<div class="cb-jus-vazio">Falha ao buscar município. Confira sua internet.</div>';
            console.warn('[CB-DOU] erro ao buscar municípios:', e);
        }
    }
    elMunicipioBuscar.addEventListener('click', cbDouBuscarMunicipios);
    elMunicipioInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') cbDouBuscarMunicipios(); });

    function cbDouRenderCard(g) {
        const excerpt = (g.excerpts && g.excerpts[0]) || '';
        const link = g.url || g.txt_url || '';
        return `
            <div class="cb-jus-card">
                <div class="cb-jus-card-top">
                    <span class="cb-jus-processo">${cbDouEscapeHtml(g.territory_name || '')}</span>
                    ${g.date ? `<span class="cb-jus-data">Publicado em ${cbDouEscapeHtml(g.date)}</span>` : ''}
                </div>
                ${g.is_extra_edition ? '<div class="cb-jus-tribunal-badge">Edição extra</div>' : ''}
                ${excerpt ? `<div class="cb-jus-trecho">${cbDouEscapeHtml(excerpt)}</div>` : ''}
                ${link ? `<a class="cb-jus-link" href="${cbDouEscapeHtml(link)}" target="_blank" rel="noopener">Abrir diário ↗</a>` : ''}
            </div>
        `;
    }

    async function cbDouBuscar(continuar) {
        if (!cbDouMunicipio) {
            elStatus.textContent = 'Escolha um município primeiro.';
            return;
        }
        const termo = elQuery.value.trim();
        if (cbDouBuscando) return;
        cbDouBuscando = true;
        elBuscar.disabled = true;
        if (!continuar) {
            cbDouOffsetAtual = 0;
            elResultados.innerHTML = '';
        }
        elStatus.textContent = 'Buscando…';
        try {
            const params = new URLSearchParams({
                territory_ids: cbDouMunicipio.territory_id,
                size: String(CB_DOU_TAMANHO_PAGINA),
                offset: String(cbDouOffsetAtual)
            });
            if (termo) params.set('querystring', termo);
            const resp = await fetch(`${CB_DOU_API_BASE}/gazettes?${params.toString()}`);
            if (!resp.ok) throw new Error('HTTP ' + resp.status);
            const corpo = await resp.json();
            const gazetas = corpo.gazettes || [];
            cbDouTotalDisponivel = corpo.total_gazettes || 0;

            // Zero resultado: antes de dizer "nada encontrado", confere se a cidade tem diários
            // no Querido Diário (município salvo antes deste aviso não guarda essa informação).
            let semCobertura = cbDouSemCobertura(cbDouMunicipio);
            if (!continuar && !gazetas.length && cbDouMunicipio.availability_date === undefined) {
                try {
                    const rc = await fetch(`${CB_DOU_API_BASE}/cities?city_name=${encodeURIComponent(cbDouMunicipio.territory_name)}`);
                    const cc = rc.ok ? await rc.json() : null;
                    const achada = ((cc && cc.cities) || []).find((c) => String(c.territory_id) === String(cbDouMunicipio.territory_id));
                    if (achada) {
                        cbDouMunicipio.availability_date = achada.availability_date || '';
                        chrome.storage.local.set({ [CB_DOU_MUNICIPIO_KEY]: cbDouMunicipio });
                        cbDouAtualizarChipMunicipio();
                        semCobertura = cbDouSemCobertura(cbDouMunicipio);
                    }
                } catch (e) { /* sem rede para conferir: segue com a mensagem comum */ }
            }

            if (!continuar && !gazetas.length) {
                elResultados.innerHTML = semCobertura
                    ? `<div class="cb-jus-vazio">O Querido Diário ainda não tem os diários de ${cbDouEscapeHtml(cbDouMunicipio.territory_name)}. Não é falha da busca: a cidade não está na base. Tente outro município ou consulte o site oficial da prefeitura.</div>`
                    : '<div class="cb-jus-vazio">Nada encontrado nesse Diário Oficial.</div>';
            } else {
                elResultados.insertAdjacentHTML('beforeend', gazetas.map(cbDouRenderCard).join(''));
            }
            cbDouOffsetAtual += gazetas.length;
            elStatus.textContent = semCobertura
                ? 'Município sem diários na base.'
                : `${cbDouTotalDisponivel} publicação(ões) encontrada(s) em ${cbDouMunicipio.territory_name}.`;
            elCarregarMais.hidden = cbDouOffsetAtual >= cbDouTotalDisponivel;
        } catch (e) {
            elStatus.textContent = 'Falha de conexão com a API do Querido Diário. Confira sua internet e tente de novo.';
            console.warn('[CB-DOU] erro ao buscar diário:', e);
        } finally {
            cbDouBuscando = false;
            elBuscar.disabled = false;
        }
    }
    elBuscar.addEventListener('click', () => cbDouBuscar(false));
    elQuery.addEventListener('keydown', (e) => { if (e.key === 'Enter') cbDouBuscar(false); });
    elCarregarMais.addEventListener('click', () => cbDouBuscar(true));
});
