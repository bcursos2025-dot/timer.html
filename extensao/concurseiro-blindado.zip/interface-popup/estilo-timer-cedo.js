// Decide cedo (antes da primeira pintura) se o estilo "Planeta" do cronômetro entra. Fica em arquivo à parte porque a
// Content Security Policy do Manifest V3 bloqueia <script> inline (o Firefox mostrava o erro em popup.html:50).
(function () {
    function aplicar(planeta) {
        if (!planeta) return;
        document.getElementById('planeta-css-link').disabled = false;
        document.documentElement.classList.remove('cb-timer-classico');
    }
    try {
        aplicar(localStorage.getItem('cbEstiloTimer') === 'planeta');
    } catch (e) { /* localStorage indisponível (raro): segue só com o chrome.storage abaixo */ }
    try {
        chrome.storage.local.get(['cbEstiloTimer'], (result) => {
            const planeta = !!(result && result.cbEstiloTimer === 'planeta');
            aplicar(planeta);
            try { localStorage.setItem('cbEstiloTimer', planeta ? 'planeta' : 'classico'); } catch (e) {}
        });
    } catch (e) { /* sem storage disponível: mantém o padrão (círculo clássico) */ }
})();
