// ===================== ASSISTENTE PARA INICIANTES (botão "Ajuda" + chat simples) =====================
//
// Interface PRÓPRIA, separada do chat completo (ia-chat.js, ao lado da meta). Sem anexo de PDF, sem pesquisa na
// web, sem escolha de modelo, sem histórico: só perguntar e receber resposta curta sobre a extensão.
// A resposta sobre a extensão vem SÓ do manual (dados-config/ia-manual-extensao.js). A chamada de IA é a mesma
// do resto do app (cbGerarRespostaIA, em dados-config/ia-provider.js), carregada só na primeira pergunta.
//
// Aparece para quem está no modo iniciante (instalação nova); quem já usava a extensão não vê o botão.
(function () {
    'use strict';
    if (!window.chrome || !chrome.storage) return;

    const SISTEMA = `Você é o Assistente do Concurseiro Blindado, uma extensão de navegador para quem estuda para concursos e OAB. Você ajuda principalmente quem acabou de instalar e está se acostumando.
Regras:
- Responda em português do Brasil, em linguagem simples e amigável, em no máximo 4 frases curtas ou uma lista de até 4 itens. Sem jargão.
- Sobre a extensão (o que cada recurso faz, onde fica, como usar), responda SOMENTE com base no MANUAL que vem na mensagem seguinte. Nunca invente botão, tela, preço ou recurso. Se a resposta não estiver no manual, diga com honestidade que não tem essa informação e sugira Configurações > Ajuda.
- Se a pessoa perguntar por um recurso que aparece na lista "AINDA NÃO LIBERADOS", explique o que ele faz e diga que será liberado aos poucos conforme ela usa (use as condições do manual), sem dizer que não existe.
- Para dúvidas de matéria (Direito, Português etc.), dê uma explicação curta e correta; se não tiver certeza, diga que não tem certeza em vez de chutar. Para valores e prazos de lei, recomende conferir o texto da lei.
- Se perguntarem qual tecnologia ou modelo de I.A. você usa, responda apenas: "Sou o Assistente do Concurseiro Blindado." Nunca cite empresas ou provedores de I.A.
- Termine, quando fizer sentido, com um próximo passo simples (por exemplo: "Quer tentar agora?").`;

    const SUGESTOES = [
        'Como eu começo?',
        'O que é Online e Offline?',
        'Como salvo o artigo de uma questão que errei?',
        'Por que tem coisa escondida?'
    ];

    let montado = false;
    let enviando = false;
    let historico = [];   // {role:'user'|'assistant', content}
    let el = {};

    function icone(d, w) {
        return `<svg viewBox="0 0 24 24" width="${w || 22}" height="${w || 22}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
    }
    const ICO_FAISCA = '<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/><path d="M19 3v4M17 5h4"/>';
    const ICO_ENVIAR = '<path d="M5 12h14M13 6l6 6-6 6"/>';
    const ICO_FECHAR = '<path d="M18 6 6 18M6 6l12 12"/>';

    function escapar(t) {
        return String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }
    // negrito e listas simples; o resto vira texto seguro
    function formatar(t) {
        const linhas = escapar(t).split(/\n/);
        let html = '', lista = false;
        linhas.forEach((l) => {
            const item = l.match(/^\s*(?:[-*•]|\d+[.)])\s+(.*)$/);
            if (item) { if (!lista) { html += '<ul>'; lista = true; } html += '<li>' + item[1] + '</li>'; return; }
            if (lista) { html += '</ul>'; lista = false; }
            if (l.trim()) html += '<p>' + l + '</p>';
        });
        if (lista) html += '</ul>';
        return html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    }

    function montar() {
        if (montado) return;
        montado = true;
        const folha = document.createElement('div');
        folha.id = 'cb-ai-folha';
        folha.hidden = true;
        folha.innerHTML = `
          <div class="cb-ai-fundo" data-fechar></div>
          <section class="cb-ai-painel" role="dialog" aria-modal="true" aria-label="Assistente do Concurseiro Blindado">
            <header class="cb-ai-cab">
              <span class="cb-ai-avatar">${icone(ICO_FAISCA, 20)}</span>
              <span class="cb-ai-cab-txt"><strong>Assistente</strong><small>Tire dúvidas sobre a extensão</small></span>
              <button type="button" class="cb-ai-fechar" data-fechar aria-label="Fechar">${icone(ICO_FECHAR, 18)}</button>
            </header>
            <div class="cb-ai-msgs" id="cb-ai-msgs" aria-live="polite"></div>
            <div class="cb-ai-sugestoes" id="cb-ai-sugestoes"></div>
            <form class="cb-ai-form" id="cb-ai-form" autocomplete="off">
              <input type="text" id="cb-ai-input" maxlength="400" placeholder="Pergunte o que quiser" aria-label="Sua pergunta">
              <button type="submit" id="cb-ai-enviar" aria-label="Enviar">${icone(ICO_ENVIAR, 20)}</button>
            </form>
            <p class="cb-ai-aviso">Respostas geradas por I.A. podem errar. Na dúvida, veja Configurações › Ajuda.</p>
          </section>`;
        document.body.appendChild(folha);
        el = {
            folha,
            msgs: folha.querySelector('#cb-ai-msgs'),
            sug: folha.querySelector('#cb-ai-sugestoes'),
            form: folha.querySelector('#cb-ai-form'),
            input: folha.querySelector('#cb-ai-input'),
            enviar: folha.querySelector('#cb-ai-enviar')
        };
        folha.addEventListener('click', (e) => { if (e.target.closest('[data-fechar]')) fechar(); });
        document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !folha.hidden) fechar(); });
        el.form.addEventListener('submit', (e) => { e.preventDefault(); perguntar(el.input.value); });
        SUGESTOES.forEach((s) => {
            const b = document.createElement('button');
            b.type = 'button'; b.className = 'cb-ai-chip'; b.textContent = s;
            b.addEventListener('click', () => perguntar(s));
            el.sug.appendChild(b);
        });
        balao('ia', 'Oi! Eu ajudo você a se achar na extensão. Pode perguntar qualquer coisa, ou tocar em uma das sugestões abaixo.');
    }

    function rolar() { el.msgs.scrollTop = el.msgs.scrollHeight; }

    function balao(quem, texto) {
        const b = document.createElement('div');
        b.className = 'cb-ai-balao ' + (quem === 'eu' ? 'eu' : 'ia');
        if (quem === 'eu') b.textContent = texto; else b.innerHTML = formatar(texto);
        el.msgs.appendChild(b);
        rolar();
        return b;
    }

    function digitando() {
        const b = document.createElement('div');
        b.className = 'cb-ai-balao ia cb-ai-digitando';
        b.innerHTML = '<span></span><span></span><span></span>';
        el.msgs.appendChild(b);
        rolar();
        return b;
    }

    // revela a resposta aos poucos (a chamada devolve o texto de uma vez)
    function revelar(b, texto) {
        return new Promise((ok) => {
            const total = texto.length;
            const passo = Math.max(2, Math.ceil(total / 90));
            let n = 0;
            const t = setInterval(() => {
                n = Math.min(total, n + passo);
                b.innerHTML = formatar(texto.slice(0, n));
                rolar();
                if (n >= total) { clearInterval(t); ok(); }
            }, 22);
        });
    }

    function abrir() {
        montar();
        el.folha.hidden = false;
        requestAnimationFrame(() => el.folha.classList.add('aberta'));
        setTimeout(() => el.input.focus(), 250);
        const fab = document.getElementById('cb-ai-fab');
        if (fab) fab.classList.remove('chamar');
    }
    function fechar() {
        el.folha.classList.remove('aberta');
        setTimeout(() => { el.folha.hidden = true; }, 220);
    }

    function contextoDoUsuario() {
        let extra = '';
        try {
            const e = typeof window.cbPdEstado === 'function' ? window.cbPdEstado() : null;
            if (e && e.pendentes && e.pendentes.length) extra = '\nAINDA NÃO LIBERADOS PARA ESTA PESSOA: ' + e.pendentes.join('; ') + '.';
            else if (e) extra = '\nTodos os recursos já estão liberados para esta pessoa.';
        } catch (x) { /* sem contexto */ }
        return extra;
    }

    async function perguntar(texto) {
        texto = String(texto || '').trim();
        if (!texto || enviando) return;
        enviando = true;
        el.input.value = '';
        el.enviar.disabled = true;
        el.sug.hidden = true;
        balao('eu', texto);
        historico.push({ role: 'user', content: texto });
        const espera = digitando();
        try {
            if (typeof window.cbCarregarScript === 'function' && typeof window.cbGerarRespostaIA !== 'function') {
                await window.cbCarregarScript('../dados-config/ia-provider.js');
            }
            if (typeof window.cbGerarRespostaIA !== 'function' && typeof cbGerarRespostaIA !== 'function') throw new Error('sem provedor');
            const gerar = window.cbGerarRespostaIA || cbGerarRespostaIA;
            const manual = window.CB_MANUAL_EXTENSAO || '';
            const mensagens = [
                { role: 'system', content: SISTEMA },
                { role: 'system', content: 'MANUAL (única fonte sobre a extensão):\n' + manual + contextoDoUsuario() },
                ...historico.slice(-8)
            ];
            const resposta = String(await gerar(mensagens, { timeoutMs: 45000 }) || '').trim();
            if (!resposta) throw new Error('vazio');
            espera.remove();
            const b = balao('ia', '');
            await revelar(b, resposta);
            historico.push({ role: 'assistant', content: resposta });
        } catch (e) {
            espera.remove();
            balao('ia', 'Não consegui responder agora. Confira sua internet e tente de novo em instantes.');
            historico.pop();
        } finally {
            enviando = false;
            el.enviar.disabled = false;
            el.input.focus();
        }
    }

    function botao() {
        if (document.getElementById('cb-ai-fab')) return;
        const b = document.createElement('button');
        b.type = 'button';
        b.id = 'cb-ai-fab';
        b.className = 'chamar';
        b.setAttribute('aria-label', 'Abrir o assistente de ajuda');
        b.innerHTML = icone(ICO_FAISCA, 24) + '<span class="cb-ai-fab-rotulo">Dúvidas?</span>';
        b.addEventListener('click', abrir);
        // já deixa a chamada de I.A. carregando quando a pessoa se aproxima
        ['pointerenter', 'touchstart'].forEach((ev) => b.addEventListener(ev, () => {
            if (typeof window.cbCarregarScript === 'function') window.cbCarregarScript('../dados-config/ia-provider.js').catch(() => {});
        }, { once: true, passive: true }));
        document.body.appendChild(b);
        setTimeout(() => b.classList.remove('chamar'), 9000);
    }

    function remover() {
        ['cb-ai-fab', 'cb-ai-folha'].forEach((i) => { const e = document.getElementById(i); if (e) e.remove(); });
        montado = false;
    }

    function atualizar(d) {
        const ativo = !!d && (d.modo === 'novo' || d.origem === 'instalacao');
        if (ativo) botao(); else remover();
    }

    chrome.storage.local.get(['cbPrimeirosDias'], (r) => atualizar(r.cbPrimeirosDias));
    chrome.storage.onChanged.addListener((mud, area) => { if (area === 'local' && mud.cbPrimeirosDias) atualizar(mud.cbPrimeirosDias.newValue); });
})();
