// ============================================================================
// suporte.js — Configurações → Relatar Problemas & Feedback: antes de abrir o WhatsApp do suporte, a pessoa se identifica
// (nome + CPF). O objetivo é saber com quem se está falando e não deixar o número do desenvolvedor à mostra para qualquer um.
//
//   • O CPF é conferido pelos dígitos verificadores (não há como confirmar que é da pessoa) e fica gravado NO REGISTRO DA CONTA
//     (chrome.storage.local: cbAccountCpf + cópia de segurança cbAccountCpfSelo, nome e data). Depois de gravado, a tela não tem
//     como editar nem apagar, e se uma das duas cópias sumir a outra a restaura. Fica só neste computador; vai para o
//     desenvolvedor apenas dentro da mensagem do WhatsApp que a própria pessoa envia.
//   • O número do suporte não aparece em nenhum texto da tela: o link só é montado no clique.
// Funções puras (cpfValido, formatarCpf, mascararCpf) rodam em Node: interface-popup/testes/suporte.test.js.
// ============================================================================
(function (raiz) {
    'use strict';

    // ------------------------------------------------------------------ puro
    const soDigitos = (t) => String(t == null ? '' : t).replace(/\D/g, '');

    function cpfValido(cpf) {
        const d = soDigitos(cpf);
        if (d.length !== 11 || /^(\d)\1{10}$/.test(d)) return false;
        const dv = (n) => {
            let soma = 0;
            for (let i = 0; i < n; i++) soma += Number(d[i]) * (n + 1 - i);
            const r = (soma * 10) % 11;
            return r === 10 ? 0 : r;
        };
        return dv(9) === Number(d[9]) && dv(10) === Number(d[10]);
    }
    function formatarCpf(cpf) {
        const d = soDigitos(cpf).slice(0, 11);
        return d.replace(/^(\d{3})(\d)/, '$1.$2').replace(/^(\d{3})\.(\d{3})(\d)/, '$1.$2.$3').replace(/\.(\d{3})(\d)/, '.$1-$2');
    }
    const mascararCpf = (cpf) => { const d = soDigitos(cpf); return d.length === 11 ? `***.***.***-${d.slice(9)}` : ''; };
    const nomeValido = (n) => String(n || '').trim().replace(/\s+/g, ' ').length >= 5 && /\s/.test(String(n).trim());

    const api = { soDigitos, cpfValido, formatarCpf, mascararCpf, nomeValido };
    if (typeof module !== 'undefined' && module.exports) { module.exports = api; return; }
    raiz.CBSuporte = api;

    // ------------------------------------------------------------------ tela
    const K_CPF = 'cbAccountCpf', K_SELO = 'cbAccountCpfSelo', K_NOME = 'cbAccountNomeCompleto', K_EM = 'cbAccountCpfRegistradoEm';
    const lerStorage = (chaves) => new Promise((r) => { try { chrome.storage.local.get(chaves, (x) => r(x || {})); } catch (e) { r({}); } });
    const gravar = (o) => new Promise((r) => { try { chrome.storage.local.set(o, () => r()); } catch (e) { r(); } });
    // número montado só no clique (não existe como texto contínuo na página)
    const numeroSuporte = () => ['5545', '99806', '1263'].join('');

    async function restaurarSeFaltar() {
        const x = await lerStorage([K_CPF, K_SELO, K_NOME, K_EM]);
        if (x[K_CPF] && !x[K_SELO]) await gravar({ [K_SELO]: x[K_CPF] });
        else if (!x[K_CPF] && x[K_SELO]) await gravar({ [K_CPF]: x[K_SELO] });
        return Object.assign({}, x, { [K_CPF]: x[K_CPF] || x[K_SELO] });
    }

    async function iniciar() {
        const card = document.getElementById('suporte-card');
        if (!card) return;
        const q = (s) => card.querySelector(s);
        const form = q('#suporte-identificacao'), liberado = q('#suporte-liberado');
        const inNome = q('#suporte-nome'), inCpf = q('#suporte-cpf'), aceite = q('#suporte-aceite');
        const btnSalvar = q('#suporte-salvar'), erro = q('#suporte-erro'), quem = q('#suporte-quem'), wa = q('#btn-whatsapp-feedback');

        function mostrarLiberado(x) {
            form.hidden = true; liberado.hidden = false;
            quem.innerHTML = '';
            const b = document.createElement('b'); b.textContent = x[K_NOME] || 'Você';
            quem.append('Identificado como ', b, ` · CPF ${mascararCpf(x[K_CPF])} (registrado nesta conta, não pode ser alterado)`);
            const conta = document.getElementById('account-identificacao');
            if (conta) { conta.value = `${x[K_NOME] || ''} · CPF ${mascararCpf(x[K_CPF])}`; const linha = document.getElementById('account-identificacao-linha'); if (linha) linha.hidden = false; }
        }

        const existente = await restaurarSeFaltar();
        if (cpfValido(existente[K_CPF])) mostrarLiberado(existente);

        inCpf.addEventListener('input', () => { inCpf.value = formatarCpf(inCpf.value); validar(); });
        inNome.addEventListener('input', validar);
        aceite.addEventListener('change', validar);
        function validar() {
            btnSalvar.disabled = !(nomeValido(inNome.value) && cpfValido(inCpf.value) && aceite.checked);
            erro.hidden = true;
        }
        validar();

        btnSalvar.addEventListener('click', async () => {
            if (!nomeValido(inNome.value)) { erro.textContent = 'Informe nome e sobrenome.'; erro.hidden = false; return; }
            if (!cpfValido(inCpf.value)) { erro.textContent = 'Esse CPF não parece válido. Confira os números.'; erro.hidden = false; return; }
            // nunca sobrescreve: se já existe um CPF registrado, ele permanece
            const atual = await lerStorage([K_CPF, K_SELO]);
            if (atual[K_CPF] || atual[K_SELO]) { mostrarLiberado(await restaurarSeFaltar()); return; }
            const cpf = soDigitos(inCpf.value);
            await gravar({ [K_CPF]: cpf, [K_SELO]: cpf, [K_NOME]: inNome.value.trim().replace(/\s+/g, ' '), [K_EM]: Date.now() });
            mostrarLiberado(await lerStorage([K_CPF, K_NOME]));
        });

        wa.addEventListener('click', async (e) => {
            e.preventDefault();
            const x = await restaurarSeFaltar();
            if (!cpfValido(x[K_CPF])) { liberado.hidden = true; form.hidden = false; return; }
            const conta = await lerStorage(['cbAccountId']);
            let instalacao = '';
            try { instalacao = raiz.CBLicense ? await raiz.CBLicense.getInstallId() : ''; } catch (err) { /* ignora */ }
            const nome = (await lerStorage([K_NOME]))[K_NOME] || '';
            const msg = `Olá! Preciso de suporte no Concurseiro Blindado.\nNome: ${nome}\nCPF: ${formatarCpf(x[K_CPF])}\nID da conta: ${conta.cbAccountId || '—'}\nID de instalação: ${instalacao || '—'}\n\nDescrição: `;
            raiz.open(`https://wa.me/${numeroSuporte()}?text=${encodeURIComponent(msg)}`, '_blank', 'noopener');
        });
    }
    if (raiz.document.readyState === 'loading') raiz.document.addEventListener('DOMContentLoaded', iniciar); else iniciar();
})(typeof window !== 'undefined' ? window : globalThis);
