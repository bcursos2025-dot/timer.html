// ===================== PRIMEIROS DIAS: INTERFACE QUE SE LIBERA AOS POUCOS =====================
//
// Quem acabou de instalar vê só o cronômetro e a barra Cronômetro | Desempenho (mais a ilha de baixo com
// Configurações e Perfil). O resto da tela é liberado conforme a pessoa usa: por AÇÃO (primeira sessão de
// estudo, primeiro artigo salvo dos erros, dias de uso) e, nos extras, por HORAS estudadas.
//
// Quem já usava a extensão NÃO passa por aqui: o modo "novo" só é gravado na instalação (background.js,
// chave cbPrimeirosDias). Sem a chave, este arquivo não faz nada.
//
// Depois que um recurso é liberado ele nunca mais some (a liberação fica gravada). "Liberar tudo agora" no
// cartão "Comece por aqui" encerra o modo. Os bloqueios PRO/FREE (data-pro-feature) e os níveis de 50h+ são
// outra camada e continuam funcionando por conta própria.
(function () {
    'use strict';
    if (!window.chrome || !chrome.storage) return;

    const CHAVE = 'cbPrimeirosDias';
    const MIN = 60 * 1000;
    const tab = (id) => `.tab-btn[data-tab="${id}"]`;
    const acc = (id) => `.settings-accordion[data-acc="${id}"]`;   // Configurações: no começo ficam só Aparência, Modo iniciante, Plano, Ajuda, Segurança e Feedback

    // ok(estado) → true quando o recurso deve aparecer. alvo = seletores que ficam escondidos até lá.
    const PORTOES = [
        { id: 'desempenho', rotulo: 'Desempenho',
          ok: (s) => s.questoes >= 1 || s.ms >= 5 * MIN,
          alvo: ['.hv-barra', '.hv-desempenho'] },
        { id: 'sessao', rotulo: 'Meta diária, histórico e produtividade',
          ok: (s) => s.ms >= 5 * MIN,
          alvo: ['#section-meta', '#section-conquistas', '#section-tabs', tab('tab-chart'), tab('tab-productivity'), tab('tab-ansiedade'),
                  '#cb-semana', '.cb-perfil-secao', '#btn-perfil', '#streak-tag', acc('som'), acc('layout'), acc('grafico')] },
        { id: 'erro', rotulo: 'Revisão de artigos e Questões',
          ok: (s) => s.artigos >= 1,
          alvo: ['#btn-open-artigos', tab('tab-questoes'), acc('artigos'), acc('qcestat')] },
        { id: 'dias3', rotulo: 'Foco, bloqueio de sites, plano de hoje, cronograma e aviso de backup',
          ok: (s) => s.dias >= 3,
          alvo: [tab('tab-distractions'), tab('tab-foco'), tab('tab-sites'), '#plano-hoje-card', '#btn-open-dashboard', '#btn-abrir-rotina', '#hn-btn-organizar', '#cb-backup-banner', '#btn-float-handle', '.cb-perfil-conta', acc('cronometro-flutuante'), acc('foco'), acc('antiproc'), acc('atalhos')] },
        { id: 'h1', rotulo: 'PCI, Estudos, JUS e Diário',
          ok: (s) => s.ms >= 60 * MIN,
          alvo: [tab('tab-pci'), tab('tab-estudos'), tab('tab-jus'), tab('tab-dou'), '#hn-btn-viagem', '#hn-btn-pciconcursos', acc('terceiros')] },
        { id: 'h3', rotulo: 'Assistente de I.A.',
          ok: (s) => s.ms >= 3 * 60 * MIN,
          alvo: ['#btn-ia-chat'] },
        { id: 'h5', rotulo: 'Comunidade, celular e opções visuais avançadas',
          ok: (s) => s.ms >= 5 * 60 * MIN,
          alvo: ['#btn-comunidade', '#btn-open-celular', acc('compartilhar'),
                  '.theme-opt[data-theme="navy"]', '.theme-opt[data-theme="glass"]',
                  // Aparência: sobram só os temas Escuro, Claro e Automático; modo da interface, estilo do cronômetro, desempenho, animações e dock aparecem aqui
                  ...['#interface-mode-row', '#timer-estilo-row', '#desempenho-row', '#chk-chart-animations', '#chk-dock-hover'].map((i) => `.settings-section:has(${i})`)] }
    ];

    let dados = null;                 // conteúdo de cbPrimeirosDias
    let medidas = { ms: 0, artigos: 0, dias: 0, questoes: 0 };
    let cartao = null;
    let avisoTimer = null;

    const hoje = () => new Date().toISOString().slice(0, 10);

    // estado resumido para o assistente de iniciantes (assistente-iniciante.js)
    window.cbPdEstado = function () {
        if (!dados) return null;
        return { modo: dados.modo, pendentes: PORTOES.filter((x) => !(dados.liberado || {})[x.id]).map((x) => x.rotulo) };
    };

    function gravar() { chrome.storage.local.set({ [CHAVE]: dados }); }

    function esconder(sel, sim) {
        document.querySelectorAll(sel).forEach((el) => el.classList.toggle('cb-pd-oculto', sim));
    }

    // páginas do carrossel de abas: some a página sem nenhuma aba visível e a seta que levaria até ela
    function ajustarCarrossel() {
        const paginas = Array.from(document.querySelectorAll('#tabs-track .tabs-page'));
        if (!paginas.length) return;
        const visivel = paginas.map((p) => !!p.querySelector('.tab-btn[data-tab]:not(.cb-pd-oculto)'));
        paginas.forEach((p, i) => {
            p.classList.toggle('cb-pd-oculto', !visivel[i]);
            p.querySelectorAll('.tabs-arrow-btn').forEach((b) => {
                const alvo = i + Number(b.getAttribute('data-tabs-dir') || 0);
                b.classList.toggle('cb-pd-oculto', !(alvo >= 0 && alvo < paginas.length && visivel[alvo]));
            });
        });
    }

    // "Offline · Leitura" no topo do cronômetro: explica em palavras simples (só no modo guiado)
    function dicaDoStatus() {
        const rotulo = document.getElementById('current-focus-label');
        if (!rotulo || document.getElementById('cb-pd-dica-btn')) return;
        const btn = document.createElement('button');
        btn.type = 'button'; btn.id = 'cb-pd-dica-btn'; btn.className = 'cb-pd-dica-btn';
        btn.setAttribute('aria-expanded', 'false');
        btn.textContent = 'O que é isso?';
        const caixa = document.createElement('div');
        caixa.id = 'cb-pd-dica'; caixa.className = 'cb-pd-dica'; caixa.hidden = true;
        caixa.innerHTML = '<b>A extensão percebe sozinha o que você está fazendo:</b>'
            + '<p><strong>Online · Questões</strong>: você está em um site de questões, como o QConcursos.</p>'
            + '<p><strong>Offline · Leitura</strong>: qualquer outra coisa, como livro, PDF, a lei no Planalto ou caderno de papel.</p>'
            + '<p>Você não precisa escolher nada. É só tocar em <strong>Iniciar Estudo</strong>.</p>';
        btn.addEventListener('click', () => {
            caixa.hidden = !caixa.hidden;
            btn.setAttribute('aria-expanded', String(!caixa.hidden));
        });
        rotulo.insertAdjacentElement('afterend', caixa);
        rotulo.insertAdjacentElement('afterend', btn);
    }

    // cartão de Configurações sem nenhuma seção visível some junto
    function ajustarGrupos() {
        // temas: com Marinho e Vidro escondidos, os 3 que sobram ficam numa fileira só
        const secTemas = document.querySelector('.theme-selector-row--grid3');
        if (secTemas && secTemas.parentElement) secTemas.parentElement.classList.toggle('cb-pd-temas', !dados.liberado.h5);
        document.querySelectorAll('.cfg-grupo').forEach((g) => {
            const itens = g.querySelectorAll('.settings-accordion');
            if (!itens.length) return;
            g.classList.toggle('cb-pd-oculto', !g.querySelector('.settings-accordion:not(.cb-pd-oculto)'));
        });
    }

    function aviso(texto) {
        let el = document.getElementById('cb-pd-aviso');
        if (!el) {
            el = document.createElement('div');
            el.id = 'cb-pd-aviso';
            el.setAttribute('role', 'status');
            document.body.appendChild(el);
        }
        el.textContent = texto;
        el.classList.add('on');
        clearTimeout(avisoTimer);
        avisoTimer = setTimeout(() => el.classList.remove('on'), 5000);
    }

    function aplicar(comAviso) {
        const novos = [];
        dados.liberado = dados.liberado || {};
        PORTOES.forEach((p) => {
            if (!dados.liberado[p.id] && p.ok(medidas)) { dados.liberado[p.id] = true; novos.push(p); }
        });
        if (novos.length) gravar();
        PORTOES.forEach((p) => esconder(p.alvo.join(','), !dados.liberado[p.id]));
        ajustarCarrossel();
        ajustarGrupos();
        desenharCartao();
        if (comAviso && novos.length) aviso('Liberado: ' + novos.map((p) => p.rotulo).join(' · '));
        if (PORTOES.every((p) => dados.liberado[p.id])) encerrar(false);
    }

    // sai do modo "novo": mostra tudo e remove o cartão
    function encerrar(gravarFim) {
        if (gravarFim) { dados.modo = 'completo'; gravar(); }
        else if (dados.modo !== 'completo') { dados.modo = 'completo'; gravar(); }
        PORTOES.forEach((p) => esconder(p.alvo.join(','), false));
        document.querySelectorAll('.cb-pd-oculto').forEach((el) => el.classList.remove('cb-pd-oculto'));
        if (cartao) { cartao.remove(); cartao = null; }
        document.querySelectorAll('.cb-pd-temas').forEach((e) => e.classList.remove('cb-pd-temas'));
        ['cb-pd-dica-btn', 'cb-pd-dica'].forEach((i) => { const e = document.getElementById(i); if (e) e.remove(); });
    }

    function passo(feito, titulo, texto) {
        return `<li class="cb-pd-passo${feito ? ' feito' : ''}"><span class="cb-pd-marca" aria-hidden="true">${feito ? '✓' : ''}</span>`
            + `<span><b>${titulo}</b><small>${texto}</small></span></li>`;
    }

    function desenharCartao() {
        if (dados.modo !== 'novo') return;
        if (dados.liberado.sessao && dados.liberado.erro && medidas.dias >= 2) {   // guia cumprido
            if (cartao) { cartao.remove(); cartao = null; }
            return;
        }
        const ancora = document.getElementById('plano-hoje-card') || document.querySelector('.card.timer-section');
        if (!ancora) return;
        if (!cartao) {
            cartao = document.createElement('div');
            cartao.className = 'card cb-pd-cartao';
            ancora.parentNode.insertBefore(cartao, ancora);
            cartao.addEventListener('click', (e) => {
                if (e.target.closest('.cb-pd-tudo')) encerrar(true);
            });
        }
        cartao.innerHTML = '<div class="cb-pd-tit">Comece por aqui</div>'
            + '<ul class="cb-pd-lista">'
            + passo(!!dados.liberado.sessao || medidas.ms >= 5 * MIN, 'Inicie um estudo', 'Toque em “Iniciar Estudo” e deixe o cronômetro rodando.')
            + passo(!!dados.liberado.erro || medidas.artigos >= 1, 'Errou uma questão? Salve o artigo', 'No QConcursos, ao errar, a extensão oferece o artigo da lei e abre o texto no Planalto, grifado.')
            + passo(medidas.dias >= 2, 'Volte amanhã', 'O artigo salvo reaparece na revisão espaçada, na hora de rever.')
            + '</ul>'
            + '<div class="cb-pd-rodape"><span>Os outros recursos são liberados aos poucos, conforme você usa, para facilitar a familiaridade com eles e ajudar você a se acostumar com a extensão.</span>'
            + (dados.origem === 'manual' ? '<button type="button" class="cb-pd-tudo">Liberar tudo agora</button>' : '') + '</div>';
    }

    function medir(cb) {
        chrome.storage.local.get(['totalStudyMs', 'cbArtigosPendentes', 'cbArtigosRevisao', 'questoesPeriodStats'], (r) => {
            const qs = r.questoesPeriodStats && typeof r.questoesPeriodStats === 'object' ? r.questoesPeriodStats : {};
            const questoes = Object.keys(qs).reduce((m, k) => Math.max(m, Number(qs[k] && qs[k].total) || 0), 0);
            const pend = Array.isArray(r.cbArtigosPendentes) ? r.cbArtigosPendentes.length : 0;
            const rev = Array.isArray(r.cbArtigosRevisao) ? r.cbArtigosRevisao.length : 0;
            const base = dados.base || { ms: 0, artigos: 0 };   // ao reativar o modo em conta com histórico, conta só o que vem depois
            medidas = { ms: Math.max(0, (Number(r.totalStudyMs) || 0) - base.ms), artigos: Math.max(0, pend + rev - base.artigos), dias: (dados.dias || []).length, questoes };
            cb();
        });
    }

    // botão em Configurações → "Modo iniciante": liga/desliga o modo guiado (também serve pra quem quer rever)
    // Instalação nova: o modo não tem saída (a pessoa vai liberando com o uso). Quem já usava a extensão pode ligar e desligar à vontade.
    function ligarBotao(modoAtual, origem) {
        const btn = document.getElementById('cb-pd-alternar');
        const txt = document.getElementById('cb-pd-estado');
        if (!btn) return;
        const novo = modoAtual === 'novo';
        const semSaida = novo && origem !== 'manual';
        btn.textContent = novo ? 'Mostrar tudo agora' : 'Ativar modo iniciante';
        btn.style.display = semSaida ? 'none' : '';
        if (txt) txt.textContent = novo ? 'Ativo: os outros recursos são liberados aos poucos.' : 'Desligado: todos os recursos estão visíveis.';
        btn.onclick = () => {
            if (novo) { chrome.storage.local.get([CHAVE], (r) => { const d = r[CHAVE] || {}; d.modo = 'completo'; chrome.storage.local.set({ [CHAVE]: d }, () => location.reload()); }); return; }
            chrome.storage.local.get(['totalStudyMs', 'cbArtigosPendentes', 'cbArtigosRevisao'], (r) => {
                const n = (a) => Array.isArray(a) ? a.length : 0;
                const d = { modo: 'novo', origem: 'manual', criadoEm: Date.now(), dias: [hoje()], liberado: {},
                    base: { ms: Number(r.totalStudyMs) || 0, artigos: n(r.cbArtigosPendentes) + n(r.cbArtigosRevisao) } };
                chrome.storage.local.set({ [CHAVE]: d }, () => location.reload());
            });
        };
    }

    const btnAnim = document.getElementById('cb-pd-animacao');
    if (btnAnim) btnAnim.addEventListener('click', () => chrome.tabs.create({ url: chrome.runtime.getURL('interface-popup/boas-vindas.html') }));

    chrome.storage.local.get([CHAVE], (r) => {
        dados = r[CHAVE];
        ligarBotao(dados && dados.modo, dados && dados.origem);
        if (!dados || dados.modo !== 'novo') return;   // usuário antigo ou modo encerrado: nada muda

        const d = hoje();
        dados.dias = Array.isArray(dados.dias) ? dados.dias : [];
        if (!dados.dias.includes(d)) { dados.dias.push(d); gravar(); }

        // o estilo "Planeta" fica escondido até a liberação dos extras: no modo guiado o cronômetro começa sempre no Círculo (padrão)
        if (!dados.estiloOk) {
            dados.estiloOk = true; gravar();
            chrome.storage.local.get(['cbEstiloTimer'], (e) => {
                if (e.cbEstiloTimer === 'planeta') {
                    try { localStorage.setItem('cbEstiloTimer', 'classico'); } catch (x) { /* sem localStorage */ }
                    chrome.storage.local.set({ cbEstiloTimer: 'classico' }, () => location.reload());
                }
            });
        }

        dicaDoStatus();
        medir(() => aplicar(false));

        chrome.storage.onChanged.addListener((mud, area) => {
            if (area !== 'local' || !dados || dados.modo !== 'novo') return;
            if (mud.totalStudyMs || mud.cbArtigosPendentes || mud.cbArtigosRevisao || mud.questoesPeriodStats) medir(() => aplicar(true));
        });

        // "restaurar backup" na tela de boas-vindas: quem volta com histórico não precisa do modo guiado ("Pular" não encerra o modo)
        ['cb-onboarding-restaurar'].forEach((id) => {
            const b = document.getElementById(id);
            if (b) b.addEventListener('click', () => encerrar(true));
        });
    });
})();
