// ===================== TELA INICIAL: DUAS ABAS NO TOPO (Cronômetro | Desempenho) =====================
//
// Uma barra segmentada, no estilo do iOS, logo acima do cartão do cronômetro. "Cronômetro" mostra o cartão de
// sempre; "Desempenho" troca esse cartão por um resumo do desempenho em questões (anel de acerto + acertos,
// erros e total, com Hoje / 7 dias / 30 dias), lido da mesma chave do storage da aba Questões
// (questoesPeriodStats). Os dois cartões não aparecem juntos, então o cronômetro continua rodando por baixo.
// A escolha é lembrada (localStorage). Visual em apple.css, bloco "TELA INICIAL: DUAS ABAS".
(function () {
    'use strict';
    const cronometro = document.querySelector('.card.timer-section');
    if (!cronometro || !window.chrome || !chrome.storage) return;

    const CHAVE = 'cbHomeVisao';
    const PERIODOS = [[1, 'Hoje'], [7, '7 dias'], [30, '30 dias']];
    const ZONAS = { 1: 'Abaixo da meta', 2: 'Em evolução', 3: 'Competitiva', 4: 'Aprovação' };
    let visao = 'cronometro';
    let periodo = 1;
    try { if (localStorage.getItem(CHAVE) === 'desempenho') visao = 'desempenho'; } catch (e) { /* sem localStorage */ }

    // ---- barra segmentada ----
    const barra = document.createElement('div');
    barra.className = 'hv-barra';
    barra.setAttribute('role', 'tablist');
    barra.innerHTML = '<button type="button" role="tab" data-v="cronometro">Cronômetro</button>'
        + '<button type="button" role="tab" data-v="desempenho">Desempenho</button>';
    cronometro.parentNode.insertBefore(barra, cronometro);

    // ---- cartão de desempenho ----
    const cartao = document.createElement('div');
    cartao.className = 'card hv-desempenho';
    cartao.hidden = true;
    cartao.innerHTML = '<div class="hv-periodos" role="group" aria-label="Período">'
        + PERIODOS.map(([d, r]) => `<button type="button" data-p="${d}">${r}</button>`).join('')
        + '</div><div class="hv-corpo"></div>'
        + '<button type="button" class="hv-mais">Ver análise completa →</button>';
    cronometro.parentNode.insertBefore(cartao, cronometro.nextSibling);
    const corpo = cartao.querySelector('.hv-corpo');

    function desenhar(stats) {
        const s = (stats && stats[periodo]) || { acertos: 0, erros: 0, total: 0 };
        const total = s.total || (s.acertos + s.erros);
        if (!total) {
            corpo.innerHTML = '<p class="hv-vazio">Nenhuma questão respondida neste período. Resolva questões no QConcursos com a extensão ativa e o resumo aparece aqui.</p>';
            return;
        }
        const pct = Math.round((s.acertos / total) * 100);
        const zona = pct >= 90 ? 4 : pct >= 80 ? 3 : pct >= 60 ? 2 : 1;
        const R = 40;
        const circ = 2 * Math.PI * R;
        corpo.innerHTML = `
            <section class="qh qh-z${zona} hv-qh">
                <div class="qh-anel">
                    <div class="qh-anel-wrap">
                        <svg viewBox="0 0 100 100" class="qh-svg" aria-hidden="true">
                            <circle class="qh-trilho" cx="50" cy="50" r="${R}"/>
                            <circle class="qh-prog hv-prog" cx="50" cy="50" r="${R}" stroke-dasharray="${circ}" stroke-dashoffset="${circ - (pct / 100) * circ}" transform="rotate(-90 50 50)"/>
                        </svg>
                        <div class="qh-centro"><span class="qh-pct">${pct}%</span><span class="qh-zona">${ZONAS[zona]}</span></div>
                    </div>
                    <div class="qh-sub">${s.acertos} de ${total} corretas</div>
                </div>
                <div class="qh-lista">
                    <div class="qh-linha"><span class="qh-ic qh-ic--ok"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg></span><span class="qh-rot">Acertos</span><b>${s.acertos}</b></div>
                    <div class="qh-linha"><span class="qh-ic qh-ic--err"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg></span><span class="qh-rot">Erros</span><b>${s.erros}</b></div>
                    <div class="qh-linha"><span class="qh-ic qh-ic--tot"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16M4 12h16M4 17h10"/></svg></span><span class="qh-rot">Total resolvidas</span><b>${total}</b></div>
                </div>
            </section>`;
    }
    function atualizarDados() {
        chrome.storage.local.get(['questoesPeriodStats'], (r) => desenhar((r && r.questoesPeriodStats) || {}));
    }

    // ---- troca de visão ----
    function aplicar() {
        cronometro.hidden = visao !== 'cronometro';
        cartao.hidden = visao !== 'desempenho';
        barra.querySelectorAll('button').forEach((b) => {
            const ativo = b.dataset.v === visao;
            b.classList.toggle('ativo', ativo);
            b.setAttribute('aria-selected', String(ativo));
        });
        cartao.querySelectorAll('.hv-periodos button').forEach((b) => b.classList.toggle('ativo', Number(b.dataset.p) === periodo));
        if (visao === 'desempenho') atualizarDados();
    }
    barra.addEventListener('click', (e) => {
        const b = e.target.closest('button[data-v]');
        if (!b) return;
        visao = b.dataset.v;
        try { localStorage.setItem(CHAVE, visao); } catch (err) { /* ignora */ }
        aplicar();
    });
    cartao.querySelector('.hv-periodos').addEventListener('click', (e) => {
        const b = e.target.closest('button[data-p]');
        if (!b) return;
        periodo = Number(b.dataset.p);
        aplicar();
    });
    cartao.querySelector('.hv-mais').addEventListener('click', () => {
        const aba = document.querySelector('.tab-btn[data-tab="tab-questoes"]');
        if (aba) aba.click();
        window.scrollTo({ top: 0 });
    });
    chrome.storage.onChanged.addListener((mud, area) => {
        if (area === 'local' && mud.questoesPeriodStats && visao === 'desempenho') atualizarDados();
    });
    aplicar();
})();
