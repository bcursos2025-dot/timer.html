// =====================================================================
// REVISÃO DE ARTIGOS — a ponta do popup do sistema "artigos dos meus erros".
//   QConcursos (qconcursos/artigos-erros.js) → pendentes
//   Planalto   (planalto/artigos-erros.js)   → a pessoa confirma e salva
//   Popup      (este arquivo)                → revisão espaçada dos salvos
//
// A folha "Artigos para revisar" (ícone do livro na ilha de baixo) mostra um
// artigo por vez, em recordação ativa: primeiro só o número e a lei ("o que diz
// este artigo?"), depois de "Mostrar o artigo" vem o texto, e a pessoa marca
// "Lembrei" (sobe de caixa: 3, 7, 14, 30, 60 dias) ou "Esqueci" (volta para
// amanhã). Também mostra as próximas revisões e liga/desliga a captura nas
// Configurações → Artigos da lei.
//
// Dados e regras: dados-config/artigos-erros-store.js, revisao-espacada.js e
// ref-artigos.js (os mesmos que o QConcursos e o Planalto usam).
// =====================================================================
(function () {
    'use strict';
    const Store = window.CBArtigosStore;
    const Ref = window.CBRefArtigos;
    const Srs = window.CBRevisaoEspacada;
    if (!Store || !Ref || !Srs) return;

    const $ = (id) => document.getElementById(id);
    const btnAbrir = $('btn-open-artigos');
    const overlay = $('artigos-modal-overlay');
    const btnFechar = $('artigos-modal-close');
    const corpo = $('artigos-modal-body');
    const badge = $('cb-artigos-contagem');
    const chk = $('chk-artigos-erro');
    const resumoEl = $('artigos-resumo');
    const btnAbrirDasConfig = $('btn-artigos-abrir-revisao');
    if (!overlay || !corpo) return;

    let estado = { pendentes: [], revisao: [], ativo: true };
    let revelado = false;
    let idAtual = null;

    function h(tag, classe, texto) {
        const el = document.createElement(tag);
        if (classe) el.className = classe;
        if (texto != null) el.textContent = texto;
        return el;
    }
    function icone(svg) {
        const span = h('span', 'art-ico');
        span.innerHTML = svg; // SVG fixo, escrito aqui
        return span;
    }
    const SVG_OK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>';
    const SVG_LIXO = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>';

    // ---------------------------------------------------------------- dados
    function vencidos() {
        const agora = Date.now();
        return Srs.ordenarParaRevisao(estado.revisao.filter((i) => i.srs && Srs.vencido(i.srs, agora)), agora);
    }
    function proximos(devidos) {
        const ids = new Set(devidos.map((i) => i.id));
        return estado.revisao.filter((i) => !ids.has(i.id)).sort((a, b) => ((a.srs && a.srs.proxima) || 0) - ((b.srs && b.srs.proxima) || 0));
    }
    async function carregar() {
        estado = await Store.ler();
        atualizarBadge();
        atualizarConfig();
        if (overlay.classList.contains('open')) renderizar();
    }
    function atualizarBadge() {
        if (!badge) return;
        const n = vencidos().length;
        badge.hidden = n === 0;
        badge.textContent = n > 99 ? '99+' : String(n);
    }
    function atualizarConfig() {
        if (chk) chk.checked = estado.ativo;
        if (resumoEl) {
            const n = vencidos().length;
            const partes = [];
            partes.push(estado.pendentes.length + (estado.pendentes.length === 1 ? ' aguardando' : ' aguardando') + ' confirmação no Planalto');
            partes.push(estado.revisao.length + (estado.revisao.length === 1 ? ' salvo' : ' salvos') + (n ? ' (' + n + ' para hoje)' : ''));
            resumoEl.textContent = partes.join(' · ');
        }
    }

    function abrirNaLei(item) {
        const url = item.url || Ref.urlDaLei(item.lei, item.artigo, item.sufixo);
        if (!url) return;
        try { chrome.tabs.create({ url }); } catch (e) { window.open(url, '_blank'); }
    }
    async function avaliar(item, lembrou) {
        await Store.avaliarRevisao(item.id, lembrou);
        revelado = false;
        await carregar();
    }
    async function remover(item) {
        await Store.removerRevisao(item.id);
        await carregar();
    }

    // ---------------------------------------------------------------- tela
    function origemTexto(item) {
        const o = (item.origens || [])[0];
        if (!o) return item.manual ? 'Adicionado por você' : '';
        const mais = (item.origens || []).length > 1 ? ' e mais ' + ((item.origens || []).length - 1) : '';
        return 'Você errou a ' + (o.questaoId || 'questão') + (o.assunto ? ' (' + o.assunto + ')' : '') + mais;
    }

    function cartaoRevisao(item) {
        const card = h('div', 'art-card');
        const sup = h('div', 'art-card-sup');
        if (item.detalhe) sup.append(h('span', 'art-chip', item.detalhe));
        sup.append(h('span', 'art-chip art-chip--neutro', 'caixa ' + ((item.srs && item.srs.nivel) || 0)));
        card.append(sup, h('div', 'art-card-art', Ref.rotuloDoArtigo(item)), h('div', 'art-card-lei', Ref.nomeCompletoDaLei(item.lei)));
        const origem = origemTexto(item);
        if (origem) card.append(h('div', 'art-card-origem', origem));

        if (!revelado) {
            card.append(h('p', 'art-card-dica', 'Tente lembrar o que diz este artigo. Depois, confira.'));
            const b = h('button', 'art-btn pri', 'Mostrar o artigo');
            b.type = 'button';
            b.style.width = '100%';
            b.addEventListener('click', () => { revelado = true; renderizar(); });
            card.append(b);
        } else {
            card.append(h('div', 'art-card-texto', item.texto || 'O texto deste artigo não foi capturado. Abra a lei para conferir.'));
            const linha = h('div', 'art-botoes');
            const esqueci = h('button', 'art-btn sec', 'Esqueci');
            esqueci.type = 'button';
            esqueci.addEventListener('click', () => avaliar(item, false));
            const lembrei = h('button', 'art-btn pri', 'Lembrei');
            lembrei.type = 'button';
            lembrei.addEventListener('click', () => avaliar(item, true));
            linha.append(esqueci, lembrei);
            card.append(linha);
        }
        const link = h('button', 'art-link', 'Abrir na lei ↗');
        link.type = 'button';
        link.addEventListener('click', () => abrirNaLei(item));
        card.append(link);
        return card;
    }

    function listaProximas(itens) {
        const agora = Date.now();
        const lista = h('div', 'art-lista');
        itens.forEach((item) => {
            const linha = h('div', 'art-linha');
            const txt = h('div', 'art-linha-txt');
            txt.append(h('b', null, Ref.rotuloDoArtigo(item) + (item.detalhe ? ' · ' + item.detalhe : '')), h('small', null, Ref.nomeDaLei(item.lei)));
            const quando = h('span', 'art-linha-quando', item.srs ? Srs.rotuloProxima(item.srs, agora) : '');
            const ver = h('button', 'art-linha-btn');
            ver.type = 'button';
            ver.title = 'Abrir na lei';
            ver.setAttribute('aria-label', 'Abrir na lei');
            ver.textContent = '↗';
            ver.addEventListener('click', () => abrirNaLei(item));
            const rm = h('button', 'art-linha-btn');
            rm.type = 'button';
            rm.title = 'Remover da revisão';
            rm.setAttribute('aria-label', 'Remover da revisão');
            rm.append(icone(SVG_LIXO));
            rm.addEventListener('click', () => remover(item));
            linha.append(txt, quando, ver, rm);
            lista.append(linha);
        });
        return lista;
    }

    function renderizar() {
        corpo.textContent = '';
        const devidos = vencidos();
        const atual = devidos[0] || null;
        if ((atual ? atual.id : null) !== idAtual) { idAtual = atual ? atual.id : null; revelado = false; }

        const hero = h('div', 'art-hero');
        if (atual) {
            hero.append(h('div', 'art-hero-num', String(devidos.length)),
                h('div', 'art-hero-rot', devidos.length === 1 ? 'artigo para revisar hoje' : 'artigos para revisar hoje'));
        } else {
            const ok = h('div', 'art-hero-ok');
            ok.append(icone(SVG_OK));
            hero.append(ok, h('div', 'art-hero-rot', estado.revisao.length ? 'Tudo em dia por hoje' : 'Nada salvo ainda'));
        }
        corpo.append(hero);

        if (atual) corpo.append(cartaoRevisao(atual));
        else if (!estado.revisao.length) {
            corpo.append(h('p', 'art-nota', 'Quando você errar uma questão no QConcursos e os comentários citarem artigos de lei, eles aparecem num painel na própria lei, no Planalto. Os que você confirmar vêm para cá, para revisar nos dias certos (1, 3, 7, 14, 30 e 60 dias).'));
        }

        const prox = proximos(devidos);
        if (prox.length) {
            corpo.append(h('div', 'art-secao', 'Próximas revisões'), listaProximas(prox));
        }
        if (estado.pendentes.length) {
            corpo.append(h('p', 'art-nota', estado.pendentes.length + (estado.pendentes.length === 1 ? ' artigo aguarda' : ' artigos aguardam') + ' a sua confirmação. Abra a lei no Planalto para vê-los.'));
        }
    }

    // ---------------------------------------------------------------- ligações
    function abrirFolha() {
        overlay.classList.add('open');
        carregar().then(renderizar);
    }
    function fecharFolha() { overlay.classList.remove('open'); }

    if (btnAbrir) btnAbrir.addEventListener('click', abrirFolha);
    if (btnFechar) btnFechar.addEventListener('click', fecharFolha);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) fecharFolha(); });
    if (btnAbrirDasConfig) {
        btnAbrirDasConfig.addEventListener('click', () => {
            const cfg = $('settings-modal-overlay');
            if (cfg) cfg.classList.remove('open');
            abrirFolha();
        });
    }
    if (chk) chk.addEventListener('change', () => { Store.definirAtivo(chk.checked); });

    try {
        chrome.storage.onChanged.addListener((mud, area) => {
            if (area !== 'local') return;
            if (mud[Store.K_PEND] || mud[Store.K_REV] || mud[Store.K_ATIVO]) carregar();
        });
    } catch (e) { /* fora da extensão: segue sem atualizar ao vivo */ }

    carregar();
})();
