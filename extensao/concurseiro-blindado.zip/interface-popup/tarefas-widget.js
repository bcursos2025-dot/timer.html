// =====================================================================
// TAREFAS RÁPIDAS — widget leve e isolado do resto do popup.js (pra não
// arriscar mexer no arquivo grande existente). Fala direto com o mesmo
// Firebase Realtime Database usado pelo timer.html do celular, no nó
// dispositivos/{deviceId}/tarefas — então uma tarefa criada aqui aparece
// no celular e vice-versa.
// =====================================================================
(function () {
    const CB_FIREBASE_URL = "https://concurseiro-blindado-default-rtdb.firebaseio.com";
    const POLL_MS = 12000; // não dá pra manter um listener em tempo real fácil
                           // a partir do popup (ele fecha toda vez que você
                           // clica fora), então "puxamos" a cada ~12s pra
                           // pegar tarefas criadas no celular.

    let deviceId = null;
    let tarefas = [];
    let ultimoHashRemoto = null;

    const lista = document.getElementById('tarefas-rapidas-lista');
    const input = document.getElementById('tarefas-rapidas-input');
    const btnAdd = document.getElementById('tarefas-rapidas-add');
    if (!lista || !input || !btnAdd) return; // popup.html ainda não tem os elementos

    function obterDeviceId() {
        return new Promise((resolve) => {
            chrome.storage.local.get(['cbDeviceId'], (res) => {
                if (res.cbDeviceId) return resolve(res.cbDeviceId);
                const novo = 'dev_' + crypto.randomUUID();
                chrome.storage.local.set({ cbDeviceId: novo }, () => resolve(novo));
            });
        });
    }

    async function firebaseGet(path) {
        const resp = await fetch(`${CB_FIREBASE_URL}/${path}.json`);
        return resp.json();
    }
    async function firebasePut(path, valor) {
        await fetch(`${CB_FIREBASE_URL}/${path}.json`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(valor)
        });
    }

    function render() {
        lista.innerHTML = '';
        if (!tarefas.length) {
            const vazio = document.createElement('div');
            vazio.className = 'tarefas-rapidas-vazio';
            vazio.textContent = 'nenhuma tarefa por aqui ainda';
            lista.appendChild(vazio);
            return;
        }
        tarefas.forEach((t) => {
            const item = document.createElement('div');
            item.className = 'tarefas-rapidas-item' + (t.feita ? ' feita' : '');

            const check = document.createElement('button');
            check.className = 'tarefas-rapidas-check';
            check.textContent = t.feita ? '✓' : '';
            check.addEventListener('click', () => alternarFeita(t.id));

            const texto = document.createElement('span');
            texto.className = 'tarefas-rapidas-texto';
            texto.textContent = t.texto;

            const del = document.createElement('button');
            del.className = 'tarefas-rapidas-del';
            del.textContent = '×';
            del.addEventListener('click', () => removerTarefa(t.id));

            item.appendChild(check);
            item.appendChild(texto);
            item.appendChild(del);
            lista.appendChild(item);
        });
    }

    async function salvarNoFirebase() {
        if (!deviceId) return;
        ultimoHashRemoto = JSON.stringify(tarefas);
        await firebasePut(`dispositivos/${deviceId}/tarefas`, tarefas);
    }

    function adicionarTarefa() {
        const texto = input.value.trim();
        if (!texto) return;
        tarefas.push({ id: 't_' + Date.now(), texto, feita: false });
        input.value = '';
        render();
        salvarNoFirebase();
    }

    function alternarFeita(id) {
        const t = tarefas.find((x) => x.id === id);
        if (t) t.feita = !t.feita;
        render();
        salvarNoFirebase();
    }

    function removerTarefa(id) {
        tarefas = tarefas.filter((x) => x.id !== id);
        render();
        salvarNoFirebase();
    }

    async function puxarDoFirebase() {
        if (!deviceId) return;
        try {
            const remoto = await firebaseGet(`dispositivos/${deviceId}/tarefas`);
            const remotoArr = Array.isArray(remoto) ? remoto.filter(Boolean) : [];
            const hashRemoto = JSON.stringify(remotoArr);
            // Só substitui a lista local se o remoto for diferente do que a
            // GENTE mesma acabou de mandar — evita sobrescrever uma edição
            // que o usuário acabou de fazer aqui com uma leitura antiga.
            if (hashRemoto !== ultimoHashRemoto) {
                tarefas = remotoArr;
                ultimoHashRemoto = hashRemoto;
                render();
            }
        } catch (e) {
            console.warn('[Tarefas] falha ao puxar do Firebase:', e);
        }
    }

    btnAdd.addEventListener('click', adicionarTarefa);
    input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') adicionarTarefa();
    });

    (async () => {
        deviceId = await obterDeviceId();
        await puxarDoFirebase();
        setInterval(puxarDoFirebase, POLL_MS);
    })();
})();
