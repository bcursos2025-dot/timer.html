// =====================================================================
// MODAL "MINHA CONTA" — ID, apelido, senha e token gerados e guardados
// só localmente (chrome.storage.local), sem nenhum backend ainda. É a
// base pra, quando a comunidade existir, o usuário conseguir entrar na
// MESMA conta pelo celular direto no site (ID + senha + token).
//
// Mesmo padrão de modal já usado por pareamento-celular.js (abrir/
// fechar por overlay, botão de copiar com feedback "Copiado!").
// =====================================================================

function cbAccountCharsAleatorios(tamanho, alfabeto) {
    const bytes = new Uint8Array(tamanho);
    crypto.getRandomValues(bytes);
    let out = '';
    for (let i = 0; i < tamanho; i++) out += alfabeto[bytes[i] % alfabeto.length];
    return out;
}

// Sem caracteres ambíguos (0/O, 1/l/I) pra facilitar digitar no celular.
const CB_ACCOUNT_ALFABETO_ID = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const CB_ACCOUNT_ALFABETO_SENHA = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789';

function cbGerarAccountId() {
    return 'CB-' + cbAccountCharsAleatorios(8, CB_ACCOUNT_ALFABETO_ID);
}
function cbGerarAccountSenha() {
    return cbAccountCharsAleatorios(10, CB_ACCOUNT_ALFABETO_SENHA);
}
function cbGerarAccountToken() {
    const bytes = new Uint8Array(24);
    crypto.getRandomValues(bytes);
    return Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
}

document.addEventListener('DOMContentLoaded', () => {
    const btnOpen = document.getElementById('btn-open-account');
    const overlay = document.getElementById('account-modal-overlay');
    const btnClose = document.getElementById('account-modal-close');
    if (!btnOpen || !overlay) return; // segurança, caso o HTML mude

    const inApelido = document.getElementById('account-apelido');
    const inId = document.getElementById('account-id');
    const inSenha = document.getElementById('account-senha');
    const inToken = document.getElementById('account-token');
    const btnVerSenha = document.getElementById('account-ver-senha');
    const btnGerarSenha = document.getElementById('account-gerar-senha');
    const btnCopiarId = document.getElementById('account-copiar-id');
    const btnCopiarToken = document.getElementById('account-copiar-token');
    const btnSairSessoes = document.getElementById('account-sair-sessoes');
    const senhaHint = document.getElementById('account-senha-hint');
    const msgCopiado = document.getElementById('account-copiado-msg');

    let ultimaSenhaValida = '';

    // ---- Garante que a conta existe (gera na primeira vez que o popup abre) ----
    function garantirConta(callback) {
        chrome.storage.local.get(['cbAccountId', 'cbAccountApelido', 'cbAccountSenha', 'cbAccountToken'], (res) => {
            const patch = {};
            if (!res.cbAccountId) patch.cbAccountId = cbGerarAccountId();
            if (!res.cbAccountSenha) patch.cbAccountSenha = cbGerarAccountSenha();
            if (!res.cbAccountToken) patch.cbAccountToken = cbGerarAccountToken();
            if (Object.keys(patch).length) {
                chrome.storage.local.set(patch, () => callback({ ...res, ...patch }));
            } else {
                callback(res);
            }
        });
    }

    function preencherCampos(dados) {
        inApelido.value = dados.cbAccountApelido || '';
        inId.value = dados.cbAccountId || '';
        inSenha.value = dados.cbAccountSenha || '';
        inToken.value = dados.cbAccountToken || '';
        ultimaSenhaValida = dados.cbAccountSenha || '';
    }

    function mostrarCopiado() {
        msgCopiado.classList.add('show');
        clearTimeout(mostrarCopiado._t);
        mostrarCopiado._t = setTimeout(() => msgCopiado.classList.remove('show'), 1600);
    }

    async function copiarValor(valor) {
        try {
            await navigator.clipboard.writeText(valor);
        } catch (e) {
            // Fallback caso a API de clipboard esteja bloqueada no contexto do popup.
            const tmp = document.createElement('textarea');
            tmp.value = valor;
            document.body.appendChild(tmp);
            tmp.select();
            document.execCommand('copy');
            tmp.remove();
        }
        mostrarCopiado();
    }

    // ---- Abrir/fechar modal ----
    btnOpen.addEventListener('click', () => {
        garantirConta(preencherCampos);
        overlay.classList.add('open');
    });
    btnClose?.addEventListener('click', () => overlay.classList.remove('open'));
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) overlay.classList.remove('open');
    });

    // ---- Apelido: salva ao sair do campo ----
    inApelido.addEventListener('change', () => {
        const valor = inApelido.value.trim().slice(0, 24);
        inApelido.value = valor;
        chrome.storage.local.set({ cbAccountApelido: valor });
    });

    // ---- Senha: editável, mas com mínimo de 6 caracteres ----
    inSenha.addEventListener('change', () => {
        const valor = inSenha.value.trim();
        if (valor.length < 6) {
            senhaHint.textContent = 'A senha precisa ter pelo menos 6 caracteres — mantive a anterior.';
            senhaHint.classList.add('is-erro');
            inSenha.value = ultimaSenhaValida;
            setTimeout(() => {
                senhaHint.textContent = 'Salva sozinha ao sair do campo. Mínimo de 6 caracteres.';
                senhaHint.classList.remove('is-erro');
            }, 2600);
            return;
        }
        ultimaSenhaValida = valor;
        chrome.storage.local.set({ cbAccountSenha: valor });
    });

    // ---- Mostrar/ocultar senha ----
    let senhaVisivel = false;
    btnVerSenha.addEventListener('click', () => {
        senhaVisivel = !senhaVisivel;
        inSenha.type = senhaVisivel ? 'text' : 'password';
        btnVerSenha.title = senhaVisivel ? 'Ocultar senha' : 'Mostrar senha';
        btnVerSenha.innerHTML = senhaVisivel
            ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.94 10.94 0 0 1 12 19c-7 0-11-7-11-7a20.6 20.6 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 7 11 7a20.6 20.6 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><path d="M1 1l22 22"/></svg>'
            : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7Z"/><circle cx="12" cy="12" r="3"/></svg>';
    });

    // ---- Gerar nova senha ----
    btnGerarSenha.addEventListener('click', () => {
        if (!confirm('Isso troca sua senha agora. Você vai precisar da nova senha pra entrar pelo celular. Continuar?')) return;
        const nova = cbGerarAccountSenha();
        inSenha.value = nova;
        inSenha.type = 'text';
        senhaVisivel = true;
        btnVerSenha.title = 'Ocultar senha';
        ultimaSenhaValida = nova;
        chrome.storage.local.set({ cbAccountSenha: nova });
    });

    // ---- Copiar ID / token ----
    btnCopiarId.addEventListener('click', () => copiarValor(inId.value));
    btnCopiarToken.addEventListener('click', () => copiarValor(inToken.value));

    // ---- Gerar novo token (derruba qualquer sessão logada em outro aparelho) ----
    btnSairSessoes.addEventListener('click', () => {
        if (!confirm('Isso desconecta imediatamente qualquer celular já logado com o token atual. Gerar um novo token?')) return;
        const novo = cbGerarAccountToken();
        inToken.value = novo;
        chrome.storage.local.set({ cbAccountToken: novo });
    });
});
