// Configurações → Estatísticas do QConcursos: liga/desliga a busca automática (cbQcEstatAuto), mostra quantas questões
// já têm estatística guardada e como foi a última busca, e copia a "amostra" (a última leitura crua) para a área de
// transferência, para conferir a leitura quando o site mudar ou der problema.
(function () {
    'use strict';
    const resumo = document.getElementById('qcestat-resumo');
    const botao = document.getElementById('qcestat-copiar');
    const aviso = document.getElementById('qcestat-aviso');
    const chave = document.getElementById('qcestat-auto');
    if (!resumo || !window.chrome || !chrome.storage) return;

    const minutos = (ts) => Math.max(0, Math.round((Date.now() - ts) / 60000));

    function atualizar() {
        chrome.storage.local.get(['cbQcEstat', 'cbQcEstatAmostra', 'cbQcEstatStatus', 'cbQcEstatAuto'], (r) => {
            const mapa = (r && r.cbQcEstat) || {};
            const n = Object.keys(mapa).length;
            const comResultado = Object.keys(mapa).filter((k) => mapa[k] && typeof mapa[k].acertei === 'boolean' && mapa[k].pct != null).length;
            const st = r && r.cbQcEstatStatus;
            const am = r && r.cbQcEstatAmostra;
            if (chave && document.activeElement !== chave) chave.checked = r.cbQcEstatAuto !== false;
            let txt = `Questões com estatística guardada: ${n} (${comResultado} já comparáveis com o seu resultado).`;
            if (st) {
                txt += st.ok
                    ? ` Última busca automática há ${minutos(st.ts)} min.`
                    : ` Última busca automática falhou há ${minutos(st.ts)} min: ${st.erro || 'motivo desconhecido'}.`;
            } else if (r.cbQcEstatAuto !== false) {
                txt += ' Nenhuma busca ainda: responda uma questão no QConcursos (logado) com a página aberta.';
            }
            if (am && !am.interpretado) txt += ' A última leitura não foi entendida: use “Copiar amostra”.';
            resumo.textContent = txt;
        });
    }
    atualizar();
    setInterval(atualizar, 3000);

    if (chave) {
        chave.addEventListener('change', () => chrome.storage.local.set({ cbQcEstatAuto: chave.checked }));
    }

    if (botao) {
        botao.addEventListener('click', () => {
            chrome.storage.local.get(['cbQcEstatAmostra', 'cbQcEstatStatus'], async (r) => {
                const am = r && r.cbQcEstatAmostra;
                aviso.hidden = false;
                if (!am) { aviso.textContent = 'Ainda não há amostra: responda uma questão no QConcursos (logado) e tente de novo.'; return; }
                try {
                    await navigator.clipboard.writeText(JSON.stringify({ amostra: am, status: r.cbQcEstatStatus || null }, null, 2));
                    aviso.textContent = 'Amostra copiada. Cole na conversa para eu conferir a leitura.';
                } catch (e) {
                    aviso.textContent = 'Não consegui copiar automaticamente. Tente de novo com o popup em foco.';
                }
            });
        });
    }
})();
