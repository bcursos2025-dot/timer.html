// ===================== TENDÊNCIA DE DESEMPENHO EM QUESTÕES =====================
//
// Duas camadas, de propósito separadas:
//   • ESTATÍSTICA (funções puras, sem DOM — rodam em Node, ver interface-popup/testes):
//     intervalo de Wilson, teste de tendência de Cochran–Armitage e projeção em escala logística.
//   • DESENHO (render): cartão com um número, uma frase e um gráfico limpo.
//
// Por que não a regressão linear de antes:
//   1. Com os snapshots "7 dias" e "30 dias" só existem DOIS pontos (a média dos últimos 7 dias e a
//      dos 23 dias anteriores). Uma reta por dois pontos sempre parece perfeita, e o "em queda" saía
//      de 61% (31 questões) contra 68% (19 questões): uma diferença que o acaso explica sozinho
//      (z ≈ 0,5). O texto mandava a pessoa "voltar na teoria" por causa de ruído.
//   2. A previsão de datas usava "fatores de resistência" inventados (60%, 30%, 15%).
// Aqui a tendência só é afirmada quando supera a margem de erro; com 2 pontos o teste vira o teste
// de duas proporções, com N pontos vira o de tendência — o mesmo cálculo serve aos dois casos.
(function (root) {
    'use strict';

    const Z95 = 1.959963985;   // 95% bicaudal
    const Z80 = 1.2815515655;  // "indício": 80% bicaudal
    const MIN_QUESTOES = 20;   // abaixo disso não se afirma tendência nenhuma

    // ------------------------------------------------------------------ estatística
    // Intervalo de Wilson (melhor que o normal simples com poucas questões).
    function wilson(k, n, z) {
        z = z || Z95;
        if (!n) return { p: 0, lo: 0, hi: 0 };
        const p = k / n, z2 = z * z, d = 1 + z2 / n;
        const c = p + z2 / (2 * n);
        const a = z * Math.sqrt((p * (1 - p) + z2 / (4 * n)) / n);
        return { p, lo: Math.max(0, (c - a) / d), hi: Math.min(1, (c + a) / d) };
    }

    // Teste de tendência de Cochran–Armitage sobre pontos { x (dias, hoje = 0), k (acertos), n (questões) }.
    // b = variação da taxa de acerto por dia (fração), se = erro-padrão de b sob "sem tendência".
    function testeTendencia(pts) {
        const p = (pts || []).filter((q) => q && q.n > 0);
        const N = p.reduce((s, q) => s + q.n, 0);
        if (p.length < 2 || N < 1) return null;
        const K = p.reduce((s, q) => s + q.k, 0);
        const pbar = K / N;
        const xbar = p.reduce((s, q) => s + q.n * q.x, 0) / N;
        const Sxx = p.reduce((s, q) => s + q.n * (q.x - xbar) * (q.x - xbar), 0);
        if (Sxx < 1e-9) return null;
        const Sxy = p.reduce((s, q) => s + (q.x - xbar) * (q.k - q.n * pbar), 0);
        const b = Sxy / Sxx;
        const vari = pbar * (1 - pbar);
        const se = vari > 0 ? Math.sqrt(vari / Sxx) : 0;
        return { N, K, pbar, xbar, b, se, z: se > 0 ? b / se : 0, pontos: p.length };
    }

    // 'poucos' | 'estavel' | 'indicio-sobe' | 'indicio-cai' | 'sobe' | 'cai'
    function veredito(t) {
        if (!t || t.N < MIN_QUESTOES) return 'poucos';
        const az = Math.abs(t.z);
        if (az >= Z95) return t.z > 0 ? 'sobe' : 'cai';
        if (az >= Z80) return t.z > 0 ? 'indicio-sobe' : 'indicio-cai';
        return 'estavel';
    }

    const logit = (p) => Math.log(p / (1 - p));
    const limitar = (p) => Math.min(0.985, Math.max(0.015, p));

    // Dias até a taxa de acerto chegar a `alvo` (0–1), partindo de pAtual, com a variação b (fração/dia).
    // Em escala logística: perto de 100% cada ponto custa mais, sem constantes inventadas.
    function diasAteMeta(pAtual, alvo, b, vari) {
        if (!(b > 0)) return null;
        if (pAtual >= alvo) return 0;
        const bLogit = b / Math.max(vari, 0.05);
        return (logit(limitar(alvo)) - logit(limitar(pAtual))) / bLogit;
    }
    // { central, rapido, lento } em dias; lento = null quando a faixa de erro inclui "sem melhora".
    function projecao(t, pAtual, alvo) {
        const vari = t.pbar * (1 - t.pbar);
        return {
            central: diasAteMeta(pAtual, alvo, t.b, vari),
            rapido: diasAteMeta(pAtual, alvo, t.b + Z95 * t.se, vari),
            lento: diasAteMeta(pAtual, alvo, t.b - Z95 * t.se, vari),
        };
    }

    // Próxima meta de referência do app: 60% → 80% → 90%.
    function proximaMeta(pct) { return pct < 60 ? 60 : pct < 80 ? 80 : pct < 90 ? 90 : null; }

    // ------------------------------------------------------------------ dados
    const chaveDia = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

    // Um ponto por dia com questões, últimos `dias` dias. x = 0 é hoje; passado é negativo.
    function pontosDiarios(daily, hoje, dias) {
        const out = [];
        for (let i = (dias || 30) - 1; i >= 0; i--) {
            const d = new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate() - i);
            const r = daily && daily[chaveDia(d)];
            if (r && r.total > 0) out.push({ x: -i, k: Math.min(r.acertos || 0, r.total), n: r.total, data: d });
        }
        return out;
    }

    // Taxa de acerto dos 7 dias que terminam em x (soma de acertos / soma de questões — não média de médias).
    function janela7(diarios, x) {
        let k = 0, n = 0;
        diarios.forEach((q) => { if (q.x <= x && q.x > x - 7) { k += q.k; n += q.n; } });
        return { k, n };
    }

    // Série suavizada para o gráfico: janela móvel de 7 dias, só onde a janela tem questões suficientes
    // pra ser um número que merece ser desenhado.
    function serieSuave(diarios, hoje, minN) {
        minN = minN || 8;
        const out = [];
        for (let x = -29; x <= 0; x++) {
            const j = janela7(diarios, x);
            if (j.n >= minN) {
                const d = new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate() + x);
                out.push({ x, p: (j.k / j.n) * 100, n: j.n, k: j.k, data: d });
            }
        }
        return out;
    }

    // Decide a fonte e calcula tudo que o desenho precisa.
    //  - histórico diário, se tem 5+ dias E cobre a maior parte do que o QConcursos reporta em 30 dias
    //    (senão o histórico começou há pouco e subestimaria o volume);
    //  - senão, as duas janelas do QConcursos (7 dias × 23 dias anteriores);
    //  - senão, o diário que houver (2+ dias); senão, nada.
    function analisar(stats, daily, hoje) {
        hoje = hoje || new Date();
        stats = stats || {};
        const diarios = pontosDiarios(daily, hoje, 30);
        const s7 = stats[7], s30 = stats[30];
        let agg = null;
        if (s7 && s30 && s7.total > 0 && s30.total > s7.total) {
            const ant = { k: s30.acertos - s7.acertos, n: s30.total - s7.total };
            if (ant.n > 0 && ant.k >= 0 && ant.k <= ant.n) {
                agg = { recente: { x: -3.5, k: Math.min(s7.acertos, s7.total), n: s7.total }, anterior: { x: -18.5, k: ant.k, n: ant.n } };
            }
        }
        const somaDiaria = diarios.reduce((s, q) => s + q.n, 0);
        const cobertura = s30 && s30.total > 0 ? somaDiaria / s30.total : 1;

        let modo = 'vazio';
        if (diarios.length >= 5 && cobertura >= 0.6) modo = 'linha';
        else if (agg) modo = 'barras';
        else if (diarios.length >= 2) modo = 'linha';
        if (modo === 'vazio') return { modo };

        if (modo === 'barras') {
            const teste = testeTendencia([agg.recente, agg.anterior]);
            const w = wilson(agg.recente.k, agg.recente.n), wa = wilson(agg.anterior.k, agg.anterior.n);
            return {
                modo, teste, veredito: veredito(teste), agg,
                atual: { pct: w.p * 100, n: agg.recente.n, rotulo: 'Acerto nos últimos 7 dias' },
                ic: { recente: w, anterior: wa },
            };
        }
        const teste = testeTendencia(diarios);
        const serie = serieSuave(diarios, hoje);
        // O número em destaque: os 7 dias até o último dia com dado (que normalmente é hoje).
        const ultimoX = diarios[diarios.length - 1].x;
        const j = janela7(diarios, ultimoX);
        const w = wilson(j.k, j.n);
        return {
            modo, teste, veredito: veredito(teste), diarios, serie,
            atual: { pct: j.n ? (j.k / j.n) * 100 : 0, n: j.n, rotulo: ultimoX === 0 ? 'Acerto nos últimos 7 dias' : 'Acerto na semana até ' + String(diarios[diarios.length - 1].data.getDate()).padStart(2, '0') + '/' + String(diarios[diarios.length - 1].data.getMonth() + 1).padStart(2, '0') },
            ic: { recente: w },
            total: somaDiaria,
        };
    }

    // ------------------------------------------------------------------ texto
    const plural = (n, um, varios) => `${n} ${n === 1 ? um : varios}`;
    const fmt1 = (v) => v.toFixed(1).replace('.', ',');

    function fmtPrazo(dias) {
        if (dias == null) return null;
        if (dias > 365) return 'mais de um ano';
        if (dias < 21) return plural(Math.max(1, Math.round(dias)), 'dia', 'dias');
        return plural(Math.round(dias / 7), 'semana', 'semanas');
    }

    // { chip: {texto, tom}, frase, projecao? }
    function textos(a) {
        const pct = Math.round(a.atual.pct);
        const t = a.teste;
        const porSemana = t ? t.b * 7 * 100 : 0; // pp por semana
        switch (a.veredito) {
            case 'poucos':
                return { chip: { texto: 'Poucos dados', tom: 'neutro' }, frase: 'Ainda são poucas questões para enxergar tendência. Conforme você resolve mais, esta análise fica confiável.' };
            case 'sobe': {
                const meta = proximaMeta(pct);
                let frase = `Seu acerto está subindo, cerca de ${fmt1(Math.abs(porSemana))} pontos por semana.`;
                if (meta) {
                    const pr = projecao(t, pct / 100, meta / 100);
                    const c = fmtPrazo(pr.central);
                    if (c) {
                        const r = pr.rapido != null && pr.lento != null ? ` (entre ${fmtPrazo(pr.rapido)} e ${fmtPrazo(pr.lento)})` : '';
                        frase += ` No ritmo atual, deve chegar a ${meta}% em ${c}${r}.`;
                    }
                } else {
                    frase += ' Você já está na zona de aprovação: mantenha a revisão.';
                }
                return { chip: { texto: `+${fmt1(Math.abs(porSemana))} pp/sem`, tom: 'bom' }, frase };
            }
            case 'cai':
                return { chip: { texto: `−${fmt1(Math.abs(porSemana))} pp/sem`, tom: 'ruim' }, frase: `Seu acerto caiu, cerca de ${fmt1(Math.abs(porSemana))} pontos por semana. Vale revisar a teoria dos assuntos que você mais erra.` };
            case 'indicio-sobe':
                return { chip: { texto: 'Indício de alta', tom: 'neutro' }, frase: 'Há sinais de melhora, mas ainda dentro da margem de erro. Mais algumas sessões confirmam.' };
            case 'indicio-cai':
                return { chip: { texto: 'Indício de queda', tom: 'neutro' }, frase: 'Há sinais de queda, mas ainda dentro da margem de erro. Acompanhe nos próximos dias antes de mudar o plano.' };
            default:
                return {
                    chip: { texto: 'Estável', tom: 'neutro' },
                    frase: pct >= 90 ? 'Você está na zona de aprovação e se mantendo. Foque em revisar os erros finos.' : 'Sem mudança relevante: as oscilações recentes cabem na margem de erro.',
                };
        }
    }

    // ------------------------------------------------------------------ desenho
    const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const f1 = (v) => (Math.round(v * 10) / 10).toString();
    const MESES = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
    const dm = (d) => `${d.getDate()} ${MESES[d.getMonth()]}`;
    const ICONE_EXPANDIR = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/></svg>';

    // Curva suave sem "estourar" além dos pontos vizinhos (Catmull-Rom com o controle preso entre os dois Y).
    function caminhoSuave(pts) {
        if (pts.length < 2) return '';
        let d = `M${f1(pts[0].X)} ${f1(pts[0].Y)}`;
        for (let i = 0; i < pts.length - 1; i++) {
            const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
            const lo = Math.min(p1.Y, p2.Y), hi = Math.max(p1.Y, p2.Y);
            const c1y = Math.max(lo, Math.min(hi, p1.Y + (p2.Y - p0.Y) / 6));
            const c2y = Math.max(lo, Math.min(hi, p2.Y - (p3.Y - p1.Y) / 6));
            d += ` C${f1(p1.X + (p2.X - p0.X) / 6)} ${f1(c1y)} ${f1(p2.X - (p3.X - p1.X) / 6)} ${f1(c2y)} ${f1(p2.X)} ${f1(p2.Y)}`;
        }
        return d;
    }

    function graficoLinha(a, grande) {
        const W = 340, H = grande ? 210 : 150, padL = 4, padR = 30, padT = 12, padB = 22;
        const pw = W - padL - padR, ph = H - padT - padB;
        const serie = a.serie;
        if (serie.length < 2) {
            return { html: '<p class="tnd-vazio tnd-vazio--mini">Ainda não há dias suficientes com muitas questões para desenhar a curva.</p>', pts: null, W };
        }
        const vals = serie.map((p) => p.p);
        const meta = proximaMeta(a.atual.pct);
        let lo = Math.floor((Math.min.apply(null, vals) - 6) / 10) * 10;
        let hi = Math.ceil((Math.max.apply(null, vals) + 6) / 10) * 10;
        if (meta && meta <= Math.max.apply(null, vals) + 30) hi = Math.max(hi, meta + 5 > 100 ? 100 : Math.ceil((meta + 4) / 10) * 10);
        lo = Math.max(0, lo); hi = Math.min(100, hi);
        if (hi - lo < 30) { const falta = 30 - (hi - lo); lo = Math.max(0, lo - Math.ceil(falta / 2 / 10) * 10); hi = Math.min(100, lo + 30); lo = Math.max(0, hi - 30); }
        const X = (x) => padL + ((x + 29) / 29) * pw;
        const Y = (p) => padT + (1 - (p - lo) / (hi - lo)) * ph;
        const pts = serie.map((s) => ({ ...s, X: X(s.x), Y: Y(s.p) }));

        const passo = hi - lo <= 40 ? 10 : 20;
        let grade = '';
        for (let v = lo; v <= hi; v += passo) {
            grade += `<line class="tnd-grade" x1="${padL}" x2="${padL + pw}" y1="${f1(Y(v))}" y2="${f1(Y(v))}"/><text class="tnd-eixo" x="${W - 2}" y="${f1(Y(v) + 3)}" text-anchor="end">${v}%</text>`;
        }
        // 80% e 90% são as metas do app: linha tracejada discreta, só se estiverem na janela.
        let refs = '';
        [80, 90].forEach((m) => { if (m > lo && m < hi) refs += `<line class="tnd-ref" x1="${padL}" x2="${padL + pw}" y1="${f1(Y(m))}" y2="${f1(Y(m))}"/>`; });

        const linha = caminhoSuave(pts);
        const base = f1(padT + ph);
        const area = `${linha} L${f1(pts[pts.length - 1].X)} ${base} L${f1(pts[0].X)} ${base} Z`;
        const fim = pts[pts.length - 1];
        // Reta ajustada só quando a tendência é confirmada: desenhada SOBRE o período observado, sem inventar futuro.
        let tend = '';
        if ((a.veredito === 'sobe' || a.veredito === 'cai') && a.teste) {
            const t = a.teste, pAt = (x) => (t.pbar + t.b * (x - t.xbar)) * 100;
            const x0 = pts[0].x, x1 = fim.x;
            const clamp = (p) => Math.min(hi, Math.max(lo, p));
            tend = `<line class="tnd-tend" x1="${f1(pts[0].X)}" y1="${f1(Y(clamp(pAt(x0))))}" x2="${f1(fim.X)}" y2="${f1(Y(clamp(pAt(x1))))}"/>`;
        }
        const rotulos = `<text class="tnd-eixo" x="${padL}" y="${H - 5}" text-anchor="start">${dm(new Date(a.serie[0].data))}</text><text class="tnd-eixo" x="${f1(padL + pw)}" y="${H - 5}" text-anchor="end">hoje</text>`;
        const resumo = `Curva de acerto dos últimos 30 dias, de ${Math.round(vals[0])}% a ${Math.round(vals[vals.length - 1])}%.`;
        const html = `
            <div class="tnd-grafico" data-w="${W}">
                <svg viewBox="0 0 ${W} ${H}" class="tnd-svg" role="img" aria-label="${esc(resumo)}">
                    <defs><linearGradient id="tnd-area" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--accent)" stop-opacity="0.22"/><stop offset="1" stop-color="var(--accent)" stop-opacity="0"/></linearGradient></defs>
                    ${grade}${refs}
                    <path class="tnd-area" d="${area}"/>
                    ${tend}
                    <path class="tnd-linha" d="${linha}" pathLength="1"/>
                    <line class="tnd-guia" x1="0" x2="0" y1="${padT}" y2="${base}" style="display:none"/>
                    <circle class="tnd-hover" r="4.5" cx="0" cy="0" style="display:none"/>
                    <circle class="tnd-fim" cx="${f1(fim.X)}" cy="${f1(fim.Y)}" r="4.5"/>
                    ${rotulos}
                    <rect class="tnd-alvo" x="0" y="0" width="${W}" height="${H}" fill="transparent"/>
                </svg>
                <div class="tnd-tip" hidden></div>
            </div>`;
        return { html, pts, W };
    }

    function ligarHover(raiz, pts, W) {
        const svg = raiz.querySelector('svg'), tip = raiz.querySelector('.tnd-tip');
        const guia = svg.querySelector('.tnd-guia'), bolinha = svg.querySelector('.tnd-hover');
        if (!svg || !tip) return;
        const esconder = () => { tip.hidden = true; guia.style.display = 'none'; bolinha.style.display = 'none'; };
        const mover = (ev) => {
            const r = svg.getBoundingClientRect();
            const px = ((ev.clientX - r.left) / r.width) * W;
            let m = pts[0];
            pts.forEach((p) => { if (Math.abs(p.X - px) < Math.abs(m.X - px)) m = p; });
            guia.setAttribute('x1', m.X); guia.setAttribute('x2', m.X); guia.style.display = '';
            bolinha.setAttribute('cx', m.X); bolinha.setAttribute('cy', m.Y); bolinha.style.display = '';
            tip.innerHTML = `<b>${Math.round(m.p)}%</b><span>${dm(new Date(m.data))} · ${plural(m.n, 'questão', 'questões')} em 7 dias</span>`;
            tip.hidden = false;
            const esq = Math.min(78, Math.max(22, (m.X / W) * 100));
            tip.style.left = esq + '%';
        };
        svg.addEventListener('pointermove', mover);
        svg.addEventListener('pointerdown', mover);
        svg.addEventListener('pointerleave', esconder);
    }

    // Duas janelas na MESMA escala (0–100%): o ponto é o acerto medido e a faixa é onde o acerto real
    // provavelmente está (intervalo de Wilson). Faixas que se sobrepõem muito = sem diferença que o acaso
    // não explique; é exatamente isso que o texto acima diz, agora dá para ver.
    function graficoBarras(a) {
        const linha = (rot, q, w, cls) => {
            const pc = Math.round((q.k / q.n) * 100), lo = Math.round(w.lo * 100), hi = Math.round(w.hi * 100);
            return `
                <div class="tnd-bl">
                    <div class="tnd-bl-top"><span>${rot}</span><b>${pc}%</b></div>
                    <div class="tnd-trilho" role="img" aria-label="${esc(`${rot}: ${pc}% de acerto, provavelmente entre ${lo}% e ${hi}%`)}">
                        <span class="tnd-faixa ${cls}" style="left:${lo}%;width:${Math.max(2, hi - lo)}%"></span>
                        <span class="tnd-ponto ${cls}" style="left:${pc}%"></span>
                    </div>
                    <small>${plural(q.n, 'questão', 'questões')} · acerto real provavelmente entre ${lo}% e ${hi}%</small>
                </div>`;
        };
        const escala = '<div class="tnd-escala" aria-hidden="true"><span style="left:0">0%</span><span style="left:50%">50%</span><span style="left:100%">100%</span></div>';
        return `<div class="tnd-barras">${linha('Últimos 7 dias', a.agg.recente, a.ic.recente, 'rec')}${linha('23 dias anteriores', a.agg.anterior, a.ic.anterior, 'ant')}${escala}</div>`;
    }

    const COMO = 'Comparamos o seu acerto ao longo dos dias com um teste estatístico de tendência (Cochran–Armitage) e só dizemos que subiu ou caiu quando a diferença é maior que a margem de erro (95%). A faixa “entre X% e Y%” é o intervalo de Wilson. A previsão de prazo usa a taxa de acerto em escala logística: cada ponto a mais custa mais esforço perto dos 100%.';

    // Desenha o cartão dentro de `el`. dados: { stats, daily, hoje? }. opts: { grande, semExpandir }.
    function render(el, dados, opts) {
        opts = opts || {};
        const a = analisar(dados.stats, dados.daily, dados.hoje);
        if (a.modo === 'vazio') {
            el.innerHTML = '<p class="tnd-vazio">Ainda não há dados suficientes para mostrar a sua tendência. Resolva questões no QConcursos com a extensão ativa e volte aqui.</p>';
            return a;
        }
        const tx = textos(a);
        const pct = Math.round(a.atual.pct);
        const ic = a.ic.recente, margem = Math.round(((ic.hi - ic.lo) / 2) * 100);
        const gl = a.modo === 'barras' ? null : graficoLinha(a, !!opts.grande);
        const grafico = a.modo === 'barras' ? graficoBarras(a) : gl.html;
        const base = a.modo === 'barras'
            ? `Base: ${plural(a.agg.recente.n, 'questão', 'questões')} nos últimos 7 dias e ${a.agg.anterior.n} nos 23 dias anteriores (dados do QConcursos).`
            : `Base: ${plural(a.total, 'questão', 'questões')} em ${plural(a.diarios.length, 'dia', 'dias')} de estudo nos últimos 30 dias.`;
        el.innerHTML = `
            <section class="tnd${opts.grande ? ' tnd-grande' : ''}">
                <div class="tnd-cab">
                    <span class="tnd-tit">Tendência</span>
                    ${opts.semExpandir ? '' : `<button type="button" id="questoes-trend-expand-btn" class="tnd-expand" title="Ver em tela cheia" aria-label="Ver em tela cheia">${ICONE_EXPANDIR}</button>`}
                </div>
                <div class="tnd-hero">
                    <div class="tnd-num"><b>${pct}</b><small>%</small></div>
                    <span class="tnd-chip tnd-chip--${tx.chip.tom}">${esc(tx.chip.texto)}</span>
                </div>
                <div class="tnd-leg">${esc(a.atual.rotulo)} · ${plural(a.atual.n, 'questão', 'questões')} · margem ±${margem} pp</div>
                <p class="tnd-frase">${esc(tx.frase)}</p>
                ${grafico}
                <p class="tnd-rodape">${esc(base)}</p>
                <details class="tnd-como"><summary>Como calculamos</summary><p>${esc(COMO)}</p></details>
            </section>`;
        if (gl && gl.pts) ligarHover(el.querySelector('.tnd-grafico'), gl.pts, gl.W);
        return a;
    }

    const api = { Z95, Z80, MIN_QUESTOES, wilson, testeTendencia, veredito, diasAteMeta, projecao, proximaMeta, pontosDiarios, janela7, serieSuave, analisar, textos, fmtPrazo, render };
    if (typeof module !== 'undefined' && module.exports) module.exports = api;
    else root.CBTendencia = api;
})(typeof window !== 'undefined' ? window : globalThis);
