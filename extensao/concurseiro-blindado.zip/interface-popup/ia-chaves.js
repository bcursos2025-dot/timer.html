// ===================== CHAVES OPCIONAIS DE IA (Configurações → Inteligência artificial) =====================
//
// A fila de provedores mora em dados-config/ia-provider.js. Aqui só se guarda o que a
// pessoa colar:
//   chrome.storage.local.cbChavesIA = { groq, openrouter, mistral, bai, tavily, brave }
//     (tavily e brave são da PESQUISA NA WEB do chat, ver dados-config/ia-busca-web.js)
//   chrome.storage.local.cbGeminiApiKey            (a mesma chave que o Gemini já usava)
// Nada sai do navegador a não ser nas chamadas ao próprio provedor da chave.
(function () {
    'use strict';

    const PROVEDORES = [
        { id: 'groq',       nome: 'Groq',       dica: 'Gratuito, sem cartão (30 req/min)', link: 'https://console.groq.com/keys' },
        { id: 'openrouter', nome: 'OpenRouter', dica: 'Gratuito, modelos “:free”',          link: 'https://openrouter.ai/keys' },
        { id: 'mistral',    nome: 'Mistral',    dica: 'Gratuito, sem cartão',               link: 'https://console.mistral.ai/api-keys' },
        { id: 'gemini',     nome: 'Google Gemini', dica: 'Gratuito, sem cartão',            link: 'https://aistudio.google.com/apikey' },
        { id: 'bai',        nome: 'B.AI',       dica: 'Usa créditos da conta (modelos com desconto)', link: 'https://chat.b.ai/key' },
        // Pesquisa na web (botão "Web" do chat). Já funciona SEM chave (modo keyless da Tavily, com limite
        // baixo); a chave só aumenta o limite. A Brave é uma reserva opcional.
        { id: 'tavily',     nome: 'Tavily',     dica: 'Opcional: o botão Web já funciona sem chave, com limite baixo. Com a chave grátis são 1.000 buscas por mês, sem cartão.', link: 'https://app.tavily.com/home', grupo: 'web' },
        { id: 'brave',      nome: 'Brave Search', dica: 'Reserva opcional, usada se a Tavily falhar. O cadastro pede cartão de crédito (verificação antifraude); veja o limite gratuito no site.', link: 'https://brave.com/search/api/', grupo: 'web' },
    ];
    const TITULOS_GRUPO = { web: 'Pesquisa na web' };

    // Botão "Conectar" do Puter (Configurações → IA): abre a página de login numa aba, porque a janela de
    // login tira o foco e o popup fecharia.
    const btnPuter = document.getElementById('iach-puter-abrir');
    if (btnPuter && window.chrome && chrome.tabs) {
        btnPuter.addEventListener('click', () => chrome.tabs.create({ url: chrome.runtime.getURL('interface-popup/puter.html') }));
    }

    const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const lista = document.getElementById('iach-lista');
    if (!lista || !window.chrome || !chrome.storage) return;

    function ler(cb) {
        chrome.storage.local.get(['cbChavesIA', 'cbGeminiApiKey'], (res) => {
            const chaves = Object.assign({}, (res && res.cbChavesIA) || {});
            if (res && res.cbGeminiApiKey) chaves.gemini = res.cbGeminiApiKey;
            cb(chaves);
        });
    }

    function gravar(id, valor, cb) {
        valor = String(valor || '').trim();
        if (id === 'gemini') {
            const fim = () => cb && cb();
            if (valor) chrome.storage.local.set({ cbGeminiApiKey: valor }, fim);
            else chrome.storage.local.remove('cbGeminiApiKey', fim);
            return;
        }
        chrome.storage.local.get(['cbChavesIA'], (res) => {
            const chaves = Object.assign({}, (res && res.cbChavesIA) || {});
            if (valor) chaves[id] = valor; else delete chaves[id];
            chrome.storage.local.set({ cbChavesIA: chaves }, () => cb && cb());
        });
    }

    // Mostra só o final da chave: o campo nunca devolve a chave inteira na tela.
    const mascara = (k) => '••••' + String(k).slice(-4);

    function desenhar() {
        ler((chaves) => {
            let grupoAtual = '';
            lista.innerHTML = PROVEDORES.map((p) => {
                const salva = chaves[p.id];
                const cabecalho = (p.grupo || '') !== grupoAtual && TITULOS_GRUPO[p.grupo]
                    ? `<div class="iach-grupo">${esc(TITULOS_GRUPO[p.grupo])}</div>` : '';
                grupoAtual = p.grupo || '';
                return `${cabecalho}
                <div class="iach-item" data-id="${p.id}">
                    <div class="iach-topo">
                        <strong>${esc(p.nome)}</strong>
                        ${salva ? '<span class="iach-ok">salva</span>' : ''}
                        <a href="${esc(p.link)}" target="_blank" rel="noopener noreferrer">gerar chave</a>
                    </div>
                    <small>${esc(p.dica)}</small>
                    <div class="iach-campo">
                        <input type="password" autocomplete="off" spellcheck="false" placeholder="${salva ? esc(mascara(salva)) : 'Cole a chave aqui'}" aria-label="Chave ${esc(p.nome)}">
                        <button type="button" data-acao="salvar">Salvar</button>
                        ${salva ? '<button type="button" data-acao="remover" class="iach-rm" aria-label="Remover chave">Remover</button>' : ''}
                    </div>
                </div>`;
            }).join('');
        });
    }

    lista.addEventListener('click', (e) => {
        const btn = e.target.closest('button[data-acao]');
        if (!btn) return;
        const item = btn.closest('.iach-item');
        const id = item.dataset.id;
        if (btn.dataset.acao === 'remover') { gravar(id, '', desenhar); return; }
        const valor = item.querySelector('input').value.trim();
        if (!valor) return;
        gravar(id, valor, desenhar);
    });
    lista.addEventListener('keydown', (e) => {
        if (e.key !== 'Enter' || e.target.tagName !== 'INPUT') return;
        e.preventDefault();
        e.target.closest('.iach-item').querySelector('[data-acao="salvar"]').click();
    });

    desenhar();
})();
