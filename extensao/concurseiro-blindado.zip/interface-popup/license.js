// ==========================================================================
// license.js — Sistema de licenciamento Free/Pro do Concurseiro Blindado
// ==========================================================================
// Como funciona:
//  - Cada instalação da extensão tem um ID único (installId), gerado uma
//    vez e salvo em chrome.storage.local. Esse ID é o que a pessoa te manda
//    no WhatsApp quando pede o desbloqueio.
//  - Você gera um "código de licença" com o script generate-license.js
//    (fica só no seu computador, NUNCA vai dentro da extensão). Esse código
//    é uma string tipo "CB1.<payload_base64>.<assinatura_base64>".
//  - O payload contém: installId autorizado, quais features libera, e uma
//    validade opcional (expiresAt). A assinatura é HMAC-SHA256 usando uma
//    chave secreta que só existe nos dois lados (aqui e no seu gerador).
//  - A extensão SÓ aceita o código se a assinatura bater E o installId do
//    código for igual ao installId da própria instalação. Isso impede que
//    um código gerado pra uma pessoa funcione copiado/vazado em outra
//    instalação.
//
// IMPORTANTE SOBRE A CHAVE SECRETA:
//  A LICENSE_SECRET abaixo tem que ser EXATAMENTE a mesma usada no
//  generate-license.js. Troque o valor abaixo por algo só seu (uma string
//  longa e aleatória) e troque a mesma string lá no gerador antes de usar
//  em produção. Nunca poste essa chave em lugar público (github público,
//  etc.) — quem tiver a chave consegue gerar licenças válidas.
// ==========================================================================

// AVISO IMPORTANTE — leia antes de confiar nisso:
// Isso NÃO é proteção de verdade. É só pra chave não aparecer inteira num
// "Ctrl+F" ingênuo no código-fonte. Qualquer pessoa com um pouco mais de
// paciência (abrir o DevTools, colocar um breakpoint em _hmacSha256, ou só
// rodar `console.log(LICENSE_SECRET)` no console da extensão) ainda
// consegue extrair a chave e gerar licenças "all: true" pra sempre — porque
// TODO client-side-only DRM tem esse limite: o código roda na máquina de
// quem você não confia, com a chave junto.
// Se você quer proteção de verdade, o único jeito é validar a licença num
// servidor seu (a extensão manda o installId + código, o servidor responde
// se é válido) — nesse caso a chave nunca sai do seu backend. Isso está
// fora do escopo do que dá pra resolver só editando estes arquivos.
const LICENSE_SECRET = _cbMontarSegredo();
function _cbMontarSegredo() {
    // Chave dividida em pedaços só pra não ficar uma string única e óbvia.
    // TROQUE por pedaços de uma chave longa e aleatória só sua.
    const partes = ['TROQUE-ESTA-', 'CHAVE-POR-UMA-', 'SOMENTE-SUA-', '2026-xyz789'];
    return partes.join('');
}

// Lista de todas as features que podem ser travadas/destravadas.
// Use estas chaves tanto no gerador quanto nos gates espalhados pelo popup.js
const CB_FEATURES = {
    THEMES: 'themes',                 // temas Escuro e Marinho
    AMBIENT_SOUND: 'ambient_sound',    // som de ambiente (chuva/ruído/lofi)
    HARDCORE_MODE: 'hardcore_mode',    // modo hardcore
    REORDER_SECTIONS: 'reorder_sections', // ordem das seções principais
    REORDER_TABS: 'reorder_tabs',      // ordem das abas
    POMODORO: 'pomodoro',              // sistema pomodoro
    MONTHLY_PRODUCTIVITY: 'monthly_productivity', // produtividade mensal
    MONTHLY_HISTORY: 'monthly_history',           // histórico mensal
    QUESTOES: 'questoes',              // sistema de questões (QConcursos)
    CALENDAR: 'calendar',              // escolher/navegar calendário
    EDIT_DAILY_GOAL: 'edit_daily_goal',// editar meta diária
    BREAKS_ACTIVITY: 'breaks_activity', // pausas e atividade (diário/semanal/mensal)
    META_QUESTOES: 'meta_questoes'     // meta diária por número de questões (em vez de horas)
};

// Se quiser um "tudo liberado", o gerador pode marcar all: true no payload
// em vez de listar cada feature.

// --------------------------------------------------------------------
// Utilidades de criptografia (Web Crypto API — já disponível no Chrome)
// --------------------------------------------------------------------
function _b64encode(bytes) {
    let bin = '';
    bytes.forEach(b => bin += String.fromCharCode(b));
    return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
function _b64decode(str) {
    str = str.replace(/-/g, '+').replace(/_/g, '/');
    while (str.length % 4) str += '=';
    const bin = atob(str);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return bytes;
}

async function _hmacSha256(secret, message) {
    const enc = new TextEncoder();
    const key = await crypto.subtle.importKey(
        'raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
    );
    const sig = await crypto.subtle.sign('HMAC', key, enc.encode(message));
    return _b64encode(new Uint8Array(sig));
}

// --------------------------------------------------------------------
// installId — identifica esta instalação de forma única e permanente
// --------------------------------------------------------------------
function getInstallId() {
    return new Promise((resolve) => {
        chrome.storage.local.get(['cbInstallId'], (result) => {
            if (result.cbInstallId) {
                resolve(result.cbInstallId);
                return;
            }
            const id = (crypto.randomUUID ? crypto.randomUUID() : _b64encode(crypto.getRandomValues(new Uint8Array(16))));
            chrome.storage.local.set({ cbInstallId: id }, () => resolve(id));
        });
    });
}

// --------------------------------------------------------------------
// Validação de um código de licença colado pelo usuário
// --------------------------------------------------------------------
async function validateLicenseCode(code) {
    try {
        const parts = (code || '').trim().split('.');
        if (parts.length !== 3 || parts[0] !== 'CB1') {
            return { valid: false, error: 'Código em formato inválido.' };
        }
        const [, payloadB64, sigB64] = parts;

        const expectedSig = await _hmacSha256(LICENSE_SECRET, payloadB64);
        // Comparação — não precisa ser "constant time" aqui pois isso roda
        // 100% client-side e não expõe nada por timing (não é um servidor).
        if (expectedSig !== sigB64) {
            return { valid: false, error: 'Assinatura inválida. Código incorreto ou adulterado.' };
        }

        const payloadJson = new TextDecoder().decode(_b64decode(payloadB64));
        const payload = JSON.parse(payloadJson);

        const myInstallId = await getInstallId();
        if (payload.installId !== myInstallId) {
            return { valid: false, error: 'Este código não pertence a esta instalação. Peça um código gerado para o seu ID.' };
        }

        if (typeof payload.expiresAt === 'number' && Date.now() > payload.expiresAt) {
            return { valid: false, error: 'Este código expirou. Peça um novo.' };
        }

        return { valid: true, payload };
    } catch (e) {
        return { valid: false, error: 'Não foi possível ler este código.' };
    }
}

// --------------------------------------------------------------------
// Aplicar / salvar uma licença validada
// --------------------------------------------------------------------
async function applyLicenseCode(code) {
    const result = await validateLicenseCode(code);
    if (!result.valid) return result;

    await new Promise((resolve) => {
        chrome.storage.sync.set({
            cbLicenseCode: code,
            cbLicensePayload: result.payload
        }, resolve);
    });
    return result;
}

// --------------------------------------------------------------------
// Checar se uma feature está liberada. Sempre revalida a assinatura
// (não confia cegamente no payload salvo) para dificultar edição manual
// do storage via devtools.
// --------------------------------------------------------------------
async function isFeatureUnlocked(featureKey) {
    return new Promise((resolve) => {
        chrome.storage.sync.get(['cbLicenseCode', 'cbPromoLifetimePro'], async (result) => {
            // Promoção de PRO grátis e vitalício (resgatada uma vez pelo botão
            // acima do cronômetro) libera tudo, sem precisar de código.
            if (result.cbPromoLifetimePro === true) return resolve(true);
            if (!result.cbLicenseCode) return resolve(false);
            const check = await validateLicenseCode(result.cbLicenseCode);
            if (!check.valid) return resolve(false);
            const payload = check.payload;
            if (payload.all === true) return resolve(true);
            resolve(Array.isArray(payload.features) && payload.features.includes(featureKey));
        });
    });
}

// Versão que checa várias de uma vez e devolve um objeto { feature: bool }
async function getUnlockedMap() {
    const keys = Object.values(CB_FEATURES);
    const entries = await Promise.all(keys.map(async k => [k, await isFeatureUnlocked(k)]));
    return Object.fromEntries(entries);
}

// --------------------------------------------------------------------
// Promoção "PRO grátis e vitalício" — resgatada uma única vez pelo botão
// que aparece acima do cronômetro para quem ainda está no plano Free.
// Não depende de código nem de installId: é só uma flag local, salva no
// chrome.storage.sync (sincroniza entre computadores logados na mesma
// conta do Chrome), que isFeatureUnlocked() passa a considerar como
// "libera tudo" permanentemente.
// --------------------------------------------------------------------
function resgatarProVitalicio() {
    return new Promise((resolve) => {
        chrome.storage.sync.set({ cbPromoLifetimePro: true }, () => resolve(true));
    });
}
function isPromoLifetimeProResgatado() {
    return new Promise((resolve) => {
        chrome.storage.sync.get(['cbPromoLifetimePro'], (result) => {
            resolve(result.cbPromoLifetimePro === true);
        });
    });
}

// Exporta pro escopo global do popup (popup.js não usa módulos ES, é script clássico)
window.CBLicense = {
    FEATURES: CB_FEATURES,
    getInstallId,
    validateLicenseCode,
    applyLicenseCode,
    isFeatureUnlocked,
    getUnlockedMap,
    resgatarProVitalicio,
    isPromoLifetimeProResgatado
};
