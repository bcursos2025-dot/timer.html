// Página "Nova versão disponível": explica por que atualizar e como ligar a atualização
// automática do Firefox (about:addons). Não leva à loja: a extensão não consegue abrir
// about:addons sozinha, então o passo a passo é feito pela própria pessoa.
(function () {
    // Segue o tema escolhido no popup ("auto" = Claro de dia, Escuro das 18h às 6h).
    function resolver(pref) {
        if (pref === 'auto') { const h = new Date().getHours(); return (h >= 18 || h < 6) ? 'dark' : 'light'; }
        return pref || 'light';
    }
    try {
        chrome.storage.local.get(['themePref', 'cbUpdateDisponivel'], (r) => {
            document.documentElement.setAttribute('data-theme', resolver(r && r.themePref));
            const v = r && r.cbUpdateDisponivel && r.cbUpdateDisponivel.versao;
            if (v) {
                const el = document.getElementById('at-versao');
                el.textContent = 'v' + String(v).replace(/[^\w.\-]/g, '');
                el.hidden = false;
            }
        });
    } catch (e) { /* sem storage: fica no tema padrão */ }

    const btnCopiar = document.getElementById('at-copiar');
    btnCopiar.addEventListener('click', async () => {
        try { await navigator.clipboard.writeText('about:addons'); } catch (e) {
            const t = document.createElement('textarea');
            t.value = 'about:addons';
            document.body.appendChild(t);
            t.select();
            try { document.execCommand('copy'); } catch (e2) { /* sem cópia: o endereço está escrito na tela */ }
            t.remove();
        }
        btnCopiar.textContent = 'Copiado ✓';
        setTimeout(() => { btnCopiar.textContent = 'Copiar endereço'; }, 2000);
    });

    // "Entendi": marca esta versão como vista (o banner do popup também some) e fecha a aba.
    document.getElementById('at-entendi').addEventListener('click', () => {
        try {
            chrome.storage.local.get(['cbUpdateDisponivel'], (r) => {
                const v = r && r.cbUpdateDisponivel && r.cbUpdateDisponivel.versao;
                const fim = () => { try { window.close(); } catch (e) { /* aba aberta à mão: fica aberta */ } };
                if (v) chrome.storage.local.set({ cbUpdateDispensadaVersao: v }, fim); else fim();
            });
        } catch (e) { window.close(); }
    });
})();
