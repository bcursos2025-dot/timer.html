// Página "Liberar o microfone" (permissao-microfone.html).
// O popup da extensão não consegue mostrar a pergunta de permissão do microfone,
// então o ditado por voz do chat de IA (ia-chat.js) falhava com "not-allowed".
// Aqui a pergunta aparece numa aba normal; depois de "Permitir", a permissão fica
// valendo para a extensão inteira, popup incluído.
(function () {
    const card = document.getElementById('pm-card');
    const status = document.getElementById('pm-status');
    const btn = document.getElementById('pm-btn');

    // Segue o tema do sistema (esta página não passa pelo seletor de tema do popup).
    try {
        const escuro = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
        document.documentElement.setAttribute('data-theme', escuro ? 'dark' : 'light');
    } catch (e) { /* mantém o tema padrão */ }

    function mostrar(estado, texto) {
        card.dataset.estado = estado;
        status.textContent = texto;
    }

    function mensagemDeErro(err) {
        const nome = err && err.name;
        if (nome === 'NotAllowedError' || nome === 'SecurityError') {
            return 'O microfone está bloqueado para esta extensão. Clique no ícone de cadeado (ou de microfone) ao lado do endereço desta aba, escolha Permitir e clique em “Tentar de novo”.';
        }
        if (nome === 'NotFoundError' || nome === 'OverconstrainedError') {
            return 'Não encontrei nenhum microfone. Conecte um e confira se ele está liberado nas configurações de privacidade do Windows.';
        }
        if (nome === 'NotReadableError') {
            return 'O microfone está sendo usado por outro programa. Feche-o e tente de novo.';
        }
        return 'Não consegui acessar o microfone' + (nome ? ' (' + nome + ')' : '') + '.';
    }

    function fecharAba() {
        try {
            chrome.tabs.getCurrent((aba) => {
                if (aba && aba.id != null) chrome.tabs.remove(aba.id);
                else window.close();
            });
        } catch (e) { window.close(); }
    }

    async function pedir() {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            mostrar('erro', 'Este navegador não permite acessar o microfone a partir de extensões.');
            btn.hidden = true;
            return;
        }
        btn.disabled = true;
        mostrar('espera', 'Aguardando a sua resposta na barra do navegador…');
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            stream.getTracks().forEach((t) => t.stop());
            mostrar('ok', 'Pronto! O microfone foi liberado. Esta aba vai fechar sozinha — é só voltar ao chat e clicar no microfone.');
            btn.hidden = true;
            setTimeout(fecharAba, 2600);
        } catch (err) {
            mostrar('erro', mensagemDeErro(err));
            btn.disabled = false;
            btn.textContent = 'Tentar de novo';
        }
    }

    btn.addEventListener('click', pedir);
    // Já abre perguntando: quem chegou aqui clicou em "Permitir microfone" no chat.
    pedir();
})();
