// ===================== ASSUNTOS: MAIS E MENOS ACERTOS =====================
//
// Cartão da aba Questões com duas leituras dos assuntos já sincronizados do QConcursos
// (chrome.storage.local.questoesAssuntos.materias = [{ materia, itens: [{nome, certas, erradas, total}] }]):
//   • RADAR ("aranha"): uma ponta por matéria. A forma azul/violeta é o acerto nos assuntos MAIS certos da
//     matéria (os que estão na média dela ou acima) e a rosa, nos MENOS certos (abaixo da média). Cada forma
//     soma as questões dos assuntos do grupo, então não depende de um assunto de 1 questão. Quanto mais
//     distantes as duas formas, mais irregular é a matéria (um buraco escondido atrás de uma média boa);
//   • LISTAS: os 5 assuntos que a pessoa mais acerta e os 5 que menos acerta, no geral.
//
// Duas camadas, no mesmo molde de tendencia.js:
//   • funções puras (sem DOM — rodam em Node, ver interface-popup/testes/destaques-assuntos.test.js);
//   • desenho (render).
//
// Regras que evitam conclusão falsa:
//   1. Só entra assunto com amostra mínima (MIN_QUESTOES). 5 de 5 é sorte, não domínio; sem isso o topo
//      da lista seria sempre "assunto que apareceu 1 vez e a pessoa acertou".
//   2. As duas listas nunca repetem um assunto: com poucos assuntos, cada lado leva no máximo metade.
//   3. A média das listas é ponderada pelas questões (soma de acertos / soma de questões), não média de %.
//   4. O radar usa escala fixa de 0 a 100%: a forma reflete o acerto de verdade, não o maior valor da tela.
//   5. No radar, cada grupo (mais/menos certos) é uma média ponderada pelas questões dos assuntos dele; a forma
//      azul nunca fica abaixo da rosa por construção (média dos acima da média ≥ média dos abaixo dela).
(function (root) {
    'use strict';

    const MIN_QUESTOES = 5;
    const POR_LADO = 5;
    const MAX_EIXOS = 8;  // mais pontas que isso vira um borrão no popup
    const MIN_EIXOS = 3;  // abaixo de 3 pontas não existe polígono

    // ------------------------------------------------------------------ cálculo
    function achatar(materias) {
        const lista = [];
        (Array.isArray(materias) ? materias : []).forEach((g) => {
            if (!g || !Array.isArray(g.itens)) return;
            g.itens.forEach((it) => {
                if (!it || !it.nome) return;
                const total = Number(it.total) || 0;
                if (total <= 0) return;
                const certas = Math.min(Math.max(Number(it.certas) || 0, 0), total);
                lista.push({ nome: String(it.nome), materia: String(g.materia || ''), certas, total, pct: (certas / total) * 100 });
            });
        });
        return lista;
    }

    const soma = (lista, campo) => lista.reduce((s, a) => s + a[campo], 0);
    const mediaPonderada = (lista) => (soma(lista, 'total') ? (soma(lista, 'certas') / soma(lista, 'total')) * 100 : 0);
    const mediaSimples = (v) => (v.length ? v.reduce((s, x) => s + x, 0) / v.length : 0);
    // maior acerto primeiro; empate → mais questões (evidência maior); depois ordem alfabética
    const porAcerto = (a, b) => b.pct - a.pct || b.total - a.total || a.nome.localeCompare(b.nome, 'pt');

    // { ok:true, melhores, piores, mediaMelhores, mediaPiores } | { ok:false, qualificados, min }
    // melhores: maior acerto primeiro; piores: menor acerto primeiro.
    function separar(materias, opcoes) {
        const o = opcoes || {};
        const min = o.min != null ? o.min : MIN_QUESTOES;
        const porLado = o.porLado != null ? o.porLado : POR_LADO;
        const aptos = achatar(materias).filter((a) => a.total >= min);
        if (aptos.length < 2) return { ok: false, qualificados: aptos.length, min };
        const ordem = aptos.slice().sort(porAcerto);
        const k = Math.max(1, Math.min(porLado, Math.floor(aptos.length / 2)));
        const melhores = ordem.slice(0, k);
        const piores = ordem.slice(-k).reverse();
        return { ok: true, melhores, piores, mediaMelhores: mediaPonderada(melhores), mediaPiores: mediaPonderada(piores), qualificados: aptos.length, min };
    }

    // Uma ponta do radar por matéria ("Não classificado" não é matéria, fica de fora). Dentro de cada matéria os
    // assuntos se dividem pela média DELA: "mais certos" = acerto igual ou acima da média, "menos certos" = abaixo.
    // Cada grupo vale pelas questões somadas (média ponderada). Se todos os assuntos têm o mesmo acerto, o grupo dos
    // "menos certos" fica vazio e repete o outro (as duas formas se tocam naquela ponta). A matéria só entra com `min`
    // questões somadas. Com muitas matérias ficam as MAX_EIXOS com mais questões, em ordem alfabética (a posição
    // de cada matéria no radar não muda de um dia para o outro).
    function porMateria(materias, opcoes) {
        const o = opcoes || {};
        const min = o.min != null ? o.min : MIN_QUESTOES;
        const maxEixos = o.maxEixos != null ? o.maxEixos : MAX_EIXOS;
        const grupo = (lista) => ({ pct: mediaPonderada(lista), assuntos: lista.length, total: soma(lista, 'total') });
        const eixos = [];
        (Array.isArray(materias) ? materias : []).forEach((g) => {
            if (!g || !Array.isArray(g.itens) || g.materia === 'Não classificado') return;
            const itens = achatar([g]);
            const total = soma(itens, 'total');
            if (!itens.length || total < min) return;
            const geral = mediaPonderada(itens);
            const acima = itens.filter((a) => a.pct >= geral);
            const abaixo = itens.filter((a) => a.pct < geral);
            const mais = acima.length ? acima : itens;
            const menos = abaixo.length ? abaixo : mais;
            eixos.push({ materia: String(g.materia || ''), geral, total, assuntos: itens.length, mais: grupo(mais), menos: grupo(menos) });
        });
        return eixos
            .sort((a, b) => b.total - a.total)
            .slice(0, maxEixos)
            .sort((a, b) => a.materia.localeCompare(b.materia, 'pt'));
    }

    // Quem estuda há pouco tempo tem quase todo assunto com 1 ou 2 questões: com o mínimo fixo de 5 o cartão ficava
    // vazio ou com 2 assuntos. Então o mínimo desce sozinho, do mais exigente para o menos, até haver o que
    // mostrar, e o cartão AVISA qual mínimo usou (a amostra pequena fica à vista, não escondida).
    //  • listas: 5 → 3 → 2, e só aceita um mínimo que dê pelo menos 4 assuntos (2 por lado);
    //  • radar: matéria com 5 → 3 → 2 questões somadas, e só aceita um mínimo que dê pelo menos MIN_EIXOS matérias.
    const MINIMOS_LISTAS = [5, 3, 2];
    const MINIMOS_RADAR = [5, 3, 2]; // questões somadas da matéria
    function separarAdaptativo(materias) {
        for (const min of MINIMOS_LISTAS) {
            const r = separar(materias, { min });
            if (r.ok && r.qualificados >= 4) return r;
        }
        return separar(materias, { min: MINIMOS_LISTAS[MINIMOS_LISTAS.length - 1] }); // último recurso: o menor mínimo
    }
    function eixosAdaptativos(materias) {
        for (const min of MINIMOS_RADAR) {
            const eixos = porMateria(materias, { min });
            if (eixos.length >= MIN_EIXOS) return { eixos, min };
        }
        return { eixos: [], min: MINIMOS_RADAR[MINIMOS_RADAR.length - 1] };
    }

    // ------------------------------------------------------------------ desenho
    const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const plural = (n, um, varios) => `${n} ${n === 1 ? um : varios}`;
    const ROSA = '#ff4d8d';

    // Radar de duas formas. A dos menos certos é desenhada por cima: por construção nunca passa da dos mais certos.
    function radarHtml(eixos) {
        const LARG = 320, cx = LARG / 2, cy = 118, R = 78, n = eixos.length;
        const ang = (i) => -Math.PI / 2 + (i * 2 * Math.PI) / n;
        const pt = (i, f) => ({ x: cx + Math.cos(ang(i)) * R * f, y: cy + Math.sin(ang(i)) * R * f });
        const str = (arr) => arr.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');
        let grade = '';
        [0.25, 0.5, 0.75, 1].forEach((f, k) => {
            grade += `<polygon points="${str(eixos.map((_, i) => pt(i, f)))}" fill="none" stroke="currentColor" stroke-opacity="${k === 3 ? 0.24 : 0.11}" stroke-width="1"/>`;
        });
        let raios = '', rotulos = '';
        eixos.forEach((e, i) => {
            const ponta = pt(i, 1);
            raios += `<line x1="${cx}" y1="${cy}" x2="${ponta.x.toFixed(1)}" y2="${ponta.y.toFixed(1)}" stroke="currentColor" stroke-opacity="0.11" stroke-width="1"/>`;
            const c = Math.cos(ang(i)), sn = Math.sin(ang(i));
            const x = cx + c * (R + 11), y = cy + sn * (R + 11);
            const anchor = Math.abs(c) < 0.2 ? 'middle' : (c > 0 ? 'start' : 'end');
            const dy = sn > 0.6 ? 9 : (sn < -0.6 ? -3 : 3);
            const nome = e.materia.length > 14 ? e.materia.slice(0, 13).trim() + '…' : e.materia;
            rotulos += `<text x="${x.toFixed(1)}" y="${(y + dy).toFixed(1)}" text-anchor="${anchor}" class="dst-radar-rot"><title>${esc(e.materia)}: assuntos mais certos ${Math.round(e.mais.pct)}% (${plural(e.mais.assuntos, 'assunto', 'assuntos')}), menos certos ${Math.round(e.menos.pct)}% (${plural(e.menos.assuntos, 'assunto', 'assuntos')})</title>${esc(nome)}</text>`;
        });
        // piso de 3% do raio: assunto zerado continua visível como ponto perto do centro
        const serie = (campo) => eixos.map((e, i) => pt(i, Math.max(0.03, e[campo].pct / 100)));
        const melhores = serie('mais'), piores = serie('menos');
        const bolinhas = (pts, cor) => pts.map((p) => `<circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="2.8" fill="${cor}"/>`).join('');
        // recorta o desenho ao que existe (topo da 1ª ponta/rótulo até a base do último rótulo)
        const ys = eixos.flatMap((_, i) => [cy + Math.sin(ang(i)) * R, cy + Math.sin(ang(i)) * (R + 11) + (Math.sin(ang(i)) > 0.6 ? 9 : 0)]);
        const topo = Math.floor(Math.min.apply(null, ys) - 16), base = Math.ceil(Math.max.apply(null, ys) + 10);
        const resumo = `Radar por matéria: acerto nos assuntos mais certos de cada uma, em média ${Math.round(mediaSimples(eixos.map((e) => e.mais.pct)))}%, e nos menos certos, ${Math.round(mediaSimples(eixos.map((e) => e.menos.pct)))}%.`;
        return `
            <svg viewBox="0 ${topo} ${LARG} ${base - topo}" class="dst-radar" role="img" aria-label="${esc(resumo)}">
                <g>${grade}</g><g>${raios}</g>
                <polygon points="${str(melhores)}" fill="var(--accent)" fill-opacity="0.22" stroke="var(--accent)" stroke-width="2" stroke-linejoin="round"/>
                <polygon points="${str(piores)}" fill="${ROSA}" fill-opacity="0.30" stroke="${ROSA}" stroke-width="2" stroke-linejoin="round"/>
                ${bolinhas(melhores, 'var(--accent)')}${bolinhas(piores, ROSA)}
                <g>${rotulos}</g>
            </svg>`;
    }

    function itemHtml(a) {
        const pct = Math.round(a.pct);
        const sub = `${a.materia ? esc(a.materia) + ' · ' : ''}${a.certas} de ${plural(a.total, 'questão', 'questões')}`;
        return `
            <li class="dst-item" title="${esc(a.nome)} — ${esc(a.materia)}: ${a.certas} de ${a.total} questões">
                <div class="dst-linha"><span class="dst-nome">${esc(a.nome)}</span><b class="dst-pct">${pct}%</b></div>
                <div class="dst-tubo" role="img" aria-label="${esc(a.nome)}: ${pct}% de acerto"><i style="width:${pct === 0 ? 0 : Math.max(pct, 6)}%"></i></div>
                <small class="dst-sub">${sub}</small>
            </li>`;
    }

    function ladoHtml(tom, titulo, lista) {
        return `
            <h4 class="dst-tit dst-tit--${tom}">${titulo}</h4>
            <ol class="dst-lista dst-lista--${tom}">${lista.map(itemHtml).join('')}</ol>`;
    }

    function numeroHtml(tom, valor, legenda) {
        return `<div class="dst-num dst-num--${tom}"><b>${Math.round(valor)}<small>%</small></b><span>${legenda}</span></div>`;
    }

    // Desenha dentro de `el`. `materias` é questoesAssuntos.materias (ou undefined se ainda não sincronizou).
    function render(el, materias) {
        const dados = Array.isArray(materias) && materias.length ? materias : null;
        if (!dados) {
            el.innerHTML = '<p class="questoes-empty">Ainda não sincronizamos seus assuntos. Abra a página "Estatísticas &gt; Assuntos" no QConcursos.com com a extensão ativa para ver aqui quais você mais e menos acerta.</p>';
            return null;
        }
        const r = separarAdaptativo(dados);
        if (!r.ok) {
            el.innerHTML = `<p class="questoes-empty">Ainda não há assuntos suficientes para comparar. Entram aqui os assuntos com ${r.min} questões ou mais; resolva mais um pouco e volte.</p>`;
            return r;
        }
        const { eixos, min: minRadar } = eixosAdaptativos(dados);
        const comRadar = eixos.length >= MIN_EIXOS;
        // Com radar, os dois números grandes resumem as duas formas; sem ele, resumem as duas listas.
        let topo;
        if (comRadar) {
            const aviso = minRadar < MIN_QUESTOES
                ? ` Ainda são poucas questões: o radar usa matérias com ${minRadar} ou mais e fica mais firme com o tempo.`
                : '';
            topo = `${radarHtml(eixos)}
                <div class="dst-resumo">
                    ${numeroHtml('bom', mediaSimples(eixos.map((e) => e.mais.pct)), 'acerto nos assuntos mais certos de cada matéria')}
                    ${numeroHtml('ruim', mediaSimples(eixos.map((e) => e.menos.pct)), 'acerto nos assuntos menos certos de cada matéria')}
                </div>
                <p class="dst-nota">Em cada matéria, “mais certos” são os assuntos na média dela ou acima; “menos certos”, os abaixo. Quanto mais distantes as formas, mais irregular é a matéria.${aviso}</p>`;
        } else {
            topo = `<p class="dst-nota dst-nota--topo">O radar aparece quando há assuntos de pelo menos ${MIN_EIXOS} matérias.</p>
                <div class="dst-resumo">
                    ${numeroHtml('bom', r.mediaMelhores, 'média dos mais certos')}
                    ${numeroHtml('ruim', r.mediaPiores, 'média dos menos certos')}
                </div>`;
        }
        const rodape = r.min < MIN_QUESTOES
            ? `Poucos assuntos têm ${MIN_QUESTOES} questões ou mais; as listas contam os de ${r.min} ou mais (${r.qualificados} no momento).`
            : `Entram só os assuntos com ${r.min} questões ou mais (${r.qualificados} no momento).`;
        el.innerHTML = `
            <section class="dst">
                ${topo}
                ${ladoHtml('bom', 'Mais acertos', r.melhores)}
                ${ladoHtml('ruim', 'Menos acertos', r.piores)}
                <p class="dst-rodape">${rodape}</p>
            </section>`;
        r.eixos = comRadar ? eixos : [];
        r.minRadar = minRadar;
        return r;
    }

    const api = { MIN_QUESTOES, POR_LADO, MAX_EIXOS, MIN_EIXOS, achatar, mediaPonderada, separar, porMateria, separarAdaptativo, eixosAdaptativos, render };
    if (typeof module !== 'undefined' && module.exports) module.exports = api;
    else root.CBDestaques = api;
})(typeof window !== 'undefined' ? window : globalThis);
