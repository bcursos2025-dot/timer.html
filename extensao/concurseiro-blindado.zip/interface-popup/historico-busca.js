// ===================== BUSCA NO HISTÓRICO DE CONVERSAS DO CHAT DE IA (lógica pura) =====================
//
// Sem DOM: roda em Node (ver interface-popup/testes/historico-busca.test.js) e é usada por
// interface-popup/ia-chat-historico.js, que cuida só da telinha.
//
// Regras:
//   • procura em TODAS as mensagens de pergunta e resposta (a mensagem "system" é contexto interno do app);
//   • não liga para maiúsculas nem acentos ("licitacao" acha "Licitação");
//   • com várias palavras, a conversa precisa ter todas, em qualquer mensagem;
//   • devolve também onde achou a primeira palavra, para mostrar um trecho com ela destacada.
(function (root) {
    'use strict';

    const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

    // minúsculas e sem acento. O tamanho do texto não muda (cada letra acentuada vira a letra simples),
    // por isso o índice achado no texto normalizado vale no original.
    const normalizar = (s) => String(s == null ? '' : s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');

    const palavrasDaBusca = (termo) => normalizar(termo).split(/\s+/).filter(Boolean);

    const mensagensVisiveis = (conversa) => ((conversa && conversa.mensagens) || [])
        .filter((m) => m && (m.role === 'user' || m.role === 'assistant') && m.content);

    // null = a conversa não tem todas as palavras; { trecho } = tem (trecho null quando a busca está vazia)
    function acharNaConversa(conversa, palavras) {
        if (!palavras || !palavras.length) return { trecho: null };
        const msgs = mensagensVisiveis(conversa);
        const tudo = normalizar(msgs.map((m) => String(m.content)).join('\n'));
        if (!palavras.every((p) => tudo.includes(p))) return null;
        for (const m of msgs) {
            const texto = String(m.content);
            const i = normalizar(texto).indexOf(palavras[0]);
            if (i >= 0) {
                // o destaque cobre a palavra INTEIRA ("administrativ" marca "Administrativo"), não só o que foi digitado
                let fimPalavra = i + palavras[0].length;
                while (fimPalavra < texto.length && /[\p{L}\p{N}_-]/u.test(texto[fimPalavra])) fimPalavra++;
                return { trecho: { texto, i, len: fimPalavra - i, role: m.role } };
            }
        }
        return { trecho: null };
    }

    // ~90 caracteres em volta do achado, com a palavra em <mark>; todo o resto é escapado.
    function trechoHtml(t) {
        const antes = 36, depois = 54;
        const ini = Math.max(0, t.i - antes);
        const fim = Math.min(t.texto.length, t.i + t.len + depois);
        const limpo = (s) => esc(s.replace(/\s+/g, ' '));
        return (ini > 0 ? '…' : '')
            + limpo(t.texto.slice(ini, t.i))
            + '<mark>' + limpo(t.texto.slice(t.i, t.i + t.len)) + '</mark>'
            + limpo(t.texto.slice(t.i + t.len, fim))
            + (fim < t.texto.length ? '…' : '');
    }

    // Filtra a lista: [{ conversa, trecho }] na mesma ordem em que veio.
    function filtrar(conversas, termo) {
        const palavras = palavrasDaBusca(termo);
        const out = [];
        (conversas || []).forEach((conversa) => {
            const r = acharNaConversa(conversa, palavras);
            if (r) out.push({ conversa, trecho: r.trecho });
        });
        return out;
    }

    const api = { esc, normalizar, palavrasDaBusca, mensagensVisiveis, acharNaConversa, trechoHtml, filtrar };
    if (typeof module !== 'undefined' && module.exports) module.exports = api;
    else root.CBHistoricoBusca = api;
})(typeof window !== 'undefined' ? window : globalThis);
