// ===================== ASSISTENTE DE IA (chat no popup) =====================
//
// A chamada de verdade (com fallback automático Pollinations → LLM7 →
// Gemini) mora em dados-config/ia-provider.js (cbGerarRespostaIA). O
// resumo de agenda/desempenho/tempo de estudo vem de
// dados-config/ia-contexto.js (cbColetarContextoEstudo), só leitura. Gravar
// blocos na agenda a partir do chat passa por
// dados-config/ia-agenda-writer.js (cbAdicionarBlocosAgenda), e só acontece
// depois que a pessoa confirma explicitamente o cartão de proposta.
//
// A conversa fica só em memória enquanto o popup está aberto — fechou o
// popup, o histórico some; não é gravado em disco nem enviado a ninguém além
// do endpoint de IA.

(function () {
    const overlay = document.getElementById('ia-chat-modal-overlay');
    const btnAbrir = document.getElementById('btn-ia-chat');
    const btnFechar = document.getElementById('ia-chat-modal-close');
    const elMensagens = document.getElementById('ia-chat-mensagens');
    const elInput = document.getElementById('ia-chat-input');
    const btnEnviar = document.getElementById('ia-chat-enviar');
    const btnPensar = document.getElementById('ia-chat-pensar-toggle');
    const btnProfunda = document.getElementById('ia-chat-profunda-toggle');
    const btnMais = document.getElementById('ia-chat-mais-btn');
    const painelMais = document.getElementById('ia-chat-mais-painel');
    const btnWeb = document.getElementById('ia-chat-web-toggle');
    const btnTemp = document.getElementById('ia-chat-temp-toggle');
    const seloTemp = document.getElementById('ia-chat-temp-selo');
    const btnDestaques = document.getElementById('ia-chat-destaques-toggle');
    const btnMic = document.getElementById('ia-chat-mic');
    const btnModelo = document.getElementById('ia-chat-modelo-btn');
    const painelModelo = document.getElementById('ia-chat-modelo-painel');
    const elModeloLabel = document.getElementById('ia-chat-modelo-label');
    if (!overlay || !btnAbrir) return;

    const SYSTEM_PROMPT = `Você é o "Assistente E.CONCURSOS", o assistente de estudos embutido na extensão Concurseiro Blindado - Analítico, para concursos públicos brasileiros.
Responda em português, de forma direta e prática — poucos parágrafos, a menos que a pessoa peça mais detalhe.
Você é um assistente focado em concursos públicos brasileiros. Responda de forma direta. Se a pergunta for sobre Direito, use os conceitos estritos da doutrina majoritária. NUNCA misture teses de jurisprudência diferentes. Se não souber a tese exata, diga "Não tenho essa informação no momento".
Quando explicar regras de exceção ou jurisprudência do STF/STJ, use sempre tópicos (bullet points) curtos e diretos. Evite parágrafos longos com muitas condicionais (se/então).
Ao citar prazo, quantidade, percentual ou valor previsto em lei/Constituição (ex.: "30 dias", "1/3 dos membros", "10%"), REPRODUZA o número literalmente como aparece na fonte de busca fornecida — nunca parafraseie, arredonde, dobre ou "lembre de cabeça" um número parecido. Se esse número não estiver literalmente na fonte de busca, diga que não tem certeza do valor exato em vez de arriscar um chute.
Se perguntarem qual modelo, motor ou tecnologia de IA você usa/roda, quem te desenvolveu, ou qualquer coisa sobre o que roda por trás de você, responda SEMPRE em primeira pessoa, com exatamente esta ideia: "Sou o Assistente E.CONCURSOS, feito para a extensão Concurseiro Blindado - Analítico." Nunca responda em segunda pessoa (nunca diga "Você é o Assistente..." — quem está te perguntando é a pessoa estudando, não você). Nunca mencione OpenAI, GPT, Google, Gemini, Pollinations, LLM7 ou qualquer nome de provedor de IA de terceiros — esses detalhes técnicos não interessam a quem está estudando.
Você recebe, em outra mensagem de sistema, um resumo real da agenda, do desempenho em questões e do tempo de estudo da pessoa. Use esses dados pra responder perguntas como "como estou indo essa semana" ou "o que devo estudar hoje" — nunca invente números que não estejam nesse resumo.
Quando fizer sentido organizar a resposta (comparações, requisitos, prazos, diferenças entre institutos), você pode usar uma tabela em markdown (uma linha de cabeçalho "| Coluna A | Coluna B |", uma linha de traços "| --- | --- |" logo abaixo, e as linhas de dados no mesmo formato) e **negrito** para destacar termos — a interface do chat sabe renderizar os dois.

Quando a pessoa pedir pra AGENDAR, MARCAR ou CRIAR um bloco de estudo (ex: "marca revisão de português amanhã às 14h"), além da resposta normal em texto, termine sua mensagem com um bloco cercado assim, contendo APENAS blocos que a pessoa pediu de verdade:

\`\`\`agendar
[{"data":"AAAA-MM-DD","inicio":"HH:MM","fim":"HH:MM","materia":"nome curto","prioridade":"alta|media|baixa"}]
\`\`\`

Regras desse bloco: use a data de hoje informada no resumo pra calcular "amanhã"/"segunda"/etc. Nunca inclua esse bloco se a pessoa não pediu explicitamente pra agendar algo — é só para pedidos de agendamento.

Às vezes, antes da pergunta, você recebe trechos reais de lei (importados pela pessoa) numa mensagem de sistema chamada "TRECHOS DE LEGISLAÇÃO ENCONTRADOS". Quando isso vier e for relevante pra pergunta, baseie sua resposta NELES e cite o artigo exato. Se vier vazio ou não tiver relação com a pergunta, responda normalmente com seu conhecimento — não force a citação.`;

    let historico = [{ role: 'system', content: SYSTEM_PROMPT }];
    let contextoCarregado = false;
    let enviando = false;
    let requestSeq = 0;
    let pensarAtivo = false;
    let webAtivo = false;
    let profundaAtiva = false;
    let conversaAtualId = null;
    let temporario = false;
    const CB_WEB_STORAGE_KEY = 'cbChatWebAtivo';

    // ===================== seletor de modelo ("Trocar de modelo") =====================
    // As 3 opções são, na prática, perfis de velocidade/comportamento em cima
    // do MESMO provedor com fallback automático (dados-config/ia-provider.js
    // — Pollinations → LLM7 → Gemini): "PRO" é o padrão de sempre (deixa a
    // classificação decidir se pesquisa antes de responder); "Res" pula essa
    // pesquisa automática pra responder mais rápido, a não ser que "Pensar"
    // esteja ligado (aí a pessoa está pedindo pesquisa explicitamente); "Mini"
    // faz o mesmo e ainda pede respostas mais curtas, que geram mais rápido.
    const CB_MODELO_STORAGE_KEY = 'cbChatModeloAtivo';
    const CB_MODELOS = {
        pro: { label: '2.5 PRO' },
        rapido: { label: '2.5 Res' },
        mini: { label: '2.0 Mini' },
    };
    let modeloAtivo = 'pro';

    function cbAplicarModeloNaUI() {
        if (elModeloLabel) elModeloLabel.textContent = (CB_MODELOS[modeloAtivo] || CB_MODELOS.pro).label;
        if (painelModelo) {
            painelModelo.querySelectorAll('.ia-chat-modelo-opt').forEach((opt) => {
                opt.classList.toggle('ia-chat-modelo-opt-ativo', opt.dataset.modelo === modeloAtivo);
            });
        }
    }
    function cbFecharPainelModelo() {
        if (!painelModelo) return;
        painelModelo.hidden = true;
        if (btnModelo) btnModelo.setAttribute('aria-expanded', 'false');
    }
    function cbAlternarPainelModelo() {
        if (!painelModelo) return;
        const vaiAbrir = painelModelo.hidden;
        painelModelo.hidden = !vaiAbrir;
        if (btnModelo) btnModelo.setAttribute('aria-expanded', String(vaiAbrir));
    }
    if (typeof chrome !== 'undefined' && chrome.storage) {
        chrome.storage.local.get([CB_MODELO_STORAGE_KEY], (res) => {
            if (res[CB_MODELO_STORAGE_KEY] && CB_MODELOS[res[CB_MODELO_STORAGE_KEY]]) {
                modeloAtivo = res[CB_MODELO_STORAGE_KEY];
                cbAplicarModeloNaUI();
            }
        });
    }

    // ===================== histórico de conversas (chrome.storage.local) =====================
    // Cada troca de pergunta/resposta bem-sucedida atualiza a conversa atual
    // no storage (identificada por conversaAtualId, criado na primeira
    // mensagem enviada/recebida desta sessão do popup). Reabrir o popup
    // começa uma conversa NOVA — é só o histórico de conversas PASSADAS que
    // fica persistido; ver interface-popup/ia-chat-historico.js pra tela que
    // lista/reabre isso.
    const CB_HISTORICO_STORAGE_KEY = 'cbChatConversasHistorico';
    const CB_HISTORICO_MAX = 30;

    function cbObterMensagensParaSalvar() {
        return historico
            .filter((m) => m.role === 'user' || m.role === 'assistant')
            .map((m) => ({ role: m.role, content: m.content }));
    }

    function cbSalvarConversaAtual() {
        if (temporario) return; // chat temporário: nada vai para o histórico
        const mensagens = cbObterMensagensParaSalvar();
        if (!mensagens.length || typeof chrome === 'undefined' || !chrome.storage) return;
        if (!conversaAtualId) conversaAtualId = `c${Date.now()}${Math.random().toString(36).slice(2, 7)}`;
        chrome.storage.local.get([CB_HISTORICO_STORAGE_KEY], (res) => {
            let lista = res[CB_HISTORICO_STORAGE_KEY] || [];
            const agora = Date.now();
            const existente = lista.find((c) => c.id === conversaAtualId);
            if (existente) {
                existente.mensagens = mensagens;
                existente.atualizadoEm = agora;
            } else {
                lista.push({ id: conversaAtualId, criadoEm: agora, atualizadoEm: agora, mensagens });
            }
            lista.sort((a, b) => b.atualizadoEm - a.atualizadoEm);
            if (lista.length > CB_HISTORICO_MAX) lista = lista.slice(0, CB_HISTORICO_MAX);
            chrome.storage.local.set({ [CB_HISTORICO_STORAGE_KEY]: lista });
        });
    }

    window.cbChatListarHistorico = function () {
        return new Promise((resolve) => {
            if (typeof chrome === 'undefined' || !chrome.storage) { resolve([]); return; }
            chrome.storage.local.get([CB_HISTORICO_STORAGE_KEY], (res) => resolve(res[CB_HISTORICO_STORAGE_KEY] || []));
        });
    };

    window.cbChatApagarConversa = function (id) {
        return new Promise((resolve) => {
            chrome.storage.local.get([CB_HISTORICO_STORAGE_KEY], (res) => {
                const lista = (res[CB_HISTORICO_STORAGE_KEY] || []).filter((c) => c.id !== id);
                chrome.storage.local.set({ [CB_HISTORICO_STORAGE_KEY]: lista }, resolve);
            });
        });
    };

    window.cbChatLimparHistorico = function () {
        return new Promise((resolve) => chrome.storage.local.remove(CB_HISTORICO_STORAGE_KEY, resolve));
    };

    // Substitui a conversa em tela pela conversa salva `id` — recusa se uma
    // resposta ainda estiver em andamento, pra não misturar o histórico
    // antigo com uma rodada que já estava em voo.
    window.cbChatCarregarConversa = async function (id) {
        if (enviando) {
            alert('Espere a resposta atual terminar antes de abrir outra conversa.');
            return;
        }
        const lista = await window.cbChatListarHistorico();
        const conversa = lista.find((c) => c.id === id);
        if (!conversa) return;
        if (temporario) cbDefinirTemporario(false); // abrir uma conversa salva encerra o chat temporário

        elMensagens.innerHTML = '';
        historico = [{ role: 'system', content: SYSTEM_PROMPT }];
        conversaAtualId = conversa.id;

        (conversa.mensagens || []).forEach((m, idx) => {
            if (m.role === 'user') {
                criarBolhaUsuario(m.content);
                historico.push({ role: 'user', content: m.content });
            } else if (m.role === 'assistant') {
                const anterior = conversa.mensagens[idx - 1];
                const pergunta = anterior && anterior.role === 'user' ? anterior.content : '';
                const bolha = document.createElement('div');
                bolha.className = 'ia-chat-msg ia-chat-msg-ia';
                elMensagens.appendChild(bolha);
                const { textoLimpo } = cbExtrairPropostaAgenda(m.content || '');
                bolha.innerHTML = cbRenderizarMarkdownSimples(textoLimpo);
                const indiceHistorico = historico.length;
                historico.push({ role: 'assistant', content: m.content });
                cbAdicionarAcoesResposta(bolha, textoLimpo, pergunta, indiceHistorico);
            }
        });
        elMensagens.scrollTop = elMensagens.scrollHeight;
    };

    async function abrirModal() {
        overlay.classList.add('open');
        elInput.focus();
        if (!contextoCarregado && typeof window.cbColetarContextoEstudo === 'function') {
            try {
                const contexto = await window.cbColetarContextoEstudo();
                historico.splice(1, 0, { role: 'system', content: contexto });
            } catch (e) { /* segue sem contexto se der ruim */ }
            contextoCarregado = true;
        }
    }
    // ---- chat temporário ----
    // Conversa que não é salva no histórico (cbSalvarConversaAtual sai cedo) e some ao fechar o chat.
    // Ligar ou desligar começa uma conversa em branco; o que já estava salvo continua no histórico.
    function cbNovaConversaEmBranco(textoInicial) {
        elMensagens.innerHTML = '';
        const oi = document.createElement('div');
        oi.className = 'ia-chat-msg ia-chat-msg-ia';
        oi.textContent = textoInicial;
        elMensagens.appendChild(oi);
        // mantém só as mensagens de sistema do começo (instruções e resumo de estudo)
        let n = 0;
        while (n < historico.length && historico[n].role === 'system') n++;
        historico = historico.slice(0, n);
        conversaAtualId = null;
        requestSeq += 1;
    }
    function cbDefinirTemporario(ligado) {
        temporario = ligado;
        overlay.querySelector('.ap-chatia').classList.toggle('ia-temporario', ligado);
        if (seloTemp) seloTemp.hidden = !ligado;
        if (btnTemp) {
            btnTemp.setAttribute('aria-pressed', String(ligado));
            btnTemp.title = ligado ? 'Sair do chat temporário' : 'Chat temporário: não salva no histórico';
        }
        cbNovaConversaEmBranco(ligado
            ? 'Chat temporário: esta conversa não é salva no histórico e some quando você fechar o chat.'
            : 'Oi! Pode perguntar sobre técnicas de estudo, dúvidas de matérias ou pedir ajuda para organizar seu cronograma.');
    }
    if (btnTemp) {
        btnTemp.addEventListener('click', () => {
            if (enviando) { cbMostrarAviso('Espere a resposta terminar para trocar de chat.', { duracao: 3000 }); return; }
            cbDefinirTemporario(!temporario);
        });
    }

    function fecharModal() {
        if (temporario && !enviando) cbDefinirTemporario(false);
        overlay.classList.remove('open');
        cbPararGravacaoVoz();
    }

    // ===================== render de markdown leve + grifos =====================
    // A IA devolve texto puro (+ eventualmente tabela em markdown). Aqui a
    // gente escapa HTML primeiro (segurança — texto vem de uma API externa),
    // depois converte **negrito** e tabela "| col | col |", e por cima disso
    // passa o grifador de palavras-chave. Cada etapa trabalha em cima de HTML
    // já escapado, nunca em cima do texto bruto, pra não reabrir brecha de
    // injeção via a própria resposta da IA.
    function cbEscapeHtml(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }

    // Cada grupo é uma "cor de grifo" com sua lista de gatilhos. A ordem de
    // busca não importa pro resultado final — em caso de sobreposição, quem
    // ganha é o casamento que começa mais cedo (e, empatando, o mais longo);
    // ver cbGrifarPalavrasChave.
    const CB_GRIFO_GRUPOS = [
        { cor: 'vermelho', re: /\b(falsa?|incorret[oa]s?|errad[oa]s?|nunca|jamais|imposs[íi]vel|proibid[oa]s?|veda(?:do|da|dos|das|[çc][ãa]o)?)\b/gi },
        { cor: 'verde', re: /\b(verdadeir[oa]s?|corretas?|correto|c[êe]rto|v[áa]lid[oa]s?|confirmad[oa]s?|autorizad[oa]s?)\b/gi },
        { cor: 'amarelo', re: /\b(por[ée]m|contudo|todavia|no entanto|entretanto|mas|talvez|possivelmente|cuidado|aten[çc][ãa]o|ressalva)\b/gi },
        { cor: 'violeta', re: /\b(salvo|exceto|ressalvad[oa]s?|excepcionalmente|em regra)\b/gi },
        { cor: 'azul', re: /(\d+(?:[.,]\d+)?\s?%|\bn[úu]mero\b|\d+(?:[.,]\d+)?)/gi },
    ];

    function cbGrifarPalavrasChave(textoEscapado) {
        const achados = [];
        CB_GRIFO_GRUPOS.forEach((grupo) => {
            grupo.re.lastIndex = 0;
            let m;
            while ((m = grupo.re.exec(textoEscapado))) {
                achados.push({ inicio: m.index, fim: m.index + m[0].length, cor: grupo.cor, texto: m[0] });
                if (m[0].length === 0) grupo.re.lastIndex += 1;
            }
        });
        if (!achados.length) return textoEscapado;
        achados.sort((a, b) => a.inicio - b.inicio || (b.fim - b.inicio) - (a.fim - a.inicio));
        const escolhidos = [];
        let fimAnterior = -1;
        achados.forEach((a) => {
            if (a.inicio >= fimAnterior) { escolhidos.push(a); fimAnterior = a.fim; }
        });
        let resultado = '';
        let cursor = 0;
        escolhidos.forEach((a) => {
            resultado += textoEscapado.slice(cursor, a.inicio);
            resultado += `<mark class="ia-grifo ia-grifo-${a.cor}">${a.texto}</mark>`;
            cursor = a.fim;
        });
        resultado += textoEscapado.slice(cursor);
        return resultado;
    }

    function cbLinhaParaHtml(linha) {
        let html = cbEscapeHtml(linha);
        html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
        html = cbGrifarPalavrasChave(html);
        return html;
    }

    function cbDividirLinhaTabela(linha) {
        return linha.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map((p) => p.trim());
    }

    function cbRenderizarMarkdownSimples(texto) {
        const linhas = String(texto || '').split(/\r?\n/);
        let html = '';
        let i = 0;
        while (i < linhas.length) {
            const linha = linhas[i];
            const proxima = linhas[i + 1] || '';
            const pareceTabela = /^\s*\|.*\|\s*$/.test(linha) && /^\s*\|?[\s:|-]+\|?\s*$/.test(proxima) && proxima.includes('-');
            if (pareceTabela) {
                const cabecalho = cbDividirLinhaTabela(linha);
                i += 2;
                const corpo = [];
                while (i < linhas.length && /^\s*\|.*\|\s*$/.test(linhas[i])) {
                    corpo.push(cbDividirLinhaTabela(linhas[i]));
                    i += 1;
                }
                html += '<div class="ia-chat-tabela-wrap"><table class="ia-chat-tabela"><thead><tr>'
                    + cabecalho.map((c) => `<th>${cbLinhaParaHtml(c)}</th>`).join('')
                    + '</tr></thead><tbody>'
                    + corpo.map((cols) => `<tr>${cols.map((c) => `<td>${cbLinhaParaHtml(c)}</td>`).join('')}</tr>`).join('')
                    + '</tbody></table></div>';
                continue;
            }
            html += (html ? '<br>' : '') + cbLinhaParaHtml(linha);
            i += 1;
        }
        return html;
    }

    // ===================== bolhas de mensagem =====================
    function criarBolhaUsuario(texto) {
        const div = document.createElement('div');
        div.className = 'ia-chat-msg ia-chat-msg-user';
        const span = document.createElement('span');
        span.className = 'ia-chat-msg-texto';
        span.textContent = texto;
        div.appendChild(span);
        elMensagens.appendChild(div);
        elMensagens.scrollTop = elMensagens.scrollHeight;
        return div;
    }

    const MASCOTE_PENSANDO_HTML = `
        <span class="ia-pensando-orb" aria-hidden="true">
            <span class="ia-pensando-olhos">
                <span class="ia-pensando-olho"></span>
                <span class="ia-pensando-olho"></span>
            </span>
        </span>
        <span class="ia-pensando-texto">Pensando...</span>
    `;
    function criarBolhaPensando() {
        const div = document.createElement('div');
        div.className = 'ia-chat-msg ia-chat-msg-ia ia-chat-msg-pensando';
        div.innerHTML = MASCOTE_PENSANDO_HTML;
        elMensagens.appendChild(div);
        elMensagens.scrollTop = elMensagens.scrollHeight;
        return div;
    }
    function atualizarFasePensando(bolha, texto) {
        const el = bolha.querySelector('.ia-pensando-texto');
        if (el) el.textContent = texto;
    }

    function truncarConversaApartirDe(bolha) {
        let prox = bolha.nextElementSibling;
        while (prox) {
            const seguinte = prox.nextElementSibling;
            prox.remove();
            prox = seguinte;
        }
    }

    // Mostra, discretamente, de onde a resposta anterior tirou a informação —
    // um julgado do acervo local, a lei no Planalto, a doutrina importada ou a
    // Wikipédia. Cada chip é um link de verdade quando a fonte tem URL; sem
    // URL (doutrina local, informativo sem link direto) vira só um selo de
    // texto.
    function cbRenderizarFontes(fontes) {
        if (!fontes || !fontes.length) return;

        const label = document.createElement('div');
        label.className = 'ia-chat-fontes-label';
        label.textContent = 'Fontes';
        elMensagens.appendChild(label);

        const row = document.createElement('div');
        row.className = 'ia-chat-fontes';
        fontes.forEach((f) => {
            if (!f || !f.titulo) return;
            const chip = document.createElement(f.url ? 'a' : 'span');
            chip.className = 'ia-chat-fonte-chip' + (f.interna ? ' ia-chat-fonte-interna' : '');
            chip.textContent = f.titulo;
            if (f.url) {
                chip.href = f.url;
                chip.target = '_blank';
                chip.rel = 'noopener';
                chip.title = f.url;
            }
            row.appendChild(chip);
        });
        elMensagens.appendChild(row);
        elMensagens.scrollTop = elMensagens.scrollHeight;
    }

    function cbRenderizarCartaoProposta(propostas) {
        const card = document.createElement('div');
        card.className = 'ia-chat-proposta';

        const lista = document.createElement('div');
        lista.className = 'ia-chat-proposta-lista';
        propostas.forEach((p) => {
            const linha = document.createElement('div');
            linha.className = 'ia-chat-proposta-item';
            linha.textContent = `${p.data} · ${p.inicio}–${p.fim} · ${p.materia || 'Estudo'}`;
            lista.appendChild(linha);
        });

        const acoes = document.createElement('div');
        acoes.className = 'ia-chat-proposta-acoes';
        const btnOk = document.createElement('button');
        btnOk.type = 'button';
        btnOk.className = 'ia-chat-proposta-confirmar';
        btnOk.textContent = `Adicionar ${propostas.length > 1 ? `${propostas.length} blocos` : 'à agenda'}`;
        const btnNao = document.createElement('button');
        btnNao.type = 'button';
        btnNao.className = 'ia-chat-proposta-ignorar';
        btnNao.textContent = 'Ignorar';

        btnOk.addEventListener('click', async () => {
            btnOk.disabled = true;
            btnNao.disabled = true;
            try {
                await window.cbAdicionarBlocosAgenda(propostas);
                card.remove();
                const bolha = document.createElement('div');
                bolha.className = 'ia-chat-msg ia-chat-msg-ia';
                bolha.innerHTML = cbRenderizarMarkdownSimples('Pronto — adicionei isso na sua agenda.');
                elMensagens.appendChild(bolha);
                elMensagens.scrollTop = elMensagens.scrollHeight;
            } catch (e) {
                btnOk.disabled = false;
                btnNao.disabled = false;
            }
        });
        btnNao.addEventListener('click', () => card.remove());

        acoes.appendChild(btnOk);
        acoes.appendChild(btnNao);
        card.appendChild(lista);
        card.appendChild(acoes);
        elMensagens.appendChild(card);
        elMensagens.scrollTop = elMensagens.scrollHeight;
    }

    // ===================== ações abaixo da resposta (regenerar/copiar/ouvir) =====================
    const SVG_FALAR = '<path d="M11 5 6 9H2v6h4l5 4V5Z"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"/>';
    const SVG_PARAR = '<rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor" stroke="none"/>';

    let ttsBotaoAtivo = null;
    let ttsFila = [];
    let ttsIndice = 0;

    function cbPararLeituraVoz() {
        if ('speechSynthesis' in window) window.speechSynthesis.cancel();
        if (ttsBotaoAtivo) {
            ttsBotaoAtivo.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${SVG_FALAR}</svg>`;
            ttsBotaoAtivo.classList.remove('ia-chat-acao-ativa');
        }
        ttsBotaoAtivo = null;
    }
    function cbFalarProximoChunk() {
        if (ttsIndice >= ttsFila.length) { cbPararLeituraVoz(); return; }
        const utter = new SpeechSynthesisUtterance(ttsFila[ttsIndice]);
        utter.lang = 'pt-BR';
        utter.onend = () => { ttsIndice += 1; cbFalarProximoChunk(); };
        utter.onerror = () => cbPararLeituraVoz();
        window.speechSynthesis.speak(utter);
    }
    function cbAlternarLeituraVoz(botao, textoBruto) {
        if (!('speechSynthesis' in window)) {
            alert('Seu navegador não suporta leitura em voz alta.');
            return;
        }
        if (ttsBotaoAtivo === botao) { cbPararLeituraVoz(); return; }
        cbPararLeituraVoz();
        const textoLimpo = String(textoBruto || '').replace(/[*_`#|]/g, ' ');
        ttsFila = (textoLimpo.match(/[^.!?\n]+[.!?\n]?/g) || [textoLimpo]).map((s) => s.trim()).filter(Boolean);
        ttsIndice = 0;
        ttsBotaoAtivo = botao;
        botao.innerHTML = `<svg viewBox="0 0 24 24">${SVG_PARAR}</svg>`;
        botao.classList.add('ia-chat-acao-ativa');
        cbFalarProximoChunk();
    }

    function cbAdicionarAcoesResposta(bolha, textoResposta, pergunta, indiceHistorico) {
        const row = document.createElement('div');
        row.className = 'ia-chat-acoes-resposta';

        const btnRegenerar = document.createElement('button');
        btnRegenerar.type = 'button';
        btnRegenerar.className = 'ia-chat-acao-btn';
        btnRegenerar.title = 'Gerar novamente';
        btnRegenerar.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 3v6h-6"/></svg>';

        const btnCopiar = document.createElement('button');
        btnCopiar.type = 'button';
        btnCopiar.className = 'ia-chat-acao-btn';
        btnCopiar.title = 'Copiar resposta';
        btnCopiar.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>';

        const btnFalar = document.createElement('button');
        btnFalar.type = 'button';
        btnFalar.className = 'ia-chat-acao-btn';
        btnFalar.title = 'Ler em voz alta';
        btnFalar.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${SVG_FALAR}</svg>`;

        btnRegenerar.addEventListener('click', () => {
            if (enviando) return;
            row.remove();
            truncarConversaApartirDe(bolha);
            historico.length = indiceHistorico;
            executarRodada({ texto: pergunta, bolhaExistente: bolha, permitirEdicao: false });
        });
        btnCopiar.addEventListener('click', async () => {
            try {
                await navigator.clipboard.writeText(textoResposta);
                btnCopiar.classList.add('ia-chat-acao-ok');
                setTimeout(() => btnCopiar.classList.remove('ia-chat-acao-ok'), 1200);
            } catch (e) { /* clipboard pode falhar sem foco na página — sem problema, ignora */ }
        });
        btnFalar.addEventListener('click', () => cbAlternarLeituraVoz(btnFalar, textoResposta));

        row.appendChild(btnRegenerar);
        row.appendChild(btnCopiar);
        row.appendChild(btnFalar);
        bolha.insertAdjacentElement('afterend', row);
    }

    function finalizarBolhaResposta(bolha, textoResposta, pergunta, indiceHistorico) {
        bolha.classList.remove('ia-chat-msg-pensando');
        bolha.innerHTML = cbRenderizarMarkdownSimples(textoResposta);
        cbAdicionarAcoesResposta(bolha, textoResposta, pergunta, indiceHistorico);
    }

    // ===================== editar pergunta enquanto a IA pensa =====================
    function cbHabilitarEdicaoBolha(bolhaUsuario, onReenviar) {
        const btnEditar = document.createElement('button');
        btnEditar.type = 'button';
        btnEditar.className = 'ia-chat-msg-editar-btn';
        btnEditar.title = 'Editar pergunta';
        btnEditar.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/></svg>';
        bolhaUsuario.appendChild(btnEditar);

        let emEdicao = false;
        function iniciarEdicao() {
            if (emEdicao) return;
            emEdicao = true;
            const span = bolhaUsuario.querySelector('.ia-chat-msg-texto');
            const textoAtual = span.textContent;
            span.style.display = 'none';
            btnEditar.style.display = 'none';

            const wrap = document.createElement('div');
            wrap.className = 'ia-chat-edit-wrap';
            const textarea = document.createElement('textarea');
            textarea.className = 'ia-chat-edit-textarea';
            textarea.value = textoAtual;
            const acoes = document.createElement('div');
            acoes.className = 'ia-chat-edit-acoes';
            const btnCancelar = document.createElement('button');
            btnCancelar.type = 'button';
            btnCancelar.className = 'ia-chat-edit-cancelar';
            btnCancelar.textContent = 'Cancelar';
            const btnOk = document.createElement('button');
            btnOk.type = 'button';
            btnOk.className = 'ia-chat-edit-ok';
            btnOk.textContent = 'Reenviar';
            acoes.appendChild(btnCancelar);
            acoes.appendChild(btnOk);
            wrap.appendChild(textarea);
            wrap.appendChild(acoes);
            bolhaUsuario.appendChild(wrap);
            textarea.focus();
            textarea.setSelectionRange(textarea.value.length, textarea.value.length);

            function fecharEdicao() {
                wrap.remove();
                span.style.display = '';
                btnEditar.style.display = '';
                emEdicao = false;
            }
            btnCancelar.addEventListener('click', fecharEdicao);
            btnOk.addEventListener('click', () => {
                const novo = textarea.value.trim();
                fecharEdicao();
                if (!novo || novo === textoAtual) return;
                span.textContent = novo;
                onReenviar(novo);
            });
        }
        btnEditar.addEventListener('click', iniciarEdicao);

        return function pararEdicao() {
            btnEditar.remove();
            const wrap = bolhaUsuario.querySelector('.ia-chat-edit-wrap');
            if (wrap) {
                wrap.remove();
                const span = bolhaUsuario.querySelector('.ia-chat-msg-texto');
                if (span) span.style.display = '';
            }
        };
    }

    // ===================== extrai proposta de agenda do texto da IA =====================
    function cbExtrairPropostaAgenda(texto) {
        const re = /```agendar\s*([\s\S]*?)```/i;
        const m = texto.match(re);
        if (!m) return { textoLimpo: texto, propostas: [] };
        const textoLimpo = texto.replace(re, '').trim();
        try {
            const lista = JSON.parse(m[1].trim());
            const propostas = (Array.isArray(lista) ? lista : []).filter((p) => p && p.data && p.inicio && p.fim);
            return { textoLimpo, propostas };
        } catch (e) {
            return { textoLimpo, propostas: [] };
        }
    }

    // ===================== chamada de rede (busca/verificação/IA) =====================
    // pensarAtivo (toggle "Pensar" na barra) força a pergunta a passar pelo
    // pipeline de busca+verificação mesmo quando ela pareceria "interna"
    // (dados da própria extensão) — isso inclui consultar o acervo de
    // jurisprudência, o Planalto e a doutrina salva localmente (ver
    // dados-config/ia-pesquisa-externa.js e ia-doutrina-permanente.js), com
    // o progresso de cada fase aparecendo no lugar do "Pensando...".
    // O histórico termina na pergunta de agora; a anterior é a última mensagem "user" antes dela.
    function perguntaAnteriorDoUsuario() {
        for (let i = historico.length - 2; i >= 0; i--) {
            if (historico[i].role === 'user') return historico[i].content;
        }
        return '';
    }

    async function processarPergunta(texto, onFase) {
        const mensagensParaEnviar = historico.slice();
        let temTrechoDeLei = false;
        let trechosDeLeiEncontrados = [];
        if (typeof window.cbBuscarTrechosRelevantes === 'function') {
            const trechos = await window.cbBuscarTrechosRelevantes(texto, 3).catch(() => []);
            if (trechos.length) {
                temTrechoDeLei = true;
                trechosDeLeiEncontrados = trechos;
                const textoTrechos = trechos
                    .map((t) => `[${t.lei}${t.artigo ? ' — ' + t.artigo : ''}]\n${t.texto}`)
                    .join('\n\n');
                mensagensParaEnviar.splice(mensagensParaEnviar.length - 1, 0, {
                    role: 'system',
                    content: `TRECHOS DE LEGISLAÇÃO ENCONTRADOS (da base importada pela pessoa):\n\n${textoTrechos}`,
                });
            }
        }

        // Os agentes de busca (legislação/doutrina/Planalto/jurisprudência/
        // leis importadas etc.) SÓ rodam no modo PRO — "Res" e "Mini"
        // priorizam velocidade e nunca disparam essa pesquisa, nem com
        // "Pensar" ligado. Dentro do PRO, "Pensar" liga o sistema de 3 IAs
        // votando (ver cbResponderComVerificacao/usarAgentesParalelos em
        // ia-pesquisa-externa.js) — sem "Pensar", o PRO ainda pesquisa, mas
        // sequencial e sem a votação.
        const ehInterna = modeloAtivo !== 'pro' || temTrechoDeLei || (typeof window.cbClassificarPergunta === 'function' && window.cbClassificarPergunta(texto) === 'interna');

        if (modeloAtivo === 'mini') {
            mensagensParaEnviar.splice(mensagensParaEnviar.length - 1, 0, {
                role: 'system',
                content: 'Modo rápido ativado: responda em no máximo 2-3 frases curtas, direto ao ponto, só o essencial.',
            });
        } else if (modeloAtivo === 'pro' && !ehInterna) {
            // Só no modo PRO (o mais completo) e só pra pergunta "de fora"
            // (não pra saudação/pergunta interna, que não tem o que
            // esquematizar) — Res e Mini priorizam velocidade, uma tabela a
            // mais deles vai contra o objetivo dos dois.
            mensagensParaEnviar.splice(mensagensParaEnviar.length - 1, 0, {
                role: 'system',
                content: 'Se a pergunta for complexa (envolve múltiplos conceitos, comparações, requisitos, prazos ou distinções entre institutos), termine sua resposta com uma tabela markdown de resumo esquemático dos pontos principais, depois da explicação em texto. Se a pergunta for simples ou direta, não force essa tabela — só inclua quando ela realmente ajudar a organizar a resposta.',
            });
        }

        // Botão "Web": pesquisa na internet ANTES de responder, em qualquer modelo. Pergunta sobre
        // os dados da própria pessoa ("como estou indo?") não precisa de web e não gasta a cota.
        // Se a pesquisa falhar, a resposta sai sem ela e avisa isso com todas as letras.
        let achadoWeb = null;
        let avisoWeb = '';
        const perguntaSobreOsProprioDados = typeof window.cbClassificarPergunta === 'function' && window.cbClassificarPergunta(texto) === 'interna';
        if (webAtivo && !profundaAtiva && !perguntaSobreOsProprioDados && typeof window.cbBuscarNaWeb === 'function') {
            if (onFase) onFase('Pesquisando na web...');
            const web = await window.cbBuscarNaWeb(texto, perguntaAnteriorDoUsuario());
            if (web.ok) {
                achadoWeb = web;
            } else {
                avisoWeb = web.mensagem;
                cbMostrarAviso(web.mensagem, web.semChave
                    ? { duracao: 16000, acao: { rotulo: 'Colar chave', fn: cbAbrirConfiguracoesDaWeb } }
                    : { duracao: 9000 });
            }
        }

        // Pesquisa aprofundada: plano em 3 buscas + relatório com fontes (ia-pesquisa-aprofundada.js)
        if (profundaAtiva && !perguntaSobreOsProprioDados && typeof window.cbPesquisaAprofundada === 'function') {
            const rel = await window.cbPesquisaAprofundada(texto, onFase);
            return { respostaBruta: rel.texto, textoLimpo: rel.texto, propostas: [], fontes: rel.fontes };
        }

        let respostaBruta;
        let fontes = [];
        if (ehInterna || typeof window.cbResponderComVerificacao !== 'function') {
            if (achadoWeb) {
                mensagensParaEnviar.splice(mensagensParaEnviar.length - 1, 0, {
                    role: 'system',
                    content: `PESQUISA NA WEB:\n\n${achadoWeb.resumo}\n\n${achadoWeb.instrucao}`,
                });
            }
            if (onFase) onFase('Pensando...');
            respostaBruta = await window.cbGerarRespostaIA(mensagensParaEnviar);
            if (temTrechoDeLei) {
                fontes = trechosDeLeiEncontrados.map((t) => ({ titulo: `${t.lei}${t.artigo ? ' — ' + t.artigo : ''}`, url: null, interna: true }));
            }
            if (achadoWeb) fontes = [...fontes, ...achadoWeb.fontes];
        } else {
            const resultado = await window.cbResponderComVerificacao(texto, mensagensParaEnviar, onFase, pensarAtivo, achadoWeb);
            respostaBruta = resultado && typeof resultado === 'object' ? resultado.texto : resultado;
            fontes = (resultado && resultado.fontes) || [];
            if (temTrechoDeLei) {
                const fontesLei = trechosDeLeiEncontrados.map((t) => ({ titulo: `${t.lei}${t.artigo ? ' — ' + t.artigo : ''}`, url: null, interna: true }));
                fontes = [...fontesLei, ...fontes];
            }
        }

        const { textoLimpo, propostas } = cbExtrairPropostaAgenda(respostaBruta || '');
        return {
            respostaBruta,
            textoLimpo: (avisoWeb ? `⚠️ Respondi sem pesquisar na web. ${avisoWeb}\n\n` : '') + (textoLimpo || 'Não consegui gerar uma resposta agora.'),
            propostas,
            fontes,
        };
    }

    // ===================== orquestra uma rodada (envio novo / edição / regenerar) =====================
    async function executarRodada({ texto, bolhaUsuario, bolhaExistente, permitirEdicao }) {
        enviando = true;
        atualizarFerramentasInput();

        const meuSeq = ++requestSeq;
        const bolhaEspera = bolhaExistente || criarBolhaPensando();
        if (bolhaExistente) {
            bolhaExistente.className = 'ia-chat-msg ia-chat-msg-ia ia-chat-msg-pensando';
            bolhaExistente.innerHTML = MASCOTE_PENSANDO_HTML;
        }

        let pararEdicao = () => {};
        if (permitirEdicao && bolhaUsuario) {
            pararEdicao = cbHabilitarEdicaoBolha(bolhaUsuario, (novoTexto) => {
                if (meuSeq !== requestSeq) return; // já foi superada por outra edição
                requestSeq += 1; // aposenta esta rodada em andamento
                bolhaEspera.remove();
                if (historico[historico.length - 1] && historico[historico.length - 1].role === 'user') historico.pop();
                historico.push({ role: 'user', content: novoTexto });
                executarRodada({ texto: novoTexto, bolhaUsuario, permitirEdicao: true });
            });
        }

        const meuIndiceAssistant = historico.length;
        try {
            const resultado = await processarPergunta(texto, (fase) => atualizarFasePensando(bolhaEspera, fase));
            if (meuSeq !== requestSeq) return;
            pararEdicao();
            historico.push({ role: 'assistant', content: resultado.respostaBruta });
            finalizarBolhaResposta(bolhaEspera, resultado.textoLimpo, texto, meuIndiceAssistant);
            if (resultado.fontes.length) cbRenderizarFontes(resultado.fontes);
            if (window.cbUltimoProvedorIA === 'puter') {
                cbMostrarAviso('Esta resposta veio de um modelo de terceiros (Puter), porque a cota do nosso modelo acabou.', { duracao: 7000 });
            }
            if (resultado.propostas.length) cbRenderizarCartaoProposta(resultado.propostas);
            cbSalvarConversaAtual();
        } catch (err) {
            if (meuSeq !== requestSeq) return;
            pararEdicao();
            bolhaEspera.className = 'ia-chat-msg ia-chat-msg-erro';
            bolhaEspera.textContent = err.message || 'Não deu pra falar com a IA agora. Tente de novo.';
            if (historico.length > meuIndiceAssistant) historico.length = meuIndiceAssistant;
            if (historico[historico.length - 1] && historico[historico.length - 1].content === texto) historico.pop();
        } finally {
            if (meuSeq === requestSeq) {
                enviando = false;
                atualizarFerramentasInput();
            }
            elMensagens.scrollTop = elMensagens.scrollHeight;
        }
    }

    function autoresize() {
        elInput.style.height = 'auto';
        elInput.style.height = Math.min(elInput.scrollHeight, 80) + 'px';
    }

    function atualizarFerramentasInput() {
        const temTexto = elInput.value.trim().length > 0;
        // Enquanto está gravando, o microfone precisa continuar visível mesmo
        // com texto aparecendo (é a transcrição em tempo real) — senão a
        // pessoa perde o botão que usaria pra parar a gravação.
        if (btnMic) btnMic.classList.toggle('ia-chat-mic-oculto', temTexto && !gravandoVoz);
        btnEnviar.disabled = enviando || !temTexto;
    }

    async function enviarPergunta() {
        const texto = elInput.value.trim();
        if (!texto || enviando) return;
        cbPararGravacaoVoz();
        const bolhaUsuario = criarBolhaUsuario(texto);
        historico.push({ role: 'user', content: texto });
        elInput.value = '';
        autoresize();
        executarRodada({ texto, bolhaUsuario, permitirEdicao: true });
    }

    // ===================== ditado por voz (Web Speech API) =====================
    // Usa o reconhecimento de fala do próprio navegador (o mesmo tipo de recurso
    // do TTS de planalto/reading-mode.js). Duas coisas costumam dar errado, e
    // antes o botão falhava em silêncio — a pessoa clicava e nada acontecia:
    //  1) Popup de extensão não consegue mostrar a pergunta "permitir microfone":
    //     o erro volta como "not-allowed". A saída é liberar o microfone UMA vez
    //     numa aba da extensão (permissao-microfone.html); depois disso o popup
    //     passa a funcionar.
    //  2) No Chrome/Opera/Brave o áudio vai para um serviço online do navegador.
    //     Sem acesso a ele (VPN, bloqueio, navegador sem o serviço) vem "network".
    // Agora cada falha vira uma mensagem clara no próprio chat (#ia-chat-aviso).
    let reconhecimentoVoz = null;
    let gravandoVoz = false;
    const PLACEHOLDER_PADRAO = elInput.placeholder;
    const elAviso = document.getElementById('ia-chat-aviso');
    const DICA_WIN_H = 'Dica: com o cursor no campo, aperte Win + H para ditar pelo próprio Windows.';
    let avisoTimer = null;

    function cbEsconderAviso() {
        clearTimeout(avisoTimer);
        if (elAviso) elAviso.hidden = true;
    }
    function cbMostrarAviso(texto, opcoes) {
        if (!elAviso) return;
        const o = opcoes || {};
        clearTimeout(avisoTimer);
        elAviso.textContent = '';
        const span = document.createElement('span');
        span.className = 'iac-aviso-texto';
        span.textContent = texto;
        elAviso.appendChild(span);
        if (o.acao) {
            const b = document.createElement('button');
            b.type = 'button';
            b.className = 'iac-aviso-btn';
            b.textContent = o.acao.rotulo;
            b.addEventListener('click', o.acao.fn);
            elAviso.appendChild(b);
        }
        elAviso.hidden = false;
        avisoTimer = setTimeout(cbEsconderAviso, o.duracao || 10000);
    }
    function cbAbrirPaginaMicrofone() {
        const url = chrome.runtime.getURL('interface-popup/permissao-microfone.html');
        if (chrome.tabs && chrome.tabs.create) chrome.tabs.create({ url });
        else window.open(url, '_blank');
    }
    const AVISO_SEM_PERMISSAO = {
        texto: 'O navegador não liberou o microfone para a extensão.',
        opcoes: { acao: { rotulo: 'Permitir microfone', fn: cbAbrirPaginaMicrofone }, duracao: 15000 }
    };
    function cbAvisoDeErroVoz(codigo) {
        switch (codigo) {
            case 'not-allowed':
            case 'service-not-allowed':
                return AVISO_SEM_PERMISSAO;
            case 'audio-capture':
                return { texto: 'Não encontrei um microfone. Confira se ele está conectado e liberado nas configurações de privacidade do Windows.' };
            case 'network':
                return { texto: `O navegador não conseguiu usar o serviço de reconhecimento de voz (pode ser VPN, bloqueio ou um navegador sem esse serviço). ${DICA_WIN_H}`, opcoes: { duracao: 16000 } };
            case 'language-not-supported':
                return { texto: `O serviço de voz do navegador não reconheceu o português. ${DICA_WIN_H}`, opcoes: { duracao: 14000 } };
            case 'no-speech':
                return { texto: 'Não ouvi nada. Clique no microfone e fale de novo.' };
            case 'aborted':
                return null;
            default:
                return { texto: `O ditado por voz falhou (${codigo}). ${DICA_WIN_H}`, opcoes: { duracao: 14000 } };
        }
    }
    async function cbMicrofoneBloqueado() {
        try {
            if (!navigator.permissions || !navigator.permissions.query) return false;
            const p = await navigator.permissions.query({ name: 'microphone' });
            return p.state === 'denied';
        } catch (e) { return false; /* sem Permissions API: deixa o onerror falar */ }
    }

    function cbPararGravacaoVoz() {
        if (reconhecimentoVoz && gravandoVoz) {
            try { reconhecimentoVoz.stop(); } catch (e) { /* ignora */ }
        }
    }
    async function cbAlternarGravacaoVoz() {
        if (gravandoVoz) { cbPararGravacaoVoz(); return; }
        cbEsconderAviso();
        const Ctor = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!Ctor) {
            cbMostrarAviso(`Este navegador não oferece ditado por voz para extensões. ${DICA_WIN_H}`, { duracao: 15000 });
            return;
        }
        // Se o microfone já está bloqueado, o navegador nem pergunta de novo:
        // vai direto pra página que explica como liberar.
        if (await cbMicrofoneBloqueado()) {
            cbMostrarAviso(AVISO_SEM_PERMISSAO.texto, AVISO_SEM_PERMISSAO.opcoes);
            return;
        }

        const r = new Ctor();
        r.lang = 'pt-BR';
        r.continuous = false;
        r.interimResults = true;
        r.maxAlternatives = 1;
        reconhecimentoVoz = r;

        const textoBase = elInput.value ? `${elInput.value.trim()} ` : '';
        let ouviuAlgo = false;
        let jaAvisou = false;
        gravandoVoz = true;
        btnMic.classList.add('ia-chat-mic-gravando');
        atualizarFerramentasInput();

        // Se em 7s o navegador não começou a ouvir, a pergunta de permissão não
        // apareceu (comum em popup): encerra e mostra o caminho pra liberar.
        const timerInicio = setTimeout(() => {
            if (!gravandoVoz) return;
            jaAvisou = true;
            cbMostrarAviso(AVISO_SEM_PERMISSAO.texto, AVISO_SEM_PERMISSAO.opcoes);
            try { r.abort(); } catch (e) { /* ignora */ }
        }, 7000);

        r.onstart = () => {
            clearTimeout(timerInicio);
            elInput.placeholder = 'Ouvindo… pode falar';
        };
        r.onresult = (e) => {
            ouviuAlgo = true;
            let transcricao = '';
            for (let i = 0; i < e.results.length; i++) transcricao += e.results[i][0].transcript;
            elInput.value = textoBase + transcricao;
            autoresize();
            atualizarFerramentasInput();
        };
        r.onerror = (e) => {
            clearTimeout(timerInicio);
            if (jaAvisou) return;
            const aviso = cbAvisoDeErroVoz(e && e.error);
            jaAvisou = true;
            if (aviso) cbMostrarAviso(aviso.texto, aviso.opcoes);
        };
        r.onend = () => {
            clearTimeout(timerInicio);
            gravandoVoz = false;
            btnMic.classList.remove('ia-chat-mic-gravando');
            elInput.placeholder = PLACEHOLDER_PADRAO;
            reconhecimentoVoz = null;
            atualizarFerramentasInput();
            // terminou sem texto e sem erro: não ouviu nada
            if (!ouviuAlgo && !jaAvisou) {
                const aviso = cbAvisoDeErroVoz('no-speech');
                cbMostrarAviso(aviso.texto, aviso.opcoes);
            }
        };
        try {
            r.start();
        } catch (e) {
            clearTimeout(timerInicio);
            gravandoVoz = false;
            btnMic.classList.remove('ia-chat-mic-gravando');
            elInput.placeholder = PLACEHOLDER_PADRAO;
            cbMostrarAviso(`Não consegui iniciar o ditado por voz. ${DICA_WIN_H}`, { duracao: 14000 });
        }
    }

    btnAbrir.addEventListener('click', abrirModal);
    btnFechar.addEventListener('click', fecharModal);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) fecharModal(); });

    btnEnviar.addEventListener('click', enviarPergunta);
    elInput.addEventListener('input', () => { autoresize(); atualizarFerramentasInput(); });
    elInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            enviarPergunta();
        }
    });
    if (btnProfunda) {
        btnProfunda.addEventListener('click', () => {
            profundaAtiva = !profundaAtiva;
            btnProfunda.classList.toggle('ia-chat-pensar-ativo', profundaAtiva);
            btnProfunda.setAttribute('aria-pressed', String(profundaAtiva));
        });
    }
    // ---- botão "+": menu que junta Pensar, Web e Pesquisa aprofundada ----
    function cbAtualizarMais() {
        if (btnMais) btnMais.classList.toggle('ia-chat-mais-ativo', pensarAtivo || webAtivo || profundaAtiva);
    }
    function cbFecharPainelMais() {
        if (!painelMais) return;
        painelMais.hidden = true;
        btnMais.setAttribute('aria-expanded', 'false');
    }
    if (btnMais && painelMais) {
        btnMais.addEventListener('click', (e) => {
            e.stopPropagation();
            const abrir = painelMais.hidden;
            painelMais.hidden = !abrir;
            btnMais.setAttribute('aria-expanded', String(abrir));
        });
        painelMais.addEventListener('click', () => setTimeout(cbAtualizarMais, 0));
        document.addEventListener('click', (e) => {
            if (!painelMais.hidden && !painelMais.contains(e.target) && !btnMais.contains(e.target)) cbFecharPainelMais();
        });
        // a escolha de "Web" salva chega do storage depois da abertura: atualiza o "+" quando chegar
        setTimeout(cbAtualizarMais, 300);
    }
    if (btnPensar) {
        btnPensar.addEventListener('click', () => {
            pensarAtivo = !pensarAtivo;
            btnPensar.classList.toggle('ia-chat-pensar-ativo', pensarAtivo);
            btnPensar.setAttribute('aria-pressed', String(pensarAtivo));
        });
    }
    // ---- botão do marca-texto: destaques coloridos das respostas ----
    // Só muda uma classe na folha do chat (ver bloco "destaques coloridos" no apple.css), então vale
    // também para as respostas que já estão na tela. A escolha fica salva e vale na próxima abertura.
    const CB_DESTAQUES_STORAGE_KEY = 'cbChatDestaques';
    let destaquesAtivos = true;
    function cbAplicarDestaques() {
        const folha = overlay.querySelector('.ap-chatia');
        if (folha) folha.classList.toggle('ia-sem-destaques', !destaquesAtivos);
        if (btnDestaques) {
            btnDestaques.setAttribute('aria-pressed', String(destaquesAtivos));
            btnDestaques.title = `Destaques coloridos nas respostas: ${destaquesAtivos ? 'ligados' : 'desligados'}`;
        }
    }
    if (btnDestaques) {
        btnDestaques.addEventListener('click', () => {
            destaquesAtivos = !destaquesAtivos;
            cbAplicarDestaques();
            if (typeof chrome !== 'undefined' && chrome.storage) chrome.storage.local.set({ [CB_DESTAQUES_STORAGE_KEY]: destaquesAtivos });
            cbMostrarAviso(destaquesAtivos ? 'Destaques coloridos ligados.' : 'Destaques coloridos desligados. As respostas ficam em texto normal.', { duracao: 3500 });
        });
        if (typeof chrome !== 'undefined' && chrome.storage) {
            chrome.storage.local.get([CB_DESTAQUES_STORAGE_KEY], (res) => {
                if (res && res[CB_DESTAQUES_STORAGE_KEY] === false) {
                    destaquesAtivos = false;
                    cbAplicarDestaques();
                }
            });
        }
    }

    // ---- botão "Web" ----
    // A pesquisa funciona sem chave (modo keyless da Tavily, com limite baixo). Quando o limite
    // acaba, o aviso da resposta tem o botão "Colar chave", que leva direto às Configurações.
    function cbAplicarWebNaUI() {
        if (!btnWeb) return;
        btnWeb.classList.toggle('ia-chat-pensar-ativo', webAtivo);
        btnWeb.setAttribute('aria-pressed', String(webAtivo));
    }
    function cbAbrirConfiguracoesDaWeb() {
        fecharModal();
        const abrir = document.getElementById('btn-open-settings');
        if (abrir) abrir.click();
        const acc = document.querySelector('.settings-accordion[data-acc="ia"]');
        if (acc && !acc.classList.contains('open')) {
            const cab = acc.querySelector('.settings-accordion-head');
            if (cab) cab.click();
        }
    }
    if (btnWeb) {
        btnWeb.addEventListener('click', () => {
            webAtivo = !webAtivo;
            cbAplicarWebNaUI();
            if (typeof chrome !== 'undefined' && chrome.storage) chrome.storage.local.set({ [CB_WEB_STORAGE_KEY]: webAtivo });
            if (webAtivo) cbMostrarAviso('Pesquisa na web ligada: sua pergunta é enviada ao serviço de busca antes de a IA responder.', { duracao: 6000 });
            else cbEsconderAviso();
        });
        // lembra a escolha da última vez
        if (typeof chrome !== 'undefined' && chrome.storage) {
            chrome.storage.local.get([CB_WEB_STORAGE_KEY], (res) => {
                if (res && res[CB_WEB_STORAGE_KEY]) {
                    webAtivo = true;
                    cbAplicarWebNaUI();
                }
            });
        }
    }
    if (btnMic) btnMic.addEventListener('click', cbAlternarGravacaoVoz);

    if (btnModelo && painelModelo) {
        cbAplicarModeloNaUI();
        btnModelo.addEventListener('click', (e) => {
            e.stopPropagation();
            cbAlternarPainelModelo();
        });
        painelModelo.querySelectorAll('.ia-chat-modelo-opt').forEach((opt) => {
            opt.addEventListener('click', () => {
                modeloAtivo = opt.dataset.modelo;
                cbAplicarModeloNaUI();
                cbFecharPainelModelo();
                if (typeof chrome !== 'undefined' && chrome.storage) {
                    chrome.storage.local.set({ [CB_MODELO_STORAGE_KEY]: modeloAtivo });
                }
            });
        });
        document.addEventListener('click', (e) => {
            if (!painelModelo.hidden && !btnModelo.contains(e.target) && !painelModelo.contains(e.target)) {
                cbFecharPainelModelo();
            }
        });
    }

    // Sugestões de pergunta: só aparecem enquanto a conversa não começou (some assim
    // que existe uma pergunta sua na tela, inclusive ao abrir uma conversa do histórico).
    const elSugestoes = document.getElementById('ia-chat-sugestoes');
    if (elSugestoes) {
        const atualizarSugestoes = () => {
            elSugestoes.hidden = !!elMensagens.querySelector('.ia-chat-msg-user');
        };
        new MutationObserver(atualizarSugestoes).observe(elMensagens, { childList: true });
        elSugestoes.addEventListener('click', (e) => {
            const botao = e.target.closest('button[data-pergunta]');
            if (!botao || enviando) return;
            elInput.value = botao.dataset.pergunta;
            autoresize();
            atualizarFerramentasInput();
            enviarPergunta();
        });
        atualizarSugestoes();
    }

    atualizarFerramentasInput();
})();
