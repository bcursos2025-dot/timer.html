// ============================================================================
// verificacao.js — cartão "Verificação de segurança" (Configurações → Sobre). Os resultados vêm DESTE objeto: só preencha
// com o que os serviços realmente devolveram para o arquivo .zip publicado (VirusTotal, Jotti, Kaspersky, Hybrid Analysis).
// Campo `resultado` vazio = "pendente" (nada é afirmado). `url` deve ser o link do relatório daquele arquivo, quando existir.
//
// `sha256` fica vazio dentro do pacote DE PROPÓSITO: o hash de um .zip não pode estar escrito dentro do próprio .zip (mudaria o
// hash). Depois de publicar, preencha aqui na próxima versão ou divulgue o hash no site/loja.
// ============================================================================
window.CB_VERIFICACAO = {
    versao: '8.0',
    // SHA-256 do zip enviado a VirusTotal, Jotti, Kaspersky e Hybrid Analysis. Gridinsoft analisou o zip seguinte (19b261c5b616…); o pacote
    // final difere só nesta própria tela, que não pode citar o hash do arquivo em que está escrita.
    sha256: '266922011efbd4d4aad3be50de2edb96c2a816c42a3a6eb0aee7827c20a23d77',
    // true só quando TODOS os resultados abaixo mostram nenhuma detecção de antivírus.
    semAmeacas: true,
    servicos: [
        { nome: 'VirusTotal', url: 'https://www.virustotal.com/gui/file/266922011efbd4d4aad3be50de2edb96c2a816c42a3a6eb0aee7827c20a23d77', resultado: '0/63' },
        { nome: "Jotti's Malware Scan", url: 'https://virusscan.jotti.org/pt-BR/filescanjob/sfl12k0awl', resultado: '0/13' },
        { nome: 'Kaspersky Threat Intelligence', url: 'https://opentip.kaspersky.com/266922011EFBD4D4AAD3BE50DE2EDB96C2A816C42A3A6EB0AEE7827C20A23D77/results', resultado: 'Clean' },
        { nome: 'Hybrid Analysis', url: 'https://hybrid-analysis.com/sample/266922011efbd4d4aad3be50de2edb96c2a816c42a3a6eb0aee7827c20a23d77', resultado: '0/26' },
        { nome: 'Gridinsoft', url: 'https://pt.gridinsoft.com/online-virus-scanner/id/19b261c5b6167d9f7a6303c7bf28fa9a8ca065dd5b7dfdec834bc118d0693ecd', resultado: '0%' },
        { nome: 'VeePN File Checker', url: 'https://veepn.com/pt/file-checker/', resultado: 'Limpo' },
        { nome: 'NordVPN File Checker', url: 'https://nordvpn.com/pt-br/file-checker/', resultado: 'Limpo' },
        { nome: 'IPQualityScore', url: 'https://www.ipqualityscore.com/file-malware-scanner/d877438ad289e8ebe7afd99b067cfa8135ca55a50b5424726b91675220292eac', resultado: 'Clean' },
        { nome: 'ESET Online Scanner', url: 'https://www.eset.com/br/home/online-scanner/', resultado: '0 de 30 arquivos' },
        { nome: 'Malwarebytes', url: 'https://www.malwarebytes.com/', resultado: '0 ameaças' },
        { nome: 'Avira Free Security', url: 'https://www.avira.com/pt-br/free-antivirus-windows', resultado: '0 de 205 arquivos' },
        { nome: 'Mozilla Add-ons (revisão da loja)', url: 'https://addons.mozilla.org/pt-BR/firefox/addon/concurseiro-blindado-anal%C3%ADtico/', resultado: 'Aprovada' },
    ],
};

(function () {
    'use strict';
    const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const OK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>';
    const RELOGIO = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></svg>';

    function desenhar() {
        const alvo = document.getElementById('av-verify-card');
        const d = window.CB_VERIFICACAO;
        if (!alvo || !d) return;
        const feitos = d.servicos.filter((s) => s.resultado);
        const completo = feitos.length === d.servicos.length;
        const tudoLimpo = completo && d.semAmeacas;
        const texto = completo
            ? (d.semAmeacas
                ? `O pacote da v${esc(d.versao)} passou por ${d.servicos.length === 4 ? 'quatro' : d.servicos.length} serviços independentes de análise. Nenhum antivírus detectou malware.`
                : `Resultados de ${d.servicos.length} análises independentes do pacote da v${esc(d.versao)}, todos publicados aqui, inclusive o alerta. Abra cada relatório para conferir.`)
            : (feitos.length
                ? `Pacote da v${esc(d.versao)}: ${feitos.length} de ${d.servicos.length} análises publicadas. As demais ainda estão pendentes.`
                : `As análises do pacote da v${esc(d.versao)} ainda não foram publicadas. Quando forem, os resultados aparecem aqui.`);
        alvo.innerHTML = `
            <div class="av-verify-head">
                <span class="av-verify-badge${tudoLimpo ? '' : ' av-verify-badge--pend'}">${tudoLimpo ? OK : RELOGIO}</span>
                <span class="av-verify-headtext"><h4>Verificação de segurança · v${esc(d.versao)}</h4><p>${texto}</p></span>
            </div>
            <ul class="av-verify-list">${d.servicos.map((s) => `
                <li><a href="${esc(s.url)}" target="_blank" rel="noopener">
                    <span class="av-verify-name">${esc(s.nome)}</span>
                    <span class="av-verify-result${s.alerta ? ' av-verify-result--alerta' : (s.resultado ? '' : ' av-verify-result--pend')}">${s.resultado ? esc(s.resultado) : 'pendente'}</span>
                </a></li>`).join('')}</ul>
            ${d.sha256 ? `<div class="av-verify-hash"><span class="av-verify-hash-label">Arquivo analisado · SHA-256</span><code>${esc(d.sha256)}</code></div>` : ''}`;
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', desenhar); else desenhar();
})();
