
const DUR=31;
const E={lin:x=>x,oc:x=>1-Math.pow(1-x,3),io:x=>x<.5?4*x*x*x:1-Math.pow(-2*x+2,3)/2,ob:x=>{const c1=1.70158,c3=c1+1;return 1+c3*Math.pow(x-1,3)+c1*Math.pow(x-1,2)},oe:x=>x>=1?1:1-Math.pow(2,-10*x),oq:x=>1-Math.pow(1-x,5)};
const C=(x,a=0,b=1)=>Math.min(b,Math.max(a,x));
const P=(t,a,d,e=E.oc)=>e(C((t-a)/d));
const $=id=>document.getElementById(id);
function T(el,o){ if(typeof el==='string')el=$(el);
  const x=o.x||0,y=o.y||0,s=o.s==null?1:o.s,r=o.r||0;
  el.style.transform=`translate(${x}px,${y}px) rotate(${r}deg) scale(${s})`;
  el.style.opacity=o.o==null?1:o.o;
  if(o.b!=null)el.style.filter=o.b>0.05?`blur(${o.b}px)`:'';}
// inclinação 3D suave + flutuação (depois do T)
function tilt(id,t,amp=1,ph=0){const el=$(id);const ry=3.2*amp*Math.sin(t*.9+ph),rx=2.4*amp*Math.cos(t*.7+ph),by=7*amp*Math.sin(t*1.3+ph);
  el.style.transform=`perspective(1800px) rotateX(${rx}deg) rotateY(${ry}deg) translateY(${by}px) `+el.style.transform;}
function bob(id,t,amp=8,ph=0){const el=$(id);el.style.transform+=` translateY(${amp*Math.sin(t*1.6+ph)}px)`;}
// ===== efeitos (deterministas): ondas, faíscas, confete, flash, varredura de luz =====
const rd=(i)=>{const x=Math.sin(i*91.7+3.1)*43758.5453;return x-Math.floor(x)};
const FXE=[];
const shock=(t,x,y,col,R=520,d=.9)=>FXE.push({t,d,f:(c,a)=>{const p=a/d,q=1-Math.pow(1-p,3);c.strokeStyle=col;c.globalAlpha=(1-p)*.9;c.lineWidth=2+16*(1-p);c.beginPath();c.arc(x,y,R*q,0,6.283);c.stroke();c.globalAlpha=1}});
const flash=(t,al=.5,d=.45)=>FXE.push({t,d,f:(c,a)=>{c.fillStyle=`rgba(255,255,255,${al*(1-a/d)})`;c.fillRect(0,0,1080,1920)}});
const sweep=(t,d=.75)=>FXE.push({t,d,f:(c,a)=>{const p=a/d,q=p*p*(3-2*p),x=-400+1900*q,g=c.createLinearGradient(x-120,0,x+120,0);g.addColorStop(0,'rgba(170,140,255,0)');g.addColorStop(.5,`rgba(210,190,255,${.42*Math.sin(p*3.14159)})`);g.addColorStop(1,'rgba(170,140,255,0)');c.fillStyle=g;c.beginPath();c.moveTo(x-120,0);c.lineTo(x+120,0);c.lineTo(x+120-560,1920);c.lineTo(x-120-560,1920);c.closePath();c.fill()}});
const burst=(t,x,y,n,pal,{conf=false,sp=700,d=1.3,g=900,size=12,seed=1}={})=>FXE.push({t,d,f:(c,a)=>{const p=a/d;for(let i=0;i<n;i++){const an=rd(i*3+seed)*6.283,v=(.35+rd(i*7+seed))*sp*(1-.55*p),px=x+Math.cos(an)*v*a,py=y+Math.sin(an)*v*a+g*(conf?1:.35)*a*a*.5;const col=pal[i%pal.length];c.globalAlpha=Math.max(0,1-p*p);c.fillStyle=col;
  if(conf){c.save();c.translate(px,py);c.rotate(a*(4+rd(i)*10));c.fillRect(-size/2,-size/4,size,size/2);c.restore()}else{const r=size*(.4+rd(i*5)*.7)*(1-p*.6);const gr=c.createRadialGradient(px,py,0,px,py,r*2.4);gr.addColorStop(0,col);gr.addColorStop(1,'rgba(255,255,255,0)');c.fillStyle=gr;c.beginPath();c.arc(px,py,r*2.4,0,6.283);c.fill()}}c.globalAlpha=1}});
function fx(t){const c=$('fx').getContext('2d');c.clearRect(0,0,1080,1920);c.globalCompositeOperation='lighter';FXE.forEach(e=>{const a=t-e.t;if(a>=0&&a<=e.d)e.f(c,a)});
  if(t>=30.4){const p=((t-30.4)%2.6)/2.6;c.strokeStyle='rgba(180,150,255,'+(.55*(1-p))+')';c.lineWidth=3+8*(1-p);c.beginPath();c.arc(540,590,170+420*p,0,6.283);c.stroke()}
  c.globalCompositeOperation='source-over'}
function shake(t){let x=0,y=0;[[.95,6],[1.65,6],[2.35,10],[6.9,14]].forEach(([t0,A])=>{const a=t-t0;if(a>=0&&a<.5){const d=Math.pow(1-a/.5,2)*A;x+=Math.sin(a*85)*d;y+=Math.cos(a*70)*d*.7}});return[x,y]}
// linha do tempo dos efeitos
[3.6,6.8,10,15.6,19.4,23.4,26.6,29.4].forEach(b=>sweep(b-.15));
[.95,1.65,2.35].forEach((t0,i)=>{shock(t0+.08,740,1045,'rgb(255,77,106)',500,.8);burst(t0+.08,740,1045,18,['#ff4d6a','#ff9aa9','#fff'],{sp:520,d:.8,size:10,seed:i+1})});
flash(6.9,.3,.5);shock(6.95,540,760,'rgb(190,160,255)',700,1.1);shock(7.1,540,760,'rgb(255,255,255)',520,.9);burst(6.95,540,760,70,['#c4b5fd','#fff','#7dd3fc','#ffd166'],{sp:900,d:1.5,size:14,seed:5});
burst(12.35,680,1320,60,['#2fd68b','#7dffc0','#ffd166','#a78bfa','#fff'],{conf:true,sp:760,d:1.6,size:16,seed:9});shock(12.35,680,1320,'rgb(47,214,139)',360,.7);
burst(13.9,520,900,26,['#ffe066','#fff'],{sp:380,d:1,size:10,seed:3});
burst(14.45,930,690,26,['#ff4d6a','#ffb3bf'],{sp:420,d:.9,size:10,seed:4});shock(14.45,930,690,'rgb(255,77,106)',240,.6);
burst(21.0,780,420,40,['#ffd166','#ff9f43','#ff5e3a'],{sp:620,d:1.1,size:12,seed:6});
for(let i=0;i<6;i++){const cx=[228,540,851][i%3],cy=[565,840][Math.floor(i/3)];shock(24.3+i*.14+.1,cx,cy,'rgb(167,139,250)',260,.6)}
burst(29.55,540,600,110,['#a78bfa','#fff','#ffd166','#2fd68b','#7dd3fc','#ff7aa8'],{conf:true,sp:1000,d:2.2,size:18,g:1100,seed:11});shock(29.5,540,590,'rgb(190,160,255)',650,1.2);flash(29.5,.35,.4);
// SCENES [start,end]
const SC={s1:[0,3.6],s2:[3.6,6.8],s3:[6.8,10],s4:[10,15.6],s5:[15.6,19.4],s6:[19.4,23.4],s7:[23.4,26.6],s8:[26.6,29.4],s9:[29.4,99999]};
// split headlines into words
document.querySelectorAll('.headline').forEach(h=>{
  const walk=(n)=>{[...n.childNodes].forEach(c=>{
    if(c.nodeType===3){const f=document.createDocumentFragment();c.textContent.split(/(\s+)/).forEach(w=>{if(!w)return; if(/^\s+$/.test(w)){f.append(' ');return;} const s=document.createElement('span');s.className='w';s.textContent=w;f.append(s);});c.replaceWith(f);}
    else if(c.nodeType===1&&c.tagName!=='BR'&&!c.classList.contains('w'))walk(c);});};
  walk(h);});
function words(h,t,a,gap=.07,dur=.5){[...$(h).querySelectorAll('.w')].forEach((w,i)=>{const p=P(t,a+i*gap,dur,E.ob);w.style.opacity=C(p*1.4);w.style.transform=`translateY(${(1-p)*60}px) scale(${.85+.15*p})`;w.style.filter=p<.98?`blur(${(1-p)*10}px)`:'';});}
// background particles
const bk=$('bk').getContext('2d');
const rnd=(i)=>{const x=Math.sin(i*127.1)*43758.5453;return x-Math.floor(x)};
const PARTS=Array.from({length:46},(_,i)=>({x:rnd(i)*1080,y:rnd(i+99)*1920,r:6+rnd(i+7)*34,sp:8+rnd(i+3)*26,ph:rnd(i+5)*6.28,a:.05+rnd(i+11)*.16,h:rnd(i+13)>.6?'180,140,255':(rnd(i+17)>.5?'80,200,220':'255,255,255')}));
function bg(t){bk.clearRect(0,0,1080,1920);
  const gx=540+Math.cos(t*.35)*260,gy=520+Math.sin(t*.28)*180;
  let g=bk.createRadialGradient(gx,gy,0,gx,gy,620);g.addColorStop(0,'rgba(124,58,237,.30)');g.addColorStop(1,'rgba(124,58,237,0)');bk.fillStyle=g;bk.fillRect(0,0,1080,1920);
  const hx=540+Math.sin(t*.3)*300,hy=1500+Math.cos(t*.33)*160;
  g=bk.createRadialGradient(hx,hy,0,hx,hy,560);g.addColorStop(0,'rgba(34,190,210,.18)');g.addColorStop(1,'rgba(34,190,210,0)');bk.fillStyle=g;bk.fillRect(0,0,1080,1920);
  bk.save();bk.globalCompositeOperation='lighter';for(let k=0;k<2;k++){const ang=.5+k*.9+Math.sin(t*.12+k)*.12,cx=300+k*500+Math.sin(t*.2+k*2)*120;bk.translate(cx,-200);bk.rotate(ang);const lg=bk.createLinearGradient(-140,0,140,0);lg.addColorStop(0,'rgba(140,110,255,0)');lg.addColorStop(.5,'rgba(140,110,255,'+(.07+.03*Math.sin(t*.7+k))+')');lg.addColorStop(1,'rgba(140,110,255,0)');bk.fillStyle=lg;bk.fillRect(-140,0,280,2600);bk.rotate(-ang);bk.translate(-cx,200)}bk.restore();
  PARTS.forEach(p=>{const y=((p.y-t*p.sp)%2100+2100)%2100-90;const x=p.x+Math.sin(t*.5+p.ph)*30;
    const gg=bk.createRadialGradient(x,y,0,x,y,p.r);gg.addColorStop(0,`rgba(${p.h},${p.a*1.6})`);gg.addColorStop(.7,`rgba(${p.h},${p.a})`);gg.addColorStop(1,`rgba(${p.h},0)`);bk.fillStyle=gg;bk.beginPath();bk.arc(x,y,p.r,0,6.283);bk.fill();});}
// grain tile
(function(){const c=$('grain').getContext('2d');const d=c.createImageData(256,256);for(let i=0;i<d.data.length;i+=4){const v=Math.random()*255;d.data[i]=d.data[i+1]=d.data[i+2]=v;d.data[i+3]=255}c.putImageData(d,0,0);})();
// build dynamic bits
(function(){
  const b=$('s6bars');[.45,.62,.38,.8,.7,.55,1].forEach((h,i)=>{const d=document.createElement('div');d.style.cssText=`flex:1;height:${h*110}px;border-radius:12px 12px 6px 6px;background:${i===6?'linear-gradient(180deg,#8b5cf6,#6d28d9)':'#cfd3e6'};transform-origin:50% 100%`;d.className='bar';b.append(d);});
  (function(){const tk=$('ticks');let h='';for(let i=0;i<60;i++){const a=i/60*6.2832-1.5708,r1=162,r2=i%5===0?148:154;h+=`<line x1="${230+r1*Math.cos(a)}" y1="${230+r1*Math.sin(a)}" x2="${230+r2*Math.cos(a)}" y2="${230+r2*Math.sin(a)}" stroke="#8b5cf6" stroke-width="${i%5===0?4:2.5}" stroke-linecap="round" opacity=".28"/>`}tk.innerHTML=h})();
  const g=$('s7grid');const cols=[['#ff7a59','#ff3d6e'],['#46c3ff','#3b6bff'],['#ffd44d','#ff8f3d'],['#8a5cff','#c04bff'],['#3ddc97','#12a8a0'],['#ff6bb5','#ff4d4d']];
  const nm=['Redes','Vídeos','Jogos','Feed','Stories','Chat'];
  cols.forEach((c,i)=>{const d=document.createElement('div');d.className='app';d.style.cssText='position:relative;text-align:center';d.innerHTML=`<div style="height:190px;border-radius:50px;background:linear-gradient(145deg,${c[0]},${c[1]});box-shadow:0 24px 50px rgba(0,0,0,.45),inset 0 2px 0 rgba(255,255,255,.4);display:flex;align-items:center;justify-content:center"><div style="width:76px;height:76px;border-radius:50%;background:rgba(255,255,255,.28)"></div></div><div style="color:#fff;font-size:28px;font-weight:700;margin-top:14px;opacity:.9">${nm[i]}</div><div class="lock" style="position:absolute;left:0;right:0;top:0;height:190px;border-radius:50px;background:rgba(14,10,40,.78);display:flex;align-items:center;justify-content:center;opacity:0"><svg width="72" height="72" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="10.5" width="14" height="10" rx="3"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/></svg></div>`;g.append(d);});
})();

function fade(id,t,cam=true){const [a,b]=SC[id];const el=$(id);
  if(t<a-.01||t>b+.01){el.style.opacity=0;el.style.visibility='hidden';return -1}
  el.style.visibility='visible';const lt=t-a,d=b-a;
  const o=Math.min(P(t,a,id==='s1'?.01:.28,E.lin),1-P(t,b-.28,.28,E.lin));el.style.opacity=id==='s9'?Math.min(P(t,a,.28,E.lin),1):o;el.style.pointerEvents=(id==='s9'&&o>.5)?'auto':'none';
  const c=el.querySelector('.cam');const k=Math.min(1,lt/Math.min(d,6));const en=id==='s1'?1:P(t,a,.55,E.oc),ex=id==='s9'?0:P(t,b-.4,.4,E.lin);const [sx,sy]=shake(t);
  c.style.transform=`translate(${sx}px,${sy-16*k+36*(1-en)}px) scale(${(1+.045*k)*(1+.06*(1-en))*(1-.05*ex)})`;
  const bl=(1-en)*12+ex*10;c.style.filter=bl>.15?`blur(${bl}px)`:'';
  return lt;}

const TYPED='O art. 5º, XII protege o sigilo das comunicações. Quanto às telefônicas, só cabe quebra por ordem judicial, para investigação criminal ou instrução processual penal.';
function seek(t){
  bg(t);fx(t);
  $('grain').style.transform=`translate(${-(Math.floor(t*30)*53%200)}px,${-(Math.floor(t*30)*97%200)}px)`;
  let lt;
  // S1
  if((lt=fade('s1',t))>=0){
    words('s1h',lt,.05,.09,.55);
    T('s1card',{y:(1-P(lt,.15,.7,E.oq))*400+(lt>2.9?(lt-2.9)*40:0),o:P(lt,.15,.4)});tilt('s1card',lt,.8);
    const pick=lt>.75;$('optE').style.cssText=pick?'background:#ffe3e8;border-color:#ff4d6a;color:#b4233d':'';
    const cyc=[.95,1.65,2.35];let n=0;cyc.forEach((c,i)=>{if(lt>=c)n=i+1});
    const st=cyc[n-1]??0;const sp=n?P(lt,st,.18,E.ob):0;const sh=n?Math.max(0,1-(lt-st)/.35):0;
    T('s1stamp',{s:n?1.9-.9*sp:.01,o:n?C(sp*2)*(lt>st+.62&&n<3?1-P(lt,st+.62,.12,E.lin):1):0,r:-9+n*3+Math.sin(lt*70)*sh*3,x:Math.sin(lt*90)*sh*14});
    $('s1stamp').textContent=n?['ERROU','ERROU','ERROU!'][n-1]:'';
    const att=$('s1att');[...att.children].forEach((c,i)=>{const p=P(lt,cyc[i]+.1,.35,E.ob);c.style.opacity=p;c.style.transform=`scale(${.6+.4*p})`});
    T('s1cap',{y:(1-P(lt,2.4,.5,E.oc))*50,o:P(lt,2.4,.4)});
  }
  // S2
  if((lt=fade('s2',t))>=0){
    words('s2h',lt,.05,.06,.5);
    ['s2c1','s2c2','s2c3'].forEach((id,i)=>{const p=P(lt,.7+i*.35,.55,E.oq);T(id,{x:(i%2?1:-1)*(1-p)*600,o:C(p*2)});
      const st=$(id).querySelector('.strike');st.style.transform=`scaleX(${P(lt,1.5+i*.3,.4,E.io)})`;});
  }
  // S3
  if((lt=fade('s3',t))>=0){
    const p=P(lt,.1,.8,E.ob);
    T('s3icon',{s:.3+.7*p,o:C(p*3),r:(1-p)*-25});
    T('s3glow',{s:.5+.7*P(lt,0,1.4,E.oc)+Math.sin(lt*2)*.03,o:P(lt,0,.5)*.9});
    ['s3ring1','s3ring2'].forEach((id,i)=>{const q=P(lt,.2+i*.18,1.2,E.oc);T(id,{s:.8+q*1.2,o:(1-q)*.9})});
    $('shp').style.strokeDasharray=60;$('shp').style.strokeDashoffset=60*(1-P(lt,.3,.7,E.io));
    $('chk').style.strokeDasharray=20;$('chk').style.strokeDashoffset=20*(1-P(lt,.85,.4,E.io));
    words('s3t',lt,.8,.14,.6);
    T('s3sub',{y:(1-P(lt,1.7,.6))*40,o:P(lt,1.7,.5)});
    T('s3icon',{s:(.3+.7*p)*(1+.012*Math.sin(lt*3)),o:C(p*3),r:(1-p)*-25,y:Math.sin(lt*2)*8});tilt('s3icon',lt,.6);
  }
  // S4
  if((lt=fade('s4',t))>=0){
    T('s4n',{s:.4+.6*P(lt,0,.5,E.ob),o:P(lt,0,.3)});words('s4h',lt,.1,.07,.5);
    T('br',{y:(1-P(lt,.15,.8,E.oq))*700,o:P(lt,.15,.3),s:1});tilt('br',lt,.7);
    // phase A question page
    const toL=P(lt,2.75,.5,E.io); // tab switch
    $('tabq').className='tab'+(toL<.5?' on':'');$('tabl').className='tab'+(toL>=.5?' on':'');
    $('urltxt').textContent=toL<.5?'site-de-questoes.com.br/q/1043087':'planalto.gov.br/ccivil_03/constituicao';
    $('q4c').style.cssText=lt>.7?'':'';$('q4e').style.cssText=lt>.9?'background:#ffe3e8;border-color:#ff4d6a;color:#b4233d':'';
    T('q4res',{y:(1-P(lt,1.0,.4,E.ob))*30,o:P(lt,1.0,.3)});
    T('q4toast',{y:(1-P(lt,1.45,.6,E.oq))*300,o:P(lt,1.45,.3)});
    const click=lt>2.3&&lt<2.45;$('q4btn').style.transform=click?'scale(.94)':'scale(1)';
    if(lt>2.4){$('q4btn').textContent='Salvo ✓';$('q4btn').style.background='linear-gradient(180deg,#3fe29a,#16a870)'}else{$('q4btn').textContent='Salvar artigo';$('q4btn').style.background='linear-gradient(180deg,#8b5cf6,#6d28d9)'}
    T('pgQ',{x:-toL*980,o:1});T('pgL',{x:(1-toL)*980,o:1});
    // phase B law page
    $('hl1').style.setProperty('--hp',(P(lt,3.55,.9,E.io)*100)+'%');
    $('bd1').style.textDecoration=lt>4.35?'underline':'none';$('bd1').style.textDecorationColor='#ff4d6a';$('bd1').style.textDecorationThickness='4px';
    T('badge',{s:P(lt,4.4,.4,E.ob),o:C(P(lt,4.4,.2)*2)});
    // cursor: path
    const cp=[[0,[820,1230]],[1.5,[790,1230]],[2.25,[667,1312]],[2.45,[667,1312]],[2.8,[545,437]],[3.0,[545,437]],[3.5,[250,930]],[4.5,[700,1010]]];
    let cx=cp[0][1][0],cy=cp[0][1][1];for(let i=0;i<cp.length-1;i++){const [a,A]=cp[i],[b,B]=cp[i+1];if(lt>=a&&lt<=b){const q=E.io((lt-a)/(b-a));cx=A[0]+(B[0]-A[0])*q;cy=A[1]+(B[1]-A[1])*q}else if(lt>b){cx=B[0];cy=B[1]}}
    T('cur',{x:cx,y:cy,o:P(lt,1.2,.3),s:click?.85:1});
    T('s4cap',{y:(1-P(lt,3.9,.6))*40,o:P(lt,3.9,.4)});
  }
  // S5
  if((lt=fade('s5',t))>=0){
    T('s5n',{s:.4+.6*P(lt,0,.5,E.ob),o:P(lt,0,.3)});words('s5h',lt,.1,.07,.5);
    T('s5c1',{y:(1-P(lt,.2,.7,E.oq))*800,o:P(lt,.2,.3)});tilt('s5c1',lt,.6);
    ['j1','j2'].forEach((id,i)=>{const p=P(lt,.7+i*.22,.45,E.ob);T(id,{y:(1-p)*30,o:p,s:1})});
    document.querySelectorAll('#s5c1 .skl').forEach(s=>s.style.backgroundPosition=`${-(lt*120)%300}% 0`);
    T('s5c2',{y:(1-P(lt,1.1,.7,E.oq))*900,o:P(lt,1.1,.3)});tilt('s5c2',lt,.6,1.5);
    ['r1','r2','r3'].forEach((id,i)=>{const p=P(lt,1.7+i*.25,.45,E.ob);T(id,{x:(1-p)*120,o:p})});
    T('s5cap',{y:(1-P(lt,2.3,.6))*40,o:P(lt,2.3,.4)});
  }
  // S6
  if((lt=fade('s6',t))>=0){
    T('s6n',{s:.4+.6*P(lt,0,.5,E.ob),o:P(lt,0,.3)});words('s6h',lt,.1,.07,.5);
    T('s6pop',{y:(1-P(lt,.15,.8,E.oq))*800,o:P(lt,.15,.3)});tilt('s6pop',lt,.7);
    const prog=P(lt,.6,2.6,E.io)*.92,C0=1231.5;$('rarc').style.strokeDashoffset=C0*(1-prog);$('rarcg').style.strokeDashoffset=C0*(1-prog);
    const ang=(prog*360-90)*Math.PI/180;$('rdot').setAttribute('cx',230+196*Math.cos(ang));$('rdot').setAttribute('cy',230+196*Math.sin(ang));$('rdot').style.opacity=prog>.01?1:0;
    document.querySelectorAll('#ticks line').forEach((l,i)=>{l.style.opacity=(i/60<prog)?1:.28});
    const sec=2*3600+47*60+13+Math.floor(lt*1);const hh=Math.floor(sec/3600),mm=Math.floor(sec%3600/60),ss=sec%60;
    $('s6time').textContent=`${String(hh).padStart(2,'0')}:${String(mm).padStart(2,'0')}:${String(ss).padStart(2,'0')}`;
    $('s6pct').textContent=Math.round(prog/.92*92)+'%';$('s6bar').style.width=(prog/.92*92)+'%';
    document.querySelectorAll('#s6bars .bar').forEach((b,i)=>{b.style.transform=`scaleY(${P(lt,1.0+i*.08,.5,E.ob)})`});
    T('s6streak',{y:(1-P(lt,1.6,.6,E.ob))*-60,o:P(lt,1.6,.3),s:.8+.2*P(lt,1.6,.6,E.ob)});bob('s6streak',lt,6);
    T('fc1',{x:(1-P(lt,2.0,.6,E.ob))*-200,o:P(lt,2.0,.3),r:-5});bob('fc1',lt,10,1);
    T('fc2',{x:(1-P(lt,2.3,.6,E.ob))*200,o:P(lt,2.3,.3),r:4});bob('fc2',lt,10,3);
    T('s6cap',{y:(1-P(lt,2.0,.6))*40,o:P(lt,2.0,.4)});
  }
  // S7
  if((lt=fade('s7',t))>=0){
    T('s7n',{s:.4+.6*P(lt,0,.5,E.ob),o:P(lt,0,.3)});words('s7h',lt,.1,.07,.5);
    document.querySelectorAll('#s7grid .app').forEach((a,i)=>{const p=P(lt,.1+i*.06,.5,E.ob);const lk=P(lt,.9+i*.14,.25,E.ob);
      const wob=lt<1.9+i*.0?Math.sin(lt*22+i)*2.2*(1-lk):0;
      a.style.opacity=p;a.style.transform=`translateY(${(1-p)*80}px) rotate(${wob}deg) scale(${1-.06*lk})`;a.querySelector('.lock').style.opacity=lk;a.querySelector('.lock svg').style.transform=`scale(${.4+.6*lk})`});
    T('s7card',{y:(1-P(lt,1.4,.7,E.oq))*700,o:P(lt,1.4,.3)});tilt('s7card',lt,.6);
    const rem=4320-Math.floor(lt*60);$('s7cd').textContent=`${String(Math.floor(rem/3600)).padStart(2,'0')}:${String(Math.floor(rem%3600/60)).padStart(2,'0')}:${String(rem%60).padStart(2,'0')}`;
    T('s7cap',{y:(1-P(lt,1.9,.6))*40,o:P(lt,1.9,.4)});
  }
  // S8
  if((lt=fade('s8',t))>=0){
    T('s8n',{s:.4+.6*P(lt,0,.5,E.ob),o:P(lt,0,.3)});words('s8h',lt,.1,.07,.5);
    T('s8pop',{y:(1-P(lt,.15,.8,E.oq))*800,o:P(lt,.15,.3)});tilt('s8pop',lt,.6);
    T('u1',{x:(1-P(lt,.7,.45,E.oq))*300,o:P(lt,.7,.3)});
    T('a1',{y:(1-P(lt,1.3,.45,E.oq))*60,o:P(lt,1.3,.3)});
    const n=Math.floor(C((lt-1.6)/1.0)*TYPED.length);$('a1t').textContent=TYPED.slice(0,n);$('a1c').style.opacity=(Math.floor(lt*3)%2||n<TYPED.length)?1:0;
    T('s8chips',{y:(1-P(lt,2.55,.4,E.oq))*40,o:P(lt,2.55,.3)});
    T('s8cap',{y:(1-P(lt,1.9,.6))*40,o:P(lt,1.9,.4)});
  }
  // S9
  if((lt=fade('s9',t))>=0){
    T('s9glow',{s:.7+.5*P(lt,0,1.2),o:P(lt,0,.5)});
    T('s9icon',{s:(.4+.6*P(lt,0,.7,E.ob))*(1+.015*Math.sin(lt*4)),o:C(P(lt,0,.3)*3)});
    words('s9t',lt,.35,.1,.55);
    const pulse=1+.035*Math.sin(lt*6);T('s9btn',{y:(1-P(lt,.9,.6,E.ob))*120,o:P(lt,.9,.3),s:P(lt,.9,.6,E.ob)<1?1:pulse});const sh=((lt-1.6)%2.4)/2.4;$('s9btn').firstElementChild.style.backgroundImage=`linear-gradient(105deg,rgba(255,255,255,0) ${sh*160-40}%,rgba(255,255,255,.38) ${sh*160-25}%,rgba(255,255,255,0) ${sh*160-10}%),linear-gradient(180deg,#9f7aff,#6d28d9)`;
    T('s9sub',{y:(1-P(lt,1.2,.5))*30,o:P(lt,1.2,.4)});
  }
}


// ===================== PLAYER (tempo real) =====================
(function(){
  const stage=document.getElementById('stage');
  function fit(){const s=Math.min(innerWidth/1080,(innerHeight-70)/1920);stage.style.transform=`scale(${s}) translate(-50%,-50%)`;stage.style.left='50%';stage.style.top=`calc(50% - 22px)`;}
  addEventListener('resize',fit);fit();
  const g=document.getElementById('grain');g.style.width='1480px';g.style.height='2320px';g.style.imageRendering='pixelated';
  const marcos=[0,3.6,6.8,10,15.6,19.4,23.4,26.6,29.4];const nomes=['Gancho','Problema','Apresentação','Questão e artigo','Revisão','Cronômetro','Foco','I.A.','Começar'];
  const dots=document.getElementById('bv-dots');
  marcos.forEach((m,i)=>{const d=document.createElement('i');d.title=nomes[i];d.onclick=()=>ir(m+.02);dots.appendChild(d)});
  let t=0,pausado=false,ult=performance.now();
  function ir(x){t=Math.max(0,x);}
  function quadro(now){
    const dt=Math.min(.1,(now-ult)/1000);ult=now;
    if(!pausado) t+=dt;
    seek(t);
    let idx=0;marcos.forEach((m,i)=>{if(t>=m)idx=i});
    [...dots.children].forEach((d,i)=>d.classList.toggle('on',i===idx));
    requestAnimationFrame(quadro);
  }
  requestAnimationFrame(quadro);
  const pp=document.getElementById('bv-pp');
  pp.onclick=()=>{pausado=!pausado;pp.textContent=pausado?'Continuar':'Pausar'};
  document.getElementById('bv-rever').onclick=()=>{t=0;pausado=false;pp.textContent='Pausar'};
  addEventListener('keydown',e=>{if(e.code==='Space'){e.preventDefault();pp.click()}
    if(e.code==='ArrowRight'){const n=marcos.find(m=>m>t+.1);ir(n!=null?n+.02:marcos[8]+.02)}
    if(e.code==='ArrowLeft'){const p=[...marcos].reverse().find(m=>m<t-1);ir(p!=null?p+.02:0)}});
  function concluir(abrirPopup){
    try{chrome.storage.local.set({cbOnboardingPendente:false,cbOnboardingSeen:true,cbBoasVindasVista:true});}catch(e){}
    if(abrirPopup){try{const r=chrome.action&&chrome.action.openPopup&&chrome.action.openPopup();if(r&&r.catch)r.catch(()=>{});}catch(e){}}
    setTimeout(()=>{try{window.close()}catch(e){}},250);
  }
  document.getElementById('bv-comecar').onclick=()=>concluir(true);
  document.getElementById('bv-pular').onclick=()=>concluir(false);
})();
