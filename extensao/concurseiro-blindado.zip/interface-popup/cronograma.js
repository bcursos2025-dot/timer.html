// ===================== ORGANIZE O SEU DIA =====================
// Cronograma diário de estudo: a pessoa monta blocos (horário, forma de
// estudo, matéria) e o background.js usa esses blocos pra travar sites de
// distração automaticamente enquanto um bloco está "no ar" — mesmo com o
// popup fechado. Guardado em chrome.storage.local em 'cbCronogramaHoje',
// resetado sozinho a cada novo dia (ver dataDoCronograma abaixo).

const CRONO_TIPO_LABEL = {
    leitura: '📖 Leitura',
    video: '🎬 Vídeo-aula',
    questoes: '✅ Questões',
    revisao: '🔁 Revisão'
};

// "materia" é texto livre digitado pelo usuário e sincroniza entre
// dispositivos via Firebase (cbCronogramaHoje) — nunca interpolar sem escape.
function cronoEscapeHtml(str) {
    return String(str == null ? '' : str)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function cronogramaHojeStr() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function cronoMinutos(hhmm) {
    const [h, m] = hhmm.split(':').map(Number);
    return h * 60 + m;
}

function cronoFmtHoras(blocos) {
    const totalMin = blocos.reduce((acc, b) => acc + Math.max(0, cronoMinutos(b.fim) - cronoMinutos(b.inicio)), 0);
    const h = Math.floor(totalMin / 60);
    const m = totalMin % 60;
    if (h === 0) return `${m}min`;
    if (m === 0) return `${h}h`;
    return `${h}h${m}min`;
}

// Prévia do dia no card "Organizar meu dia" do painel inicial — só aparece
// quando tem algo marcado pra hoje; sem nada agendado, o texto continua
// exatamente como sempre foi ("Monte seu cronograma de estudos").
function atualizarPreviaOrganizarDia() {
    const sub = document.querySelector('#hn-btn-organizar .hn-widget-sub');
    if (!sub) return;
    carregarCronograma((blocos) => {
        if (!blocos.length) {
            sub.textContent = 'Monte seu cronograma de estudos';
            return;
        }
        const agora = new Date();
        const minAgora = agora.getHours() * 60 + agora.getMinutes();
        const ativo = blocos.find((b) => minAgora >= cronoMinutos(b.inicio) && minAgora < cronoMinutos(b.fim));
        if (ativo) {
            sub.textContent = `Agora: ${CRONO_TIPO_LABEL[ativo.tipo] || ativo.tipo}${ativo.materia ? ' · ' + ativo.materia : ''}`;
            return;
        }
        const proximo = blocos.find((b) => cronoMinutos(b.inicio) > minAgora);
        if (proximo) {
            sub.textContent = `Próximo: ${proximo.inicio} · ${CRONO_TIPO_LABEL[proximo.tipo] || proximo.tipo}`;
        } else {
            sub.textContent = `${blocos.length} bloco${blocos.length === 1 ? '' : 's'} hoje · ${cronoFmtHoras(blocos)}`;
        }
    });
}

function carregarCronograma(callback) {
    chrome.storage.local.get(['cbCronogramaHoje', 'cbCronogramaData'], (res) => {
        const hoje = cronogramaHojeStr();
        if (res.cbCronogramaData !== hoje) {
            // Virou o dia: começa uma lista nova, sem apagar histórico de outros dias.
            chrome.storage.local.set({ cbCronogramaHoje: [], cbCronogramaData: hoje });
            callback([]);
        } else {
            callback(res.cbCronogramaHoje || []);
        }
    });
}

function salvarCronograma(blocos) {
    blocos.sort((a, b) => cronoMinutos(a.inicio) - cronoMinutos(b.inicio));
    chrome.storage.local.set({ cbCronogramaHoje: blocos, cbCronogramaData: cronogramaHojeStr() });
    // Avisa o background pra recalcular o bloco ativo já, sem esperar o próximo alarme.
    chrome.runtime.sendMessage({ action: 'cronogramaAtualizado' }).catch(() => {});
}

function renderCronograma() {
    const lista = document.getElementById('cronograma-lista');
    const status = document.getElementById('cronograma-status');
    if (!lista) return;

    carregarCronograma((blocos) => {
        if (!blocos.length) {
            lista.innerHTML = '<div class="cronograma-vazio">Nenhum bloco pra hoje ainda. Monte seu dia abaixo.</div>';
            if (status) status.textContent = '—';
            return;
        }

        const agora = new Date();
        const minAgora = agora.getHours() * 60 + agora.getMinutes();
        let ativo = null;

        lista.innerHTML = blocos.map((b) => {
            const ini = cronoMinutos(b.inicio);
            const fim = cronoMinutos(b.fim);
            const estaAtivo = minAgora >= ini && minAgora < fim;
            const jaPassou = minAgora >= fim;
            if (estaAtivo) ativo = b;
            return `
                <div class="cronograma-item ${estaAtivo ? 'is-ativo' : ''} ${jaPassou ? 'is-feito' : ''}" data-id="${b.id}">
                    <span class="cronograma-item-hora">${b.inicio}–${b.fim}</span>
                    <span class="cronograma-item-info">
                        <strong>${cronoEscapeHtml(CRONO_TIPO_LABEL[b.tipo] || b.tipo)}</strong>
                        ${b.materia ? `<span class="crono-materia">${cronoEscapeHtml(b.materia)}</span>` : ''}
                    </span>
                    <button class="cronograma-item-del" data-del="${b.id}" title="Remover">✕</button>
                </div>`;
        }).join('');

        if (status) {
            status.textContent = ativo
                ? `Agora: ${CRONO_TIPO_LABEL[ativo.tipo] || ativo.tipo}`
                : `Hoje: ${cronoFmtHoras(blocos)}`;
        }

        lista.querySelectorAll('[data-del]').forEach((btn) => {
            btn.addEventListener('click', () => {
                carregarCronograma((atual) => {
                    const restante = atual.filter((b) => b.id !== btn.dataset.del);
                    salvarCronograma(restante);
                    renderCronograma();
                });
            });
        });
    });
}

function initCronogramaUI() {
    const lista = document.getElementById('cronograma-lista');

    const btnAdd = document.getElementById('btn-crono-add');
    if (btnAdd) {
        btnAdd.addEventListener('click', () => {
            const inicio = document.getElementById('crono-inicio').value;
            const fim = document.getElementById('crono-fim').value;
            const tipo = document.getElementById('crono-tipo').value;
            const materiaEl = document.getElementById('crono-materia');
            const materia = materiaEl.value.trim();

            if (!inicio || !fim || cronoMinutos(fim) <= cronoMinutos(inicio)) {
                showToast?.('O horário de fim precisa ser depois do início.') ?? alert('O horário de fim precisa ser depois do início.');
                return;
            }

            carregarCronograma((blocos) => {
                const novoBloco = {
                    id: `crono_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
                    inicio, fim, tipo, materia
                };
                const sobrepoe = blocos.some((b) => cronoMinutos(inicio) < cronoMinutos(b.fim) && cronoMinutos(fim) > cronoMinutos(b.inicio));
                if (sobrepoe && !confirm('Esse horário sobrepõe outro bloco já criado. Adicionar mesmo assim?')) return;

                blocos.push(novoBloco);
                salvarCronograma(blocos);
                materiaEl.value = '';
                renderCronograma();
            });
        });
    }

    // Bloco discreto: recolhido por padrão, lembra a preferência do usuário
    const cronoBlock = document.getElementById('cronograma-block');
    const cronoToggle = document.getElementById('cronograma-toggle');
    if (cronoBlock && cronoToggle) {
        chrome.storage.local.get(['cronogramaAberto'], (r) => {
            if (r.cronogramaAberto) cronoBlock.classList.add('is-open');
        });
        cronoToggle.addEventListener('click', () => {
            const aberto = cronoBlock.classList.toggle('is-open');
            chrome.storage.local.set({ cronogramaAberto: aberto });
        });
    }

    // Ícone único ao lado de "Editar meta diária" que abre a organização
    // completa do cronograma em uma aba cheia.
    const btnAbrirRotina = document.getElementById('btn-abrir-rotina');
    if (btnAbrirRotina) {
        btnAbrirRotina.addEventListener('click', () => {
            chrome.tabs.create({ url: chrome.runtime.getURL('rotina/rotina-diaria.html') });
        });
    }

    // Widget "Organizar meu dia" no painel inicial — mesma ação do ícone
    // de calendário ao lado de "Editar meta diária".
    const btnOrganizarWidget = document.getElementById('hn-btn-organizar');
    if (btnOrganizarWidget) {
        btnOrganizarWidget.addEventListener('click', () => {
            chrome.tabs.create({ url: chrome.runtime.getURL('rotina/rotina-diaria.html') });
        });
    }

    document.getElementById('cronograma-permissao-aviso')?.remove();

    if (lista) {
        renderCronograma();
        setInterval(renderCronograma, 30 * 1000);
    }
    atualizarPreviaOrganizarDia();
    setInterval(atualizarPreviaOrganizarDia, 30 * 1000);
}

document.addEventListener('DOMContentLoaded', () => {
    initCronogramaUI();
    initAlarmeUI();
});

// ===================== ALARME DE INÍCIO =====================
function initAlarmeUI() {
    const toggle = document.getElementById('alarme-toggle');
    const aviso = document.getElementById('alarme-pendente-aviso');
    if (!toggle) return;

    function refletirEstado() {
        chrome.runtime.sendMessage({ action: 'cbAlarmeGetEstado' }, (res) => {
            if (!res) return;
            toggle.checked = res.ativo;
            if (res.pendente) {
                const dataEfetiva = new Date(res.pendente.efetivoEm);
                aviso.style.display = 'block';
                aviso.textContent = `Pedido de desligar o alarme registrado. Só some às ${dataEfetiva.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })} de ${dataEfetiva.toLocaleDateString('pt-BR')}.`;
            } else {
                aviso.style.display = 'none';
            }
        });
    }

    toggle.addEventListener('change', () => {
        chrome.runtime.sendMessage({ action: 'cbAlarmeSetEstado', ativo: toggle.checked }, () => refletirEstado());
    });

    refletirEstado();
}

