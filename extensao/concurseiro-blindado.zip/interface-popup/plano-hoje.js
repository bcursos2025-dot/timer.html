// ===================== PLANO DE HOJE (mini tabela abaixo do cronômetro) =====================
//
// Mostra o que o plano de estudos (criado a partir do edital, ver plano/plano.js)
// propõe para HOJE. Para cada item a pessoa pode:
//   • marcar se estudou;
//   • lançar acertos e erros À MÃO (de qualquer plataforma — não depende do QConcursos);
//   • ver/ajustar o tempo estudado na matéria;
//   • tocar em ▶ para "estudar esta matéria agora": o cronômetro geral continua
//     como sempre, mas o tempo passa a ser somado TAMBÉM nesta matéria
//     (quem soma é o background.js, enquanto o cronômetro está rodando).
//
// Chaves em chrome.storage.local (detalhes no cabeçalho de plano/plano-core.js):
//   planoEstudo, planoRegistros (escrito aqui e na página do plano),
//   planoTempo (escrito SÓ pelo background), planoItemAtivo (escrito aqui).

(function () {
    'use strict';
    const C = window.CBPlano;
    const card = document.getElementById('plano-hoje-card');
    if (!C || !card) return;

    const corpo = document.getElementById('ph-corpo');
    const meta = document.getElementById('ph-meta');
    const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

    const E = { plano: null, registros: {}, tempos: {}, ativo: null, sessao: 'stopped' };

    function abrirPlano(hash) {
        chrome.tabs.create({ url: chrome.runtime.getURL('plano/plano.html' + (hash || '')) });
    }

    // Fila: duas mudanças seguidas (marcar e digitar) não podem se atropelar no storage.
    let fila = Promise.resolve();
    function salvarRegistro(id, patch) {
        fila = fila.then(() => new Promise((resolve) => {
            chrome.storage.local.get(['planoRegistros'], (r) => {
                const atual = r.planoRegistros || {};
                atual[id] = { ...(atual[id] || {}), ...patch };
                E.registros = atual;
                chrome.storage.local.set({ planoRegistros: atual }, resolve);
            });
        }));
        return fila;
    }

    function minutosDoItem(id) {
        return Math.round(C.tempoDoItemMs(id, E.registros, E.tempos) / 60000);
    }
    function relogioAtivo(id) {
        const ms = C.tempoDoItemMs(id, E.registros, E.tempos);
        const s = Math.floor(ms / 1000);
        const mm = Math.floor(s / 60), ss = s % 60;
        return `${mm}:${String(ss).padStart(2, '0')}`;
    }
    const ehAtivo = (id) => !!(E.ativo && E.ativo.id === id && E.ativo.dia === C.hojeStr());

    // ---------------------------------------------------------------- render
    function render() {
        const p = E.plano;
        if (!p) {
            meta.textContent = '';
            // Mesmo botão do "Iniciar Estudo" (.btn.play): a cor segue o tema.
            corpo.innerHTML = `
                <div class="ph-vazio">
                    <p>Anexe o edital e a IA monta o seu cronograma.</p>
                    <button type="button" class="btn play" data-ph="novo">Criar plano</button>
                </div>`;
            return;
        }
        const hoje = C.hojeStr();
        const dia = C.diaDoPlano(p, hoje);
        const total = p.dias.length;
        const idx = p.dias.findIndex((d) => d.data === hoje);
        const atrasados = C.itensPendentesAtrasados(p, E.registros, hoje).filter((i) => i.tipo === 'estudo').length;
        let rodape = `<div class="ph-rodape">
            ${atrasados ? `<button type="button" class="ph-aviso" data-ph="atrasados" title="Há itens de dias anteriores sem marcar. Abra o plano para reorganizar.">${atrasados} pendente${atrasados === 1 ? '' : 's'}</button>` : '<span></span>'}
            <button type="button" class="ph-link" data-ph="plano">Ver plano ↗</button>
        </div>`;

        if (!dia) {
            const ultimo = p.dias.length ? p.dias[p.dias.length - 1].data : hoje;
            meta.textContent = '';
            let msg;
            if (hoje < p.inicio) msg = `Seu plano começa em <strong>${C.fmtBR(p.inicio)}</strong>.`;
            else if (hoje > ultimo) msg = 'O período do plano terminou. Abra o plano completo para ver o resultado ou criar um novo.';
            else msg = 'Hoje é um dia livre no seu plano.';
            corpo.innerHTML = `<p class="ph-msg">${msg}</p>${rodape}`;
            return;
        }

        const [, rotFase] = (function () {
            if (dia.fase === 'prova') return [0, 'Dia da prova'];
            if (dia.fase === 'revisao') return [0, 'Fase 2 · Revisão'];
            if (dia.rotulo === 'Revisão da semana') return [0, 'Revisão da semana'];
            return [0, 'Fase 1 · Estudo'];
        })();
        meta.textContent = `Dia ${idx + 1} de ${total} · ${rotFase}`;

        if (dia.fase === 'prova') {
            corpo.innerHTML = `<p class="ph-msg"><strong>Hoje é a prova.</strong> ${esc(dia.itens[0] ? dia.itens[0].topico : '')}</p>${rodape}`;
            return;
        }

        const itens = dia.itens;
        const feitos = itens.filter((i) => E.registros[i.id] && E.registros[i.id].feito).length;
        const tempoDia = itens.reduce((s, i) => s + C.tempoDoItemMs(i.id, E.registros, E.tempos), 0);
        const rodando = E.sessao === 'running';

        const linhas = itens.map((it) => {
            const r = E.registros[it.id] || {};
            const mat = p.materias.find((m) => m.id === it.materiaId);
            const cor = mat ? mat.cor : 'var(--text-faint)';
            const ativo = ehAtivo(it.id);
            const sub = [it.topico];
            if (it.partes > 1) sub.push(`parte ${it.parte}/${it.partes}`);
            const tempo = ativo && rodando
                ? `<span class="ph-live" data-live="${esc(it.id)}">${relogioAtivo(it.id)}</span>`
                : `<input class="ph-n ph-n--min" type="number" min="0" step="1" data-c="min" value="${minutosDoItem(it.id)}" title="Minutos estudados (você pode ajustar)" aria-label="Minutos estudados">`;
            return `<div class="ph-linha${r.feito ? ' is-feito' : ''}${ativo ? ' is-ativa' : ''}" data-id="${esc(it.id)}">
                <label class="ph-chk" title="Marcar como estudado">
                    <input type="checkbox" data-c="feito" ${r.feito ? 'checked' : ''} aria-label="Estudei">
                    <span class="ph-chk-box"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg></span>
                </label>
                <div class="ph-info">
                    <strong title="${esc(it.materia)}"><span class="ph-bolinha" style="background:${cor}"></span>${esc(it.materia)}</strong>
                    <span title="${esc(it.detalhe || it.topico)}">${esc(sub.join(' · '))} · ${esc(C.fmtMin(it.min))}</span>
                </div>
                <div class="ph-tempo">${tempo}</div>
                <input class="ph-n" type="number" min="0" step="1" data-c="acertos" value="${r.acertos == null ? '' : r.acertos}" placeholder="0" title="Acertos (de qualquer plataforma)" aria-label="Acertos">
                <input class="ph-n" type="number" min="0" step="1" data-c="erros" value="${r.erros == null ? '' : r.erros}" placeholder="0" title="Erros (de qualquer plataforma)" aria-label="Erros">
                <button type="button" class="ph-play${ativo ? ' is-ativo' : ''}" data-c="play" title="${ativo ? 'Parar de contar nesta matéria' : 'Estudar esta matéria agora (o cronômetro soma o tempo nela)'}" aria-label="${ativo ? 'Parar' : 'Estudar agora'}">${ativo
                    ? '<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/></svg>'
                    : '<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M8 5v14l11-7z"/></svg>'}</button>
            </div>`;
        }).join('');

        corpo.innerHTML = `
            <div class="ph-cabecalho" aria-hidden="true"><span></span><span></span><span>Min</span><span>Acertos</span><span>Erros</span><span></span></div>
            <div class="ph-lista">${linhas}</div>
            <div class="ph-resumo"><span>${feitos}/${itens.length} feitos</span><span data-tempo-dia>${esc(C.fmtMin(tempoDia / 60000))}</span></div>
            ${rodape}`;
    }

    // Atualiza só os números que mudam a cada segundo, sem recriar a lista (senão o
    // campo que a pessoa está digitando perderia o foco).
    function atualizarAoVivo() {
        corpo.querySelectorAll('[data-live]').forEach((el) => { el.textContent = relogioAtivo(el.dataset.live); });
        corpo.querySelectorAll('.ph-linha').forEach((linha) => {
            const campo = linha.querySelector('[data-c="min"]');
            if (campo && campo !== document.activeElement) campo.value = minutosDoItem(linha.dataset.id);
        });
        const resumo = corpo.querySelector('[data-tempo-dia]');
        const dia = E.plano && C.diaDoPlano(E.plano, C.hojeStr());
        if (resumo && dia) resumo.textContent = C.fmtMin(dia.itens.reduce((s, i) => s + C.tempoDoItemMs(i.id, E.registros, E.tempos), 0) / 60000);
    }

    // ---------------------------------------------------------------- eventos
    function alternarAtivo(it) {
        const hoje = C.hojeStr();
        if (ehAtivo(it.id)) {
            chrome.storage.local.set({ planoItemAtivo: null });
            return;
        }
        chrome.storage.local.set({ planoItemAtivo: { id: it.id, materiaId: it.materiaId, dia: hoje } }, () => {
            // Se o cronômetro não está rodando, liga com o mesmo botão de sempre
            // (ele cuida de modo, permissões e animação).
            if (E.sessao !== 'running') {
                const play = document.getElementById('btn-play');
                if (play) play.click();
            }
        });
    }

    card.addEventListener('click', (e) => {
        const acao = e.target.closest('[data-ph]');
        if (acao) {
            const a = acao.dataset.ph;
            if (a === 'novo') abrirPlano('#novo');
            else abrirPlano('');
            return;
        }
        const play = e.target.closest('[data-c="play"]');
        if (play) {
            const id = play.closest('.ph-linha').dataset.id;
            const dia = C.diaDoPlano(E.plano, C.hojeStr());
            const it = dia && dia.itens.find((x) => x.id === id);
            if (it) alternarAtivo(it);
        }
    });
    document.getElementById('ph-abrir').addEventListener('click', () => abrirPlano(''));

    card.addEventListener('change', (e) => {
        const el = e.target;
        const campo = el.dataset && el.dataset.c;
        const linha = el.closest('.ph-linha');
        if (!campo || !linha) return;
        const id = linha.dataset.id;
        if (campo === 'feito') {
            linha.classList.toggle('is-feito', el.checked);
            salvarRegistro(id, { feito: el.checked }).then(() => {
                // Terminou a matéria: para de contar o tempo nela.
                if (el.checked && ehAtivo(id)) chrome.storage.local.set({ planoItemAtivo: null });
                else render();
            });
            return;
        }
        const v = el.value === '' ? null : Math.max(0, Math.floor(+el.value) || 0);
        if (campo === 'min') {
            const auto = Math.round(((E.tempos[id]) || 0) / 60000);
            salvarRegistro(id, { ajusteMin: (v == null ? 0 : v) - auto }).then(atualizarAoVivo);
        } else {
            salvarRegistro(id, { [campo]: v });
        }
    });

    // ---------------------------------------------------------------- dados
    function carregar() {
        chrome.storage.local.get(['planoEstudo', 'planoRegistros', 'planoTempo', 'planoItemAtivo', 'sessionState'], (r) => {
            E.plano = r.planoEstudo || null;
            E.registros = r.planoRegistros || {};
            E.tempos = r.planoTempo || {};
            E.ativo = r.planoItemAtivo || null;
            E.sessao = r.sessionState || 'stopped';
            // Virou o dia: o item "ativo" de ontem não vale mais.
            if (E.ativo && E.ativo.dia !== C.hojeStr()) { E.ativo = null; chrome.storage.local.set({ planoItemAtivo: null }); }
            render();
        });
    }

    chrome.storage.onChanged.addListener((ch, area) => {
        if (area !== 'local') return;
        if (ch.planoEstudo || ch.planoItemAtivo || ch.sessionState) {
            if (ch.planoEstudo) E.plano = ch.planoEstudo.newValue || null;
            if (ch.planoItemAtivo) E.ativo = ch.planoItemAtivo.newValue || null;
            if (ch.sessionState) E.sessao = ch.sessionState.newValue || 'stopped';
            if (ch.planoRegistros) E.registros = ch.planoRegistros.newValue || {};
            if (ch.planoTempo) E.tempos = ch.planoTempo.newValue || {};
            render();
            return;
        }
        if (ch.planoRegistros) E.registros = ch.planoRegistros.newValue || {};
        if (ch.planoTempo) E.tempos = ch.planoTempo.newValue || {};
        if (ch.planoTempo || ch.planoRegistros) {
            // O foco está num campo desta tabela? Só atualiza números; senão redesenha.
            if (corpo.contains(document.activeElement) && document.activeElement.tagName === 'INPUT') atualizarAoVivo();
            else if (ch.planoRegistros && !ch.planoTempo) render();
            else atualizarAoVivo();
        }
    });

    carregar();
})();
