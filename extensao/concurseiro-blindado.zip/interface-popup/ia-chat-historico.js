// ===================== HISTÓRICO DE CONVERSAS DO CHAT DE IA =====================
//
// Cada conversa que a pessoa tem com o Assistente de IA fica salva
// localmente via chrome.storage.local (nunca enviada a lugar nenhum) — ver
// cbSalvarConversaAtual em interface-popup/ia-chat.js, que é quem de fato
// grava/recarrega o estado da conversa, porque é ele que tem acesso às
// bolhas e ao histórico em memória. Este arquivo cuida só da telinha que
// lista, busca, abre e apaga essas conversas (window.cbChat* expostos por ele).
//
// BUSCA: o texto digitado procura em TODAS as mensagens da conversa (perguntas e respostas), sem
// ligar para maiúsculas nem acentos. Com várias palavras, a conversa precisa ter todas (em qualquer
// mensagem). Quando o trecho achado não está na primeira pergunta, a linha mostra o trecho com a
// palavra destacada, para a pessoa reconhecer a conversa.

(function () {
    const btnAbrir = document.getElementById('ia-chat-abrir-historico');
    const overlay = document.getElementById('ia-historico-modal-overlay');
    const btnFechar = document.getElementById('ia-historico-modal-close');
    const elLista = document.getElementById('ia-historico-lista');
    const elVazio = document.getElementById('ia-historico-vazio');
    const btnLimpar = document.getElementById('ia-historico-limpar-btn');
    const elBuscaWrap = document.getElementById('ia-historico-busca-wrap');
    const elBusca = document.getElementById('ia-historico-busca');
    const btnBuscaLimpar = document.getElementById('ia-historico-busca-limpar');
    const elContagem = document.getElementById('ia-historico-contagem');
    if (!overlay || !btnAbrir) return;

    const TEXTO_VAZIO_PADRAO = elVazio ? elVazio.textContent : '';

    // ------------------------------------------------------------------ texto
    // A lógica da busca (normalizar, achar, trecho com destaque) vive em historico-busca.js, que tem testes.
    const Busca = window.CBHistoricoBusca;
    const esc = Busca.esc;
    const normalizar = Busca.normalizar;
    const palavrasDaBusca = Busca.palavrasDaBusca;
    const trechoHtml = Busca.trechoHtml;

    // ------------------------------------------------------------------ tela
    function abrirModal() {
        overlay.classList.add('open');
        if (elBusca) elBusca.value = '';   // reabrir a folha começa sem filtro
        renderLista();
    }
    function fecharModal() {
        overlay.classList.remove('open');
    }

    function formatarQuando(ts) {
        try {
            const d = new Date(ts);
            const hoje = new Date();
            const mesmoDia = d.toDateString() === hoje.toDateString();
            const hora = d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
            return mesmoDia ? `Hoje, ${hora}` : `${d.toLocaleDateString('pt-BR')}, ${hora}`;
        } catch (e) { return ''; }
    }

    function primeiraPergunta(conversa) {
        const m = (conversa.mensagens || []).find((msg) => msg.role === 'user');
        if (!m) return '(sem pergunta)';
        const texto = String(m.content || '').trim();
        return texto.length > 70 ? `${texto.slice(0, 70)}…` : texto;
    }

    async function renderLista() {
        if (typeof window.cbChatListarHistorico !== 'function') return;
        const todas = await window.cbChatListarHistorico();
        const termo = elBusca ? elBusca.value.trim() : '';
        const palavras = palavrasDaBusca(termo);
        const buscando = palavras.length > 0;

        // a busca só existe quando há o que buscar
        if (elBuscaWrap) elBuscaWrap.hidden = todas.length === 0;
        if (btnBuscaLimpar) btnBuscaLimpar.hidden = !elBusca || elBusca.value === '';

        const itens = Busca.filtrar(todas, termo);

        elLista.innerHTML = '';
        const temItens = itens.length > 0;
        elVazio.style.display = temItens ? 'none' : '';
        elVazio.textContent = buscando && todas.length > 0
            ? `Nenhuma conversa encontrada para “${termo}”.`
            : TEXTO_VAZIO_PADRAO;
        // "Limpar histórico" apaga TUDO: some enquanto há um filtro, para não parecer que apaga só o resultado
        btnLimpar.style.display = todas.length > 0 && !buscando ? '' : 'none';
        if (elContagem) {
            elContagem.hidden = !(buscando && temItens);
            elContagem.textContent = `${itens.length} ${itens.length === 1 ? 'conversa encontrada' : 'conversas encontradas'}`;
        }

        itens.forEach(({ conversa, trecho }) => {
            const item = document.createElement('button');
            item.type = 'button';
            item.className = 'ia-historico-item';

            const pergunta = primeiraPergunta(conversa);
            // o trecho só aparece quando a palavra NÃO está na pergunta que já é o título da linha
            const mostrarTrecho = buscando && trecho && !normalizar(pergunta).includes(normalizar(palavrasDaBusca(termo)[0]));

            const texto = document.createElement('span');
            texto.className = 'ia-historico-item-texto';
            texto.innerHTML = `<b>${esc(pergunta)}</b>`
                + (mostrarTrecho ? `<span class="iah-trecho">${trechoHtml(trecho)}</span>` : '')
                + `<small>${formatarQuando(conversa.atualizadoEm)} · ${(conversa.mensagens || []).length} mensagens</small>`;

            const btnRemover = document.createElement('span');
            btnRemover.className = 'ia-historico-item-remover';
            btnRemover.title = 'Apagar esta conversa';
            btnRemover.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>';
            btnRemover.addEventListener('click', async (e) => {
                e.stopPropagation();
                await window.cbChatApagarConversa(conversa.id);
                renderLista();
            });

            item.appendChild(texto);
            item.appendChild(btnRemover);
            item.addEventListener('click', async () => {
                if (typeof window.cbChatCarregarConversa === 'function') {
                    await window.cbChatCarregarConversa(conversa.id);
                }
                fecharModal();
            });
            elLista.appendChild(item);
        });
    }

    btnAbrir.addEventListener('click', abrirModal);
    btnFechar.addEventListener('click', fecharModal);
    overlay.addEventListener('click', (e) => { if (e.target === overlay) fecharModal(); });
    btnLimpar.addEventListener('click', async () => {
        if (!confirm('Apagar todo o histórico de conversas? Isso não pode ser desfeito.')) return;
        await window.cbChatLimparHistorico();
        renderLista();
    });

    if (elBusca) {
        elBusca.addEventListener('input', renderLista);
        elBusca.addEventListener('keydown', (e) => {
            // Esc limpa a busca (e só fecha a folha se já estiver vazia)
            if (e.key === 'Escape' && elBusca.value) { e.stopPropagation(); elBusca.value = ''; renderLista(); }
        });
    }
    if (btnBuscaLimpar) {
        btnBuscaLimpar.addEventListener('click', () => {
            elBusca.value = '';
            renderLista();
            elBusca.focus();
        });
    }
})();
