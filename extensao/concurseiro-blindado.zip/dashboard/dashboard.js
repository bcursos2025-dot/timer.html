document.addEventListener('DOMContentLoaded', () => {
    const frame = document.getElementById('dash-frame');
    const frameWrap = document.getElementById('dash-frame-wrap');
    const zoomInput = document.getElementById('dash-zoom');

    // ===================== TEMA =====================
    // O dashboard.html usa o mesmo popup.html dentro do iframe (mesma origem,
    // faz parte da mesma extensão), então o popup.js já aplica o tema salvo
    // dentro do próprio iframe automaticamente. Aqui só espelhamos o tema
    // na página externa (topbar/fundo) para tudo ficar coerente.
    // "Automático" (ver popup.js/applyTheme) não é um tema de verdade — é
    // Claro de dia e Escuro à noite (18h–6h), mesmo corte usado no resto do
    // app. themePref guarda "auto" literal; quem exibe a página precisa
    // resolver pro tema real antes de aplicar no data-theme.
    let temaPrefDashboard = 'dark';
    function cbResolverTemaAuto(pref) {
        if (pref !== 'auto') return pref;
        const hora = new Date().getHours();
        return (hora >= 18 || hora < 6) ? 'dark' : 'light';
    }
    function aplicarTemaExterno(theme) {
        temaPrefDashboard = theme;
        document.documentElement.setAttribute('data-theme', cbResolverTemaAuto(theme));
    }
    // Enquanto a aba do dashboard ficar aberta com "Automático" selecionado,
    // reavalia a cada poucos minutos — sem isso só trocaria de tema na
    // próxima vez que a página fosse recarregada depois da virada.
    setInterval(() => {
        if (temaPrefDashboard === 'auto') aplicarTemaExterno('auto');
    }, 5 * 60 * 1000);
    // Local primeiro (mais confiável entre navegadores), sync como reforço.
    chrome.storage.local.get(['themePref'], (localResult) => {
        if (localResult.themePref) {
            aplicarTemaExterno(localResult.themePref);
        } else {
            chrome.storage.sync.get(['themePref'], (result) => {
                aplicarTemaExterno(result.themePref || 'dark');
            });
        }
    });
    chrome.storage.onChanged.addListener((changes, area) => {
        if ((area === 'sync' || area === 'local') && changes.themePref) {
            aplicarTemaExterno(changes.themePref.newValue || 'dark');
        }
    });

    // ===================== ZOOM =====================
    function aplicarZoom(valor) {
        // `zoom` em vez de `transform: scale()` — ver comentário em
        // dashboard.css sobre por que isso evita o corte do card à direita.
        frameWrap.style.zoom = valor;
    }
    zoomInput.addEventListener('input', () => aplicarZoom(zoomInput.value));
    aplicarZoom(zoomInput.value);

    // ===================== ALTURA DINÂMICA DO IFRAME =====================
    // O popup.html não tem altura fixa (o Chrome que limita isso quando é
    // popup de verdade); aqui, como é uma aba normal, medimos o conteúdo
    // real dentro do iframe e ajustamos a altura para não cortar nada,
    // mesmo quando o usuário troca de aba/abre modais lá dentro.
    let resizeObserver = null;
    // Guarda a última altura aplicada pra só tocar no iframe quando o
    // conteúdo realmente mudou de tamanho. Sem isso, a checagem a cada
    // 2s (e o ResizeObserver, que dispara por qualquer arredondamento
    // sub-pixel do zoom) reescrevia `frame.style.height` o tempo todo
    // mesmo sem mudança real — e isso é o que piscava a tela.
    let ultimaAltura = 0;

    function medirEAjustarAltura() {
        try {
            const doc = frame.contentDocument;
            if (!doc || !doc.body) return;
            const altura = Math.max(doc.documentElement.scrollHeight, doc.body.scrollHeight);
            if (Math.abs(altura - ultimaAltura) < 2) return;
            ultimaAltura = altura;
            frame.style.height = altura + 'px';
        } catch (e) {
            // Se por algum motivo não der pra acessar o documento do iframe,
            // cai num fallback de altura generosa em vez de travar.
            if (ultimaAltura !== 760) {
                ultimaAltura = 760;
                frame.style.height = '760px';
            }
        }
    }

    frame.addEventListener('load', () => {
        medirEAjustarAltura();

        try {
            const doc = frame.contentDocument;
            if (window.ResizeObserver && doc && doc.body) {
                if (resizeObserver) resizeObserver.disconnect();
                resizeObserver = new ResizeObserver(() => medirEAjustarAltura());
                resizeObserver.observe(doc.body);
            }
        } catch (e) {
            // ambiente sem acesso ao contentDocument — segue só com o polling abaixo
        }
    });

    // Rede de segurança: mesmo sem ResizeObserver funcionando (ex: alguma
    // extensão de terceiros interferindo), reavalia a altura periodicamente
    // enquanto esta aba de dashboard ficar aberta.
    setInterval(medirEAjustarAltura, 2000);

    window.addEventListener('resize', medirEAjustarAltura);
});
