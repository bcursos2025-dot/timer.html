// Armazena os blocos por data em cbCronogramaPorData: { "AAAA-MM-DD": [blocos] }.
// Migra automaticamente o formato antigo (cbCronogramaHoje/cbCronogramaData), então
// nada se perde. O bloqueio de distrações e o popup continuam lendo o dia de hoje
// a partir dessa mesma estrutura (veja a sincronização em salvarBlocosDoDia).
// CORREÇÃO: antes começava às 6h (HORA_INICIO = 6), cortando fora qualquer
// bloco de madrugada/manhã cedo — agora mostra o dia inteiro, de meia-noite
// até meia-noite.
const HORA_INICIO = 0, HORA_FIM = 24, ALTURA_HORA = 72;
const CAT_COR = {trabalho:'var(--trabalho)',academia:'var(--academia)',leitura:'var(--leitura)',hobby:'var(--hobby)',outro:'var(--outro)'};
const CAT_LABEL = {trabalho:'Trabalho',academia:'Academia',leitura:'Leitura',hobby:'Hobby',outro:'Outro'};
const PRIO_LABEL = {alta:'Alta prioridade',media:'Média prioridade',baixa:'Baixa prioridade'};
const DOW = ['dom','seg','ter','qua','qui','sex','sáb'];
const MESES = ['janeiro','fevereiro','março','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro'];

let blocos = [];
let catSelecionada = 'trabalho';
let prioSelecionada = 'alta';
let dataSelecionada = hojeStr();      // "AAAA-MM-DD" do dia visível na timeline
let popMonthCursor = new Date();       // mês exibido no calendário popover
let diasComBloco = new Set();          // datas com pelo menos um bloco (para os pontinhos)
let avisosDisparados = new Set();      // ids de bloco cujo aviso sonoro já tocou hoje

function minutos(hhmm){ const [h,m] = hhmm.split(':').map(Number); return h*60+m; }
function pad(n){ return String(n).padStart(2,'0'); }
function toDateStr(d){ return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`; }

/* ---------------- feriados nacionais ---------------- */
// Calculados localmente (sem API), então funcionam offline e pra qualquer
// ano. Datas móveis (Carnaval, Sexta-feira Santa, Páscoa, Corpus Christi)
// usam o algoritmo de Gauss pra achar o domingo de Páscoa daquele ano.
function calcularPascoa(ano){
  const a = ano % 19, b = Math.floor(ano/100), c = ano % 100;
  const d = Math.floor(b/4), e = b % 4;
  const f = Math.floor((b+8)/25);
  const g = Math.floor((b-f+1)/3);
  const h = (19*a + b - d - g + 15) % 30;
  const i = Math.floor(c/4), k = c % 4;
  const l = (32 + 2*e + 2*i - h - k) % 7;
  const m = Math.floor((a + 11*h + 22*l)/451);
  const mes = Math.floor((h + l - 7*m + 114)/31);
  const dia = ((h + l - 7*m + 114) % 31) + 1;
  return new Date(ano, mes-1, dia);
}
const FERIADOS_CACHE = {};
function feriadosDoAno(ano){
  if (FERIADOS_CACHE[ano]) return FERIADOS_CACHE[ano];
  const pascoa = calcularPascoa(ano);
  const comOffset = (n)=>{ const d = new Date(pascoa); d.setDate(d.getDate()+n); return d; };
  const lista = [
    [new Date(ano,0,1), 'Confraternização Universal'],
    [comOffset(-47), 'Carnaval'],
    [comOffset(-46), 'Carnaval'],
    [comOffset(-2), 'Sexta-feira Santa'],
    [pascoa, 'Páscoa'],
    [new Date(ano,3,21), 'Tiradentes'],
    [new Date(ano,4,1), 'Dia do Trabalho'],
    [comOffset(60), 'Corpus Christi'],
    [new Date(ano,8,7), 'Independência do Brasil'],
    [new Date(ano,9,12), 'Nossa Senhora Aparecida'],
    [new Date(ano,10,2), 'Finados'],
    [new Date(ano,10,15), 'Proclamação da República'],
    [new Date(ano,10,20), 'Consciência Negra'],
    [new Date(ano,11,25), 'Natal']
  ];
  const mapa = {};
  lista.forEach(([d, nome])=>{ mapa[toDateStr(d)] = nome; });
  FERIADOS_CACHE[ano] = mapa;
  return mapa;
}
function nomeFeriado(ds){
  const ano = Number(ds.slice(0,4));
  return feriadosDoAno(ano)[ds] || null;
}
function fromDateStr(s){ const [y,m,d] = s.split('-').map(Number); return new Date(y, m-1, d); }
function hojeStr(){ return toDateStr(new Date()); }
function addDias(dateStr, n){ const d = fromDateStr(dateStr); d.setDate(d.getDate()+n); return toDateStr(d); }

/* ---------------- storage ---------------- */

// IMPORTANTE: o popup (interface-popup/cronograma.js) e o widget antigo
// (rotina/rotina.js) continuam gravando SOMENTE em cbCronogramaHoje/
// cbCronogramaData — eles não conhecem cbCronogramaPorData. Para os dois
// sistemas nunca ficarem dessincronizados, toda leitura aqui sobrepõe a
// entrada de HOJE em cbCronogramaPorData com o conteúdo atual de
// cbCronogramaHoje (quando cbCronogramaData é o dia de hoje). Assim, não
// importa por qual tela o bloco foi criado — o calendário sempre reflete
// a fonte mais recente para o dia de hoje, e os outros dias (que só esta
// tela consegue criar) ficam guardados normalmente em cbCronogramaPorData.
function carregarTudo(callback){
  chrome.storage.local.get(['cbCronogramaPorData','cbCronogramaHoje','cbCronogramaData'], (res) => {
    const porData = res.cbCronogramaPorData ? {...res.cbCronogramaPorData} : {};
    const hoje = hojeStr();
    if (res.cbCronogramaData === hoje){
      porData[hoje] = res.cbCronogramaHoje || [];
    }
    callback(porData);
  });
}

function carregarBlocosDoDia(dataStr, callback){
  carregarTudo((porData) => callback(porData[dataStr] || []));
}

function salvarBlocosDoDia(dataStr, novosBlocos, callback){
  novosBlocos.sort((a,b)=>minutos(a.inicio)-minutos(b.inicio));
  carregarTudo((porData) => {
    porData[dataStr] = novosBlocos;
    // Mantém as chaves antigas sincronizadas para o dia de HOJE, para não quebrar
    // outras partes da extensão (popup / bloqueio) que ainda leem cbCronogramaHoje.
    const patch = { cbCronogramaPorData: porData };
    if (dataStr === hojeStr()){
      patch.cbCronogramaHoje = novosBlocos;
      patch.cbCronogramaData = dataStr;
    }
    chrome.storage.local.set(patch, () => {
      chrome.runtime.sendMessage({ action: 'cronogramaAtualizado' }).catch(()=>{});
      if (callback) callback();
    });
  });
}

/* ---------------- calendário (semana + popover de mês) ---------------- */

function desenharSemana(){
  carregarTudo((porData) => {
    diasComBloco = new Set(Object.keys(porData).filter(k => (porData[k]||[]).length));
    const wrap = document.getElementById('cal-week');
    wrap.innerHTML = '';
    const base = fromDateStr(dataSelecionada);
    const inicioSemana = new Date(base);
    inicioSemana.setDate(base.getDate() - base.getDay());
    const hoje = hojeStr();
    for(let i=0;i<7;i++){
      const d = new Date(inicioSemana);
      d.setDate(inicioSemana.getDate()+i);
      const ds = toDateStr(d);
      const fer = nomeFeriado(ds);
      const el = document.createElement('button');
      el.className = 'cal-day' + (ds===hoje?' is-today':'') + (ds===dataSelecionada?' is-selected':'') + (diasComBloco.has(ds)?' has-blocos':'') + (fer?' is-feriado':'');
      if (fer) el.title = fer;
      el.innerHTML = `<span class="dow">${DOW[d.getDay()]}</span><span class="dnum">${d.getDate()}</span><span class="dmark"></span>`;
      el.addEventListener('click', ()=> selecionarData(ds));
      wrap.appendChild(el);
    }
    const label = MESES[base.getMonth()] + ' de ' + base.getFullYear();
    document.getElementById('cal-month-label').textContent = label;
    renderAgendaLateral(porData);
  });
}

/* Lista de agenda na barra lateral, tipo "Hoje / Amanhã / Segunda..." de
   apps de calendário nativos — mostra os próximos dias com algo marcado,
   sempre incluindo "Hoje" mesmo vazio, pra confirmar que está tudo certo. */
function renderAgendaLateral(porData){
  const wrap = document.getElementById('mini-cal-agenda');
  if (!wrap) return;
  const hoje = hojeStr();
  const HORIZONTE = 6;
  let html = '';
  for (let i = 0; i < HORIZONTE; i++){
    const ds = addDias(hoje, i);
    const lista = [...(porData[ds] || [])].sort((a,b)=>minutos(a.inicio)-minutos(b.inicio));
    if (!lista.length && i > 0) continue; // só pula dias vazios que não sejam hoje
    const d = fromDateStr(ds);
    const titulo = i === 0 ? 'Hoje' : i === 1 ? 'Amanhã' : `${DOW[d.getDay()]}, ${d.getDate()} ${MESES[d.getMonth()].slice(0,3)}`;
    html += `<div><div class="mca-dia-titulo">${titulo}</div>`;
    if (!lista.length){
      html += `<div class="mca-vazio">Nada agendado.</div>`;
    } else {
      lista.forEach(b=>{
        const nome = b.materia || CAT_LABEL[b.tipo] || 'Bloco';
        html += `<div class="mca-item" data-ds="${ds}" title="${escapeHtml(nome)}">
          <span class="mca-dot" style="--cat:${CAT_COR[b.tipo] || 'var(--accent)'}"></span>
          <span class="mca-hora">${b.inicio}</span>
          <span class="mca-nome">${escapeHtml(nome)}</span>
        </div>`;
      });
    }
    html += `</div>`;
  }
  wrap.innerHTML = html || '<div class="mca-vazio">Nada agendado nos próximos dias.</div>';
  wrap.querySelectorAll('.mca-item[data-ds]').forEach(el=>{
    el.addEventListener('click', ()=> selecionarData(el.dataset.ds));
  });
}

function selecionarData(ds){
  dataSelecionada = ds;
  // Efeito de "virar a página" ao trocar de dia — puramente visual (CSS),
  // não interfere no cálculo de posição dos blocos, que continua rodando
  // normalmente em desenhar().
  ['timeline', 'timeline-periodo', 'view-mes', 'view-ano'].forEach((id) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.classList.remove('pagina-virando');
    void el.offsetWidth; // força reflow pra poder reiniciar a animação em cliques seguidos
    el.classList.add('pagina-virando');
    setTimeout(() => el.classList.remove('pagina-virando'), 400);
  });
  // mantém o calendário mensal (popover + o fixo ao lado) sincronizado com
  // a data selecionada — se a pessoa pular pra outro mês pelas setas de
  // dia, o mini-calendário acompanha e já mostra o mês certo.
  const dSel = fromDateStr(ds);
  if (popMonthCursor.getMonth() !== dSel.getMonth() || popMonthCursor.getFullYear() !== dSel.getFullYear()){
    popMonthCursor = new Date(dSel.getFullYear(), dSel.getMonth(), 1);
  }
  desenharPopoverMes();
  desenharSemana();
  atualizarVisaoPeriodo();
}

/* Pula direto pra visão "Dia" numa data específica — usado ao clicar num
   dia dentro da visão Mês ou Ano. */
function irParaDia(ds){
  periodoAtual = 'dia';
  document.querySelectorAll('.periodo-opt').forEach(b => b.classList.toggle('active', b.dataset.periodo === 'dia'));
  selecionarData(ds);
}

function desenharPopoverMes(){
  const y = popMonthCursor.getFullYear(), m = popMonthCursor.getMonth();
  const label = `${MESES[m]} ${y}`;
  let html = DOW.map(w=>`<div class="wd">${w}</div>`).join('');
  const primeiroDia = new Date(y, m, 1);
  const offset = primeiroDia.getDay();
  const diasNoMes = new Date(y, m+1, 0).getDate();
  const hoje = hojeStr();
  for(let i=0;i<offset;i++) html += `<div class="dd mut"></div>`;
  for(let dia=1; dia<=diasNoMes; dia++){
    const ds = `${y}-${pad(m+1)}-${pad(dia)}`;
    const cls = ['dd'];
    if (ds===hoje) cls.push('tdy');
    if (ds===dataSelecionada) cls.push('sel');
    const fer = nomeFeriado(ds);
    if (fer) cls.push('fer');
    html += `<div class="${cls.join(' ')}" data-ds="${ds}"${fer ? ` title="${fer}"` : ''}>${dia}</div>`;
  }

  // desenha nos dois lugares: o popover (mobile/telas estreitas) e o
  // calendário fixo ao lado, tipo Google Agenda (telas largas).
  [
    { grid: 'pop-grid', label: 'pop-month-label' },
    { grid: 'mini-cal-grid', label: 'mini-month-label' }
  ].forEach(({grid, label: labelId}) => {
    const gridEl = document.getElementById(grid);
    const labelEl = document.getElementById(labelId);
    if (!gridEl) return;
    labelEl.textContent = label;
    gridEl.innerHTML = html;
    gridEl.querySelectorAll('[data-ds]').forEach(el=>{
      el.addEventListener('click', ()=>{
        selecionarData(el.dataset.ds);
        document.getElementById('cal-popover').classList.remove('open');
      });
    });
  });
}

document.getElementById('cal-prev').addEventListener('click', ()=> selecionarData(addDias(dataSelecionada,-1)));
document.getElementById('cal-next').addEventListener('click', ()=> selecionarData(addDias(dataSelecionada,1)));
document.getElementById('cal-today').addEventListener('click', ()=> selecionarData(hojeStr()));
document.getElementById('btn-exportar-pdf').addEventListener('click', ()=> window.print());

/* ---------------- zoom da grade (visual, tipo apps de calendário nativos) ---------------- */
let zoomAtual = 1;
function aplicarZoom(){
  const alvo1 = document.getElementById('timeline');
  const alvo2 = document.querySelector('.wk-body');
  if (alvo1) alvo1.style.zoom = zoomAtual;
  if (alvo2) alvo2.style.zoom = zoomAtual;
  document.getElementById('zoom-label').textContent = Math.round(zoomAtual*100) + '%';
}
document.getElementById('zoom-in').addEventListener('click', ()=>{ zoomAtual = Math.min(1.5, +(zoomAtual + 0.1).toFixed(2)); aplicarZoom(); });
document.getElementById('zoom-out').addEventListener('click', ()=>{ zoomAtual = Math.max(0.6, +(zoomAtual - 0.1).toFixed(2)); aplicarZoom(); });
document.getElementById('cal-month-toggle').addEventListener('click', ()=>{
  popMonthCursor = fromDateStr(dataSelecionada);
  desenharPopoverMes();
  document.getElementById('cal-popover').classList.toggle('open');
});
document.getElementById('pop-prev-month').addEventListener('click', ()=>{
  popMonthCursor.setMonth(popMonthCursor.getMonth()-1); desenharPopoverMes();
});
document.getElementById('pop-next-month').addEventListener('click', ()=>{
  popMonthCursor.setMonth(popMonthCursor.getMonth()+1); desenharPopoverMes();
});
document.getElementById('mini-prev-month').addEventListener('click', ()=>{
  popMonthCursor.setMonth(popMonthCursor.getMonth()-1); desenharPopoverMes();
});
document.getElementById('mini-next-month').addEventListener('click', ()=>{
  popMonthCursor.setMonth(popMonthCursor.getMonth()+1); desenharPopoverMes();
});
document.addEventListener('click', (e)=>{
  const pop = document.getElementById('cal-popover');
  if (!pop.classList.contains('open')) return;
  if (pop.contains(e.target) || e.target.closest('#cal-month-toggle')) return;
  pop.classList.remove('open');
});

/* ---------------- layout anti-sobreposição ---------------- */
// Agrupa blocos que se cruzam no tempo e distribui em colunas lado a lado,
// no estilo Google Calendar, para nunca mais desenhar um bloco em cima do outro.
function calcularLayout(lista){
  const ordenada = lista.slice().sort((a,b)=> minutos(a.inicio)-minutos(b.inicio) || minutos(a.fim)-minutos(b.fim));
  const grupos = [];
  let grupoAtual = [], fimMaximo = -1;
  ordenada.forEach(b=>{
    const ini = minutos(b.inicio), fim = minutos(b.fim);
    if (grupoAtual.length && ini >= fimMaximo){
      grupos.push(grupoAtual);
      grupoAtual = [];
      fimMaximo = -1;
    }
    grupoAtual.push(b);
    fimMaximo = Math.max(fimMaximo, fim);
  });
  if (grupoAtual.length) grupos.push(grupoAtual);

  const posicoes = new Map();
  grupos.forEach(grupo=>{
    const colunas = []; // cada posição guarda o "fim" do último bloco alocado nela
    grupo.forEach(b=>{
      const ini = minutos(b.inicio), fim = minutos(b.fim);
      let col = colunas.findIndex(fimCol => ini >= fimCol);
      if (col === -1){ col = colunas.length; colunas.push(fim); }
      else colunas[col] = fim;
      posicoes.set(b, col);
    });
    const totalCols = colunas.length;
    grupo.forEach(b=> posicoes.set(b, {col: posicoes.get(b), total: totalCols}));
  });
  return posicoes;
}

/* ---------------- desenho da timeline ---------------- */

function render(){
  carregarBlocosDoDia(dataSelecionada, (dados) => {
    blocos = dados.map(b => ({
      id: b.id,
      categoria: b.tipo,
      label: b.materia || '',
      inicio: b.inicio,
      fim: b.fim,
      camera: !!b.camera,
      prioridade: b.prioridade || 'media',
      aviso: b.aviso !== false,
      concluido: !!b.concluido
    }));
    desenhar();
  });
}

/* Cria o elemento visual de um bloco (reaproveitado tanto na visão de um
   dia só quanto na grade semanal/multi-dia). GAP e a folga de 6px nas
   bordas são as mesmas usadas há tempos na timeline de um dia. */
function montarBlocoEl(b, pos, isNow){
  const GAP = 4;
  const ini = minutos(b.inicio), fim = minutos(b.fim);
  const top = (ini - HORA_INICIO*60) / 60 * ALTURA_HORA;
  const height = Math.max((fim-ini)/60 * ALTURA_HORA, 30);
  const folgaTotal = 12 + GAP * (pos.total - 1);
  const larguraColuna = `((100% - ${folgaTotal}px) / ${pos.total})`;
  const el = document.createElement('div');
  el.className = 'tl-block' + (isNow ? ' is-now' : '') + (b.concluido ? ' is-done' : '');
  el.style.top = top+'px';
  el.style.height = height+'px';
  el.style.left = `calc(6px + ${pos.col} * (${larguraColuna} + ${GAP}px))`;
  el.style.width = `calc(${larguraColuna})`;
  el.style.zIndex = String(10 + pos.col);
  el.style.setProperty('--cat', CAT_COR[b.categoria]);

  const nomeExibido = b.label || CAT_LABEL[b.categoria];
  const iconeSom = '<svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H2v6h4l5 4V5Z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/></svg>';
  const iconeCheck = '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>';
  const iconeGCal = '<svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></svg>';
  el.innerHTML = `
    <button class="b-done" data-done-id="${b.id}" title="${b.concluido ? 'Marcar como não concluída' : 'Marcar como concluída'}">${iconeCheck}</button>
    <button class="b-gcal" data-gcal-id="${b.id}" title="Adicionar ao Google Agenda">${iconeGCal}</button>
    <button class="b-del" data-id="${b.id}" title="Remover">✕</button>
    <div class="b-time">${b.inicio} – ${b.fim}</div>
    <div class="b-title">
      <span class="b-prio pr-${b.prioridade}" title="${PRIO_LABEL[b.prioridade]}"></span>
      <span class="b-nome${b.prioridade === 'alta' ? ' b-grifo' : ''}">${escapeHtml(nomeExibido)}</span>
      ${b.aviso ? `<span class="b-som" title="Aviso sonoro ativado">${iconeSom}</span>` : ''}
      ${b.camera ? '<span class="b-cam">● câmera</span>' : ''}
    </div>
    <div class="b-sub">${CAT_LABEL[b.categoria]}</div>`;
  return el;
}

function desenhar(){
  const tl = document.getElementById('timeline');
  let html = '';
  for(let h=HORA_INICIO; h<HORA_FIM; h++){
    html += `<div class="tl-hour"><span class="tl-hour-label">${pad(h)}:00</span></div>`;
  }
  tl.innerHTML = html;

  const ehHoje = dataSelecionada === hojeStr();
  const agora = new Date();
  const minAgora = agora.getHours()*60 + agora.getMinutes();

  const layout = calcularLayout(blocos);

  blocos.forEach(b=>{
    const ini = minutos(b.inicio), fim = minutos(b.fim);
    const isNow = ehHoje && minAgora >= ini && minAgora < fim;
    const pos = layout.get(b) || {col:0,total:1};
    tl.appendChild(montarBlocoEl(b, pos, isNow));
  });

  if (ehHoje && minAgora >= HORA_INICIO*60 && minAgora < HORA_FIM*60){
    const line = document.createElement('div');
    line.className = 'now-line';
    line.style.top = ((minAgora - HORA_INICIO*60)/60*ALTURA_HORA) + 'px';
    line.innerHTML = `<div class="now-track"></div><div class="now-dot"></div><div class="now-time">${agora.toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}</div>`;
    tl.appendChild(line);
  }

  if (!blocos.length){
    tl.insertAdjacentHTML('beforeend', `<div class="empty-hint">Nenhum bloco ${ehHoje ? 'ainda hoje' : 'nesse dia'}. Monte o primeiro ao lado.</div>`);
  }

  tl.querySelectorAll('.b-del[data-id]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      carregarBlocosDoDia(dataSelecionada, (atual) => {
        salvarBlocosDoDia(dataSelecionada, atual.filter(b => b.id !== btn.dataset.id), () => { render(); desenharSemana(); });
      });
    });
  });

  tl.querySelectorAll('.b-gcal[data-gcal-id]').forEach(btn=>{
    btn.addEventListener('click', (ev)=>{
      ev.stopPropagation();
      abrirNoGoogleCalendar(btn.dataset.gcalId);
    });
  });

  tl.querySelectorAll('.b-done[data-done-id]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      carregarBlocosDoDia(dataSelecionada, (atual) => {
        const atualizados = atual.map(b => b.id === btn.dataset.doneId ? { ...b, concluido: !b.concluido } : b);
        salvarBlocosDoDia(dataSelecionada, atualizados, () => { render(); desenharSemana(); });
      });
    });
  });

  const totalMin = blocos.reduce((acc,b)=>acc+Math.max(0,minutos(b.fim)-minutos(b.inicio)),0);
  document.getElementById('stat-horas').textContent = totalMin>=60 ? `${Math.floor(totalMin/60)}h${totalMin%60?(totalMin%60)+'m':''}` : `${totalMin}m`;
  document.getElementById('stat-blocos').textContent = blocos.length;
}

function escapeHtml(s){
  const d = document.createElement('div'); d.textContent = s; return d.innerHTML;
}

// -------------- Sincronizar com o Google Agenda --------------
// Não usa a API do Google (isso exigiria OAuth e um projeto no Google
// Cloud Console configurado por vocês, algo que não dá pra deixar pronto
// sem essa etapa manual do lado de vocês). Em vez disso, usa o link de
// "criação rápida de evento" que o próprio Google Agenda expõe
// publicamente (o mesmo mecanismo por trás de botões "Adicionar ao Google
// Agenda" espalhados pela web) — clicar no botão abre uma aba nova já com
// título, data e horário do bloco preenchidos; a pessoa só confirma
// "Salvar" do lado do Google. Zero configuração adicional necessária.
function gerarLinkGoogleCalendar(b, dataStr){
  const d = fromDateStr(dataStr);
  const [hIni, mIni] = b.inicio.split(':').map(Number);
  const [hFim, mFim] = b.fim.split(':').map(Number);
  const inicio = new Date(d.getFullYear(), d.getMonth(), d.getDate(), hIni, mIni);
  const fim = new Date(d.getFullYear(), d.getMonth(), d.getDate(), hFim, mFim);
  const fmt = (dt) => `${dt.getFullYear()}${pad(dt.getMonth()+1)}${pad(dt.getDate())}T${pad(dt.getHours())}${pad(dt.getMinutes())}00`;
  const titulo = b.label || CAT_LABEL[b.categoria];
  const params = new URLSearchParams({
    action: 'TEMPLATE',
    text: titulo,
    dates: `${fmt(inicio)}/${fmt(fim)}`,
    details: `Criado pelo Concurseiro Blindado — categoria: ${CAT_LABEL[b.categoria]}, prioridade: ${PRIO_LABEL[b.prioridade]}.`
  });
  return `https://calendar.google.com/calendar/render?${params.toString()}`;
}

function abrirNoGoogleCalendarBloco(b, dataStr){
  const url = gerarLinkGoogleCalendar(b, dataStr);
  if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.create) {
    chrome.tabs.create({ url });
  } else {
    window.open(url, '_blank');
  }
}
function abrirNoGoogleCalendar(blocoId){
  const b = blocos.find(x => x.id === blocoId);
  if (!b) return;
  abrirNoGoogleCalendarBloco(b, dataSelecionada);
}

function relogio(){
  document.getElementById('hora-atual').textContent = new Date().toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'});
}
relogio(); setInterval(relogio, 15000);

/* ---------------- aviso sonoro (bipe via Web Audio, sem precisar de arquivo) ---------------- */

function tocarBipe(){
  try{
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    [0, 0.18, 0.36].forEach((delay, i)=>{
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = i===2 ? 1046.5 : 880;
      gain.gain.setValueAtTime(0.0001, ctx.currentTime+delay);
      gain.gain.exponentialRampToValueAtTime(0.22, ctx.currentTime+delay+0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime+delay+0.16);
      osc.connect(gain).connect(ctx.destination);
      osc.start(ctx.currentTime+delay);
      osc.stop(ctx.currentTime+delay+0.18);
    });
  }catch(e){ /* Web Audio indisponível — ignora silenciosamente */ }
}

function verificarAvisos(){
  if (dataSelecionada !== hojeStr()) return;
  const agora = new Date();
  const minAgora = agora.getHours()*60 + agora.getMinutes();
  blocos.forEach(b=>{
    if (!b.aviso) return;
    if (avisosDisparados.has(b.id)) return;
    const ini = minutos(b.inicio);
    if (minAgora >= ini && minAgora < ini+1){
      avisosDisparados.add(b.id);
      tocarBipe();
      if (window.Notification && Notification.permission === 'granted'){
        new Notification('Hora de: ' + (b.label || CAT_LABEL[b.categoria]), {
          body: `${b.inicio} – ${b.fim} · ${PRIO_LABEL[b.prioridade]}`
        });
      }
    }
  });
}
if (window.Notification && Notification.permission === 'default'){
  Notification.requestPermission().catch(()=>{});
}

/* ---------------- builder (formulário de novo bloco) ---------------- */

document.getElementById('cat-grid').addEventListener('click', (e)=>{
  const btn = e.target.closest('.cat-btn');
  if(!btn) return;
  document.querySelectorAll('.cat-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  catSelecionada = btn.dataset.cat;
  document.getElementById('cam-row').classList.toggle('show', catSelecionada === 'leitura');
  document.getElementById('outro-name-wrap').classList.toggle('show', catSelecionada === 'outro');
});

document.getElementById('prio-grid').addEventListener('click', (e)=>{
  const btn = e.target.closest('.prio-btn');
  if(!btn) return;
  document.querySelectorAll('.prio-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  prioSelecionada = btn.dataset.prio;
});

/* ---------------- time picker personalizado (Início / Fim) ---------------- */
function criarTimePicker(nome){
  const wrap = document.getElementById(`tp-${nome}`);
  const btn = document.getElementById(`tp-${nome}-btn`);
  const label = document.getElementById(`tp-${nome}-label`);
  const nativo = document.getElementById(`in-${nome}`);
  const painel = document.getElementById(`tp-${nome}-panel`);
  const colHora = painel.querySelector('[data-col="hora"]');
  const colMin = painel.querySelector('[data-col="min"]');
  const colAmpm = painel.querySelector('[data-col="ampm"]');

  const horas = Array.from({length:12}, (_,i)=> pad(i+1));
  const mins = Array.from({length:12}, (_,i)=> pad(i*5));
  colHora.innerHTML = horas.map(h=>`<button type="button" data-val="${h}">${h}</button>`).join('');
  colMin.innerHTML = mins.map(m=>`<button type="button" data-val="${m}">${m}</button>`).join('');

  function paraExibicao(valor24){
    const [h, m] = (valor24 || '08:00').split(':').map(Number);
    const ampm = h >= 12 ? 'PM' : 'AM';
    let h12 = h % 12; if (h12 === 0) h12 = 12;
    const mArred = Math.round(m/5)*5 % 60; // o seletor só oferece de 5 em 5 min
    return { hora: pad(h12), min: pad(mArred), ampm };
  }
  function paraValor24(hora12, min, ampm){
    let h = Number(hora12) % 12;
    if (ampm === 'PM') h += 12;
    return `${pad(h)}:${pad(Number(min))}`;
  }
  function atualizarSelecao(){
    const atual = paraExibicao(nativo.value);
    colHora.querySelectorAll('button').forEach(b=> b.classList.toggle('sel', b.dataset.val === atual.hora));
    colMin.querySelectorAll('button').forEach(b=> b.classList.toggle('sel', b.dataset.val === atual.min));
    colAmpm.querySelectorAll('button').forEach(b=> b.classList.toggle('sel', b.dataset.val === atual.ampm));
    label.textContent = `${atual.hora}:${atual.min} ${atual.ampm}`;
  }
  function escolher(coluna, valor){
    const atual = paraExibicao(nativo.value);
    atual[coluna] = valor;
    nativo.value = paraValor24(atual.hora, atual.min, atual.ampm);
    atualizarSelecao();
  }
  colHora.addEventListener('click', (e)=>{ const b = e.target.closest('button'); if (b) escolher('hora', b.dataset.val); });
  colMin.addEventListener('click', (e)=>{ const b = e.target.closest('button'); if (b) escolher('min', b.dataset.val); });
  colAmpm.addEventListener('click', (e)=>{ const b = e.target.closest('button'); if (b) escolher('ampm', b.dataset.val); });

  btn.addEventListener('click', (e)=>{
    e.stopPropagation();
    const abrindo = !wrap.classList.contains('aberto');
    document.querySelectorAll('.time-picker.aberto').forEach(w=> w.classList.remove('aberto'));
    if (abrindo){
      wrap.classList.add('aberto');
      atualizarSelecao();
      requestAnimationFrame(()=>{
        const sh = colHora.querySelector('.sel'); if (sh) sh.scrollIntoView({block:'center'});
        const sm = colMin.querySelector('.sel'); if (sm) sm.scrollIntoView({block:'center'});
      });
    }
  });

  atualizarSelecao();
}
document.addEventListener('click', ()=>{
  document.querySelectorAll('.time-picker.aberto').forEach(w=> w.classList.remove('aberto'));
});
criarTimePicker('inicio');
criarTimePicker('fim');

document.getElementById('btn-add').addEventListener('click', ()=>{
  const inicio = document.getElementById('in-inicio').value;
  const fim = document.getElementById('in-fim').value;
  let label = document.getElementById('in-label').value.trim();
  const outroNome = document.getElementById('in-outro-nome').value.trim();
  const camera = document.getElementById('in-camera').checked && catSelecionada === 'leitura';
  const aviso = document.getElementById('in-som').checked;

  if (catSelecionada === 'outro' && outroNome && !label) label = outroNome;

  if(!inicio || !fim || minutos(fim) <= minutos(inicio)){
    alert('O horário de fim precisa ser depois do início.');
    return;
  }

  carregarBlocosDoDia(dataSelecionada, (atual) => {
    const novoBloco = {
      id: `crono_${Date.now()}_${Math.random().toString(36).slice(2,7)}`,
      inicio, fim, tipo: catSelecionada, materia: label, camera,
      prioridade: prioSelecionada, aviso
    };
    atual.push(novoBloco);
    salvarBlocosDoDia(dataSelecionada, atual, () => {
      document.getElementById('in-label').value = '';
      document.getElementById('in-outro-nome').value = '';
      render();
      desenharSemana();
    });
  });
});

/* ---------------- visão Dia / Semana / Mês / Ano ---------------- */

let periodoAtual = 'semana';
const painelTitulo = document.getElementById('panel-title');
const timelineEl = document.getElementById('timeline');
const timelinePeriodoEl = document.getElementById('timeline-periodo');

function mapBloco(b){
  return {
    id: b.id, categoria: b.tipo, label: b.materia || '', inicio: b.inicio, fim: b.fim,
    camera: !!b.camera, prioridade: b.prioridade || 'media', aviso: b.aviso !== false, concluido: !!b.concluido
  };
}

/* Grade semanal/multi-dia no estilo Google Agenda: uma coluna de horas +
   uma coluna por dia, cada bloco desenhado na posição exata do horário
   (reaproveita montarBlocoEl(), a mesma função da visão de um dia só). */
function renderPeriodo(numDias){
  const hoje = hojeStr();
  const datas = [];
  for (let i = 0; i < numDias; i++) datas.push(addDias(hoje, i));

  Promise.all(datas.map(ds => new Promise(resolve => carregarBlocosDoDia(ds, resolve))))
    .then(listas => {
      const agora = new Date();
      const minAgora = agora.getHours()*60 + agora.getMinutes();

      // cabeçalho dos dias
      const headEl = document.getElementById('wk-head');
      let headHtml = '<div class="wk-head-gutter"></div>';
      datas.forEach(ds => {
        const d = fromDateStr(ds);
        const ehHoje = ds === hoje;
        const fer = nomeFeriado(ds);
        headHtml += `<div class="wk-head-day${ehHoje ? ' is-today' : ''}"${fer ? ` title="${fer}"` : ''}>
          <div class="dow">${DOW[d.getDay()]}</div>
          <div class="dnum">${d.getDate()}</div>
          ${fer ? `<div class="wk-head-feriado">${fer}</div>` : ''}
        </div>`;
      });
      headEl.innerHTML = headHtml;

      // régua de horas (coluna fixa da esquerda)
      const gutterEl = document.getElementById('wk-gutter');
      let gutterHtml = '';
      for (let h = HORA_INICIO; h < HORA_FIM; h++){
        gutterHtml += `<div class="wk-hour"><span class="wk-hour-label">${pad(h)}:00</span></div>`;
      }
      gutterEl.innerHTML = gutterHtml;

      // uma coluna por dia
      const daysEl = document.getElementById('wk-days');
      daysEl.innerHTML = '';
      datas.forEach((ds, i) => {
        const blocosDia = listas[i].map(mapBloco);
        const ehHoje = ds === hoje;
        const col = document.createElement('div');
        col.className = 'wk-day';
        let linhas = '';
        for (let h = HORA_INICIO; h < HORA_FIM; h++) linhas += '<div class="tl-hour"></div>';
        col.innerHTML = linhas;

        const layout = calcularLayout(blocosDia);
        blocosDia.forEach(b=>{
          const ini = minutos(b.inicio), fim = minutos(b.fim);
          const isNow = ehHoje && minAgora >= ini && minAgora < fim;
          const pos = layout.get(b) || {col:0,total:1};
          const el = montarBlocoEl(b, pos, isNow);
          el.querySelectorAll('.b-del,.b-gcal,.b-done').forEach(btn=>{
            if (btn.classList.contains('b-del')) btn.addEventListener('click', ()=>{
              carregarBlocosDoDia(ds, (atual) => {
                salvarBlocosDoDia(ds, atual.filter(x => x.id !== b.id), () => { renderPeriodo(numDias); if (ds === dataSelecionada) render(); desenharSemana(); });
              });
            });
            if (btn.classList.contains('b-gcal')) btn.addEventListener('click', (ev)=>{ ev.stopPropagation(); abrirNoGoogleCalendarBloco(b, ds); });
            if (btn.classList.contains('b-done')) btn.addEventListener('click', ()=>{
              carregarBlocosDoDia(ds, (atual) => {
                const atualizados = atual.map(x => x.id === b.id ? { ...x, concluido: !x.concluido } : x);
                salvarBlocosDoDia(ds, atualizados, () => { renderPeriodo(numDias); if (ds === dataSelecionada) render(); desenharSemana(); });
              });
            });
          });
          col.appendChild(el);
        });

        if (ehHoje && minAgora >= HORA_INICIO*60 && minAgora < HORA_FIM*60){
          const line = document.createElement('div');
          line.className = 'now-line';
          line.style.top = ((minAgora - HORA_INICIO*60)/60*ALTURA_HORA) + 'px';
          line.innerHTML = `<div class="now-track"></div><div class="now-dot"></div>`;
          col.appendChild(line);
        }
        daysEl.appendChild(col);
      });

      // rola a grade pra começar perto do início do dia de trabalho, em vez
      // de abrir sempre lá na meia-noite (igual ao comportamento padrão do
      // Google Agenda, que abre a semana já rolada pras primeiras horas úteis).
      const wkBody = document.querySelector('.wk-body');
      if (wkBody) wkBody.scrollTop = Math.max(0, 6 * ALTURA_HORA - 30);

      // fallback compacto (telas estreitas) — lista simples por dia
      const fb = document.getElementById('tp-lista-fallback');
      let fbHtml = '';
      datas.forEach((ds, i) => {
        const lista = [...listas[i]].sort((a,b)=>minutos(a.inicio)-minutos(b.inicio));
        const d = fromDateStr(ds);
        const ehHoje = ds === hoje;
        const tituloDia = ehHoje
          ? `Hoje, ${d.getDate()} de ${MESES[d.getMonth()]}`
          : `${DOW[d.getDay()]}, ${d.getDate()} de ${MESES[d.getMonth()]}`;
        fbHtml += `<div class="tp-dia${ehHoje ? ' tp-hoje' : ''}">
          <div class="tp-dia-head"><span class="tp-dia-titulo">${tituloDia}</span></div>`;
        if (!lista.length){
          fbHtml += `<div class="tp-vazio">Nada agendado.</div>`;
        } else {
          lista.forEach(b => {
            const nome = b.materia || CAT_LABEL[b.tipo] || 'Bloco';
            fbHtml += `<div class="tp-bloco${b.concluido ? ' tp-done' : ''}">
              <span class="tp-hora">${b.inicio} – ${b.fim}</span>
              <span class="tp-dot" style="--cat:${CAT_COR[b.tipo] || 'var(--accent)'}"></span>
              <span class="tp-nome">${escapeHtml(nome)}</span>
            </div>`;
          });
        }
        fbHtml += `</div>`;
      });
      fb.innerHTML = fbHtml;
    });
}

document.getElementById('periodo-toggle').addEventListener('click', (e) => {
  const btn = e.target.closest('.periodo-opt');
  if (!btn) return;
  periodoAtual = btn.dataset.periodo;
  document.querySelectorAll('.periodo-opt').forEach(b => b.classList.toggle('active', b === btn));
  atualizarVisaoPeriodo();
});

/* Mostra a view certa (Dia/Semana/Mês/Ano) de acordo com periodoAtual e
   dispara o desenho dela. Chamada tanto pelo clique nas abas quanto toda
   vez que a data selecionada muda (troca de dia, adicionar/remover bloco
   etc.), pra sempre refletir o estado mais atual na tela. */
function atualizarVisaoPeriodo(){
  const viewMes = document.getElementById('view-mes');
  const viewAno = document.getElementById('view-ano');
  const layoutEl = document.querySelector('.layout');

  timelineEl.style.display = 'none';
  timelinePeriodoEl.style.display = 'none';
  viewMes.style.display = 'none';
  viewAno.style.display = 'none';
  layoutEl.classList.toggle('layout-full', periodoAtual === 'mes' || periodoAtual === 'ano');

  if (periodoAtual === 'dia'){
    const fer = nomeFeriado(dataSelecionada);
    painelTitulo.textContent = (dataSelecionada === hojeStr() ? 'Linha do dia' : 'Linha do dia selecionado') + (fer ? ` · Feriado: ${fer}` : '');
    timelineEl.style.display = '';
    render();
  } else if (periodoAtual === 'mes'){
    painelTitulo.textContent = 'Mês';
    viewMes.style.display = 'block';
    mesViewCursor = fromDateStr(dataSelecionada);
    renderMesView();
  } else if (periodoAtual === 'ano'){
    painelTitulo.textContent = 'Ano';
    viewAno.style.display = 'block';
    anoViewCursor = fromDateStr(dataSelecionada).getFullYear();
    renderAnoView();
  } else { // 'semana'
    painelTitulo.textContent = 'Semana';
    timelinePeriodoEl.style.display = 'block';
    renderPeriodo(7);
  }
}

/* ---------------- visão Mês ---------------- */
let mesViewCursor = new Date();
function renderMesView(){
  const y = mesViewCursor.getFullYear(), m = mesViewCursor.getMonth();
  document.getElementById('mes-view-label').textContent = `${MESES[m]} ${y}`;
  carregarTudo((porData)=>{
    const diasCom = new Set(Object.keys(porData).filter(k => (porData[k]||[]).length));
    const grid = document.getElementById('mes-view-grid');
    let html = DOW.map(w=>`<div class="wd">${w}</div>`).join('');
    const offset = new Date(y, m, 1).getDay();
    const diasNoMes = new Date(y, m+1, 0).getDate();
    const hoje = hojeStr();
    for(let i=0;i<offset;i++) html += `<div class="dd mut"></div>`;
    for(let dia=1; dia<=diasNoMes; dia++){
      const ds = `${y}-${pad(m+1)}-${pad(dia)}`;
      const cls = ['dd'];
      if (ds===hoje) cls.push('tdy');
      if (ds===dataSelecionada) cls.push('sel');
      const fer = nomeFeriado(ds);
      if (fer) cls.push('fer');
      html += `<div class="${cls.join(' ')}" data-ds="${ds}"${fer ? ` title="${fer}"` : ''}>${dia}${diasCom.has(ds) ? '<span class="pt"></span>' : ''}</div>`;
    }
    grid.innerHTML = html;
    grid.querySelectorAll('[data-ds]').forEach(el=>{
      el.addEventListener('click', ()=> irParaDia(el.dataset.ds));
    });
  });
}
document.getElementById('mes-view-prev').addEventListener('click', ()=>{ mesViewCursor.setMonth(mesViewCursor.getMonth()-1); renderMesView(); });
document.getElementById('mes-view-next').addEventListener('click', ()=>{ mesViewCursor.setMonth(mesViewCursor.getMonth()+1); renderMesView(); });

/* ---------------- visão Ano ---------------- */
let anoViewCursor = new Date().getFullYear();
function renderAnoView(){
  document.getElementById('ano-view-label').textContent = String(anoViewCursor);
  const wrap = document.getElementById('ano-view-grid');
  const hoje = hojeStr();
  let html = '';
  for (let m=0; m<12; m++){
    const offset = new Date(anoViewCursor, m, 1).getDay();
    const diasNoMes = new Date(anoViewCursor, m+1, 0).getDate();
    let g = DOW.map(w=>`<div class="wd">${w[0]}</div>`).join('');
    for(let i=0;i<offset;i++) g += `<div class="dd mut"></div>`;
    for(let dia=1; dia<=diasNoMes; dia++){
      const ds = `${anoViewCursor}-${pad(m+1)}-${pad(dia)}`;
      const cls = ['dd'];
      if (ds===hoje) cls.push('tdy');
      const fer = nomeFeriado(ds);
      if (fer) cls.push('fer');
      g += `<div class="${cls.join(' ')}" data-ds="${ds}"${fer ? ` title="${fer}"` : ''}>${dia}</div>`;
    }
    html += `<div class="ano-mes-card"><div class="titulo">${MESES[m]}</div><div class="grid">${g}</div></div>`;
  }
  wrap.innerHTML = html;
  wrap.querySelectorAll('[data-ds]').forEach(el=>{
    el.addEventListener('click', ()=> irParaDia(el.dataset.ds));
  });
}
document.getElementById('ano-view-prev').addEventListener('click', ()=>{ anoViewCursor--; renderAnoView(); });
document.getElementById('ano-view-next').addEventListener('click', ()=>{ anoViewCursor++; renderAnoView(); });

/* ---------------- ciclo de vida ---------------- */

selecionarData(dataSelecionada);
setInterval(()=>{ if (periodoAtual === 'dia') render(); }, 30000);

/* ---------------- personalização: cor da capa do caderno ---------------- */
// Recolore --accent/--accent-light/--accent-dark (usadas em botões, no dia
// selecionado do calendário, na bolinha "ao vivo" etc.) — funciona como a
// "cor da capa" do caderno. Fica salvo em chrome.storage.local, então
// persiste entre visitas a esta página.
const CAPA_PALETA = [
  { nome: 'terracota', accent:'#c8654a', light:'#d98164', dark:'#a8503a' },
  { nome: 'verde-sálvia', accent:'#5f8f6e', light:'#7ba789', dark:'#476b53' },
  { nome: 'azul-jeans', accent:'#4d6fa8', light:'#6f8dbd', dark:'#3a5480' },
  { nome: 'ameixa', accent:'#8c5a9e', light:'#a67bb5', dark:'#6d4479' },
  { nome: 'mostarda', accent:'#c99a2e', light:'#d9b158', dark:'#a67c22' },
  { nome: 'grafite', accent:'#5c5548', light:'#78705f', dark:'#443f35' }
];

function aplicarCorCapa(cor, persistir){
  document.documentElement.style.setProperty('--accent', cor.accent);
  document.documentElement.style.setProperty('--accent-light', cor.light);
  document.documentElement.style.setProperty('--accent-dark', cor.dark);
  document.documentElement.style.setProperty('--accent-dim', cor.accent + '1f');
  document.documentElement.style.setProperty('--accent-glow', cor.accent + '4d');
  if (persistir && typeof chrome !== 'undefined' && chrome.storage){
    chrome.storage.local.set({ rotinaCorCapa: cor.nome });
  }
}

function initPersonalizacaoCapa(){
  const wrap = document.getElementById('capa-swatches');
  if (!wrap) return;
  wrap.innerHTML = '';
  CAPA_PALETA.forEach((cor) => {
    const btn = document.createElement('button');
    btn.style.background = cor.accent;
    btn.title = cor.nome;
    btn.addEventListener('click', () => {
      wrap.querySelectorAll('button').forEach(b => b.classList.remove('ativo'));
      btn.classList.add('ativo');
      aplicarCorCapa(cor, true);
    });
    wrap.appendChild(btn);
  });

  if (typeof chrome !== 'undefined' && chrome.storage){
    chrome.storage.local.get(['rotinaCorCapa'], (res) => {
      const salva = CAPA_PALETA.find(c => c.nome === res.rotinaCorCapa) || CAPA_PALETA[0];
      aplicarCorCapa(salva, false);
      const idx = CAPA_PALETA.indexOf(salva);
      const botoes = wrap.querySelectorAll('button');
      if (botoes[idx]) botoes[idx].classList.add('ativo');
    });
  }
}
initPersonalizacaoCapa();

/* ---------------- personalização: cor da caneta / marcações ---------------- */
// Separado da cor da capa — controla --caneta, usada no contorno do bloco
// "agora", no grifo dos blocos de prioridade alta, no check de concluído e
// no texto escrito à mão (anotações de matéria, nomes na visão de dias).
const CANETA_PALETA = [
  { nome: 'tinta-azul', cor:'#2f5a6e' },
  { nome: 'tinta-preta', cor:'#2b2b2b' },
  { nome: 'verde-caneta', cor:'#2f6b4a' },
  { nome: 'vermelho-correcao', cor:'#a8324a' },
  { nome: 'roxo-caneta', cor:'#5a3e8c' },
  { nome: 'laranja-marcador', cor:'#c47a1f' }
];

function aplicarCorCaneta(cor, persistir){
  document.documentElement.style.setProperty('--caneta', cor.cor);
  document.documentElement.style.setProperty('--caneta-dim', cor.cor + '29');
  document.documentElement.style.setProperty('--caneta-glow', cor.cor + '66');
  if (persistir && typeof chrome !== 'undefined' && chrome.storage){
    chrome.storage.local.set({ rotinaCorCaneta: cor.nome });
  }
}

function initPersonalizacaoCaneta(){
  const wrap = document.getElementById('caneta-swatches');
  if (!wrap) return;
  wrap.innerHTML = '';
  CANETA_PALETA.forEach((cor) => {
    const btn = document.createElement('button');
    btn.style.background = cor.cor;
    btn.title = cor.nome;
    btn.addEventListener('click', () => {
      wrap.querySelectorAll('button').forEach(b => b.classList.remove('ativo'));
      btn.classList.add('ativo');
      aplicarCorCaneta(cor, true);
    });
    wrap.appendChild(btn);
  });

  if (typeof chrome !== 'undefined' && chrome.storage){
    chrome.storage.local.get(['rotinaCorCaneta'], (res) => {
      const salva = CANETA_PALETA.find(c => c.nome === res.rotinaCorCaneta) || CANETA_PALETA[0];
      aplicarCorCaneta(salva, false);
      const idx = CANETA_PALETA.indexOf(salva);
      const botoes = wrap.querySelectorAll('button');
      if (botoes[idx]) botoes[idx].classList.add('ativo');
    });
  }
}
initPersonalizacaoCaneta();

/* A capa/tela de abertura e as abas laterais (Semana / Simulados /
   Matérias) que existiam aqui foram removidas — esta página agora abre
   direto na visão "Organize o seu dia", sem tela de capa nem navegação
   de caderno. As páginas de Simulados e Matérias ficaram só com o HTML e
   as funções abaixo (não removidas, caso sejam reaproveitadas depois),
   mas hoje nada mais chama renderSimulados()/renderMaterias(). */

/* ==================== PÁGINA: SIMULADOS ==================== */
function carregarSimulados(cb){
  chrome.storage.local.get(['cbSimulados'], (res) => cb(res.cbSimulados || []));
}
function salvarSimulados(lista, cb){
  chrome.storage.local.set({ cbSimulados: lista }, cb);
}
function renderSimulados(){
  carregarSimulados((lista) => {
    const wrap = document.getElementById('sim-lista');
    if (!lista.length){
      wrap.innerHTML = '<div class="sim-vazio">Nenhum simulado registrado ainda.</div>';
      return;
    }
    const ordenada = lista.slice().sort((a,b) => (b.data||'').localeCompare(a.data||''));
    wrap.innerHTML = ordenada.map((s) => {
      const total = (Number(s.acertos)||0) + (Number(s.erros)||0);
      const pct = total > 0 ? Math.round((Number(s.acertos)||0) / total * 100) : 0;
      const dataFmt = s.data ? fromDateStr(s.data).toLocaleDateString('pt-BR') : '—';
      return `<div class="sim-card">
        <b>${escapeHtml(s.nome || 'Simulado')}</b>
        <span>${dataFmt}</span>
        <span>${escapeHtml(s.estilo || '—')}</span>
        <span>${Number(s.acertos)||0} certas</span>
        <span>${Number(s.erros)||0} erradas</span>
        <span class="sim-pct">${pct}%</span>
        <button class="sim-del" data-id="${s.id}" title="Remover">✕</button>
      </div>`;
    }).join('');
    wrap.querySelectorAll('.sim-del').forEach((btn) => {
      btn.addEventListener('click', () => {
        carregarSimulados((atual) => {
          salvarSimulados(atual.filter(s => s.id !== btn.dataset.id), renderSimulados);
        });
      });
    });
  });
}
document.getElementById('btn-add-simulado').addEventListener('click', () => {
  const nome = document.getElementById('sim-nome').value.trim();
  const data = document.getElementById('sim-data').value;
  const estilo = document.getElementById('sim-estilo').value.trim();
  const acertos = document.getElementById('sim-acertos').value.trim();
  const erros = document.getElementById('sim-erros').value.trim();
  if (!nome){ alert('Dá um nome pro simulado.'); return; }
  carregarSimulados((atual) => {
    atual.push({ id: `sim_${Date.now()}_${Math.random().toString(36).slice(2,7)}`, nome, data, estilo, acertos, erros });
    salvarSimulados(atual, () => {
      document.getElementById('sim-nome').value = '';
      document.getElementById('sim-estilo').value = '';
      document.getElementById('sim-acertos').value = '';
      document.getElementById('sim-erros').value = '';
      renderSimulados();
    });
  });
});

/* ==================== PÁGINA: MATÉRIAS ==================== */
let materiaAtivaId = null;

function carregarMaterias(cb){
  chrome.storage.local.get(['cbMaterias'], (res) => cb(res.cbMaterias || []));
}
function salvarMaterias(lista, cb){
  chrome.storage.local.set({ cbMaterias: lista }, cb);
}
function renderListaMaterias(){
  carregarMaterias((lista) => {
    const wrap = document.getElementById('mat-lista-itens');
    if (!lista.length){
      wrap.innerHTML = '<div class="mat-vazio">Nenhuma matéria ainda.</div>';
      return;
    }
    if (!materiaAtivaId && lista[0]) materiaAtivaId = lista[0].id;
    wrap.innerHTML = lista.map(m => `
      <div class="mat-item${m.id === materiaAtivaId ? ' ativa' : ''}" data-id="${m.id}">
        <span>${escapeHtml(m.nome)}</span>
        <button class="mat-del" data-id="${m.id}" title="Remover matéria">✕</button>
      </div>`).join('');
    wrap.querySelectorAll('.mat-item').forEach((el) => {
      el.addEventListener('click', (ev) => {
        if (ev.target.closest('.mat-del')) return;
        materiaAtivaId = el.dataset.id;
        renderListaMaterias();
        renderPainelMateria();
      });
    });
    wrap.querySelectorAll('.mat-del').forEach((btn) => {
      btn.addEventListener('click', () => {
        carregarMaterias((atual) => {
          const nova = atual.filter(m => m.id !== btn.dataset.id);
          if (materiaAtivaId === btn.dataset.id) materiaAtivaId = nova[0] ? nova[0].id : null;
          salvarMaterias(nova, () => { renderListaMaterias(); renderPainelMateria(); });
        });
      });
    });
  });
}
function renderPainelMateria(){
  const painel = document.getElementById('mat-painel');
  if (!materiaAtivaId){
    painel.innerHTML = '<div class="mat-vazio">Escolha ou crie uma matéria ao lado.</div>';
    return;
  }
  carregarMaterias((lista) => {
    const materia = lista.find(m => m.id === materiaAtivaId);
    if (!materia){ painel.innerHTML = '<div class="mat-vazio">Escolha ou crie uma matéria ao lado.</div>'; return; }
    const notas = materia.notas || [];
    painel.innerHTML = `
      <h2>${escapeHtml(materia.nome)}</h2>
      <table class="mat-tabela">
        <thead><tr><th>Prova/Atividade</th><th>Data</th><th>Resultado</th><th></th></tr></thead>
        <tbody id="mat-notas-body">
          ${notas.map((n, i) => `
            <tr data-i="${i}">
              <td><input type="text" data-campo="titulo" value="${escapeHtml(n.titulo||'')}" placeholder="Ex: Prova 1"></td>
              <td><input type="text" data-campo="data" value="${escapeHtml(n.data||'')}" placeholder="dd/mm"></td>
              <td><input type="text" data-campo="resultado" value="${escapeHtml(n.resultado||'')}" placeholder="Ex: 8,5"></td>
              <td><button class="mat-nota-del" data-i="${i}" title="Remover linha">✕</button></td>
            </tr>`).join('')}
        </tbody>
      </table>
      <button class="mat-nota-add" id="mat-nota-add">+ adicionar linha</button>
      <div class="field" style="margin-top:16px;">
        <label>Anotações</label>
        <textarea class="mat-anotacoes" id="mat-anotacoes-txt" placeholder="Escreva aqui...">${escapeHtml(materia.anotacoes||'')}</textarea>
      </div>`;

    function atualizarMateria(mutador){
      carregarMaterias((atual) => {
        const idx = atual.findIndex(m => m.id === materiaAtivaId);
        if (idx === -1) return;
        mutador(atual[idx]);
        salvarMaterias(atual, () => {});
      });
    }

    painel.querySelectorAll('#mat-notas-body input').forEach((input) => {
      input.addEventListener('change', () => {
        const i = Number(input.closest('tr').dataset.i);
        const campo = input.dataset.campo;
        atualizarMateria((m) => { m.notas = m.notas || []; m.notas[i] = { ...m.notas[i], [campo]: input.value }; });
      });
    });
    painel.querySelectorAll('.mat-nota-del').forEach((btn) => {
      btn.addEventListener('click', () => {
        const i = Number(btn.dataset.i);
        atualizarMateria((m) => { m.notas = (m.notas||[]).filter((_, idx) => idx !== i); });
        renderPainelMateria();
      });
    });
    document.getElementById('mat-nota-add').addEventListener('click', () => {
      atualizarMateria((m) => { m.notas = m.notas || []; m.notas.push({ titulo:'', data:'', resultado:'' }); });
      renderPainelMateria();
    });
    document.getElementById('mat-anotacoes-txt').addEventListener('change', (e) => {
      atualizarMateria((m) => { m.anotacoes = e.target.value; });
    });
  });
}
function renderMaterias(){ renderListaMaterias(); renderPainelMateria(); }

document.getElementById('btn-add-materia').addEventListener('click', () => {
  const input = document.getElementById('mat-nova');
  const nome = input.value.trim();
  if (!nome) return;
  carregarMaterias((atual) => {
    const nova = { id: `mat_${Date.now()}_${Math.random().toString(36).slice(2,7)}`, nome, notas: [], anotacoes: '' };
    atual.push(nova);
    materiaAtivaId = nova.id;
    salvarMaterias(atual, () => {
      input.value = '';
      renderListaMaterias();
      renderPainelMateria();
    });
  });
});
setInterval(verificarAvisos, 20000);

chrome.storage.onChanged.addListener((changes, area) => {
  // Reage tanto a mudanças feitas por esta tela (cbCronogramaPorData) quanto
  // a blocos criados pelo popup ou pelo widget antigo (cbCronogramaHoje).
  if (area === 'local' && (changes.cbCronogramaPorData || changes.cbCronogramaHoje || changes.cbCronogramaData)){
    atualizarVisaoPeriodo();
    desenharSemana();
  }
});

/* ---------------- geração de cronograma com IA ----------------
   cbGerarCronogramaIA() vem de ia-cronograma.js: só chama a IA (Pollinations,
   sem chave/sem cadastro) quando a pessoa clica em "Gerar", nunca sozinho. */
(function(){
  const overlay = document.getElementById('ia-modal-overlay');
  const btnAbrir = document.getElementById('btn-ia-cronograma');
  const btnCancelar = document.getElementById('ia-cancelar');
  const btnGerar = document.getElementById('ia-gerar');
  const elErro = document.getElementById('ia-erro');
  if (!overlay || !btnAbrir) return;

  function abrirModal(){
    elErro.style.display = 'none';
    document.getElementById('ia-descricao').value = '';
    overlay.style.display = 'flex';
  }
  function fecharModal(){ overlay.style.display = 'none'; }
  function mostrarErro(msg){
    elErro.textContent = msg;
    elErro.style.display = 'block';
  }

  btnAbrir.addEventListener('click', abrirModal);
  btnCancelar.addEventListener('click', fecharModal);
  overlay.addEventListener('click', (e) => { if (e.target === overlay) fecharModal(); });

  btnGerar.addEventListener('click', () => {
    const descricao = document.getElementById('ia-descricao').value.trim();
    const inicioDisp = document.getElementById('ia-inicio').value;
    const fimDisp = document.getElementById('ia-fim').value;

    if (!descricao){ mostrarErro('Descreva o que você quer estudar.'); return; }
    if (!inicioDisp || !fimDisp || minutos(fimDisp) <= minutos(inicioDisp)){
      mostrarErro('Janela de horário inválida.');
      return;
    }

    btnGerar.disabled = true;
    btnGerar.textContent = 'Gerando...';
    elErro.style.display = 'none';

    carregarBlocosDoDia(dataSelecionada, (existentes) => {
      window.cbGerarCronogramaIA({ descricao, inicioDisp, fimDisp, blocosExistentes: existentes })
        .then((novos) => {
          if (!novos.length) throw new Error('A IA não retornou nenhum bloco válido.');
          const combinados = existentes.concat(novos);
          salvarBlocosDoDia(dataSelecionada, combinados, () => {
            render();
            desenharSemana();
            fecharModal();
          });
        })
        .catch((err) => mostrarErro(err.message || 'Erro ao gerar cronograma.'))
        .finally(() => {
          btnGerar.disabled = false;
          btnGerar.textContent = 'Gerar';
        });
    });
  });
})();
