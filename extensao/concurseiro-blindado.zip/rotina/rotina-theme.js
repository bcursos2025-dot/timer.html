// rotina-theme.js — aplica o tema salvo (themePref) nesta página o quanto
// antes, pra combinar com o resto da extensão (popup, dashboard etc.) e
// evitar piscar num tema errado antes do resto da página carregar.
// Precisa ser arquivo externo (não inline) por causa do CSP do Manifest V3.
(function () {
    try {
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            chrome.storage.local.get(['themePref'], function (r) {
                var pref = r.themePref || 'light';
                // "Automático" (ver popup.js/applyTheme) guarda "auto" literal
                // no themePref — Claro de dia, Escuro à noite (18h-6h). Resolve
                // pro tema real antes de aplicar; "auto" sozinho não bate com
                // nenhuma regra de CSS.
                if (pref === 'auto') {
                    var hora = new Date().getHours();
                    pref = (hora >= 18 || hora < 6) ? 'dark' : 'light';
                }
                document.documentElement.setAttribute('data-theme', pref);
            });
        }
    } catch (e) {}
})();
