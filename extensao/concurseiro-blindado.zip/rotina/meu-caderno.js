/* Toda a lógica do "Meu Caderno" (semestre, semanal, mensal, matérias,
   extras, resumos) morava num <script> inline dentro do meu-caderno.html.
   O CSP padrão do Manifest V3 bloqueia script inline em páginas da
   extensão, então nada aqui rodava de verdade — a página abria, mas
   ficava travada na tela de capa e nenhuma das páginas funcionava.
   Por isso o código foi movido pra este arquivo externo. */

/* ---------------- storage ---------------- */
const TEM_CHROME = (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local);
function storageGet(chave, padrao, cb){
  if (TEM_CHROME){ chrome.storage.local.get([chave], (r)=> cb(r[chave] !== undefined ? r[chave] : padrao)); }
  else { try{ const v = JSON.parse(localStorage.getItem(chave)); cb(v !== null && v !== undefined ? v : padrao); }catch(e){ cb(padrao); } }
}
function storageSet(chave, valor){
  if (TEM_CHROME){ chrome.storage.local.set({ [chave]: valor }); }
  else { localStorage.setItem(chave, JSON.stringify(valor)); }
}

/* ---------------- feriados nacionais ---------------- */
// Mesmo cálculo usado em "Organize o seu dia" (rotina-diaria.js) — sem
// API, funciona offline, qualquer ano. Datas móveis via algoritmo de Gauss.
function pad2(n){ return String(n).padStart(2,'0'); }
function toDateStr2(d){ return `${d.getFullYear()}-${pad2(d.getMonth()+1)}-${pad2(d.getDate())}`; }
function calcularPascoa(ano){
  const a = ano % 19, b = Math.floor(ano/100), c = ano % 100;
  const d = Math.floor(b/4), e = b % 4;
  const f = Math.floor((b+8)/25);
  const g = Math.floor((b-f+1)/3);
  const h = (19*a + b - d - g + 15) % 30;
  const i = Math.floor(c/4), k = c % 4;
  const l = (32 + 2*e + 2*i - h - k) % 7;
  const m = Math.floor((a + 11*h + 22*l)/451);
  const mes = Math.floor((h + l - 7*m + 114)/31);
  const dia = ((h + l - 7*m + 114) % 31) + 1;
  return new Date(ano, mes-1, dia);
}
const FERIADOS_CACHE = {};
function feriadosDoAno(ano){
  if (FERIADOS_CACHE[ano]) return FERIADOS_CACHE[ano];
  const pascoa = calcularPascoa(ano);
  const comOffset = (n)=>{ const d = new Date(pascoa); d.setDate(d.getDate()+n); return d; };
  const lista = [
    [new Date(ano,0,1), 'Confraternização Universal'],
    [comOffset(-47), 'Carnaval'], [comOffset(-46), 'Carnaval'],
    [comOffset(-2), 'Sexta-feira Santa'], [pascoa, 'Páscoa'],
    [new Date(ano,3,21), 'Tiradentes'], [new Date(ano,4,1), 'Dia do Trabalho'],
    [comOffset(60), 'Corpus Christi'], [new Date(ano,8,7), 'Independência do Brasil'],
    [new Date(ano,9,12), 'Nossa Senhora Aparecida'], [new Date(ano,10,2), 'Finados'],
    [new Date(ano,10,15), 'Proclamação da República'], [new Date(ano,10,20), 'Consciência Negra'],
    [new Date(ano,11,25), 'Natal']
  ];
  const mapa = {};
  lista.forEach(([d, nome])=>{ mapa[toDateStr2(d)] = nome; });
  FERIADOS_CACHE[ano] = mapa;
  return mapa;
}
function nomeFeriado(ds){ return feriadosDoAno(Number(ds.slice(0,4)))[ds] || null; }

let DADOS = {
  capaCor:'', elasticoCor:'', canetaCor:'', tituloCapa:'',
  semestres:{ '1':{ grade:{}, aulas:[] }, '2':{ grade:{}, aulas:[] } },
  semanas:{}, meses:{}, semanasLivres:{},
  materias:[], vocab:[], leituras:[], revisao:[], questoes:[], resumos:[], tabelasPersonalizadas:[]
};
function salvar(){ storageSet('meuCadernoDados', DADOS); }

/* ---------------- personalização da capa ---------------- */
/* Paleta discreta e sóbria — tons de tinta e couro, não pastel/candy. */
const CORES_CAPA = ['#5a4632','#6b5640','#3d4a45','#3d4a5c','#4a3d3a','#514630'];
const CORES_ELASTICO = ['#8a6f4e','#4b4f58','#7a8a92','#9c8a6b','#8a4b42','#c9c9c9'];
const CORES_CANETA = ['#4a3c28','#2f4858','#2b2b2b','#31563e','#6b2d3c','#7a5a2f'];

function montarSwatches(id, cores, aplicar){
  const wrap = document.getElementById(id);
  wrap.innerHTML = '';
  cores.forEach((cor)=>{
    const b = document.createElement('button');
    b.style.background = cor;
    b.addEventListener('click', ()=>{
      wrap.querySelectorAll('button').forEach(x=>x.classList.remove('ativo'));
      b.classList.add('ativo');
      aplicar(cor);
    });
    wrap.appendChild(b);
  });
}
function marcarAtivo(id, cores, valor){
  const wrap = document.getElementById(id);
  const idx = cores.indexOf(valor);
  const botoes = wrap.querySelectorAll('button');
  if (botoes[idx >= 0 ? idx : 0]) botoes[idx >= 0 ? idx : 0].classList.add('ativo');
}

montarSwatches('sw-capa', CORES_CAPA, (cor)=>{
  document.documentElement.style.setProperty('--capa-clara', cor);
  document.documentElement.style.setProperty('--capa-escura', ajustarCor(cor,-28));
  DADOS.capaCor = cor; salvar();
});
montarSwatches('sw-elastico', CORES_ELASTICO, (cor)=>{
  document.documentElement.style.setProperty('--elastico', cor);
  DADOS.elasticoCor = cor; salvar();
});
montarSwatches('sw-caneta', CORES_CANETA, (cor)=>{
  document.documentElement.style.setProperty('--caneta', cor);
  DADOS.canetaCor = cor; salvar();
});

/* ---------------- ilustração da capa ---------------- */
// Desenhos simples em traço branco translúcido, iguais em cima de
// qualquer cor de capa escolhida. "nenhuma" limpa a capa (padrão liso).
const ILUSTRACOES_CAPA = {
  nenhuma: '',
  bolinhas: `<svg viewBox="0 0 200 250"><circle cx="40" cy="50" r="6" fill="#fff"/><circle cx="100" cy="30" r="4" fill="#fff"/><circle cx="150" cy="70" r="8" fill="#fff"/><circle cx="60" cy="120" r="5" fill="#fff"/><circle cx="140" cy="140" r="6" fill="#fff"/><circle cx="30" cy="180" r="4" fill="#fff"/><circle cx="170" cy="190" r="7" fill="#fff"/><circle cx="90" cy="205" r="5" fill="#fff"/><circle cx="120" cy="90" r="3" fill="#fff"/><circle cx="170" cy="30" r="3" fill="#fff"/><circle cx="55" cy="230" r="4" fill="#fff"/></svg>`,
  paisagem: `<svg viewBox="0 0 200 250" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><circle cx="150" cy="55" r="16" fill="#fff" stroke="none"/><path d="M15 165 L65 100 L100 140 L135 85 L190 165 Z"/><line x1="10" y1="165" x2="195" y2="165"/></svg>`,
  floresta: `<svg viewBox="0 0 200 250" fill="none" stroke="#fff" stroke-width="3" stroke-linejoin="round"><path d="M35 175 L58 115 L81 175 Z"/><path d="M35 150 L58 95 L81 150 Z"/><path d="M88 185 L116 105 L144 185 Z"/><path d="M88 158 L116 85 L144 158 Z"/><path d="M150 175 L170 128 L190 175 Z"/><line x1="15" y1="185" x2="195" y2="185"/></svg>`,
  borboletas: `<svg viewBox="0 0 200 250" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><g transform="translate(65,85)"><path d="M0 0 C -22 -22 -32 0 -11 11 C -27 16 -16 32 0 16"/><path d="M0 0 C 22 -22 32 0 11 11 C 27 16 16 32 0 16"/><line x1="0" y1="-6" x2="0" y2="20"/></g><g transform="translate(135,155) scale(0.75)"><path d="M0 0 C -22 -22 -32 0 -11 11 C -27 16 -16 32 0 16"/><path d="M0 0 C 22 -22 32 0 11 11 C 27 16 16 32 0 16"/><line x1="0" y1="-6" x2="0" y2="20"/></g></svg>`,
  praia: `<svg viewBox="0 0 200 250" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round"><circle cx="100" cy="55" r="20" fill="#fff" stroke="none"/><path d="M15 140 Q 37 123 60 140 T 105 140 T 150 140 T 185 140"/><path d="M15 168 Q 37 151 60 168 T 105 168 T 150 168 T 185 168"/><path d="M15 196 Q 37 179 60 196 T 105 196 T 150 196 T 185 196"/></svg>`,
  cristo: `<svg viewBox="0 0 200 250" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round"><line x1="100" y1="62" x2="100" y2="152"/><line x1="52" y1="92" x2="148" y2="92"/><circle cx="100" cy="46" r="9" fill="#fff" stroke="none"/><path d="M35 195 Q100 155 165 195 L182 213 L18 213 Z" fill="#fff" stroke="none" opacity=".85"/></svg>`
};
const ILUSTRACOES_LABEL = { nenhuma:'Nenhuma', bolinhas:'Bolinhas', paisagem:'Paisagem', floresta:'Floresta', borboletas:'Borboletas', praia:'Praia', cristo:'Cristo Redentor' };
// glifo pequeno de cada opção, pro botão do seletor (não precisa ser o
// desenho inteiro, só uma referência simples do que é)
const ILUSTRACOES_ICONE = {
  nenhuma: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="4" y1="4" x2="20" y2="20"/><line x1="20" y1="4" x2="4" y2="20"/></svg>`,
  bolinhas: `<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="7" cy="7" r="2.2"/><circle cx="16" cy="6" r="1.6"/><circle cx="12" cy="14" r="2"/><circle cx="18" cy="16" r="1.6"/><circle cx="6" cy="17" r="1.4"/></svg>`,
  paisagem: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><circle cx="17" cy="6" r="2" fill="currentColor" stroke="none"/><path d="M3 18 L9 10 L13 14 L16 9 L21 18 Z"/></svg>`,
  floresta: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M5 19 L9 8 L13 19 Z"/><path d="M12 19 L16.5 6 L21 19 Z"/></svg>`,
  borboletas: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M12 12 C 6 4 3 12 9 13 C 4 16 8 21 12 15"/><path d="M12 12 C 18 4 21 12 15 13 C 20 16 16 21 12 15"/></svg>`,
  praia: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="7" r="2.4" fill="currentColor" stroke="none"/><path d="M3 14 Q6 11 9 14 T15 14 T21 14"/><path d="M3 19 Q6 16 9 19 T15 19 T21 19"/></svg>`,
  cristo: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="12" y1="6" x2="12" y2="16"/><line x1="7" y1="9" x2="17" y2="9"/><circle cx="12" cy="4" r="1.3" fill="currentColor" stroke="none"/></svg>`
};
function montarSeletorIlustracao(){
  const wrap = document.getElementById('il-row');
  wrap.innerHTML = Object.keys(ILUSTRACOES_CAPA).map(chave =>
    `<button type="button" data-il="${chave}" title="${ILUSTRACOES_LABEL[chave]}">${ILUSTRACOES_ICONE[chave]}</button>`
  ).join('');
  wrap.querySelectorAll('button').forEach(btn=>{
    btn.addEventListener('click', ()=> aplicarIlustracao(btn.dataset.il, true));
  });
}
function aplicarIlustracao(chave, persistir){
  const alvo = ILUSTRACOES_CAPA[chave] !== undefined ? chave : 'nenhuma';
  document.getElementById('capa-ilustracao').innerHTML = ILUSTRACOES_CAPA[alvo];
  document.querySelectorAll('#il-row button').forEach(b=> b.classList.toggle('ativo', b.dataset.il === alvo));
  if (persistir){ DADOS.capaIlustracao = alvo; salvar(); }
}
montarSeletorIlustracao();

function ajustarCor(hex, qtd){
  const n = parseInt(hex.slice(1),16);
  let r = Math.max(0,Math.min(255,(n>>16)+qtd));
  let g = Math.max(0,Math.min(255,((n>>8)&0xff)+qtd));
  let b = Math.max(0,Math.min(255,(n&0xff)+qtd));
  return '#'+((1<<24)+(r<<16)+(g<<8)+b).toString(16).slice(1);
}

const inTituloCapa = document.getElementById('in-titulo-capa');
const capaTituloTxt = document.getElementById('capa-titulo-txt');
inTituloCapa.addEventListener('input', ()=>{
  const v = inTituloCapa.value.trim();
  capaTituloTxt.innerHTML = v ? escapeHtml(v).replace(/\n/g,'<br>') : 'Meu caderno<br>de estudos';
  DADOS.tituloCapa = v; salvar();
});
function escapeHtml(s){ const d=document.createElement('div'); d.textContent=s; return d.innerHTML; }

/* ---------------- abrir/fechar caderno ---------------- */
const telaCapa = document.getElementById('tela-capa');
const app = document.getElementById('app');
document.getElementById('capa-livro').addEventListener('click', ()=>{
  telaCapa.classList.add('abrindo');
  setTimeout(()=>{ telaCapa.classList.add('escondida'); app.classList.add('aberto'); }, 650);
});
document.getElementById('btn-fechar').addEventListener('click', ()=>{
  // Sem tela de capa pra "voltar", fechar o caderno agora fecha a própria
  // aba (o caderno abre em aba própria — ver abrir-meu-caderno.js).
  window.close();
});
document.querySelectorAll('.btn-imprimir-pagina').forEach(btn=>{
  btn.addEventListener('click', ()=> window.print());
});

/* ---------------- abas ---------------- */
document.querySelectorAll('.aba').forEach(aba=>{
  aba.addEventListener('click', ()=>{
    if (aba.classList.contains('ativa')) return;
    const novaPagina = document.getElementById(aba.dataset.pagina);
    const paginaAtual = document.querySelector('.pagina.ativa');
    if (!novaPagina || novaPagina === paginaAtual) return;

    document.querySelectorAll('.aba').forEach(a=>a.classList.remove('ativa'));
    aba.classList.add('ativa');

    const reduzMovimento = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!paginaAtual || reduzMovimento){
      if (paginaAtual) paginaAtual.classList.remove('ativa');
      novaPagina.classList.add('ativa');
      return;
    }
    // pequena animação de "virar a folha": a página atual gira e desaparece,
    // a nova entra girando do lado oposto — como se uma folha do caderno
    // estivesse sendo virada.
    paginaAtual.classList.add('pagina-sai');
    setTimeout(()=>{
      paginaAtual.classList.remove('ativa','pagina-sai');
      novaPagina.classList.add('ativa','pagina-entra');
      setTimeout(()=> novaPagina.classList.remove('pagina-entra'), 320);
    }, 210);
  });
});

/* ---------------- espiral metálica (capa + lombada do caderno aberto) ---------------- */
function montarEspiral(elId, altura){
  const el = document.getElementById(elId);
  if (!el) return;
  const n = Math.max(6, Math.round(altura / 34));
  el.innerHTML = Array.from({length:n}).map(()=>'<div class="anel"></div>').join('');
}
montarEspiral('capa-espiral', document.getElementById('capa-livro').getBoundingClientRect().height || 420);
function montarLombada(){ montarEspiral('lombada', window.innerHeight); }
montarLombada();
window.addEventListener('resize', montarLombada);

/* ================= VISÃO SEMESTRAL ================= */
const DIAS5 = ['SEG','TER','QUA','QUI','SEX'];
const HORAS_SEM = ['07h','08h','09h','10h','11h','13h','14h','15h','16h','17h','18h','19h','20h'];
let semestreAtual = '1';
function renderGradeSemestre(){
  const tbl = document.getElementById('grade-semestre');
  const dados = DADOS.semestres[semestreAtual].grade;
  let html = '<tr><th></th>'+DIAS5.map(d=>`<th>${d}</th>`).join('')+'</tr>';
  HORAS_SEM.forEach(h=>{
    html += `<tr><td class="hora">${h}</td>`;
    DIAS5.forEach(d=>{
      const chave = h+'_'+d;
      html += `<td><textarea data-chave="${chave}">${dados[chave]||''}</textarea></td>`;
    });
    html += '</tr>';
  });
  tbl.innerHTML = html;
  tbl.querySelectorAll('textarea').forEach(ta=>{
    ta.addEventListener('input', ()=>{ dados[ta.dataset.chave] = ta.value; salvar(); });
  });
}
document.getElementById('sem-toggle').addEventListener('click', (e)=>{
  const btn = e.target.closest('button'); if(!btn) return;
  document.querySelectorAll('#sem-toggle button').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  semestreAtual = btn.dataset.sem;
  renderGradeSemestre(); renderAulas();
});
function renderAulas(){
  const wrap = document.getElementById('lista-aulas');
  const aulas = DADOS.semestres[semestreAtual].aulas;
  wrap.innerHTML = aulas.map((a,i)=>`<input type="text" data-i="${i}" value="${escapeHtml(a)}">`).join('') || '<span class="vazio">Nenhuma aula ainda.</span>';
  wrap.querySelectorAll('input').forEach(inp=>{
    inp.addEventListener('input', ()=>{ aulas[inp.dataset.i]=inp.value; salvar(); });
  });
}
document.getElementById('btn-add-aula').addEventListener('click', ()=>{
  const inp = document.getElementById('in-aula');
  if(!inp.value.trim()) return;
  DADOS.semestres[semestreAtual].aulas.push(inp.value.trim());
  inp.value=''; salvar(); renderAulas();
});

/* ================= VISÃO SEMANAL ================= */
const DIAS7 = ['SEG','TER','QUA','QUI','SEX','SÁB','DOM'];
const HORAS_SEMANA = ['06h','07h','08h','09h','10h','11h','12h','13h','14h','15h','16h','17h','18h','19h','20h','21h'];
let semanaRef = new Date();
function chaveSemana(d){
  const seg = new Date(d); const dia = seg.getDay(); const diff = (dia===0?-6:1-dia);
  seg.setDate(seg.getDate()+diff);
  return toDateStr2(seg);
}
function garantirSemana(chave){
  if(!DADOS.semanas[chave]) DADOS.semanas[chave] = { grade:{}, prioridades:[], habitos:[] };
  return DADOS.semanas[chave];
}

/* ---------------- sincronização com "Organize o seu dia" ---------------- */
// Cada célula preenchida na grade Semanal do caderno vira um bloco de 1h
// na agenda de "Organize o seu dia" (rotina-diaria.html), guardada no
// mesmo formato que aquela tela já usa (chrome.storage.local, chave
// cbCronogramaPorData). O id de cada bloco sincronizado é determinístico
// (a partir da data+hora), então editar uma célula atualiza o mesmo bloco
// em vez de duplicar, e apagar o texto remove o bloco de lá também.
// Blocos criados manualmente em "Organize o seu dia" (id sem esse prefixo)
// nunca são tocados por essa sincronização.
const PREFIXO_SYNC = 'caderno_sync_';
function idSyncBloco(dataStr, hora){ return `${PREFIXO_SYNC}${dataStr}_${hora}`; }

function dataDaCelula(chaveMonday, diaAbr){
  const idx = DIAS7.indexOf(diaAbr);
  const seg = new Date(chaveMonday + 'T00:00:00Z');
  seg.setUTCDate(seg.getUTCDate() + idx);
  return seg.toISOString().slice(0,10);
}

// Reescreve de uma vez só (um único get + um único set) todos os blocos
// sincronizados da semana em questão, a partir do estado atual da grade —
// evita condição de corrida que existiria se cada célula lesse/gravasse o
// storage de forma independente e em paralelo.
function sincronizarSemanaInteira(chaveMonday, grade){
  if (!TEM_CHROME) return;
  const porDia = {}; // dataStr -> { "08:00": "texto da célula", ... }
  Object.keys(grade).forEach(chaveCel=>{
    const [hLabel, diaAbr] = chaveCel.split('_');
    const dataStr = dataDaCelula(chaveMonday, diaAbr);
    const horaStr = hLabel.replace('h', ':00');
    if (!porDia[dataStr]) porDia[dataStr] = {};
    porDia[dataStr][horaStr] = grade[chaveCel];
  });

  chrome.storage.local.get(['cbCronogramaPorData'], (res)=>{
    const porData = res.cbCronogramaPorData ? {...res.cbCronogramaPorData} : {};
    Object.keys(porDia).forEach(dataStr=>{
      const horas = porDia[dataStr];
      const prefixoData = `${PREFIXO_SYNC}${dataStr}_`;
      let lista = (porData[dataStr] || []).filter(b => !String(b.id||'').startsWith(prefixoData));
      Object.keys(horas).forEach(horaStr=>{
        const valor = (horas[horaStr] || '').trim();
        if (!valor) return;
        const hNum = Number(horaStr.slice(0,2));
        const fim = `${String((hNum+1)%24).padStart(2,'0')}:00`;
        lista.push({
          id: idSyncBloco(dataStr, horaStr), inicio: horaStr, fim,
          tipo:'outro', materia: valor, camera:false, prioridade:'media',
          aviso:true, concluido:false
        });
      });
      porData[dataStr] = lista;
    });
    // "Organize o seu dia" e o resto da extensão (o preview no painel
    // inicial, o bloqueio de distrações) ainda leem o dia de HOJE também
    // das chaves antigas (cbCronogramaHoje/cbCronogramaData) — sem isso, o
    // que é digitado aqui no caderno não aparecia lá enquanto fosse hoje.
    const hojeStrCaderno = (()=>{ const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; })();
    const patch = { cbCronogramaPorData: porData };
    if (porData[hojeStrCaderno]){
      patch.cbCronogramaHoje = porData[hojeStrCaderno];
      patch.cbCronogramaData = hojeStrCaderno;
    }
    chrome.storage.local.set(patch, ()=>{
      chrome.runtime.sendMessage({ action: 'cronogramaAtualizado' }).catch(()=>{});
    });
  });
}

let timerSyncSemana = null;
function agendarSincronizacaoSemana(){
  if (!TEM_CHROME) return;
  clearTimeout(timerSyncSemana);
  const chave = chaveSemana(semanaRef);
  timerSyncSemana = setTimeout(()=>{
    sincronizarSemanaInteira(chave, garantirSemana(chave).grade);
  }, 500);
}

function renderSemanal(){
  const chave = chaveSemana(semanaRef);
  const dados = garantirSemana(chave);
  const seg = new Date(chave);
  const dom = new Date(seg); dom.setDate(dom.getDate()+6);
  document.getElementById('semanal-label').textContent =
    seg.toLocaleDateString('pt-BR',{day:'2-digit',month:'short'}) + ' – ' + dom.toLocaleDateString('pt-BR',{day:'2-digit',month:'short'});

  const tbl = document.getElementById('grade-semanal');
  let html = '<tr><th></th>'+DIAS7.map(d=>{
    const dsCol = dataDaCelula(chave, d);
    const fer = nomeFeriado(dsCol);
    return `<th${fer?` style="color:#c43c32;" title="${fer}"`:''}>${d}${fer?' •':''}</th>`;
  }).join('')+'</tr>';
  HORAS_SEMANA.forEach(h=>{
    html += `<tr><td class="hora">${h}</td>`;
    DIAS7.forEach(d=>{
      const chaveCel = h+'_'+d;
      html += `<td><textarea data-chave="${chaveCel}">${dados.grade[chaveCel]||''}</textarea></td>`;
    });
    html += '</tr>';
  });
  tbl.innerHTML = html;
  tbl.querySelectorAll('textarea').forEach(ta=>{
    ta.addEventListener('input', ()=>{
      dados.grade[ta.dataset.chave]=ta.value; salvar();
      agendarSincronizacaoSemana();
    });
  });
  // também sincroniza ao simplesmente abrir/navegar pra essa semana, pra
  // capturar células preenchidas antes dessa sincronização existir.
  agendarSincronizacaoSemana();

  const listaP = document.getElementById('lista-prioridades');
  listaP.innerHTML = dados.prioridades.map((p,i)=>`<input type="text" data-i="${i}" value="${escapeHtml(p)}">`).join('') || '<span class="vazio">Nenhuma prioridade ainda.</span>';
  listaP.querySelectorAll('input').forEach(inp=> inp.addEventListener('input', ()=>{ dados.prioridades[inp.dataset.i]=inp.value; salvar(); }));

  const habitWrap = document.getElementById('habit-tracker');
  habitWrap.innerHTML = dados.habitos.map((h,i)=>`
    <div style="margin-bottom:8px;">
      <div style="font-size:12.5px;font-weight:700;font-family:'Kalam',cursive;margin-bottom:4px;">${escapeHtml(h.nome)}</div>
      <div style="display:flex;gap:5px;">
        ${DIAS7.map((d,j)=>`<button class="marca-habito ${h.marcados[j]?'on':''}" data-hi="${i}" data-di="${j}" style="width:22px;height:22px;border-radius:50%;border:1px solid var(--papel-linha);background:${h.marcados[j]?'var(--caneta)':'transparent'};cursor:pointer;"></button>`).join('')}
      </div>
    </div>`).join('') || '<span class="vazio">Nenhum hábito ainda.</span>';
  habitWrap.querySelectorAll('.marca-habito').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const hi=btn.dataset.hi, di=btn.dataset.di;
      dados.habitos[hi].marcados[di] = !dados.habitos[hi].marcados[di];
      salvar(); renderSemanal();
    });
  });
}
document.getElementById('sem-prev').addEventListener('click', ()=>{ semanaRef.setDate(semanaRef.getDate()-7); renderSemanal(); });
document.getElementById('sem-next').addEventListener('click', ()=>{ semanaRef.setDate(semanaRef.getDate()+7); renderSemanal(); });
document.getElementById('btn-add-prioridade').addEventListener('click', ()=>{
  const inp = document.getElementById('in-prioridade'); if(!inp.value.trim()) return;
  garantirSemana(chaveSemana(semanaRef)).prioridades.push(inp.value.trim());
  inp.value=''; salvar(); renderSemanal();
});
document.getElementById('btn-add-habito').addEventListener('click', ()=>{
  const inp = document.getElementById('in-habito'); if(!inp.value.trim()) return;
  garantirSemana(chaveSemana(semanaRef)).habitos.push({ nome:inp.value.trim(), marcados:[false,false,false,false,false,false,false] });
  inp.value=''; salvar(); renderSemanal();
});

/* ================= VISÃO MENSAL ================= */
let mesRef = new Date(); mesRef.setDate(1);
function chaveMes(d){ return d.getFullYear()+'-'+(d.getMonth()+1); }
function garantirMes(chave){
  if(!DADOS.meses[chave]) DADOS.meses[chave] = { dias:{}, prioridades:[], provas:[], todo:[], anotacoes:'' };
  return DADOS.meses[chave];
}
function renderMensal(){
  const chave = chaveMes(mesRef);
  const dados = garantirMes(chave);
  document.getElementById('mensal-label').textContent = mesRef.toLocaleDateString('pt-BR',{month:'long',year:'numeric'});

  const primeiroDia = new Date(mesRef.getFullYear(), mesRef.getMonth(), 1);
  const ultimoDia = new Date(mesRef.getFullYear(), mesRef.getMonth()+1, 0);
  let offset = primeiroDia.getDay(); offset = offset===0?6:offset-1; // segunda=0
  const totalDias = ultimoDia.getDate();
  const celulas = [];
  for(let i=0;i<offset;i++) celulas.push(null);
  for(let d=1; d<=totalDias; d++) celulas.push(d);
  while(celulas.length % 7 !== 0) celulas.push(null);

  const tbl = document.getElementById('grade-mensal');
  let html = '<tr>'+DIAS7.slice(0,7).map(d=>`<th>${d}</th>`).join('')+'</tr>';
  for(let i=0;i<celulas.length;i+=7){
    html += '<tr>';
    for(let j=i;j<i+7;j++){
      const dia = celulas[j];
      if(dia===null){ html += '<td></td>'; continue; }
      const dsCel = `${mesRef.getFullYear()}-${pad2(mesRef.getMonth()+1)}-${pad2(dia)}`;
      const fer = nomeFeriado(dsCel);
      html += `<td style="vertical-align:top;${fer?'background:rgba(196,60,50,.06);':''}"><div style="font-size:10px;color:${fer?'#c43c32':'var(--muted)'};padding:3px 4px 0;font-weight:${fer?'700':'400'};" ${fer?`title="${fer}"`:''}>${dia}${fer?' •':''}</div><textarea data-dia="${dia}" style="height:46px;">${dados.dias[dia]||''}</textarea></td>`;
    }
    html += '</tr>';
  }
  tbl.innerHTML = html;
  tbl.querySelectorAll('textarea').forEach(ta=>{
    ta.addEventListener('input', ()=>{ dados.dias[ta.dataset.dia]=ta.value; salvar(); });
  });

  renderListaSimples('lista-mes-prioridades', dados.prioridades);
  renderListaSimples('lista-mes-provas', dados.provas);
  renderListaSimples('lista-mes-todo', dados.todo);
  const ta = document.getElementById('mes-anotacoes');
  ta.value = dados.anotacoes || '';
  ta.oninput = ()=>{ dados.anotacoes = ta.value; salvar(); };
}
function renderListaSimples(id, arr){
  const wrap = document.getElementById(id);
  wrap.innerHTML = arr.map((v,i)=>`<input type="text" data-i="${i}" value="${escapeHtml(v)}">`).join('') || '<span class="vazio">Vazio.</span>';
  wrap.querySelectorAll('input').forEach(inp=> inp.addEventListener('input', ()=>{ arr[inp.dataset.i]=inp.value; salvar(); }));
}
document.getElementById('mes-prev').addEventListener('click', ()=>{ mesRef.setMonth(mesRef.getMonth()-1); renderMensal(); });
document.getElementById('mes-next').addEventListener('click', ()=>{ mesRef.setMonth(mesRef.getMonth()+1); renderMensal(); });
document.getElementById('btn-add-mes-prioridade').addEventListener('click', ()=>{
  const inp=document.getElementById('in-mes-prioridade'); if(!inp.value.trim())return;
  garantirMes(chaveMes(mesRef)).prioridades.push(inp.value.trim()); inp.value=''; salvar(); renderMensal();
});
document.getElementById('btn-add-mes-prova').addEventListener('click', ()=>{
  const inp=document.getElementById('in-mes-prova'); if(!inp.value.trim())return;
  garantirMes(chaveMes(mesRef)).provas.push(inp.value.trim()); inp.value=''; salvar(); renderMensal();
});
document.getElementById('btn-add-mes-todo').addEventListener('click', ()=>{
  const inp=document.getElementById('in-mes-todo'); if(!inp.value.trim())return;
  garantirMes(chaveMes(mesRef)).todo.push(inp.value.trim()); inp.value=''; salvar(); renderMensal();
});

/* ================= MATÉRIAS ================= */
let materiaAtiva = -1;
function renderMaterias(){
  const wrap = document.getElementById('mat-lista-itens');
  wrap.innerHTML = DADOS.materias.map((m,i)=>`
    <div class="mat-item ${i===materiaAtiva?'ativa':''}" data-i="${i}">
      <span>${escapeHtml(m.nome)}</span><button class="del" data-i="${i}">✕</button>
    </div>`).join('') || '<span class="vazio">Nenhuma matéria ainda.</span>';
  wrap.querySelectorAll('.mat-item').forEach(el=>{
    el.addEventListener('click', (e)=>{
      if(e.target.classList.contains('del')) return;
      materiaAtiva = Number(el.dataset.i); renderMaterias(); renderPainelMateria();
    });
  });
  wrap.querySelectorAll('.del').forEach(b=>{
    b.addEventListener('click', ()=>{
      DADOS.materias.splice(Number(b.dataset.i),1);
      if(materiaAtiva>=DADOS.materias.length) materiaAtiva=DADOS.materias.length-1;
      salvar(); renderMaterias(); renderPainelMateria();
    });
  });
}
function renderPainelMateria(){
  const painel = document.getElementById('mat-painel');
  if(materiaAtiva<0 || !DADOS.materias[materiaAtiva]){
    painel.innerHTML = '<div class="vazio">Escolha ou crie uma matéria ao lado.</div>'; return;
  }
  const m = DADOS.materias[materiaAtiva];
  painel.innerHTML = `
    <h2 style="font-family:'Kalam',cursive;font-size:22px;margin-bottom:14px;">${escapeHtml(m.nome)}</h2>
    <div class="card-title">Controle de notas</div>
    <table class="tabela-simples" id="tabela-notas-mat">
      <thead><tr><th>Prova/Atividade</th><th style="width:14%">Data</th><th style="width:16%">Objetivo</th><th style="width:16%">Resultado</th><th></th></tr></thead>
      <tbody>${(m.notas||[]).map((n,i)=>`
        <tr>
          <td><input data-campo="prova" data-i="${i}" value="${escapeHtml(n.prova||'')}"></td>
          <td><input data-campo="data" data-i="${i}" value="${escapeHtml(n.data||'')}"></td>
          <td><input data-campo="objetivo" data-i="${i}" value="${escapeHtml(n.objetivo||'')}"></td>
          <td><input data-campo="resultado" data-i="${i}" value="${escapeHtml(n.resultado||'')}"></td>
          <td><button class="del-linha" data-i="${i}">✕</button></td>
        </tr>`).join('')}</tbody>
    </table>
    <button class="add-linha" id="btn-add-nota-mat">+ adicionar linha</button>
    <div class="card-title" style="margin-top:16px;">Anotações</div>
    <textarea class="anotacoes" id="mat-anotacoes-txt">${m.anotacoes||''}</textarea>
  `;
  painel.querySelectorAll('#tabela-notas-mat input').forEach(inp=>{
    inp.addEventListener('input', ()=>{ m.notas[inp.dataset.i][inp.dataset.campo]=inp.value; salvar(); });
  });
  painel.querySelectorAll('.del-linha').forEach(b=>{
    b.addEventListener('click', ()=>{ m.notas.splice(Number(b.dataset.i),1); salvar(); renderPainelMateria(); });
  });
  document.getElementById('btn-add-nota-mat').addEventListener('click', ()=>{
    if(!m.notas) m.notas=[]; m.notas.push({prova:'',data:'',objetivo:'',resultado:''}); salvar(); renderPainelMateria();
  });
  document.getElementById('mat-anotacoes-txt').addEventListener('input', (e)=>{ m.anotacoes=e.target.value; salvar(); });
}
document.getElementById('btn-add-mat').addEventListener('click', ()=>{
  const inp = document.getElementById('in-mat'); if(!inp.value.trim()) return;
  DADOS.materias.push({ nome:inp.value.trim(), notas:[], anotacoes:'' });
  materiaAtiva = DADOS.materias.length-1;
  inp.value=''; salvar(); renderMaterias(); renderPainelMateria();
});

/* ================= EXTRAS ================= */
document.getElementById('extras-toggle').addEventListener('click', (e)=>{
  const btn = e.target.closest('button'); if(!btn) return;
  document.querySelectorAll('#extras-toggle button').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('.extra-pag').forEach(p=>p.style.display='none');
  const chave = btn.dataset.extra;
  const mapa = { vocab:'extra-vocab', leituras:'extra-leituras', revisao:'extra-revisao', questoes:'extra-questoes' };
  document.getElementById(mapa[chave]).style.display='block';
  document.getElementById('extras-titulo').textContent = btn.textContent;
});

function renderVocab(){
  const tbody = document.querySelector('#tabela-vocab tbody');
  tbody.innerHTML = DADOS.vocab.map((v,i)=>`
    <tr>
      <td><input data-campo="palavra" data-i="${i}" value="${escapeHtml(v.palavra||'')}"></td>
      <td><input data-campo="traducao" data-i="${i}" value="${escapeHtml(v.traducao||'')}"></td>
      <td><input data-campo="sinonimos" data-i="${i}" value="${escapeHtml(v.sinonimos||'')}"></td>
      <td><button class="del-linha" data-i="${i}">✕</button></td>
    </tr>`).join('') || `<tr><td colspan="4" class="vazio">Nenhuma palavra ainda.</td></tr>`;
  tbody.querySelectorAll('input').forEach(inp=> inp.addEventListener('input', ()=>{ DADOS.vocab[inp.dataset.i][inp.dataset.campo]=inp.value; salvar(); }));
  tbody.querySelectorAll('.del-linha').forEach(b=> b.addEventListener('click', ()=>{ DADOS.vocab.splice(Number(b.dataset.i),1); salvar(); renderVocab(); }));
}
document.getElementById('btn-add-vocab').addEventListener('click', ()=>{ DADOS.vocab.push({palavra:'',traducao:'',sinonimos:''}); salvar(); renderVocab(); });

function renderLeituras(){
  const wrap = document.getElementById('lista-leituras');
  wrap.innerHTML = DADOS.leituras.map((l,i)=>`
    <div style="display:flex;align-items:center;gap:10px;border-bottom:1px solid var(--papel-linha);padding:6px 0;">
      <input type="text" data-i="${i}" value="${escapeHtml(l.titulo||'')}" style="flex:1;border:none;background:transparent;font-family:'Kalam',cursive;font-size:14px;">
      <div class="estrelas" data-i="${i}">${[1,2,3,4,5].map(n=>`<button data-n="${n}" class="${(l.nota||0)>=n?'on':''}">★</button>`).join('')}</div>
      <button class="del-linha" data-i="${i}">✕</button>
    </div>`).join('') || '<span class="vazio">Nenhuma leitura ainda.</span>';
  wrap.querySelectorAll('input[type=text]').forEach(inp=> inp.addEventListener('input', ()=>{ DADOS.leituras[inp.dataset.i].titulo=inp.value; salvar(); }));
  wrap.querySelectorAll('.estrelas').forEach(est=>{
    est.querySelectorAll('button').forEach(b=>{
      b.addEventListener('click', ()=>{ DADOS.leituras[est.dataset.i].nota = Number(b.dataset.n); salvar(); renderLeituras(); });
    });
  });
  wrap.querySelectorAll('.del-linha').forEach(b=> b.addEventListener('click', ()=>{ DADOS.leituras.splice(Number(b.dataset.i),1); salvar(); renderLeituras(); }));
}
document.getElementById('btn-add-leitura').addEventListener('click', ()=>{
  const inp=document.getElementById('in-leitura'); if(!inp.value.trim())return;
  DADOS.leituras.push({titulo:inp.value.trim(),nota:0}); inp.value=''; salvar(); renderLeituras();
});

function renderRevisao(){
  const wrap = document.getElementById('lista-revisao');
  wrap.innerHTML = DADOS.revisao.map((r,i)=>`
    <div class="revisao-linha">
      <input type="text" data-i="${i}" value="${escapeHtml(r.assunto||'')}">
      ${[0,1,2,3,4,5,6].map(j=>`<button class="marca ${r.marcas[j]?'on':''}" data-i="${i}" data-j="${j}"></button>`).join('')}
      <button class="del-linha" data-i="${i}">✕</button>
    </div>`).join('') || '<span class="vazio">Nenhum assunto ainda.</span>';
  wrap.querySelectorAll('input[type=text]').forEach(inp=> inp.addEventListener('input', ()=>{ DADOS.revisao[inp.dataset.i].assunto=inp.value; salvar(); }));
  wrap.querySelectorAll('.marca').forEach(b=>{
    b.addEventListener('click', ()=>{
      DADOS.revisao[b.dataset.i].marcas[b.dataset.j] = !DADOS.revisao[b.dataset.i].marcas[b.dataset.j];
      salvar(); renderRevisao();
    });
  });
  wrap.querySelectorAll('.del-linha').forEach(b=> b.addEventListener('click', ()=>{ DADOS.revisao.splice(Number(b.dataset.i),1); salvar(); renderRevisao(); }));
}
document.getElementById('btn-add-revisao').addEventListener('click', ()=>{
  const inp=document.getElementById('in-revisao'); if(!inp.value.trim())return;
  DADOS.revisao.push({assunto:inp.value.trim(), marcas:[false,false,false,false,false,false,false]});
  inp.value=''; salvar(); renderRevisao();
});

function renderQuestoes(){
  const tbody = document.querySelector('#tabela-questoes tbody');
  tbody.innerHTML = DADOS.questoes.map((q,i)=>`
    <tr>
      <td><input data-campo="dia" data-i="${i}" value="${escapeHtml(q.dia||'')}"></td>
      <td><input data-campo="disciplina" data-i="${i}" value="${escapeHtml(q.disciplina||'')}"></td>
      <td><input data-campo="acertos" data-i="${i}" value="${escapeHtml(q.acertos||'')}"></td>
      <td><input data-campo="erros" data-i="${i}" value="${escapeHtml(q.erros||'')}"></td>
      <td><button class="del-linha" data-i="${i}">✕</button></td>
    </tr>`).join('') || `<tr><td colspan="5" class="vazio">Nenhum registro ainda.</td></tr>`;
  tbody.querySelectorAll('input').forEach(inp=> inp.addEventListener('input', ()=>{ DADOS.questoes[inp.dataset.i][inp.dataset.campo]=inp.value; salvar(); }));
  tbody.querySelectorAll('.del-linha').forEach(b=> b.addEventListener('click', ()=>{ DADOS.questoes.splice(Number(b.dataset.i),1); salvar(); renderQuestoes(); }));
}
document.getElementById('btn-add-questao').addEventListener('click', ()=>{ DADOS.questoes.push({dia:'',disciplina:'',acertos:'',erros:''}); salvar(); renderQuestoes(); });

/* ================= FICHA DE RESUMOS ================= */
let fichaAtiva = -1;
function renderFichaTabs(){
  const wrap = document.getElementById('ficha-tabs');
  wrap.innerHTML = DADOS.resumos.map((f,i)=>`
    <div class="ficha-tab ${i===fichaAtiva?'ativa':''}" data-i="${i}">${escapeHtml(f.titulo||'Sem título')} <span class="x" data-del="${i}">✕</span></div>
  `).join('') || '<span class="vazio">Nenhuma ficha ainda.</span>';
  wrap.querySelectorAll('.ficha-tab').forEach(el=>{
    el.addEventListener('click', (e)=>{
      if(e.target.dataset.del !== undefined){
        DADOS.resumos.splice(Number(e.target.dataset.del),1);
        if(fichaAtiva>=DADOS.resumos.length) fichaAtiva=DADOS.resumos.length-1;
        salvar(); renderFichaTabs(); renderFichaCorpo(); return;
      }
      fichaAtiva = Number(el.dataset.i); renderFichaTabs(); renderFichaCorpo();
    });
  });
}
function renderFichaCorpo(){
  const corpo = document.getElementById('ficha-corpo');
  if(fichaAtiva<0 || !DADOS.resumos[fichaAtiva]){ corpo.innerHTML = '<div class="vazio">Crie uma nova ficha acima.</div>'; return; }
  const f = DADOS.resumos[fichaAtiva];
  corpo.innerHTML = `
    <input class="ficha-titulo-input" id="ficha-titulo" value="${escapeHtml(f.titulo||'')}" placeholder="Título da ficha">
    <textarea class="anotacoes" id="ficha-texto" style="min-height:260px;">${f.texto||''}</textarea>
  `;
  document.getElementById('ficha-titulo').addEventListener('input', (e)=>{ f.titulo=e.target.value; salvar(); renderFichaTabs(); });
  document.getElementById('ficha-texto').addEventListener('input', (e)=>{ f.texto=e.target.value; salvar(); });
}
document.getElementById('btn-add-ficha').addEventListener('click', ()=>{
  DADOS.resumos.push({titulo:'Nova ficha', texto:''});
  fichaAtiva = DADOS.resumos.length-1; salvar(); renderFichaTabs(); renderFichaCorpo();
});

/* ================= TABELAS PERSONALIZADAS (sem datas) =================
   Uma "planilha" livre: a pessoa define as colunas e vai adicionando
   linhas, sem nenhuma data amarrada — serve pra qualquer controle que não
   se encaixe nas outras páginas (lista de material, controle de gastos,
   check-list de edital, o que for). Pode ter várias tabelas, cada uma
   com seu próprio título, trocadas pelas abas em cima — mesmo padrão da
   Ficha de Resumos. */
let tabelaAtiva = -1;
function novaTabelaPadrao(){
  return { titulo: 'Nova tabela', colunas: ['Tarefa'], linhas: [['']], concluidas: [false] };
}
function renderTabelasTabs(){
  const wrap = document.getElementById('tabelas-tabs');
  wrap.innerHTML = DADOS.tabelasPersonalizadas.map((t,i)=>`
    <div class="ficha-tab ${i===tabelaAtiva?'ativa':''}" data-i="${i}">${escapeHtml(t.titulo||'Sem título')} <span class="x" data-del="${i}">✕</span></div>
  `).join('') || '<span class="vazio">Nenhuma tabela ainda.</span>';
  wrap.querySelectorAll('.ficha-tab').forEach(el=>{
    el.addEventListener('click', (e)=>{
      if(e.target.dataset.del !== undefined){
        DADOS.tabelasPersonalizadas.splice(Number(e.target.dataset.del),1);
        if(tabelaAtiva>=DADOS.tabelasPersonalizadas.length) tabelaAtiva=DADOS.tabelasPersonalizadas.length-1;
        salvar(); renderTabelasTabs(); renderTabelaCorpo(); return;
      }
      tabelaAtiva = Number(el.dataset.i); renderTabelasTabs(); renderTabelaCorpo();
    });
  });
}
function renderTabelaCorpo(){
  const corpo = document.getElementById('tabela-corpo');
  if (tabelaAtiva<0 || !DADOS.tabelasPersonalizadas[tabelaAtiva]){
    corpo.innerHTML = '<div class="vazio">Crie uma nova tabela acima.</div>';
    return;
  }
  const t = DADOS.tabelasPersonalizadas[tabelaAtiva];
  if (!t.concluidas) t.concluidas = t.linhas.map(()=> false); // compatibilidade com tabelas criadas antes dessa opção

  const cabecalho = t.colunas.map((col,ci)=>`
    <th>
      <input type="text" data-col="${ci}" value="${escapeHtml(col)}" placeholder="Coluna ${ci+1}">
      <button class="tl-col-del" data-col-del="${ci}" title="Remover coluna">✕</button>
    </th>`).join('');

  const linhas = t.linhas.map((linha,ri)=>`
    <tr class="${t.concluidas[ri] ? 'tl-concluida' : ''}">
      <td class="tl-td-check"><input type="checkbox" class="tl-check" data-row-check="${ri}" ${t.concluidas[ri] ? 'checked' : ''} title="Marcar como concluída"></td>
      ${t.colunas.map((_,ci)=>`<td><input type="text" data-row="${ri}" data-col="${ci}" value="${escapeHtml(linha[ci]||'')}"></td>`).join('')}
      <td class="tl-td-del"><button class="tl-row-del" data-row-del="${ri}" title="Remover linha">✕</button></td>
    </tr>`).join('');

  corpo.innerHTML = `
    <input class="ficha-titulo-input" id="tabela-titulo" value="${escapeHtml(t.titulo||'')}" placeholder="Título da tabela">
    <div class="tl-toolbar">
      <button class="add-linha" id="btn-add-coluna">+ coluna</button>
      <button class="add-linha" id="btn-add-tl-linha">+ linha</button>
    </div>
    <div class="tl-editor">
      <table class="tl-tabela">
        <thead><tr><th class="tl-th-vazio"></th>${cabecalho}<th class="tl-th-vazio"></th></tr></thead>
        <tbody>${linhas || `<tr><td colspan="${t.colunas.length+2}" class="vazio">Nenhuma linha ainda.</td></tr>`}</tbody>
      </table>
    </div>
  `;

  document.getElementById('tabela-titulo').addEventListener('input', (e)=>{ t.titulo=e.target.value; salvar(); renderTabelasTabs(); });
  document.getElementById('btn-add-coluna').addEventListener('click', ()=>{
    t.colunas.push(`Coluna ${t.colunas.length+1}`);
    t.linhas.forEach(l=> l.push(''));
    salvar(); renderTabelaCorpo();
  });
  document.getElementById('btn-add-tl-linha').addEventListener('click', ()=>{
    t.linhas.push(t.colunas.map(()=> ''));
    t.concluidas.push(false);
    salvar(); renderTabelaCorpo();
  });
  corpo.querySelectorAll('thead input[data-col]').forEach(inp=>{
    inp.addEventListener('input', ()=>{ t.colunas[inp.dataset.col]=inp.value; salvar(); });
  });
  corpo.querySelectorAll('.tl-col-del').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const ci = Number(btn.dataset.colDel);
      if (t.colunas.length<=1) return; // sempre sobra pelo menos 1 coluna
      t.colunas.splice(ci,1);
      t.linhas.forEach(l=> l.splice(ci,1));
      salvar(); renderTabelaCorpo();
    });
  });
  corpo.querySelectorAll('tbody input[type=text][data-row]').forEach(inp=>{
    inp.addEventListener('input', ()=>{ t.linhas[inp.dataset.row][inp.dataset.col]=inp.value; salvar(); });
  });
  corpo.querySelectorAll('.tl-check').forEach(chk=>{
    chk.addEventListener('change', ()=>{
      t.concluidas[chk.dataset.rowCheck] = chk.checked;
      salvar(); renderTabelaCorpo();
    });
  });
  corpo.querySelectorAll('.tl-row-del').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const ri = Number(btn.dataset.rowDel);
      t.linhas.splice(ri,1);
      t.concluidas.splice(ri,1);
      salvar(); renderTabelaCorpo();
    });
  });
}
document.getElementById('btn-add-tabela').addEventListener('click', ()=>{
  DADOS.tabelasPersonalizadas.push(novaTabelaPadrao());
  tabelaAtiva = DADOS.tabelasPersonalizadas.length-1; salvar(); renderTabelasTabs(); renderTabelaCorpo();
});

/* ================= SEMANA LIVRE =================
   Página livre, sem hora fixa: uma lista de tarefas da semana (com
   checkbox de concluída) + um espaço de texto livre por dia (segunda a
   domingo) + um bloco de notas gerais. Junta num só lugar as referências
   de "checklist", "folha lisa com os dias da semana" e "weekly plan" que
   foram pedidas — em vez de 3-4 páginas quase iguais. */
let semanaLivreRef = new Date();
function garantirSemanaLivre(chave){
  if (!DADOS.semanasLivres[chave]){
    DADOS.semanasLivres[chave] = { tarefas: [], dias: {}, notas: '' };
  }
  return DADOS.semanasLivres[chave];
}
function renderSemanaLivre(){
  const chave = chaveSemana(semanaLivreRef);
  const dados = garantirSemanaLivre(chave);
  const seg = new Date(chave + 'T00:00:00Z');
  const dom = new Date(seg); dom.setUTCDate(dom.getUTCDate()+6);
  document.getElementById('livre-label').textContent =
    seg.toLocaleDateString('pt-BR',{day:'2-digit',month:'short',timeZone:'UTC'}) + ' – ' +
    dom.toLocaleDateString('pt-BR',{day:'2-digit',month:'short',timeZone:'UTC'});

  // checklist
  const lista = document.getElementById('livre-lista');
  lista.innerHTML = dados.tarefas.map((t,i)=>`
    <div class="livre-check-item ${t.feito?'feito':''}">
      <input type="checkbox" data-i="${i}" ${t.feito?'checked':''}>
      <input type="text" data-i="${i}" value="${escapeHtml(t.texto||'')}" placeholder="Tarefa...">
      <button class="del-linha" data-i="${i}">✕</button>
    </div>`).join('') || '<span class="vazio">Nenhuma tarefa ainda.</span>';
  lista.querySelectorAll('input[type=checkbox]').forEach(chk=>{
    chk.addEventListener('change', ()=>{ dados.tarefas[chk.dataset.i].feito = chk.checked; salvar(); renderSemanaLivre(); });
  });
  lista.querySelectorAll('input[type=text]').forEach(inp=>{
    inp.addEventListener('input', ()=>{ dados.tarefas[inp.dataset.i].texto = inp.value; salvar(); });
  });
  lista.querySelectorAll('.del-linha').forEach(btn=>{
    btn.addEventListener('click', ()=>{ dados.tarefas.splice(Number(btn.dataset.i),1); salvar(); renderSemanaLivre(); });
  });

  // um espaço de texto por dia da semana
  const diasWrap = document.getElementById('livre-dias');
  diasWrap.innerHTML = DIAS7.map((d,i)=>{
    const ds = dataDaCelula(chave, d);
    const dObj = new Date(ds + 'T00:00:00Z');
    const fer = nomeFeriado(ds);
    return `<div class="livre-dia${fer?' fer':''}" ${fer?`title="${fer}"`:''}>
      <div class="cab">${d}<span class="num">${dObj.getUTCDate()}</span></div>
      <textarea data-dia="${d}" placeholder="...">${dados.dias[d]||''}</textarea>
    </div>`;
  }).join('');
  diasWrap.querySelectorAll('textarea').forEach(ta=>{
    ta.addEventListener('input', ()=>{ dados.dias[ta.dataset.dia] = ta.value; salvar(); });
  });

  const notas = document.getElementById('livre-notas');
  notas.value = dados.notas || '';
  notas.oninput = ()=>{ dados.notas = notas.value; salvar(); };
}
document.getElementById('livre-prev').addEventListener('click', ()=>{ semanaLivreRef.setDate(semanaLivreRef.getDate()-7); renderSemanaLivre(); });
document.getElementById('livre-next').addEventListener('click', ()=>{ semanaLivreRef.setDate(semanaLivreRef.getDate()+7); renderSemanaLivre(); });
document.getElementById('btn-add-livre-tarefa').addEventListener('click', ()=>{
  const inp = document.getElementById('in-livre-tarefa');
  if (!inp.value.trim()) return;
  garantirSemanaLivre(chaveSemana(semanaLivreRef)).tarefas.push({ texto: inp.value.trim(), feito: false });
  inp.value = ''; salvar(); renderSemanaLivre();
});

/* ================= INICIALIZAÇÃO ================= */
storageGet('meuCadernoDados', null, (salvo)=>{
  if(salvo){ DADOS = Object.assign(DADOS, salvo); }
  document.documentElement.style.setProperty('--capa-clara', DADOS.capaCor || '#6b5640');
  document.documentElement.style.setProperty('--capa-escura', ajustarCor(DADOS.capaCor || '#5a4632', -28));
  document.documentElement.style.setProperty('--elastico', DADOS.elasticoCor || '#8a6f4e');
  document.documentElement.style.setProperty('--caneta', DADOS.canetaCor || '#4a3c28');
  marcarAtivo('sw-capa', CORES_CAPA, DADOS.capaCor);
  marcarAtivo('sw-elastico', CORES_ELASTICO, DADOS.elasticoCor);
  marcarAtivo('sw-caneta', CORES_CANETA, DADOS.canetaCor);
  aplicarIlustracao(DADOS.capaIlustracao || 'nenhuma', false);
  if(DADOS.tituloCapa){ inTituloCapa.value = DADOS.tituloCapa; capaTituloTxt.innerHTML = escapeHtml(DADOS.tituloCapa).replace(/\n/g,'<br>'); }

  if(!DADOS.semestres) DADOS.semestres = {'1':{grade:{},aulas:[]},'2':{grade:{},aulas:[]}};
  if(!DADOS.semanas) DADOS.semanas = {};
  if(!DADOS.meses) DADOS.meses = {};
  if(!DADOS.materias) DADOS.materias = [];
  if(!DADOS.vocab) DADOS.vocab = [];
  if(!DADOS.leituras) DADOS.leituras = [];
  if(!DADOS.revisao) DADOS.revisao = [];
  if(!DADOS.questoes) DADOS.questoes = [];
  if(!DADOS.resumos) DADOS.resumos = [];
  if(!DADOS.tabelasPersonalizadas) DADOS.tabelasPersonalizadas = [];
  if(!DADOS.semanasLivres) DADOS.semanasLivres = {};

  renderGradeSemestre(); renderAulas();
  renderSemanal();
  renderMensal();
  renderMaterias(); renderPainelMateria();
  renderVocab(); renderLeituras(); renderRevisao(); renderQuestoes();
  renderFichaTabs(); renderFichaCorpo();
  renderTabelasTabs(); renderTabelaCorpo();
  renderSemanaLivre();
});
