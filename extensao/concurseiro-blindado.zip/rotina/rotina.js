// ===================== ORGANIZE O SEU DIA — TELA CHEIA =====================
// Usa exatamente as mesmas chaves de storage do popup (cbCronogramaHoje,
// cbCronogramaData, cbAlarme*), então qualquer bloco adicionado aqui aparece
// no popup e vice-versa. Nenhum som é tocado nesta tela — os avisos são
// só visuais (divs), nunca chrome.notifications nem áudio.

const CRONO_TIPO_LABEL = { leitura: 'Leitura', video: 'Vídeo-aula', questoes: 'Questões', revisao: 'Revisão' };
const CRONO_TIPO_COR = { leitura: '#2dd4a0', video: '#e774c0', questoes: '#6ea8fe', revisao: '#e6a94f' };

function hojeStr() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
function minutos(hhmm) { const [h, m] = hhmm.split(':').map(Number); return h * 60 + m; }
// "materia" é texto livre digitado pelo usuário e sincroniza entre
// dispositivos via Firebase (cbCronogramaHoje) — nunca interpolar sem escape.
function escapeHtml(str) {
    return String(str == null ? '' : str)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function fmtHoras(ms) {
    const totalMin = Math.round(ms / 60000);
    const h = Math.floor(totalMin / 60), m = totalMin % 60;
    return `${h}h${String(m).padStart(2, '0')}`;
}

document.getElementById('rt-date').textContent = new Date().toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });

// ===================== BLOCOS =====================
function carregarBlocos(callback) {
    chrome.storage.local.get(['cbCronogramaHoje', 'cbCronogramaData'], (res) => {
        const hoje = hojeStr();
        if (res.cbCronogramaData !== hoje) {
            chrome.storage.local.set({ cbCronogramaHoje: [], cbCronogramaData: hoje });
            callback([]);
        } else {
            callback(res.cbCronogramaHoje || []);
        }
    });
}

function salvarBlocos(blocos) {
    blocos.sort((a, b) => minutos(a.inicio) - minutos(b.inicio));
    chrome.storage.local.set({ cbCronogramaHoje: blocos, cbCronogramaData: hojeStr() });
    chrome.runtime.sendMessage({ action: 'cronogramaAtualizado' }).catch(() => {});
}

function renderBlocos() {
    const lista = document.getElementById('rt-lista');
    const status = document.getElementById('rt-status');

    carregarBlocos((blocos) => {
        document.getElementById('stat-blocos').textContent = blocos.length;

        if (!blocos.length) {
            lista.innerHTML = '<div class="rt-empty">Nenhum bloco pra hoje ainda. Monte o primeiro ao lado.</div>';
            status.textContent = '—';
            renderAvisos(blocos, []);
            return;
        }

        const agora = new Date();
        const minAgora = agora.getHours() * 60 + agora.getMinutes();
        let ativo = null;

        chrome.storage.local.get(['cbAlarmeDisparadosHoje'], (res) => {
            const disparados = (res.cbAlarmeDisparadosHoje && res.cbAlarmeDisparadosHoje.data === hojeStr())
                ? res.cbAlarmeDisparadosHoje.ids : [];

            lista.innerHTML = blocos.map((b) => {
                const ini = minutos(b.inicio), fim = minutos(b.fim);
                const estaAtivo = minAgora >= ini && minAgora < fim;
                const jaPassou = minAgora >= fim;
                const perdido = disparados.includes(b.id);
                if (estaAtivo) ativo = b;

                let statusTxt = jaPassou ? 'Concluído' : 'A seguir';
                if (estaAtivo) statusTxt = 'Agora';
                if (perdido) statusTxt = 'Não iniciado';

                return `
                    <div class="rt-row ${estaAtivo ? 'is-now' : ''} ${jaPassou ? 'is-feito' : ''} ${perdido ? 'is-perdido' : ''}" data-id="${b.id}">
                        <div class="rt-row-time">${b.inicio}<small>${b.fim}</small></div>
                        <div class="rt-row-info">
                            <span class="rt-row-dot" style="--rt-cat:${CRONO_TIPO_COR[b.tipo] || '#2dd4a0'}"></span>
                            <div style="min-width:0;">
                                <div class="rt-row-form">${escapeHtml(CRONO_TIPO_LABEL[b.tipo] || b.tipo)}</div>
                                ${b.materia ? `<div class="rt-row-materia">${escapeHtml(b.materia)}</div>` : ''}
                            </div>
                        </div>
                        <div class="rt-row-status">${statusTxt}</div>
                        <button class="rt-row-del" data-del="${b.id}" title="Remover">✕</button>
                    </div>`;
            }).join('');

            status.textContent = ativo ? `Agora: ${CRONO_TIPO_LABEL[ativo.tipo] || ativo.tipo}` : `Hoje: ${blocos.length} bloco${blocos.length > 1 ? 's' : ''}`;

            lista.querySelectorAll('[data-del]').forEach((btn) => {
                btn.addEventListener('click', () => {
                    carregarBlocos((atual) => {
                        salvarBlocos(atual.filter((b) => b.id !== btn.dataset.del));
                        renderBlocos();
                    });
                });
            });

            renderAvisos(blocos, disparados);
        });
    });
}

// ===================== AVISOS (SÓ VISUAL, SEM SOM) =====================
let avisosFechados = new Set();

function renderAvisos(blocos, disparados) {
    const wrap = document.getElementById('rt-avisos');
    const avisos = [];

    const perdidos = blocos.filter((b) => disparados.includes(b.id));
    if (perdidos.length && !avisosFechados.has('cronograma')) {
        avisos.push({
            id: 'cronograma',
            tipo: 'is-red',
            titulo: `${perdidos.length} bloco${perdidos.length > 1 ? 's' : ''} do cronograma não iniciado${perdidos.length > 1 ? 's' : ''} a tempo`,
            texto: perdidos.map((b) => `${b.inicio}–${b.fim} (${CRONO_TIPO_LABEL[b.tipo] || b.tipo})`).join(' · ')
        });
    }

    chrome.storage.sync.get(['dailyGoalMs'], (syncRes) => {
        chrome.storage.local.get(['studyHistory'], (localRes) => {
            const goalMs = syncRes.dailyGoalMs || 4 * 60 * 60 * 1000;
            const estudadoMs = (localRes.studyHistory || {})[hojeStr()] || 0;
            const pct = Math.min(100, Math.round((estudadoMs / goalMs) * 100));

            document.getElementById('stat-meta').textContent = `${pct}%`;
            document.getElementById('stat-horas').textContent = fmtHoras(estudadoMs);

            const horaAgora = new Date().getHours();
            if (horaAgora >= 20 && estudadoMs < goalMs && !avisosFechados.has('meta')) {
                avisos.push({
                    id: 'meta',
                    tipo: '',
                    titulo: 'Meta diária ainda não batida',
                    texto: `${fmtHoras(estudadoMs)} de ${fmtHoras(goalMs)} até agora.`
                });
            }

            wrap.innerHTML = avisos.map((a) => `
                <div class="rt-aviso ${a.tipo}" data-aviso="${a.id}">
                    <div class="rt-aviso-text"><b>${a.titulo}</b><span>${a.texto}</span></div>
                    <button class="rt-aviso-close" data-fechar="${a.id}">✕</button>
                </div>`).join('');

            wrap.querySelectorAll('[data-fechar]').forEach((btn) => {
                btn.addEventListener('click', () => {
                    avisosFechados.add(btn.dataset.fechar);
                    btn.closest('.rt-aviso').remove();
                });
            });
        });
    });
}

// ===================== ESTATÍSTICAS =====================
function renderStreak() {
    chrome.storage.local.get(['streakCount'], (res) => {
        document.getElementById('stat-ofensiva').textContent = res.streakCount || 0;
    });
}

// ===================== FORM DE NOVO BLOCO =====================
document.getElementById('btn-add').addEventListener('click', () => {
    const inicio = document.getElementById('in-inicio').value;
    const fim = document.getElementById('in-fim').value;
    const tipo = document.getElementById('in-tipo').value;
    const materiaEl = document.getElementById('in-materia');
    const materia = materiaEl.value.trim();

    if (!inicio || !fim || minutos(fim) <= minutos(inicio)) {
        alert('O horário de fim precisa ser depois do início.');
        return;
    }

    carregarBlocos((blocos) => {
        const novoBloco = { id: `crono_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`, inicio, fim, tipo, materia };
        const sobrepoe = blocos.some((b) => minutos(inicio) < minutos(b.fim) && minutos(fim) > minutos(b.inicio));
        if (sobrepoe && !confirm('Esse horário sobrepõe outro bloco já criado. Adicionar mesmo assim?')) return;

        blocos.push(novoBloco);
        salvarBlocos(blocos);
        materiaEl.value = '';
        renderBlocos();
    });
});

// ===================== ALARME DE INÍCIO =====================
const chkAlarme = document.getElementById('chk-alarme');
const avisoPendente = document.getElementById('alarme-pendente-aviso');

function refletirEstadoAlarme() {
    chrome.runtime.sendMessage({ action: 'cbAlarmeGetEstado' }, (res) => {
        if (!res) return;
        chkAlarme.checked = res.ativo;
        if (res.pendente) {
            const dataEfetiva = new Date(res.pendente.efetivoEm);
            avisoPendente.style.display = 'block';
            avisoPendente.textContent = `Pedido de desligar o alarme registrado. Só some às ${dataEfetiva.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })} de ${dataEfetiva.toLocaleDateString('pt-BR')}.`;
        } else {
            avisoPendente.style.display = 'none';
        }
    });
}
chkAlarme.addEventListener('change', () => {
    chrome.runtime.sendMessage({ action: 'cbAlarmeSetEstado', ativo: chkAlarme.checked }, () => refletirEstadoAlarme());
});

// ===================== INICIALIZAÇÃO =====================
renderBlocos();
renderStreak();
refletirEstadoAlarme();
setInterval(renderBlocos, 30 * 1000);

chrome.storage.onChanged.addListener((changes, area) => {
    if ((area === 'local' && (changes.cbCronogramaHoje || changes.cbAlarmeDisparadosHoje || changes.studyHistory)) ||
        (area === 'sync' && changes.dailyGoalMs)) {
        renderBlocos();
    }
});
