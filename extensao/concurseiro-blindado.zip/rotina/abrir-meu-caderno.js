/* Botão do "Meu Caderno" — abre o caderno personalizável (páginas
   semestral/semanal/mensal/matérias/extras/resumos) em uma aba própria.
   Precisa ficar num arquivo externo: o CSP padrão do Manifest V3 bloqueia
   script inline em qualquer página da extensão, então o <script> que
   morava direto no HTML nunca rodava e o botão não fazia nada. */
document.getElementById('btn-abrir-meu-caderno').addEventListener('click', function(){
  var url = (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL)
    ? chrome.runtime.getURL('rotina/meu-caderno.html')
    : 'meu-caderno.html';
  if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.create) {
    chrome.tabs.create({ url: url });
  } else {
    window.open(url, '_blank');
  }
});
