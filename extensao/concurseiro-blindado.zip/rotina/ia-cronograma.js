// ===================== GERAÇÃO DE CRONOGRAMA COM IA =====================
//
// A chamada de verdade (com fallback automático Pollinations → Gemini) mora
// em dados-config/ia-provider.js (cbGerarRespostaIA). Aqui só monta o prompt
// específico de cronograma e valida o formato da resposta.

function cbMontarPromptCronograma({ descricao, inicioDisp, fimDisp, blocosExistentes }) {
  const ocupados = (blocosExistentes || [])
    .map((b) => `${b.inicio}-${b.fim} (${b.materia || b.tipo || 'bloco'})`)
    .join('; ') || 'nenhum';

  return `Gere um cronograma de estudo para UM único dia, respeitando a janela de horário
disponível e os blocos que já existem (não pode sobrepor os horários já ocupados).

Janela disponível: ${inicioDisp} às ${fimDisp}
Blocos já ocupados nesse dia: ${ocupados}
Pedido da pessoa: ${descricao}

Responda APENAS com um JSON válido (sem markdown, sem texto fora do JSON), no
formato de uma lista de blocos:
[{"inicio":"HH:MM","fim":"HH:MM","materia":"nome curto da matéria/tarefa","prioridade":"alta|media|baixa"}]

Regras: horários dentro da janela informada, sem sobrepor os blocos já ocupados,
inclua pausas curtas quando fizer sentido, no máximo 8 blocos.`;
}

function cbExtrairJSON(texto) {
  const semCerca = String(texto || '').replace(/```json|```/gi, '').trim();
  const ini = semCerca.indexOf('[');
  const fimIdx = semCerca.lastIndexOf(']');
  if (ini === -1 || fimIdx === -1) throw new Error('A resposta da IA não trouxe uma lista JSON.');
  return JSON.parse(semCerca.slice(ini, fimIdx + 1));
}

async function cbGerarCronogramaIA({ descricao, inicioDisp, fimDisp, blocosExistentes }) {
  const promptTexto = cbMontarPromptCronograma({ descricao, inicioDisp, fimDisp, blocosExistentes });

  const mensagens = [
    { role: 'system', content: 'Você é um planejador de estudos para concursos públicos brasileiros. Responde APENAS com JSON válido, sem markdown e sem texto fora do JSON.' },
  ];

  // Contexto real (desempenho em questões, matérias fracas) pra priorizar
  // melhor — se não der pra carregar, segue sem ele.
  if (typeof window.cbColetarContextoEstudo === 'function') {
    try {
      const contexto = await window.cbColetarContextoEstudo();
      mensagens.push({ role: 'system', content: `${contexto}\n\nUse as matérias fracas/prioritárias acima como preferência ao montar o cronograma, quando o pedido da pessoa não especificar tudo.` });
    } catch (e) { /* segue sem contexto */ }
  }

  mensagens.push({ role: 'user', content: promptTexto });

  const texto = await window.cbGerarRespostaIA(mensagens);

  const lista = cbExtrairJSON(texto);

  return lista
    .filter((b) => b && b.inicio && b.fim)
    .map((b) => ({
      id: `crono_ia_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      inicio: b.inicio,
      fim: b.fim,
      tipo: 'outro',
      materia: String(b.materia || 'Estudo').slice(0, 80),
      prioridade: ['alta', 'media', 'baixa'].includes(b.prioridade) ? b.prioridade : 'media',
      aviso: true,
    }));
}

window.cbGerarCronogramaIA = cbGerarCronogramaIA;
