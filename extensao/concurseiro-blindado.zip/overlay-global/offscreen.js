// offscreen.js — Toca ruído branco / chuva (gerados via Web Audio) ou uma rádio Lo-Fi
// (stream de áudio), continuando a tocar mesmo com o popup fechado.

let audioCtx = null;
let masterGain = null;
let noiseSource = null;
let rainFilterNodes = [];
let lofiAudioEl = null;
let currentType = 'none';
let currentVolume = 0.5;

// Servidor principal atual da SomaFM (o antigo "ice1" foi descontinuado —
// era por isso que o Lo-Fi nunca tocava). Mantemos um servidor alternativo
// de fallback caso o principal esteja fora do ar.
const LOFI_STREAM_URL = 'https://ice5.somafm.com/groovesalad-128-mp3';
const LOFI_STREAM_URL_FALLBACK = 'https://ice3.somafm.com/groovesalad-128-mp3';

function ensureContext() {
    if (!audioCtx) {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        masterGain = audioCtx.createGain();
        masterGain.gain.value = currentVolume;
        masterGain.connect(audioCtx.destination);
    }
    if (audioCtx.state === 'suspended') {
        audioCtx.resume().catch(() => {});
    }
}

function buildNoiseBuffer() {
    const bufferSize = audioCtx.sampleRate * 4; // 4s, dá loop sem clique perceptível
    const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
    }
    return buffer;
}

function stopWebAudioNodes() {
    if (noiseSource) {
        try { noiseSource.stop(); } catch (e) {}
        noiseSource.disconnect();
        noiseSource = null;
    }
    rainFilterNodes.forEach(n => { try { n.disconnect(); } catch (e) {} });
    rainFilterNodes = [];
}

function stopLofi() {
    if (lofiAudioEl) {
        lofiAudioEl.pause();
        lofiAudioEl.src = '';
        lofiAudioEl = null;
    }
}

function playWhiteNoise() {
    ensureContext();
    stopWebAudioNodes();
    stopLofi();
    noiseSource = audioCtx.createBufferSource();
    noiseSource.buffer = buildNoiseBuffer();
    noiseSource.loop = true;
    // Filtro leve para não ficar áspero demais
    const lowpass = audioCtx.createBiquadFilter();
    lowpass.type = 'lowpass';
    lowpass.frequency.value = 6000;
    noiseSource.connect(lowpass);
    lowpass.connect(masterGain);
    rainFilterNodes.push(lowpass);
    noiseSource.start();
}

function playRainNoise() {
    ensureContext();
    stopWebAudioNodes();
    stopLofi();
    noiseSource = audioCtx.createBufferSource();
    noiseSource.buffer = buildNoiseBuffer();
    noiseSource.loop = true;

    // Simula "chuva": corta graves e agudos extremos e adiciona um leve LFO no volume
    const highpass = audioCtx.createBiquadFilter();
    highpass.type = 'highpass';
    highpass.frequency.value = 700;
    const lowpass = audioCtx.createBiquadFilter();
    lowpass.type = 'lowpass';
    lowpass.frequency.value = 5000;

    const lfoGain = audioCtx.createGain();
    lfoGain.gain.value = 1;
    const lfo = audioCtx.createOscillator();
    lfo.frequency.value = 0.15;
    const lfoDepth = audioCtx.createGain();
    lfoDepth.gain.value = 0.15;
    lfo.connect(lfoDepth);
    lfoDepth.connect(lfoGain.gain);
    lfo.start();

    noiseSource.connect(highpass);
    highpass.connect(lowpass);
    lowpass.connect(lfoGain);
    lfoGain.connect(masterGain);

    rainFilterNodes.push(highpass, lowpass, lfoGain, lfo, lfoDepth);
    noiseSource.start();
}

function playRainNoise() {
    ensureContext();
    stopWebAudioNodes();
    stopLofi();
    noiseSource = audioCtx.createBufferSource();
    noiseSource.buffer = buildNoiseBuffer();
    noiseSource.loop = true;

    // Simula "chuva": corta graves e agudos extremos e adiciona um leve LFO no volume
    const highpass = audioCtx.createBiquadFilter();
    highpass.type = 'highpass';
    highpass.frequency.value = 700;
    const lowpass = audioCtx.createBiquadFilter();
    lowpass.type = 'lowpass';
    lowpass.frequency.value = 5000;

    const lfoGain = audioCtx.createGain();
    lfoGain.gain.value = 1;
    const lfo = audioCtx.createOscillator();
    lfo.frequency.value = 0.15;
    const lfoDepth = audioCtx.createGain();
    lfoDepth.gain.value = 0.15;
    lfo.connect(lfoDepth);
    lfoDepth.connect(lfoGain.gain);
    lfo.start();

    noiseSource.connect(highpass);
    highpass.connect(lowpass);
    lowpass.connect(lfoGain);
    lfoGain.connect(masterGain);

    rainFilterNodes.push(highpass, lowpass, lfoGain, lfo, lfoDepth);
    noiseSource.start();
}

// "Vento" — ruído filtrado numa faixa média (imita o assobio do vento),
// com um LFO mais lento e mais profundo que o da chuva pra dar a sensação
// de rajadas indo e vindo. 100% sintetizado (Web Audio), sem depender de
// nenhum arquivo/stream externo.
function playWindNoise() {
    ensureContext();
    stopWebAudioNodes();
    stopLofi();
    noiseSource = audioCtx.createBufferSource();
    noiseSource.buffer = buildNoiseBuffer();
    noiseSource.loop = true;

    const bandpass = audioCtx.createBiquadFilter();
    bandpass.type = 'bandpass';
    bandpass.frequency.value = 500;
    bandpass.Q.value = 0.6;
    const lowpass = audioCtx.createBiquadFilter();
    lowpass.type = 'lowpass';
    lowpass.frequency.value = 1800;

    // Rajadas: LFO lento (um ciclo a cada ~7s) modulando bem o volume.
    const lfoGain = audioCtx.createGain();
    lfoGain.gain.value = 0.55;
    const lfo = audioCtx.createOscillator();
    lfo.frequency.value = 0.14;
    const lfoDepth = audioCtx.createGain();
    lfoDepth.gain.value = 0.45;
    lfo.connect(lfoDepth);
    lfoDepth.connect(lfoGain.gain);
    lfo.start();

    // Segundo LFO, mais rápido e sutil, sobreposto — evita soar "mecânico".
    const lfo2 = audioCtx.createOscillator();
    lfo2.frequency.value = 0.37;
    const lfo2Depth = audioCtx.createGain();
    lfo2Depth.gain.value = 0.12;
    lfo2.connect(lfo2Depth);
    lfo2Depth.connect(lfoGain.gain);
    lfo2.start();

    noiseSource.connect(bandpass);
    bandpass.connect(lowpass);
    lowpass.connect(lfoGain);
    lfoGain.connect(masterGain);

    rainFilterNodes.push(bandpass, lowpass, lfoGain, lfo, lfoDepth, lfo2, lfo2Depth);
    noiseSource.start();
}

// "Trovão/tempestade" — base de ruído bem grave (rumor contínuo) somada a
// duas modulações lentas e não-harmônicas entre si, que se combinam pra
// criar "ondas" de intensidade irregulares (mais parecido com trovão
// distante rolando do que um LFO único e previsível criaria).
function playThunderNoise() {
    ensureContext();
    stopWebAudioNodes();
    stopLofi();
    noiseSource = audioCtx.createBufferSource();
    noiseSource.buffer = buildNoiseBuffer();
    noiseSource.loop = true;

    const lowpass = audioCtx.createBiquadFilter();
    lowpass.type = 'lowpass';
    lowpass.frequency.value = 220;

    const rumbleGain = audioCtx.createGain();
    rumbleGain.gain.value = 0.5;

    const lfoA = audioCtx.createOscillator();
    lfoA.frequency.value = 0.05;
    const lfoADepth = audioCtx.createGain();
    lfoADepth.gain.value = 0.28;
    lfoA.connect(lfoADepth);
    lfoADepth.connect(rumbleGain.gain);
    lfoA.start();

    const lfoB = audioCtx.createOscillator();
    lfoB.frequency.value = 0.087; // não-harmônico com lfoA, evita padrão repetitivo curto
    const lfoBDepth = audioCtx.createGain();
    lfoBDepth.gain.value = 0.22;
    lfoB.connect(lfoBDepth);
    lfoBDepth.connect(rumbleGain.gain);
    lfoB.start();

    noiseSource.connect(lowpass);
    lowpass.connect(rumbleGain);
    rumbleGain.connect(masterGain);

    rainFilterNodes.push(lowpass, rumbleGain, lfoA, lfoADepth, lfoB, lfoBDepth);
    noiseSource.start();
}

function playLofi() {
    stopWebAudioNodes();
    stopLofi();
    lofiAudioEl = new Audio(LOFI_STREAM_URL);
    // Não usar crossOrigin='anonymous' aqui: como o áudio não passa pelo
    // Web Audio API (não precisamos de createMediaElementSource), pedir modo
    // CORS anônimo só faz o navegador rejeitar a resposta do servidor de
    // streaming (que não manda os headers de CORS), travando o play.
    lofiAudioEl.volume = currentVolume;

    let tentouFallback = false;
    lofiAudioEl.addEventListener('error', () => {
        if (!tentouFallback && lofiAudioEl && lofiAudioEl.src.includes('ice5')) {
            tentouFallback = true;
            console.warn('[Concurseiro Blindado] Servidor principal do Lo-Fi falhou, tentando servidor alternativo...');
            lofiAudioEl.src = LOFI_STREAM_URL_FALLBACK;
            lofiAudioEl.play().catch((err) => {
                console.warn('[Concurseiro Blindado] Falha também no servidor alternativo do Lo-Fi:', err);
            });
        }
    });

    lofiAudioEl.play().catch((err) => {
        console.warn('[Concurseiro Blindado] Falha ao iniciar rádio Lo-Fi:', err);
    });
}

function applyVolume(vol) {
    currentVolume = vol;
    if (masterGain) masterGain.gain.value = vol;
    if (lofiAudioEl) lofiAudioEl.volume = vol;
}

function playSound(type, volume) {
    // Se o mesmo som já está tocando, só o volume mudou (ex: usuário
    // arrastando o slider) — reconstruir o grafo de áudio do zero a cada
    // chamada causaria cliques/estalos audíveis e reiniciaria osciladores/
    // LFOs do zero. Nesse caso só ajusta o ganho, sem recriar nada.
    if (currentType === type && type !== 'none') {
        if (typeof volume === 'number') applyVolume(volume);
        return;
    }

    currentType = type;
    if (typeof volume === 'number') currentVolume = volume;

    if (type === 'white') playWhiteNoise();
    else if (type === 'rain') playRainNoise();
    else if (type === 'wind') playWindNoise();
    else if (type === 'thunder') playThunderNoise();
    else if (type === 'lofi') playLofi();
    else stopSound();

    applyVolume(currentVolume);
}

function stopSound() {
    currentType = 'none';
    stopWebAudioNodes();
    stopLofi();
}

// ===================== ALERTA SONORO DO POMODORO =====================
// Toca aqui (no offscreen document) em vez de mandar mensagem pra aba ativa:
// assim o beep sempre dispara, não importa qual aba/janela está em foco,
// nem se o overlay chegou a ser injetado naquela aba específica. Usa um
// AudioContext PRÓPRIO (não o de som ambiente) pra não interferir no volume
// nem no estado ligado/desligado do som ambiente.
let alertCtx = null;
function ensureAlertContext() {
    if (!alertCtx) {
        alertCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (alertCtx.state === 'suspended') {
        alertCtx.resume().catch(() => {});
    }
    return alertCtx;
}

// Toca uma sequência de tons (frequência em Hz, duração em segundos), com
// pequenos intervalos entre eles, formando um "beep" distinto para cada
// evento do Pomodoro.
function tocarTons(tons) {
    const ctx = ensureAlertContext();
    let tempoInicial = ctx.currentTime;
    tons.forEach(({ freq, duracao, gap }) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, tempoInicial);
        gain.gain.setValueAtTime(0.0001, tempoInicial);
        gain.gain.exponentialRampToValueAtTime(0.35, tempoInicial + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, tempoInicial + duracao);
        osc.start(tempoInicial);
        osc.stop(tempoInicial + duracao + 0.02);
        tempoInicial += duracao + (gap || 0.05);
    });
}

function tocarAlertaPomodoro(kind) {
    try {
        if (kind === 'foco-inicio' || kind === 'inicio') {
            // Foco começando (ou Pomodoro ligado): dois tons subindo.
            tocarTons([{ freq: 660, duracao: 0.14 }, { freq: 880, duracao: 0.18 }]);
        } else if (kind === 'foco-fim' || kind === 'descanso-inicio') {
            // Fim do foco / início do descanso: tom único mais grave.
            tocarTons([{ freq: 523, duracao: 0.28 }]);
        } else if (kind === 'descanso-fim' || kind === 'fim') {
            // Fim do descanso / Pomodoro desligado: dois tons descendo.
            tocarTons([{ freq: 880, duracao: 0.14 }, { freq: 660, duracao: 0.2 }]);
        } else {
            tocarTons([{ freq: 880, duracao: 0.2 }]);
        }
    } catch (e) {
        // Nunca deixa um erro de beep travar o resto do fluxo.
    }
}

chrome.runtime.onMessage.addListener((msg) => {
    if (msg.target !== 'offscreen') return;
    if (msg.action === 'offscreen_play') {
        playSound(msg.soundType, msg.volume);
    } else if (msg.action === 'offscreen_stop') {
        stopSound();
    } else if (msg.action === 'offscreen_setVolume') {
        applyVolume(msg.volume);
    } else if (msg.action === 'offscreen_playAlert') {
        tocarAlertaPomodoro(msg.kind);
    }
});
