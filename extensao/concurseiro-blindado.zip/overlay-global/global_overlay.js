// ============================================================================
// Tudo dentro de uma IIFE (função auto-executável) — isso permite que o
// Chrome reinjete uma versão nova deste arquivo numa aba que já estava
// aberta com uma versão antiga, sem estourar erro de "Identifier already
// declared" (que acontecia quando os `const`/`function` do topo do arquivo
// ficavam soltos direto no escopo global da página). Cada injeção agora
// tem seu próprio escopo isolado.
// ============================================================================
(function () {
'use strict';

// Esse content script é registrado com matches: ['<all_urls>'] (ver
// cbRegistrarOverlayGlobal em background.js) — só que isso também injeta
// nas PRÓPRIAS páginas da extensão (chrome-extension://<id>/...), incluindo
// foco/bloqueio.html. Resultado: a tela cheia de bloqueio (cujo propósito é
// justamente "pare, volte a estudar") aparecia com o cronômetro flutuante
// arrastável por cima dela, o que não faz sentido nenhum ali. Nenhuma
// lógica deste arquivo (tela escura, prompts de exceção, cronômetro
// flutuante, dock etc.) é relevante nas páginas da própria extensão — todas
// já têm sua própria UI dedicada — então paramos aqui antes de montar
// qualquer coisa.
if (location.protocol === 'chrome-extension:') {
    return;
}

const CB_OVERLAY_SCRIPT_VERSION = 18;

// Se essa MESMA versão já rodou nessa aba (ex: registro automático +
// injeção manual disparando no mesmo carregamento), não desenha tudo de
// novo. Se uma versão DIFERENTE (mais antiga) já rodou antes, remove o
// que ela deixou montado e segue para montar a versão atual por cima.
if (window.__cbOverlayVersion === CB_OVERLAY_SCRIPT_VERSION) {
    return;
}
if (window.__cbOverlayVersion && window.__cbOverlayVersion !== CB_OVERLAY_SCRIPT_VERSION) {
    ['cb-offline-overlay', 'pomodoro-rest-screen', 'cb-floating-timer', 'cb-plan',
     'cb-postits-floating', 'cb-dock-nub', 'cb-dock-bar', 'cb-dock-addmenu',
     'cb-dock-evento-popover', 'cb-hub-overlay', 'cb-mapa-overlay', 'cb-mapa-galeria',
     'cb-command-island', 'cb-distraction-bar', 'cb-studytime-hud', 'cb-pdf-pergunta',
     'cb-bloqueio-pergunta'].forEach((id) => {
        const el = document.getElementById(id);
        if (el) el.remove();
    });
}
window.__cbOverlayVersion = CB_OVERLAY_SCRIPT_VERSION;

const CB_SHIELD_ICON = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/></svg>';
const CB_COFFEE_ICON = '<svg viewBox="0 0 24 24" width="34" height="34" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8h1a4 4 0 0 1 0 8h-1"/><path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4Z"/><path d="M6 1v3M10 1v3M14 1v3"/></svg>';

const CB_FRASES_MOTIVACIONAIS = [
    "Cada questão resolvida hoje é um passo a menos até a posse.",
    "Aprovado não é quem é mais inteligente, é quem não desiste.",
    "A banca não te conhece, mas o edital sim. Estuda o que cai.",
    "Nos dias difíceis, lembre do motivo que te fez começar.",
    "Constância vence talento quando o talento não é constante.",
    "Sua concorrência está descansando agora. E você?",
    "O cargo dos seus sonhos está do outro lado do cansaço.",
    "Revisar hoje é economizar tempo na véspera da prova.",
    "Não compare seu capítulo 1 com o capítulo 20 de alguém.",
    "Foco no processo. A aprovação é consequência.",
    "Todo edital publicado é uma nova chance. Esteja pronto.",
    "Estudar cansado ainda é melhor do que não estudar.",
    "Sua rotina de hoje decide seu currículo de amanhã.",
    "Ninguém disse que seria fácil, disseram que valeria a pena.",
    "A prova é só uma reunião: quem estudou mais, senta primeiro."
];

function frasePomodoroAleatoria() {
    return CB_FRASES_MOTIVACIONAIS[Math.floor(Math.random() * CB_FRASES_MOTIVACIONAIS.length)];
}

// ======================================================================
// A TELA ESCURA (id `cb-offline-overlay`) — a de verdade.
// ======================================================================
// É esta: uma camada escura que cobre a página INTEIRA, com o cronômetro
// de estudo grande no canto. A aba continua no site (não troca de página);
// o site só fica atrás do escuro, ilegível e sem clique.
//
// HISTÓRICO — por que ela tinha sumido e por que voltou diferente:
// ela era ligada AUTOMATICAMENTE em qualquer aba sempre que a sessão
// estivesse no modo Offline. Como este script roda em <all_urls>, isso
// escurecia páginas sem relação nenhuma com estudo, piscava e aparecia
// por cima de abas aleatórias. A "solução" da versão anterior foi
// simplesmente apagar a tela escura inteira — o que resolveu o piscar e
// tirou junto a única coisa que a pessoa realmente queria.
//
// AGORA ela existe de novo, mas o gatilho é o oposto: só aparece em site
// que a PESSOA mandou bloquear (respondendo "Bloquear" na pergunta que
// aparece na própria página) e só enquanto o cronômetro estiver rodando.
// Nunca liga sozinha em lugar nenhum — não tem como voltar a piscar em
// aba aleatória, porque não existe mais nenhum caminho automático até ela.

const cbTelaEscura = document.createElement('div');
cbTelaEscura.id = 'cb-offline-overlay';
cbTelaEscura.style.cssText = `
    display: none; position: fixed; inset: 0; width: 100vw; height: 100vh;
    background: rgba(6, 7, 10, 0.965);
    backdrop-filter: saturate(0.25) blur(3px);
    -webkit-backdrop-filter: saturate(0.25) blur(3px);
    z-index: 2147483646;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    cursor: default;
`;
cbTelaEscura.innerHTML = `
    <div id="cb-te-marca" style="
        position:absolute; top:22px; left:26px;
        display:flex; align-items:center; gap:8px;
        font-size:12px; font-weight:700; letter-spacing:0.04em;
        color:rgba(230,233,239,0.28); text-transform:uppercase; user-select:none;">
        ${CB_SHIELD_ICON}<span id="cb-te-marca-texto">Concurseiro Blindado</span>
    </div>

    <div style="position:absolute; right:40px; bottom:34px; text-align:right; user-select:none;">
        <div id="cb-te-timer" style="
            font-family:'SF Mono', Consolas, 'Roboto Mono', monospace;
            font-size:46px; font-weight:600; letter-spacing:3px;
            font-variant-numeric: tabular-nums;
            color:rgba(230,233,239,0.55); line-height:1;">00:00:00</div>
        <div id="cb-te-timer-label" style="
            margin-top:8px; font-size:10.5px; font-weight:700;
            letter-spacing:0.14em; text-transform:uppercase;
            color:rgba(230,233,239,0.22);">estudando hoje</div>
    </div>

    <div style="position:absolute; left:0; right:0; bottom:26px; text-align:center;">
        <button id="cb-te-liberar" style="
            background:none; border:none; padding:6px 10px;
            color:rgba(230,233,239,0.22); font-size:11.5px; font-family:inherit;
            cursor:pointer; text-decoration:underline; text-underline-offset:3px;">
            Não é bem assim, preciso deste site agora (libera por 5 min)
        </button>
    </div>
`;

// Guarda o host pra não depender de ler o storage na hora do clique.
function cbTelaEscuraLigarBotao() {
    const btn = cbTelaEscura.querySelector('#cb-te-liberar');
    if (!btn || btn.dataset.cbLigado === '1') return;
    btn.dataset.cbLigado = '1';
    btn.addEventListener('mouseenter', () => { btn.style.color = 'rgba(230,233,239,0.55)'; });
    btn.addEventListener('mouseleave', () => { btn.style.color = 'rgba(230,233,239,0.22)'; });
    btn.addEventListener('click', () => {
        chrome.runtime.sendMessage({ action: 'cronogramaLiberarHost', host: cbHostAtual(), minutos: 5 }, () => {
            cbEsconderTelaEscura();
        });
    });
}

// ---- cronômetro da tela escura ----
// Lê o mesmo studyHistory que o cronômetro flutuante usa. Entre uma
// atualização e outra do background, continua contando localmente pra não
// ficar travado em 00:00:00 na tela.
let cbTeBaseMs = 0;
let cbTeBaseLidoEm = 0;
let cbTeRodando = false;
let cbTeTickInterval = null;

function cbTeHojeKey() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function cbTePintar() {
    const el = cbTelaEscura.querySelector('#cb-te-timer');
    if (!el) return;
    const extra = cbTeRodando ? (Date.now() - cbTeBaseLidoEm) : 0;
    el.textContent = cbFormatHHMMSS(cbTeBaseMs + extra);
}

function cbTeSincronizar() {
    chrome.storage.local.get(['studyHistory', 'sessionState'], (res) => {
        cbTeBaseMs = (res.studyHistory || {})[cbTeHojeKey()] || 0;
        cbTeBaseLidoEm = Date.now();
        const estado = res.sessionState || 'stopped';
        cbTeRodando = estado === 'running';
        const label = cbTelaEscura.querySelector('#cb-te-timer-label');
        if (label) {
            label.textContent = cbTeRodando ? 'estudando hoje'
                : (estado.startsWith('paused') ? 'pausado' : 'cronômetro parado');
        }
        cbTePintar();
    });
}

let cbTelaEscuraVisivel = false;
let cbOverflowOriginal = null;

function cbMostrarTelaEscura() {
    if (cbTelaEscuraVisivel) return;
    if (!document.body) return;
    if (!cbTelaEscura.isConnected) document.body.appendChild(cbTelaEscura);
    cbTelaEscuraLigarBotao();
    cbTelaEscura.style.display = 'block';
    cbTelaEscuraVisivel = true;

    // Sem isso a roda do mouse continuaria rolando a página ATRÁS do
    // escuro — dava pra "usar" o site no escuro, o que derrota o propósito.
    if (cbOverflowOriginal === null) {
        cbOverflowOriginal = document.documentElement.style.overflow || '';
    }
    document.documentElement.style.overflow = 'hidden';

    // A barrinha vermelha de distração não faz sentido por cima da tela
    // escura (e tinha z-index maior que ela, então ficava sobrando lá).
    const barra = document.getElementById('cb-distraction-bar');
    if (barra) barra.style.display = 'none';

    cbTeSincronizar();
    if (!cbTeTickInterval) cbTeTickInterval = setInterval(cbTePintar, 1000);
}

function cbEsconderTelaEscura() {
    cbTelaEscura.style.display = 'none';
    if (cbTelaEscuraVisivel && cbOverflowOriginal !== null) {
        document.documentElement.style.overflow = cbOverflowOriginal;
        cbOverflowOriginal = null;
    }
    cbTelaEscuraVisivel = false;
    if (cbTeTickInterval) { clearInterval(cbTeTickInterval); cbTeTickInterval = null; }
}

// Quando a liberação de 5 min vence, nada muda no storage — então marcamos
// a hora exata pra reavaliar sozinho e a tela escura voltar na hora certa.
let cbTeVoltaTimeout = null;
function cbAgendarVoltaDaTelaEscura(quando) {
    if (cbTeVoltaTimeout) clearTimeout(cbTeVoltaTimeout);
    const falta = Math.max(1000, quando - Date.now() + 500);
    if (falta > 2147483000) return; // além do limite do setTimeout
    cbTeVoltaTimeout = setTimeout(() => { cbTeVoltaTimeout = null; checkState(); }, falta);
}

const restOverlay = document.createElement('div');
restOverlay.id = 'pomodoro-rest-screen';
restOverlay.style.cssText = `
    display: none; position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
    background:
        radial-gradient(560px 320px at 50% 30%, rgba(45, 212, 160, 0.08) 0%, transparent 60%),
        rgba(8, 9, 12, 0.98);
    color: white; z-index: 2147483647;
    justify-content: center; align-items: center;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    text-align: center;
`;
restOverlay.innerHTML = `
    <div>
        <div style="display:flex; align-items:center; justify-content:center; width:64px; height:64px; margin:0 auto 20px auto; border-radius:16px; background:linear-gradient(155deg, #182036, #0d1220); border:1px solid #262a3b; color:#2dd4a0;">${CB_COFFEE_ICON}</div>
        <h1 style="font-size: 26px; font-weight: 800; letter-spacing: 0.01em; color: #f2f3f7; margin: 0 0 8px 0;">Intervalo Pomodoro</h1>
        <p style="font-size: 14px; color: #8b90a6; margin-bottom: 28px; font-weight: 500;">Sessão pausada. Descanse um pouco e volte depois.</p>
        <div id="rest-timer-display" style="font-size: 52px; font-weight: 700; font-family: 'SF Mono', Consolas, monospace; letter-spacing: 1px; color: #2dd4a0; font-variant-numeric: tabular-nums;">03:00</div>
        <div id="rest-phrase" style="max-width: 380px; margin: 22px auto 0 auto; font-size: 13px; font-style: italic; color: #6d7387; line-height: 1.6;"></div>
    </div>
`;
document.body.appendChild(restOverlay);

// ==========================================================================
// Detecção de PDF: quando a aba é um PDF, em vez de já escurecer a tela,
// mostra uma perguntinha uma única vez por aba/URL — o cronômetro continua
// contando normalmente de qualquer forma (isso nunca dependeu do overlay),
// a única coisa que muda é se a tela escura de bloqueio aparece ou não
// NESSA aba específica.
// ==========================================================================
function cbEhPaginaPdf() {
    try {
        if (document.contentType === 'application/pdf') return true;
        if (/\.pdf($|[?#])/i.test(location.pathname)) return true;
    } catch (e) {}
    return false;
}

// Sites oficiais de legislação/jurisprudência — texto de lei pra ler, não
// distração. planalto.gov.br é o principal (Constituição, leis, decretos),
// mas cobre os outros mais comuns também.
const CB_SITES_LEGISLACAO = [
    'planalto.gov.br',
    'normas.leg.br',
    'senado.leg.br',
    'camara.leg.br',
    'stf.jus.br',
    'stj.jus.br'
];

function cbEhPaginaLegislacao() {
    try {
        const host = location.hostname.replace(/^www\./, '');
        return CB_SITES_LEGISLACAO.some(h => host.endsWith(h));
    } catch (e) {}
    return false;
}

function cbEhPaginaVideoAula() {
    try {
        const host = location.hostname.replace(/^www\./, '').replace(/^m\./, '');
        if (host === 'youtube.com' && location.pathname === '/watch') return true;
        if (host === 'youtu.be') return true;
    } catch (e) {}
    return false;
}

// Mantida só pra classificar o TEXTO da pergunta ("Este PDF" / "Este vídeo"
// / "Este site de legislação"). Não decide mais bloqueio nenhum: hoje a
// pergunta aparece em qualquer site que não seja de questões.
function cbEhPaginaExcecao() {
    return cbEhPaginaPdf() || cbEhPaginaVideoAula() || cbEhPaginaLegislacao();
}

// Avisa o background o que essa aba é (pdf/vídeo/normal) assim que carrega,
// pra aba "Atividade" separar Leitura de Vídeo-aula sozinha, sem precisar de
// seletor manual — a pessoa só escolhe "Leitura" no popup e o sistema decide
// o balde certo pela própria página.
(function cbReportarTipoPagina() {
    let tipo = null;
    if (cbEhPaginaVideoAula()) tipo = 'videoaula';
    else if (cbEhPaginaPdf() || cbEhPaginaLegislacao()) tipo = 'pdf';
    if (tipo) chrome.runtime.sendMessage({ action: 'reportarTipoPagina', tipo });
})();

// ==========================================================================
// PERGUNTA DE BLOQUEIO — agora acontece AQUI, na própria página.
// ==========================================================================
// ANTES: a pergunta "quer bloquear este site?" morava DENTRO do popup da
// extensão, e aqui na página existia uma OUTRA pergunta, só pra PDF/vídeo/
// legislação, gravando numa terceira chave de storage. Duas perguntas,
// três listas, nenhuma conversando com a outra — responder numa não tinha
// efeito nenhum na outra.
//
// AGORA existe uma pergunta só, e ela aparece no site que está sendo
// visitado, no momento em que faz sentido decidir. Regras:
//
//   • Site de questões (QConcursos, TEC, Gran, Estratégia): nunca pergunta,
//     nunca bloqueia.
//   • Qualquer outro site — YouTube, PDF, legislação, notícia, rede social,
//     o que for — pergunta UMA vez, com o cronômetro rodando.
//   • Nada escurece a tela por conta própria: a tela escura só passa a
//     existir naquele site depois de a pessoa responder "Bloquear".
//
// As respostas vão pras listas únicas do service worker (ver
// dados-config/cronograma-bloqueio.js): cbSitesBloqueadosManual,
// cbSitesLiberados e cbBloqueioManualDispensados.

const CB_BLOQUEIO_LISTA_KEY = 'cbSitesBloqueadosManual';
const CB_LIBERADOS_KEY = 'cbSitesLiberados';
const CB_DISPENSADOS_KEY = 'cbBloqueioManualDispensados';

// Mesma lista de background.js (QUESTION_BANK_HOSTS). Repetida aqui porque
// content script não compartilha escopo com o service worker; se um dia
// mudar lá, mude aqui junto.
const CB_SITES_QUESTOES = [
    'qconcursos.com',
    'tecconcursos.com.br',
    'gran.com.br',
    'grancursosonline.com.br',
    'estrategiaconcursos.com.br'
];

function cbHostAtual() {
    try { return location.hostname.replace(/^www\./, '').toLowerCase(); } catch (e) { return ''; }
}

function cbHostBate(host, lista) {
    const h = String(host || '').trim().toLowerCase().replace(/^www\./, '');
    if (!h) return false;
    return (lista || []).some((alvo) => {
        const a = String(alvo || '').trim().toLowerCase().replace(/^www\./, '');
        return a && (h === a || h.endsWith('.' + a));
    });
}

function cbEhSiteDeQuestoes() {
    return cbHostBate(cbHostAtual(), CB_SITES_QUESTOES);
}

// 'pendente' (nunca respondeu) | 'perguntando' | 'bloqueado' | 'liberado' | 'adiado'
let cbDecisaoSite = 'pendente';

function cbLerDecisaoSite(callback) {
    chrome.storage.local.get([CB_BLOQUEIO_LISTA_KEY, CB_LIBERADOS_KEY, CB_DISPENSADOS_KEY], (res) => {
        const host = cbHostAtual();
        if (cbHostBate(host, res[CB_BLOQUEIO_LISTA_KEY])) cbDecisaoSite = 'bloqueado';
        else if (cbHostBate(host, res[CB_LIBERADOS_KEY])) cbDecisaoSite = 'liberado';
        else {
            const dispensados = res[CB_DISPENSADOS_KEY] || {};
            cbDecisaoSite = (dispensados[host] && dispensados[host] > Date.now()) ? 'adiado' : 'pendente';
        }
        if (callback) callback(cbDecisaoSite);
    });
}

cbLerDecisaoSite(() => checkState());

chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes[CB_BLOQUEIO_LISTA_KEY] || changes[CB_LIBERADOS_KEY] || changes[CB_DISPENSADOS_KEY]) {
        // Se a decisão foi desfeita em outro lugar, essa aba volta a perguntar.
        cbLerDecisaoSite(() => checkState());
    }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message && message.action === 'cbConsultarExcecaoAtual') {
        sendResponse({
            ehExcecao: !cbEhSiteDeQuestoes(),
            escolha: cbDecisaoSite,
            hostname: cbHostAtual()
        });
        return true;
    }

    // O service worker pergunta se esta aba consegue mostrar a tela escura
    // sozinha. Respondendo {ok:true}, ele não troca a URL da aba — o site
    // fica no lugar, só coberto. Se esta resposta não chegar (visualizador
    // de PDF, página interna do navegador), ele usa foco/bloqueio.html.
    if (message && message.action === 'cbAplicarTelaEscura') {
        cbDecisaoSite = 'bloqueado';
        cbMostrarTelaEscura();
        sendResponse({ ok: true });
        return true;
    }
});

function cbTipoDoSiteTexto() {
    if (cbEhPaginaVideoAula()) return 'Este vídeo';
    if (cbEhPaginaPdf()) return 'Este PDF';
    if (cbEhPaginaLegislacao()) return 'Este site de legislação';
    return 'Este site';
}

function cbMostrarPerguntaBloqueio() {
    if (document.getElementById('cb-bloqueio-pergunta')) return;
    if (!document.body) return;
    cbDecisaoSite = 'perguntando';

    const host = cbHostAtual();

    const caixa = document.createElement('div');
    caixa.id = 'cb-bloqueio-pergunta';
    caixa.style.cssText = `
        position: fixed; top: 24px; left: 50%; transform: translateX(-50%);
        z-index: 2147483647; max-width: 460px; width: calc(100vw - 40px);
        background: linear-gradient(155deg, #14182a, #0c0f18);
        border: 1px solid rgba(255,255,255,0.1); border-radius: 14px;
        box-shadow: 0 20px 50px rgba(0,0,0,0.5);
        padding: 16px 18px; color: #e7e9f0;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    `;
    caixa.innerHTML = `
        <div style="display:flex; gap:10px; align-items:flex-start;">
            <div style="flex-shrink:0; color:#2dd4a0; margin-top:2px;">${CB_SHIELD_ICON}</div>
            <div style="flex:1; min-width:0;">
                <p style="margin:0 0 4px 0; font-size:13px; font-weight:700;">Quer bloquear este site enquanto estuda?</p>
                <p style="margin:0 0 12px 0; font-size:12px; color:#9096ab; line-height:1.45; word-break:break-all;">
                    ${cbTipoDoSiteTexto()} (<strong style="color:#c3c7d6;">${host}</strong>) só fica bloqueado se você mandar. Nada é bloqueado automaticamente.
                </p>
                <div style="display:flex; gap:8px; flex-wrap:wrap;">
                    <button id="cb-bloq-btn-nao" style="flex:1; min-width:120px; background:#2dd4a0; color:#08090c; border:none; border-radius:8px; padding:8px 10px; font-size:12px; font-weight:800; cursor:pointer; font-family:inherit;">Não bloquear</button>
                    <button id="cb-bloq-btn-sim" style="flex:1; min-width:120px; background:rgba(255,255,255,0.06); color:#c3c7d6; border:1px solid rgba(255,255,255,0.12); border-radius:8px; padding:8px 10px; font-size:12px; font-weight:700; cursor:pointer; font-family:inherit;">Bloquear</button>
                </div>
                <button id="cb-bloq-btn-depois" style="margin-top:8px; background:none; border:none; color:#6d7387; font-size:11px; cursor:pointer; padding:2px 0; font-family:inherit; text-decoration:underline;">Agora não — pergunte de novo daqui a 1 hora</button>
            </div>
        </div>
    `;
    document.body.appendChild(caixa);

    const fechar = () => { try { caixa.remove(); } catch (e) {} };

    document.getElementById('cb-bloq-btn-nao').addEventListener('click', () => {
        cbDecisaoSite = 'liberado';
        chrome.runtime.sendMessage({ action: 'cbLiberarSite', host });
        // Também tira esse site do contador de distração da sessão, que é a
        // outra coisa que costumava incomodar em PDF/vídeo de aula.
        chrome.runtime.sendMessage({ action: 'permitirExcecaoHost', hostname: location.hostname });
        fechar();
    });

    document.getElementById('cb-bloq-btn-sim').addEventListener('click', () => {
        cbDecisaoSite = 'bloqueado';
        // O service worker redireciona esta aba pra tela escura assim que
        // registra a escolha — não precisa fazer nada aqui além de fechar.
        chrome.runtime.sendMessage({ action: 'cbBloquearSite', host });
        fechar();
    });

    document.getElementById('cb-bloq-btn-depois').addEventListener('click', () => {
        cbDecisaoSite = 'adiado';
        chrome.runtime.sendMessage({ action: 'cbAdiarPerguntaSite', host });
        fechar();
    });
}


chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local') {
        checkState();
    }
});

let restOverlayWasVisible = false;

function checkState() {
    chrome.storage.local.get(['sessionState', 'activeMethod', 'pomodoroMode', 'pomodoroState', 'pomodoroTimeLeft', 'cbLiberadosTemp'], (result) => {
        const rodando = result.sessionState === 'running';
        const ehQuestoes = cbEhSiteDeQuestoes();

        // A pergunta de bloqueio vale pros DOIS modos (Online e Offline) e
        // pra qualquer site que não seja de questões — é a única decisão de
        // bloqueio que existe. Enquanto a resposta for "pendente", a página
        // segue normal: nada escurece sozinho.
        if (rodando && !ehQuestoes && cbDecisaoSite === 'pendente') {
            cbMostrarPerguntaBloqueio();
        }

        // TELA ESCURA: só neste caso, nunca automático.
        // cronômetro rodando + a pessoa respondeu "Bloquear" neste site +
        // ela não pediu os 5 minutos de liberação.
        const liberadosTemp = result.cbLiberadosTemp || {};
        const ateQuando = liberadosTemp[cbHostAtual()];
        const liberadoAgora = !!ateQuando && ateQuando > Date.now();

        if (rodando && !ehQuestoes && cbDecisaoSite === 'bloqueado' && !liberadoAgora) {
            cbMostrarTelaEscura();
        } else {
            cbEsconderTelaEscura();
            // Os 5 minutos vencem sozinhos, sem gravar nada novo no storage
            // — então nenhum evento avisaria a página. Sem este reagendamento
            // a tela escura só voltaria na próxima navegação.
            if (liberadoAgora) cbAgendarVoltaDaTelaEscura(ateQuando);
        }

        // Controle da Tela de Descanso do Pomodoro
        if (result.pomodoroMode && result.pomodoroState === 'rest') {
            restOverlay.style.display = 'flex';
            if (!restOverlayWasVisible) {
                const phraseEl = document.getElementById('rest-phrase');
                if (phraseEl) phraseEl.innerText = frasePomodoroAleatoria();
            }
            restOverlayWasVisible = true;
            const minutes = Math.floor(result.pomodoroTimeLeft / 60);
            const seconds = result.pomodoroTimeLeft % 60;
            document.getElementById('rest-timer-display').innerText = 
                `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
        } else {
            restOverlay.style.display = 'none';
            restOverlayWasVisible = false;
        }
    });
}

// ==========================================================================
// Painel de comando (Ctrl+M) — um "island" ancorado no topo da tela, no
// mesmo espírito visual do Dynamic Island / Notification Center do iOS.
// Aparece encolhido, expande mostrando o resumo do dia, e recolhe sozinho.
// ==========================================================================
const cbIslandStyleTag = document.createElement('style');
cbIslandStyleTag.textContent = `
@keyframes cbIslandIn { from { opacity: 0; transform: translate(-50%, -14px) scale(0.94); } to { opacity: 1; transform: translate(-50%, 0) scale(1); } }
@keyframes cbIslandOut { from { opacity: 1; transform: translate(-50%, 0) scale(1); } to { opacity: 0; transform: translate(-50%, -10px) scale(0.96); } }
#cb-command-island { font-variant-numeric: tabular-nums; }
#cb-command-island * { box-sizing: border-box; }
#cb-command-island .cb-isl-row { display: flex; align-items: center; }
#cb-command-island .cb-isl-divider { width: 1px; align-self: stretch; background: rgba(255,255,255,0.14); }
`;
document.head.appendChild(cbIslandStyleTag);

let cbIslandEl = null;
let cbIslandHideTimeout = null;

function cbFraseCurtaEstado(state) {
    if (state === 'running') return 'Estudando';
    if (state && state.startsWith('paused')) return 'Pausado';
    return 'Parado';
}

function cbCriarIsland() {
    const el = document.createElement('div');
    el.id = 'cb-command-island';
    el.style.cssText = `
        position: fixed; top: 14px; left: 50%; z-index: 2147483647;
        display: flex; align-items: center; gap: 0;
        padding: 11px 22px 11px 16px;
        background: rgba(255,255,255,0.1);
        backdrop-filter: blur(30px) saturate(180%);
        -webkit-backdrop-filter: blur(30px) saturate(180%);
        border-radius: 26px;
        border: 0.5px solid rgba(255,255,255,0.22);
        box-shadow: 0 10px 34px rgba(0,0,0,0.32), inset 0 1px 0 rgba(255,255,255,0.25);
        font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Text', 'SF Pro Display', system-ui, sans-serif;
        color: #fff;
        animation: cbIslandIn 0.42s cubic-bezier(0.32, 0.72, 0, 1);
        pointer-events: none;
        user-select: none;
        white-space: nowrap;
    `;
    document.body.appendChild(el);
    return el;
}

function cbPreencherIsland(el, { timeStr, pct, statusLabel, dotColor, dotBg }) {
    el.innerHTML = `
        <div class="cb-isl-row" style="gap: 9px;">
            <div style="width: 26px; height: 26px; border-radius: 9px; background: ${dotBg}; border: 0.5px solid ${dotColor}4d; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                <span style="width: 6px; height: 6px; border-radius: 50%; background: ${dotColor}; box-shadow: 0 0 6px ${dotColor}99;"></span>
            </div>
            <span style="font-size: 13px; font-weight: 400; color: rgba(255,255,255,0.75); letter-spacing: -0.01em;">${statusLabel}</span>
        </div>
        <div class="cb-isl-divider" style="margin: 0 16px; background: rgba(255,255,255,0.18);"></div>
        <div class="cb-isl-row" style="gap: 6px;">
            <span style="font-size: 16px; font-weight: 300; letter-spacing: -0.02em;">${timeStr}</span>
            <span style="font-size: 12px; font-weight: 300; color: rgba(255,255,255,0.5);">hoje</span>
        </div>
        <div class="cb-isl-divider" style="margin: 0 16px; background: rgba(255,255,255,0.18);"></div>
        <div class="cb-isl-row" style="gap: 6px;">
            <span style="font-size: 16px; font-weight: 300; letter-spacing: -0.02em; color: #30d158;">${pct}%</span>
            <span style="font-size: 12px; font-weight: 300; color: rgba(255,255,255,0.5);">meta</span>
        </div>
    `;
}

function cbEsconderIsland() {
    if (!cbIslandEl) return;
    const el = cbIslandEl;
    cbIslandEl = null;
    el.style.animation = 'cbIslandOut 0.32s cubic-bezier(0.32, 0.72, 0, 1) forwards';
    setTimeout(() => el.remove(), 320);
}

function cbMostrarCommandIsland(state) {
    if (cbIslandHideTimeout) { clearTimeout(cbIslandHideTimeout); cbIslandHideTimeout = null; }
    if (cbIslandEl) cbIslandEl.remove();
    cbIslandEl = cbCriarIsland();

    const d = new Date();
    const todayKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

    chrome.storage.local.get(['studyHistory', 'sessionState', 'dailyGoalMinutes'], (result) => {
        const ms = (result.studyHistory || {})[todayKey] || 0;
        const metaMin = result.dailyGoalMinutes || 240;
        const pct = Math.min(100, Math.round((ms / 60000 / metaMin) * 100));
        const currentState = state || result.sessionState || 'stopped';
        const dotColor = currentState === 'running' ? '#30d158' : (currentState.startsWith('paused') ? '#ff9f0a' : '#8e8e93');
        const dotBg = currentState === 'running' ? 'rgba(48,209,88,0.18)' : (currentState.startsWith('paused') ? 'rgba(255,159,10,0.18)' : 'rgba(142,142,147,0.18)');

        if (!cbIslandEl) return; // já foi fechado antes da resposta do storage
        cbPreencherIsland(cbIslandEl, {
            timeStr: cbFormatHHMMSS(ms),
            pct,
            statusLabel: cbFraseCurtaEstado(currentState),
            dotColor,
            dotBg
        });
    });

    cbIslandHideTimeout = setTimeout(cbEsconderIsland, 3200);
}

chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'cbShowCommandIsland') {
        cbMostrarCommandIsland(msg.state);
        return;
    }
    if (msg.action === 'play_pomodoro_alert') {
        tocarAlertaPomodoro();
    }
    if (msg.action === 'cbUpdateDistractionBar') {
        cbAtualizarBarraDistracao(msg.pct, msg.restanteMs);
        return;
    }
    if (msg.action === 'cbHideDistractionBar') {
        cbEsconderBarraDistracao();
        return;
    }
    if (msg.action === 'cbAntiProcStart') {
        cbMostrarAntiProc(msg);
        return;
    }
    if (msg.action === 'cbAntiProcStop') {
        cbEsconderAntiProc();
        return;
    }
});

// ==========================================================================
// MODO ANTI-PROCRASTINAÇÃO — aviso na página (ver dados-config/anti-procrastinacao.js)
// Cartão de vidro no topo + a MESMA linha vermelha fina de sempre, encolhendo durante os 2 minutos.
// Quem fecha a aba no fim é o service worker; aqui só se mostra o tempo e se oferecem dois botões.
// Shadow DOM: o CSS do site não mexe no cartão.
// ==========================================================================
let cbAntiProcHost = null;
let cbAntiProcTimer = null;

function cbEsconderAntiProc() {
    clearInterval(cbAntiProcTimer);
    cbAntiProcTimer = null;
    if (cbAntiProcHost) { cbAntiProcHost.remove(); cbAntiProcHost = null; }
    cbEsconderBarraDistracao();
}

function cbMostrarAntiProc(msg) {
    cbEsconderAntiProc();
    const fim = Number(msg.fim) || (Date.now() + 120000);
    const TOTAL = Number(msg.total) || 120000;

    const host = document.createElement('div');
    host.id = 'cb-antiproc';
    const raiz = host.attachShadow({ mode: 'open' });
    const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    raiz.innerHTML = `
        <style>
            :host { all: initial; }
            .cartao {
                position: fixed; top: 16px; left: 50%; transform: translateX(-50%); z-index: 2147483646;
                width: min(440px, calc(100vw - 24px)); box-sizing: border-box; padding: 18px 18px 14px;
                font: 14px/1.5 -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                color: #f2f3f7; background: rgba(24, 26, 38, 0.95);
                -webkit-backdrop-filter: blur(24px) saturate(1.4); backdrop-filter: blur(24px) saturate(1.4);
                border-radius: 22px; box-shadow: 0 0 0 1px rgba(255,255,255,0.12), 0 22px 54px rgba(0,0,0,0.5);
                animation: entra 0.38s cubic-bezier(0.2, 0.9, 0.25, 1);
            }
            @keyframes entra { from { opacity: 0; transform: translate(-50%, -14px) scale(0.97); } to { opacity: 1; transform: translateX(-50%); } }
            @media (prefers-reduced-motion: reduce) { .cartao { animation: none; } }
            .topo { display: flex; align-items: center; justify-content: space-between; gap: 12px; }
            .tit { font-size: 17px; font-weight: 700; letter-spacing: -0.015em; }
            .tempo { font-size: 28px; font-weight: 700; font-variant-numeric: tabular-nums; color: #ff6b61; letter-spacing: -0.02em; }
            .sub { margin: 4px 0 12px; color: #b9bfd3; font-size: 13px; }
            ul { list-style: none; margin: 0; padding: 0; display: grid; gap: 8px; }
            li { display: flex; gap: 10px; align-items: flex-start; padding: 10px 12px; border-radius: 14px; background: rgba(255,255,255,0.07); font-size: 13px; }
            li svg { flex: none; width: 18px; height: 18px; margin-top: 1px; color: #ff9f93; }
            .dica { margin: 12px 2px 0; font-size: 12px; color: #9aa1b8; }
            .acoes { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-top: 14px; }
            .btn { padding: 10px 16px; border: 0; border-radius: 999px; font: inherit; font-size: 13px; font-weight: 700; cursor: pointer; color: #fff; background: linear-gradient(160deg, #8b5cf6, #6d28d9); }
            .btn:active { transform: scale(0.97); }
            .link { padding: 6px 4px; border: 0; background: none; font: inherit; font-size: 12px; color: #9aa1b8; text-decoration: underline; cursor: pointer; }
            .link:hover { color: #d7dbea; }
        </style>
        <div class="cartao" role="alertdialog" aria-label="Hora de voltar a estudar">
            <div class="topo"><div class="tit">Hora de voltar a estudar</div><div class="tempo" id="t">2:00</div></div>
            <div class="sub">Você está em <b>${esc(msg.host || 'um site de distração')}</b> e o cronômetro está parado. Esta aba fecha sozinha quando o tempo acabar.</div>
            <ul>
                <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="7" y="2.5" width="10" height="19" rx="2.5"/><path d="M11 18.5h2"/><path d="m3 3 18 18"/></svg><span>Desligue o celular ou coloque no modo silencioso.</span></li>
                <li><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a6 6 0 0 0-3.6 10.8c.7.6 1.1 1.3 1.1 2.2h5c0-.9.4-1.6 1.1-2.2A6 6 0 0 0 12 3Z"/><path d="M9.5 19h5M10.5 21.5h3"/></svg><span>Mentalize: esse cargo já é seu. Mas, por enquanto, você precisa abrir mão de outras coisas.</span></li>
            </ul>
            ${msg.primeiraVez ? '<p class="dica">Este aviso pode ser desativado em Configurações → Modo anti-procrastinação.</p>' : ''}
            <div class="acoes"><button class="btn" id="fechar">Fechar e voltar a estudar</button><button class="link" id="preciso">Preciso deste site agora (5 min)</button></div>
        </div>`;
    document.documentElement.appendChild(host);
    cbAntiProcHost = host;

    const rotulo = raiz.getElementById('t');
    const passo = () => {
        const resta = Math.max(0, fim - Date.now());
        const s = Math.ceil(resta / 1000);
        rotulo.textContent = `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
        cbAtualizarBarraDistracao((resta / TOTAL) * 100, resta);
        if (resta <= 0) { clearInterval(cbAntiProcTimer); cbAntiProcTimer = null; }
    };
    passo();
    cbAntiProcTimer = setInterval(passo, 500);

    raiz.getElementById('fechar').addEventListener('click', () => chrome.runtime.sendMessage({ action: 'cbAntiProcFecharAgora' }).catch(() => {}));
    raiz.getElementById('preciso').addEventListener('click', () => {
        chrome.runtime.sendMessage({ action: 'cbAntiProcPreciso' }).catch(() => {});
        cbEsconderAntiProc();
    });
}

// ==========================================================================
// Barrinha vermelha de contagem regressiva — aparece bem fina, colada no
// topo da página, quando a pessoa está numa aba de distração com a sessão
// de estudo rodando (modo online). Vai encolhendo da direita pra esquerda
// conforme o tempo passa, mostrando quanto falta antes do redirecionamento
// automático de volta pro sistema de questões.
// ==========================================================================
let cbDistractionBarEl = null;

function cbCriarBarraDistracao() {
    const el = document.createElement('div');
    el.id = 'cb-distraction-bar';
    el.style.cssText = `
        position: fixed; top: 0; left: 0; right: 0; z-index: 2147483647;
        height: 3px;
        pointer-events: none;
        background: rgba(0,0,0,0.15);
    `;
    const fill = document.createElement('div');
    fill.id = 'cb-distraction-bar-fill';
    fill.style.cssText = `
        height: 100%; width: 100%;
        background: linear-gradient(90deg, #ff453a, #ff8a80);
        box-shadow: 0 0 6px rgba(255,69,58,0.7);
        transform-origin: left;
        transition: width 1s linear;
    `;
    el.appendChild(fill);
    document.documentElement.appendChild(el);
    return el;
}

function cbAtualizarBarraDistracao(pct, restanteMs) {
    if (!cbDistractionBarEl) cbDistractionBarEl = cbCriarBarraDistracao();
    const fill = cbDistractionBarEl.querySelector('#cb-distraction-bar-fill');
    if (fill) {
        fill.style.width = `${Math.max(0, Math.min(100, pct))}%`;
        // Fica mais vermelho/urgente conforme o tempo acaba.
        if (pct <= 20) {
            fill.style.background = '#ff1a1a';
            fill.style.boxShadow = '0 0 10px rgba(255,26,26,0.9)';
        } else {
            fill.style.background = 'linear-gradient(90deg, #ff453a, #ff8a80)';
            fill.style.boxShadow = '0 0 6px rgba(255,69,58,0.7)';
        }
    }
    const restanteSeg = Math.ceil((restanteMs || 0) / 1000);
    cbDistractionBarEl.title = `Voltando para as questões em ${restanteSeg}s`;
}

function cbEsconderBarraDistracao() {
    if (!cbDistractionBarEl) return;
    const el = cbDistractionBarEl;
    cbDistractionBarEl = null;
    el.style.transition = 'opacity 0.3s ease';
    el.style.opacity = '0';
    setTimeout(() => el.remove(), 320);
}

function tocarAlertaPomodoro() {
    try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, ctx.currentTime); 
        gain.gain.setValueAtTime(0.3, ctx.currentTime);
        osc.start();
        osc.stop(ctx.currentTime + 0.5); 
    } catch(e) {}
}

checkState();

// --- HEARTBEAT (SINAL DE VIDA) ---
// Impede que o Chrome suspenda a extensão por inatividade no modo Offline.
setInterval(() => {
    chrome.storage.local.get(['sessionState'], (result) => {
        if (result.sessionState === 'running') {
            chrome.runtime.sendMessage({ action: 'keep_alive' }).catch(() => {});
        }
    });
}, 20000);

// ============================================================================
// ATALHO CTRL + WINDOWS — mostra o tempo de estudo de hoje no topo da tela,
// em qualquer site, sem precisar abrir a extensão. Funciona igual nos modos
// Online e Offline (a tela escura de bloqueio do modo Offline foi removida
// — ver comentário acima de "restOverlay" — então não duplica mais nada).
// ============================================================================
const CB_CLOCK_ICON = '<svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>';

const studyTimeHud = document.createElement('div');
studyTimeHud.id = 'cb-studytime-hud';
studyTimeHud.style.cssText = `
    position: fixed; top: 18px; left: 50%; transform: translateX(-50%) translateY(-12px);
    z-index: 2147483647;
    display: none; align-items: center; gap: 10px;
    padding: 10px 18px; border-radius: 999px;
    background: rgba(10, 12, 17, 0.92); backdrop-filter: blur(10px);
    border: 1px solid rgba(45, 212, 160, 0.35);
    box-shadow: 0 12px 30px rgba(0,0,0,0.35);
    color: #e7e9f0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px; font-weight: 700;
    opacity: 0; transition: opacity 0.25s ease, transform 0.25s ease;
    pointer-events: none;
`;
studyTimeHud.innerHTML = `
    <span style="color:#2dd4a0; display:flex;">${CB_CLOCK_ICON}</span>
    <span id="cb-studytime-hud-time" style="font-family:'SF Mono', Consolas, monospace; letter-spacing:0.5px; font-variant-numeric: tabular-nums;">00:00:00</span>
    <span id="cb-studytime-hud-status" style="font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:0.05em; color:#8b90a6;"></span>
`;
document.documentElement.appendChild(studyTimeHud);

let cbHudTickInterval = null;
let cbHudHideTimeout = null;

function cbFormatHHMMSS(ms) {
    let seconds = Math.floor(ms / 1000);
    let minutes = Math.floor(seconds / 60);
    let hours = Math.floor(minutes / 60);
    seconds %= 60;
    minutes %= 60;
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

function cbAtualizarHudTempo() {
    const d = new Date();
    const todayKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    chrome.storage.local.get(['studyHistory', 'sessionState'], (result) => {
        const ms = (result.studyHistory || {})[todayKey] || 0;
        const timeEl = document.getElementById('cb-studytime-hud-time');
        const statusEl = document.getElementById('cb-studytime-hud-status');
        if (timeEl) timeEl.innerText = cbFormatHHMMSS(ms);
        if (statusEl) {
            const state = result.sessionState || 'stopped';
            statusEl.innerText = state === 'running' ? 'estudando'
                : state.startsWith('paused') ? 'pausado' : 'parado';
        }
    });
}

function cbMostrarStudyTimeHud() {
    // Antes ficava suprimido no modo Offline porque a tela escura de
    // bloqueio já mostrava um cronômetro o tempo todo — como esse overlay
    // foi removido, o atalho passa a funcionar igual nos dois modos.
    cbAtualizarHudTempo();
    studyTimeHud.style.display = 'flex';
    requestAnimationFrame(() => {
        studyTimeHud.style.opacity = '1';
        studyTimeHud.style.transform = 'translateX(-50%) translateY(0)';
    });

    if (!cbHudTickInterval) cbHudTickInterval = setInterval(cbAtualizarHudTempo, 1000);

    clearTimeout(cbHudHideTimeout);
    cbHudHideTimeout = setTimeout(cbEsconderStudyTimeHud, 5000);
}

function cbEsconderStudyTimeHud() {
    studyTimeHud.style.opacity = '0';
    studyTimeHud.style.transform = 'translateX(-50%) translateY(-12px)';
    clearTimeout(cbHudHideTimeout);
    cbHudHideTimeout = null;
    setTimeout(() => {
        studyTimeHud.style.display = 'none';
        if (cbHudTickInterval) {
            clearInterval(cbHudTickInterval);
            cbHudTickInterval = null;
        }
    }, 250);
}

// Liga/desliga o atalho inteiro — controlado pela opção "Atalho Ctrl+Windows"
// nas Configurações. Mesmo padrão de cache local + chrome.storage.onChanged
// já usado pra "Barra flutuante (Dock)" logo abaixo neste arquivo: lê uma vez
// no carregamento e depois só atualiza quando a config muda, em vez de fazer
// uma leitura assíncrona a cada tecla apertada (o keydown dispara demais pra
// isso ser barato).
let cbAtalhoCtrlWinAtivo = true; // padrão: ligado, igual sempre foi até agora
chrome.storage.sync.get(['atalhoCtrlWinAtivo'], (result) => {
    cbAtalhoCtrlWinAtivo = result.atalhoCtrlWinAtivo !== false;
});
chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync' && changes.atalhoCtrlWinAtivo) {
        cbAtalhoCtrlWinAtivo = changes.atalhoCtrlWinAtivo.newValue !== false;
    }
});

document.addEventListener('keydown', (e) => {
    // Ctrl + Windows/Cmd (metaKey) — dispara só uma vez por combinação
    // pressionada (ignora o auto-repeat do sistema operacional).
    if (e.ctrlKey && e.metaKey && !e.repeat) {
        if (!cbAtalhoCtrlWinAtivo) return;
        cbMostrarStudyTimeHud();
    }
}, true);

// ============================================================================
// PAINEL DE PLANEJAMENTO (Ctrl + X) — overlay em tela cheia que substitui o
// antigo painel radial de atalhos. Reaproveita o mesmo mecanismo de injeção
// global (<all_urls>) já usado pelo HUD e pela tela offline acima. Guarda
// tudo em chrome.storage.local, então persiste entre sessões e sincroniza
// com o popup/dashboard se algo ler as mesmas chaves.
//
// ATENÇÃO Ctrl+X: é também o atalho padrão de "recortar". Por isso só
// disparamos o painel quando o foco NÃO está num campo editável (input,
// textarea, contenteditable) — assim quem está digitando em qualquer site
// continua recortando texto normalmente.
//
// Seções do painel:
//  1) Cronograma de hoje — lê cronogramaConfig/cronogramaProgresso, os
//     mesmos dados que o popup já usa, só que num resumo rápido.
//  2) Simulados da semana — agenda (data + nome) e depois permite marcar
//     como feito e registrar a nota. Guardado em chrome.storage.local
//     como "cbSimulados".
//  3) Post-its — notas soltas, arrastáveis, tipo as que a pessoa colaria
//     na parede do quarto. Guardado como "cbPostits".
//  4) Tabela de planejamento — grade fixa (Data / Matéria-Assunto / Página
//     ou Aula / Questões) editável célula a célula, no mesmo espírito das
//     planilhas de planner (cronograma de estudos, metas etc.). Guardado
//     como "cbPlannerTabela".
// ============================================================================

const CB_PLAN_ICON_CLOSE = '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18M6 6l12 12"/></svg>';
const CB_PLAN_ICON_PLUS = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>';
const CB_PLAN_ICON_CHECK = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>';
const CB_PLAN_ICON_TRASH = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>';

const CB_POSTIT_CORES = ['#fdf19a', '#ffd1dc', '#c9f5c1', '#bfe3ff', '#e6d1ff', '#ffd8ad'];

function cbGetDateKeyPlan(d) {
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// --------------------------------------------------------------------------
// Estrutura do painel
// --------------------------------------------------------------------------
const cbPlanStyleTag = document.createElement('style');
cbPlanStyleTag.textContent = `
#cb-plan { display:none; position:fixed; inset:0; z-index:2147483647;
  background: radial-gradient(1200px 700px at 50% 0%, rgba(45,212,160,0.07) 0%, transparent 60%), rgba(6,7,11,0.92);
  backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px);
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  color: #e7e9f0; opacity:0; transition: opacity 0.2s ease; overflow-y:auto; }
#cb-plan-inner { transform: scale(0.985); transition: transform 0.2s cubic-bezier(.2,.8,.2,1); }
#cb-plan.cb-plan-open { opacity:1; }
#cb-plan.cb-plan-open #cb-plan-inner { transform: scale(1); }
#cb-plan-inner { max-width: 1180px; margin: 0 auto; padding: 30px 34px 60px; box-sizing: border-box; }
.cb-plan-topbar { display:flex; align-items:center; justify-content:space-between; margin-bottom: 22px; }
.cb-plan-title { display:flex; align-items:center; gap:9px; font-size:13px; font-weight:800; letter-spacing:0.05em; color:#8b90a6; text-transform:uppercase; }
.cb-plan-title svg { color:#2dd4a0; }
.cb-plan-close { display:flex; align-items:center; gap:7px; background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.09);
  color:#aab0c2; border-radius:999px; padding:7px 13px; font-size:11.5px; font-weight:700; cursor:pointer; }
.cb-plan-close:hover { border-color:#2dd4a0; color:#2dd4a0; }
.cb-plan-grid { display:grid; grid-template-columns: 1fr 1fr; gap:18px; }
@media (max-width: 860px) { .cb-plan-grid { grid-template-columns: 1fr; } }
.cb-plan-card { background: rgba(16,19,28,0.78); border:1px solid rgba(255,255,255,0.07); border-radius:16px; padding:18px 18px 16px; }
.cb-plan-card h2 { margin:0 0 12px; font-size:12.5px; font-weight:800; letter-spacing:0.05em; text-transform:uppercase; color:#8b90a6; display:flex; align-items:center; justify-content:space-between; gap:8px; }
.cb-plan-empty { font-size:12px; color:#5c6376; font-style:italic; padding: 6px 2px 4px; }

/* Cronograma de hoje */
.cb-plan-cron-item { display:flex; align-items:center; gap:10px; padding:8px 4px; border-bottom:1px solid rgba(255,255,255,0.05); font-size:13px; }
.cb-plan-cron-item:last-child { border-bottom:none; }
.cb-plan-cron-check { width:18px; height:18px; border-radius:6px; border:1.5px solid #3a3f52; flex-shrink:0; cursor:pointer;
  display:flex; align-items:center; justify-content:center; color:transparent; }
.cb-plan-cron-check.done { background:#2dd4a0; border-color:#2dd4a0; color:#08090c; }
.cb-plan-cron-item span.done-text { text-decoration: line-through; color:#5c6376; }

/* Simulados */
.cb-plan-sim-form { display:flex; gap:6px; margin-bottom:12px; flex-wrap:wrap; }
.cb-plan-sim-form input { background:#0e1017; border:1px solid #262a3b; color:#e7e9f0; border-radius:8px; padding:7px 9px; font-size:12px; }
.cb-plan-sim-form input[type="date"] { flex: 0 0 132px; }
.cb-plan-sim-form input[type="text"] { flex: 1 1 120px; min-width:100px; }
.cb-plan-sim-add { background:#2dd4a0; border:none; color:#08090c; border-radius:8px; padding:0 12px; font-weight:800; cursor:pointer; display:flex; align-items:center; }
.cb-plan-sim-item { display:flex; align-items:center; gap:9px; padding:9px 4px; border-bottom:1px solid rgba(255,255,255,0.05); font-size:12.5px; }
.cb-plan-sim-item:last-child { border-bottom:none; }
.cb-plan-sim-date { font-family:'SF Mono', Consolas, monospace; font-size:11px; color:#7c8194; flex-shrink:0; width:58px; }
.cb-plan-sim-nome { flex:1; }
.cb-plan-sim-nome.done { text-decoration: line-through; color:#5c6376; }
.cb-plan-sim-nota { width:54px; background:#0e1017; border:1px solid #262a3b; color:#2dd4a0; border-radius:6px; padding:4px 6px; font-size:11px; text-align:center; }
.cb-plan-sim-done-btn { width:22px; height:22px; border-radius:50%; border:1.5px solid #3a3f52; background:transparent; color:transparent; cursor:pointer; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
.cb-plan-sim-done-btn.done { background:#2dd4a0; border-color:#2dd4a0; color:#08090c; }
.cb-plan-sim-del { background:transparent; border:none; color:#565c72; cursor:pointer; flex-shrink:0; display:flex; }
.cb-plan-sim-del:hover { color:#e5586b; }

/* Post-its flutuantes — camada independente do painel modal antigo, agora
   com fundo levemente escurecido (não opaco) + barra de opções à esquerda
   (cronograma de hoje + ações rápidas), e os post-its soltos no restante
   da tela, por cima da página atual. Aberta/fechada com Ctrl+X. */
#cb-postits-floating {
  position: fixed; inset: 0; z-index: 2147483646;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  pointer-events: none; opacity: 0; visibility: hidden;
  transition: opacity 0.18s ease;
}
#cb-postits-floating.cb-postits-open { opacity: 1; visibility: visible; pointer-events: auto; }

#cb-postits-backdrop {
  position: absolute; inset: 0;
  background: rgba(6,7,11,0.45);
  backdrop-filter: blur(2px); -webkit-backdrop-filter: blur(2px);
}

#cb-postits-sidebar {
  position: absolute; top: 0; left: 0; bottom: 0; width: 264px;
  background: rgba(12,14,20,0.94); border-right: 1px solid rgba(255,255,255,0.08);
  box-shadow: 12px 0 30px rgba(0,0,0,0.35);
  padding: 20px 18px; box-sizing: border-box; overflow-y: auto;
  color: #e7e9f0; display: flex; flex-direction: column; gap: 18px;
}
.cb-postits-sb-title { display:flex; align-items:center; gap:8px; font-size:12.5px; font-weight:800; letter-spacing:0.05em; text-transform:uppercase; color:#8b90a6; }
.cb-postits-sb-title svg { color:#2dd4a0; flex-shrink:0; }
.cb-postits-sb-close { display:flex; align-items:center; gap:6px; background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.09);
  color:#aab0c2; border-radius:999px; padding:6px 11px; font-size:11px; font-weight:700; cursor:pointer; align-self:flex-start; }
.cb-postits-sb-close:hover { border-color:#2dd4a0; color:#2dd4a0; }
.cb-postits-sb-section h3 { margin:0 0 10px; font-size:11.5px; font-weight:800; letter-spacing:0.05em; text-transform:uppercase; color:#7c8194; }
.cb-postits-sb-newbtn { display:flex; align-items:center; justify-content:center; gap:8px; width:100%; background:#2dd4a0; border:none; color:#08090c;
  border-radius:10px; padding:11px 12px; font-weight:800; font-size:12.5px; cursor:pointer; box-shadow: 0 6px 18px rgba(45,212,160,0.3); }
.cb-postits-sb-newbtn:hover { filter: brightness(1.06); transform: translateY(-1px); }
.cb-postits-sb-colors { display:flex; gap:8px; flex-wrap:wrap; margin-top:10px; }
.cb-postits-sb-color { width:24px; height:24px; border-radius:50%; cursor:pointer; border:2px solid transparent; box-shadow: inset 0 0 0 1px rgba(0,0,0,0.15); }
.cb-postits-sb-color.selected { border-color:#e7e9f0; transform: scale(1.1); }

#cb-postits-canvas {
  position: absolute; top: 0; right: 0; bottom: 0; left: 264px;
  overflow: hidden;
}
@media (max-width: 700px) {
  #cb-postits-sidebar { width: 100%; height: auto; bottom: auto; border-right: none; border-bottom: 1px solid rgba(255,255,255,0.08); }
  #cb-postits-canvas { left: 0; top: 170px; }
}

.cb-postit { position:absolute; width:170px; min-height:120px; border-radius:6px; padding:10px 10px 26px; box-shadow: 0 10px 24px rgba(0,0,0,0.45); cursor:grab; transform: rotate(var(--cb-rot, -2deg)); }
.cb-postit textarea { width:100%; height:84px; resize:none; border:none; background:transparent; font-family: inherit; font-size:13px; color:#20210f; line-height:1.35; outline:none; }
.cb-postit .cb-postit-del { position:absolute; bottom:6px; right:8px; background:transparent; border:none; color:rgba(0,0,0,0.35); cursor:pointer; display:flex; }
.cb-postit .cb-postit-del:hover { color:rgba(0,0,0,0.7); }

/* Tabela planner */
.cb-plan-table-wrap { grid-column: 1 / -1; overflow-x:auto; }
table.cb-plan-table { width:100%; border-collapse: collapse; font-size:12.5px; }
table.cb-plan-table th { text-align:left; font-size:10.5px; text-transform:uppercase; letter-spacing:0.05em; color:#7c8194; font-weight:800; padding:6px 8px; border-bottom:1px solid rgba(255,255,255,0.1); }
table.cb-plan-table td { padding:2px; border-bottom:1px solid rgba(255,255,255,0.05); }
table.cb-plan-table td[contenteditable] { padding:7px 8px; outline:none; border-radius:6px; min-width: 70px; }
table.cb-plan-table td[contenteditable]:focus { background: rgba(45,212,160,0.08); box-shadow: inset 0 0 0 1px rgba(45,212,160,0.4); }
table.cb-plan-table td[contenteditable]:empty:before { content: attr(data-ph); color:#4a5066; }
.cb-plan-table-del { background:transparent; border:none; color:#565c72; cursor:pointer; display:flex; }
.cb-plan-table-del:hover { color:#e5586b; }
.cb-plan-table-addrow { margin-top:10px; background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.09); color:#aab0c2; border-radius:8px; padding:7px 12px; font-size:11.5px; font-weight:700; cursor:pointer; display:inline-flex; align-items:center; gap:6px; }
.cb-plan-table-addrow:hover { border-color:#2dd4a0; color:#2dd4a0; }

/* ===================== ANIMAÇÕES ===================== */
@keyframes cbPlanCardIn { from { opacity:0; transform:translateY(14px) scale(0.98); } to { opacity:1; transform:translateY(0) scale(1); } }
.cb-plan-card { animation: cbPlanCardIn 0.32s cubic-bezier(.2,.8,.2,1) both; }
.cb-plan-grid > .cb-plan-card:nth-child(1) { animation-delay: 0ms; }
.cb-plan-grid > .cb-plan-card:nth-child(2) { animation-delay: 60ms; }
.cb-plan-grid > .cb-plan-card:nth-child(3) { animation-delay: 120ms; }
.cb-plan-grid > .cb-plan-card:nth-child(4) { animation-delay: 180ms; }
.cb-plan-card { transition: transform 0.18s ease, box-shadow 0.18s ease, border-color 0.18s ease; }
.cb-plan-card:hover { transform: translateY(-2px); border-color: rgba(45,212,160,0.25); box-shadow: 0 12px 28px rgba(0,0,0,0.28); }

@keyframes cbPlanItemIn { from { opacity:0; transform:translateX(-6px); } to { opacity:1; transform:translateX(0); } }
.cb-plan-cron-item, .cb-plan-sim-item { animation: cbPlanItemIn 0.24s ease both; }

.cb-plan-cron-check, .cb-plan-sim-done-btn { transition: transform 0.15s cubic-bezier(.4,0,.2,1.4), background 0.15s, border-color 0.15s; }
.cb-plan-cron-check.done, .cb-plan-sim-done-btn.done { animation: cbPlanCheckPop 0.28s cubic-bezier(.4,0,.2,1.6); }
@keyframes cbPlanCheckPop { 0% { transform:scale(0.7); } 60% { transform:scale(1.18); } 100% { transform:scale(1); } }
.cb-plan-cron-item span { transition: color 0.2s ease; }

@keyframes cbPostitPop { from { opacity:0; transform: scale(0.7) rotate(var(--cb-rot, -2deg)); } to { opacity:1; transform: scale(1) rotate(var(--cb-rot, -2deg)); } }
.cb-postit-enter { animation: cbPostitPop 0.28s cubic-bezier(.3,1.4,.4,1) both; }
.cb-postit { transition: box-shadow 0.15s ease, transform 0.1s ease; }
.cb-postit:hover { box-shadow: 0 12px 24px rgba(0,0,0,0.45); }
.cb-plan-sim-add { transition: transform 0.12s ease, filter 0.12s ease; }
.cb-plan-sim-add:hover { transform: translateY(-1px); filter: brightness(1.08); }
.cb-plan-table-addrow, .cb-plan-close { transition: transform 0.12s ease, border-color 0.15s, color 0.15s; }
.cb-plan-table-addrow:hover, .cb-plan-close:hover { transform: translateY(-1px); }

@media (prefers-reduced-motion: reduce) {
  .cb-plan-card, .cb-plan-cron-item, .cb-plan-sim-item, .cb-postit-enter,
  .cb-plan-cron-check.done, .cb-plan-sim-done-btn.done { animation: none !important; }
}
`;
document.head.appendChild(cbPlanStyleTag);

const cbPlan = document.createElement('div');
cbPlan.id = 'cb-plan';
cbPlan.innerHTML = `
  <div id="cb-plan-inner">
    <div class="cb-plan-topbar">
        <div class="cb-plan-title">${CB_SHIELD_ICON}<span>Painel de planejamento</span></div>
        <button class="cb-plan-close" id="cb-plan-close-btn">${CB_PLAN_ICON_CLOSE}<span>Esc para fechar</span></button>
    </div>
    <div class="cb-plan-grid">
        <div class="cb-plan-card">
            <h2><span>Cronograma de hoje</span></h2>
            <div id="cb-plan-cron-list"></div>
        </div>
        <div class="cb-plan-card">
            <h2><span>Simulados da semana</span></h2>
            <div class="cb-plan-sim-form">
                <input type="date" id="cb-plan-sim-data">
                <input type="text" id="cb-plan-sim-nome" placeholder="Nome do simulado (ex: TRT 2ª fase)">
                <button class="cb-plan-sim-add" id="cb-plan-sim-add-btn" title="Agendar">${CB_PLAN_ICON_PLUS}</button>
            </div>
            <div id="cb-plan-sim-list"></div>
        </div>
        <div class="cb-plan-card cb-plan-table-wrap">
            <h2><span>Tabela de planejamento</span></h2>
            <table class="cb-plan-table">
                <thead><tr>
                    <th style="width:110px;">Data</th>
                    <th>Matéria / assunto</th>
                    <th style="width:140px;">Página / aula</th>
                    <th style="width:90px;">Questões</th>
                    <th style="width:30px;"></th>
                </tr></thead>
                <tbody id="cb-plan-table-body"></tbody>
            </table>
            <button class="cb-plan-table-addrow" id="cb-plan-table-addrow-btn">${CB_PLAN_ICON_PLUS}<span>Nova linha</span></button>
        </div>
    </div>
  </div>
`;
document.documentElement.appendChild(cbPlan);

let cbPlanOpen = false;

function cbAbrirPlan() {
    if (cbPlanOpen) return;
    cbPlanOpen = true;
    cbPlan.style.display = 'block';
    requestAnimationFrame(() => cbPlan.classList.add('cb-plan-open'));
    const dataInput = document.getElementById('cb-plan-sim-data');
    if (dataInput && !dataInput.value) dataInput.value = cbGetDateKeyPlan(new Date());
    cbRenderCronogramaHoje('cb-plan-cron-list');
    cbRenderSimulados();
    cbRenderTabelaPlanner();
}

function cbFecharPlan() {
    if (!cbPlanOpen) return;
    cbPlanOpen = false;
    cbPlan.classList.remove('cb-plan-open');
    setTimeout(() => { if (!cbPlanOpen) cbPlan.style.display = 'none'; }, 180);
}

document.getElementById('cb-plan-close-btn').addEventListener('click', cbFecharPlan);
cbPlan.addEventListener('click', (e) => { if (e.target === cbPlan) cbFecharPlan(); });

function cbEhCampoEditavel(el) {
    if (!el) return false;
    const tag = (el.tagName || '').toLowerCase();
    return tag === 'input' || tag === 'textarea' || el.isContentEditable;
}

document.addEventListener('keydown', (e) => {
    // Ctrl+X sozinho — mas só fora de campos de texto, pra não roubar o
    // "recortar" de quem está digitando em qualquer site — agora abre/fecha
    // os post-its flutuantes direto em cima da página atual (sem escurecer
    // nem bloquear o resto da tela).
    if (e.ctrlKey && e.shiftKey && !e.altKey && !e.metaKey && (e.key === 'x' || e.key === 'X') && !e.repeat) {
        // Ctrl+Shift+X continua abrindo o painel completo (cronograma,
        // simulados e tabela de planejamento).
        if (cbEhCampoEditavel(e.target) || cbEhCampoEditavel(document.activeElement)) return;
        e.preventDefault();
        cbPlanOpen ? cbFecharPlan() : cbAbrirPlan();
        return;
    }
    if (e.ctrlKey && !e.shiftKey && !e.altKey && !e.metaKey && (e.key === 'x' || e.key === 'X') && !e.repeat) {
        if (cbEhCampoEditavel(e.target) || cbEhCampoEditavel(document.activeElement)) return;
        e.preventDefault();
        // No Planalto, Ctrl+X abre o painel do Marcador de Texto (novo
        // recurso) em vez do painel de post-its, que continua funcionando
        // normalmente em todos os outros sites.
        console.log('[Overlay] Ctrl+X capturado. host:', location.hostname, 'toggle disponível?', typeof window.__cbHighlighterToggle);
        if (location.hostname.endsWith('planalto.gov.br') && typeof window.__cbHighlighterToggle === 'function') {
            window.__cbHighlighterToggle();
            return;
        }
        cbPostitsAbertos ? cbFecharPostitsFlutuantes() : cbAbrirPostitsFlutuantes();
        return;
    }
    if (cbPlanOpen && e.key === 'Escape' && !cbEhCampoEditavel(e.target)) {
        e.preventDefault();
        cbFecharPlan();
        return;
    }
    if (cbPostitsAbertos && e.key === 'Escape' && !cbEhCampoEditavel(e.target)) {
        e.preventDefault();
        cbFecharPostitsFlutuantes();
    }
}, true);

// --------------------------------------------------------------------------
// 1) Cronograma de hoje — mesma lógica de índice de dia usada no popup.js
// --------------------------------------------------------------------------
function cbRenderCronogramaHoje(targetId) {
    const wrap = document.getElementById(targetId || 'cb-plan-cron-list');
    if (!wrap) return;
    chrome.storage.local.get(['cronogramaConfig', 'cronogramaProgresso'], (result) => {
        const config = result.cronogramaConfig;
        if (!config || !Array.isArray(config.dias) || config.dias.length === 0) {
            wrap.innerHTML = `<div class="cb-plan-empty">Nenhum cronograma configurado ainda. Configure em Configurações → Cronograma, no popup.</div>`;
            return;
        }
        const hoje = new Date();
        hoje.setHours(0, 0, 0, 0);
        const inicio = new Date(config.startDate + 'T00:00:00');
        const totalDias = config.dias.length;
        let diaIndex = Math.floor((hoje - inicio) / 86400000);
        diaIndex = Math.max(0, Math.min(totalDias - 1, diaIndex));

        const itens = config.dias[diaIndex] || [];
        if (itens.length === 0) {
            wrap.innerHTML = `<div class="cb-plan-empty">Nada programado para hoje no cronograma.</div>`;
            return;
        }
        const progresso = result.cronogramaProgresso || {};
        const marcados = progresso[diaIndex] || [];
        wrap.innerHTML = itens.map((texto, i) => `
            <div class="cb-plan-cron-item" style="animation-delay:${i * 35}ms">
                <div class="cb-plan-cron-check ${marcados[i] ? 'done' : ''}" data-i="${i}">${CB_PLAN_ICON_CHECK}</div>
                <span class="${marcados[i] ? 'done-text' : ''}">${cbEscapeHtml(cbTextoDoItemCronograma(texto))}</span>
            </div>
        `).join('');
        wrap.querySelectorAll('.cb-plan-cron-check').forEach(el => {
            el.addEventListener('click', () => {
                const i = Number(el.dataset.i);
                chrome.storage.local.get(['cronogramaProgresso'], (r2) => {
                    const prog = r2.cronogramaProgresso || {};
                    const doDia = prog[diaIndex] || new Array(itens.length).fill(false);
                    doDia[i] = !doDia[i];
                    prog[diaIndex] = doDia;
                    chrome.storage.local.set({ cronogramaProgresso: prog }, () => cbRenderCronogramaHoje(targetId));
                });
            });
        });
    });
}

// Itens do cronograma normalmente são texto puro, mas em algumas versões do
// cronograma cada dia guarda objetos ({materia, pagina, ...}) em vez de
// string — sem esse tratamento o item virava "[object Object]" na tela.
function cbTextoDoItemCronograma(item) {
    if (item == null) return '';
    if (typeof item === 'string') return item;
    if (typeof item === 'object') {
        const partes = [item.materia || item.assunto || item.titulo || item.nome, item.pagina || item.aula]
            .filter(Boolean);
        if (partes.length) return partes.join(' — ');
        return '';
    }
    return String(item);
}

function cbEscapeHtml(str) {
    const d = document.createElement('div');
    d.innerText = str == null ? '' : String(str);
    return d.innerHTML;
}

// --------------------------------------------------------------------------
// 2) Simulados da semana — agendar, marcar como feito, registrar nota
// --------------------------------------------------------------------------
function cbRenderSimulados() {
    const wrap = document.getElementById('cb-plan-sim-list');
    if (!wrap) return;
    chrome.storage.local.get(['cbSimulados'], (result) => {
        const lista = (result.cbSimulados || []).slice().sort((a, b) => (a.date || '').localeCompare(b.date || ''));
        if (lista.length === 0) {
            wrap.innerHTML = `<div class="cb-plan-empty">Nenhum simulado agendado. Adicione a data e o nome acima.</div>`;
            return;
        }
        wrap.innerHTML = lista.map(sim => `
            <div class="cb-plan-sim-item" data-id="${sim.id}">
                <span class="cb-plan-sim-date">${cbFormatDataCurta(sim.date)}</span>
                <button class="cb-plan-sim-done-btn ${sim.feito ? 'done' : ''}" data-action="toggle" title="Marcar como feito">${CB_PLAN_ICON_CHECK}</button>
                <span class="cb-plan-sim-nome ${sim.feito ? 'done' : ''}">${cbEscapeHtml(sim.nome)}</span>
                ${sim.feito ? `<input class="cb-plan-sim-nota" type="text" data-action="nota" placeholder="nota" value="${sim.nota ? cbEscapeHtml(sim.nota) : ''}">` : ''}
                <button class="cb-plan-sim-del" data-action="del" title="Remover">${CB_PLAN_ICON_TRASH}</button>
            </div>
        `).join('');

        wrap.querySelectorAll('[data-action="toggle"]').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = btn.closest('.cb-plan-sim-item').dataset.id;
                cbAtualizarSimulado(id, s => { s.feito = !s.feito; if (!s.feito) s.nota = ''; });
            });
        });
        wrap.querySelectorAll('[data-action="del"]').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = btn.closest('.cb-plan-sim-item').dataset.id;
                chrome.storage.local.get(['cbSimulados'], (r2) => {
                    const nova = (r2.cbSimulados || []).filter(s => s.id !== id);
                    chrome.storage.local.set({ cbSimulados: nova }, cbRenderSimulados);
                });
            });
        });
        wrap.querySelectorAll('[data-action="nota"]').forEach(input => {
            input.addEventListener('change', () => {
                const id = input.closest('.cb-plan-sim-item').dataset.id;
                cbAtualizarSimulado(id, s => { s.nota = input.value.trim(); });
            });
        });
    });
}

function cbFormatDataCurta(dateKey) {
    if (!dateKey) return '--/--';
    const [, m, d] = dateKey.split('-');
    return `${d}/${m}`;
}

function cbAtualizarSimulado(id, mutate) {
    chrome.storage.local.get(['cbSimulados'], (result) => {
        const lista = result.cbSimulados || [];
        const item = lista.find(s => s.id === id);
        if (!item) return;
        mutate(item);
        chrome.storage.local.set({ cbSimulados: lista }, cbRenderSimulados);
    });
}

document.getElementById('cb-plan-sim-add-btn').addEventListener('click', () => {
    const dataInput = document.getElementById('cb-plan-sim-data');
    const nomeInput = document.getElementById('cb-plan-sim-nome');
    const date = dataInput.value;
    const nome = nomeInput.value.trim();
    if (!date || !nome) return;
    chrome.storage.local.get(['cbSimulados'], (result) => {
        const lista = result.cbSimulados || [];
        lista.push({ id: 'sim_' + Date.now(), date, nome, feito: false, nota: '' });
        chrome.storage.local.set({ cbSimulados: lista }, () => {
            nomeInput.value = '';
            cbRenderSimulados();
        });
    });
});

// --------------------------------------------------------------------------
// 3) Post-its — agora flutuam direto em cima da página atual (sem painel
//    escuro, sem bloquear o resto da tela), abertos/fechados com Ctrl+X.
//    Continuam salvos por posição em % (agora relativa à janela) em
//    "cbPostits", então sincronizam entre abas e persistem normalmente.
// --------------------------------------------------------------------------
const cbPostitsLayer = document.createElement('div');
cbPostitsLayer.id = 'cb-postits-floating';
cbPostitsLayer.innerHTML = `
    <div id="cb-postits-backdrop"></div>
    <aside id="cb-postits-sidebar">
        <div class="cb-postits-sb-title">${CB_SHIELD_ICON}<span>Painel de planejamento</span></div>
        <button class="cb-postits-sb-close" id="cb-postits-close-btn">${CB_PLAN_ICON_CLOSE}<span>Ctrl+X ou Esc</span></button>
        <div class="cb-postits-sb-section">
            <h3>Cronograma de hoje</h3>
            <div id="cb-postits-cron-list"></div>
        </div>
        <div class="cb-postits-sb-section">
            <h3>Post-its</h3>
            <button class="cb-postits-sb-newbtn" id="cb-postits-add-btn">${CB_PLAN_ICON_PLUS}<span>Novo post-it</span></button>
            <div class="cb-postits-sb-colors" id="cb-postits-sb-colors"></div>
        </div>
    </aside>
    <div id="cb-postits-canvas"></div>
`;
document.documentElement.appendChild(cbPostitsLayer);

let cbPostitsAbertos = false;
let cbPostitCorSelecionada = CB_POSTIT_CORES[0];

function cbAbrirPostitsFlutuantes() {
    if (cbPostitsAbertos) return;
    cbPostitsAbertos = true;
    cbPostitsLayer.classList.add('cb-postits-open');
    cbRenderCronogramaHoje('cb-postits-cron-list');
    cbRenderPostits();
}

function cbFecharPostitsFlutuantes() {
    if (!cbPostitsAbertos) return;
    cbPostitsAbertos = false;
    cbPostitsLayer.classList.remove('cb-postits-open');
}

document.getElementById('cb-postits-close-btn').addEventListener('click', cbFecharPostitsFlutuantes);
document.getElementById('cb-postits-backdrop').addEventListener('click', cbFecharPostitsFlutuantes);
// A área vazia da tela (fora dos post-its e da barra lateral) também fecha,
// já que ela cobre visualmente o fundo escurecido.
document.getElementById('cb-postits-canvas').addEventListener('click', (e) => {
    if (e.target.id === 'cb-postits-canvas') cbFecharPostitsFlutuantes();
});

// Seletor de cor rápido — define a cor do próximo post-it criado.
(function cbMontarSeletorCores() {
    const wrap = document.getElementById('cb-postits-sb-colors');
    wrap.innerHTML = CB_POSTIT_CORES.map((cor, i) => `<div class="cb-postits-sb-color ${cor === cbPostitCorSelecionada ? 'selected' : ''}" data-cor="${cor}" style="background:${cor};"></div>`).join('');
    wrap.querySelectorAll('.cb-postits-sb-color').forEach(el => {
        el.addEventListener('click', () => {
            cbPostitCorSelecionada = el.dataset.cor;
            wrap.querySelectorAll('.cb-postits-sb-color').forEach(c => c.classList.remove('selected'));
            el.classList.add('selected');
        });
    });
})();

function cbRenderPostits() {
    const wrap = document.getElementById('cb-postits-canvas');
    if (!wrap) return;
    chrome.storage.local.get(['cbPostits'], (result) => {
        const notas = result.cbPostits || [];
        wrap.querySelectorAll('.cb-postit').forEach(el => el.remove());
        notas.forEach((nota, i) => wrap.appendChild(cbCriarPostitEl(nota, i)));
    });
}

// Sincroniza entre abas: se um post-it for criado/movido/apagado em outra
// aba enquanto esta está com os post-its abertos, reflete aqui também.
chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.cbPostits && cbPostitsAbertos) {
        cbRenderPostits();
    }
});

// Posição "espalhada" em grade (com um leve jitter aleatório) usada só
// quando o post-it ainda não tem x/y salvos — evita que post-its novos
// nasçam todos empilhados no mesmo canto.
function cbPosicaoPadraoPostit(indice) {
    const colunas = 4;
    const col = indice % colunas;
    const linha = Math.floor(indice / colunas);
    const jitterX = (Math.random() * 6 - 3);
    const jitterY = (Math.random() * 6 - 3);
    return {
        x: Math.min(80, 6 + col * 22 + jitterX),
        y: Math.min(75, 12 + linha * 30 + jitterY)
    };
}

function cbCriarPostitEl(nota, indice) {
    const pos = (nota.x == null || nota.y == null) ? cbPosicaoPadraoPostit(indice || 0) : null;
    const el = document.createElement('div');
    el.className = 'cb-postit cb-postit-enter';
    el.dataset.id = nota.id;
    el.style.left = (nota.x ?? pos.x) + '%';
    el.style.top = (nota.y ?? pos.y) + '%';
    el.style.background = nota.cor || CB_POSTIT_CORES[0];
    el.style.setProperty('--cb-rot', (nota.rot ?? -2) + 'deg');
    el.style.animationDelay = ((indice || 0) * 45) + 'ms';
    el.innerHTML = `<textarea placeholder="Escreva aqui...">${cbEscapeHtml(nota.texto || '')}</textarea><button class="cb-postit-del" title="Remover">${CB_PLAN_ICON_TRASH}</button>`;

    const textarea = el.querySelector('textarea');
    let salvarTimeout = null;
    textarea.addEventListener('input', () => {
        clearTimeout(salvarTimeout);
        salvarTimeout = setTimeout(() => cbAtualizarPostit(nota.id, p => { p.texto = textarea.value; }), 400);
    });
    textarea.addEventListener('pointerdown', (e) => e.stopPropagation());

    el.querySelector('.cb-postit-del').addEventListener('click', (e) => {
        e.stopPropagation();
        chrome.storage.local.get(['cbPostits'], (r2) => {
            const restantes = (r2.cbPostits || []).filter(p => p.id !== nota.id);
            chrome.storage.local.set({ cbPostits: restantes }, cbRenderPostits);
        });
    });

    cbTornarPostitArrastavel(el, nota.id);
    return el;
}

function cbTornarPostitArrastavel(el, id) {
    let arrastando = false, offsetX = 0, offsetY = 0, pointerId = null;
    el.addEventListener('pointerdown', (e) => {
        if (e.target.closest('.cb-postit-del')) return;
        arrastando = true;
        pointerId = e.pointerId;
        const rect = el.parentElement.getBoundingClientRect();
        offsetX = e.clientX - el.offsetLeft - rect.left;
        offsetY = e.clientY - el.offsetTop - rect.top;
        el.style.cursor = 'grabbing';
        try { el.setPointerCapture(pointerId); } catch (err) {}
    });
    el.addEventListener('pointermove', (e) => {
        if (!arrastando) return;
        const rect = el.parentElement.getBoundingClientRect();
        const x = e.clientX - rect.left - offsetX;
        const y = e.clientY - rect.top - offsetY;
        const pctX = Math.min(94, Math.max(0, (x / rect.width) * 100));
        const pctY = Math.min(90, Math.max(0, (y / rect.height) * 100));
        el.style.left = pctX + '%';
        el.style.top = pctY + '%';
    });
    function soltar() {
        if (!arrastando) return;
        arrastando = false;
        el.style.cursor = 'grab';
        cbAtualizarPostit(id, p => {
            p.x = parseFloat(el.style.left);
            p.y = parseFloat(el.style.top);
        }, true);
    }
    el.addEventListener('pointerup', soltar);
    el.addEventListener('pointercancel', soltar);
}

function cbAtualizarPostit(id, mutate, semRerender) {
    chrome.storage.local.get(['cbPostits'], (result) => {
        const lista = result.cbPostits || [];
        const item = lista.find(p => p.id === id);
        if (!item) return;
        mutate(item);
        chrome.storage.local.set({ cbPostits: lista }, () => { if (!semRerender) cbRenderPostits(); });
    });
}

function cbCriarNovoPostit(focarTexto) {
    chrome.storage.local.get(['cbPostits'], (result) => {
        const lista = result.cbPostits || [];
        const nova = {
            id: 'note_' + Date.now(),
            texto: '',
            x: 6 + Math.random() * 60,
            y: 10 + Math.random() * 55,
            cor: cbPostitCorSelecionada || CB_POSTIT_CORES[lista.length % CB_POSTIT_CORES.length],
            rot: Math.round((Math.random() * 6 - 3) * 10) / 10
        };
        lista.push(nova);
        chrome.storage.local.set({ cbPostits: lista }, () => {
            cbRenderPostits();
            if (focarTexto) {
                setTimeout(() => {
                    const el = document.querySelector(`#cb-postits-canvas .cb-postit[data-id="${nova.id}"] textarea`);
                    if (el) el.focus();
                }, 60);
            }
        });
    });
}

document.getElementById('cb-postits-add-btn').addEventListener('click', () => cbCriarNovoPostit(true));

// --------------------------------------------------------------------------
// 4) Tabela de planejamento — grade editável estilo planner (Data / Matéria
//    / Página-aula / Questões), como as planilhas de cronograma de estudos.
// --------------------------------------------------------------------------
function cbRenderTabelaPlanner() {
    const body = document.getElementById('cb-plan-table-body');
    if (!body) return;
    chrome.storage.local.get(['cbPlannerTabela'], (result) => {
        let linhas = result.cbPlannerTabela;
        if (!Array.isArray(linhas) || linhas.length === 0) {
            linhas = [{ data: '', materia: '', pagina: '', questoes: '' }];
        }
        body.innerHTML = linhas.map((linha, i) => `
            <tr data-i="${i}">
                <td contenteditable="true" data-campo="data" data-ph="dd/mm">${cbEscapeHtml(linha.data)}</td>
                <td contenteditable="true" data-campo="materia" data-ph="matéria / assunto">${cbEscapeHtml(linha.materia)}</td>
                <td contenteditable="true" data-campo="pagina" data-ph="pág. ou aula">${cbEscapeHtml(linha.pagina)}</td>
                <td contenteditable="true" data-campo="questoes" data-ph="0/0">${cbEscapeHtml(linha.questoes)}</td>
                <td><button class="cb-plan-table-del" title="Remover linha">${CB_PLAN_ICON_TRASH}</button></td>
            </tr>
        `).join('');

        body.querySelectorAll('td[contenteditable]').forEach(td => {
            td.addEventListener('blur', () => cbSalvarCelulaPlanner(td));
        });
        body.querySelectorAll('.cb-plan-table-del').forEach(btn => {
            btn.addEventListener('click', () => {
                const i = Number(btn.closest('tr').dataset.i);
                chrome.storage.local.get(['cbPlannerTabela'], (r2) => {
                    const atuais = r2.cbPlannerTabela || linhas;
                    atuais.splice(i, 1);
                    chrome.storage.local.set({ cbPlannerTabela: atuais }, cbRenderTabelaPlanner);
                });
            });
        });
    });
}

function cbSalvarCelulaPlanner(td) {
    const i = Number(td.closest('tr').dataset.i);
    const campo = td.dataset.campo;
    chrome.storage.local.get(['cbPlannerTabela'], (result) => {
        const linhas = Array.isArray(result.cbPlannerTabela) && result.cbPlannerTabela.length > 0
            ? result.cbPlannerTabela
            : [{ data: '', materia: '', pagina: '', questoes: '' }];
        if (!linhas[i]) linhas[i] = { data: '', materia: '', pagina: '', questoes: '' };
        linhas[i][campo] = td.innerText.trim();
        chrome.storage.local.set({ cbPlannerTabela: linhas });
    });
}

document.getElementById('cb-plan-table-addrow-btn').addEventListener('click', () => {
    chrome.storage.local.get(['cbPlannerTabela'], (result) => {
        const linhas = result.cbPlannerTabela || [];
        linhas.push({ data: '', materia: '', pagina: '', questoes: '' });
        chrome.storage.local.set({ cbPlannerTabela: linhas }, cbRenderTabelaPlanner);
    });
});


// ============================================================================
// CRONÔMETRO FLUTUANTE — o usuário "arranca" o cronômetro do popup (arrastando
// o número) e ele fica solto por cima da página, em qualquer aba, até ser
// encaixado de volta. Posição arrastável e persistida entre sessões.
// ============================================================================
// Se a extensão foi recarregada/atualizada com esta aba já aberta, pode sobrar
// uma instância antiga deste widget na página (script antigo ainda rodando em
// paralelo com o novo) — remove qualquer uma antes de criar a atual, senão dá
// pra existirem dois elementos com o mesmo id e o clique ir parar no errado.
document.getElementById('cb-floating-timer')?.remove();

const floatingTimer = document.createElement('div');
floatingTimer.id = 'cb-floating-timer';
floatingTimer.style.cssText = `
    display: none; position: fixed; z-index: 2147483647;
    align-items: center; gap: 10px;
    background: rgba(10, 12, 17, 0.94); backdrop-filter: blur(10px);
    border: 1px solid rgba(45, 212, 160, 0.35);
    box-shadow: 0 14px 34px rgba(0,0,0,0.4);
    color: #e7e9f0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    cursor: grab; user-select: none; touch-action: none;
    --cb-ft-accent: #2dd4a0;
`;
floatingTimer.innerHTML = `
    <span id="cb-floating-timer-icon" style="color:var(--cb-ft-accent); display:flex; flex-shrink:0;">${CB_SHIELD_ICON}</span>
    <div class="cb-ft-text" style="display:flex; flex-direction:column; line-height:1.15;">
        <span id="cb-floating-timer-time" style="font-family:'SF Mono', Consolas, monospace; font-weight:800; letter-spacing:0.5px; font-variant-numeric: tabular-nums;">00:00:00</span>
        <span id="cb-floating-timer-status" style="font-weight:700; text-transform:uppercase; letter-spacing:0.05em; color:#8b90a6;"></span>
    </div>
    <button id="cb-floating-timer-close" title="Encaixar de volta no popup" style="
        display:flex; align-items:center; justify-content:center;
        width:20px; height:20px; margin-left:2px; padding:0; border-radius:50%;
        border:none; background:rgba(255,255,255,0.06); color:#8b90a6; cursor:pointer; flex-shrink:0;
    ">
        <svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
    </button>
`;
document.documentElement.appendChild(floatingTimer);


// Folha de estilos com as combinações de tamanho/formato — os mesmos nomes de
// classe usados na prévia do popup, pra o resultado bater exatamente com o
// que a pessoa configurou em Configurações → Cronômetro Flutuante.
const cbFloatingTimerStyleTag = document.createElement('style');
cbFloatingTimerStyleTag.textContent = `
#cb-floating-timer.cb-ft-shape-pill { border-radius: 999px; padding: 10px 10px 10px 14px; }
#cb-floating-timer.cb-ft-shape-card { border-radius: 14px; padding: 10px 10px 10px 14px; }
#cb-floating-timer.cb-ft-shape-circle {
    border-radius: 50%; flex-direction: column; justify-content: center;
    padding: 0; text-align: center; gap: 2px; overflow: hidden;
}
#cb-floating-timer.cb-ft-shape-circle #cb-floating-timer-icon,
#cb-floating-timer.cb-ft-shape-circle #cb-floating-timer-status { display: none !important; }
#cb-floating-timer.cb-ft-shape-circle #cb-floating-timer-close {
    position: absolute; top: -6px; right: -6px;
    background: rgba(10,12,17,0.94); box-shadow: 0 2px 8px rgba(0,0,0,0.4);
}
/* Fontes específicas do Círculo, menores que Pílula/Cartão: nesse formato
   o texto mostrado é "HH:MM" (sem segundos, ver cbAtualizarFloatingTimer)
   porque o "00:00:00" completo (8 caracteres) não cabia numa bolinha de
   54-84px de largura fixa — estourava e virava uma bagunça ilegível de
   dígitos sobrepostos em vez de um número. */
#cb-floating-timer.cb-ft-size-sm.cb-ft-shape-circle #cb-floating-timer-time { font-size: 13px; }
#cb-floating-timer.cb-ft-size-md.cb-ft-shape-circle #cb-floating-timer-time { font-size: 16px; }
#cb-floating-timer.cb-ft-size-lg.cb-ft-shape-circle #cb-floating-timer-time { font-size: 20px; }

#cb-floating-timer.cb-ft-size-sm #cb-floating-timer-time { font-size: 12px; }
#cb-floating-timer.cb-ft-size-sm #cb-floating-timer-status { font-size: 8.5px; }
#cb-floating-timer.cb-ft-size-sm.cb-ft-shape-pill, #cb-floating-timer.cb-ft-size-sm.cb-ft-shape-card { padding: 7px 7px 7px 10px; gap: 7px; }
#cb-floating-timer.cb-ft-size-sm.cb-ft-shape-circle { width: 54px; height: 54px; }

#cb-floating-timer.cb-ft-size-md #cb-floating-timer-time { font-size: 15px; }
#cb-floating-timer.cb-ft-size-md #cb-floating-timer-status { font-size: 9.5px; }
#cb-floating-timer.cb-ft-size-md.cb-ft-shape-circle { width: 68px; height: 68px; }

#cb-floating-timer.cb-ft-size-lg #cb-floating-timer-time { font-size: 19px; }
#cb-floating-timer.cb-ft-size-lg #cb-floating-timer-status { font-size: 10.5px; }
#cb-floating-timer.cb-ft-size-lg.cb-ft-shape-pill, #cb-floating-timer.cb-ft-size-lg.cb-ft-shape-card { padding: 13px 13px 13px 18px; gap: 13px; }
#cb-floating-timer.cb-ft-size-lg.cb-ft-shape-circle { width: 84px; height: 84px; }
`;
document.head.appendChild(cbFloatingTimerStyleTag);

function cbAplicarEstiloFloatingTimer() {
    chrome.storage.local.get(['floatingTimerSize', 'floatingTimerShape', 'floatingTimerColor'], (result) => {
        const size = result.floatingTimerSize || 'md';
        const shape = result.floatingTimerShape || 'pill';
        const color = result.floatingTimerColor || '#2dd4a0';
        floatingTimer.className = `cb-ft-size-${size} cb-ft-shape-${shape}`;
        floatingTimer.style.setProperty('--cb-ft-accent', color);
        floatingTimer.style.borderColor = color + '59'; // ~35% de opacidade
    });
}
cbAplicarEstiloFloatingTimer();

let cbFloatTickInterval = null;

function cbAtualizarFloatingTimer() {
    const d = new Date();
    const todayKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    chrome.storage.local.get(['studyHistory', 'sessionState', 'pomodoroMode', 'pomodoroState'], (result) => {
        const ms = (result.studyHistory || {})[todayKey] || 0;
        const timeEl = floatingTimer.querySelector('#cb-floating-timer-time');
        const statusEl = floatingTimer.querySelector('#cb-floating-timer-status');
        if (timeEl) {
            const ehCirculo = floatingTimer.classList.contains('cb-ft-shape-circle');
            // No Círculo o espaço é fixo e pequeno — "HH:MM" (sem segundos)
            // sempre cabe direito; o "HH:MM:SS" completo só faz sentido no
            // Pílula/Cartão, que crescem em largura conforme o conteúdo.
            timeEl.innerText = ehCirculo ? cbFormatHHMMSS(ms).slice(0, 5) : cbFormatHHMMSS(ms);
        }
        if (statusEl) {
            const state = result.sessionState || 'stopped';
            // Cobre a retomada manual (botão Play) durante o descanso do
            // Pomodoro: sessionState vira 'running' mas pomodoroState
            // continua 'rest' — sem isso o status mostrava "estudando"
            // ainda dentro do intervalo de descanso.
            const emPausaPomodoro = result.pomodoroMode && result.pomodoroState === 'rest';
            statusEl.innerText = emPausaPomodoro ? 'pausado'
                : state === 'running' ? 'estudando'
                : state.startsWith('paused') ? 'pausado' : 'parado';
        }
    });
}

function cbPosicionarFloatingTimerDefault() {
    // Canto inferior direito por padrão, com uma margem segura.
    const rect = floatingTimer.getBoundingClientRect();
    const w = rect.width || 180;
    const h = rect.height || 46;
    return { x: Math.max(12, window.innerWidth - w - 24), y: Math.max(12, window.innerHeight - h - 24) };
}

function cbAplicarPosicaoFloatingTimer(pos) {
    if (!pos) return;
    const maxX = Math.max(0, window.innerWidth - floatingTimer.offsetWidth);
    const maxY = Math.max(0, window.innerHeight - floatingTimer.offsetHeight);
    const x = Math.min(Math.max(0, pos.x), maxX);
    const y = Math.min(Math.max(0, pos.y), maxY);
    floatingTimer.style.left = x + 'px';
    floatingTimer.style.top = y + 'px';
}

function cbMostrarFloatingTimer() {
    floatingTimer.style.display = 'flex';
    cbAplicarEstiloFloatingTimer();
    chrome.storage.local.get(['floatingTimerPos'], (result) => {
        cbAplicarPosicaoFloatingTimer(result.floatingTimerPos || cbPosicionarFloatingTimerDefault());
    });
    cbAtualizarFloatingTimer();
    if (!cbFloatTickInterval) cbFloatTickInterval = setInterval(cbAtualizarFloatingTimer, 1000);
}

function cbEsconderFloatingTimer() {
    floatingTimer.style.display = 'none';
    if (cbFloatTickInterval) { clearInterval(cbFloatTickInterval); cbFloatTickInterval = null; }
}

function cbChecarFloatingTimer() {
    chrome.storage.local.get(['floatingTimerEnabled', 'floatingTimerFeatureEnabled'], (result) => {
        const recursoHabilitado = result.floatingTimerFeatureEnabled !== false; // ausente = ligado por padrão
        if (result.floatingTimerEnabled && recursoHabilitado) cbMostrarFloatingTimer();
        else cbEsconderFloatingTimer();
    });
}
cbChecarFloatingTimer();

chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.floatingTimerEnabled || changes.floatingTimerFeatureEnabled) cbChecarFloatingTimer();
    if ((changes.floatingTimerSize || changes.floatingTimerShape || changes.floatingTimerColor) && floatingTimer.style.display !== 'none') {
        cbAplicarEstiloFloatingTimer();
    }
});

floatingTimer.querySelector('#cb-floating-timer-close').addEventListener('click', (e) => {
    e.stopPropagation();
    chrome.storage.local.set({ floatingTimerEnabled: false });
});

// --- arrastar o widget pela tela e lembrar onde foi solto ---
(function tornarFloatingTimerArrastavel() {
    let arrastando = false, offsetX = 0, offsetY = 0, pointerId = null, moveu = false;

    floatingTimer.addEventListener('pointerdown', (e) => {
        if (e.target.closest('#cb-floating-timer-close')) return;
        if (e.button !== undefined && e.button !== 0) return;
        arrastando = true;
        moveu = false;
        pointerId = e.pointerId;
        const rect = floatingTimer.getBoundingClientRect();
        offsetX = e.clientX - rect.left;
        offsetY = e.clientY - rect.top;
        floatingTimer.style.cursor = 'grabbing';
        try { floatingTimer.setPointerCapture(pointerId); } catch (err) {}
    });

    floatingTimer.addEventListener('pointermove', (e) => {
        if (!arrastando) return;
        moveu = true;
        const x = e.clientX - offsetX;
        const y = e.clientY - offsetY;
        cbAplicarPosicaoFloatingTimer({ x, y });
    });

    function soltar() {
        if (!arrastando) return;
        arrastando = false;
        floatingTimer.style.cursor = 'grab';
        if (moveu) {
            const rect = floatingTimer.getBoundingClientRect();
            chrome.storage.local.set({ floatingTimerPos: { x: rect.left, y: rect.top } });
        }
    }
    floatingTimer.addEventListener('pointerup', soltar);
    floatingTimer.addEventListener('pointercancel', soltar);
})();

window.addEventListener('resize', () => {
    if (floatingTimer.style.display !== 'none') {
        chrome.storage.local.get(['floatingTimerPos'], (result) => {
            cbAplicarPosicaoFloatingTimer(result.floatingTimerPos || cbPosicionarFloatingTimerDefault());
        });
    }
});
// ============================================================================
// 4) Barra Dock — substitui o antigo gatilho isolado do post-it por uma
//    barra inferior tipo "dock", que aparece ao levar o mouse até a borda
//    de baixo da tela (ou ao passar o mouse sobre a barrinha discreta que
//    fica sempre visível). Dentro dela: Post-it, Mapa Mental, o botão
//    central "Hub" (abre o painel cheio com cronômetro e desempenho),
//    Agenda pessoal, atalhos do próprio site, leis do Planalto anexadas
//    pelo usuário (CPC, CC, CF, CTN...) e "eventos" (pastas), tudo
//    reorganizável por arrastar e removível jogando no ícone de lixeira.
// ============================================================================

const CB_DOCK_ICONS = {
    postit: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>',
    mapa: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="6" cy="6" r="3"/><circle cx="18" cy="6" r="3"/><circle cx="12" cy="18" r="3"/><path d="M8.5 7.5 11 15M15.5 7.5 13 15M9 6h6"/></svg>',
    agenda: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>',
    atalho: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>',
    lei: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V4H6.5A2.5 2.5 0 0 0 4 6.5z"/><path d="M4 19.5V6.5"/></svg>',
    evento: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2z"/></svg>',
    hub: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>',
    mais: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>',
    lixo: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0-1 14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2L4 6"/></svg>',
    fogo: '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" stroke="none"><path d="M12 2c1 3-3 4-3 8a3 3 0 0 0 6 0c0-1-.5-2-1-2.5 2 .5 4 3 4 6.5a6 6 0 0 1-12 0c0-5 4-6 6-12Z"/></svg>',
    fechar: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18M6 6l12 12"/></svg>'
};

const CB_DOCK_STORAGE_KEY = 'cbDockItens';
const CB_DOCK_MAX_EVENTOS = 6;

function cbDockIdUnico() {
    return 'd' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function cbDockItensPadrao() {
    const itens = [
        { id: 'fixo-postit', tipo: 'postit', nome: 'Post-it', fixo: true },
        { id: 'fixo-mapa', tipo: 'mapa', nome: 'Mapa Mental', fixo: true },
        { id: 'fixo-hub', tipo: 'hub', nome: 'Painel', fixo: true },
        { id: 'fixo-agenda', tipo: 'agenda', nome: 'Agenda', fixo: true }
    ];
    // No QConcursos, três atalhos internos do próprio site já vêm prontos
    // como sugestão inicial (o usuário pode apagar/reorganizar depois).
    if (location.hostname.endsWith('qconcursos.com')) {
        itens.push({ id: cbDockIdUnico(), tipo: 'atalho', nome: 'Questões', url: 'https://www.qconcursos.com/questoes-de-concursos/questoes' });
        itens.push({ id: cbDockIdUnico(), tipo: 'atalho', nome: 'Cadernos', url: 'https://www.qconcursos.com/cadernos-de-questoes' });
        itens.push({ id: cbDockIdUnico(), tipo: 'atalho', nome: 'Simulados', url: 'https://www.qconcursos.com/simulados' });
    }
    return itens;
}

let cbDockItens = [];
let cbDockCarregado = false;
let cbDockArrastandoId = null;

const cbDockStyleTag = document.createElement('style');
cbDockStyleTag.textContent = `
#cb-dock-nub {
    position: fixed; left: 50%; bottom: 0; transform: translate(-50%, 0);
    width: 120px; height: 18px; z-index: 2147483000; cursor: pointer;
    display: flex; align-items: flex-end; justify-content: center; padding-bottom: 5px;
}
#cb-dock-nub span {
    width: 54px; height: 5px; border-radius: 4px; background: rgba(255,255,255,0.28);
    transition: background 0.15s ease, width 0.15s ease;
}
#cb-dock-nub:hover span { background: rgba(45,212,160,0.85); width: 70px; }

#cb-dock-bar {
    position: fixed; left: 50%; bottom: 10px; z-index: 2147483001;
    transform: translate(-50%, 140%); opacity: 0;
    display: flex; align-items: center; gap: 6px;
    background: rgba(14,15,20,0.92); backdrop-filter: blur(14px) saturate(140%);
    border: 1px solid rgba(255,255,255,0.08); border-radius: 22px;
    padding: 7px 10px; box-shadow: 0 14px 40px rgba(0,0,0,0.5);
    transition: transform 0.22s cubic-bezier(.2,.9,.3,1.2), opacity 0.18s ease;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    max-width: 92vw; overflow-x: auto; scrollbar-width: none;
}
#cb-dock-bar::-webkit-scrollbar { display: none; }
#cb-dock-bar.cb-dock-visivel { transform: translate(-50%, 0); opacity: 1; }

.cb-dock-item {
    position: relative; display: flex; align-items: center; justify-content: center;
    width: 38px; height: 38px; border-radius: 12px; flex-shrink: 0;
    background: rgba(255,255,255,0.05); color: #c9cde0; cursor: grab;
    transition: background 0.15s ease, transform 0.12s ease, color 0.15s ease;
    user-select: none;
}
.cb-dock-item:hover { background: rgba(255,255,255,0.12); color: #fff; transform: translateY(-2px); }
.cb-dock-item.cb-dock-arrastando { opacity: 0.35; }
.cb-dock-item.cb-dock-hub {
    width: 46px; height: 46px; margin: 0 2px; color: #08090c;
    background: linear-gradient(135deg, #2dd4a0, #22b98d);
    box-shadow: 0 0 0 3px rgba(45,212,160,0.15), 0 6px 18px rgba(45,212,160,0.35);
}
.cb-dock-item.cb-dock-hub:hover { transform: translateY(-3px) scale(1.04); }
.cb-dock-item .cb-dock-badge {
    position: absolute; top: -3px; right: -3px; background: #ff6767; color: #fff;
    font-size: 9px; font-weight: 800; border-radius: 8px; padding: 1px 4px; line-height: 1.3;
}
.cb-dock-tip {
    position: absolute; bottom: 46px; left: 50%; transform: translateX(-50%);
    background: #16171f; color: #e7e9f0; font-size: 11px; font-weight: 600;
    padding: 4px 8px; border-radius: 6px; white-space: nowrap; pointer-events: none;
    opacity: 0; transition: opacity 0.12s ease; border: 1px solid rgba(255,255,255,0.08);
}
.cb-dock-item:hover .cb-dock-tip { opacity: 1; }

.cb-dock-sep { width: 1px; height: 24px; background: rgba(255,255,255,0.1); margin: 0 2px; flex-shrink: 0; }

.cb-dock-item.cb-dock-lixeira {
    color: #ff8a8a; background: rgba(255,90,90,0.08); display: none;
}
#cb-dock-bar.cb-dock-arraste-ativo .cb-dock-lixeira { display: flex; }
.cb-dock-item.cb-dock-lixeira.cb-dock-hover-lixo { background: #ff5a5a; color: #fff; transform: scale(1.08); }
.cb-dock-item.cb-dock-hover-evento { background: #ffd27a; color: #08090c; transform: scale(1.12); }

#cb-dock-addmenu {
    position: fixed; z-index: 2147483002; background: #16171f; border: 1px solid rgba(255,255,255,0.1);
    border-radius: 12px; padding: 6px; min-width: 200px; box-shadow: 0 14px 30px rgba(0,0,0,0.5);
    display: none; flex-direction: column; gap: 2px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}
#cb-dock-addmenu.cb-dock-open { display: flex; }
#cb-dock-addmenu button {
    display: flex; align-items: center; gap: 9px; background: transparent; border: none;
    color: #d7d9e6; font-size: 12.5px; font-weight: 600; padding: 9px 10px; border-radius: 8px;
    cursor: pointer; text-align: left;
}
#cb-dock-addmenu button:hover { background: rgba(45,212,160,0.12); color: #2dd4a0; }

#cb-dock-evento-popover {
    position: fixed; z-index: 2147483002; width: 260px; max-height: 320px;
    background: #16171f; border: 1px solid rgba(255,255,255,0.1); border-radius: 14px;
    padding: 12px; box-shadow: 0 14px 30px rgba(0,0,0,0.5); display: none; flex-direction: column; gap: 8px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; color: #e7e9f0;
}
#cb-dock-evento-popover.cb-dock-open { display: flex; }
#cb-dock-evento-popover h4 { margin: 0; font-size: 13px; font-weight: 800; }
#cb-dock-evento-lista { display: flex; flex-direction: column; gap: 6px; max-height: 190px; overflow-y: auto; }
.cb-dock-evento-card { background: rgba(255,255,255,0.05); border-radius: 8px; padding: 7px 9px; font-size: 12px; display: flex; justify-content: space-between; gap: 8px; align-items: flex-start; }
.cb-dock-evento-card span { word-break: break-word; }
.cb-dock-evento-card button { background: transparent; border: none; color: #7c8194; cursor: pointer; flex-shrink: 0; }
.cb-dock-evento-card button:hover { color: #ff8a8a; }
#cb-dock-evento-addcard { display: flex; gap: 6px; }
#cb-dock-evento-addcard input {
    flex: 1; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1);
    border-radius: 7px; padding: 6px 8px; color: #fff; font-size: 12px;
}
#cb-dock-evento-addcard button {
    background: #2dd4a0; border: none; color: #08090c; border-radius: 7px; padding: 0 10px; font-weight: 800; cursor: pointer;
}

/* --------- Painel Hub (tela cheia: cronômetro + desempenho) --------- */
#cb-hub-overlay {
    display: none; position: fixed; inset: 0; z-index: 2147483005;
    background: radial-gradient(700px 420px at 50% 0%, rgba(45,212,160,0.10) 0%, transparent 60%), #08090c;
    color: #e7e9f0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    overflow-y: auto;
}
#cb-hub-overlay.cb-dock-open { display: block; }
.cb-hub-topbar { display: flex; align-items: center; justify-content: space-between; padding: 18px 26px; }
.cb-hub-brand { display: flex; align-items: center; gap: 8px; font-weight: 800; font-size: 14px; color: #cfd2e3; }
.cb-hub-streak { display: flex; align-items: center; gap: 5px; background: rgba(255,255,255,0.06); padding: 5px 10px; border-radius: 20px; font-size: 12px; font-weight: 800; color: #ffb454; }
.cb-hub-close { background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1); color: #cfd2e3; border-radius: 10px; width: 34px; height: 34px; display: flex; align-items: center; justify-content: center; cursor: pointer; }
.cb-hub-close:hover { border-color: #ff8a8a; color: #ff8a8a; }
.cb-hub-tabs { display: flex; justify-content: center; gap: 8px; margin: 6px 0 26px; }
.cb-hub-tab { background: rgba(255,255,255,0.05); border: none; color: #9aa0b4; padding: 9px 16px; border-radius: 20px; font-weight: 700; font-size: 12.5px; cursor: pointer; display: flex; gap: 7px; align-items: center; }
.cb-hub-tab.ativa { background: rgba(45,212,160,0.16); color: #2dd4a0; }
.cb-hub-tab b { background: rgba(255,255,255,0.08); border-radius: 10px; padding: 0 6px; font-size: 11px; }
.cb-hub-tab.ativa b { background: rgba(45,212,160,0.25); }
.cb-hub-timerwrap { display: flex; flex-direction: column; align-items: center; padding: 10px 20px 34px; }
.cb-hub-ring { position: relative; width: 260px; height: 260px; }
.cb-hub-ring svg { transform: rotate(-90deg); }
.cb-hub-ring-track { fill: none; stroke: rgba(255,255,255,0.08); stroke-width: 8; }
.cb-hub-ring-fill { fill: none; stroke: #2dd4a0; stroke-width: 8; stroke-linecap: round; transition: stroke-dashoffset 0.3s linear; }
.cb-hub-ring-center { position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 6px; }
.cb-hub-time { font-size: 46px; font-weight: 800; font-variant-numeric: tabular-nums; letter-spacing: 1px; }
.cb-hub-sublabel { font-size: 11.5px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.06em; color: #7c8194; }
.cb-hub-startbtn { margin-top: 22px; background: linear-gradient(135deg,#2dd4a0,#22b98d); color: #08090c; border: none; font-weight: 800; font-size: 14px; padding: 13px 34px; border-radius: 30px; cursor: pointer; display: flex; align-items: center; gap: 8px; }
.cb-hub-startbtn:hover { filter: brightness(1.06); }
.cb-hub-section { max-width: 620px; margin: 0 auto 40px; padding: 0 26px; }
.cb-hub-section h3 { font-size: 13px; text-transform: uppercase; letter-spacing: 0.06em; color: #7c8194; margin: 0 0 12px; }
.cb-hub-desemp { display: flex; gap: 10px; }
.cb-hub-desemp-card { flex: 1; background: rgba(255,255,255,0.05); border-radius: 12px; padding: 14px; }
.cb-hub-desemp-card .num { font-size: 24px; font-weight: 800; }
.cb-hub-desemp-card .lab { font-size: 11px; color: #8b90a6; font-weight: 700; text-transform: uppercase; }
.cb-hub-desemp-card.acertos .num { color: #2dd4a0; }
.cb-hub-desemp-card.erros .num { color: #ff6767; }
.cb-hub-bar { height: 8px; border-radius: 6px; background: rgba(255,255,255,0.08); overflow: hidden; margin-top: 14px; }
.cb-hub-bar-fill { height: 100%; background: linear-gradient(90deg,#2dd4a0,#22b98d); }
.cb-hub-quicklinks { display: flex; gap: 10px; flex-wrap: wrap; }
.cb-hub-quicklink { display: flex; align-items: center; gap: 8px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.08); color: #d7d9e6; padding: 10px 14px; border-radius: 10px; cursor: pointer; font-size: 12.5px; font-weight: 700; }
.cb-hub-quicklink:hover { border-color: #2dd4a0; color: #2dd4a0; }

/* --------- Mapa Mental (desenho livre + cartões de texto) --------- */
#cb-mapa-overlay {
    display: none; position: fixed; inset: 0; z-index: 2147483005; background: #0b0c11; color: #e7e9f0;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}
#cb-mapa-overlay.cb-dock-open { display: flex; flex-direction: column; }
.cb-mapa-toolbar { display: flex; align-items: center; gap: 10px; padding: 10px 16px; border-bottom: 1px solid rgba(255,255,255,0.08); flex-wrap: wrap; }
.cb-mapa-toolbar button { background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1); color: #d7d9e6; border-radius: 8px; padding: 7px 12px; font-size: 12px; font-weight: 700; cursor: pointer; display: flex; align-items: center; gap: 6px; }
.cb-mapa-toolbar button:hover { border-color: #2dd4a0; color: #2dd4a0; }
.cb-mapa-toolbar button.ativo { background: rgba(45,212,160,0.18); border-color: #2dd4a0; color: #2dd4a0; }
.cb-mapa-cores { display: flex; gap: 5px; }
.cb-mapa-cor { width: 20px; height: 20px; border-radius: 50%; cursor: pointer; border: 2px solid transparent; }
.cb-mapa-cor.selected { border-color: #fff; }
.cb-mapa-canvaswrap { position: relative; flex: 1; overflow: hidden; }
#cb-mapa-canvas { position: absolute; inset: 0; width: 100%; height: 100%; cursor: crosshair; }
.cb-mapa-cartao {
    position: absolute; min-width: 130px; min-height: 70px; padding: 10px 12px; border-radius: 10px;
    color: #1a1a1a; font-size: 13px; font-weight: 600; cursor: move; box-shadow: 0 10px 24px rgba(0,0,0,0.4);
    outline: none; resize: both; overflow: auto;
}
.cb-mapa-cartao .cb-mapa-cartao-del { position: absolute; top: 4px; right: 5px; background: rgba(0,0,0,0.15); border: none; border-radius: 5px; width: 18px; height: 18px; cursor: pointer; color: rgba(0,0,0,0.5); font-size: 11px; line-height: 1; }

#cb-mapa-galeria {
    position: fixed; z-index: 2147483006; width: 280px; max-height: 360px;
    background: #16171f; border: 1px solid rgba(255,255,255,0.1); border-radius: 14px;
    padding: 12px; box-shadow: 0 14px 30px rgba(0,0,0,0.5); display: none; flex-direction: column; gap: 8px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; color: #e7e9f0;
}
#cb-mapa-galeria.cb-dock-open { display: flex; }
#cb-mapa-galeria h4 { margin: 0; font-size: 13px; font-weight: 800; }
#cb-mapa-galeria-lista { display: flex; flex-direction: column; gap: 7px; max-height: 280px; overflow-y: auto; }
.cb-mapa-galeria-item { display: flex; align-items: center; gap: 9px; background: rgba(255,255,255,0.05); border-radius: 9px; padding: 6px; cursor: pointer; }
.cb-mapa-galeria-item:hover { background: rgba(45,212,160,0.14); }
.cb-mapa-galeria-item img { width: 52px; height: 34px; object-fit: cover; border-radius: 5px; background: #0b0c11; flex-shrink: 0; }
.cb-mapa-galeria-item .nome { flex: 1; font-size: 12.5px; font-weight: 700; word-break: break-word; }
.cb-mapa-galeria-item button { background: transparent; border: none; color: #7c8194; cursor: pointer; flex-shrink: 0; }
.cb-mapa-galeria-item button:hover { color: #ff8a8a; }
.cb-mapa-galeria-vazio { font-size: 12px; color: #7c8194; text-align: center; padding: 14px 0; }

@media (max-width: 640px) {
    .cb-hub-ring { width: 210px; height: 210px; }
    .cb-hub-time { font-size: 36px; }
}
`;
document.head.appendChild(cbDockStyleTag);

// --------------------------------------------------------------------------
// Estrutura fixa da barra (nub + dock) e do menu de "adicionar item".
// --------------------------------------------------------------------------
const cbDockNub = document.createElement('div');
cbDockNub.id = 'cb-dock-nub';
cbDockNub.innerHTML = '<span></span>';
document.documentElement.appendChild(cbDockNub);

const cbDockBar = document.createElement('div');
cbDockBar.id = 'cb-dock-bar';
document.documentElement.appendChild(cbDockBar);

const cbDockAddMenu = document.createElement('div');
cbDockAddMenu.id = 'cb-dock-addmenu';
cbDockAddMenu.innerHTML = `
    <button data-acao="atalho">${CB_DOCK_ICONS.atalho}<span>Atalho do site</span></button>
    <button data-acao="lei">${CB_DOCK_ICONS.lei}<span>Lei do Planalto</span></button>
    <button data-acao="evento">${CB_DOCK_ICONS.evento}<span>Novo evento</span></button>
`;
document.documentElement.appendChild(cbDockAddMenu);

const cbDockEventoPopover = document.createElement('div');
cbDockEventoPopover.id = 'cb-dock-evento-popover';
document.documentElement.appendChild(cbDockEventoPopover);

// --------------------------------------------------------------------------
// Mostrar / esconder a barra ao aproximar o mouse da borda inferior.
// --------------------------------------------------------------------------
let cbDockTimeoutEsconder = null;
let cbDockMousePertoDaBorda = false;
let cbDockMouseSobreABarra = false;

function cbDockAtualizarVisibilidade() {
    const deveMostrar = cbDockMousePertoDaBorda || cbDockMouseSobreABarra;
    clearTimeout(cbDockTimeoutEsconder);
    if (deveMostrar) {
        cbDockBar.classList.add('cb-dock-visivel');
    } else {
        cbDockTimeoutEsconder = setTimeout(() => {
            if (!cbDockMouseSobreABarra) cbDockBar.classList.remove('cb-dock-visivel');
        }, 700);
    }
}

// --------------------------------------------------------------------------
// Liga/desliga a barra inteira — controlado pela opção "Barra flutuante
// (Dock)" nas Configurações. Quando desativada, a barra e a bolinha (nub)
// ficam escondidas e o listener de mousemove não faz nada.
// --------------------------------------------------------------------------
// TRAVADO EM DESATIVADO POR ENQUANTO: a barra flutuante (Dock) ainda não
// está finalizada, então ela fica sempre desligada aqui, independente do
// que estiver salvo em `dockHoverEnabled` — remova a linha abaixo (e volte
// a ler o valor de chrome.storage.sync normalmente) quando o recurso
// estiver pronto pra liberar de novo pro usuário decidir.
const CB_DOCK_TRAVADO_DESATIVADO = true;
let cbDockHoverAtivado = !CB_DOCK_TRAVADO_DESATIVADO;

function cbDockAplicarAtivacao() {
    if (cbDockHoverAtivado) {
        cbDockNub.style.display = '';
        cbDockBar.style.display = '';
    } else {
        cbDockMousePertoDaBorda = false;
        cbDockMouseSobreABarra = false;
        clearTimeout(cbDockTimeoutEsconder);
        cbDockBar.classList.remove('cb-dock-visivel');
        cbDockNub.style.display = 'none';
        cbDockBar.style.display = 'none';
    }
}

chrome.storage.sync.get(['dockHoverEnabled'], (result) => {
    cbDockHoverAtivado = CB_DOCK_TRAVADO_DESATIVADO ? false : (result.dockHoverEnabled !== false);
    cbDockAplicarAtivacao();
});

chrome.storage.onChanged.addListener((changes, area) => {
    if (CB_DOCK_TRAVADO_DESATIVADO) return; // travado: ignora mudanças na config enquanto não finalizado
    if (area === 'sync' && changes.dockHoverEnabled) {
        cbDockHoverAtivado = changes.dockHoverEnabled.newValue !== false;
        cbDockAplicarAtivacao();
    }
});

document.addEventListener('mousemove', (e) => {
    if (!cbDockHoverAtivado) return;
    const pertoAgora = (window.innerHeight - e.clientY) < 60;
    if (pertoAgora !== cbDockMousePertoDaBorda) {
        cbDockMousePertoDaBorda = pertoAgora;
        cbDockAtualizarVisibilidade();
    }
});
cbDockBar.addEventListener('mouseenter', () => { if (cbDockHoverAtivado) { cbDockMouseSobreABarra = true; cbDockAtualizarVisibilidade(); } });
cbDockBar.addEventListener('mouseleave', () => { cbDockMouseSobreABarra = false; cbDockAtualizarVisibilidade(); });
cbDockNub.addEventListener('mouseenter', () => { if (cbDockHoverAtivado) { cbDockMousePertoDaBorda = true; cbDockAtualizarVisibilidade(); } });

// --------------------------------------------------------------------------
// Persistência — os itens da barra sincronizam entre abas via
// chrome.storage.local, igual ao resto da extensão.
// --------------------------------------------------------------------------
function cbDockSalvar() {
    chrome.storage.local.set({ [CB_DOCK_STORAGE_KEY]: cbDockItens });
}

function cbDockCarregarEDesenhar() {
    chrome.storage.local.get([CB_DOCK_STORAGE_KEY], (result) => {
        if (Array.isArray(result[CB_DOCK_STORAGE_KEY]) && result[CB_DOCK_STORAGE_KEY].length) {
            cbDockItens = result[CB_DOCK_STORAGE_KEY];
        } else {
            cbDockItens = cbDockItensPadrao();
            cbDockSalvar();
        }
        cbDockCarregado = true;
        cbDockRenderizar();
    });
}

chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes[CB_DOCK_STORAGE_KEY]) {
        cbDockItens = changes[CB_DOCK_STORAGE_KEY].newValue || [];
        cbDockRenderizar();
    }
});

// --------------------------------------------------------------------------
// Desenho da barra + drag and drop para reordenar / arrastar até a lixeira.
// --------------------------------------------------------------------------
function cbDockRenderizar() {
    if (!cbDockCarregado) return;
    cbDockBar.innerHTML = '';

    cbDockItens.forEach((item) => {
        const el = document.createElement('div');
        el.className = 'cb-dock-item' + (item.tipo === 'hub' ? ' cb-dock-hub' : '');
        el.draggable = true;
        el.dataset.id = item.id;
        const icone = CB_DOCK_ICONS[item.tipo] || CB_DOCK_ICONS.atalho;
        el.innerHTML = `${icone}<span class="cb-dock-tip">${item.nome}</span>`;
        if (item.tipo === 'evento') {
            el.style.color = '#ffd27a';
        }
        el.addEventListener('click', () => cbDockAcionarItem(item));
        el.addEventListener('dragstart', (e) => {
            cbDockArrastandoId = item.id;
            el.classList.add('cb-dock-arrastando');
            cbDockBar.classList.add('cb-dock-arraste-ativo');
            e.dataTransfer.effectAllowed = 'move';
        });
        el.addEventListener('dragend', () => {
            el.classList.remove('cb-dock-arrastando');
            cbDockBar.classList.remove('cb-dock-arraste-ativo');
            cbDockArrastandoId = null;
        });
        el.addEventListener('dragover', (e) => {
            e.preventDefault();
            if (!cbDockArrastandoId || cbDockArrastandoId === item.id) return;
            const origem = cbDockItens.find(i => i.id === cbDockArrastandoId);
            // Soltar um Post-it ou uma Lei em cima de um Evento não reordena —
            // vira um cartão de atalho dentro daquele evento.
            if (item.tipo === 'evento' && origem && (origem.tipo === 'lei' || origem.tipo === 'postit')) {
                el.classList.add('cb-dock-hover-evento');
                return;
            }
            const doOrigem = cbDockItens.findIndex(i => i.id === cbDockArrastandoId);
            const doDestino = cbDockItens.findIndex(i => i.id === item.id);
            if (doOrigem < 0 || doDestino < 0) return;
            const [mov] = cbDockItens.splice(doOrigem, 1);
            cbDockItens.splice(doDestino, 0, mov);
            cbDockRenderizar();
        });
        el.addEventListener('dragleave', () => el.classList.remove('cb-dock-hover-evento'));
        el.addEventListener('drop', (e) => {
            e.preventDefault();
            el.classList.remove('cb-dock-hover-evento');
            const origem = cbDockItens.find(i => i.id === cbDockArrastandoId);
            if (item.tipo === 'evento' && origem && (origem.tipo === 'lei' || origem.tipo === 'postit') && origem.id !== item.id) {
                item.cartoes = item.cartoes || [];
                item.cartoes.push(
                    origem.tipo === 'lei'
                        ? { texto: origem.nome, tipo: 'lei', url: origem.url }
                        : { texto: 'Post-it (abrir)', tipo: 'postit' }
                );
                cbDockSalvar();
                cbDockRenderizar();
                return;
            }
            cbDockSalvar();
        });
        cbDockBar.appendChild(el);
    });

    // separador antes das ações fixas da direita (adicionar / lixeira)
    const sep = document.createElement('div');
    sep.className = 'cb-dock-sep';
    cbDockBar.appendChild(sep);

    const addBtn = document.createElement('div');
    addBtn.className = 'cb-dock-item';
    addBtn.innerHTML = `${CB_DOCK_ICONS.mais}<span class="cb-dock-tip">Adicionar</span>`;
    addBtn.addEventListener('click', (e) => cbDockAbrirAddMenu(e));
    cbDockBar.appendChild(addBtn);

    const lixeira = document.createElement('div');
    lixeira.className = 'cb-dock-item cb-dock-lixeira';
    lixeira.innerHTML = `${CB_DOCK_ICONS.lixo}<span class="cb-dock-tip">Soltar aqui remove</span>`;
    lixeira.addEventListener('dragover', (e) => { e.preventDefault(); lixeira.classList.add('cb-dock-hover-lixo'); });
    lixeira.addEventListener('dragleave', () => lixeira.classList.remove('cb-dock-hover-lixo'));
    lixeira.addEventListener('drop', (e) => {
        e.preventDefault();
        lixeira.classList.remove('cb-dock-hover-lixo');
        const item = cbDockItens.find(i => i.id === cbDockArrastandoId);
        if (!item) return;
        if (item.fixo) {
            alert('Esse item é fixo e não pode ser removido — só reorganizado.');
            return;
        }
        if (!confirm(`Remover "${item.nome}" da barra?`)) return;
        cbDockItens = cbDockItens.filter(i => i.id !== item.id);
        cbDockSalvar();
        cbDockRenderizar();
    });
    cbDockBar.appendChild(lixeira);
}

function cbDockAcionarItem(item) {
    switch (item.tipo) {
        case 'postit':
            cbPostitsAbertos ? cbFecharPostitsFlutuantes() : cbAbrirPostitsFlutuantes();
            break;
        case 'mapa':
            cbAbrirMapaMental();
            break;
        case 'hub':
            cbAbrirHub();
            break;
        case 'agenda':
            window.open(chrome.runtime.getURL('rotina/rotina-diaria.html'), '_blank');
            break;
        case 'atalho':
        case 'lei':
            window.open(item.url, '_blank');
            break;
        case 'evento':
            cbDockAbrirEventoPopover(item);
            break;
    }
}

// --------------------------------------------------------------------------
// Menu "+" — adicionar atalho, lei do Planalto ou evento (pasta).
// --------------------------------------------------------------------------
function cbDockAbrirAddMenu(e) {
    e.stopPropagation();
    const rect = e.currentTarget.getBoundingClientRect();
    cbDockAddMenu.style.left = Math.min(rect.left, window.innerWidth - 220) + 'px';
    cbDockAddMenu.style.top = (rect.top - 8) + 'px';
    cbDockAddMenu.style.transform = 'translateY(-100%)';
    cbDockAddMenu.classList.add('cb-dock-open');
}
document.addEventListener('click', (e) => {
    if (!cbDockAddMenu.contains(e.target)) cbDockAddMenu.classList.remove('cb-dock-open');
    if (!cbDockEventoPopover.contains(e.target) && !e.target.closest('.cb-dock-item')) {
        cbDockEventoPopover.classList.remove('cb-dock-open');
    }
});
cbDockAddMenu.querySelectorAll('button').forEach(btn => {
    btn.addEventListener('click', () => {
        cbDockAddMenu.classList.remove('cb-dock-open');
        const acao = btn.dataset.acao;
        if (acao === 'atalho') {
            const nome = prompt('Nome do atalho:');
            if (!nome) return;
            cbDockItens.push({ id: cbDockIdUnico(), tipo: 'atalho', nome, url: location.href });
        } else if (acao === 'lei') {
            const nome = prompt('Nome (ex: CPC, CC, CF, CTN):');
            if (!nome) return;
            const url = prompt('Link da lei no planalto.gov.br:', location.hostname.endsWith('planalto.gov.br') ? location.href : 'https://www.planalto.gov.br/ccivil_03/leis/');
            if (!url) return;
            cbDockItens.push({ id: cbDockIdUnico(), tipo: 'lei', nome, url });
        } else if (acao === 'evento') {
            const qtdAtual = cbDockItens.filter(i => i.tipo === 'evento').length;
            if (qtdAtual >= CB_DOCK_MAX_EVENTOS) {
                alert(`Limite de ${CB_DOCK_MAX_EVENTOS} eventos na barra atingido.`);
                return;
            }
            const nome = prompt('Nome do evento:');
            if (!nome) return;
            cbDockItens.push({ id: cbDockIdUnico(), tipo: 'evento', nome, cartoes: [] });
        }
        cbDockSalvar();
        cbDockRenderizar();
    });
});

// --------------------------------------------------------------------------
// Pasta de evento — pequeno painel com cartões de texto livres.
// --------------------------------------------------------------------------
function cbDockAbrirEventoPopover(item) {
    const el = cbDockBar.querySelector(`[data-id="${item.id}"]`);
    const rect = el.getBoundingClientRect();
    cbDockEventoPopover.style.left = Math.max(10, Math.min(rect.left, window.innerWidth - 280)) + 'px';
    cbDockEventoPopover.style.top = (rect.top - 8) + 'px';
    cbDockEventoPopover.style.transform = 'translateY(-100%)';

    function desenhar() {
        const atual = cbDockItens.find(i => i.id === item.id);
        if (!atual) { cbDockEventoPopover.classList.remove('cb-dock-open'); return; }
        cbDockEventoPopover.innerHTML = `
            <h4>${atual.nome}</h4>
            <div id="cb-dock-evento-lista"></div>
            <div id="cb-dock-evento-addcard">
                <input type="text" placeholder="Adicionar item..." maxlength="140">
                <button>${CB_DOCK_ICONS.mais}</button>
            </div>
        `;
        const lista = cbDockEventoPopover.querySelector('#cb-dock-evento-lista');
        (atual.cartoes || []).forEach((c, idx) => {
            // Cartões antigos eram só texto puro; cartões novos (arrastados da
            // barra) são objetos { texto, tipo, url } — aceita os dois formatos.
            const cartao = typeof c === 'string' ? { texto: c, tipo: 'nota' } : c;
            const card = document.createElement('div');
            card.className = 'cb-dock-evento-card';
            const rotulo = cartao.tipo === 'lei' ? `${CB_DOCK_ICONS.lei} ` : cartao.tipo === 'postit' ? `${CB_DOCK_ICONS.postit} ` : '';
            card.innerHTML = `<span style="display:flex; align-items:center; gap:6px; ${cartao.tipo !== 'nota' ? 'cursor:pointer;' : ''}">${rotulo}${cartao.texto}</span><button title="remover">${CB_DOCK_ICONS.fechar}</button>`;
            if (cartao.tipo === 'lei' && cartao.url) {
                card.querySelector('span').addEventListener('click', () => window.open(cartao.url, '_blank'));
            } else if (cartao.tipo === 'postit') {
                card.querySelector('span').addEventListener('click', () => {
                    cbDockEventoPopover.classList.remove('cb-dock-open');
                    cbAbrirPostitsFlutuantes();
                });
            }
            card.querySelector('button').addEventListener('click', () => {
                atual.cartoes.splice(idx, 1);
                cbDockSalvar();
                desenhar();
            });
            lista.appendChild(card);
        });
        const input = cbDockEventoPopover.querySelector('#cb-dock-evento-addcard input');
        const addBtn = cbDockEventoPopover.querySelector('#cb-dock-evento-addcard button');
        function addCartao() {
            const v = input.value.trim();
            if (!v) return;
            atual.cartoes = atual.cartoes || [];
            atual.cartoes.push({ texto: v, tipo: 'nota' });
            cbDockSalvar();
            desenhar();
        }
        addBtn.addEventListener('click', addCartao);
        input.addEventListener('keydown', (e) => { if (e.key === 'Enter') addCartao(); });
    }
    desenhar();
    cbDockEventoPopover.classList.add('cb-dock-open');
}

// --------------------------------------------------------------------------
// Painel Hub — cronômetro Pomodoro (Foco / Pausa curta / Pausa longa) +
// resumo de desempenho, aberto pelo botão central da barra.
// --------------------------------------------------------------------------
const cbHubOverlay = document.createElement('div');
cbHubOverlay.id = 'cb-hub-overlay';
document.documentElement.appendChild(cbHubOverlay);

const CB_HUB_DURACOES = { foco: 25 * 60, curta: 5 * 60, longa: 15 * 60 };
let cbHubModo = 'foco';
let cbHubSegundosRestantes = CB_HUB_DURACOES.foco;
let cbHubRodando = false;
let cbHubIntervalo = null;
let cbHubContadores = { foco: 0, curta: 0, longa: 0 };

function cbHubFormatarTempo(s) {
    const m = Math.floor(s / 60).toString().padStart(2, '0');
    const seg = Math.floor(s % 60).toString().padStart(2, '0');
    return `${m}:${seg}`;
}

function cbHubMontarHTML() {
    cbHubOverlay.innerHTML = `
        <div class="cb-hub-topbar">
            <div class="cb-hub-brand">${CB_SHIELD_ICON}<span>Painel de Estudo</span></div>
            <div style="display:flex; align-items:center; gap:10px;">
                <div class="cb-hub-streak">${CB_DOCK_ICONS.fogo}<span id="cb-hub-streak-num">0</span></div>
                <div class="cb-hub-close" id="cb-hub-close">${CB_DOCK_ICONS.fechar}</div>
            </div>
        </div>
        <div class="cb-hub-tabs">
            <button class="cb-hub-tab" data-modo="foco">Foco <b id="cb-hub-count-foco">0</b></button>
            <button class="cb-hub-tab" data-modo="curta">Pausa curta <b id="cb-hub-count-curta">0</b></button>
            <button class="cb-hub-tab" data-modo="longa">Pausa longa <b id="cb-hub-count-longa">0</b></button>
        </div>
        <div class="cb-hub-timerwrap">
            <div class="cb-hub-ring">
                <svg width="260" height="260" viewBox="0 0 260 260">
                    <circle class="cb-hub-ring-track" cx="130" cy="130" r="118"></circle>
                    <circle class="cb-hub-ring-fill" id="cb-hub-ring-fill" cx="130" cy="130" r="118" stroke-dasharray="741" stroke-dashoffset="0"></circle>
                </svg>
                <div class="cb-hub-ring-center">
                    <div class="cb-hub-time" id="cb-hub-time">25:00</div>
                    <div class="cb-hub-sublabel" id="cb-hub-sublabel">Sessão de Foco</div>
                </div>
            </div>
            <button class="cb-hub-startbtn" id="cb-hub-startbtn">▶ Começar</button>
        </div>
        <div class="cb-hub-section">
            <h3>Desempenho</h3>
            <div class="cb-hub-desemp">
                <div class="cb-hub-desemp-card acertos"><div class="num" id="cb-hub-acertos">0</div><div class="lab">Acertos</div></div>
                <div class="cb-hub-desemp-card erros"><div class="num" id="cb-hub-erros">0</div><div class="lab">Erros</div></div>
            </div>
            <div class="cb-hub-bar"><div class="cb-hub-bar-fill" id="cb-hub-bar-fill" style="width:0%"></div></div>
        </div>
        <div class="cb-hub-section">
            <h3>Acesso rápido</h3>
            <div class="cb-hub-quicklinks">
                <div class="cb-hub-quicklink" data-q="postit">${CB_DOCK_ICONS.postit} Post-it</div>
                <div class="cb-hub-quicklink" data-q="mapa">${CB_DOCK_ICONS.mapa} Mapa mental</div>
                <div class="cb-hub-quicklink" data-q="agenda">${CB_DOCK_ICONS.agenda} Agenda pessoal</div>
            </div>
        </div>
    `;

    cbHubOverlay.querySelector('#cb-hub-close').addEventListener('click', cbFecharHub);
    cbHubOverlay.querySelectorAll('.cb-hub-tab').forEach(tab => {
        tab.addEventListener('click', () => cbHubTrocarModo(tab.dataset.modo));
    });
    cbHubOverlay.querySelector('#cb-hub-startbtn').addEventListener('click', cbHubAlternarRodando);
    cbHubOverlay.querySelectorAll('.cb-hub-quicklink').forEach(q => {
        q.addEventListener('click', () => {
            const tipo = q.dataset.q;
            if (tipo === 'postit') { cbFecharHub(); cbAbrirPostitsFlutuantes(); }
            if (tipo === 'mapa') { cbFecharHub(); cbAbrirMapaMental(); }
            if (tipo === 'agenda') window.open(chrome.runtime.getURL('rotina/rotina-diaria.html'), '_blank');
        });
    });
}

function cbHubAtualizarTela() {
    const timeEl = document.getElementById('cb-hub-time');
    if (!timeEl) return;
    timeEl.textContent = cbHubFormatarTempo(cbHubSegundosRestantes);
    const total = CB_HUB_DURACOES[cbHubModo];
    const perimetro = 741;
    const offset = perimetro * (1 - cbHubSegundosRestantes / total);
    document.getElementById('cb-hub-ring-fill').style.strokeDashoffset = offset;
    document.getElementById('cb-hub-sublabel').textContent =
        cbHubModo === 'foco' ? 'Sessão de Foco' : cbHubModo === 'curta' ? 'Pausa curta' : 'Pausa longa';
    document.querySelectorAll('.cb-hub-tab').forEach(t => t.classList.toggle('ativa', t.dataset.modo === cbHubModo));
    document.getElementById('cb-hub-count-foco').textContent = cbHubContadores.foco;
    document.getElementById('cb-hub-count-curta').textContent = cbHubContadores.curta;
    document.getElementById('cb-hub-count-longa').textContent = cbHubContadores.longa;
    document.getElementById('cb-hub-startbtn').textContent = cbHubRodando ? '⏸ Pausar' : '▶ Começar';
}

function cbHubTrocarModo(modo) {
    cbHubModo = modo;
    cbHubSegundosRestantes = CB_HUB_DURACOES[modo];
    cbHubPararIntervalo();
    cbHubRodando = false;
    cbHubAtualizarTela();
}

function cbHubPararIntervalo() {
    clearInterval(cbHubIntervalo);
    cbHubIntervalo = null;
}

function cbHubAlternarRodando() {
    cbHubRodando = !cbHubRodando;
    if (cbHubRodando) {
        // Sem isso, um clique duplo no botão (ou o overlay sendo remontado
        // com cbHubRodando já true) criava um SEGUNDO setInterval sem
        // derrubar o primeiro — os dois decrementavam cbHubSegundosRestantes
        // por segundo ao mesmo tempo, fazendo o anel "fechar" (esvaziar) no
        // dobro da velocidade real.
        cbHubPararIntervalo();
        cbHubIntervalo = setInterval(() => {
            cbHubSegundosRestantes--;
            if (cbHubSegundosRestantes <= 0) {
                cbHubContadores[cbHubModo]++;
                cbHubPararIntervalo();
                cbHubRodando = false;
                cbHubSegundosRestantes = CB_HUB_DURACOES[cbHubModo];
                try { new Notification('Concurseiro Blindado', { body: 'Sessão concluída!' }); } catch (err) {}
            }
            cbHubAtualizarTela();
        }, 1000);
    } else {
        cbHubPararIntervalo();
    }
    cbHubAtualizarTela();
}

function cbHubCarregarDesempenho() {
    // Aproveita o caderno de erros já existente na extensão, quando disponível,
    // pra não duplicar essa contagem em outro lugar.
    chrome.storage.local.get(['cbCadernoErros', 'cbCadernoAcertos'], (result) => {
        const erros = Array.isArray(result.cbCadernoErros) ? result.cbCadernoErros.length : (result.cbCadernoErros || 0);
        const acertos = result.cbCadernoAcertos || 0;
        const acertosEl = document.getElementById('cb-hub-acertos');
        const errosEl = document.getElementById('cb-hub-erros');
        const barFill = document.getElementById('cb-hub-bar-fill');
        if (!acertosEl) return;
        acertosEl.textContent = acertos;
        errosEl.textContent = erros;
        const total = acertos + erros;
        barFill.style.width = total > 0 ? `${Math.round((acertos / total) * 100)}%` : '0%';
    });
}

function cbAbrirHub() {
    cbHubMontarHTML();
    cbHubAtualizarTela();
    cbHubCarregarDesempenho();
    cbHubOverlay.classList.add('cb-dock-open');
}

function cbFecharHub() {
    cbHubOverlay.classList.remove('cb-dock-open');
    cbHubPararIntervalo();
    cbHubRodando = false;
}

// --------------------------------------------------------------------------
// Mapa Mental — desenho livre (canvas) + cartões de texto arrastáveis,
// no estilo dos post-its coloridos que a pessoa monta na tela.
// --------------------------------------------------------------------------
const cbMapaOverlay = document.createElement('div');
cbMapaOverlay.id = 'cb-mapa-overlay';
cbMapaOverlay.innerHTML = `
    <div class="cb-mapa-toolbar">
        <button id="cb-mapa-lapis" class="ativo">✏️ Lápis</button>
        <button id="cb-mapa-borracha">🧹 Borracha</button>
        <div class="cb-mapa-cores" id="cb-mapa-cores"></div>
        <button id="cb-mapa-texto">${CB_DOCK_ICONS.mais} Cartão de texto</button>
        <button id="cb-mapa-limpar">Limpar desenho</button>
        <div style="flex:1"></div>
        <button id="cb-mapa-novo">Novo mapa</button>
        <button id="cb-mapa-galeria-btn">Meus mapas</button>
        <button id="cb-mapa-salvar">💾 Salvar</button>
        <button id="cb-mapa-fechar">${CB_DOCK_ICONS.fechar} Fechar</button>
    </div>
    <div class="cb-mapa-canvaswrap">
        <canvas id="cb-mapa-canvas"></canvas>
    </div>
`;
document.documentElement.appendChild(cbMapaOverlay);

const cbMapaGaleria = document.createElement('div');
cbMapaGaleria.id = 'cb-mapa-galeria';
document.documentElement.appendChild(cbMapaGaleria);

const CB_MAPAS_STORAGE_KEY = 'cbMapasMentais';
let cbMapaAtualId = null;

const CB_MAPA_CORES = ['#2dd4a0', '#ff6767', '#ffd27a', '#7ea3ff', '#c58bff', '#ffffff'];
let cbMapaCorAtual = CB_MAPA_CORES[0];
let cbMapaFerramenta = 'lapis';
let cbMapaDesenhando = false;
let cbMapaCtx = null;

function cbMapaMontarCores() {
    const wrap = cbMapaOverlay.querySelector('#cb-mapa-cores');
    wrap.innerHTML = CB_MAPA_CORES.map(c => `<div class="cb-mapa-cor ${c === cbMapaCorAtual ? 'selected' : ''}" data-cor="${c}" style="background:${c}"></div>`).join('');
    wrap.querySelectorAll('.cb-mapa-cor').forEach(el => {
        el.addEventListener('click', () => {
            cbMapaCorAtual = el.dataset.cor;
            cbMapaMontarCores();
        });
    });
}
cbMapaMontarCores();

function cbMapaRedimensionarCanvas() {
    const canvas = cbMapaOverlay.querySelector('#cb-mapa-canvas');
    const wrap = cbMapaOverlay.querySelector('.cb-mapa-canvaswrap');
    const imgAntes = canvas.width ? canvas.toDataURL() : null;
    canvas.width = wrap.clientWidth;
    canvas.height = wrap.clientHeight;
    cbMapaCtx = canvas.getContext('2d');
    cbMapaCtx.lineCap = 'round';
    cbMapaCtx.lineJoin = 'round';
    if (imgAntes) {
        const img = new Image();
        img.onload = () => cbMapaCtx.drawImage(img, 0, 0);
        img.src = imgAntes;
    }
}

cbMapaOverlay.querySelector('#cb-mapa-lapis').addEventListener('click', (e) => {
    cbMapaFerramenta = 'lapis';
    cbMapaOverlay.querySelectorAll('.cb-mapa-toolbar button').forEach(b => b.classList.remove('ativo'));
    e.currentTarget.classList.add('ativo');
});
cbMapaOverlay.querySelector('#cb-mapa-borracha').addEventListener('click', (e) => {
    cbMapaFerramenta = 'borracha';
    cbMapaOverlay.querySelectorAll('.cb-mapa-toolbar button').forEach(b => b.classList.remove('ativo'));
    e.currentTarget.classList.add('ativo');
});
cbMapaOverlay.querySelector('#cb-mapa-limpar').addEventListener('click', () => {
    if (!confirm('Limpar todo o desenho deste mapa mental?')) return;
    cbMapaCtx.clearRect(0, 0, cbMapaCtx.canvas.width, cbMapaCtx.canvas.height);
});
cbMapaOverlay.querySelector('#cb-mapa-fechar').addEventListener('click', cbFecharMapaMental);
cbMapaOverlay.querySelector('#cb-mapa-texto').addEventListener('click', () => cbMapaCriarCartao());
cbMapaOverlay.querySelector('#cb-mapa-salvar').addEventListener('click', cbMapaSalvar);
cbMapaOverlay.querySelector('#cb-mapa-galeria-btn').addEventListener('click', (e) => cbMapaAbrirGaleria(e));
cbMapaOverlay.querySelector('#cb-mapa-novo').addEventListener('click', () => {
    if (!confirm('Começar um mapa mental novo? O que não foi salvo se perde.')) return;
    cbMapaAtualId = null;
    cbMapaCtx.clearRect(0, 0, cbMapaCtx.canvas.width, cbMapaCtx.canvas.height);
    cbMapaOverlay.querySelectorAll('.cb-mapa-cartao').forEach(c => c.remove());
});
document.addEventListener('click', (e) => {
    if (!cbMapaGaleria.contains(e.target) && e.target.id !== 'cb-mapa-galeria-btn') {
        cbMapaGaleria.classList.remove('cb-dock-open');
    }
});

function cbMapaPosicaoRelativa(e) {
    const canvas = cbMapaOverlay.querySelector('#cb-mapa-canvas');
    const rect = canvas.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
}

function cbMapaConfigurarDesenho() {
    const canvas = cbMapaOverlay.querySelector('#cb-mapa-canvas');
    canvas.addEventListener('pointerdown', (e) => {
        cbMapaDesenhando = true;
        const { x, y } = cbMapaPosicaoRelativa(e);
        cbMapaCtx.beginPath();
        cbMapaCtx.moveTo(x, y);
    });
    canvas.addEventListener('pointermove', (e) => {
        if (!cbMapaDesenhando) return;
        const { x, y } = cbMapaPosicaoRelativa(e);
        cbMapaCtx.lineWidth = cbMapaFerramenta === 'borracha' ? 22 : 3;
        cbMapaCtx.strokeStyle = cbMapaFerramenta === 'borracha' ? '#0b0c11' : cbMapaCorAtual;
        cbMapaCtx.lineTo(x, y);
        cbMapaCtx.stroke();
    });
    ['pointerup', 'pointerleave'].forEach(ev => canvas.addEventListener(ev, () => { cbMapaDesenhando = false; }));
}

function cbMapaCriarCartao(texto, cor, x, y) {
    const wrap = cbMapaOverlay.querySelector('.cb-mapa-canvaswrap');
    const card = document.createElement('div');
    card.className = 'cb-mapa-cartao';
    card.contentEditable = true;
    card.style.background = cor || CB_MAPA_CORES[Math.floor(Math.random() * CB_MAPA_CORES.length)];
    card.style.left = (x !== undefined ? x : 40 + Math.random() * 200) + 'px';
    card.style.top = (y !== undefined ? y : 40 + Math.random() * 120) + 'px';
    card.innerHTML = `<button class="cb-mapa-cartao-del">${CB_DOCK_ICONS.fechar}</button>${texto || 'Adicionar texto'}`;
    card.querySelector('.cb-mapa-cartao-del').addEventListener('click', (e) => {
        e.stopPropagation();
        card.remove();
    });
    wrap.appendChild(card);

    let arrastando = false, offX = 0, offY = 0;
    card.addEventListener('pointerdown', (e) => {
        if (e.target.closest('.cb-mapa-cartao-del')) return;
        arrastando = true;
        const rect = card.getBoundingClientRect();
        offX = e.clientX - rect.left;
        offY = e.clientY - rect.top;
        card.setPointerCapture(e.pointerId);
    });
    card.addEventListener('pointermove', (e) => {
        if (!arrastando) return;
        const wrapRect = wrap.getBoundingClientRect();
        card.style.left = (e.clientX - wrapRect.left - offX) + 'px';
        card.style.top = (e.clientY - wrapRect.top - offY) + 'px';
    });
    card.addEventListener('pointerup', () => { arrastando = false; });
    return card;
}

// --------------------------------------------------------------------------
// Salvar / carregar mapas mentais — guarda o desenho (imagem) e os cartões
// de texto (posição, cor, conteúdo) em chrome.storage.local, com uma
// galeria de miniaturas pra reabrir depois.
// --------------------------------------------------------------------------
function cbMapaTextoDoCartao(card) {
    const clone = card.cloneNode(true);
    const del = clone.querySelector('.cb-mapa-cartao-del');
    if (del) del.remove();
    return clone.textContent.trim();
}

function cbMapaColetarCartoes() {
    return Array.from(cbMapaOverlay.querySelectorAll('.cb-mapa-cartao')).map(card => ({
        texto: cbMapaTextoDoCartao(card),
        cor: card.style.background,
        x: parseFloat(card.style.left) || 0,
        y: parseFloat(card.style.top) || 0,
        w: card.offsetWidth,
        h: card.offsetHeight
    }));
}

function cbMapaSalvar() {
    chrome.storage.local.get([CB_MAPAS_STORAGE_KEY], (result) => {
        const mapas = Array.isArray(result[CB_MAPAS_STORAGE_KEY]) ? result[CB_MAPAS_STORAGE_KEY] : [];
        const existente = cbMapaAtualId ? mapas.find(m => m.id === cbMapaAtualId) : null;
        const nome = prompt('Nome deste mapa mental:', existente ? existente.nome : `Mapa ${mapas.length + 1}`);
        if (!nome) return;
        const registro = {
            id: cbMapaAtualId || cbDockIdUnico(),
            nome,
            desenho: cbMapaCtx.canvas.toDataURL('image/png'),
            cartoes: cbMapaColetarCartoes(),
            atualizadoEm: Date.now()
        };
        cbMapaAtualId = registro.id;
        const idx = mapas.findIndex(m => m.id === registro.id);
        if (idx >= 0) mapas[idx] = registro; else mapas.push(registro);
        chrome.storage.local.set({ [CB_MAPAS_STORAGE_KEY]: mapas }, () => {
            alert('Mapa mental salvo.');
        });
    });
}

function cbMapaCarregar(mapa) {
    cbMapaAtualId = mapa.id;
    cbMapaOverlay.querySelectorAll('.cb-mapa-cartao').forEach(c => c.remove());
    cbMapaCtx.clearRect(0, 0, cbMapaCtx.canvas.width, cbMapaCtx.canvas.height);
    if (mapa.desenho) {
        const img = new Image();
        img.onload = () => cbMapaCtx.drawImage(img, 0, 0, cbMapaCtx.canvas.width, cbMapaCtx.canvas.height);
        img.src = mapa.desenho;
    }
    (mapa.cartoes || []).forEach(c => {
        const card = cbMapaCriarCartao(c.texto, c.cor, c.x, c.y);
        if (c.w) card.style.width = c.w + 'px';
        if (c.h) card.style.height = c.h + 'px';
    });
}

function cbMapaAbrirGaleria(e) {
    e.stopPropagation();
    const rect = e.currentTarget.getBoundingClientRect();
    cbMapaGaleria.style.left = Math.max(10, Math.min(rect.left, window.innerWidth - 300)) + 'px';
    cbMapaGaleria.style.top = (rect.bottom + 8) + 'px';

    chrome.storage.local.get([CB_MAPAS_STORAGE_KEY], (result) => {
        const mapas = Array.isArray(result[CB_MAPAS_STORAGE_KEY]) ? result[CB_MAPAS_STORAGE_KEY] : [];
        cbMapaGaleria.innerHTML = `<h4>Meus mapas mentais</h4><div id="cb-mapa-galeria-lista"></div>`;
        const lista = cbMapaGaleria.querySelector('#cb-mapa-galeria-lista');
        if (!mapas.length) {
            lista.innerHTML = '<div class="cb-mapa-galeria-vazio">Nenhum mapa salvo ainda.</div>';
        }
        mapas.slice().sort((a, b) => b.atualizadoEm - a.atualizadoEm).forEach(m => {
            const item = document.createElement('div');
            item.className = 'cb-mapa-galeria-item';
            item.innerHTML = `<img src="${m.desenho}" alt=""><span class="nome">${m.nome}</span><button title="excluir">${CB_DOCK_ICONS.fechar}</button>`;
            item.addEventListener('click', (ev) => {
                if (ev.target.closest('button')) return;
                cbMapaCarregar(m);
                cbMapaGaleria.classList.remove('cb-dock-open');
            });
            item.querySelector('button').addEventListener('click', (ev) => {
                ev.stopPropagation();
                if (!confirm(`Excluir o mapa "${m.nome}"?`)) return;
                const restantes = mapas.filter(x => x.id !== m.id);
                chrome.storage.local.set({ [CB_MAPAS_STORAGE_KEY]: restantes }, () => cbMapaAbrirGaleria(e));
            });
            lista.appendChild(item);
        });
        cbMapaGaleria.classList.add('cb-dock-open');
    });
}

function cbAbrirMapaMental() {
    cbMapaOverlay.classList.add('cb-dock-open');
    if (!cbMapaCtx) {
        cbMapaConfigurarDesenho();
    }
    setTimeout(cbMapaRedimensionarCanvas, 0);
}

function cbFecharMapaMental() {
    cbMapaOverlay.classList.remove('cb-dock-open');
}

window.addEventListener('resize', () => {
    if (cbMapaOverlay.classList.contains('cb-dock-open')) cbMapaRedimensionarCanvas();
});

// Fecha o Hub e o Mapa Mental com Esc, igual ao resto dos painéis flutuantes.
document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if (cbHubOverlay.classList.contains('cb-dock-open')) cbFecharHub();
    if (cbMapaOverlay.classList.contains('cb-dock-open')) cbFecharMapaMental();
}, true);

cbDockCarregarEDesenhar();

// ===================== MODO DE ECONOMIA (monitor de CPU/RAM) =====================
// Este content script roda em TODA aba http(s) aberta (ver
// cbRegistrarOverlayGlobal em background.js) — se o aparelho da pessoa
// estiver sob carga pesada (muitas abas, PC/celular fraco, vídeo pesado
// rodando em outra aba etc.), as animações contínuas da UI flutuante da
// extensão (glow do anel, blur nos painéis, giro) podem ser a gota d'água
// que deixa a navegação travando.
//
// Não existe API de extensão que devolva "% de CPU" ou "MB de RAM livre" do
// sistema — então usamos o proxy mais confiável disponível: o tempo real
// entre frames de renderização (requestAnimationFrame). Se os frames estão
// demorando MUITO mais que os ~16.6ms esperados a 60fps, de forma
// consistente (não só um soluço isolado), é sinal de que o processador está
// sufocado, seja lá qual for o motivo. Quando detecta isso, remove toda
// animação/blur decorativos por alguns minutos.
//
// IMPORTANTE: isso nunca toca no cronômetro em si (contagem/timestamps em
// background.js e no setInterval do Hub) — só classes CSS puramente visuais.
// Ver interface-popup/style.css (.cb-perf-safe-mode) pro equivalente do
// anel principal do popup.
const cbPerfStyleTag = document.createElement('style');
cbPerfStyleTag.textContent = `
html.cb-perf-safe-mode [id^="cb-"],
html.cb-perf-safe-mode [class*="cb-"] {
    animation: none !important;
    backdrop-filter: none !important;
    -webkit-backdrop-filter: none !important;
}
`;
document.head.appendChild(cbPerfStyleTag);

const CB_PERF_JANELA_AMOSTRAS = 30;         // ~meio segundo de frames a 60fps
const CB_PERF_LIMIAR_MS = 42;               // média de frame > 42ms ~= abaixo de 24fps
const CB_PERF_CONFIRMACOES_NECESSARIAS = 3; // 3 janelas ruins seguidas antes de agir (evita reagir a 1 soluço isolado)
const CB_PERF_SAFE_MODE_DURACAO_MS = 3 * 60 * 1000; // 3 minutos de modo economia por vez, renovável

let cbPerfAmostras = [];
let cbPerfUltimoFrame = 0;
let cbPerfConfirmacoesRuins = 0;
let cbPerfSafeModeAteTs = 0;
let cbPerfSafeModeAtivo = false;

function cbPerfChecarMemoria() {
    // performance.memory só existe em navegadores baseados em Chromium — em
    // outros (Firefox) simplesmente não existe, então esse sinal vira
    // "sem dado" e a decisão fica só por conta do tempo de frame acima.
    const mem = performance.memory;
    if (!mem || !mem.jsHeapSizeLimit) return false;
    return (mem.usedJSHeapSize / mem.jsHeapSizeLimit) > 0.92;
}

function cbPerfAtivarSafeMode() {
    cbPerfSafeModeAteTs = Date.now() + CB_PERF_SAFE_MODE_DURACAO_MS;
    if (cbPerfSafeModeAtivo) return;
    cbPerfSafeModeAtivo = true;
    document.documentElement.classList.add('cb-perf-safe-mode');
}

function cbPerfChecarFimSafeMode() {
    if (cbPerfSafeModeAtivo && Date.now() >= cbPerfSafeModeAteTs) {
        cbPerfSafeModeAtivo = false;
        document.documentElement.classList.remove('cb-perf-safe-mode');
    }
}

function cbPerfFrameTick(agora) {
    if (cbPerfUltimoFrame) {
        const delta = agora - cbPerfUltimoFrame;
        cbPerfAmostras.push(delta);
        if (cbPerfAmostras.length >= CB_PERF_JANELA_AMOSTRAS) {
            const media = cbPerfAmostras.reduce((a, b) => a + b, 0) / cbPerfAmostras.length;
            cbPerfAmostras = [];
            if (media > CB_PERF_LIMIAR_MS || cbPerfChecarMemoria()) {
                cbPerfConfirmacoesRuins++;
                if (cbPerfConfirmacoesRuins >= CB_PERF_CONFIRMACOES_NECESSARIAS) {
                    cbPerfAtivarSafeMode();
                }
            } else {
                cbPerfConfirmacoesRuins = 0;
            }
        }
    }
    cbPerfUltimoFrame = agora;
    cbPerfChecarFimSafeMode();
    requestAnimationFrame(cbPerfFrameTick);
}

requestAnimationFrame(cbPerfFrameTick);

})();
